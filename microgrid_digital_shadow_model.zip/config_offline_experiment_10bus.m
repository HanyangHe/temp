function cfg = config_offline_experiment_10bus()
%CONFIG_OFFLINE_EXPERIMENT_10BUS Settings for manuscript Offline Experiment Part 1.
%
% Common training-data rule:
%   N = (# short trajectories) * (# saved points per trajectory).
% Pointwise vector-field methods (SINDy variants and CT M-KBF) use the common
% [local x,V,u] -> xdot samples, with complete trajectories retained for the
% validation split. Neural ODE keeps trajectory grouping for multi-step loss.
% The exact algebraic network is shared by every learned baseline.
%
% This file intentionally lives at the PROJECT ROOT.

cfg.name = 'offline_model_accuracy_10bus';

%% Experiment switches
cfg.run.section1p1 = true;
cfg.run.section1p2 = true;
cfg.run.section1p3 = true;
cfg.displayTrueSys = false;

%% Section-level parallel execution
% Scientific sections remain sequential and data-sampling seeds remain serial.
% Within each section, all missing activated method/condition jobs are flattened
% into one bounded parfor queue. Six workers are used for the current non-NODE
% completion campaign on the six-core local CPU; this changes wall-clock time only.
cfg.parallel.enabled = true;
cfg.parallel.mode = 'within_section';
cfg.parallel.numWorkers = 6;
cfg.parallel.autoStartPool = true;
cfg.parallel.poolProfile = 'local';
cfg.parallel.section1p1 = true;
cfg.parallel.section1p2 = true;
cfg.parallel.section1p3 = true;

% Final primary manuscript set.
% Baselines: M-KBF, V-SINDy, PE-SINDy, ED-SINDy, and NODE.
% Proposed: LLM-Prior SINDy.
%
% NODE is REPLAY-ONLY in the ordinary MLX campaign because it is trained in a
% separate expensive overnight workflow. Keep it in methodsToRun so complete
% saved NODE bundles are merged into the final multi-seed summary, but never
% place it in the section compute selectors below.
cfg.run.methodsToRun = { ...
    'modular_koopman_kbf', ...
    'vanilla_sindy', ...
    'physics_embedded_sindy', ...
    'edsi', ...
    'neural_ode_modular', ...
    'llm_prior_sindy'};
cfg.run.optionalReplayOnlyMethods = {'neural_ode_modular'};

% Ordinary MLX compute set: NODE is deliberately omitted.
cfg.run.section1p1MethodsToRun = { ...
    'modular_koopman_kbf', ...
    'vanilla_sindy', ...
    'physics_embedded_sindy', ...
    'edsi', ...
    'llm_prior_sindy'};
cfg.run.section1p2MethodsToRun = cfg.run.section1p1MethodsToRun;
cfg.run.section1p3MethodsToRun = cfg.run.section1p1MethodsToRun;

%% Manuscript study settings
cfg.typicalSampleCount = 500;
% Full manuscript sweeps:
cfg.sampleCounts = [250 500 750 1000 2000]; 
cfg.noiseLevels = [0 0.001 0.005 0.01 0.05 0.10];
% Development/smoke setting:
% cfg.sampleCounts = [500];
% cfg.noiseLevels = [0];
% Three independent DATA-SAMPLING seeds for manuscript statistics.
% The validation split, neural-basis seed, and noise seed remain fixed
% across these runs so the reported spread isolates identification-data
% sampling variability.
cfg.randomSeeds = [20260814 20260815 20260816];
cfg.randomSeed = cfg.randomSeeds(1); % single-seed fallback / first representative seed
cfg.multiseed.enabled = true;
cfg.multiseed.seedFolderName = 'seed_runs';
cfg.multiseed.keepSeedFigures = false;
cfg.multiseed.errorBar = 'std';

% Official cross-network protocol: the same fixed V4 physical prior bank
% is reused for ALL data seeds and ALL 10/69/123-bus networks.  Only the
% training-data Sobol seed varies; device-instance coefficients are fitted
% independently.  Bank 3755CE11 was verified from 69-bus 3-seed MAT records.
cfg.multiseed.llmPriorDiscoveryPolicy = 'fixed_bank';
cfg.multiseed.llmPriorFixedDiscoverySeed = 20260814;
cfg.multiseed.llmPriorExpectedBankHash = '3755CE11';
% Never silently plot a one-seed subset as a completed three-seed campaign.
cfg.multiseed.strictPlotSeedCoverage = true;

%% Short-trajectory training-data design
% Final practical NODE/SINDy common-data design selected after NODE tuning:
% With N=500 -> 10 trajectories x 50 points; one trajectory is the test-initial
% anchor and the remaining 9 are Sobol-started. Pointwise SINDy uses all 500
% flattened sample pairs regardless of their sequence.
cfg.data.pointsPerTrajectory = 50;
cfg.data.trajectorySampleStep = 0.010;
cfg.data.trajectoryDuration = ...
    (cfg.data.pointsPerTrajectory-1)*cfg.data.trajectorySampleStep;
cfg.data.includeTestInitialAnchor = true;

allN = unique([cfg.typicalSampleCount cfg.sampleCounts(:).']);
if any(mod(allN,cfg.data.pointsPerTrajectory) ~= 0)
    error('config_offline_experiment_10bus:TrajectoryPacking', ...
        ['Every requested sample count must be divisible by pointsPerTrajectory=%d. ', ...
         'Current N values: [%s].'],cfg.data.pointsPerTrajectory, ...
        strtrim(sprintf('%d ',allN)));
end

%% Sobol / DAE-consistency data generation
cfg.data.reuseExisting = true;
cfg.data.forceRegenerate = false;
cfg.data.sobolSkip = 1024;
cfg.data.sobolLeap = 31;
cfg.data.sobolScramble = true;
cfg.data.maxCandidateMultiplier = 4.0;
cfg.data.progressEveryAcceptedTrajectory = 10;
cfg.data.acceptVoltageMinPU = 0.90;
cfg.data.acceptVoltageMaxPU = 1.10;
cfg.data.acceptAlgebraicResidualInf = 1e-8;
cfg.data.fsolve.FunctionTolerance = 1e-10;
cfg.data.fsolve.StepTolerance = 1e-10;
cfg.data.fsolve.OptimalityTolerance = 1e-10;
cfg.data.fsolve.MaxIterations = 120;
cfg.data.fsolve.MaxFunctionEvaluations = 4000;
cfg.data.truthSegment.RelTol = 1e-8;
cfg.data.truthSegment.AbsTol = 1e-10;
cfg.data.truthSegment.MaxStep = min(0.005,cfg.data.trajectorySampleStep);

%% Differential-state Sobol ranges around nominal equilibrium
cfg.sampling.state.sg.deltaHalfRangeRad = 0.080;
cfg.sampling.state.sg.nuHalfRangePU = 0.0020;
% Additional five-state SG+AVR coordinates (used when the active SG has them).
cfg.sampling.state.sg.EqPrimeHalfRangePU = 0.040;
cfg.sampling.state.sg.EdPrimeHalfRangePU = 0.030;
cfg.sampling.state.sg.EfdHalfRangePU = 0.080;
cfg.sampling.state.gfm.deltaHalfRangeRad = 0.080;
cfg.sampling.state.gfm.pFiltRelativeHalfRange = 0.30;
cfg.sampling.state.gfm.pFiltAbsoluteFloor = 0.010;
cfg.sampling.state.gfm.qFiltHalfRangePU = 0.020;
cfg.sampling.state.gfm.EHalfRangePU = 0.030;
cfg.sampling.state.gfl.thetaHalfRangeRad = 0.080;
cfg.sampling.state.gfl.xiPLLHalfRange = 2.0e-4;
cfg.sampling.state.gfl.idHalfRangePU = 0.015;
cfg.sampling.state.gfl.iqHalfRangePU = 0.015;

%% Controllable-input Sobol ranges
cfg.sampling.input.loadScaleRange = [0.80 1.20];
cfg.sampling.input.sgPmScaleRange = [0.85 1.15];
% AVR Vref is independently sampled so it is not collinear with the constant term.
cfg.sampling.input.sgVrefAddRangePU = [-0.015 +0.015];
cfg.sampling.input.gfmPstarAddRangePU = [-0.015 +0.015];
cfg.sampling.input.gfmQstarAddRangePU = [-0.015 +0.015];
cfg.sampling.input.gfmErefAddRangePU = [-0.030 +0.030];
cfg.sampling.input.gflPstarAddRangePU = [-0.012 +0.012];
cfg.sampling.input.gflQstarAddRangePU = [-0.012 +0.012];

%% Neural ODE baseline -- finalized practical configuration
% NODE is enabled for the Stage-4 baseline completion campaign.
cfg.node.enabled = true; % registered for replay; omitted from ordinary section compute selectors
cfg.node.hiddenSizes = [64 64];
cfg.node.gradientMode = 'adjoint';
cfg.node.trainingProtocolVersion = 'adjoint_window25_meaningful_es_v1';
cfg.node.validationFraction = 0.20;
cfg.node.validationSeed = 20260816;
cfg.node.numRestarts = 1;
cfg.node.restartSeed = 20260820;
cfg.node.maxEpochs = 500;
cfg.node.miniBatchTrajectories = 8;
% NODE optimization only: preserve every original 50-point observation but
% train through two non-overlapping 25-point windows per trajectory. The
% held-out validation trajectories remain at the original full length.
cfg.node.trainingWindowPoints = 25;
if mod(cfg.data.pointsPerTrajectory,cfg.node.trainingWindowPoints) ~= 0
    error('NODE trainingWindowPoints=%d must exactly divide pointsPerTrajectory=%d.', ...
        cfg.node.trainingWindowPoints,cfg.data.pointsPerTrajectory);
end
cfg.node.initialLearnRate = 1.0e-3;
cfg.node.learnRateDropFactor = 0.5;
cfg.node.learnRateDropPeriodEpochs = 150;
cfg.node.gradientDecayFactor = 0.9;
cfg.node.squaredGradientDecayFactor = 0.999;
cfg.node.validationFrequencyEpochs = 5;
cfg.node.validationPatienceChecks = 20;
% Tiny numerical decreases should not keep an expensive NODE job alive.
% The numerically best model is still retained; this threshold only controls
% whether patience is reset.
cfg.node.earlyStopping.minRelativeImprovement = 0.002;
% Completed NODE conditions are checkpointed to disk immediately; the long
% sweep keeps only compact report-facing copies in RAM between conditions.
cfg.node.compactInMemoryEvaluations = true;
cfg.node.verbose = true;
cfg.node.solver.RelativeTolerance = 1e-4;
cfg.node.solver.AbsoluteTolerance = 1e-5;
cfg.node.solver.MaxStepSize = min(0.005,cfg.data.trajectorySampleStep);
cfg.node.normalization.relativeFloor = 1e-6;
cfg.node.normalization.absoluteFloor = 1e-8;

%% Modular bilinear Koopman baseline (continuous Eq. 16 adaptation)
% Same learned-module boundary as NODE/SINDy: local DER state + terminal bus
% voltage + local references -> DER differential dynamics. The exact network
% algebraic equations remain common physics during rollout.
%
% The fixed lift is z=T(s), where s is the normalized local DER state and T
% contains all monomials through order 3. Lift derivatives are obtained by the
% analytic chain rule from xdot labels. The learned matrices directly identify
% Jiang et al. Eq. (16): zdot=A*z+sum_i q_i*B_i*z. Because the degree-one
% observables equal s exactly, xdot is recovered by a fixed algebraic map from
% zdot; no discrete KBF step or (x_next-x)/dt approximation is used.
% Low-data conditioning is improved by joint SVD-rank + ridge selection on
% held-out vector-field error; the ordinary normalized Poly-3 lift is unchanged.
cfg.koopman.enabled = true;
cfg.koopman.formulationVersion = 'continuous_generator_eq16_poly3_rankwindow_ridge_v4';
cfg.koopman.liftingMode = 'normalized_state_monomials';
cfg.koopman.polyOrder = 3;
cfg.koopman.validationFraction = 0.20;
cfg.koopman.validationSeed = 20260816;
cfg.koopman.verbose = true;
cfg.koopman.identificationForm = 'continuous_generator_eq16';
cfg.koopman.rolloutForm = 'direct_vector_field';
cfg.koopman.rankCandidateCount = 18;
cfg.koopman.rankFractionFloor = 0.05;
cfg.koopman.rankFractionCeiling = 1;
cfg.koopman.rankRelativeSingularValueFloor = 1e-10;
cfg.koopman.maxRank = inf;
cfg.koopman.ridgeRelativeGrid = [0 1e-10 1e-8 1e-7 1e-6 1e-5 1e-4 1e-3 1e-2];
cfg.koopman.preferSimplerWithinRelativeValidationTolerance = 0.01;
cfg.koopman.validationAbsoluteTolerance = 1e-12;
cfg.koopman.maxAutonomousRealPart = 10.0;
cfg.koopman.enforceConstantObservableDerivative = true;
cfg.koopman.normalization.stateStdFloor = 1e-8;
cfg.koopman.normalization.forceStdFloor = 1e-8;
cfg.koopman.normalization.outputScaleFloor = 1e-10;

%% Modular SINDy baselines and compact neural-candidate variant
% Generic library for every module:
%   Theta_0(chi) = [1, all raw-input monomials of degree 1..p,
%                   sin(raw chi_i), cos(raw chi_i)]
% where chi uses exactly the same local state/terminal-voltage/control scope as
% the corresponding NODE module.
cfg.sindy.enabled = true;
cfg.sindy.polyOrderOption = 2;       % Poly-2 generic/universal terms for V-/PE-SINDy
cfg.sindy.includeSin = true;
cfg.sindy.includeCos = true;
cfg.sindy.validationFraction = 0.20;
cfg.sindy.validationSeed = 20260816;
cfg.sindy.verbose = true;

% Independent registry switches.
cfg.sindy.vanilla.enabled = true;
cfg.sindy.poly3Baseline.enabled = false; % supplementary dictionary-width ablation only
cfg.sindy.physicsEmbedded.enabled = true;  % PE-SINDy strong-prior baseline and prior-recovery reference

% Proposed LLM-Prior SINDy. The actual seed-specific priorBank/priorItems are
% injected automatically by prepare_offline_llm_prior_config before training.
% Discovery is shared across network cases and repeated only across manuscript
% discovery/data seeds; N and noise sweeps reuse the same bank for that seed.
cfg.sindy.llmPrior.enabled = true;
cfg.sindy.llmPrior.formulationVersion = 'llm_prior_sindy_weak_domain_compiled_v1';
cfg.sindy.llmPrior.discoveryProtocolVersion = 'weak_domain_canonical_deterministic_closure_v4';
cfg.sindy.llmPrior.reasoningEffort = 'medium';
cfg.sindy.llmPrior.maxOutputTokens = 8000;
cfg.sindy.llmPrior.maxBasisTerms = 18;
cfg.sindy.llmPrior.maxLatentFeatures = 8;
cfg.sindy.llmPrior.maxExpressionDepth = 8;
cfg.sindy.llmPrior.maxExpressionComplexity = 32;
cfg.sindy.llmPrior.maxBasisAbsValue = 1e10;
cfg.sindy.llmPrior.discoverySeed = 0;
cfg.sindy.llmPrior.priorBankHash = '';
cfg.sindy.llmPrior.priorBank = struct('sg',{{}},'gfm',{{}},'gfl',{{}});
cfg.sindy.llmPrior.priorItems = struct('sg',struct([]),'gfm',struct([]),'gfl',struct([]));

cfg.sindy.priorWeighted.enabled = false; % retired from final manuscript
cfg.sindy.neural.enabled = false; % legacy N-SINDy retained in code but excluded from manuscript tests
cfg.sindy.physicsNeural.enabled = false; % excluded from final primary comparison
cfg.sindy.physicsNeuralCompositional.enabled = false; % excluded from final primary comparison
cfg.sindy.physicsNeuralCompositional.includeLayer1BypassCandidate = true;
cfg.sindy.physicsNeuralCompositional.includeFlatPNSkipCandidate = true;
cfg.sindy.physicsNeuralCompositional.compositionalSeedOffset = 1000003;
cfg.sindy.priorWeightedNeural.enabled = false; % retired from final manuscript

% Weak SINDy baseline: SAME generic Poly-2 + sin/cos candidate library as
% V-SINDy, but coefficients are identified from compact-support weak integral
% constraints without pointwise xdot labels. This isolates weak-form noise
% handling from the proposed PNC-SINDy representation.
cfg.sindy.weakSindy.enabled = false; % excluded from final primary comparison
cfg.sindy.weakSindy.windowPoints = [11 21 31];
cfg.sindy.weakSindy.windowStride = 1;
cfg.sindy.weakSindy.testFunctionPower = 2;
cfg.sindy.weakSindy.thresholdGrid = [ ...
    1e-6 3e-6 1e-5 3e-5 1e-4 3e-4 ...
    1e-3 3e-3 1e-2 3e-2 1e-1 3e-1 ...
    1 3 10 30];
cfg.sindy.weakSindy.supportRidgeRelativeAlpha = 1e-10;

% Retired experimental Weak PN-SINDy option retained only for backward
% compatibility with old saved bundles; it is not registered or run.
cfg.sindy.weakPhysicsNeural.enabled = false;



% Fixed neural candidate generator used by PNC-SINDy and the optional flat PN-SINDy ablation.
% It replaces the generic polynomial+sin/cos dictionary with
% [1, raw chi, fixed neural-ridge features]; explicit physics is appended separately.
% The generator matches the PhDN fixed-neural-ridge design: train-only
% normalization, orthogonal direction blocks, projected-data quantiles,
% multiple tanh scales, variance/correlation screening, and pivoted QR.
cfg.sindy.neuralBasis.featureCount = 64;
cfg.sindy.neuralBasis.activation = 'tanh';
cfg.sindy.neuralBasis.quantiles = [0.20 0.40 0.60 0.80];
cfg.sindy.neuralBasis.scales = [0.5 1.0 2.0];
cfg.sindy.neuralBasis.poolRatio = 3.0;
cfg.sindy.neuralBasis.seed = 1701;
cfg.sindy.neuralBasis.stdFloor = 1e-10;
cfg.sindy.neuralBasis.varianceThreshold = 1e-8;
cfg.sindy.neuralBasis.correlationThreshold = 0.995;
cfg.sindy.neuralBasis.ensureFullDirectionalSpan = true;


% Validation-selected sequentially thresholded least squares (STLSQ).
% Training-only column/output normalization is used for threshold selection;
% exported coefficients are converted back to physical units for rollout.
cfg.sindy.stlsq.thresholdGrid = [ ...
    1e-6 3e-6 1e-5 3e-5 1e-4 3e-4 ...
    1e-3 3e-3 1e-2 3e-2 1e-1 3e-1 ...
    1 3 10 30];
cfg.sindy.formulationVersion = 'official_brunton_2015_ols_support_fixedrho1e10_noise_ridge_v10';
cfg.sindy.stlsq.solver = 'official_brunton_2015';
cfg.sindy.stlsq.maxIterations = 10; % official sparsifyDynamics uses exactly 10 iterations
cfg.sindy.stlsq.ridge = 0;          % FORMAL OLS-STLSQ support discovery
cfg.sindy.stlsq.finalSupportRidgeRho = 1e-10; % fixed clean final-support refit
% Choose the sparsest candidate whose validation nMSE lies within 5% of the
% best candidate. Set to 0 for exact minimum-validation-error selection.
cfg.sindy.stlsq.preferSparseWithinRelativeValidationTolerance = 0.05;
cfg.sindy.stlsq.validationAbsoluteTolerance = 1e-12;

% Shared numerical-conditioning rule for every active pointwise SINDy method.
% Stage 1: official OLS-STLSQ discovers support. Stage 2: exact labels receive
% a fixed rho=1e-10 refit on frozen support; reconstructed noisy derivatives
% use the validation-selected support-ridge grid below.
cfg.sindy.stlsq.trajectoryValidation.enabled = false;
cfg.sindy.stlsq.supportRidge.enabled = true;
cfg.sindy.stlsq.supportRidge.applicationPolicy = 'reconstructed_derivative_labels_only';
cfg.sindy.stlsq.supportRidge.relativeAlphaGrid = [ ...
    0 1e-10 1e-9 1e-8 1e-7 1e-6 1e-5 1e-4 1e-3 3e-3 ...
    1e-2 3e-2 1e-1 3e-1 1];
cfg.sindy.stlsq.supportRidge.tieRelativeValidationTolerance = 0.01;
cfg.sindy.normalization.libraryScaleFloor = 1e-12;
cfg.sindy.normalization.outputScaleFloor = 1e-12;

% Numerical protection for GFL physics term rhoV=1/(VR^2+VI^2).
cfg.sindy.physics.voltageMagnitudeSquaredFloor = 1e-8;


%% ED-SINDy baseline (internal method key: edsi)
% Pure data-driven fixed-width dictionary evolution. This is now a baseline;
% its coefficient-identification backend is intentionally identical to
% V-SINDy so only dictionary search changes.
cfg.edsi.enabled = true;
cfg.edsi.formulationVersion = 'edsi_sindy_fair_ols_support_fixedrho_v4';
cfg.edsi.supportDiscoveryRho = 0;
cfg.edsi.finalSupportRidgeRho = cfg.sindy.stlsq.finalSupportRidgeRho;
cfg.edsi.rho = cfg.edsi.finalSupportRidgeRho;
cfg.edsi.shareSindyIdentificationBackend = true;
cfg.edsi.searchStlsqIterations = 2;
cfg.edsi.searchThresholdGrid = cfg.sindy.stlsq.thresholdGrid;
cfg.edsi.searchPreferSparseWithinRelativeValidationTolerance = ...
    cfg.sindy.stlsq.preferSparseWithinRelativeValidationTolerance;
cfg.edsi.finalStlsqIterations = 10;
cfg.edsi.finalThresholdGrid = cfg.sindy.stlsq.thresholdGrid;
cfg.edsi.finalPreferSparseWithinRelativeValidationTolerance = ...
    cfg.sindy.stlsq.preferSparseWithinRelativeValidationTolerance;
cfg.edsi.populationSize = 32;
cfg.edsi.eliteCount = 8;
cfg.edsi.maxGenerations = 30;
cfg.edsi.stallPatience = 7;
cfg.edsi.minRelativeImprovement = 1e-4;
cfg.edsi.mutationSlotCounts = [1 2 3];
cfg.edsi.mutationSlotProbabilities = [0.60 0.30 0.10];
cfg.edsi.productProbability = 0.60;
cfg.edsi.sinProbability = 0.20;
cfg.edsi.cosProbability = 0.20;
cfg.edsi.maxBasisDepth = 3;
cfg.edsi.maxBasisComplexity = 7;
cfg.edsi.maxBasisAbsValue = 1e8;
cfg.edsi.libraryScaleFloor = 1e-12;
cfg.edsi.outputScaleFloor = 1e-12;
cfg.edsi.maxChildRetries = 50;
cfg.edsi.printEvery = 5;
cfg.edsi.evolutionSearchSeed = 1;

% Retired legacy LLM-EDSI implementation remains in the codebase for old
% bundles/reproducibility but is NOT part of the final manuscript method set.
cfg.llmEdsi.enabled = false;

%% State-measurement-noise robustness
% One noisy state trajectory is generated first and shared by ALL methods.
% NODE learns directly from xObserved. Pointwise SINDy/M-KBF receive the same
% noisy states plus xdot reconstructed from those states using one fixed local-
% polynomial differentiator. Weak SINDy uses the same noisy states but no
% pointwise xdot labels. Terminal-voltage forcing and commanded inputs remain
% clean so the study isolates state-measurement corruption.
cfg.noise.type = 'common_state_measurement_to_derivative_v1';
cfg.noise.seed = 20260815;
cfg.noise.minimumScale = 1e-12;
cfg.noise.derivative.method = 'local_polynomial';
cfg.noise.derivative.windowPoints = 15;
cfg.noise.derivative.polyOrder = 4;

%% Rollout early-abort guard
% Stop a learned-model rollout once it is already far outside the physically
% useful error range. This avoids spending tens or hundreds of seconds on an
% ODE15I trajectory that is numerically diverging and will be reported as a
% failed whole-window rollout anyway.
%
% maxNormalizedError uses a conservative per-variable RMS normalization of
% the clean truth trajectory with a small common scale floor. A value of 100
% therefore means that at least one DAE variable has deviated by 100 times its
% reference scale. The guard affects rollout cost only; it is NOT used for
% training, validation, or model selection.
cfg.rolloutGuard.enabled = true;
cfg.rolloutGuard.maxNormalizedError = 100;
cfg.rolloutGuard.maxAbsState = 1e3;
cfg.rolloutGuard.scaleFloorRelative = 1e-3;
cfg.rolloutGuard.scaleFloorAbsolute = 1e-6;
% Computational fail-safe: evaluated inside the ODE15I residual, so a
% pathological Newton/step-size stall cannot consume tens of minutes.
% Healthy rollouts are expected to finish well below these generous limits.
cfg.rolloutGuard.maxWallClockSeconds = 60;
cfg.rolloutGuard.maxResidualEvaluations = 150000;

%% Whole-trajectory DAE error metrics
cfg.metrics.scaleFloorRelative = 1e-6;
cfg.metrics.scaleFloorAbsolute = 1e-10;
cfg.metrics.mapeFloorRelative = 1e-5;
cfg.metrics.mapeFloorAbsolute = 1e-10;

%% Identical-condition reuse
cfg.reuse.identicalConditionsWithinRun = true;

%% LLM-Prior prior-level ablation (formal manuscript attribution test)
% Execution is controlled from microgrid_digital_shadow_offline_experiments.mlx
% by RunLLMPriorLevelAblation. This config freezes the scientific protocol.
%
% Architecture ladder:
%   L0 V-SINDy          : no added prior (fixed reference)
%   L1 Coordinate-only  : supplied local d/q coordinate atoms only (fixed reference)
%   L2 LLM-direct       : L1 + terms explicitly proposed by one LLM realization
%   L3 Full LLM-Prior   : L2 + deterministic closure expansion
%
% Official attribution design (v3):
%   * choose ONE fixed data realization using the best saved V-SINDy RMSE
%     among the ordinary manuscript data seeds; this choice is independent of
%     the proposed LLM method;
%   * hold that dataset fixed;
%   * vary FIVE independent LLM discovery realizations;
%   * L0/L1 are evaluated once, while L2/L3 are evaluated for every LLM
%     realization. Thus the bar/error bars for L2/L3 isolate LLM-prior
%     generation variability rather than data-preparation variability.
cfg.ablation.llmPriorLevel.enabled = true;
cfg.ablation.llmPriorLevel.designVersion = 'fixed_best_vsindy_data_five_llm_replicates_N1000_bar_v3';
cfg.ablation.llmPriorLevel.sampleCount = 1000;
cfg.ablation.llmPriorLevel.noiseLevel = 0;
cfg.ablation.llmPriorLevel.dataSeedSelection = 'best_v_sindy';
cfg.ablation.llmPriorLevel.candidateDataSeeds = cfg.randomSeeds;
cfg.ablation.llmPriorLevel.discoverySeeds = [20260814 20260815 20260816 20260817 20260818];
cfg.ablation.llmPriorLevel.outputFolder = 'ablation_llm_prior_levels_N1000';
cfg.ablation.llmPriorLevel.reuseCompleted = true;
cfg.ablation.llmPriorLevel.reuseOfficialVSindy = true;
cfg.ablation.llmPriorLevel.reuseOfficialLLMFull = true;
cfg.ablation.llmPriorLevel.allowFallbackCompute = true;

%% Figures / outputs
cfg.figures.visible = 'on';
cfg.figures.exportPDF = true;
cfg.figures.voltageBuses = [2 7 10];
cfg.figures.nCurrentBranches = 3;
cfg.output.folderName = 'offline_model_experiments_10bus';
cfg.output.saveMethodBundles = true;
cfg.output.methodResultsFolder = 'method_results';
cfg.output.methodReplayFileName = 'offline_part1_method_replay.mat';
cfg.output.saveEvaluationCache = true;
cfg.output.evaluationCacheFolder = 'evaluation_cache';
end
