function c = case_grid_connected_10bus_true_physics()
%CASE_GRID_CONNECTED_10BUS_TRUE_PHYSICS Reference physical DAE test case.
%
% First-stage truth model for the microgrid digital-shadow project.
% The electrical network is the 10-bus radial network used in the user's
% prior grid-connected and islanded EMS projects. The source allocation is
% modified here to include one SG, one GFM inverter, and one GFL inverter.
%
% Sign convention used everywhere in this project:
%   positive current/power = injection INTO the electrical network.
% Therefore, a consuming load has negative injection current.

%% System base
c.name = 'grid_connected_10bus_true_physics_sg_avr';
c.base.S = 1e6;          % VA
c.base.Vll = 480;        % V, line-to-line
c.base.f = 60;           % Hz
c.base.w = 2*pi*c.base.f;% rad/s
c.base.Z = c.base.Vll^2/c.base.S;
c.base.I = c.base.S/(sqrt(3)*c.base.Vll);

%% Network
c.network.N = 10;
c.network.mode = 'grid-connected';
c.network.slackBus = 1;
c.network.Vslack = 1 + 1i*0; % pu, infinite-bus voltage
c.network.line = line_data_10bus_user_ems(c.base);
c.network.Ybus = build_ybus(c.network.N,c.network.line);
c.network.nonSlackBuses = setdiff((1:c.network.N).',c.network.slackBus,'stable');

%% Device allocation
% Bus 1 is reserved for the external infinite grid in this first version.
% The heterogeneous dynamic devices are distributed through the feeder.
c.sg(1).bus = 3;
c.gfm(1).bus = 7;
c.gfl(1).bus = 10;

%% Synchronous generator: salient-pole transient model + first-order AVR
% State: [delta, nu, EqPrime, EdPrime, Efd]. Pm remains an external input,
% while Vref is the AVR reference input. H, D, and Xd' retain the scale of
% the user's earlier SG parameter block; the additional salient/AVR values
% below are new microgrid-study defaults rather than copied EMS parameters.
c.sg(1).model = 'salient_avr_5state';
c.sg(1).H = 1.0;          % s
c.sg(1).D = 0.8;          % pu damping coefficient
c.sg(1).Ra = 0.0025;      % pu stator resistance
c.sg(1).Xd = 1.80;        % pu d-axis synchronous reactance
c.sg(1).Xq = 1.70;        % pu q-axis synchronous reactance
c.sg(1).XdPrime = 0.25;   % pu d-axis transient reactance
c.sg(1).XqPrime = 0.55;   % pu q-axis transient reactance (salient pole)
c.sg(1).TdoPrime = 0.80;  % s, open-circuit d-axis transient time constant
c.sg(1).TqoPrime = 0.25;  % s, open-circuit q-axis transient time constant
c.sg(1).KA = 20.0;        % AVR gain
c.sg(1).TA = 0.050;       % s, AVR/exciter time constant
c.sg(1).Pm0 = 0.060;      % pu mechanical input, nominal
c.sg(1).Vref0 = 1.050;    % pu AVR voltage reference, nominal
% Initialization-only guesses. The actual nominal equilibrium is solved by fsolve.
c.sg(1).EqPrimeGuess = 1.02;
c.sg(1).EdPrimeGuess = 0.00;
c.sg(1).EfdGuess = 1.00;

%% Grid-forming inverter: reduced droop model
% P-f droop is selected inside the 0.03--0.08 pu/pu range documented in the
% user's islanded EMS. The 0.15 pu output reactance follows the prior EMS
% inverter-branch reactance. Time constants below are new reduced-order
% truth-model defaults and are deliberately faster than the SG swing mode.
c.gfm(1).mp = 0.05;
c.gfm(1).nq = 0.05;
c.gfm(1).tauP = 0.050;          % s
c.gfm(1).tauQ = 0.050;          % s
c.gfm(1).tauE = 0.100;          % s
c.gfm(1).Zout = 0.02 + 1i*0.15;% pu virtual/output impedance
c.gfm(1).Pstar0 = 0.050;        % pu
c.gfm(1).Qstar0 = 0.000;        % pu
c.gfm(1).Eref0 = 1.000;         % pu

%% Grid-following inverter: SRF-PLL + first-order current loop
pllBandwidthHz = 10;
pllZeta = 0.707;
pllWn = 2*pi*pllBandwidthHz;
c.gfl(1).KpPLL = 2*pllZeta*pllWn/c.base.w;
c.gfl(1).KiPLL = pllWn^2/c.base.w;
c.gfl(1).tauI = 0.020;          % s
c.gfl(1).Pstar0 = 0.040;        % pu
c.gfl(1).Qstar0 = 0.000;        % pu
c.gfl(1).voltageRegularization = 1e-10;

%% Nominal constant-PQ loads
Pload = zeros(c.network.N,1);
Pload([2 4 6 8 9]) = [0.010 0.0145 0.0165 0.0185 0.025].';
Pload([5 7])       = [0.045 0.055].';
loadPF = 0.90;
Qload = Pload*tan(acos(loadPF));
c.input.nominal.Sload = Pload + 1i*Qload; % pu consumption, positive P/Q
c.input.nominal.sgPm = [c.sg.Pm0].';
c.input.nominal.sgVref = [c.sg.Vref0].';
c.input.nominal.gfmPstar = [c.gfm.Pstar0].';
c.input.nominal.gfmQstar = [c.gfm.Qstar0].';
c.input.nominal.gfmEref = [c.gfm.Eref0].';
c.input.nominal.gflPstar = [c.gfl.Pstar0].';
c.input.nominal.gflQstar = [c.gfl.Qstar0].';

%% Scenario purpose and paper-oriented transient design
% Default scenario: 12-s all-DER transient-rich operating sequence.
%
% Design principles:
%   1) the complete 12-s window is used for trajectory-error evaluation;
%   2) operating actions are distributed quasi-uniformly over the window;
%   3) neighboring event centers are separated by about 1.62 s so the DAE
%      can approach a new quasi-steady operating point before the next action;
%   4) all load buses participate through two spatial groups;
%   5) SG, GFM and GFL are all actively excited through physically meaningful
%      controllable references;
%   6) actions are moderate persistent set-point/operating-point changes,
%      rather than closely spaced pulse pairs, so each transient is distinguishable.
%
% The event centers are
%   [0.60 2.22 3.84 5.46 7.08 8.70 10.32] s,
% giving a uniform 1.62-s separation and 1.68 s of final settling time.
c.scenario.name = 'paper_12s_all_DER_transient_rich';
c.scenario.description = [ ...
    "Twelve-second paper-oriented validation scenario with quasi-evenly spaced " ...
    + "load/SG/GFM/GFL operating actions and isolated transient responses."];
c.scenario.minInterEventSeparation = 1.50; % s; reporting/diagnostic target

%% Grouped operating-input/reference action sequences
% General group rule
% ------------------
% target vector: group(r).bus or group(r).device can have arbitrary length.
% time and fraction/delta MUST have the same length and define the shared
% action sequence executed by every target in that group.
%
% Load fraction values are incremental relative changes to each target bus's
% OWN nominal complex load (P and Q change together at fixed PF).
% DER delta values are additive increments in pu. Actions persist after their
% event time, so the physical system settles toward the corresponding new
% operating point before the next separated action occurs.

% Event 1, t = 0.60 s ------------------------------------------------------
% Upstream / central load cluster. Buses 2,4,5 share a +12% load change.
c.dist.load.enabled = true;
c.dist.load.group(1).bus = [2 4 5];
c.dist.load.group(1).time = 0.60;
c.dist.load.group(1).fraction = +0.12;
c.dist.load.group(1).transition = 0.030; % s

% Event 4, t = 5.46 s ------------------------------------------------------
% Downstream / GFM-side load cluster. Buses 6,7,8,9 share a -10% change.
c.dist.load.group(2).bus = [6 7 8 9];
c.dist.load.group(2).time = 5.46;
c.dist.load.group(2).fraction = -0.10;
c.dist.load.group(2).transition = 0.030; % s

% Event 2, t = 2.22 s ------------------------------------------------------
% SG mechanical input: excites electromechanical frequency dynamics.
c.dist.sgPm.enabled = true;
c.dist.sgPm.group(1).device = 1;
c.dist.sgPm.group(1).time = 2.22;
c.dist.sgPm.group(1).delta = +0.006;     % pu, 10% of nominal Pm=0.06
c.dist.sgPm.group(1).transition = 0.025; % s

% SG AVR-reference channel is available for later dedicated studies but is
% intentionally held fixed in the default 12-s paper scenario. The SG Pm
% event at 2.22 s already excites the expanded electromechanical/AVR states.
c.dist.sgVref.enabled = false;
c.dist.sgVref.group(1).device = 1;
c.dist.sgVref.group(1).time = 4.68;
c.dist.sgVref.group(1).delta = +0.010;    % pu
c.dist.sgVref.group(1).transition = 0.025;% s

% Event 3, t = 3.84 s ------------------------------------------------------
% GFM reactive-power reference: excites voltage / Q-droop dynamics.
c.dist.gfmQ.enabled = true;
c.dist.gfmQ.group(1).device = 1;
c.dist.gfmQ.group(1).time = 3.84;
c.dist.gfmQ.group(1).delta = +0.005;     % pu
c.dist.gfmQ.group(1).transition = 0.025; % s

% Event 6, t = 8.70 s ------------------------------------------------------
% GFM active-power reference: excites P-f droop / frequency dynamics.
c.dist.gfmP.enabled = true;
c.dist.gfmP.group(1).device = 1;
c.dist.gfmP.group(1).time = 8.70;
c.dist.gfmP.group(1).delta = -0.007;     % pu
c.dist.gfmP.group(1).transition = 0.025; % s

% GFM Eref is available in the platform but intentionally held fixed in the
% default paper scenario. Q* already excites the GFM voltage channel without
% imposing an additional direct internal-voltage-reference event.
c.dist.gfmEref.enabled = false;
c.dist.gfmEref.group(1).device = 1;
c.dist.gfmEref.group(1).time = 7.92;
c.dist.gfmEref.group(1).delta = +0.005;
c.dist.gfmEref.group(1).transition = 0.025; % s

% Event 5, t = 7.08 s ------------------------------------------------------
% GFL active-power command: excites PLL/current-loop/network coupling.
c.dist.gflP.enabled = true;
c.dist.gflP.group(1).device = 1;
c.dist.gflP.group(1).time = 7.08;
c.dist.gflP.group(1).delta = +0.006;     % pu
c.dist.gflP.group(1).transition = 0.025; % s

% Event 7, t = 10.32 s ------------------------------------------------------
% GFL reactive-power command: adds an independent Q/current-loop transient.
c.dist.gflQ.enabled = true;
c.dist.gflQ.group(1).device = 1;
c.dist.gflQ.group(1).time = 10.32;
c.dist.gflQ.group(1).delta = -0.004;     % pu
c.dist.gflQ.group(1).transition = 0.025; % s

%% Optional physical-model parameter drift
% Keep disabled in Experiment Part 1 (offline predictive accuracy). Parameter
% drift is reserved for the later online-adaptation experiment so offline model
% error is not mixed with an unannounced changing truth model.
c.drift.enabled = false;
c.drift.deviceType = 'gfm';
c.drift.device = 1;
c.drift.parameter = 'mp';
c.drift.time = 6.24;       % s, example only when enabled later
c.drift.mode = 'relative';
c.drift.value = 0.20;      % +20%
c.drift.transition = 0.050;% s

%% Simulation settings
% The full 12-s trajectory is used for all offline trajectory metrics.
% The final active event occurs at 10.32 s, leaving 1.68 s for settling.
c.sim.t0 = 0;
c.sim.tf = 12.0;
c.sim.outputStep = 0.005;     % s; fixed saved/evaluation grid
c.sim.RelTol = 1e-7;
c.sim.AbsTol = 1e-9;
c.sim.MaxStep = 0.005;        % s; resolves the 20-ms GFL current-loop scale
c.sim.saveResults = true;

%% Initialization
c.init.FunctionTolerance = 1e-11;
c.init.StepTolerance = 1e-11;
c.init.OptimalityTolerance = 1e-11;
c.init.MaxIterations = 500;
c.init.MaxFunctionEvaluations = 5e4;
c.init.acceptResidual = 1e-7;

%% Source traceability note stored with results
c.referenceNotes = [ ...
    "Network topology/line impedances: uploaded grid-connected and islanded EMS linedata.m (10-bus radial case)."; ...
    "Base values, PF=0.9, 10-bus load buses and nominal active powers: uploaded islanded EMS mainV4_EMS_islandMG_20260414.mlx, Case 1."; ...
    "SG H=1 s, D=0.8, Xd'=0.25 pu scale: retained from the uploaded islanded EMS parameter block."; ...
    "SG salient-pole, transient-EMF and AVR parameters: new project defaults introduced for the identification study."; ...
    "GFM/GFL reduced dynamic time constants and PLL bandwidth: new project defaults, not claimed as values copied from the prior EMS." ...
    ];
end
