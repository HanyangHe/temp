function line = line_data_69bus_user_ems(base)
%LINE_DATA_69BUS_USER_EMS 69-bus radial feeder adapted from the user's EMS.
%
% Columns in line.table:
%   [fromBus, toBus, R_pu, X_pu]
%
% Source-derived elements
% -----------------------
% The attached EMS linedata.m contains a commented 69-bus plan with:
%   - buses 1--27 on the main feeder using AWG750, 80 m per section;
%   - laterals using AWG1/0, 30 m per section;
%   - the explicit laterals 3--28--...--35, 4--47--...--50,
%     8--51--52, 9--53--...--65, 11--66--67, and 12--68--69.
%
% Reproducible completion of the uploaded branch block
% ----------------------------------------------------
% The uploaded 69-bus branch block omits buses 36--46 even though the EMS
% 69-bus bus/device plan actively uses those buses. The visible branch list
% therefore has only 57 lines and is disconnected. To make the intended
% radial 69-bus topology executable, this project completes the missing
% numbered lateral as
%     3--36--37--...--46.
% This adds 11 branches, yielding exactly 68 branches for 69 buses. Keep this
% traceability note with manuscript code; if an older original EMS topology
% file containing the omitted lines is recovered, it should be cross-checked
% against this inferred completion.

if nargin < 1 || isempty(base) || ~isfield(base,'Z')
    error('line_data_69bus_user_ems:Base','A base structure containing base.Z is required.');
end

% Copper three-phase cable impedances used by the prior EMS code.
z_AWG750 = 0.025 + 1i*0.08; % ohm/km
z_AWG1_0 = 0.35  + 1i*0.08; % ohm/km
Lmain = 80/1000;             % km
Lsub  = 30/1000;             % km

% Main feeder: 1--2--...--27 (26 branches).
fromMain = (1:26).';
toMain   = (2:27).';

% Laterals copied/reconstructed from the uploaded EMS 69-bus plan.
fromLat = [ ...
    3; (28:34).'; ...              % 3--28--...--35
    3; (36:45).'; ...              % inferred missing 3--36--...--46
    4; (47:49).'; ...              % 4--47--...--50
    8; 51; ...                      % 8--51--52
    9; (53:64).'; ...              % 9--53--...--65
    11; 66; ...                     % 11--66--67
    12; 68 ...                      % 12--68--69
    ];
toLat = [ ...
    28; (29:35).'; ...
    36; (37:46).'; ...
    47; (48:50).'; ...
    51; 52; ...
    53; (54:65).'; ...
    66; 67; ...
    68; 69 ...
    ];

from = [fromMain;fromLat];
to   = [toMain;toLat];

if numel(from) ~= 68 || numel(to) ~= 68
    error('line_data_69bus_user_ems:BranchCount', ...
        'The 69-bus radial feeder must contain exactly 68 branches.');
end

zOhm = [ ...
    repmat(Lmain*z_AWG750,numel(fromMain),1); ...
    repmat(Lsub*z_AWG1_0,numel(fromLat),1) ...
    ];
zPu = zOhm/base.Z;

line.table = [from,to,real(zPu),imag(zPu)];
line.zPu = zPu;
line.zOhm = zOhm;
line.from = from;
line.to = to;
line.sourceTag = 'user_EMS_69bus_with_inferred_36_46_lateral';
line.inferredBranchRows = (35:45).'; % 3-36 plus 36-37 ... 45-46 in full 68-row table
end
