function line = line_data_10bus_user_ems(base)
%LINE_DATA_10BUS_USER_EMS 10-bus radial feeder used in the user's EMS code.
%
% Columns in line.table:
%   [fromBus, toBus, R_pu, X_pu]
%
% Source: the 10-bus branch construction in linedata.m from the user's
% uploaded grid-connected and islanded EMS projects. The physical cable
% impedances are specified in ohm/km and each branch is 80 m long.

z_AWG2_0 = 0.29 + 1i*0.08; % ohm/km
z_AWG8   = 2.18 + 1i*0.08; % ohm/km
z_AWG4_0 = 0.17 + 1i*0.08; % ohm/km
z_AWG10  = 3.45 + 1i*0.08; % ohm/km
z_AWG1_0 = 0.35 + 1i*0.08; % ohm/km
z_AWG6   = 1.40 + 1i*0.08; % ohm/km
Lmain = 80/1000;            % km

zOhm = [ ...
    Lmain*z_AWG2_0/2; ... % 1-3, two parallel conductors in prior EMS
    Lmain*z_AWG8;     ... % 3-6
    Lmain*z_AWG4_0;   ... % 3-10
    Lmain*z_AWG10;    ... % 10-2
    Lmain*z_AWG1_0/2; ... % 3-4, two parallel conductors in prior EMS
    Lmain*z_AWG6;     ... % 4-5
    Lmain*z_AWG2_0;   ... % 4-7
    Lmain*z_AWG10;    ... % 7-9
    Lmain*z_AWG6      ... % 7-8
    ];

from = [1;3;3;10;3;4;4;7;7];
to   = [3;6;10;2;4;5;7;9;8];
zPu = zOhm/base.Z;

line.table = [from,to,real(zPu),imag(zPu)];
line.zPu = zPu;
line.zOhm = zOhm;
line.from = from;
line.to = to;
end
