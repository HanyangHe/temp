function c = case_grid_connected_69bus_receding_horizon()
%CASE_GRID_CONNECTED_69BUS_RECEDING_HORIZON 60-s extension of paper 12-s case.
%
% The original event-rich 12-s scenario is repeated over five 12-s blocks.
% Each successive block reverses the previous block's increments.  Therefore
% every input/reference remains inside the same deviation envelope as the
% original validation case instead of accumulating five same-sign steps.
%
% Block 1: original 12-s actions
% Block 2: equal-and-opposite actions (return toward nominal)
% Block 3: original actions
% Block 4: equal-and-opposite actions
% Block 5: original actions
%
% No physical parameter drift is used in this prediction application.

c = case_grid_connected_69bus_true_physics();

baseBlockSeconds = 12.0;
numBlocks = 5;
blockOffsets = (0:numBlocks-1)*baseBlockSeconds;
blockSigns = (-1).^(0:numBlocks-1);  % + - + - +

sections = {'load','sgPm','sgVref','gfmP','gfmQ','gfmEref','gflP','gflQ'};
for iSec = 1:numel(sections)
    secName = sections{iSec};
    if ~isfield(c,'dist') || ~isfield(c.dist,secName)
        continue;
    end
    sec = c.dist.(secName);
    if isfield(sec,'enabled') && ~logical(sec.enabled)
        continue;
    end
    if ~isfield(sec,'group') || isempty(sec.group)
        continue;
    end

    if strcmp(secName,'load')
        actionField = 'fraction';
    else
        actionField = 'delta';
    end

    for ig = 1:numel(sec.group)
        g = sec.group(ig);
        if ~isfield(g,'time') || ~isfield(g,actionField)
            error('case_grid_connected_69bus_receding_horizon:MalformedGroup', ...
                'c.dist.%s.group(%d) is missing time/%s.',secName,ig,actionField);
        end

        t0 = double(g.time(:));
        a0 = double(g.(actionField)(:));
        if numel(t0) ~= numel(a0)
            error('case_grid_connected_69bus_receding_horizon:SequenceLength', ...
                'Base %s group %d has inconsistent time/action lengths.',secName,ig);
        end

        tau0 = expand_transition_local(g.transition,numel(t0));
        tNew = zeros(numel(t0)*numBlocks,1);
        aNew = zeros(size(tNew));
        tauNew = zeros(size(tNew));
        cursor = 0;
        for ib = 1:numBlocks
            q = cursor + (1:numel(t0));
            tNew(q) = t0 + blockOffsets(ib);
            aNew(q) = blockSigns(ib)*a0;
            tauNew(q) = tau0;
            cursor = cursor + numel(t0);
        end

        c.dist.(secName).group(ig).time = tNew;
        c.dist.(secName).group(ig).(actionField) = aNew;
        c.dist.(secName).group(ig).transition = tauNew;
    end
end

c.scenario.name = 'paper_60s_69bus_receding_horizon_repeat';
c.scenario.description = [ ...
    "Sixty-second extension of the original 12-s 69-bus event-rich scenario. " ...
    + "Five 12-s blocks alternate the sign of the original persistent actions " ...
    + "to revisit the same operating envelope without cumulative drift."];
c.scenario.parentScenario = 'paper_12s_69bus_all_DER_transient_rich';
c.scenario.extensionRule = 'five_12s_blocks_alternating_increment_sign';
c.scenario.blockDurationSeconds = baseBlockSeconds;
c.scenario.blockCount = numBlocks;

c.drift.enabled = false;
c.sim.t0 = 0;
c.sim.tf = 60.0;
end

function tau = expand_transition_local(tau,n)
if isscalar(tau)
    tau = repmat(double(tau),n,1);
else
    tau = double(tau(:));
end
if numel(tau) ~= n
    error('case_grid_connected_69bus_receding_horizon:TransitionLength', ...
        'Transition width must be scalar or match the base event sequence length.');
end
end
