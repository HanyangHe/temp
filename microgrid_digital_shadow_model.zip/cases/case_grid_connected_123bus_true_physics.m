function c = case_grid_connected_123bus_true_physics()
%CASE_GRID_CONNECTED_123BUS_TRUE_PHYSICS OEDI-derived 123-bus DAE benchmark.
%
% Purpose
% -------
% Large-network extension of Offline Experiment Part 1 while retaining the
% SAME learned DER scope as the 10-/69-bus cases:
%   exact balanced network algebraic equations + learned SG/GFM/GFL dynamics.
%
% Important modeling statement
% ----------------------------
% The public IEEE-123 feeder is phase-unbalanced and contains regulators,
% phase-specific branches, switches, capacitors, a 480-V service transformer,
% ZIP loads, and QSTS profiles. The current digital-shadow framework is a
% balanced positive-sequence DAE. Therefore this case uses a documented
% OEDI-derived balanced reduction; it should not be described as an exact
% OpenDSS reproduction of the phase-unbalanced IEEE-123 feeder.
%
% The static nominal OEDI load kW/kvar values are retained at 1 pu voltage.
% QSTS load/PV time profiles are deliberately NOT used because Offline Part 1
% supplies its own controlled transient scenario and Sobol training inputs.

%% Traceable source files
c.sourceFiles.case = fullfile('cases','case_grid_connected_123bus_true_physics.m');
c.sourceFiles.line = fullfile('cases','line_data_123bus_oedi_balanced.m');

%% Base
% OEDI master.dss uses a stiff 4.16-kV source. Its head regulator transformer
% is rated 5000 kVA, so 5 MVA is used as a convenient system base.
c.name = 'grid_connected_123bus_oedi_balanced_true_physics_sg_avr';
c.base.S = 5e6;           % VA
c.base.Vll = 4160;        % V line-to-line !!!!Pay attention to the voltage level, double check whether its suitable for a microgrid we studied!!!!
c.base.f = 60;            % Hz
c.base.w = 2*pi*c.base.f; % rad/s
c.base.Z = c.base.Vll^2/c.base.S;
c.base.I = c.base.S/(sqrt(3)*c.base.Vll);

%% Network
c.network.N = 123;
c.network.mode = 'grid-connected';
c.network.line = line_data_123bus_oedi_balanced(c.base);
c.network.busLabels = c.network.line.busLabels;
c.network.slackBus = c.network.line.slackBusInternal; % internal 117 = OEDI bus 150
c.network.Vslack = 1 + 1i*0;
c.network.Ybus = build_ybus(c.network.N,c.network.line);

%% OEDI fixed capacitor banks -- active in the balanced Ybus
% qsts/master.dss specifies:
%   Bus 83 : 600 kvar, three-phase
%   Bus 88 :  50 kvar, phase a
%   Bus 90 :  50 kvar, phase b
%   Bus 92 :  50 kvar, phase c
%
% In this balanced surrogate the three single-phase 50-kvar banks are kept
% as 50-kvar balanced-equivalent shunts at their original buses. The shunts
% are fixed (no switched-capacitor controller in Offline Part 1).
c.network.fixedShuntCapacitors.bus = [83 88 90 92].';
c.network.fixedShuntCapacitors.Qkvar = [600 50 50 50].';
c.network.fixedShuntCapacitors.Qpu = ...
    c.network.fixedShuntCapacitors.Qkvar*1e3/c.base.S;

for kShunt = 1:numel(c.network.fixedShuntCapacitors.bus)
    iBus = c.network.fixedShuntCapacitors.bus(kShunt);
    Bpu = c.network.fixedShuntCapacitors.Qpu(kShunt);
    % Positive capacitor susceptance in the passive network admittance.
    c.network.Ybus(iBus,iBus) = c.network.Ybus(iBus,iBus) + 1i*Bpu;
end

c.network.nonSlackBuses = setdiff((1:c.network.N).',c.network.slackBus,'stable');

%% Dynamic DER allocation -- deliberately richer than the 69-bus case
% The public OEDI QSTS model contains PV systems at buses
%   [7 29 49 55 63 68 80 87 113].
% All nine locations are used here as geographically distributed dynamic
% source anchors. The SG/GFM/GFL TYPE assignment is a benchmark design
% choice; OEDI itself does not claim synchronous generators at these PV sites.
%
% Compared with the 69-bus case (2 SG + 2 GFM + 2 GFL = 6 modules), this
% 123-bus scalability case uses:
%   3 SG + 3 GFM + 3 GFL = 9 dynamic modules.
%
% Allocation:
%   SG  : buses 29, 63, 87
%   GFM : buses 49, 80, 113
%   GFL : buses 7, 55, 68
c.sg(1).bus = 29;
c.sg(2).bus = 63;
c.sg(3).bus = 87;

c.gfm(1).bus = 49;
c.gfm(2).bus = 80;
c.gfm(3).bus = 113;

c.gfl(1).bus = 7;
c.gfl(2).bus = 55;
c.gfl(3).bus = 68;

%% Synchronous generators -- salient-pole transient model + first-order AVR
sg1 = struct( ...
    'model','salient_avr_5state','H',1.10,'D',0.85,'Ra',0.0025, ...
    'Xd',1.80,'Xq',1.70,'XdPrime',0.25,'XqPrime',0.55, ...
    'TdoPrime',0.85,'TqoPrime',0.25,'KA',20.0,'TA',0.050, ...
    'Pm0',0.110,'Vref0',1.020, ...
    'EqPrimeGuess',1.02,'EdPrimeGuess',0.00,'EfdGuess',1.00);

sg2 = sg1;
sg2.H = 1.30;
sg2.D = 0.95;
sg2.Xd = 1.85;
sg2.Xq = 1.72;
sg2.XdPrime = 0.27;
sg2.XqPrime = 0.58;
sg2.TdoPrime = 0.95;
sg2.TqoPrime = 0.28;
sg2.KA = 18.0;
sg2.TA = 0.060;
sg2.Pm0 = 0.100;

sg3 = sg1;
sg3.H = 1.20;
sg3.D = 0.90;
sg3.Xd = 1.76;
sg3.Xq = 1.66;
sg3.XdPrime = 0.24;
sg3.XqPrime = 0.52;
sg3.TdoPrime = 0.90;
sg3.TqoPrime = 0.24;
sg3.KA = 22.0;
sg3.TA = 0.055;
sg3.Pm0 = 0.090;

sg1.bus = c.sg(1).bus;
sg2.bus = c.sg(2).bus;
sg3.bus = c.sg(3).bus;
c.sg = [sg1,sg2,sg3];

%% Grid-forming inverters -- heterogeneous reduced P-f / Q-V droop models
gfm1 = struct('bus',49,'mp',0.050,'nq',0.050,'tauP',0.050, ...
    'tauQ',0.050,'tauE',0.100,'Zout',0.02+1i*0.15, ...
    'Pstar0',0.070,'Qstar0',0.000,'Eref0',1.000);

gfm2 = struct('bus',80,'mp',0.045,'nq',0.055,'tauP',0.060, ...
    'tauQ',0.060,'tauE',0.120,'Zout',0.02+1i*0.15, ...
    'Pstar0',0.065,'Qstar0',0.000,'Eref0',1.000);

gfm3 = struct('bus',113,'mp',0.055,'nq',0.047,'tauP',0.055, ...
    'tauQ',0.070,'tauE',0.110,'Zout',0.025+1i*0.14, ...
    'Pstar0',0.055,'Qstar0',0.000,'Eref0',1.000);

c.gfm = [gfm1,gfm2,gfm3];

%% Grid-following inverters -- SRF-PLL + first-order current loop
pllZeta = 0.707;
pllBandwidthHz = [10 12 9];
tauI = [0.020 0.025 0.022];
gflP0 = [0.050 0.045 0.040];
gflBus = [7 55 68];

for k = 1:3
    pllWn = 2*pi*pllBandwidthHz(k);
    c.gfl(k).bus = gflBus(k);
    c.gfl(k).KpPLL = 2*pllZeta*pllWn/c.base.w;
    c.gfl(k).KiPLL = pllWn^2/c.base.w;
    c.gfl(k).tauI = tauI(k);
    c.gfl(k).Pstar0 = gflP0(k);
    c.gfl(k).Qstar0 = 0.000;
    c.gfl(k).voltageRegularization = 1e-10;
end

%% OEDI nominal spot loads -- aggregate phase entries into one balanced bus PQ
% Source qsts/IEEE123LoadsQsts.dss:
%   91 phase/load records -> 85 unique buses,
%   total nominal P = 3490 kW, Q = 1920 kvar.
Pkw = zeros(c.network.N,1);
Qkvar = zeros(c.network.N,1);
loadData = [
      1    40.0    20.0;
      2    20.0    10.0;
      4    40.0    20.0;
      5    20.0    10.0;
      6    40.0    20.0;
      7    20.0    10.0;
      9    40.0    20.0;
     10    20.0    10.0;
     11    40.0    20.0;
     12    20.0    10.0;
     16    40.0    20.0;
     17    20.0    10.0;
     19    40.0    20.0;
     20    40.0    20.0;
     22    40.0    20.0;
     24    40.0    20.0;
     28    40.0    20.0;
     29    40.0    20.0;
     30    40.0    20.0;
     31    20.0    10.0;
     32    20.0    10.0;
     33    40.0    20.0;
     34    40.0    20.0;
     35    40.0    20.0;
     37    40.0    20.0;
     38    20.0    10.0;
     39    20.0    10.0;
     41    20.0    10.0;
     42    20.0    10.0;
     43    40.0    20.0;
     45    20.0    10.0;
     46    20.0    10.0;
     47   105.0    75.0;
     48   210.0   150.0;
     49   140.0    95.0;
     50    40.0    20.0;
     51    20.0    10.0;
     52    40.0    20.0;
     53    40.0    20.0;
     55    20.0    10.0;
     56    20.0    10.0;
     58    20.0    10.0;
     59    20.0    10.0;
     60    20.0    10.0;
     62    40.0    20.0;
     63    40.0    20.0;
     64    75.0    35.0;
     65   140.0   100.0;
     66    75.0    35.0;
     68    20.0    10.0;
     69    40.0    20.0;
     70    20.0    10.0;
     71    40.0    20.0;
     73    40.0    20.0;
     74    40.0    20.0;
     75    40.0    20.0;
     76   245.0   180.0;
     77    40.0    20.0;
     79    40.0    20.0;
     80    40.0    20.0;
     82    40.0    20.0;
     83    20.0    10.0;
     84    20.0    10.0;
     85    40.0    20.0;
     86    20.0    10.0;
     87    40.0    20.0;
     88    40.0    20.0;
     90    40.0    20.0;
     92    40.0    20.0;
     94    40.0    20.0;
     95    20.0    10.0;
     96    20.0    10.0;
     98    40.0    20.0;
     99    40.0    20.0;
    100    40.0    20.0;
    102    20.0    10.0;
    103    40.0    20.0;
    104    40.0    20.0;
    106    40.0    20.0;
    107    40.0    20.0;
    109    40.0    20.0;
    111    20.0    10.0;
    112    20.0    10.0;
    113    40.0    20.0;
    114    20.0    10.0;
];
Pkw(loadData(:,1)) = loadData(:,2);
Qkvar(loadData(:,1)) = loadData(:,3);

% Current framework uses constant-PQ load injections during the transient
% DAE. OEDI's model=8 ZIP dependence and QSTS temporal profiles are outside
% this Part-1 benchmark and are intentionally not activated.
Pload = Pkw*1e3/c.base.S;
Qload = Qkvar*1e3/c.base.S;

c.input.nominal.Sload = Pload + 1i*Qload;
c.input.nominal.sgPm = [c.sg.Pm0].';
c.input.nominal.sgVref = [c.sg.Vref0].';
c.input.nominal.gfmPstar = [c.gfm.Pstar0].';
c.input.nominal.gfmQstar = [c.gfm.Qstar0].';
c.input.nominal.gfmEref = [c.gfm.Eref0].';
c.input.nominal.gflPstar = [c.gfl.Pstar0].';
c.input.nominal.gflQstar = [c.gfl.Qstar0].';

%% 12-s transient-rich common test scenario
% Preserve the previously validated 10-s excitation schedule exactly,
% while extending only the final evaluation horizon to 12 s:
%   - all 85 loaded buses participate through SIX spatial load groups;
%   - all 9 dynamic DER modules are directly excited;
%   - SG Pm and AVR, GFM P*/Q*/Eref, and GFL P*/Q* channels all appear;
%   - all 15 event centers remain exactly at their previously validated times;
%   - the final event remains at 8.90 s, now leaving 3.10 s for final settling.
%
% Persistent operating-point changes are retained so this remains a
% physically interpretable dynamic-identification test rather than a pulse
% excitation benchmark.
c.scenario.name = 'paper_12s_123bus_oedi_9DER_6loadgroup_transient_rich';
c.scenario.description = [ ...
    "Twelve-second OEDI-derived IEEE-123 balanced validation scenario with " ...
    + "six load regions, nine dynamic DER modules, and 15 separated events."];
c.scenario.minInterEventSeparation = 0.55; % actual event-center gap = 0.60 s

loadBuses = find(abs(c.input.nominal.Sload) > 0).';

%% Grouped load actions -- every one of the 85 loaded buses participates
c.dist.load.enabled = true;

c.dist.load.group(1).bus = loadBuses(loadBuses <= 20);
c.dist.load.group(1).time = 0.50;
c.dist.load.group(1).fraction = +0.060;
c.dist.load.group(1).transition = 0.030;

c.dist.load.group(2).bus = loadBuses(loadBuses >= 21 & loadBuses <= 40);
c.dist.load.group(2).time = 2.30;
c.dist.load.group(2).fraction = -0.050;
c.dist.load.group(2).transition = 0.030;

c.dist.load.group(3).bus = loadBuses(loadBuses >= 41 & loadBuses <= 60);
c.dist.load.group(3).time = 4.10;
c.dist.load.group(3).fraction = +0.040;
c.dist.load.group(3).transition = 0.030;

c.dist.load.group(4).bus = loadBuses(loadBuses >= 61 & loadBuses <= 80);
c.dist.load.group(4).time = 5.90;
c.dist.load.group(4).fraction = -0.040;
c.dist.load.group(4).transition = 0.030;

c.dist.load.group(5).bus = loadBuses(loadBuses >= 81 & loadBuses <= 100);
c.dist.load.group(5).time = 7.70;
c.dist.load.group(5).fraction = +0.050;
c.dist.load.group(5).transition = 0.030;

c.dist.load.group(6).bus = loadBuses(loadBuses >= 101 & loadBuses <= 114);
c.dist.load.group(6).time = 8.90;
c.dist.load.group(6).fraction = -0.035;
c.dist.load.group(6).transition = 0.030;

%% SG actions -- all three SG modules participate
c.dist.sgPm.enabled = true;

c.dist.sgPm.group(1).device = 1;
c.dist.sgPm.group(1).time = 1.10;
c.dist.sgPm.group(1).delta = +0.008;
c.dist.sgPm.group(1).transition = 0.025;

c.dist.sgPm.group(2).device = 3;
c.dist.sgPm.group(2).time = 6.50;
c.dist.sgPm.group(2).delta = -0.005;
c.dist.sgPm.group(2).transition = 0.025;

c.dist.sgVref.enabled = true;
c.dist.sgVref.group(1).device = 2;
c.dist.sgVref.group(1).time = 3.50;
c.dist.sgVref.group(1).delta = +0.006;
c.dist.sgVref.group(1).transition = 0.025;

%% GFM actions -- P*, Q*, and Eref channels are all excited
c.dist.gfmQ.enabled = true;
c.dist.gfmQ.group(1).device = 1;
c.dist.gfmQ.group(1).time = 1.70;
c.dist.gfmQ.group(1).delta = +0.005;
c.dist.gfmQ.group(1).transition = 0.025;

c.dist.gfmP.enabled = true;
c.dist.gfmP.group(1).device = 2;
c.dist.gfmP.group(1).time = 4.70;
c.dist.gfmP.group(1).delta = -0.006;
c.dist.gfmP.group(1).transition = 0.025;

c.dist.gfmEref.enabled = true;
c.dist.gfmEref.group(1).device = 3;
c.dist.gfmEref.group(1).time = 7.10;
c.dist.gfmEref.group(1).delta = +0.004;
c.dist.gfmEref.group(1).transition = 0.025;

%% GFL actions -- all three GFL modules participate
c.dist.gflP.enabled = true;

c.dist.gflP.group(1).device = 1;
c.dist.gflP.group(1).time = 2.90;
c.dist.gflP.group(1).delta = +0.006;
c.dist.gflP.group(1).transition = 0.025;

c.dist.gflP.group(2).device = 3;
c.dist.gflP.group(2).time = 8.30;
c.dist.gflP.group(2).delta = -0.004;
c.dist.gflP.group(2).transition = 0.025;

c.dist.gflQ.enabled = true;
c.dist.gflQ.group(1).device = 2;
c.dist.gflQ.group(1).time = 5.30;
c.dist.gflQ.group(1).delta = -0.004;
c.dist.gflQ.group(1).transition = 0.025;

%% Optional physical-model parameter drift -- disabled in Offline Part 1
c.drift.enabled = false;
c.drift.deviceType = 'gfm';
c.drift.device = 3;
c.drift.parameter = 'mp';
c.drift.time = 7.40;
c.drift.mode = 'relative';
c.drift.value = 0.15;
c.drift.transition = 0.050;

%% Simulation
% The complete 12-s trajectory is used for all offline trajectory metrics.
% The previously validated event schedule is unchanged; the final active event
% remains at 8.90 s, leaving 3.10 s for settling.
c.sim.t0 = 0;
c.sim.tf = 12.0;
c.sim.outputStep = 0.005;
c.sim.RelTol = 1e-7;
c.sim.AbsTol = 1e-9;
c.sim.MaxStep = 0.005;
c.sim.saveResults = true;

%% Initialization
c.init.FunctionTolerance = 1e-11;
c.init.StepTolerance = 1e-11;
c.init.OptimalityTolerance = 1e-11;
c.init.MaxIterations = 1400;
c.init.MaxFunctionEvaluations = 5e5;
c.init.acceptResidual = 1e-7;

%% Traceability notes saved with results
c.referenceNotes = [ ...
    "Topology/line lengths/source voltage: openEDI/oedisi-ieee123 qsts/master.dss."; ...
    "Line impedance matrices: qsts/IEEELinecodes.dss, reduced to balanced scalar equivalents."; ...
    "Nominal spot loads: qsts/IEEE123LoadsQsts.dss; 91 records aggregated into 85 bus PQ loads."; ...
    "All nine public OEDI PV buses [7 29 49 55 63 68 80 87 113] are used as dynamic-source site anchors."; ...
    "Benchmark allocation is 3 SG + 3 GFM + 3 GFL; the SG/GFM/GFL type assignment is not an OEDI claim."; ...
    "OEDI capacitor banks at buses 83/88/90/92 are retained as fixed balanced shunts (750 kvar total)."; ...
    "QSTS load/PV time profiles are intentionally not used in Offline Part 1."; ...
    "This is a balanced positive-sequence OEDI-derived surrogate, not an exact unbalanced OpenDSS reproduction." ...
    ];
end
