function c = case_grid_connected_69bus_true_physics()
%CASE_GRID_CONNECTED_69BUS_TRUE_PHYSICS 69-bus heterogeneous physical DAE case.
%
% This case extends the established 10-bus Offline Experiment Part 1 to the
% user's larger EMS feeder while preserving the same modeling philosophy:
%   - balanced positive-sequence quasi-static network algebraic equations;
%   - positive current/power = injection INTO the electrical network;
%   - exact network retained for every learned model;
%   - SG, GFM and GFL differential dynamics are the learned DER scope.
%
% The 69-bus topology/cable data and original load/DER bus plan come from the
% attached EMS project. The original 69-bus branch block omits buses 36--46;
% line_data_69bus_user_ems.m documents the explicit reproducible completion.

%% Traceable source-file names used by the settings reporter
c.sourceFiles.case = fullfile('cases','case_grid_connected_69bus_true_physics.m');
c.sourceFiles.line = fullfile('cases','line_data_69bus_user_ems.m');

%% System base -- retained from the attached EMS project
c.name = 'grid_connected_69bus_ems_true_physics_sg_avr';
c.base.S = 1e6;           % VA (1 MVA)
c.base.Vll = 480;         % V line-to-line
c.base.f = 60;            % Hz
c.base.w = 2*pi*c.base.f; % rad/s
c.base.Z = c.base.Vll^2/c.base.S;
c.base.I = c.base.S/(sqrt(3)*c.base.Vll);

%% Network
c.network.N = 69;
c.network.mode = 'grid-connected';
c.network.slackBus = 1;
c.network.Vslack = 1 + 1i*0; % pu infinite-grid bus
c.network.line = line_data_69bus_user_ems(c.base);
c.network.Ybus = build_ybus(c.network.N,c.network.line);
c.network.nonSlackBuses = setdiff((1:c.network.N).',c.network.slackBus,'stable');

%% Heterogeneous dynamic-device allocation
% The attached EMS 69-bus plan places dispatchable/renewable/storage DERs at
% buses [27 35 46 53 65 69]. For this system-identification case, those six
% strategic DER locations are occupied by two SGs, two GFMs, and two GFLs so
% all three dynamic model families participate without co-locating devices.
c.sg(1).bus = 27;
c.sg(2).bus = 65;
c.gfm(1).bus = 35;
c.gfm(2).bus = 69;
c.gfl(1).bus = 46;
c.gfl(2).bus = 53;

%% Synchronous generators: salient-pole transient model + first-order AVR
sg1 = struct( ...
    'model','salient_avr_5state','H',1.00,'D',0.80,'Ra',0.0025, ...
    'Xd',1.80,'Xq',1.70,'XdPrime',0.25,'XqPrime',0.55, ...
    'TdoPrime',0.80,'TqoPrime',0.25,'KA',20.0,'TA',0.050, ...
    'Pm0',0.070,'Vref0',1.020, ...
    'EqPrimeGuess',1.02,'EdPrimeGuess',0.00,'EfdGuess',1.00);
sg2 = sg1;
sg2.H = 1.20;
sg2.D = 0.90;
sg2.Xd = 1.85;
sg2.Xq = 1.72;
sg2.XdPrime = 0.27;
sg2.XqPrime = 0.58;
sg2.TdoPrime = 0.90;
sg2.TqoPrime = 0.28;
sg2.KA = 18.0;
sg2.TA = 0.060;
sg2.Pm0 = 0.065;
sg2.Vref0 = 1.020;
sg1.bus = c.sg(1).bus;
sg2.bus = c.sg(2).bus;
c.sg = [sg1,sg2];

%% Grid-forming inverters: reduced P-f/Q-V droop models
% GFM1 follows the same nominal dynamic scale as the 10-bus case; GFM2 is
% intentionally mildly heterogeneous to avoid a duplicated-device test.
gfm1 = struct('bus',35,'mp',0.050,'nq',0.050,'tauP',0.050, ...
    'tauQ',0.050,'tauE',0.100,'Zout',0.02+1i*0.15, ...
    'Pstar0',0.060,'Qstar0',0.000,'Eref0',1.000);
gfm2 = struct('bus',69,'mp',0.045,'nq',0.055,'tauP',0.060, ...
    'tauQ',0.060,'tauE',0.120,'Zout',0.02+1i*0.15, ...
    'Pstar0',0.055,'Qstar0',0.000,'Eref0',1.000);
c.gfm = [gfm1,gfm2];

%% Grid-following inverters: SRF-PLL + first-order current loop
pllZeta = 0.707;
pllBandwidthHz = [10 12];
tauI = [0.020 0.025];
gflP0 = [0.050 0.045];
gflBus = [46 53];
for k = 1:2
    pllWn = 2*pi*pllBandwidthHz(k);
    c.gfl(k).bus = gflBus(k);
    c.gfl(k).KpPLL = 2*pllZeta*pllWn/c.base.w;
    c.gfl(k).KiPLL = pllWn^2/c.base.w;
    c.gfl(k).tauI = tauI(k);
    c.gfl(k).Pstar0 = gflP0(k);
    c.gfl(k).Qstar0 = 0.000;
    c.gfl(k).voltageRegularization = 1e-10;
end

%% Nominal constant-PQ loads
% The attached EMS plan uses residential buses
%   [3:26 28:34 36:45 47:49 51 52 54:64 66:68]
% and business buses [2 27 35 46 50 65]. The original optimization script
% randomized residential load powers, which is undesirable for a reproducible
% identification benchmark. Here a deterministic 4.5--8.5 kW repeating
% profile is used for residential buses and 25 kW per business bus.
%
% These magnitudes are deliberately below the EMS scheduling stress values:
% the purpose here is a stable dynamic-identification benchmark over the same
% topology, not a voltage-limit stress/OPF study. With the adopted DER dispatch,
% the nominal DAE equilibrium remains comfortably inside the [0.90,1.10] pu
% training-data acceptance window.
residentialNode = [3:26 28:34 36:45 47:49 51 52 54:64 66:68];
businessNode = [2 27 35 46 50 65];
Pload = zeros(c.network.N,1);
resProfile = 0.0045 + 0.0005*mod((0:numel(residentialNode)-1).',9);
Pload(residentialNode) = resProfile;
Pload(businessNode) = 0.025;
loadPF = 0.90;
Qload = Pload*tan(acos(loadPF));

c.input.nominal.Sload = Pload + 1i*Qload; % consumption magnitude, pu
c.input.nominal.sgPm = [c.sg.Pm0].';
c.input.nominal.sgVref = [c.sg.Vref0].';
c.input.nominal.gfmPstar = [c.gfm.Pstar0].';
c.input.nominal.gfmQstar = [c.gfm.Qstar0].';
c.input.nominal.gfmEref = [c.gfm.Eref0].';
c.input.nominal.gflPstar = [c.gfl.Pstar0].';
c.input.nominal.gflQstar = [c.gfl.Qstar0].';

%% Scenario purpose: 12-s large-feeder transient-rich sequence
% Design goals:
%   1) all 66 load buses participate through three spatial groups;
%   2) both SGs, both GFMs and both GFLs are directly excited;
%   3) event centers are separated by 1.0 s to keep individual transients
%      distinguishable while still producing a dense whole-window challenge;
%   4) actions are persistent operating-point changes, matching the 10-bus
%      Part-1 philosophy rather than artificial high-frequency pulses;
%   5) 1.5 s remains after the final event for settling.
c.scenario.name = 'paper_12s_69bus_all_DER_transient_rich';
c.scenario.description = [ ...
    "Twelve-second 69-bus validation scenario with three feeder-wide load " ...
    + "groups and independent SG/GFM/GFL operating-reference actions."];
c.scenario.minInterEventSeparation = 0.90; % s; actual event-center gap = 1.0 s

%% Grouped load actions -- every non-slack load bus participates
c.dist.load.enabled = true;
c.dist.load.group(1).bus = 2:22;
c.dist.load.group(1).time = 0.50;
c.dist.load.group(1).fraction = +0.08;
c.dist.load.group(1).transition = 0.030;

c.dist.load.group(2).bus = 23:45;
c.dist.load.group(2).time = 3.50;
c.dist.load.group(2).fraction = -0.07;
c.dist.load.group(2).transition = 0.030;

c.dist.load.group(3).bus = [46:52 54:68];
c.dist.load.group(3).time = 7.50;
c.dist.load.group(3).fraction = +0.06;
c.dist.load.group(3).transition = 0.030;

%% SG actions
c.dist.sgPm.enabled = true;
c.dist.sgPm.group(1).device = 1;
c.dist.sgPm.group(1).time = 1.50;
c.dist.sgPm.group(1).delta = +0.007;
c.dist.sgPm.group(1).transition = 0.025;
c.dist.sgPm.group(2).device = 2;
c.dist.sgPm.group(2).time = 9.50;
c.dist.sgPm.group(2).delta = -0.006;
c.dist.sgPm.group(2).transition = 0.025;

% Explicitly excite the AVR channel of SG2 in the larger-network case.
c.dist.sgVref.enabled = true;
c.dist.sgVref.group(1).device = 2;
c.dist.sgVref.group(1).time = 5.50;
c.dist.sgVref.group(1).delta = +0.008;
c.dist.sgVref.group(1).transition = 0.025;

%% GFM actions
c.dist.gfmQ.enabled = true;
c.dist.gfmQ.group(1).device = 1;
c.dist.gfmQ.group(1).time = 2.50;
c.dist.gfmQ.group(1).delta = +0.006;
c.dist.gfmQ.group(1).transition = 0.025;

c.dist.gfmP.enabled = true;
c.dist.gfmP.group(1).device = 2;
c.dist.gfmP.group(1).time = 6.50;
c.dist.gfmP.group(1).delta = -0.007;
c.dist.gfmP.group(1).transition = 0.025;
c.dist.gfmP.group(2).device = 1;
c.dist.gfmP.group(2).time = 10.50;
c.dist.gfmP.group(2).delta = +0.005;
c.dist.gfmP.group(2).transition = 0.025;

% Eref remains fixed so Q* provides the principal GFM voltage-channel action.
c.dist.gfmEref.enabled = false;
c.dist.gfmEref.group(1).device = 2;
c.dist.gfmEref.group(1).time = 8.00;
c.dist.gfmEref.group(1).delta = +0.005;
c.dist.gfmEref.group(1).transition = 0.025;

%% GFL actions
c.dist.gflP.enabled = true;
c.dist.gflP.group(1).device = 1;
c.dist.gflP.group(1).time = 4.50;
c.dist.gflP.group(1).delta = +0.006;
c.dist.gflP.group(1).transition = 0.025;

c.dist.gflQ.enabled = true;
c.dist.gflQ.group(1).device = 2;
c.dist.gflQ.group(1).time = 8.50;
c.dist.gflQ.group(1).delta = -0.005;
c.dist.gflQ.group(1).transition = 0.025;

%% Optional physical-model parameter drift -- disabled in Offline Part 1
c.drift.enabled = false;
c.drift.deviceType = 'gfm';
c.drift.device = 2;
c.drift.parameter = 'mp';
c.drift.time = 6.00;
c.drift.mode = 'relative';
c.drift.value = 0.15;       % +15%, example for later online-synchronization study
c.drift.transition = 0.050;

%% Simulation settings
c.sim.t0 = 0;
c.sim.tf = 12.0;
c.sim.outputStep = 0.005;
c.sim.RelTol = 1e-7;
c.sim.AbsTol = 1e-9;
c.sim.MaxStep = 0.005;      % resolves the fastest GFL current loop
c.sim.saveResults = true;

%% Initialization
c.init.FunctionTolerance = 1e-11;
c.init.StepTolerance = 1e-11;
c.init.OptimalityTolerance = 1e-11;
c.init.MaxIterations = 800;
c.init.MaxFunctionEvaluations = 2e5;
c.init.acceptResidual = 1e-7;

%% Source traceability notes stored with results
c.referenceNotes = [ ...
    "69-bus load/DER bus plan, 1-MVA/480-V base and cable data: attached EMS main/linedata files."; ...
    "The uploaded 69-bus branch block omits buses 36--46; the executable case infers lateral 3--36--...--46 to restore a connected 68-branch radial feeder."; ...
    "Residential/business nominal powers are deterministic dynamic-benchmark values, not the randomized/high-stress scheduling powers from the EMS optimization study."; ...
    "SG/GFM/GFL dynamic equations are the same model families used by the established 10-bus digital-shadow case; the second unit of each family is mildly parameter-heterogeneous." ...
    ];
end
