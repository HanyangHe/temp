function line = line_data_123bus_oedi_balanced(base)
%LINE_DATA_123BUS_OEDI_BALANCED OEDI IEEE-123 topology, balanced surrogate.
%
% This file is a traceable BALANCED POSITIVE-SEQUENCE reduction of the
% public openEDI/oedisi-ieee123 QSTS feeder. It is intentionally compatible
% with the present digital-shadow DAE, whose network model is one complex
% voltage per bus rather than an unbalanced multi-phase OpenDSS model.
%
% Source:
%   https://github.com/openEDI/oedisi-ieee123/tree/main/qsts
%   qsts/master.dss
%   qsts/IEEELinecodes.dss
%
% Reduction rules:
%   1) OEDI line connectivity and line lengths are retained.
%   2) Phase-specific regulator suffix buses 9r/25r/160r and 150r are
%      collapsed into their parent buses because the present DAE has no
%      discrete tap-changing regulator state.
%   3) Normally CLOSED switches Sw1--Sw5 are retained as small finite
%      pu-impedance links (1e-3+j1e-4 pu) to avoid an ill-conditioned
%      algebraic Jacobian in the balanced ODE15I benchmark.
%      Normally OPEN switches Sw7--Sw8 are omitted.
%   4) The 61s/610 480-V service transformer branch is omitted from this
%      4.16-kV balanced benchmark; bus 450 is an unloaded terminal spur and
%      is omitted. These two reductions leave exactly 123 connected nodes.
%   5) Three-phase line codes use a positive-sequence scalar reduction
%      Z1 ~= mean(diag(Zabc)) - mean(offdiag(Zabc)).
%      Two-phase codes 7/8 use the analogous self-minus-mutual scalar.
%      Single-phase codes 9/10/11 retain their published self impedance.
%
% Therefore this is NOT an exact phase-unbalanced IEEE-123 reproduction.
% It is an OEDI-derived 123-bus balanced benchmark for the same DAE/SINDy
% workflow as the established 10- and 69-bus cases.
%
% Columns in line.table:
%   [fromBusInternal, toBusInternal, R_pu, X_pu]

if nargin < 1 || isempty(base) || ~isfield(base,'Z')
    error('line_data_123bus_oedi_balanced:Base', ...
        'A base structure containing base.Z is required.');
end

% Internal buses 1:114 preserve the original OEDI numeric labels.
% Auxiliary OEDI labels are mapped to internal buses 115:123.
line.busLabels = [string(1:114), ...
    "135","149","150","151","152","160","197","250","300"].';
line.originalSlackLabel = "150";
line.slackBusInternal = 117;

% OEDI line-code scalar reductions in ohm per published feeder length unit.
% Codes 1--6 are transpositions of the same conductor geometry and have the
% same reduced positive-sequence R/X to numerical precision.
zCode = complex(zeros(12,1));
zCode(1:6) = 0.057967172 + 1i*0.118756313;
zCode(7:8) = 0.057964015 + 1i*0.130047349;
zCode(9:11)= 0.251742424 + 1i*0.255208333;
zCode(12)  = 0.192089646 + 1i*0.091521465;

% [fromInternal,toInternal,lineCode,length]
raw = [
    116   1  1 0.4; % OEDI 149 -> 1
      1   2 10 0.175; % OEDI 1 -> 2
      1   3 11 0.25; % OEDI 1 -> 3
      1   7  1 0.3; % OEDI 1 -> 7
      3   4 11 0.2; % OEDI 3 -> 4
      3   5 11 0.325; % OEDI 3 -> 5
      5   6 11 0.25; % OEDI 5 -> 6
      7   8  1 0.2; % OEDI 7 -> 8
      8  12 10 0.225; % OEDI 8 -> 12
      8   9  9 0.225; % OEDI 8 -> 9
      8  13  1 0.3; % OEDI 8 -> 13
      9  14  9 0.425; % OEDI 9 -> 14
     13  34 11 0.15; % OEDI 13 -> 34
     13  18  2 0.825; % OEDI 13 -> 18
     14  11  9 0.25; % OEDI 14 -> 11
     14  10  9 0.25; % OEDI 14 -> 10
     15  16 11 0.375; % OEDI 15 -> 16
     15  17 11 0.35; % OEDI 15 -> 17
     18  19  9 0.25; % OEDI 18 -> 19
     18  21  2 0.3; % OEDI 18 -> 21
     19  20  9 0.325; % OEDI 19 -> 20
     21  22 10 0.525; % OEDI 21 -> 22
     21  23  2 0.25; % OEDI 21 -> 23
     23  24 11 0.55; % OEDI 23 -> 24
     23  25  2 0.275; % OEDI 23 -> 25
     25  26  7 0.35; % OEDI 25 -> 26
     25  28  2 0.2; % OEDI 25 -> 28
     26  27  7 0.275; % OEDI 26 -> 27
     26  31 11 0.225; % OEDI 26 -> 31
     27  33  9 0.5; % OEDI 27 -> 33
     28  29  2 0.3; % OEDI 28 -> 29
     29  30  2 0.35; % OEDI 29 -> 30
     30 122  2 0.2; % OEDI 30 -> 250
     31  32 11 0.3; % OEDI 31 -> 32
     34  15 11 0.1; % OEDI 34 -> 15
     35  36  8 0.65; % OEDI 35 -> 36
     35  40  1 0.25; % OEDI 35 -> 40
     36  37  9 0.3; % OEDI 36 -> 37
     36  38 10 0.25; % OEDI 36 -> 38
     38  39 10 0.325; % OEDI 38 -> 39
     40  41 11 0.325; % OEDI 40 -> 41
     40  42  1 0.25; % OEDI 40 -> 42
     42  43 10 0.5; % OEDI 42 -> 43
     42  44  1 0.2; % OEDI 42 -> 44
     44  45  9 0.2; % OEDI 44 -> 45
     44  47  1 0.25; % OEDI 44 -> 47
     45  46  9 0.3; % OEDI 45 -> 46
     47  48  4 0.15; % OEDI 47 -> 48
     47  49  4 0.25; % OEDI 47 -> 49
     49  50  4 0.25; % OEDI 49 -> 50
     50  51  4 0.25; % OEDI 50 -> 51
     51 118  4 0.5; % OEDI 51 -> 151
     52  53  1 0.2; % OEDI 52 -> 53
     53  54  1 0.125; % OEDI 53 -> 54
     54  55  1 0.275; % OEDI 54 -> 55
     54  57  3 0.35; % OEDI 54 -> 57
     55  56  1 0.275; % OEDI 55 -> 56
     57  58 10 0.25; % OEDI 57 -> 58
     57  60  3 0.75; % OEDI 57 -> 60
     58  59 10 0.25; % OEDI 58 -> 59
     60  61  5 0.55; % OEDI 60 -> 61
     60  62 12 0.25; % OEDI 60 -> 62
     62  63 12 0.175; % OEDI 62 -> 63
     63  64 12 0.35; % OEDI 63 -> 64
     64  65 12 0.425; % OEDI 64 -> 65
     65  66 12 0.325; % OEDI 65 -> 66
     67  68  9 0.2; % OEDI 67 -> 68
     67  72  3 0.275; % OEDI 67 -> 72
     67  97  3 0.25; % OEDI 67 -> 97
     68  69  9 0.275; % OEDI 68 -> 69
     69  70  9 0.325; % OEDI 69 -> 70
     70  71  9 0.275; % OEDI 70 -> 71
     72  73 11 0.275; % OEDI 72 -> 73
     72  76  3 0.2; % OEDI 72 -> 76
     73  74 11 0.35; % OEDI 73 -> 74
     74  75 11 0.4; % OEDI 74 -> 75
     76  77  6 0.4; % OEDI 76 -> 77
     76  86  3 0.7; % OEDI 76 -> 86
     77  78  6 0.1; % OEDI 77 -> 78
     78  79  6 0.225; % OEDI 78 -> 79
     78  80  6 0.475; % OEDI 78 -> 80
     80  81  6 0.175; % OEDI 80 -> 81
     81  82  6 0.25; % OEDI 81 -> 82
     81  84 11 0.675; % OEDI 81 -> 84
     82  83  6 0.25; % OEDI 82 -> 83
     84  85 11 0.475; % OEDI 84 -> 85
     86  87  6 0.45; % OEDI 86 -> 87
     87  88  9 0.175; % OEDI 87 -> 88
     87  89  6 0.275; % OEDI 87 -> 89
     89  90 10 0.25; % OEDI 89 -> 90
     89  91  6 0.225; % OEDI 89 -> 91
     91  92 11 0.3; % OEDI 91 -> 92
     91  93  6 0.225; % OEDI 91 -> 93
     93  94  9 0.275; % OEDI 93 -> 94
     93  95  6 0.3; % OEDI 93 -> 95
     95  96 10 0.2; % OEDI 95 -> 96
     97  98  3 0.275; % OEDI 97 -> 98
     98  99  3 0.55; % OEDI 98 -> 99
     99 100  3 0.3; % OEDI 99 -> 100
    121 101  3 0.25; % OEDI 197 -> 101
    101 102 11 0.225; % OEDI 101 -> 102
    101 105  3 0.275; % OEDI 101 -> 105
    102 103 11 0.325; % OEDI 102 -> 103
    103 104 11 0.7; % OEDI 103 -> 104
    105 106 10 0.225; % OEDI 105 -> 106
    105 108  3 0.325; % OEDI 105 -> 108
    106 107 10 0.575; % OEDI 106 -> 107
    108 109  9 0.45; % OEDI 108 -> 109
    108 123  3 1; % OEDI 108 -> 300
    109 110  9 0.3; % OEDI 109 -> 110
    110 111  9 0.575; % OEDI 110 -> 111
    110 112  9 0.125; % OEDI 110 -> 112
    112 113  9 0.525; % OEDI 112 -> 113
    113 114  9 0.325; % OEDI 113 -> 114
    115  35  4 0.375; % OEDI 135 -> 35
    119  52  1 0.4; % OEDI 152 -> 52
    120  67  6 0.35; % OEDI 160 -> 67
    117 116  0 0.001; % OEDI 150 -> 149
     13 119  0 0.001; % OEDI 13 -> 152
     18 115  0 0.001; % OEDI 18 -> 135
     60 120  0 0.001; % OEDI 60 -> 160
     97 121  0 0.001; % OEDI 97 -> 197
];

from = raw(:,1);
to = raw(:,2);
code = raw(:,3);
len = raw(:,4);

zOhm = complex(zeros(size(from)));
zPu = complex(zeros(size(from)));

% Numerical regularization for the five normally-closed OEDI switches.
% The former 1e-5-ohm surrogate generated O(1e5) pu admittances on the
% 5-MVA/4.16-kV base and made the algebraic Jacobian unnecessarily ill
% conditioned for ODE15I. Because the present model is already a balanced
% positive-sequence reduction, use a small but finite pu switch impedance
% instead of reproducing an ideal/near-ideal OpenDSS switch.
switchZpu = 1.0e-3 + 1i*1.0e-4;

for k = 1:numel(from)
    if code(k) == 0
        zPu(k) = switchZpu;
        zOhm(k) = zPu(k)*base.Z;
    else
        zOhm(k) = zCode(code(k))*len(k);
        zPu(k) = zOhm(k)/base.Z;
    end
end
line.table = [from,to,real(zPu),imag(zPu)];
line.zPu = zPu;
line.zOhm = zOhm;
line.from = from;
line.to = to;
line.lineCode = code;
line.length = len;
line.sourceTag = 'OEDI_IEEE123_QSTS_balanced_positive_sequence_surrogate';
line.referenceRepository = 'openEDI/oedisi-ieee123';
line.referenceFiles = ["qsts/master.dss";"qsts/IEEELinecodes.dss"];

if size(line.table,1) ~= 122
    error('line_data_123bus_oedi_balanced:BranchCount', ...
        'Expected 122 branches for the connected 123-bus radial surrogate.');
end
end
