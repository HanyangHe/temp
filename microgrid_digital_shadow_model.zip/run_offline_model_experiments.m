function report = run_offline_model_experiments(projectRoot,caseFcn,configFcn)
%RUN_OFFLINE_MODEL_EXPERIMENTS Manuscript Offline Experiment Part 1.
%
% Backward-compatible default:
%   run_offline_model_experiments(projectRoot)
% runs the established 10-bus case/config.
%
% Generic selected-case interface:
%   run_offline_model_experiments(projectRoot,@caseFcn,@configFcn)
% allows the same Sections 1.1--1.3 workflow to be reused by additional
% physical-network cases without duplicating the experiment engine.
%
% Implements:
%   1.1 typical-sample predictive accuracy
%   1.2 sample-size sensitivity and training cost
%   1.3 state-measurement-noise robustness
%
% v1p17 result-storage rule:
%   - each method is saved independently under method_results/<method>/;
%   - there is NO aggregate all-method replay MAT;
%   - rerunning one method updates only that method's saved bundle/cache;
%   - replay can later select any subset of independently saved methods.

if nargin < 1 || isempty(projectRoot)
    projectRoot = fileparts(mfilename('fullpath'));
end
if nargin < 2 || isempty(caseFcn)
    caseFcn = @case_grid_connected_10bus_true_physics;
elseif ischar(caseFcn) || isstring(caseFcn)
    caseFcn = str2func(char(caseFcn));
end
if nargin < 3 || isempty(configFcn)
    configFcn = @config_offline_experiment_10bus;
elseif ischar(configFcn) || isstring(configFcn)
    configFcn = str2func(char(configFcn));
end
if ~isa(caseFcn,'function_handle') || ~isa(configFcn,'function_handle')
    error('run_offline_model_experiments:FunctionHandle', ...
        'caseFcn and configFcn must be function handles or function names.');
end
addpath(genpath(projectRoot));

c = caseFcn();
if isfield(c,'drift') && isfield(c.drift,'enabled') && c.drift.enabled
    warning('run_offline_model_experiments:DisableDrift', ...
        'Offline Experiment Part 1 disables c.drift to isolate fixed-model prediction accuracy.');
    c.drift.enabled = false;
end
layout = mg_build_state_layout(c);
cfg = configFcn();

% Multi-seed manuscript mode: run the same campaign on independent
% data-sampling seeds and aggregate mean/std statistics. The internal
% per-seed calls disable this delegation to avoid recursion.
if isfield(cfg,'multiseed') && isstruct(cfg.multiseed) && ...
        isfield(cfg.multiseed,'enabled') && logical(cfg.multiseed.enabled) && ...
        isfield(cfg,'randomSeeds') && numel(cfg.randomSeeds) > 1 && ...
        ~(isfield(cfg.multiseed,'internalSingleSeed') && logical(cfg.multiseed.internalSingleSeed))
    report = run_offline_model_experiments_multiseed(projectRoot,caseFcn,configFcn);
    return;
end

% Single-seed/internal calls automatically load/discover the formal LLM prior
% before the method registry and cache keys are constructed.
[cfg,llmPriorDiscovery] = prepare_offline_llm_prior_config(projectRoot,cfg);

allMethods = get_offline_method_registry(cfg);

% The physical truth trajectory is always solved and retained.
% displayTrueSys controls only whether the exact oracle is ALSO treated as a
% comparison method (duplicate trajectory/error/sample/noise information).
methods = allMethods;
if isfield(cfg,'displayTrueSys') && ~cfg.displayTrueSys
    isReference = false(size(allMethods));
    for iMethod = 1:numel(allMethods)
        isReference(iMethod) = isfield(allMethods(iMethod),'isTrueReference') && ...
            ~isempty(allMethods(iMethod).isTrueReference) && ...
            logical(allMethods(iMethod).isTrueReference);
    end
    methods = allMethods(~isReference);
end

% Optional run-level method selector. This is independent of registry enable
% switches and defines the complete active campaign set.
methods = select_methods_to_run(methods,cfg);

% Optional section-specific selectors support incremental campaigns. Missing
% selectors inherit cfg.run.methodsToRun.
methods1p1 = select_methods_for_section(methods,cfg,'section1p1');
methods1p2 = select_methods_for_section(methods,cfg,'section1p2');
methods1p3 = select_methods_for_section(methods,cfg,'section1p3');

fprintf('\n============================================================\n');
fprintf('Microgrid digital shadow -- Offline Experiment Part 1\n');
fprintf('Case: %s\n',c.name);
if isfield(c,'scenario') && isstruct(c.scenario) && ...
        isfield(c.scenario,'name') && ~isempty(c.scenario.name)
    scenarioName = char(string(c.scenario.name));
else
    scenarioName = 'operation sequence defined by c.dist.* in the active case';
end
fprintf('Test scenario: %s\n',scenarioName);
fprintf('Typical N: %d | sample sweep: [%s] | noise sweep (%%): [%s]\n', ...
    cfg.typicalSampleCount,strtrim(sprintf('%d ',cfg.sampleCounts)), ...
    strtrim(sprintf('%.3g ',100*cfg.noiseLevels)));
fprintf(['Sampling: Sobol short-trajectory starts (x0,u0); z0 is solved from g=0; ', ...
    'the true DAE generates the remaining trajectory points.\n']);
fprintf('Sample rule: N = number of short trajectories x points per trajectory.\n');
fprintf('Trajectory metrics: entire scenario window, no local transient cropping.\n');
fprintf('Truth reference trajectory: always enabled.\n');
fprintf('Display true-system oracle as comparison: %s\n',mat2str(cfg.displayTrueSys));
fprintf('Identical-condition reuse within run: %s\n', ...
    mat2str(cfg.reuse.identicalConditionsWithinRun));
fprintf('Active comparison methods: ');
if isempty(methods)
    fprintf('(none)');
else
    for k=1:numel(methods)
        if k > 1, fprintf(', '); end
        fprintf('%s',methods(k).displayName);
    end
end
fprintf('\n');
fprintf('  Section 1.1 methods: %s\n',method_list_text(methods1p1));
fprintf('  Section 1.2 methods: %s\n',method_list_text(methods1p2));
fprintf('  Section 1.3 methods: %s\n',method_list_text(methods1p3));
if isfield(cfg,'run') && isfield(cfg.run,'optionalReplayOnlyMethods') && ...
        ~isempty(cfg.run.optionalReplayOnlyMethods)
    fprintf('  Replay-only baseline(s), never scheduled here: %s\n', ...
        strjoin(cellstr(string(cfg.run.optionalReplayOnlyMethods)),', '));
end
fprintf('============================================================\n\n');

print_reference_case_summary(c,projectRoot);
print_offline_experiment_settings(cfg);

outRoot = fullfile(projectRoot,'outputs',cfg.output.folderName);
if ~exist(outRoot,'dir'), mkdir(outRoot); end

dataset = generate_offline_trajectory_dataset(c,layout,cfg,projectRoot);
fprintf('\nSolving one common truth test trajectory for all comparison methods...\n');
truth = simulate_reference_truth_scenario(c,layout);
fprintf('Truth trajectory solved in %.3f s; max algebraic residual %.3e.\n', ...
    truth.metadata.solveTimeSeconds,max(truth.networkResidualInf));

report = struct();
report.config = cfg;
report.llmPriorDiscovery = llmPriorDiscovery;
report.caseName = c.name;
report.caseFunction = string(func2str(caseFcn));
report.configFunction = string(func2str(configFcn));
report.methods = string({methods.name});
report.allRegisteredMethods = string({allMethods.name});
report.displayTrueSys = cfg.displayTrueSys;
report.datasetMetadata = dataset.metadata;
report.truth = truth;
report.section1p1 = struct();
report.section1p2 = struct();
report.section1p3 = struct();
report.reuseSummary = struct();

evaluationCache = struct();
evaluationCache.entries = struct('key',{},'methodName',{},'displayName',{}, ...
    'sampleCount',{},'noiseLevel',{},'firstRequest',{},'requests',{}, ...
    'requestCount',{},'checkpointPath',{},'evaluationStoredOnDisk',{}, ...
    'evaluationIsCompact',{},'evaluation',{});

if isempty(methods)
    fprintf(['NOTE: no quantitative comparison method is currently active.\n', ...
        '      Truth-reference trajectory figures will still be generated in Section 1.1.\n', ...
        '      Sections 1.2/1.3 are skipped until a learned baseline is registered.\n']);
end

%% Section 1.1: typical-sample predictive accuracy
if cfg.run.section1p1
    fprintf('\n---------------- Section 1.1: typical N=%d ----------------\n',cfg.typicalSampleCount);
    d = subset_offline_dataset(dataset,cfg.typicalSampleCount);
    datasets1p1 = {d};
    T = table();
    secDir = fullfile(outRoot,'section_1p1_typical_accuracy');
    if ~exist(secDir,'dir'), mkdir(secDir); end

    jobs = make_section_jobs_local(methods1p1,1,cfg.typicalSampleCount,0, ...
        'section1p1');
    [evals,executionMeta,evaluationCache] = run_offline_section_jobs( ...
        jobs,methods1p1,datasets1p1,truth,c,layout,cfg,evaluationCache, ...
        outRoot,'section1p1');

    report.section1p1.table = T;
    report.section1p1.evaluations = evals;
    report.section1p1.execution = executionMeta;

    % Persistent/report-side work remains serial after the section parfor barrier.
    for k = 1:numel(methods1p1)
        print_rollout_status(evals{k});
        row = evaluation_summary_row(evals{k},cfg.typicalSampleCount,0);
        row.EvaluationReused = logical(executionMeta.reused(k));
        row.EvaluationSource = executionMeta.sourceRequest(k);
        row.EvaluationCacheKey = executionMeta.cacheKey(k);
        if isempty(T), T = row; else, T = [T;row]; end %#ok<AGROW>

        methodSecDir = method_section_dir(outRoot,cfg,methods1p1(k).name, ...
            'section_1p1_typical_accuracy');
        if isfield(evals{k},'perVariableMetrics') && istable(evals{k}.perVariableMetrics)
            writetable(strip_nrmse_report_data(evals{k}.perVariableMetrics), ...
                fullfile(methodSecDir,'per_variable_metrics.csv'));
        end
        write_node_diagnostic_tables(evals{k},methodSecDir,'diagnostic');
        write_koopman_model_tables(evals{k},methodSecDir,'koopman');
    end

    plot_offline_trajectory_comparison(truth,evals,c,cfg,secDir);
    if ~isempty(methods1p1)
        writetable(T,fullfile(secDir,'section1p1_whole_trajectory_metrics.csv'));
        disp(T);
    else
        fprintf('Section 1.1: truth-reference figures generated; no model-error table is applicable yet.\n');
    end
    report.section1p1.table = T;
    report.section1p1.evaluations = evals;
    save_offline_method_replay_bundles(report,c,layout,evaluationCache,cfg,outRoot);

    % Section 1.1 needs full predictions until its trajectory plot is written.
    % After the verified section-boundary save, release NODE model/trajectory
    % payloads before the longer Section 1.2/1.3 sweeps begin.
    for k = 1:numel(evals)
        evals{k} = compact_offline_evaluation_for_memory(evals{k},cfg);
    end
    report.section1p1.evaluations = evals;
end

%% Section 1.2: sample-size sensitivity
if cfg.run.section1p2 && ~isempty(methods1p2)
    fprintf('\n---------------- Section 1.2: sample sensitivity ----------------\n');
    T = table();
    secDir = fullfile(outRoot,'section_1p2_sample_sensitivity');
    if ~exist(secDir,'dir'), mkdir(secDir); end

    % Prepare every clean N-subset serially once. All methods at a given N then
    % consume the identical dataset object inside the section-level parfor.
    sampleDatasets = cell(numel(cfg.sampleCounts),1);
    for iN = 1:numel(cfg.sampleCounts)
        sampleDatasets{iN} = subset_offline_dataset(dataset,cfg.sampleCounts(iN));
    end

    jobs = make_section_jobs_local(methods1p2,numel(cfg.sampleCounts), ...
        cfg.sampleCounts,zeros(size(cfg.sampleCounts)),'section1p2');
    [jobEvals,executionMeta,evaluationCache] = run_offline_section_jobs( ...
        jobs,methods1p2,sampleDatasets,truth,c,layout,cfg,evaluationCache, ...
        outRoot,'section1p2');

    secEvals = cell(numel(jobs),1);
    for j = 1:numel(jobs)
        k = jobs(j).methodIndex;
        N = jobs(j).sampleCount;
        ev = jobEvals{j};
        print_rollout_status(ev);

        row = evaluation_summary_row(ev,N,0);
        row.EvaluationReused = logical(executionMeta.reused(j));
        row.EvaluationSource = executionMeta.sourceRequest(j);
        row.EvaluationCacheKey = executionMeta.cacheKey(j);
        if isempty(T), T = row; else, T = [T;row]; end %#ok<AGROW>
        secEvals{j} = compact_offline_evaluation_for_memory(ev,cfg);

        methodSecDir = method_section_dir(outRoot,cfg,methods1p2(k).name, ...
            'section_1p2_sample_sensitivity');
        write_node_diagnostic_tables(ev,methodSecDir, ...
            sprintf('diagnostic_N%d_noise0',N));
        write_koopman_model_tables(ev,methodSecDir,sprintf('koopman_N%d_noise0',N));
    end

    plot_offline_sample_sensitivity(T,cfg,secDir);
    report.section1p2.table = T;
    report.section1p2.evaluations = secEvals;
    report.section1p2.execution = executionMeta;
    writetable(T,fullfile(secDir,'section1p2_sample_sensitivity.csv'));
    disp(T);
    save_offline_method_replay_bundles(report,c,layout,evaluationCache,cfg,outRoot);
end

%% Section 1.3: state-measurement-noise robustness
if cfg.run.section1p3 && ~isempty(methods1p3)
    fprintf('\n---------------- Section 1.3: state-measurement noise robustness ----------------\n');
    base = subset_offline_dataset(dataset,cfg.typicalSampleCount);
    T = table();
    secDir = fullfile(outRoot,'section_1p3_noise_robustness');
    if ~exist(secDir,'dir'), mkdir(secDir); end

    % Build each noisy state realization ONCE on the client. This guarantees that
    % every activated baseline at a given noise level receives exactly the same
    % noisy trajectory and reconstructed xdot labels, independent of worker order.
    noiseDatasets = cell(numel(cfg.noiseLevels),1);
    for in = 1:numel(cfg.noiseLevels)
        level = cfg.noiseLevels(in);
        if level == 0
            % Manuscript convention: the 0%% point is the exact clean N=500
            % benchmark already evaluated in Section 1.1/1.2.  Pass the clean
            % dataset unchanged so the canonical cache key is identical and
            % the saved clean evaluation is reused rather than retrained.
            % Positive-noise points continue to use the common measured-state
            % -> numerical-derivative protocol.
            noiseDatasets{in} = base;
        else
            noiseDatasets{in} = add_offline_training_noise(base,level,cfg);
        end
    end

    noiseSampleCounts = repmat(cfg.typicalSampleCount,size(cfg.noiseLevels));
    jobs = make_section_jobs_local(methods1p3,numel(cfg.noiseLevels), ...
        noiseSampleCounts,cfg.noiseLevels,'section1p3');
    [jobEvals,executionMeta,evaluationCache] = run_offline_section_jobs( ...
        jobs,methods1p3,noiseDatasets,truth,c,layout,cfg,evaluationCache, ...
        outRoot,'section1p3');

    secEvals = cell(numel(jobs),1);
    for j = 1:numel(jobs)
        k = jobs(j).methodIndex;
        level = jobs(j).noiseLevel;
        ev = jobEvals{j};
        print_rollout_status(ev);

        row = evaluation_summary_row(ev,cfg.typicalSampleCount,level);
        row.EvaluationReused = logical(executionMeta.reused(j));
        row.EvaluationSource = executionMeta.sourceRequest(j);
        row.EvaluationCacheKey = executionMeta.cacheKey(j);
        if isempty(T), T = row; else, T = [T;row]; end %#ok<AGROW>
        secEvals{j} = compact_offline_evaluation_for_memory(ev,cfg);

        noiseTag = regexprep(sprintf('%.6g',100*level),'[^A-Za-z0-9]','p');
        methodSecDir = method_section_dir(outRoot,cfg,methods1p3(k).name, ...
            'section_1p3_noise_robustness');
        write_node_diagnostic_tables(ev,methodSecDir, ...
            sprintf('diagnostic_N%d_noise%spct',cfg.typicalSampleCount,noiseTag));
        write_koopman_model_tables(ev,methodSecDir, ...
            sprintf('koopman_N%d_noise%spct',cfg.typicalSampleCount,noiseTag));
    end

    plot_offline_noise_robustness(T,cfg,secDir);
    report.section1p3.table = T;
    report.section1p3.evaluations = secEvals;
    report.section1p3.execution = executionMeta;
    writetable(T,fullfile(secDir,'section1p3_noise_robustness.csv'));
    disp(T);
    save_offline_method_replay_bundles(report,c,layout,evaluationCache,cfg,outRoot);
end

if cfg.run.section1p2 && isempty(methods1p2)
    fprintf('Section 1.2 skipped: no learned/quantitative comparison method is active.\n');
end
if cfg.run.section1p3 && isempty(methods1p3)
    fprintf('Section 1.3 skipped: no learned/quantitative comparison method is active.\n');
end

if isfield(cfg,'node') && isfield(cfg.node,'enabled') && cfg.node.enabled
    fprintf(['Neural ODE scope: modular DER differential dynamics trained from ', ...
        'short trajectories; network algebraic physics g=0 remains exact.\n']);
end

% Human-readable reuse summary. A requestCount > 1 means one computed result
% served more than one section. In the standard settings this is mainly the
% clean typical-N condition.
if ~isempty(evaluationCache.entries)
    nEntry = numel(evaluationCache.entries);
    methodName = strings(nEntry,1);
    sampleCount = zeros(nEntry,1);
    noisePercent = zeros(nEntry,1);
    requestCount = zeros(nEntry,1);
    firstRequest = strings(nEntry,1);
    for i = 1:nEntry
        methodName(i) = string(evaluationCache.entries(i).displayName);
        sampleCount(i) = evaluationCache.entries(i).sampleCount;
        noisePercent(i) = 100*evaluationCache.entries(i).noiseLevel;
        requestCount(i) = evaluationCache.entries(i).requestCount;
        firstRequest(i) = string(evaluationCache.entries(i).firstRequest);
    end
    reuseTable = table(methodName,sampleCount,noisePercent,requestCount,firstRequest, ...
        'VariableNames',{'Method','SampleCount','NoisePercent','RequestCount','FirstRequest'});
else
    reuseTable = table();
end
report.reuseSummary.table = reuseTable;
report.reuseSummary.uniqueEvaluations = numel(evaluationCache.entries);
report.reuseSummary.totalRequests = sum_reuse_requests(evaluationCache);
report.reuseSummary.reusedRequests = ...
    report.reuseSummary.totalRequests-report.reuseSummary.uniqueEvaluations;

bundlePaths = save_offline_method_replay_bundles( ...
    report,c,layout,evaluationCache,cfg,outRoot);

fprintf('\nOffline Experiment Part 1 finished. Output root:\n  %s\n',outRoot);
fprintf('Unique trained/evaluated conditions: %d\n',report.reuseSummary.uniqueEvaluations);
fprintf('Reused duplicate requests: %d\n',report.reuseSummary.reusedRequests);
fprintf('Independent method-result root: %s\n', ...
    fullfile(outRoot,get_method_results_folder_local(cfg)));
for iPath = 1:numel(bundlePaths)
    fprintf('  method bundle: %s\n',char(bundlePaths(iPath)));
end
fprintf(['Later replay without training/rollout: ', ...
    'replay_offline_model_experiment_results\n']);
end

function methods = select_methods_to_run(methods,cfg)
if ~isfield(cfg,'run') || ~isfield(cfg.run,'methodsToRun') || isempty(cfg.run.methodsToRun)
    return;
end
sel = cfg.run.methodsToRun;
if ischar(sel) || (isstring(sel) && isscalar(sel))
    if strcmpi(strtrim(char(string(sel))),'all') || ...
            strcmpi(strtrim(char(string(sel))),'all_enabled')
        return;
    end
    sel = string(sel);
elseif iscell(sel)
    sel = string(sel);
else
    sel = string(sel(:));
end
sel = sel(:);
for iSel = 1:numel(sel)
    sel(iSel) = canonical_method_alias(sel(iSel));
end

% Preserve the explicit user/config order. This is particularly useful for
% the Stage-4 incremental campaign: inexpensive SINDy/Koopman methods run
% before the expensive NODE baseline, and manuscript plots use the intended
% method ordering rather than registry construction order.
selected = methods([]);
missing = strings(0,1);
for i = 1:numel(sel)
    j = [];
    for k = 1:numel(methods)
        if strcmpi(sel(i),string(methods(k).name)) || ...
                strcmpi(sel(i),string(methods(k).displayName))
            j = k;
            break;
        end
    end
    if isempty(j)
        missing(end+1,1) = sel(i); %#ok<AGROW>
    elseif isempty(selected) || ~any(strcmpi(string({selected.name}),string(methods(j).name)))
        selected(end+1) = methods(j); %#ok<AGROW>
    end
end
if ~isempty(missing)
    error('run_offline_model_experiments:RequestedMethodNotEnabled', ...
        ['cfg.run.methodsToRun requested method(s) that are not enabled in ', ...
         'the registry: %s'],strjoin(cellstr(missing),', '));
end
methods = selected;
end

function methodsOut = select_methods_for_section(methods,cfg,sectionName)
methodsOut = methods;
fieldName = [char(sectionName) 'MethodsToRun'];
if ~isfield(cfg,'run') || ~isfield(cfg.run,fieldName) || isempty(cfg.run.(fieldName))
    return;
end
localCfg = struct();
localCfg.run.methodsToRun = cfg.run.(fieldName);
methodsOut = select_methods_to_run(methodsOut,localCfg);
end

function txt = method_list_text(methods)
if isempty(methods)
    txt = '(none)';
else
    txt = strjoin(cellstr(string({methods.displayName})),', ');
end
end

function q = canonical_method_alias(q)
q = string(q);
if strcmpi(q,'neural_ode') || strcmpi(q,'node')
    q = "neural_ode_modular";
elseif strcmpi(q,'koopman') || strcmpi(q,'mkbf') || strcmpi(q,'m-kbf') || ...
        strcmpi(q,'modular_koopman')
    q = "modular_koopman_kbf";
elseif strcmpi(q,'pn_sindy') || strcmpi(q,'pn-sindy') || strcmpi(q,'physics-neural')
    q = "physics_neural_sindy";
elseif strcmpi(q,'weak_sindy') || strcmpi(q,'weak-sindy') || ...
        strcmpi(q,'w-sindy') || strcmpi(q,'wsindy') || strcmpi(q,'Weak SINDy')
    q = "weak_sindy";
elseif strcmpi(q,'v-sindy') || strcmpi(q,'vsindy') || ...
        strcmpi(q,'vanilla sindy')
    q = "vanilla_sindy";
elseif strcmpi(q,'ed-sindy') || strcmpi(q,'edsindy') || strcmpi(q,'edsi')
    q = "edsi";
elseif strcmpi(q,'llm-prior-sindy') || strcmpi(q,'llm prior sindy') || ...
        strcmpi(q,'llm_sindy') || strcmpi(q,'llm-sindy')
    q = "llm_prior_sindy";
elseif strcmpi(q,'llm-edsi') || strcmpi(q,'llmedsi')
    q = "llm_edsi";
end
end

function d = method_section_dir(outRoot,cfg,methodName,sectionFolder)
d = fullfile(outRoot,get_method_results_folder_local(cfg), ...
    char(string(methodName)),sectionFolder);
if ~exist(d,'dir'), mkdir(d); end
end

function folder = get_method_results_folder_local(cfg)
folder = 'method_results';
if isfield(cfg,'output') && isfield(cfg.output,'methodResultsFolder') && ...
        ~isempty(cfg.output.methodResultsFolder)
    folder = char(string(cfg.output.methodResultsFolder));
end
end

function jobs = make_section_jobs_local(methods,nCondition,sampleCounts,noiseLevels,sectionName)
%MAKE_SECTION_JOBS_LOCAL Flatten (condition x method) in manuscript order.
if isempty(methods) || nCondition <= 0
    jobs = struct('methodIndex',{},'datasetIndex',{},'sampleCount',{}, ...
        'noiseLevel',{},'requestTag',{});
    return;
end
sampleCounts = double(sampleCounts(:).');
noiseLevels = double(noiseLevels(:).');
if isscalar(sampleCounts), sampleCounts = repmat(sampleCounts,1,nCondition); end
if isscalar(noiseLevels), noiseLevels = repmat(noiseLevels,1,nCondition); end
if numel(sampleCounts) ~= nCondition || numel(noiseLevels) ~= nCondition
    error('run_offline_model_experiments:SectionJobConditionSize', ...
        'sampleCounts/noiseLevels must be scalar or have one value per condition.');
end

nJobs = nCondition*numel(methods);
template = struct('methodIndex',0,'datasetIndex',0,'sampleCount',0, ...
    'noiseLevel',0,'requestTag','');
jobs = repmat(template,nJobs,1);
j = 0;
for iCondition = 1:nCondition
    for k = 1:numel(methods)
        j = j + 1;
        jobs(j).methodIndex = k;
        jobs(j).datasetIndex = iCondition;
        jobs(j).sampleCount = sampleCounts(iCondition);
        jobs(j).noiseLevel = noiseLevels(iCondition);
        switch lower(char(string(sectionName)))
            case 'section1p1'
                jobs(j).requestTag = sprintf('section1p1_method%d',k);
            case 'section1p2'
                jobs(j).requestTag = sprintf('section1p2_N%d_method%d', ...
                    sampleCounts(iCondition),k);
            case 'section1p3'
                jobs(j).requestTag = sprintf('section1p3_noise%.12g_method%d', ...
                    noiseLevels(iCondition),k);
            otherwise
                jobs(j).requestTag = sprintf('%s_condition%d_method%d', ...
                    char(string(sectionName)),iCondition,k);
        end
    end
end
end


function print_rollout_status(ev)
% Keep model failure visible while allowing the experiment sweep to continue.
if ev.rolloutSucceeded
    fprintf('  rollout: SUCCESS (100%% of requested horizon)\n');
else
    fprintf('  rollout: %s | reached t=%.6g s | coverage %.2f%%\n', ...
        char(string(ev.rolloutStatus)),ev.failureTimeSeconds,ev.trajectoryCoveragePercent);
    if strlength(string(ev.failureMessage)) > 0
        fprintf('  failure reason: %s\n',char(string(ev.failureMessage)));
    end
    fprintf(['  whole-scenario trajectory metrics are recorded as NaN; ', ...
        'the remaining experiment cases will continue.\n']);
end
end

function n = sum_reuse_requests(cache)
n = 0;
if isempty(cache) || ~isfield(cache,'entries'), return; end
for k = 1:numel(cache.entries)
    n = n + cache.entries(k).requestCount;
end
end
