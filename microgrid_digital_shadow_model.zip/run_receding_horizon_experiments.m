function report = run_receding_horizon_experiments(projectRoot,caseFcn,configFcn,varargin)
%RUN_RECEDING_HORIZON_EXPERIMENTS Repeated saved-model trajectory prediction.
%
% Scientific protocol
% -------------------
% 1) Build/reuse one 60-s physical parent trajectory.
% 2) Load existing Offline Part-1 N=500, clean, seed-20260814 models.
% 3) At t_k = 0,1,...,48 s, reset the learned DAE state to the parent truth
%    state x(t_k), then predict the next 12 s with the SAME future physical
%    input/reference sequence as the parent case.
% 4) Compute one whole-trajectory RMSE per 12-s window.
% 5) Report the distribution across 49 windows. No training/refitting occurs.
%
% Options
%   'ReplayOnly' : true -> load saved result MAT and regenerate/display report
%                  false -> compute missing window caches and save final result

if nargin < 1 || isempty(projectRoot), projectRoot = fileparts(mfilename('fullpath')); end
if isempty(projectRoot), projectRoot = pwd; end
if nargin < 2 || isempty(caseFcn), caseFcn = @case_grid_connected_69bus_receding_horizon; end
if nargin < 3 || isempty(configFcn), configFcn = @config_receding_horizon_experiment_69bus; end

p = inputParser;
p.FunctionName = mfilename;
addParameter(p,'ReplayOnly',false,@(x)islogical(x) || (isnumeric(x)&&isscalar(x)));
parse(p,varargin{:});
replayOnly = logical(p.Results.ReplayOnly);

projectRoot = char(string(projectRoot));
addpath(genpath(projectRoot));

cfg = configFcn();
c = caseFcn();
layout = mg_build_state_layout(c);
validate_protocol_local(c,cfg);

outRoot = fullfile(projectRoot,'outputs',cfg.output.folderName);
figDir = fullfile(outRoot,cfg.output.figureFolder);
cacheRoot = fullfile(outRoot,cfg.output.windowCacheFolder);
if exist(outRoot,'dir') ~= 7, mkdir(outRoot); end
if exist(figDir,'dir') ~= 7, mkdir(figDir); end
if exist(cacheRoot,'dir') ~= 7, mkdir(cacheRoot); end
resultFile = fullfile(outRoot,cfg.output.recedingResultFileName);

if replayOnly
    if exist(resultFile,'file') ~= 2
        error('run_receding_horizon_experiments:MissingReplay', ...
            'Saved receding-horizon result not found: %s',resultFile);
    end
    S = load(resultFile,'report');
    if ~isfield(S,'report') || ~isstruct(S.report)
        error('run_receding_horizon_experiments:InvalidReplay', ...
            'Saved file does not contain a valid report: %s',resultFile);
    end
    report = S.report;
    report.windowTable = canonicalize_display_names_local(report.windowTable);
    report.summaryTable = canonicalize_display_names_local(report.summaryTable);
    report.figureFiles = regenerate_figures_local(report.windowTable,cfg,figDir);
    fprintf('\nReceding-horizon prediction REPLAY ONLY. No truth solve or model rollout performed.\n');
    disp(report.summaryTable);
    return;
end

fprintf('\n============================================================\n');
fprintf('69-BUS RECEDING-HORIZON PREDICTION APPLICATION\n');
fprintf('Parent truth       : %.1f s\n',cfg.receding.parentDurationSeconds);
fprintf('Prediction horizon : %.1f s\n',cfg.receding.predictionHorizonSeconds);
fprintf('Sliding step       : %.1f s\n',cfg.receding.anchorStepSeconds);
fprintf('Prediction windows : %d\n',numel(cfg.receding.anchorTimesSeconds));
fprintf('Saved model source : Offline Part 1, seed=%d, N=%d, noise=%.3g%%\n', ...
    cfg.receding.initialModelSeed,cfg.receding.initialModelSampleCount, ...
    100*cfg.receding.initialModelNoiseLevel);
fprintf('IMPORTANT           : NO TRAINING / NO REFITTING / NO LLM CALL\n');
fprintf('============================================================\n');

%% Parent truth -- solve once, then reuse on later runs
truthFile = fullfile(outRoot,cfg.output.parentTruthFileName);
truth = [];
if cfg.receding.reuseParentTruth && exist(truthFile,'file') == 2
    try
        S = load(truthFile,'truth','caseSignature');
        if isfield(S,'truth') && parent_truth_compatible_local(S.truth,c,cfg,S)
            truth = S.truth;
            fprintf('Reusing saved 60-s parent truth: %s\n',truthFile);
        end
    catch ME
        warning('run_receding_horizon_experiments:ParentTruthReuse', ...
            'Saved parent truth could not be reused (%s). It will be regenerated.',ME.message);
    end
end
if isempty(truth)
    fprintf('Solving 60-s parent physical trajectory once...\n');
    truth = simulate_reference_truth_scenario(c,layout);
    caseSignature = parent_case_signature_local(c,cfg); %#ok<NASGU>
    save(truthFile,'truth','caseSignature','-v7');
    fprintf('Parent truth saved: %s\n',truthFile);
end

%% Resolve methods and strictly load already-trained models
registry = get_offline_method_registry(cfg);
methodNames = string(cfg.receding.methods(:));
methodPacks = cell(numel(methodNames),1);
for im = 1:numel(methodNames)
    idx = find(strcmp(string({registry.name}),methodNames(im)),1,'first');
    if isempty(idx)
        error('run_receding_horizon_experiments:MethodNotRegistered', ...
            'Requested method is not registered: %s',methodNames(im));
    end
    method = registry(idx);
    [model,trainInfo,source] = load_offline_initial_model_for_online( ...
        projectRoot,method,cfg,cfg.receding.initialModelSampleCount, ...
        cfg.receding.initialModelNoiseLevel);
    methodPacks{im} = struct('method',method,'model',model, ...
        'trainInfo',trainInfo,'source',source);
    fprintf('Loaded saved model: %-24s | %s\n',method.displayName,source.bundlePath);
end

%% Window rollouts -- every completed window is an independent checkpoint
anchors = double(cfg.receding.anchorTimesSeconds(:));
windowRows = cell(numel(methodNames),1);
parallelEnabled = prepare_parallel_pool_local(cfg);

for im = 1:numel(methodNames)
    pack = methodPacks{im};
    method = pack.method;
    model = pack.model;
    methodCacheDir = fullfile(cacheRoot,char(methodNames(im)));
    if exist(methodCacheDir,'dir') ~= 7, mkdir(methodCacheDir); end

    fprintf('\n[%d/%d] %s -- %d sliding windows\n', ...
        im,numel(methodNames),method.displayName,numel(anchors));

    rowsThis = cell(numel(anchors),1);
    if parallelEnabled
        parfor iw = 1:numel(anchors)
            rowsThis{iw} = evaluate_or_reuse_window_local( ...
                anchors(iw),truth,model,method,pack.source,c,layout,cfg,methodCacheDir);
        end
    else
        for iw = 1:numel(anchors)
            rowsThis{iw} = evaluate_or_reuse_window_local( ...
                anchors(iw),truth,model,method,pack.source,c,layout,cfg,methodCacheDir);
        end
    end
    windowRows{im} = vertcat(rowsThis{:});
end

windowTable = vertcat(windowRows{:});
windowTable = canonicalize_display_names_local(windowTable);
summaryTable = summarize_windows_local(windowTable,methodNames,methodPacks);
summaryTable = canonicalize_display_names_local(summaryTable);

writetable(windowTable,fullfile(outRoot,'receding_horizon_window_metrics.csv'));
writetable(summaryTable,fullfile(outRoot,'receding_horizon_summary.csv'));

figureFiles = regenerate_figures_local(windowTable,cfg,figDir);

report = struct();
report.schemaVersion = 'receding_horizon_prediction_v1';
report.generatedAt = char(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));
report.caseName = c.name;
report.scenarioName = c.scenario.name;
report.parentDurationSeconds = cfg.receding.parentDurationSeconds;
report.predictionHorizonSeconds = cfg.receding.predictionHorizonSeconds;
report.anchorStepSeconds = cfg.receding.anchorStepSeconds;
report.anchorTimesSeconds = anchors;
report.initialModelSeed = cfg.receding.initialModelSeed;
report.initialModelSampleCount = cfg.receding.initialModelSampleCount;
report.initialModelNoiseLevel = cfg.receding.initialModelNoiseLevel;
report.methodNames = methodNames;
report.windowTable = windowTable;
report.summaryTable = summaryTable;
report.figureFiles = figureFiles;
report.outputRoot = outRoot;
report.parentTruthFile = truthFile;
report.noTrainingPerformed = true;

save(resultFile,'report','-v7');

fprintf('\n============================================================\n');
fprintf('RECEDING-HORIZON PREDICTION FINISHED\n');
fprintf('Summary is mean +/- std across successful 12-s sliding predictions.\n');
fprintf('Failed windows are never hidden; see SuccessRate_percent.\n');
fprintf('============================================================\n');
disp(summaryTable);
end

function row = evaluate_or_reuse_window_local(t0,truth,model,method,source,c,layout,cfg,cacheDir)
horizon = double(cfg.receding.predictionHorizonSeconds);
tf = t0+horizon;
cacheFile = fullfile(cacheDir,sprintf('window_t%06.1f.mat',t0));

if cfg.receding.reuseWindowCache && ~cfg.receding.forceRecomputeWindows && ...
        exist(cacheFile,'file') == 2
    try
        S = load(cacheFile,'windowResult');
        if isfield(S,'windowResult') && window_cache_compatible_local( ...
                S.windowResult,method,source,t0,horizon,c,cfg)
            row = S.windowResult;
            row.Reused = true;
            return;
        end
    catch
        % Recompute this one window only.
    end
end

tol = max(1e-9,10*eps(max(1,truth.t(end))));
idx = find(truth.t >= t0-tol & truth.t <= tf+tol);
if isempty(idx) || abs(truth.t(idx(1))-t0)>tol || abs(truth.t(idx(end))-tf)>tol
    error('run_receding_horizon_experiments:WindowGrid', ...
        'Parent truth does not contain exact requested window [%.6g, %.6g] s.',t0,tf);
end
truthWindow = struct('t',truth.t(idx),'y',truth.y(idx,:));

try
    prediction = simulate_offline_model_scenario(model,method,truthWindow,c,layout,cfg);
    success = isfield(prediction,'metadata') && ...
        isfield(prediction.metadata,'rolloutSucceeded') && ...
        logical(prediction.metadata.rolloutSucceeded) && ...
        isequal(size(prediction.y),size(truthWindow.y));
    if success
        varNames = get_dae_variable_names(c,layout);
        metrics = compute_trajectory_error_metrics( ...
            truthWindow.y,prediction.y,varNames,cfg);
        rmse = metrics.RMSE;
        mae = metrics.MAE;
        maxae = metrics.MaxAE;
    else
        rmse = NaN; mae = NaN; maxae = NaN;
    end

    status = string(prediction.metadata.rolloutStatus);
    solveTime = double(prediction.metadata.modelSolveTimeSeconds);
    coverage = double(prediction.metadata.trajectoryCoveragePercent);
    failureMessage = string(prediction.metadata.failureMessage);
catch ME
    success = false;
    rmse = NaN; mae = NaN; maxae = NaN;
    status = "FAILED_EXCEPTION";
    solveTime = NaN;
    coverage = 0;
    failureMessage = string(ME.message);
end

row = table(string(method.name),string(method.displayName),t0,tf,horizon, ...
    cfg.receding.initialModelSeed,cfg.receding.initialModelSampleCount, ...
    cfg.receding.initialModelNoiseLevel,string(source.cacheKey),string(c.scenario.name), ...
    logical(success),string(status),coverage,rmse,mae,maxae,solveTime, ...
    string(failureMessage),false, ...
    'VariableNames',{'Method','DisplayName','StartTime_s','EndTime_s', ...
    'Horizon_s','ModelSeed','ModelSampleCount','ModelNoiseLevel','SourceCacheKey', ...
    'ScenarioName','RolloutSucceeded','RolloutStatus','Coverage_percent', ...
    'RMSE','MAE','MaxAE','SolveTime_s','FailureMessage','Reused'});

windowResult = row; %#ok<NASGU>
save(cacheFile,'windowResult','-v7');
end

function tf = window_cache_compatible_local(T,method,source,t0,horizon,c,cfg)
required = {'Method','StartTime_s','Horizon_s','ModelSeed','ModelSampleCount', ...
    'ModelNoiseLevel','SourceCacheKey','ScenarioName'};
tf = istable(T) && height(T)==1 && all(ismember(required,T.Properties.VariableNames));
if ~tf, return; end
tf = strcmp(string(T.Method(1)),string(method.name)) && ...
    abs(double(T.StartTime_s(1))-double(t0))<1e-10 && ...
    abs(double(T.Horizon_s(1))-double(horizon))<1e-10 && ...
    double(T.ModelSeed(1))==double(cfg.receding.initialModelSeed) && ...
    double(T.ModelSampleCount(1))==double(cfg.receding.initialModelSampleCount) && ...
    abs(double(T.ModelNoiseLevel(1))-double(cfg.receding.initialModelNoiseLevel))<1e-14 && ...
    strcmp(string(T.SourceCacheKey(1)),string(source.cacheKey)) && ...
    strcmp(string(T.ScenarioName(1)),string(c.scenario.name));
end

function T = summarize_windows_local(W,methodNames,methodPacks)
rows = cell(numel(methodNames),1);
for im = 1:numel(methodNames)
    mask = string(W.Method)==methodNames(im);
    Q = W(mask,:);
    ok = Q.RolloutSucceeded & isfinite(Q.RMSE);
    x = double(Q.RMSE(ok));
    if isempty(x)
        mu=NaN; sd=NaN; med=NaN; q25=NaN; q75=NaN; mn=NaN; mx=NaN;
    else
        mu=mean(x); sd=std(x,0); med=median(x); q25=quantile_local(x,0.25); ...
            q75=quantile_local(x,0.75); mn=min(x); mx=max(x);
    end
    successCount = sum(ok);
    totalCount = height(Q);
    solveTime = double(Q.SolveTime_s(ok));
    if isempty(solveTime), meanSolve=NaN; else, meanSolve=mean(solveTime,'omitnan'); end
    source = methodPacks{im}.source;
    displayName = manuscript_display_name_local(methodNames(im));
    pm = sprintf('%.4e +/- %.2e',mu,sd);
    rows{im} = table(methodNames(im),displayName,mu,sd,string(pm),med,q25,q75, ...
        q75-q25,mn,mx,successCount,totalCount,100*successCount/max(1,totalCount), ...
        meanSolve,double(source.offlineTrainingTimeSeconds), ...
        'VariableNames',{'Method','DisplayName','MeanRMSE','StdRMSE', ...
        'MeanPlusMinusStd','MedianRMSE','Q25_RMSE','Q75_RMSE','IQR_RMSE', ...
        'MinRMSE','MaxRMSE','SuccessfulWindows','TotalWindows', ...
        'SuccessRate_percent','MeanRolloutTime_s','OfflineTrainingTime_s'});
end
T = vertcat(rows{:});
end

function q = quantile_local(x,p)
x = sort(double(x(:)));
if isempty(x), q=NaN; return; end
if numel(x)==1, q=x; return; end
r = 1 + (numel(x)-1)*p;
lo=floor(r); hi=ceil(r);
if lo==hi, q=x(lo); else, q=x(lo)+(r-lo)*(x(hi)-x(lo)); end
end

function figureFiles = regenerate_figures_local(windowTable,cfg,figDir)
% Paper-facing output: violin-only distribution figure.  The legacy
% start-time and box+violin plotters remain available for diagnostics, but
% they are not generated/displayed by the formal Application-III report.
f = plot_receding_horizon_rmse_violin(windowTable,cfg,figDir);
figureFiles = string(f.png);
end

function T = canonicalize_display_names_local(T)
if ~istable(T) || ~ismember('Method',T.Properties.VariableNames) || ...
        ~ismember('DisplayName',T.Properties.VariableNames)
    return;
end
for i = 1:height(T)
    T.DisplayName(i) = manuscript_display_name_local(string(T.Method(i)));
end
end

function s = manuscript_display_name_local(methodName)
switch lower(char(methodName))
    case 'modular_koopman_kbf', s="M-KBF";
    case 'vanilla_sindy', s="V-SINDy";
    case 'physics_embedded_sindy', s="PE-SINDy";
    case 'edsi', s="ED-SINDy";
    case 'neural_ode_modular', s="NODE";
    case 'llm_prior_sindy', s="LLM-Prior SINDy";
    otherwise, s=string(methodName);
end
end

function enabled = prepare_parallel_pool_local(cfg)
enabled = false;
if ~cfg.receding.parallel.enabled, return; end
try
    if ~license('test','Distrib_Computing_Toolbox')
        warning('Parallel Computing Toolbox unavailable; using serial rollouts.');
        return;
    end
    pool = gcp('nocreate');
    if isempty(pool) && cfg.receding.parallel.autoStartPool
        pool = parpool(cfg.receding.parallel.poolProfile,cfg.receding.parallel.numWorkers);
    end
    if ~isempty(pool)
        enabled = true;
        fprintf('Receding-horizon rollouts: parallel pool with %d worker(s).\n',pool.NumWorkers);
    end
catch ME
    warning('run_receding_horizon_experiments:ParallelFallback', ...
        'Parallel pool unavailable (%s); using serial rollouts.',ME.message);
end
end

function validate_protocol_local(c,cfg)
assert(abs(c.sim.t0)<1e-12 && abs(c.sim.tf-cfg.receding.parentDurationSeconds)<1e-12, ...
    'Parent case horizon does not match receding configuration.');
assert(~c.drift.enabled,'Receding-horizon application must not contain parameter drift.');
assert(abs(cfg.receding.predictionHorizonSeconds-12.0)<1e-12, ...
    'Formal prediction horizon must remain 12 s.');
assert(abs(cfg.receding.anchorStepSeconds-1.0)<1e-12, ...
    'Formal sliding step must remain 1 s.');
expected = 0:1:48;
assert(isequal(double(cfg.receding.anchorTimesSeconds),expected), ...
    'Formal anchor grid must be 0:1:48 s (49 windows).');
assert(cfg.receding.initialModelSampleCount==500 && ...
    abs(cfg.receding.initialModelNoiseLevel)<1e-14, ...
    'Formal application must reuse the clean N=500 offline models.');
end

function sig = parent_case_signature_local(c,cfg)
sig = struct();
sig.caseName = c.name;
sig.scenarioName = c.scenario.name;
sig.tf = c.sim.tf;
sig.outputStep = c.sim.outputStep;
sig.predictionHorizonSeconds = cfg.receding.predictionHorizonSeconds;
sig.anchorStepSeconds = cfg.receding.anchorStepSeconds;
sig.eventSignature = event_signature_local(c);
end

function s = event_signature_local(c)
parts = strings(0,1);
sections = {'load','sgPm','sgVref','gfmP','gfmQ','gfmEref','gflP','gflQ'};
for iSec=1:numel(sections)
    secName=sections{iSec};
    if ~isfield(c,'dist') || ~isfield(c.dist,secName), continue; end
    sec=c.dist.(secName);
    if isfield(sec,'enabled') && ~logical(sec.enabled), continue; end
    if ~isfield(sec,'group') || isempty(sec.group), continue; end
    for ig=1:numel(sec.group)
        g=sec.group(ig);
        if strcmp(secName,'load'), fld='fraction'; else, fld='delta'; end
        if ~isfield(g,'time') || ~isfield(g,fld), continue; end
        parts(end+1,1)=string(secName)+"#"+string(ig)+":"+ ...
            string(sprintf('%.12g,',double(g.time(:))))+"|"+ ...
            string(sprintf('%.12g,',double(g.(fld)(:)))); %#ok<AGROW>
    end
end
s=strjoin(parts,';');
end

function tf = parent_truth_compatible_local(truth,c,cfg,S)
tf = isstruct(truth) && isfield(truth,'t') && isfield(truth,'y') && ...
    ~isempty(truth.t) && abs(double(truth.t(1))-c.sim.t0)<1e-10 && ...
    abs(double(truth.t(end))-c.sim.tf)<1e-10;
if ~tf, return; end
if ~(isfield(S,'caseSignature') && isstruct(S.caseSignature))
    tf=false;
    return;
end
expected = parent_case_signature_local(c,cfg);
tf = strcmp(string(S.caseSignature.caseName),string(expected.caseName)) && ...
    strcmp(string(S.caseSignature.scenarioName),string(expected.scenarioName)) && ...
    abs(double(S.caseSignature.tf)-expected.tf)<1e-10 && ...
    abs(double(S.caseSignature.outputStep)-expected.outputStep)<1e-12 && ...
    isfield(S.caseSignature,'eventSignature') && ...
    strcmp(string(S.caseSignature.eventSignature),string(expected.eventSignature));
end
