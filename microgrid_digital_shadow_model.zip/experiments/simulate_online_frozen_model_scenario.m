function prediction = simulate_online_frozen_model_scenario( ...
    model,method,truth,cNominal,layout,cfg)
%SIMULATE_ONLINE_FROZEN_MODEL_SCENARIO Roll out the unadapted digital model.
%
% The true reference system contains the hidden constant parameter mismatch.
% The frozen digital model deliberately uses cNominal with c.drift disabled,
% so no knowledge of the mismatched true parameter leaks into the digital
% shadow. No model correction is applied in this deployment mode.

cModel = cNominal;
if isfield(cModel,'drift')
    cModel.drift.enabled = false;
end
prediction = simulate_offline_model_scenario(model,method,truth,cModel,layout,cfg);
prediction.metadata.onlineMode = 'frozen';
prediction.metadata.parameterMismatchKnownToModel = false;
end
