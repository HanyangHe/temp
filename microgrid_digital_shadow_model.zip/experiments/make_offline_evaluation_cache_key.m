function key = make_offline_evaluation_cache_key(method,N,noiseLevel,cfg,dataset)
%MAKE_OFFLINE_EVALUATION_CACHE_KEY Canonical runtime-reuse key.
%
% The key is shared by the serial cache helper and the section-level parallel
% scheduler. Keeping one implementation prevents the scheduler from treating
% scientifically different data protocols as identical.

seed = NaN;
if isfield(cfg,'randomSeed')
    seed = cfg.randomSeed;
end
protocol = offline_method_data_protocol(dataset,method);
key = sprintf('%s|N=%d|noise=%.17g|seed=%.17g|protocol=%s', ...
    char(string(method.name)),N,noiseLevel,double(seed),char(protocol));



% Shared pointwise-SINDy backend tag.  The 2026-10-04 revision separates
% OLS-STLSQ support discovery from coefficient regularization, so caches from
% the former fixed-rho-in-STLSQ backend must not be reused silently.
pointwiseSindyMethods = ["vanilla_sindy","physics_embedded_sindy", ...
    "prior_weighted_sindy","physics_neural_sindy", ...
    "physics_neural_compositional_sindy","llm_prior_sindy", ...
    "llm_prior_sindy_diagnostic"];
if any(lower(string(method.name)) == pointwiseSindyMethods)
    so = get_sindy_options(cfg);
    key = sprintf(['%s|sindy_arch=%s|support_discovery_rho=%.17g|', ...
        'clean_final_rho=%.17g'],key,char(string(so.formulationVersion)), ...
        double(so.stlsq.ridge),double(so.stlsq.finalSupportRidgeRho));
end

% Formal Poly-3 SINDy baseline: the method name already separates it from
% V-SINDy, and this explicit tag prevents a future polynomial-order change
% from silently reusing an old Poly-3 condition checkpoint.
if lower(string(method.name)) == "poly3_sindy"
    key = sprintf('%s|poly_order=3|poly3_arch=generic_polytrig_v1',key);
end

% Formal EDSI family: tag the frozen search/LLM formulation so a future
% methodological change cannot silently reuse an incompatible old cache.
if any(lower(string(method.name)) == ["edsi","llm_edsi"])
    eo = get_edsi_options(cfg);
    key = sprintf(['%s|edsi_arch=%s|rho=%.17g|P=%d|K=%d|G=%d|search_seed=%d|', ...
        'search_stlsq=%d|final_stlsq=%d|shared_v_sindy_backend=%d'], ...
        key,char(string(eo.formulationVersion)),double(eo.rho), ...
        round(double(eo.populationSize)),round(double(eo.eliteCount)), ...
        round(double(eo.maxGenerations)),round(double(eo.evolutionSearchSeed)), ...
        round(double(eo.searchStlsqIterations)),round(double(eo.finalStlsqIterations)), ...
        logical(eo.shareSindyIdentificationBackend));
    if lower(string(method.name)) == "llm_edsi"
        key = sprintf(['%s|llm_arch=%s|llm_init_gen=%d|llm_calls=%d|', ...
            'llm_elites=%d|llm_depth=%d|llm_complexity=%d'], ...
            key,char(string(eo.llm.formulationVersion)), ...
            round(double(eo.llm.initialGeneration)),round(double(eo.llm.maxCalls)), ...
            round(double(eo.llm.refinedEliteCount)), ...
            round(double(eo.llm.maxExpressionDepth)), ...
            round(double(eo.llm.maxExpressionComplexity)));
        key = sprintf('%s|llm_active=%d|llm_propose=%d|llm_ode_terms=%d', ...
            key,round(double(eo.llm.maxActiveDictionaryTerms)), ...
            round(double(eo.llm.maxProposedTerms)), ...
            round(double(eo.llm.currentOdeTermsPerDerivative)));
    end
end



% Formal weak-domain LLM-Prior SINDy. The seed-specific prior hash is part of
% the key, so changing an LLM draw/protocol can never silently reuse an old
% identified model.
if lower(string(method.name)) == "llm_prior_sindy"
    so=get_sindy_options(cfg);
    h=string(so.llmPrior.priorBankHash);
    ds=double(so.llmPrior.discoverySeed);
    key=sprintf(['%s|llm_prior_arch=%s|discovery_protocol=%s|', ...
        'discovery_seed=%d|prior_hash=%s'],key, ...
        char(string(so.llmPrior.formulationVersion)), ...
        char(string(so.llmPrior.discoveryProtocolVersion)),round(ds),char(h));
end

% Non-production weak-domain LLM prior-discovery diagnostics. The prior bank
% is generated once per discovery seed/device schema and then reused across N
% and noise levels. Tag its hash so no stale diagnostic checkpoint is reused.
if any(lower(string(method.name)) == ["llm_prior_sindy_diagnostic","llm_prior_fixedwidth_sindy_diagnostic","llm_prior_edsi_diagnostic","llm_prior_augmented_edsi_diagnostic"])
    so = get_sindy_options(cfg);
    h = "";
    ds = 0;
    if isfield(so,'llmPriorDiagnostic')
        if isfield(so.llmPriorDiagnostic,'priorBankHash')
            h = string(so.llmPriorDiagnostic.priorBankHash);
        end
        if isfield(so.llmPriorDiagnostic,'discoverySeed')
            ds = double(so.llmPriorDiagnostic.discoverySeed);
        end
    end
    hc=NaN; mp=NaN; rt=NaN; sp=NaN;
    if isfield(so,'llmPriorDiagnostic')
        if isfield(so.llmPriorDiagnostic,'highConfidenceThreshold')
            hc=double(so.llmPriorDiagnostic.highConfidenceThreshold);
        end
        if isfield(so.llmPriorDiagnostic,'maxProtectedPriorTerms')
            mp=double(so.llmPriorDiagnostic.maxProtectedPriorTerms);
        end
        if isfield(so.llmPriorDiagnostic,'priorRedundancyRelativeTolerance')
            rt=double(so.llmPriorDiagnostic.priorRedundancyRelativeTolerance);
        end
        if isfield(so.llmPriorDiagnostic,'compressionSwapPolishMaxPasses')
            sp=double(so.llmPriorDiagnostic.compressionSwapPolishMaxPasses);
        end
    end
    key = sprintf(['%s|llm_prior_diag_v7_augmented_bank_10pct|', ...
        'discovery_seed=%d|prior_hash=%s|high_conf=%.6g|max_locked=%d|red_tol=%.3g|swap_pass=%d'], ...
        key,round(ds),char(h),hc,round(mp),rt,round(sp));
    if any(lower(string(method.name)) == ["llm_prior_edsi_diagnostic","llm_prior_augmented_edsi_diagnostic"])
        eo = get_edsi_options(cfg);
        key = sprintf(['%s|edsi_arch=%s|support_discovery_rho=%.17g|clean_final_rho=%.17g|', ...
            'P=%d|K=%d|G=%d|search_seed=%d|search_stlsq=%d|final_stlsq=%d'], ...
            key,char(string(eo.formulationVersion)),double(eo.supportDiscoveryRho), ...
            double(eo.finalSupportRidgeRho),round(eo.populationSize), ...
            round(eo.eliteCount),round(eo.maxGenerations), ...
            round(eo.evolutionSearchSeed),round(eo.searchStlsqIterations), ...
            round(eo.finalStlsqIterations));
        if lower(string(method.name)) == "llm_prior_augmented_edsi_diagnostic"
            key = sprintf(['%s|residual_refinement_v8|evolution_width_equals_v_sindy=1|', ...
                'llm_bank_basis_locked=1|llm_bank_coeff_frozen=1|short_rollout_champion=1|', ...
                'champion_min_rel=%.6g'],key,double(eo.residualChampionMinRelativeImprovement));
        end
    elseif lower(string(method.name)) == "llm_prior_fixedwidth_sindy_diagnostic"
        eo = get_edsi_options(cfg);
        key = sprintf(['%s|fw_noevo_v6|support_discovery_rho=%.17g|clean_final_rho=%.17g|', ...
            'search_stlsq=%d|final_stlsq=%d'], ...
            key,double(eo.supportDiscoveryRho),double(eo.finalSupportRidgeRho), ...
            round(eo.searchStlsqIterations),round(eo.finalStlsqIterations));
    end
end

% PNC underwent a structural change from the original [PE-output + neural]
% second layer to the v2 [PE bypass + exact flat-PN skip + composition] layer.
% Keep the architecture tag in the runtime/checkpoint key so an old PNC-v1
% condition can never be mistaken for the new method under the same N/noise.
if lower(string(method.name)) == "physics_neural_compositional_sindy"
    opt = get_sindy_options(cfg);
    key = sprintf('%s|pnc_arch=skip_v2|comp_seed_offset=%d',key, ...
        round(double(opt.physicsNeuralCompositional.compositionalSeedOffset)));
end

% Weak-SINDy now uses one fixed support-preserving coefficient refit for every
% clean/noisy condition.  Tag rho and the weak window definition so legacy
% Weak-SINDy caches cannot be reused after a methodological change.
if lower(string(method.name)) == "weak_sindy"
    opt = get_sindy_options(cfg);
    wp = sprintf('%d,',round(double(opt.weakSindy.windowPoints(:))));
    key = sprintf('%s|weak_rho=%.17g|weak_windows=%s|weak_phi_power=%d', ...
        key,double(opt.weakSindy.supportRidgeRelativeAlpha),wp, ...
        round(double(opt.weakSindy.testFunctionPower)));
end
end
