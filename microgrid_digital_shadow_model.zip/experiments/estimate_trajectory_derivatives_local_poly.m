function dX = estimate_trajectory_derivatives_local_poly(X,t,windowPoints,polyOrder)
%ESTIMATE_TRAJECTORY_DERIVATIVES_LOCAL_POLY Differentiate grouped trajectories.
%
% X is [time, trajectory, state]. For each saved sample and state channel, a
% local polynomial is fitted in physical time using one common window length
% and polynomial order. The derivative at the center sample is the linear
% polynomial coefficient. Near trajectory boundaries the same number of
% samples is retained with an asymmetric window.
%
% This implementation is self-contained and does not require Signal
% Processing Toolbox. It is intended for the common measurement-noise
% protocol in Offline Section 1.3, where every pointwise method receives
% derivative labels reconstructed from the SAME noisy state trajectories.

validateattributes(X,{'numeric'},{'nonempty','finite'});
if ndims(X) ~= 3
    error('estimate_trajectory_derivatives_local_poly:Shape', ...
        'X must have size [time, trajectory, state].');
end
t = double(t(:));
L = size(X,1);
if numel(t) ~= L
    error('estimate_trajectory_derivatives_local_poly:TimeSize', ...
        'numel(t) must match size(X,1).');
end
if any(diff(t) <= 0)
    error('estimate_trajectory_derivatives_local_poly:TimeOrder', ...
        'Trajectory time must be strictly increasing.');
end
validateattributes(windowPoints,{'numeric'}, ...
    {'scalar','integer','>=',3,'<=',L,'finite'});
validateattributes(polyOrder,{'numeric'}, ...
    {'scalar','integer','>=',1,'finite'});
if polyOrder >= windowPoints
    error('estimate_trajectory_derivatives_local_poly:PolynomialOrder', ...
        'polyOrder must be smaller than windowPoints.');
end

% An odd window keeps the interior estimator naturally centered. Requiring
% it explicitly also makes the manuscript protocol unambiguous.
if mod(windowPoints,2) ~= 1
    error('estimate_trajectory_derivatives_local_poly:OddWindow', ...
        'windowPoints must be odd.');
end

K = size(X,2);
nx = size(X,3);
dX = zeros(size(X),'like',X);
half = floor(windowPoints/2);

for i = 1:L
    i0 = i-half;
    i0 = max(1,min(i0,L-windowPoints+1));
    idx = i0:(i0+windowPoints-1);

    % Center time at the requested derivative sample. The coefficient of
    % tau^1 is therefore dx/dt evaluated at tau=0.
    tau = t(idx)-t(i);
    A = zeros(windowPoints,polyOrder+1);
    for p = 0:polyOrder
        A(:,p+1) = tau.^p;
    end

    % Solve all trajectories/state channels with the same local operator.
    Y = reshape(X(idx,:,:),windowPoints,K*nx);
    C = A\double(Y);
    dRow = C(2,:);
    dX(i,:,:) = reshape(cast(dRow,'like',X),[1 K nx]);
end
end
