function [candidateModel,info] = update_local_pnc_second_layer_stlsq( ...
    initialModel,offlineData,onlineData,method,cfg)
%UPDATE_LOCAL_PNC_SECOND_LAYER_STLSQ Fast online PNC-SINDy layer-2 correction.
%
% PNC v2 structure:
%   Layer 1: H = Theta_PE(chi) * Xi_1
%   Layer 2: xdot = [H, Theta_PN_flat(chi), Phi_comp(chi,H)] * Xi_2
%
% Online policy:
%   - freeze Xi_1 exactly;
%   - freeze BOTH random-feature banks and all stored dictionary specs exactly;
%   - update only Xi_2 for the localized DER module;
%   - allow Xi_2 support reselection so PE, shallow-PN, and compositional
%     columns can be activated/deactivated after a physical-model mismatch;
%   - use only causal online observations available before the detector/update
%     data boundary;
%   - retain the saved offline Xi_2 as a prior/no-update candidate;
%   - every candidate is a fixed-feature sparse linear regression (no BP).
%
% The sparse readout is fitted by a prior-centered, exponentially weighted
% STLSQ. The offline feature matrix contributes conditioning information only;
% its old targets are not re-fitted. This preserves the offline PNC model as
% the prior mean while letting causal data reselect the layer-2 support.

name = lower(string(method.name));
if name ~= "physics_neural_compositional_sindy"
    error('update_local_pnc_second_layer_stlsq:Method', ...
        'This updater is implemented only for physics_neural_compositional_sindy.');
end
if ~isfield(cfg.online.update,'pncLayer2') || ~isstruct(cfg.online.update.pncLayer2)
    error('update_local_pnc_second_layer_stlsq:Options', ...
        'cfg.online.update.pncLayer2 is required.');
end
opt = cfg.online.update.pncLayer2;

required = {'supportReselection','includeOfflineModelCandidate','validationFraction', ...
    'minimumValidationSamples','thresholdGrid','maxIterations', ...
    'preferSparseWithinRelativeValidationTolerance','validationAbsoluteTolerance', ...
    'offlineInformationWeight','onlineSampleWeight','priorPrecision', ...
    'covarianceJitter','forgettingHalfLifeSeconds','preferOfflineCandidateWhenNearBest'};
for k = 1:numel(required)
    if ~isfield(opt,required{k})
        error('update_local_pnc_second_layer_stlsq:Options', ...
            'Missing cfg.online.update.pncLayer2.%s.',required{k});
    end
end
if ~logical(opt.supportReselection)
    error('update_local_pnc_second_layer_stlsq:SupportPolicy', ...
        ['PNC online adaptation requires supportReselection=true so neural ', ...
         'features that were inactive in the nominal model can activate.']);
end

% Identify the localized module from the compact local dataset.
deviceType = lower(string(onlineData.deviceType));
deviceIndex = double(onlineData.deviceIndex);
moduleField = char(deviceType);
if ~isfield(initialModel,moduleField) || deviceIndex<1 || ...
        deviceIndex>numel(initialModel.(moduleField))
    error('update_local_pnc_second_layer_stlsq:ModuleIndex', ...
        'Requested %s%d module is not present in the saved PNC model.', ...
        upper(moduleField),deviceIndex);
end
module0 = initialModel.(moduleField)(deviceIndex);
if ~isfield(module0,'layer1') || isempty(module0.layer1) || ...
        ~isfield(module0,'shallowPNParent') || isempty(module0.shallowPNParent) || ...
        ~isfield(module0,'librarySpec') || isempty(module0.librarySpec) || ...
        ~isfield(module0,'architectureVersion') || ...
        ~strcmp(char(string(module0.architectureVersion)),'pnc_skip_composition_v2')
    error('update_local_pnc_second_layer_stlsq:PNCSchema', ...
        ['The saved module does not contain the PNC v2 PE-bypass / flat-PN-skip / ', ...
         'compositional schema. Rebuild the offline PNC model first.']);
end

% Rebuild BOTH datasets through the saved frozen architecture. Xi_1, the
% flat-PN random-feature bank, and the compositional random-feature bank are
% therefore identical to the offline model.
[ThetaOff,namesOff,Hoff] = evaluate_frozen_pnc_library(module0,offlineData,initialModel);
[ThetaOn,namesOn,Hon] = evaluate_frozen_pnc_library(module0,onlineData,initialModel);
if numel(namesOff)~=numel(module0.libraryNames) || ...
        any(string(namesOff(:))~=string(module0.libraryNames(:))) || ...
        numel(namesOn)~=numel(module0.libraryNames) || ...
        any(string(namesOn(:))~=string(module0.libraryNames(:)))
    error('update_local_pnc_second_layer_stlsq:LibraryOrder', ...
        'Stored and online PNC layer-2 library columns are inconsistent.');
end

C0 = double(module0.coefficients);
[nTerms,nOut] = size(C0);
if size(ThetaOn,2)~=nTerms || size(ThetaOff,2)~=nTerms
    error('update_local_pnc_second_layer_stlsq:LibraryWidth', ...
        'PNC layer-2 width does not match the saved Xi_2 coefficient rows.');
end
if size(onlineData.Y,2)~=nOut
    error('update_local_pnc_second_layer_stlsq:OutputWidth', ...
        'Online target width does not match the saved PNC Xi_2 outputs.');
end

colScale = double(module0.libraryColumnScale(:));
yScale = double(module0.outputScale(:));
if numel(colScale)~=nTerms || numel(yScale)~=nOut
    error('update_local_pnc_second_layer_stlsq:Normalization', ...
        'Saved PNC layer-2 normalization metadata are incomplete.');
end
colScale = max(abs(colScale),eps);
yScale = max(abs(yScale),eps);
PhiOff = double(ThetaOff)./colScale.';
PhiOn = double(ThetaOn)./colScale.';
BOn = double(onlineData.Y)./yScale.';
Xi0 = (C0.*colScale)./yScale.'; % saved physical coefficients -> normalized Xi_2

nOn = size(PhiOn,1);
if nOn < 6
    error('update_local_pnc_second_layer_stlsq:TooFewSamples', ...
        'At least six causal online samples are required.');
end
[valMask,trainMask] = make_internal_split(nOn,opt.validationFraction, ...
    opt.minimumValidationSamples);
if nnz(trainMask)<2 || nnz(valMask)<1
    error('update_local_pnc_second_layer_stlsq:InternalSplit', ...
        'Unable to form a valid causal internal train/validation split.');
end

% Exponential recency weighting. All samples are already causal; this only
% changes their relative influence within the available prefix.
tOn = double(onlineData.trajectoryTime(:));
if numel(tOn)~=nOn || any(~isfinite(tOn))
    tOn = (0:nOn-1).'*double(cfg.online.update.sampleStep);
end
halfLife = double(opt.forgettingHalfLifeSeconds);
if ~isfinite(halfLife) || halfLife<=0
    error('update_local_pnc_second_layer_stlsq:HalfLife', ...
        'pncLayer2.forgettingHalfLifeSeconds must be positive and finite.');
end
age = max(0,tOn(end)-tOn);
weights = double(opt.onlineSampleWeight) .* exp(log(0.5)*age/halfLife);
weights = max(weights,eps);

% Prior information: preserve the saved Xi_2 as the mean while using the
% nominal offline feature geometry only to condition poorly excited directions.
offlineWeight = max(0,double(opt.offlineInformationWeight));
priorPrecision = max(0,double(opt.priorPrecision));
jitter = max(0,double(opt.covarianceJitter));
Gprior = priorPrecision*eye(nTerms);
if offlineWeight>0 && ~isempty(PhiOff)
    Gprior = Gprior + offlineWeight*(PhiOff.'*PhiOff);
end
if jitter>0
    Gprior = Gprior + jitter*eye(nTerms);
end

lambdas = unique(sort(double(opt.thresholdGrid(:))),'stable');
if isempty(lambdas)
    lambdas = 0;
end
if ~any(lambdas==0)
    lambdas = [0;lambdas(:)];
end

resultTemplate = struct('candidateType',"",'lambda',NaN, ...
    'trainNormalizedMSE',NaN,'validationNormalizedMSE',NaN, ...
    'activeCoefficientCount',NaN,'normalizedCoefficientFroNorm',NaN, ...
    'supportMask',[],'XiNormalized',[]);
results = repmat(resultTemplate,0,1);

if logical(opt.includeOfflineModelCandidate)
    results(end+1,1) = make_result("offline_prior",NaN,Xi0, ...
        abs(Xi0)>0,PhiOn,BOn,trainMask,valMask,weights); %#ok<AGROW>
end

for iLambda = 1:numel(lambdas)
    lambda = lambdas(iLambda);
    Xi = prior_centered_stlsq(PhiOn(trainMask,:),BOn(trainMask,:), ...
        weights(trainMask),Gprior,Xi0,lambda,round(double(opt.maxIterations)));
    support = abs(Xi)>0;
    results(end+1,1) = make_result("online_stlsq",lambda,Xi,support, ...
        PhiOn,BOn,trainMask,valMask,weights); %#ok<AGROW>
end

val = [results.validationNormalizedMSE].';
complexity = [results.activeCoefficientCount].';
bestVal = min(val);
nearTol = double(opt.validationAbsoluteTolerance) + ...
    double(opt.preferSparseWithinRelativeValidationTolerance)*max(bestVal,eps);
eligible = find(val <= bestVal + nearTol);
if isempty(eligible)
    [~,bestIdx] = min(val);
else
    priorIdx = find(string({results.candidateType}).'=="offline_prior",1,'first');
    if logical(opt.preferOfflineCandidateWhenNearBest) && ...
            ~isempty(priorIdx) && any(eligible==priorIdx)
        bestIdx = priorIdx;
    else
        minComplexity = min(complexity(eligible));
        cTol = 100*eps(max(1,minComplexity));
        candidates = eligible(abs(complexity(eligible)-minComplexity)<=cTol);
        if numel(candidates)>1
            candidateVal = val(candidates);
            minVal = min(candidateVal);
            candidates = candidates(abs(candidateVal-minVal) <= ...
                100*eps(max(1,minVal)));
        end
        if numel(candidates)>1
            norms = [results(candidates).normalizedCoefficientFroNorm].';
            [~,loc] = min(norms);
            candidates = candidates(loc);
        end
        bestIdx = candidates(1);
    end
end

best = results(bestIdx);
XiNew = best.XiNormalized;
Cnew = (XiNew./colScale).*yScale.';

% Replace ONLY Xi_2 in the localized module. Layer 1, both frozen feature
% banks, scaling, dictionary ordering, and all untouched modules remain fixed.
candidateModel = initialModel;
moduleArray = candidateModel.(moduleField);
moduleArray(deviceIndex).coefficients = Cnew;
if ~isfield(moduleArray(deviceIndex),'offlineSelectedCandidateType') || ...
        isempty(moduleArray(deviceIndex).offlineSelectedCandidateType)
    moduleArray(deviceIndex).offlineSelectedCandidateType = ...
        moduleArray(deviceIndex).selectedCandidateType;
end
moduleArray(deviceIndex).selectedCandidateType = 'online_updated_layer2';
moduleArray(deviceIndex).selectedThreshold = best.lambda;
moduleArray(deviceIndex).activeCoefficientCount = nnz(Cnew~=0);
moduleArray(deviceIndex).onlineUpdateStrategy = 'pnc_layer2_prior_centered_stlsq';
moduleArray(deviceIndex).onlineLayer1Frozen = true;
moduleArray(deviceIndex).onlineNeuralBankFrozen = true; % legacy alias: both banks frozen
moduleArray(deviceIndex).onlineShallowPNBankFrozen = true;
moduleArray(deviceIndex).onlineCompositionalBankFrozen = true;
moduleArray(deviceIndex).onlineLayer2Updated = true;
moduleArray(deviceIndex).onlineLayer2SupportReselected = true;
moduleArray(deviceIndex).onlineLayer2SelectedCandidateType = char(best.candidateType);
moduleArray(deviceIndex).onlineLayer2SelectedThreshold = best.lambda;
moduleArray(deviceIndex).onlineLayer2UpdateSampleCount = nOn;
moduleArray(deviceIndex).onlineLayer2UpdateTimestamp = datetime('now');
moduleArray(deviceIndex).onlineLayer2ValidationNormalizedMSE = best.validationNormalizedMSE;
moduleArray(deviceIndex).onlineLayer2TrainNormalizedMSE = best.trainNormalizedMSE;
moduleArray(deviceIndex).onlineLayer2InitialActiveCoefficientCount = nnz(C0~=0);
moduleArray(deviceIndex).onlineLayer2SupportChanged = ...
    ~isequal(abs(Cnew)>0,abs(C0)>0);
moduleArray(deviceIndex).onlineLayer1OutputTrainingRMS = ...
    sqrt(mean(Hon.^2,1));
candidateModel.(moduleField) = moduleArray;
candidateModel.onlineUpdateStrategy = 'pnc_layer2_prior_centered_stlsq';
candidateModel.onlineUpdatedDeviceType = moduleField;
candidateModel.onlineUpdatedDeviceIndex = deviceIndex;
candidateModel.onlinePNCLayer1Frozen = true;
candidateModel.onlinePNCLayer2Only = true;

activeMask = abs(Cnew)>0;
spec = module0.librarySpec;
peIdx = spec.peBypassColumnIndices(:);
pnIdx = spec.shallowPNColumnIndices(:);
compIdx = spec.compositionalNeuralColumnIndices(:);
activePE = nnz(activeMask(peIdx,:));
activePN = nnz(activeMask(pnIdx,:));
activeComp = nnz(activeMask(compIdx,:));
moduleArray = candidateModel.(moduleField);
moduleArray(deviceIndex).activePEBypassCoefficientCount = activePE;
moduleArray(deviceIndex).activeShallowPNCoefficientCount = activePN;
moduleArray(deviceIndex).activeCompositionalCoefficientCount = activeComp;
moduleArray(deviceIndex).activeBypassCoefficientCount = activePE;
moduleArray(deviceIndex).activeNeuralCoefficientCount = activeComp;
candidateModel.(moduleField) = moduleArray;

info = struct();
info.strategy = 'pnc_layer2_prior_centered_stlsq';
info.deviceType = moduleField;
info.deviceIndex = deviceIndex;
info.layer1Frozen = true;
info.neuralBankFrozen = true; % backward-compatible summary
info.shallowPNBankFrozen = true;
info.compositionalBankFrozen = true;
info.layer2Only = true;
info.supportReselected = true;
info.supportChanged = moduleArray(deviceIndex).onlineLayer2SupportChanged;
info.selectedCandidateType = char(best.candidateType);
info.selectedThreshold = best.lambda;
info.initialValidationNormalizedMSE = result_value(results,"offline_prior", ...
    'validationNormalizedMSE');
info.selectedValidationNormalizedMSE = best.validationNormalizedMSE;
info.selectedTrainNormalizedMSE = best.trainNormalizedMSE;
info.initialActiveCoefficientCount = nnz(C0~=0);
info.activeCoefficientCount = nnz(Cnew~=0);
info.activeBypassCoefficientCount = activePE;
info.activePEBypassCoefficientCount = activePE;
info.activeShallowPNCoefficientCount = activePN;
info.activeCompositionalCoefficientCount = activeComp;
info.activeNeuralCoefficientCount = activeComp; % legacy alias
info.onlineSampleCount = nOn;
info.internalTrainingSampleCount = nnz(trainMask);
info.internalValidationSampleCount = nnz(valMask);
info.offlineInformationSampleCount = size(PhiOff,1);
info.offlineInformationWeight = offlineWeight;
info.onlineSampleWeight = double(opt.onlineSampleWeight);
info.priorPrecision = priorPrecision;
info.forgettingHalfLifeSeconds = halfLife;
info.libraryNames = string(module0.libraryNames(:));
info.layer1PredictionRMSOffline = sqrt(mean(Hoff.^2,1));
info.layer1PredictionRMSOnline = sqrt(mean(Hon.^2,1));
info.candidateTable = struct2table(rmfield(results,{'supportMask','XiNormalized'}));
end

function [Theta2,names2,H] = evaluate_frozen_pnc_library(module,data,model)
L1 = module.layer1;
[Theta1,names1] = build_sindy_library( ...
    data.X,L1.inputNames,L1.deviceType,"physics",model.options,L1.librarySpec);
if numel(names1)~=numel(L1.libraryNames) || ...
        any(string(names1(:))~=string(L1.libraryNames(:)))
    error('update_local_pnc_second_layer_stlsq:Layer1LibraryOrder', ...
        'Frozen PE layer-1 library ordering changed during online adaptation.');
end
H = Theta1*L1.coefficients;
[Theta2,names2] = build_pnc_sindy_second_layer_library( ...
    data.X,H,module.inputNames,module.outputNames,module.deviceType,model.options, ...
    module.neuralBasisSeed,module.librarySpec);
end

function Xi = prior_centered_stlsq(A,B,rowWeights,Gprior,Xi0,lambda,maxIter)
% Sparse threshold/refit where each refit solves one convex quadratic:
%   min ||W^(1/2)(A Xi-B)||_F^2 + ||Xi-Xi0||^2_{Gprior}
% with inactive coefficients fixed to zero.
if maxIter<1, maxIter=1; end
sw = sqrt(max(double(rowWeights(:)),eps));
Aw = A.*sw;
Bw = B.*sw;
nTerms = size(A,2);
nOut = size(B,2);
Xi = zeros(nTerms,nOut);

for j=1:nOut
    active = true(nTerms,1);
    xi = solve_active(Aw,Bw(:,j),Gprior,Xi0(:,j),active);
    if lambda<=0
        Xi(:,j)=xi;
        continue;
    end
    for it=1:maxIter
        activeNew = abs(xi)>=lambda;
        if ~any(activeNew)
            [~,imax] = max(abs(xi));
            activeNew(imax)=true;
        end
        if isequal(activeNew,active)
            break;
        end
        active = activeNew;
        xi = solve_active(Aw,Bw(:,j),Gprior,Xi0(:,j),active);
    end
    xi(~active)=0;
    Xi(:,j)=xi;
end
end

function xi = solve_active(Aw,bw,Gprior,xi0,active)
n = numel(active);
xi = zeros(n,1);
idx = find(active);
if isempty(idx), return; end
Gaa = Aw(:,idx).'*Aw(:,idx) + Gprior(idx,idx);
rhs = Aw(:,idx).'*bw + Gprior(idx,:)*xi0;
if rcond(Gaa) < 1e-14
    xi(idx) = pinv(Gaa)*rhs;
else
    xi(idx) = Gaa\rhs;
end
end

function r = make_result(type,lambda,Xi,support,A,B,trainMask,valMask,weights)
r = struct();
r.candidateType = string(type);
r.lambda = lambda;
r.trainNormalizedMSE = weighted_nmse(A(trainMask,:)*Xi-B(trainMask,:), ...
    B(trainMask,:),weights(trainMask));
r.validationNormalizedMSE = ordinary_nmse(A(valMask,:)*Xi-B(valMask,:),B(valMask,:));
r.activeCoefficientCount = nnz(support);
r.normalizedCoefficientFroNorm = norm(Xi,'fro');
r.supportMask = logical(support);
r.XiNormalized = Xi;
end

function e = weighted_nmse(R,Y,w)
w = double(w(:));
w = w/max(sum(w),eps);
num = sum(w.*mean(R.^2,2));
den = sum(w.*mean(Y.^2,2));
e = num/max(den,eps);
end

function e = ordinary_nmse(R,Y)
e = mean(R.^2,'all')/max(mean(Y.^2,'all'),eps);
end

function [valMask,trainMask] = make_internal_split(n,fraction,minVal)
fraction = min(max(double(fraction),0.05),0.45);
minVal = max(1,round(double(minVal)));
nVal = max(minVal,round(fraction*n));
nVal = min(nVal,max(1,n-2));
idx = unique(round(linspace(1,n,nVal)));
% If rounding collapsed points, fill deterministically from left to right.
if numel(idx)<nVal
    missing = setdiff(1:n,idx,'stable');
    idx = [idx(:); missing(1:min(nVal-numel(idx),numel(missing))).']; %#ok<AGROW>
    idx = unique(idx,'stable');
end
valMask = false(n,1);
valMask(idx)=true;
trainMask = ~valMask;
end

function v = result_value(results,type,field)
idx = find(string({results.candidateType}).'==string(type),1,'first');
if isempty(idx)
    v = NaN;
else
    v = results(idx).(field);
end
end
