function dataset = generate_offline_sobol_dataset(c,layout,cfg,projectRoot)
%GENERATE_OFFLINE_SOBOL_DATASET Compatibility wrapper (v1p7+).
% Offline samples are no longer isolated Sobol points. Sobol is now used only
% for short-trajectory initial conditions; call the trajectory generator.
dataset = generate_offline_trajectory_dataset(c,layout,cfg,projectRoot);
end
