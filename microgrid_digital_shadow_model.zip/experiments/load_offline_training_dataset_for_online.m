function [dataset,source] = load_offline_training_dataset_for_online( ...
    projectRoot,cfg,N,noiseLevel)
%LOAD_OFFLINE_TRAINING_DATASET_FOR_ONLINE Load the original nominal dataset.
%
% The online correction reuses exactly the original nominal short-trajectory
% pool. The requested first-N nested subset is reconstructed from the saved
% clean cache and receives the same offline training-target noise realization
% before online observations are appended.

if ~isfield(cfg,'online') || ~isfield(cfg.online,'offlineOutputFolder')
    error('load_offline_training_dataset_for_online:OfflineFolder', ...
        'cfg.online.offlineOutputFolder is required.');
end

offlineRoot = fullfile(projectRoot,'outputs',char(string(cfg.online.offlineOutputFolder)));
if isfield(cfg.online,'initialModelSeed') && ~isempty(cfg.online.initialModelSeed)
    offlineRoot = fullfile(offlineRoot,'seed_runs', ...
        sprintf('seed_%d',round(double(cfg.online.initialModelSeed))));
end
dataDir = fullfile(offlineRoot,'data');
if exist(dataDir,'dir') ~= 7
    error('load_offline_training_dataset_for_online:MissingDataFolder', ...
        ['Offline training-data folder was not found:\n  %s\n', ...
         'Run the corresponding offline experiment/data generation first.'],dataDir);
end

files = dir(fullfile(dataDir,'offline_short_trajectories_*.mat'));
if isempty(files)
    error('load_offline_training_dataset_for_online:MissingDataset', ...
        'No offline_short_trajectories_*.mat cache was found in %s.',dataDir);
end

% Prefer the smallest compatible cache that still contains the requested N.
best = [];
bestN = inf;
bestPath = '';
for i=1:numel(files)
    path = fullfile(files(i).folder,files(i).name);
    try
        S = load_mat_long_path_safe(path,'dataset');
        if ~isfield(S,'dataset') || ~isstruct(S.dataset), continue; end
        D = S.dataset;
        nRows = size(D.x,1);
        if nRows < N, continue; end
        if nRows < bestN
            best = D;
            bestN = nRows;
            bestPath = path;
        end
    catch
        % Ignore unreadable historical caches and continue searching.
    end
end
if isempty(best)
    error('load_offline_training_dataset_for_online:NoCompatibleDataset', ...
        'No readable offline dataset contains the requested N=%d samples.',N);
end

clean = subset_offline_dataset(best,N);
dataset = add_offline_training_noise(clean,noiseLevel,cfg);
source = struct();
source.cacheFile = bestPath;
source.cachedSampleCount = bestN;
source.sampleCount = N;
source.noiseLevel = noiseLevel;
source.noisePercent = 100*noiseLevel;
end
