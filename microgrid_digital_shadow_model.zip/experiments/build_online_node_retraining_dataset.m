function [aug,info] = build_online_node_retraining_dataset( ...
    base,observations,triggerTime,cfg)
%BUILD_ONLINE_NODE_RETRAINING_DATASET Append recent measured trajectory blocks.
%
% NODE is trajectory-trained, so online pointwise replication is not valid.
% Instead, the most recent L-point block at the original trajectory sample
% step is appended and deterministically replicated to emphasize the new
% operating dynamics. Per-time input histories are stored explicitly.

L = base.trajectories.pointsPerTrajectory;
dt = base.trajectories.t(2)-base.trajectories.t(1);
t = observations.t(:);
idxCandidate = find(t <= triggerTime+1e-12);
if isempty(idxCandidate)
    error('build_online_node_retraining_dataset:NoSamples','No samples precede trigger.');
end

% Pick nearest points on the original NODE trajectory time step.
endIdx = idxCandidate(end);
tEnd = t(endIdx);
tStart = tEnd-(L-1)*dt;
if tStart < t(1)-1e-12
    error('build_online_node_retraining_dataset:TooShort', ...
        'Trigger t=%.6g s does not provide a full %.3f-s NODE block.', ...
        triggerTime,(L-1)*dt);
end
target = tStart + (0:L-1).'*dt;
idx = zeros(L,1);
for j=1:L
    [err,idx(j)] = min(abs(t-target(j)));
    if err > max(1e-8,0.25*median(diff(t)))
        error('build_online_node_retraining_dataset:TimeGrid', ...
            'Could not align online sample %.6g s to the NODE trajectory grid.',target(j));
    end
end

rep = max(1,round(cfg.online.update.node.onlineTrajectoryReplication));
K0 = base.trajectories.nTrajectories;
aug = base;
if ~isfield(aug.trajectories,'uTimeSeriesByTrajectory') || isempty(aug.trajectories.uTimeSeriesByTrajectory)
    aug.trajectories.uTimeSeriesByTrajectory = cell(K0+rep,1);
elseif numel(aug.trajectories.uTimeSeriesByTrajectory) < K0+rep
    aug.trajectories.uTimeSeriesByTrajectory{K0+rep,1} = [];
end

% Add one or more identical recent trajectory blocks. Replication is the NODE
% analogue of the pointwise online-sample weighting used by SINDy/M-KBF.
for r=1:rep
    kNew = K0+r;
    aug.trajectories.xClean(:,kNew,:) = reshape(observations.x(:,idx).',[L 1 size(observations.x,1)]);
    aug.trajectories.xObserved(:,kNew,:) = reshape(observations.x(:,idx).',[L 1 size(observations.x,1)]);
    aug.trajectories.V(:,kNew,:) = reshape(observations.V(:,idx).',[L 1 size(observations.V,1)]);
    aug.trajectories.labelsClean(:,kNew,:) = reshape(observations.xdotClean(:,idx).',[L 1 size(observations.xdotClean,1)]);
    aug.trajectories.labels(:,kNew,:) = reshape(observations.xdotObserved(:,idx).',[L 1 size(observations.xdotObserved,1)]);
    if isfield(aug.trajectories,'features')
        aug.trajectories.features(:,kNew,:) = 0;
    end
    aug.trajectories.uByTrajectory{kNew,1} = online_input_at_observation(observations,idx(end));
    aug.trajectories.uTimeSeriesByTrajectory{kNew,1} = make_input_timeseries(observations,idx);
end


if isfield(base.trajectories,'forceTrainingMask') && ~isempty(base.trajectories.forceTrainingMask)
    aug.trajectories.forceTrainingMask = [logical(base.trajectories.forceTrainingMask(:)); true(rep,1)];
else
    aug.trajectories.forceTrainingMask = [false(K0,1); true(rep,1)];
end
if isfield(base.trajectories,'sourceType')
    aug.trajectories.sourceType = [string(base.trajectories.sourceType(:)); repmat("online_recent_block",rep,1)];
end
if isfield(base.trajectories,'isTestInitialAnchor')
    aug.trajectories.isTestInitialAnchor = [logical(base.trajectories.isTestInitialAnchor(:)); false(rep,1)];
end
if isfield(base.trajectories,'initialSobolCoordinates')
    aug.trajectories.initialSobolCoordinates = [base.trajectories.initialSobolCoordinates; ...
        nan(rep,size(base.trajectories.initialSobolCoordinates,2))];
end
aug.trajectories.nTrajectories = K0+rep;

% Keep flat arrays internally consistent for report code, although NODE reads
% the grouped trajectory arrays above.
xNew = repmat(observations.x(:,idx).',rep,1);
VNew = repmat(observations.V(:,idx).',rep,1);
yNew = repmat(observations.xdotObserved(:,idx).',rep,1);
yCleanNew = repmat(observations.xdotClean(:,idx).',rep,1);
aug.x = [base.x; xNew];
aug.V = [base.V; VNew];
aug.labels = [base.labels; yNew];
aug.labelsClean = [base.labelsClean; yCleanNew];
if isfield(base,'features'), aug.features=[base.features; zeros(size(xNew,1),size(base.features,2))]; end
if isfield(base,'z')
    if isfield(observations,'z') && ~isempty(observations.z)
        aug.z=[base.z; repmat(observations.z(:,idx).',rep,1)];
    else
        aug.z=[base.z; zeros(size(xNew,1),size(base.z,2))];
    end
end
traj = zeros(L*rep,1); point = zeros(L*rep,1);
for r=1:rep
    q=(r-1)*L+(1:L);
    traj(q)=K0+r;
    point(q)=(1:L).';
end
aug.trajectoryId=[base.trajectoryId(:);traj];
aug.pointInTrajectory=[base.pointInTrajectory(:);point];

aug.metadata.onlineAugmented=true;
aug.metadata.onlineTriggerTime=triggerTime;
aug.metadata.onlineNodeTrajectoryReplication=rep;
aug.metadata.onlineNodeTimeRange=[t(idx(1)) t(idx(end))];

info=struct();
info.onlineUniqueSampleCount=L;
info.onlineTrajectoryReplication=rep;
info.onlineReplicatedRowCount=L*rep;
info.offlineSampleCount=size(base.x,1);
info.totalRegressionRows=size(aug.x,1);
info.timeRange=[t(idx(1)) t(idx(end))];
end

function U = make_input_timeseries(obs,idx)
U=struct();
fields={'sgPm','sgVref','gfmPstar','gfmQstar','gfmEref','gflPstar','gflQstar','loadP','loadQ'};
for i=1:numel(fields)
    f=fields{i};
    if isfield(obs.inputs,f) && ~isempty(obs.inputs.(f))
        U.(f)=obs.inputs.(f)(:,idx);
    end
end
end
