function update = retrain_online_model_after_trigger( ...
    initialModel,baseDataset,observations,detector,method,cNominal,layout,cfg)
%RETRAIN_ONLINE_MODEL_AFTER_TRIGGER Causal online model correction.
%
% Online architecture-level operation A (adaptation) is method-agnostic:
% when the detector triggers, the active learned model is re-estimated from
% causal measurements. The method-specific numerical update differs:
%   - V/PE/Neural/LLM SINDy: localized fixed-support coefficient RLS
%   - PNC-SINDy: historical layer-2 sparse update
%   - M-KBF: causal retraining of its learned Koopman generator coefficients
% The actual wall-clock model-update time is measured with tic/toc and enters
% the deployment delay. State synchronization (S) is handled separately by
% the deployment engine and is therefore method independent.

update = empty_update_local();
if ~isstruct(detector) || ~isfield(detector,'triggered') || ~detector.triggered || ...
        ~cfg.online.update.enabled
    return;
end

update.triggered = true;
update.triggerTime = detector.triggerTime;
update.affectedModuleLabel = string(detector.affectedModuleLabel);
update.affectedDeviceType = char(detector.affectedDeviceType);
update.affectedDeviceIndex = detector.affectedDeviceIndex;
update.affectedStateIndices = detector.affectedStateIndices(:);
update.strategy = char(string(cfg.online.update.strategy));

methodName = lower(string(method.name));
sindyFamily = ["vanilla_sindy","physics_embedded_sindy", ...
    "neural_sindy","physics_neural_sindy","physics_neural_compositional_sindy", ...
    "llm_prior_sindy"];
isMKBF = methodName=="modular_koopman_kbf";
if ~any(methodName==sindyFamily) && ~isMKBF
    update.failureMessage = string(sprintf([ ...
        'Online adaptation has not been implemented for %s.'],method.displayName));
    update.failureIdentifier = "retrain_online_model_after_trigger:UnsupportedFamily";
    return;
end

strategy = lower(string(cfg.online.update.strategy));
validStrategies = ["method_specific_fast_update", ...
    "module_local_fixed_support_rls","pnc_layer2_prior_centered_stlsq", ...
    "causal_full_retrain"];
if ~any(strategy==validStrategies)
    update.failureMessage = "Unknown online update strategy: " + string(cfg.online.update.strategy);
    update.failureIdentifier = "retrain_online_model_after_trigger:Strategy";
    return;
end

try
    update.trainingStarted = true;

    if isMKBF
        % M-KBF uses the same causal sample-availability rule as SINDy, but
        % retrains its learned generator coefficients with its native trainer.
        % No future samples are exposed. The original offline validation
        % trajectories remain intact; the causal online block is forced into
        % the training partition.
        dataTimer = tic;
        [idx,effectiveDataEndTime,dataInfo] = select_causal_online_samples_local( ...
            observations,detector.triggerTime,cfg);
        augmentedDataset = append_online_block_local( ...
            baseDataset,observations,idx,effectiveDataEndTime);
        update.dataPreparationTimeSeconds = toc(dataTimer);

        trainTimer = tic;
        [candidateModel,localInfo] = method.trainFcn( ...
            augmentedDataset,cNominal,layout,cfg);
        trainTime = toc(trainTimer);
        localInfo.onlineUpdateStrategy = 'causal_mkbf_generator_retrain';
        localInfo.onlineUniqueSampleCount = numel(idx);
        dataInfo.offlineSampleCount = size(baseDataset.x,1);
        dataInfo.onlineUniqueSampleCount = numel(idx);
        dataInfo.onlineUsedSampleCount = numel(idx);
        dataInfo.onlineReplicatedRowCount = 0;
        dataInfo.effectiveDataEndTime = effectiveDataEndTime;
    else
        % SINDy-family updates are localized to the detector-selected module.
        dataTimer = tic;
        [offlineData,onlineData,dataInfo] = build_online_local_module_data( ...
            baseDataset,observations,detector.triggerTime,cNominal,layout, ...
            detector.affectedDeviceType,detector.affectedDeviceIndex,cfg);
        update.dataPreparationTimeSeconds = toc(dataTimer);

        trainTimer = tic;
        if methodName == "physics_neural_compositional_sindy"
            if strategy=="module_local_fixed_support_rls"
                error('retrain_online_model_after_trigger:PNCRequiresLayer2Updater', ...
                    ['PNC-SINDy cannot use module_local_fixed_support_rls. ', ...
                     'Use method_specific_fast_update or pnc_layer2_prior_centered_stlsq.']);
            end
            [candidateModel,localInfo] = update_local_pnc_second_layer_stlsq( ...
                initialModel,offlineData,onlineData,method,cfg);
        else
            if strategy=="pnc_layer2_prior_centered_stlsq"
                error('retrain_online_model_after_trigger:PNCStrategyOnFlatSINDy', ...
                    'pnc_layer2_prior_centered_stlsq is reserved for PNC-SINDy.');
            end
            [candidateModel,localInfo] = update_local_sindy_module_fixed_support_rls( ...
                initialModel,offlineData,onlineData,method,cfg);
        end
        trainTime = toc(trainTimer);
        effectiveDataEndTime = detector.triggerTime;
        if isfield(dataInfo,'effectiveDataEndTime') && isfinite(dataInfo.effectiveDataEndTime)
            effectiveDataEndTime = dataInfo.effectiveDataEndTime;
        end
    end

    update.trainingCompleted = true;
    update.trainingTimeSeconds = trainTime;
    update.dataInfo = dataInfo;
    update.localUpdateInfo = localInfo;
    update.candidateModel = candidateModel;
    update.updatedTrainInfo = localInfo;
    if isfield(localInfo,'strategy') && ~isempty(localInfo.strategy)
        update.strategy = char(string(localInfo.strategy));
    elseif isMKBF
        update.strategy = 'causal_mkbf_generator_retrain';
    end

    delay = max(double(cfg.online.update.minimumTrainingDelaySeconds), ...
        double(cfg.online.update.trainingDelayScale)*trainTime);
    update.trainingDataEndTime = effectiveDataEndTime;
    update.sampleAccumulationDelaySeconds = max(0,effectiveDataEndTime-detector.triggerTime);
    update.candidateReadyTime = effectiveDataEndTime + delay;

    validation = validate_online_candidate_module( ...
        initialModel,candidateModel,update.candidateReadyTime,detector,method, ...
        observations,cNominal,layout,cfg);
    update.validation = validation;
    update.candidateAccepted = logical(validation.accepted);

    if update.candidateAccepted
        update.updatedModel = candidateModel;
        update.activationTime = validation.activationTime;
        update.activatedWithinHorizon = isfinite(update.activationTime) && ...
            update.activationTime < observations.t(end)-1e-12;
    else
        update.updatedModel = [];
        update.activationTime = inf;
        update.activatedWithinHorizon = false;
    end
catch ME
    update.failureMessage = string(ME.message);
    update.failureIdentifier = string(ME.identifier);
    if ~isempty(ME.stack)
        update.failureLocation = string(sprintf('%s:%d',ME.stack(1).name,ME.stack(1).line));
    else
        update.failureLocation = "";
    end
end
end

function [idx,effectiveDataEndTime,info] = select_causal_online_samples_local(observations,triggerTime,cfg)
U=cfg.online.update;
t=observations.t(:);
startTime=t(1);
if isfinite(U.historyWindowSeconds)
    startTime=max(startTime,triggerTime-double(U.historyWindowSeconds));
end
step=double(U.sampleStep);
if numel(t)>1, dtSaved=median(diff(t)); else, dtSaved=step; end
tol=max(1e-9,0.25*abs(dtSaved));
candidateAll=find(t>=startTime-1e-12);
if isempty(candidateAll)
    error('retrain_online_model_after_trigger:NoOnlineSamples','No causal online samples remain.');
end
t0=t(candidateAll(1));
phaseAll=round((t(candidateAll)-t0)/step);
targetAll=t0+phaseAll*step;
gridIdx=candidateAll(abs(t(candidateAll)-targetAll)<=tol);
idx=gridIdx(t(gridIdx)<=triggerTime+1e-12);
waitForMinimum=true;
if isfield(U,'waitForMinimumSamples'), waitForMinimum=logical(U.waitForMinimumSamples); end
if numel(idx)<U.minimumOnlineSamples
    if ~waitForMinimum || numel(gridIdx)<U.minimumOnlineSamples
        error('retrain_online_model_after_trigger:TooFewOnlineSamples', ...
            'Insufficient causal samples for online retraining.');
    end
    idx=gridIdx(1:U.minimumOnlineSamples);
end
effectiveDataEndTime=t(idx(end));
info=struct();
info.uniqueSampleIndices=idx(:);
info.uniqueSampleTimes=t(idx);
info.timeRange=[t(idx(1)) t(idx(end))];
info.sampleStep=step;
info.requestedTriggerTime=triggerTime;
info.effectiveDataEndTime=effectiveDataEndTime;
info.sampleAccumulationDelaySeconds=max(0,effectiveDataEndTime-triggerTime);
info.waitedForMinimumSamples=info.sampleAccumulationDelaySeconds>1e-12;
end

function aug = append_online_block_local(base,observations,idx,effectiveDataEndTime)
idx=idx(:);
nBase=size(base.x,1);
nOnline=numel(idx);
aug=base;
aug.x=[base.x; observations.x(:,idx).'];
if isfield(base,'z')
    if isfield(observations,'z') && ~isempty(observations.z)
        aug.z=[base.z; observations.z(:,idx).'];
    else
        aug.z=[base.z; zeros(nOnline,size(base.z,2))];
    end
end
aug.V=[base.V; observations.V(:,idx).'];
aug.labelsClean=[base.labelsClean; observations.xdotClean(:,idx).'];
aug.labels=[base.labels; observations.xdotObserved(:,idx).'];
if isfield(base,'features')
    aug.features=[base.features; zeros(nOnline,size(base.features,2))];
end
K0=base.trajectories.nTrajectories;
onlineTrajectoryId=K0+1;
aug.trajectoryId=[base.trajectoryId(:); repmat(onlineTrajectoryId,nOnline,1)];
aug.pointInTrajectory=[base.pointInTrajectory(:); (1:nOnline).'];
aug.sampleInputByRow=cell(nBase+nOnline,1);
if isfield(base,'sampleInputByRow') && numel(base.sampleInputByRow)==nBase
    aug.sampleInputByRow(1:nBase)=base.sampleInputByRow(:);
else
    for i=1:nBase
        aug.sampleInputByRow{i}=base.trajectories.uByTrajectory{base.trajectoryId(i)};
    end
end
for j=1:nOnline
    aug.sampleInputByRow{nBase+j}=online_input_at_observation(observations,idx(j));
end
aug.xObservedFlat=aug.x;
if isfield(base.trajectories,'forceTrainingMask') && ~isempty(base.trajectories.forceTrainingMask)
    aug.trajectories.forceTrainingMask=[logical(base.trajectories.forceTrainingMask(:)); true];
else
    aug.trajectories.forceTrainingMask=[false(K0,1); true];
end
aug.trajectories.nTrajectories=K0+1;
aug.trajectories.uByTrajectory{K0+1,1}=online_input_at_observation(observations,idx(end));
if isfield(base.trajectories,'sourceType')
    aug.trajectories.sourceType=[string(base.trajectories.sourceType(:)); "online_observation_block"];
end
if isfield(base.trajectories,'isTestInitialAnchor')
    aug.trajectories.isTestInitialAnchor=[logical(base.trajectories.isTestInitialAnchor(:)); false];
end
if isfield(base.trajectories,'initialSobolCoordinates')
    aug.trajectories.initialSobolCoordinates=[base.trajectories.initialSobolCoordinates; ...
        nan(1,size(base.trajectories.initialSobolCoordinates,2))];
end
aug.metadata.onlineAugmented=true;
aug.metadata.offlineSampleCount=nBase;
aug.metadata.onlineUniqueSampleCount=nOnline;
aug.metadata.onlineTriggerTime=effectiveDataEndTime;
end

function U = empty_update_local()
U=struct();
U.triggered=false;
U.triggerTime=NaN;
U.trainingStarted=false;
U.trainingCompleted=false;
U.trainingTimeSeconds=NaN;
U.dataPreparationTimeSeconds=NaN;
U.candidateReadyTime=inf;
U.trainingDataEndTime=NaN;
U.sampleAccumulationDelaySeconds=0;
U.candidateAccepted=false;
U.activationTime=inf;
U.activatedWithinHorizon=false;
U.candidateModel=[];
U.updatedModel=[];
U.updatedTrainInfo=struct();
U.dataInfo=struct();
U.localUpdateInfo=struct();
U.validation=struct();
U.affectedModuleLabel="";
U.affectedDeviceType='';
U.affectedDeviceIndex=NaN;
U.affectedStateIndices=zeros(0,1);
U.strategy='';
U.failureMessage="";
U.failureIdentifier="";
U.failureLocation="";
end
