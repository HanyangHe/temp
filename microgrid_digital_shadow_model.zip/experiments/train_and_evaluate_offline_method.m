function evaluation = train_and_evaluate_offline_method(method,dataset,truth,c,layout,cfg)
%TRAIN_AND_EVALUATE_OFFLINE_METHOD Train one method and simulate test scenario.
%
% Model training errors are still allowed to surface because they generally
% indicate a code/configuration problem. In contrast, an inability of a
% trained model to complete the physical rollout is treated as a legitimate
% model-performance outcome. Such a case is returned with explicit FAILED
% status and NaN whole-window trajectory metrics so the remaining sweep can
% continue.

trainStart = tic;
[model,trainInfo] = method.trainFcn(dataset,c,layout,cfg);
trainTime = toc(trainStart);

prediction = simulate_offline_model_scenario(model,method,truth,c,layout,cfg);
varNames = get_dae_variable_names(c,layout);

if isfield(prediction,'metadata') && ...
        isfield(prediction.metadata,'rolloutSucceeded') && ...
        prediction.metadata.rolloutSucceeded && ...
        isequal(size(truth.y),size(prediction.y))
    [metrics,perVariable] = compute_trajectory_error_metrics( ...
        truth.y,prediction.y,varNames,cfg);
else
    [metrics,perVariable] = failed_metric_placeholders(varNames);
end

evaluation.method = method;
evaluation.model = model;
evaluation.trainInfo = trainInfo;
evaluation.trainingTimeSeconds = trainTime;
evaluation.prediction = prediction;
evaluation.metrics = metrics;
evaluation.perVariableMetrics = strip_nrmse_report_data(perVariable);
evaluation.rolloutSucceeded = prediction.metadata.rolloutSucceeded;
evaluation.rolloutStatus = prediction.metadata.rolloutStatus;
evaluation.failureTimeSeconds = prediction.metadata.failureTimeSeconds;
evaluation.trajectoryCoveragePercent = prediction.metadata.trajectoryCoveragePercent;
evaluation.failureMessage = prediction.metadata.failureMessage;
end

function [summary,perVariable] = failed_metric_placeholders(varNames)
% Whole-scenario metrics are undefined when the requested horizon is not
% completed. Do not disguise a partial-trajectory metric as a full-scenario
% metric: use NaN and report failure time/coverage separately.
metricNames = {'RMSE','MAE','MaxAE','NRMSE_Range','NRMSE_RMS','NRMSE_Std', ...
    'NMaxAE_Range','MAPE_percent','sMAPE_percent','MAPE_valid_fraction','MeanR2'};
summary = struct();
for k = 1:numel(metricNames)
    summary.(metricNames{k}) = NaN;
end

n = numel(varNames);
nanCol = nan(n,1);
perVariable = table(string(varNames(:)),nanCol,nanCol,nanCol,nanCol, ...
    nanCol,nanCol,nanCol,nanCol, ...
    'VariableNames',{'Variable','RMSE','MAE','MaxAE','NMaxAE_Range', ...
    'MAPE_percent','sMAPE_percent','MAPE_valid_fraction','R2'});
end
