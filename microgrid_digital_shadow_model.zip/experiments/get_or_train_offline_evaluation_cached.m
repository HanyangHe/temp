function [evaluation,cache,reused,cacheKey,sourceRequest] = ...
    get_or_train_offline_evaluation_cached(cache,method,dataset,truth,c,layout,cfg, ...
    N,noiseLevel,requestTag,outRoot)
%GET_OR_TRAIN_OFFLINE_EVALUATION_CACHED Reuse identical experiment conditions.
%
% Runtime reuse key:
%   method + sample count N + training-noise level + data/noise protocol
%
% Each newly trained unique evaluation is checkpointed immediately. For NODE,
% the complete persistent evaluation remains on disk while the long-running
% experiment keeps only a compact report-facing copy in RAM. This prevents a
% many-condition NODE campaign from accumulating full model/trajectory payloads.

if nargin < 10 || isempty(requestTag)
    requestTag = "unspecified";
end
if nargin < 11
    outRoot = '';
end
requestTag = string(requestTag);

if isempty(cache) || ~isstruct(cache) || ~isfield(cache,'entries')
    cache = initialize_cache();
end

baseKey = make_offline_evaluation_cache_key(method,N,noiseLevel,cfg,dataset);
reuseEnabled = true;
if isfield(cfg,'reuse') && isfield(cfg.reuse,'identicalConditionsWithinRun')
    reuseEnabled = logical(cfg.reuse.identicalConditionsWithinRun);
end

idx = [];
if reuseEnabled && ~isempty(cache.entries)
    keys = string({cache.entries.key});
    idx = find(keys == string(baseKey),1,'first');
end

if ~isempty(idx)
    evaluation = cache.entries(idx).evaluation;
    reused = true;
    sourceRequest = string(cache.entries(idx).firstRequest);
    cacheKey = string(cache.entries(idx).key);
    cache.entries(idx).requestCount = cache.entries(idx).requestCount + 1;
    cache.entries(idx).requests(end+1,1) = requestTag;
    fprintf(['  Reusing existing evaluation: %s | N=%d | noise=%.6g%% ', ...
        '(first computed for %s).\n'],char(string(method.displayName)),N,100*noiseLevel,char(sourceRequest));
    return;
end

fprintf('  Training/evaluating %s | N=%d | noise=%.6g%% ...\n', ...
    char(string(method.displayName)),N,100*noiseLevel);
evaluation = train_and_evaluate_offline_method(method,dataset,truth,c,layout,cfg);
reused = false;
sourceRequest = requestTag;

cacheKey = string(baseKey);
if ~reuseEnabled
    cacheKey = cacheKey + "|instance=" + string(numel(cache.entries)+1);
end

% Persist the FULL completed evaluation before any RAM compaction.
checkpointPath = '';
checkpointSaved = false;
if ~isempty(outRoot) && should_save_evaluation_cache(cfg)
    cacheDir = fullfile(outRoot,get_method_results_folder(cfg), ...
        char(string(method.name)),get_evaluation_cache_folder(cfg));
    if ~exist(cacheDir,'dir'), mkdir(cacheDir); end
    fileTag = condition_file_tag(method,N,noiseLevel,dataset);
    savedEvaluation = sanitize_offline_evaluation_for_save(evaluation); %#ok<NASGU>
    condition = struct('cacheKey',char(cacheKey), ...
        'methodName',char(string(method.name)), ...
        'displayName',char(string(method.displayName)), ...
        'sampleCount',N,'noiseLevel',noiseLevel,'noisePercent',100*noiseLevel, ...
        'dataProtocol',char(offline_method_data_protocol(dataset,method)), ...
        'firstRequest',char(requestTag)); %#ok<NASGU>
    checkpointPath = fullfile(cacheDir,[fileTag '.mat']);
    checkpointSaved = save_evaluation_checkpoint_atomic( ...
        checkpointPath,savedEvaluation,condition);

    if checkpointSaved && isfield(savedEvaluation,'perVariableMetrics') && ...
            istable(savedEvaluation.perVariableMetrics)
        try
            reportMetrics = strip_nrmse_report_data(savedEvaluation.perVariableMetrics);
            writetable(reportMetrics, ...
                fullfile(cacheDir,[fileTag '_per_variable_metrics.csv']));
        catch MEcsv
            warning('get_or_train_offline_evaluation_cached:MetricCSVWriteFailed', ...
                'Could not write per-variable CSV for %s (%s). Continuing.', ...
                fileTag,MEcsv.message);
        end
    end
end

entry = struct();
entry.key = char(cacheKey);
entry.methodName = char(string(method.name));
entry.displayName = char(string(method.displayName));
entry.sampleCount = N;
entry.noiseLevel = noiseLevel;
entry.firstRequest = char(requestTag);
entry.requests = requestTag;
entry.requestCount = 1;
entry.checkpointPath = checkpointPath;
entry.evaluationStoredOnDisk = logical(checkpointSaved);

% Compact NODE only after a verified full checkpoint exists. If checkpointing
% is disabled/failed, retain the complete evaluation in RAM so persistence is
% never weakened merely to save memory.
if checkpointSaved
    cachedEvaluation = compact_offline_evaluation_for_memory(evaluation,cfg);
else
    cachedEvaluation = evaluation;
end
entry.evaluationIsCompact = isfield(cachedEvaluation,'memoryCompacted') && ...
    logical(cachedEvaluation.memoryCompacted);
entry.evaluation = cachedEvaluation;
cache.entries = append_cache_entry_schema_safe(cache.entries,entry);
end

function entries = append_cache_entry_schema_safe(entries,entry)
%APPEND_CACHE_ENTRY_SCHEMA_SAFE Append even if a caller used an older cache schema.
%
% The NODE memory patch added checkpoint bookkeeping fields to each cache
% entry. Some runners/tests can still construct the legacy empty schema.
% MATLAB indexed struct assignment then fails with "Subscripted assignment
% between dissimilar structures". Align fields here so the cache helper is
% backward-compatible with both schemas.

if isempty(entries)
    entries = reshape(entry,[],1);
    return;
end

entryFields = fieldnames(entry);
for i = 1:numel(entryFields)
    f = entryFields{i};
    if ~isfield(entries,f)
        [entries.(f)] = deal([]);
    end
end

cacheFields = fieldnames(entries);
for i = 1:numel(cacheFields)
    f = cacheFields{i};
    if ~isfield(entry,f)
        entry.(f) = [];
    end
end

entry = orderfields(entry,entries);
entries(end+1,1) = entry;
end

function cache = initialize_cache()
cache = struct();
cache.entries = struct('key',{},'methodName',{},'displayName',{}, ...
    'sampleCount',{},'noiseLevel',{},'firstRequest',{},'requests',{}, ...
    'requestCount',{},'checkpointPath',{},'evaluationStoredOnDisk',{}, ...
    'evaluationIsCompact',{},'evaluation',{});
end

function tf = should_save_evaluation_cache(cfg)
tf = true;
if isfield(cfg,'output') && isfield(cfg.output,'saveEvaluationCache')
    tf = logical(cfg.output.saveEvaluationCache);
end
end


function folder = get_method_results_folder(cfg)
folder = 'method_results';
if isfield(cfg,'output') && isfield(cfg.output,'methodResultsFolder') && ...
        ~isempty(cfg.output.methodResultsFolder)
    folder = char(string(cfg.output.methodResultsFolder));
end
end

function folder = get_evaluation_cache_folder(cfg)
folder = 'evaluation_cache';
if isfield(cfg,'output') && isfield(cfg.output,'evaluationCacheFolder') && ...
        ~isempty(cfg.output.evaluationCacheFolder)
    folder = char(string(cfg.output.evaluationCacheFolder));
end
end


function ok = save_evaluation_checkpoint_atomic(targetMat,savedEvaluation,condition)
%SAVE_EVALUATION_CHECKPOINT_ATOMIC Robust long-path-safe checkpoint write.
%
% Build and validate the v7.3/HDF5 MAT file on a short temporary pathname,
% then copy the verified bytes to the official destination. The installed
% file is verified again through the project's long-path-safe loader.
%
% Failure remains nonfatal: the caller simply keeps the full evaluation in
% RAM and the long experiment continues without memory compaction.

ok = false;
targetDir = fileparts(targetMat);
if ~exist(targetDir,'dir'), mkdir(targetDir); end
tmpMat = make_hdf5_safe_temp_mat_path(targetMat);
cleanupObj = onCleanup(@()delete_temp_checkpoint_local(tmpMat));

try
    save(tmpMat,'savedEvaluation','condition','-v7.3');

    probe = whos('-file',tmpMat);
    probeNames = string({probe.name});
    if ~all(ismember(["savedEvaluation","condition"],probeNames))
        error('get_or_train_offline_evaluation_cached:CheckpointValidation', ...
            'Temporary checkpoint did not contain the expected variables.');
    end

    [copyOk,msg] = copyfile(tmpMat,targetMat,'f');
    if ~copyOk
        error('get_or_train_offline_evaluation_cached:CheckpointCopyFailed', ...
            'Could not install evaluation checkpoint: %s',msg);
    end

    installed = load_mat_long_path_safe(targetMat,'savedEvaluation','condition');
    if ~isfield(installed,'savedEvaluation') || ~isfield(installed,'condition')
        error('get_or_train_offline_evaluation_cached:CheckpointInstallValidation', ...
            'Installed checkpoint did not contain the expected variables.');
    end
    ok = true;
catch ME
    warning('get_or_train_offline_evaluation_cached:CheckpointSaveFailed', ...
        ['Evaluation completed but its immediate cache checkpoint could not ', ...
         'be written to\n  %s\nReason: %s\nThe experiment will continue ', ...
         'without compacting this evaluation in RAM.'],targetMat,ME.message);
end

clear cleanupObj;
delete_temp_checkpoint_local(tmpMat);
end


function delete_temp_checkpoint_local(filePath)
if exist(filePath,'file') == 2
    try, delete(filePath); catch, end %#ok<CTCH>
end
end


function tag = condition_file_tag(method,N,noiseLevel,dataset)
noiseText = sprintf('%.12g',100*noiseLevel);
noiseText = strrep(noiseText,'-','m');
noiseText = strrep(noiseText,'+','p');
noiseText = strrep(noiseText,'.','p');
protocol = regexprep(char(offline_method_data_protocol(dataset,method)),'[^A-Za-z0-9_\-]','_');
tag = sprintf('%s_N%d_noise%spct_%s', ...
    char(string(method.name)),N,noiseText,protocol);
tag = regexprep(tag,'[^A-Za-z0-9_\-]','_');
end
