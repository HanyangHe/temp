function detector = detect_online_model_mismatch( ...
    model,method,observations,cNominal,layout,cfg,offlineScale,baseDataset)
%DETECT_ONLINE_MODEL_MISMATCH Module-wise causal vector-field mismatch detector.
%
% A separate normalized vector-field residual is maintained for every SG/GFM/
% GFL module. The first module whose rolling residual persistently crosses its
% own threshold is localized as the affected module. Optional threshold
% calibration uses the saved nominal model on its original offline validation
% trajectories so known baseline residual is not mistaken for new mismatch.

opt = cfg.online.update.detector;
if ~strcmpi(string(opt.metric),'module_rolling_vector_field_nrmse')
    error('detect_online_model_mismatch:Metric', ...
        'Supported detector metric is module_rolling_vector_field_nrmse.');
end

t = observations.t(:);
nt = numel(t);
scale = double(offlineScale(:));
if numel(scale) ~= layout.nx
    error('detect_online_model_mismatch:ScaleDimension', ...
        'offlineScale must contain one value per differential state.');
end
scale = max(abs(scale),double(opt.scaleFloor));

modules = build_module_descriptors(cNominal,layout);
nMod = numel(modules);
baseThreshold = double(opt.threshold);
moduleThreshold = repmat(baseThreshold,nMod,1);
baselineQuantileScore = nan(nMod,1);

% Multi-stage online correction must keep the original nominal calibration
% fixed after the first accepted update. Recalibrating an already-adapted
% model on the OLD nominal offline data would artificially inflate the
% threshold and could suppress detection of a later parameter change.
if isfield(opt,'fixedModuleThresholds') && ~isempty(opt.fixedModuleThresholds)
    fixed = double(opt.fixedModuleThresholds(:));
    if numel(fixed) ~= nMod || any(~isfinite(fixed)) || any(fixed<=0)
        error('detect_online_model_mismatch:FixedThresholdDimension', ...
            'fixedModuleThresholds must contain one positive finite value per physical module.');
    end
    moduleThreshold = fixed;
    baselineScores = [];
elseif isfield(opt,'calibrateFromOffline') && opt.calibrateFromOffline && ...
        nargin>=8 && ~isempty(baseDataset)
    baselineScores = offline_module_scores( ...
        model,method,baseDataset,cNominal,layout,scale,modules);
    qLevel = double(opt.baselineQuantile);
    multiplier = double(opt.baselineMultiplier);
    for m=1:nMod
        q = empirical_quantile(baselineScores(:,m),qLevel);
        baselineQuantileScore(m)=q;
        if isfinite(q)
            moduleThreshold(m)=max(baseThreshold,multiplier*q);
        end
    end
else
    baselineScores = [];
end

instant = nan(nt,nMod);
rolling = nan(nt,nMod);
ratio = nan(nt,nMod);
globalInstant = nan(nt,1);
globalRolling = nan(nt,1);
maxRatio = nan(nt,1);
consecutive = zeros(nMod,1);
triggered = false;
triggerIndex = NaN;
triggerTime = NaN;
triggerModule = NaN;
windowSeconds = double(opt.windowSeconds);
minimumTriggerTime = double(opt.minimumTriggerTime);
requiredConsecutive = max(1,round(double(opt.requiredConsecutiveWindows)));

for k=1:nt
    fhat = [];
    try
        u = online_input_at_observation(observations,k);
        fhat = method.predictFcn(model,t(k),observations.x(:,k), ...
            observations.V(:,k),u,cNominal,layout);
        rAll = (observations.xdotObserved(:,k)-fhat(:))./scale;
        globalInstant(k)=sqrt(mean(rAll.^2));
        for m=1:nMod
            idx = modules(m).stateIndices;
            instant(k,m)=sqrt(mean(rAll(idx).^2));
        end
    catch
        globalInstant(k)=inf;
        instant(k,:)=inf;
    end

    first = find(t >= t(k)-windowSeconds,1,'first');
    globalRolling(k)=rolling_rms(globalInstant(first:k));
    for m=1:nMod
        rolling(k,m)=rolling_rms(instant(first:k,m));
        ratio(k,m)=rolling(k,m)/moduleThreshold(m);
    end
    maxRatio(k)=max(ratio(k,:));

    if ~triggered && t(k)>=minimumTriggerTime
        above = ratio(k,:)>1;
        consecutive(above)=consecutive(above)+1;
        consecutive(~above)=0;
        eligible = find(consecutive>=requiredConsecutive);
        if ~isempty(eligible)
            [~,loc]=max(ratio(k,eligible));
            triggerModule=eligible(loc);
            triggerIndex=k;
            triggerTime=t(k);
            triggered=true;
        end
    end
end

% Wide detector table: one row per online observation and one rolling-score
% column per physical DER module. Thresholds are stored as constant columns so
% replay/debugging remains self contained.
T = table(t,globalInstant,globalRolling,maxRatio, ...
    'VariableNames',{'Time_s','GlobalInstantaneousScore','GlobalRollingScore', ...
    'MaxModuleTriggerRatio'});
for m=1:nMod
    suffix = matlab.lang.makeValidName(modules(m).label);
    T.(['Instant_' suffix]) = instant(:,m);
    T.(['Rolling_' suffix]) = rolling(:,m);
    T.(['Threshold_' suffix]) = repmat(moduleThreshold(m),nt,1);
end

detector = struct();
detector.metric = char(string(opt.metric));
detector.time = t;
detector.instantaneousScore = globalInstant;
detector.rollingScore = globalRolling;
detector.moduleInstantaneousScore = instant;
detector.moduleRollingScore = rolling;
detector.moduleTriggerRatio = ratio;
detector.maxModuleTriggerRatio = maxRatio;
detector.moduleThresholds = moduleThreshold;
detector.baseThreshold = baseThreshold;
detector.baselineQuantileScore = baselineQuantileScore;
detector.baselineCalibrationScores = baselineScores;
detector.moduleLabels = string({modules.label}).';
detector.moduleDeviceTypes = string({modules.deviceType}).';
detector.moduleDeviceIndices = [modules.deviceIndex].';
detector.windowSeconds = windowSeconds;
detector.minimumTriggerTime = minimumTriggerTime;
detector.requiredConsecutiveWindows = requiredConsecutive;
detector.triggered = triggered;
detector.triggerIndex = triggerIndex;
detector.triggerTime = triggerTime;
detector.triggerModuleIndex = triggerModule;
detector.normalizationScale = scale;
detector.table = T;

if triggered
    d = modules(triggerModule);
    detector.affectedModuleLabel = string(d.label);
    detector.affectedDeviceType = char(d.deviceType);
    detector.affectedDeviceIndex = d.deviceIndex;
    detector.affectedStateIndices = d.stateIndices(:);
    detector.triggerModuleThreshold = moduleThreshold(triggerModule);
    detector.triggerModuleRollingScore = rolling(triggerIndex,triggerModule);
    detector.triggerModuleRatio = ratio(triggerIndex,triggerModule);
else
    detector.affectedModuleLabel = "";
    detector.affectedDeviceType = '';
    detector.affectedDeviceIndex = NaN;
    detector.affectedStateIndices = zeros(0,1);
    detector.triggerModuleThreshold = NaN;
    detector.triggerModuleRollingScore = NaN;
    detector.triggerModuleRatio = NaN;
end
end

function modules = build_module_descriptors(c,layout)
modules = struct('label',{},'deviceType',{},'deviceIndex',{},'stateIndices',{});
for k=1:numel(c.sg)
    modules(end+1)=entry('sg',k,layout.sg{k}); %#ok<AGROW>
end
for k=1:numel(c.gfm)
    modules(end+1)=entry('gfm',k,layout.gfm{k}); %#ok<AGROW>
end
for k=1:numel(c.gfl)
    modules(end+1)=entry('gfl',k,layout.gfl{k}); %#ok<AGROW>
end
    function d=entry(type,k,idx)
        d=struct('label',sprintf('%s%d',upper(type),k), ...
            'deviceType',type,'deviceIndex',k,'stateIndices',idx(:));
    end
end

function scores = offline_module_scores(model,method,D,c,layout,scale,modules)
N = size(D.x,1);
scores = nan(N,numel(modules));
mask = true(N,1);
if isfield(model,'validationTrajectoryIds') && ~isempty(model.validationTrajectoryIds) && ...
        isfield(D,'trajectoryId')
    mask = ismember(D.trajectoryId(:),model.validationTrajectoryIds(:));
    if nnz(mask)<10, mask=true(N,1); end
end
rows=find(mask);
for ii=1:numel(rows)
    i=rows(ii);
    try
        u = offline_input_at_row(D,i);
        fhat = method.predictFcn(model,0,D.x(i,:).',D.V(i,:).',u,c,layout);
        r = (D.labels(i,:).'-fhat(:))./scale;
        for m=1:numel(modules)
            idx=modules(m).stateIndices;
            scores(i,m)=sqrt(mean(r(idx).^2));
        end
    catch
        scores(i,:)=inf;
    end
end
end

function u = offline_input_at_row(D,i)
if isfield(D,'sampleInputByRow') && numel(D.sampleInputByRow)>=i && ...
        ~isempty(D.sampleInputByRow{i})
    u=D.sampleInputByRow{i};
    return;
end
tr=D.trajectoryId(i);
u=D.trajectories.uByTrajectory{tr};
end

function q = empirical_quantile(v,p)
v=v(isfinite(v));
if isempty(v)
    q=NaN;
    return;
end
v=sort(v(:));
p=min(max(p,0),1);
pos=1+(numel(v)-1)*p;
lo=floor(pos); hi=ceil(pos);
if lo==hi
    q=v(lo);
else
    a=pos-lo;
    q=(1-a)*v(lo)+a*v(hi);
end
end

function value = rolling_rms(v)
if any(isinf(v))
    value=inf;
    return;
end
v=v(isfinite(v));
if isempty(v)
    value=inf;
else
    value=sqrt(mean(v.^2));
end
end
