function d = subset_offline_dataset(dataset,N)
%SUBSET_OFFLINE_DATASET Return nested first-N samples as complete trajectories.
%
% v1p7d keeps trajectory 1 as the test-initial anchor (when enabled), so
% every nested sample-size subset retains the same anchor while increasing
% only the number of Sobol-started trajectories.

L = dataset.trajectories.pointsPerTrajectory;
if mod(N,L) ~= 0
    error('subset_offline_dataset:WholeTrajectories', ...
        'N=%d must be divisible by pointsPerTrajectory=%d.',N,L);
end
if N > size(dataset.features,1)
    error('subset_offline_dataset:SampleCount', ...
        'Requested N=%d but dataset contains only %d samples.',N,size(dataset.features,1));
end
K = N/L;
idx = 1:N;

d = dataset;
d.features = dataset.features(idx,:);
d.labelsClean = dataset.labelsClean(idx,:);
d.labels = dataset.labels(idx,:);
d.x = dataset.x(idx,:);
d.z = dataset.z(idx,:);
d.V = dataset.V(idx,:);
d.trajectoryId = dataset.trajectoryId(idx);
d.pointInTrajectory = dataset.pointInTrajectory(idx);

d.trajectories.xClean = dataset.trajectories.xClean(:,1:K,:);
d.trajectories.xObserved = dataset.trajectories.xObserved(:,1:K,:);
d.trajectories.V = dataset.trajectories.V(:,1:K,:);
d.trajectories.labelsClean = dataset.trajectories.labelsClean(:,1:K,:);
d.trajectories.labels = dataset.trajectories.labels(:,1:K,:);
d.trajectories.features = dataset.trajectories.features(:,1:K,:);
d.trajectories.uByTrajectory = dataset.trajectories.uByTrajectory(1:K);
d.trajectories.initialSobolCoordinates = ...
    dataset.trajectories.initialSobolCoordinates(1:K,:);
if isfield(dataset.trajectories,'sourceType')
    d.trajectories.sourceType = dataset.trajectories.sourceType(1:K);
end
if isfield(dataset.trajectories,'isTestInitialAnchor')
    d.trajectories.isTestInitialAnchor = ...
        dataset.trajectories.isTestInitialAnchor(1:K);
end
if isfield(dataset.trajectories,'forceTrainingMask')
    d.trajectories.forceTrainingMask = ...
        dataset.trajectories.forceTrainingMask(1:K);
end
d.trajectories.nTrajectories = K;

d.metadata.N = N;
d.metadata.nTrajectories = K;
if isfield(d.trajectories,'isTestInitialAnchor')
    nAnchor = sum(d.trajectories.isTestInitialAnchor);
    d.metadata.nSobolTrajectories = K - nAnchor;
    if isfield(d.metadata,'testInitialAnchor')
        d.metadata.testInitialAnchor.includedInThisSubset = (nAnchor > 0);
    end
end
end
