function [segment,info] = simulate_offline_training_segment(x0,V0,uFixed,pNom,c,layout,cfg)
%SIMULATE_OFFLINE_TRAINING_SEGMENT Generate one clean short truth trajectory.

L = cfg.data.pointsPerTrajectory;
dt = cfg.data.trajectorySampleStep;
t = (0:L-1).'*dt;
ns = c.network.nonSlackBuses(:);

y0 = [x0(:); real(V0(ns)); imag(V0(ns))];
[f0,g0] = mg_evaluate_physics(x0,V0,uFixed,pNom,c,layout);
if norm(g0,inf) > cfg.data.acceptAlgebraicResidualInf
    segment = struct();
    info.success = false;
    info.reason = 'Initial algebraic residual exceeds acceptance threshold.';
    return;
end
yp0 = [f0(:); zeros(layout.nvAlg,1)];

residual = @(tt,y,yp)offline_fixed_input_truth_dae_residual( ...
    tt,y,yp,uFixed,pNom,c,layout);
opts = odeset('RelTol',cfg.data.truthSegment.RelTol, ...
              'AbsTol',cfg.data.truthSegment.AbsTol, ...
              'MaxStep',cfg.data.truthSegment.MaxStep, ...
              'Stats','off');

lastwarn('');
try
    [tout,y] = ode15i(residual,t,y0,yp0,opts);
    [warnMsg,warnID] = lastwarn;
catch ME
    segment = struct();
    info.success = false;
    info.reason = sprintf('ODE15I exception: %s',ME.message);
    info.warningID = '';
    return;
end

if numel(tout) ~= L || abs(tout(end)-t(end)) > 1e-10
    segment = struct();
    info.success = false;
    info.reason = sprintf('ODE15I returned only %d/%d requested points.',numel(tout),L);
    info.warningID = warnID;
    return;
end

xStore = zeros(L,layout.nx);
VStore = complex(zeros(L,c.network.N));
fStore = zeros(L,layout.nx);
gInf = zeros(L,1);

for j = 1:L
    [xj,Vj] = mg_unpack_dae_state(y(j,:).',c,layout);
    [fj,gj] = mg_evaluate_physics(xj,Vj,uFixed,pNom,c,layout);
    xStore(j,:) = xj.';
    VStore(j,:) = Vj.';
    fStore(j,:) = fj.';
    gInf(j) = norm(gj,inf);
end

vmag = abs(VStore);
if any(~isfinite(xStore),'all') || any(~isfinite(vmag),'all') || any(~isfinite(fStore),'all')
    segment = struct();
    info.success = false;
    info.reason = 'Non-finite state/voltage/vector-field value in truth segment.';
    info.warningID = warnID;
    return;
end
if min(vmag,[],'all') < cfg.data.acceptVoltageMinPU || ...
        max(vmag,[],'all') > cfg.data.acceptVoltageMaxPU
    segment = struct();
    info.success = false;
    info.reason = 'A voltage magnitude left the accepted training-data range.';
    info.warningID = warnID;
    return;
end
if max(gInf) > cfg.data.acceptAlgebraicResidualInf
    segment = struct();
    info.success = false;
    info.reason = 'Algebraic residual exceeded the accepted training-data threshold.';
    info.warningID = warnID;
    return;
end

segment.t = t;
segment.y = y;
segment.x = xStore;
segment.V = VStore;
segment.labelsClean = fStore;
segment.u = uFixed;
segment.algebraicResidualInf = gInf;

info.success = true;
info.reason = '';
info.warningID = warnID;
info.warningMessage = warnMsg;
info.maxAlgebraicResidualInf = max(gInf);
info.minVoltagePU = min(vmag,[],'all');
info.maxVoltagePU = max(vmag,[],'all');
end
