function result = run_iterative_online_model_correction( ...
    initialModel,baseDataset,observations,truth,method,cNominal,layout,cfg,offlineScale)
%RUN_ITERATIVE_ONLINE_MODEL_CORRECTION Repeated detect-update-activate loop.
%
% The online corrector is re-armed after accepted activations and rejected candidates. Histories
% are stored as cell arrays intentionally: detector/update structs may evolve
% across stages and MATLAB cannot append dissimilar structs into one struct
% array safely.

result = struct();
result.detector = struct();
result.detectorHistory = cell(0,1);
result.update = empty_aggregate_update();
result.updateHistory = cell(0,1);
result.prediction = [];
result.updateLog = strings(0,1);

currentModel = initialModel;
currentStartTime = observations.t(1);
acceptedModels = cell(0,1);
acceptedActivationTimes = zeros(0,1);

% Keep update ATTEMPTS separate from accepted model deployments. A rejected
% candidate must never disable monitoring; it simply leaves currentModel
% unchanged and the detector is re-armed after a short refractory interval.
maxAttempts = getfield_default(cfg.online.update,'maximumUpdateAttempts',10); %#ok<GFLD>
maxAccepted = getfield_default(cfg.online.update,'maximumAcceptedUpdates',4); %#ok<GFLD>
refractorySeconds = getfield_default(cfg.online.update,'refractorySeconds',0.05); %#ok<GFLD>
maxAttempts = max(1,round(double(maxAttempts)));
maxAccepted = max(1,round(double(maxAccepted)));
refractorySeconds = max(0,double(refractorySeconds));

% Controlled external-baseline mode: disable automatic detector timing and
% force one adaptation attempt after each known hidden-parameter jump.  This
% is intentionally an oracle schedule used only to compare the model-update
% capability under identical A+S operations.  Each stage begins exactly at
% the jump time, so the minimum causal sample pool is collected AFTER the
% coefficient change rather than reusing pre-change observations.
scheduledMode = scheduled_update_mode_enabled(cfg);
scheduledTimes = zeros(0,1);
if scheduledMode
    scheduledTimes = scheduled_update_times(cfg,observations);
    if isempty(scheduledTimes)
        error('run_iterative_online_model_correction:ScheduledTimes', ...
            'Scheduled update mode requires at least one valid update time.');
    end
    maxAttempts = min(maxAttempts,numel(scheduledTimes));
    maxAccepted = max(maxAccepted,numel(scheduledTimes));
end

attempt = 0;
acceptedCount = 0;
fixedModuleThresholds = [];

while attempt < maxAttempts && acceptedCount < maxAccepted
    attempt = attempt + 1;
    if scheduledMode
        scheduledTime = scheduledTimes(attempt);
        obsStage = trim_observations(observations,scheduledTime);
    else
        scheduledTime = NaN;
        obsStage = trim_observations(observations,currentStartTime);
    end
    if numel(obsStage.t) < 5
        result.updateLog(end+1) = "  attempt "+attempt+": remaining horizon too short; stop monitoring."; %#ok<AGROW>
        break;
    end

    % Calibrate once using the original nominal model. All later attempts use
    % the same thresholds, including attempts after rejected candidates.
    cfgStage = cfg;
    if attempt>1 && ~isempty(fixedModuleThresholds)
        cfgStage.online.update.detector.fixedModuleThresholds = fixedModuleThresholds;
        cfgStage.online.update.detector.calibrateFromOffline = false;
    end

    detector = detect_online_model_mismatch( ...
        currentModel,method,obsStage,cNominal,layout,cfgStage,offlineScale,baseDataset);
    if attempt==1
        fixedModuleThresholds = detector.moduleThresholds(:);
    end
    if scheduledMode
        detector = force_scheduled_update_detector( ...
            detector,scheduledTime,cfg,cNominal,layout);
    end
    detector.stageIndex = attempt; % retained name for saved-result compatibility
    detector.attemptIndex = attempt;
    detector.acceptedUpdateCountBeforeAttempt = acceptedCount;
    result.detectorHistory{end+1,1} = detector; %#ok<AGROW>

    if ~detector.triggered
        if attempt==1
            result.updateLog(end+1) = "  trigger: NOT reached; online mode remains frozen for this horizon."; %#ok<AGROW>
        else
            result.updateLog(end+1) = "  attempt "+attempt+": no new trigger in the remaining horizon; monitoring finished."; %#ok<AGROW>
        end
        break;
    end

    if scheduledMode
        result.updateLog(end+1) = sprintf([ ...
            '  scheduled A+S update %d/%d: %s coefficient jump at t=%.6f s (automatic trigger disabled)'], ...
            attempt,numel(scheduledTimes),char(detector.affectedModuleLabel),detector.triggerTime); %#ok<AGROW>
    elseif attempt==1
        result.updateLog(end+1) = sprintf([ ...
            '  trigger: %s at t=%.6f s | local rolling score=%.6g > calibrated threshold %.6g (ratio %.3f)'], ...
            char(detector.affectedModuleLabel),detector.triggerTime, ...
            detector.triggerModuleRollingScore,detector.triggerModuleThreshold, ...
            detector.triggerModuleRatio); %#ok<AGROW>
    else
        result.updateLog(end+1) = sprintf([ ...
            '  re-trigger attempt %d: %s at t=%.6f s | local rolling score=%.6g > calibrated threshold %.6g (ratio %.3f)'], ...
            attempt,char(detector.affectedModuleLabel),detector.triggerTime, ...
            detector.triggerModuleRollingScore,detector.triggerModuleThreshold, ...
            detector.triggerModuleRatio); %#ok<AGROW>
    end

    update = retrain_online_model_after_trigger( ...
        currentModel,baseDataset,obsStage,detector,method,cNominal,layout,cfg);
    update.stageIndex = attempt; % retained for compatibility
    update.attemptIndex = attempt;
    update.acceptedUpdateIndex = NaN;
    result.updateHistory{end+1,1} = update; %#ok<AGROW>

    if update.trainingCompleted
        result.updateLog(end+1) = sprintf([ ...
            '  local update attempt %d: %s | compute %.4f s | causal samples=%d | data ready t=%.6f | candidate ready t=%.6f'], ...
            attempt,char(update.affectedModuleLabel),update.trainingTimeSeconds, ...
            getfield_default(update.dataInfo,'onlineUsedSampleCount',0), ...
            getfield_default(update,'trainingDataEndTime',detector.triggerTime), ...
            update.candidateReadyTime); %#ok<GFLD,AGROW>
        if getfield_default(update,'sampleAccumulationDelaySeconds',0)>1e-12 %#ok<GFLD>
            result.updateLog(end+1) = sprintf( ...
                '  causal sample wait attempt %d: %.4f s after trigger before coefficient update.', ...
                attempt,getfield_default(update,'sampleAccumulationDelaySeconds',0)); %#ok<GFLD,AGROW>
        end
        if update.candidateAccepted
            acceptedCount = acceptedCount + 1;
            update.acceptedUpdateIndex = acceptedCount;
            result.updateHistory{end,1} = update;
            v = update.validation;
            result.updateLog(end+1) = sprintf([ ...
                '  candidate validation attempt %d: PASS | accepted update %d | old=%.6g | new=%.6g | improvement=%.2f%% | activation t=%.6f'], ...
                attempt,acceptedCount,v.currentModelScore,v.candidateModelScore, ...
                100*v.relativeImprovement,update.activationTime); %#ok<AGROW>
        else
            reason = string(getfield_default(update.validation,'reason','not_evaluated')); %#ok<GFLD>
            result.updateLog(end+1) = "  candidate validation attempt "+attempt+": REJECT ("+reason+"); keep current model and continue monitoring."; %#ok<AGROW>
        end
    else
        result.updateLog(end+1) = "  local online update attempt "+attempt+" FAILED; keep current model and continue monitoring."; %#ok<AGROW>
        if strlength(update.failureMessage)>0
            result.updateLog(end+1) = "  update failure: "+update.failureMessage; %#ok<AGROW>
        end
        if isfield(update,'failureLocation') && strlength(string(update.failureLocation))>0
            result.updateLog(end+1) = "  update failure location: "+string(update.failureLocation); %#ok<AGROW>
        end
    end

    if update.trainingCompleted && update.candidateAccepted && ...
            isfinite(update.activationTime) && update.activationTime < observations.t(end)-1e-12
        acceptedModels{end+1,1} = update.updatedModel; %#ok<AGROW>
        acceptedActivationTimes(end+1,1) = update.activationTime; %#ok<AGROW>
        currentModel = update.updatedModel;
        resumeReferenceTime = update.activationTime;
        resumeReason = "accepted activation";
    else
        % A rejected/failed candidate does NOT terminate the digital shadow.
        % Resume only after any causal validation window that has already been
        % consumed, so the same residual samples are not used immediately to
        % fire an identical trigger again.
        resumeReferenceTime = rejected_resume_reference_time(update,detector.triggerTime);
        resumeReason = "rejected/failed candidate";
    end

    % In controlled scheduled mode each physical coefficient jump is used at
    % most once.  Do not re-arm an automatic detector between known events.
    if scheduledMode
        if attempt >= numel(scheduledTimes)
            result.updateLog(end+1) = "  controlled scheduled-update sequence finished."; %#ok<AGROW>
            break;
        end
        nextScheduledTime = scheduledTimes(attempt+1);
        if isfinite(resumeReferenceTime) && resumeReferenceTime > nextScheduledTime+1e-12
            result.updateLog(end+1) = sprintf([ ...
                '  warning: previous update/activation (t=%.6f s) extends beyond next scheduled jump at t=%.6f s.'], ...
                resumeReferenceTime,nextScheduledTime); %#ok<AGROW>
        end
        currentStartTime = nextScheduledTime;
        continue;
    end

    if acceptedCount >= maxAccepted
        result.updateLog(end+1) = "  accepted-update limit reached ("+maxAccepted+"); monitoring finished."; %#ok<AGROW>
        break;
    end

    resumeAfter = resumeReferenceTime + refractorySeconds;
    nextTime = next_time_after(observations.t,resumeAfter);
    if ~isfinite(nextTime)
        result.updateLog(end+1) = "  no observation remains after "+resumeReason+"; monitoring finished."; %#ok<AGROW>
        break;
    end
    currentStartTime = nextTime;
    result.updateLog(end+1) = sprintf( ...
        '  detector re-armed after %s at t=%.6f s (refractory %.3f s).', ...
        char(resumeReason),currentStartTime,refractorySeconds); %#ok<AGROW>
end

if isempty(acceptedActivationTimes)
    prediction = simulate_online_frozen_model_scenario( ...
        initialModel,method,truth,cNominal,layout,cfg);
    prediction.metadata.onlineMode='online_no_activation';
else
    prediction = simulate_online_multi_update_scenario( ...
        initialModel,acceptedModels,acceptedActivationTimes,method,truth,cNominal,layout,cfg);
end

result.prediction = prediction;
% Stage-3 ablation support: expose the accepted coefficient models and the
% exact causal activation schedule so frozen/state-sync and adapted/no-sync
% deployments can be evaluated without recomputing detection or adaptation.
result.acceptedModels = acceptedModels;
result.acceptedActivationTimes = acceptedActivationTimes(:);
result.detector = aggregate_detector_history(result.detectorHistory,observations);
result.detector.historyTable = detector_history_table(result.detectorHistory);
result.update = aggregate_update_history(result.updateHistory,acceptedActivationTimes,acceptedModels);
result.update.detectorHistory = result.detectorHistory;
result.update.updateHistory = result.updateHistory;
result.update.historyTable = update_history_table(result.updateHistory);
end

function U = empty_aggregate_update()
U=struct();
U.strategy='';
U.trainingTimeSeconds=NaN;
U.candidateReadyTime=NaN;
U.candidateAccepted=false;
U.activationTime=NaN;
U.activatedWithinHorizon=false;
U.updatedModel=[];
U.updatedTrainInfo=struct();
U.dataInfo=struct();
U.validation=struct();
U.triggered=false;
U.triggerTime=NaN;
U.affectedModuleLabel="";
U.affectedDeviceType='';
U.affectedDeviceIndex=NaN;
U.updateCount=0;
U.attemptCount=0;
U.acceptedUpdateCount=0;
U.rejectedUpdateCount=0;
U.activationTimes=[];
U.trainingTimeSecondsTotal=0;
U.candidateReadyTimes=[];
U.acceptedStageIndices=[];
U.acceptedAttemptIndices=[];
U.history=cell(0,1);
end

function obs = trim_observations(observations,startTime)
mask = observations.t >= startTime-1e-12;
obs = observations;
fields = fieldnames(observations);
for i=1:numel(fields)
    name = fields{i};
    value = observations.(name);
    if isnumeric(value)
        if isvector(value) && numel(value)==numel(observations.t)
            if isrow(value)
                obs.(name) = value(mask.');
            else
                obs.(name) = value(mask);
            end
        elseif size(value,2)==numel(observations.t)
            obs.(name) = value(:,mask);
        elseif size(value,1)==numel(observations.t)
            obs.(name) = value(mask,:);
        else
            obs.(name) = value;
        end
    elseif isstruct(value) && strcmp(name,'inputs')
        obs.(name) = trim_input_struct(value,mask,numel(observations.t));
    else
        obs.(name) = value;
    end
end
obs.t = obs.t(:);
end

function S = trim_input_struct(S,mask,nTime)
fields = fieldnames(S);
for ii=1:numel(fields)
    f = fields{ii};
    v = S.(f);
    if isnumeric(v) && ~isempty(v)
        if size(v,2)==nTime
            S.(f) = v(:,mask);
        elseif size(v,1)==nTime
            S.(f) = v(mask,:);
        end
    end
end
end

function tRef = rejected_resume_reference_time(update,triggerTime)
% Resume after all observations already consumed by training/validation.
tRef = triggerTime;
if isstruct(update)
    if isfield(update,'validation') && isstruct(update.validation)
        if isfield(update.validation,'validationEndTime') && ...
                isfinite(update.validation.validationEndTime)
            tRef = max(tRef,update.validation.validationEndTime);
        elseif isfield(update.validation,'validationStartTime') && ...
                isfinite(update.validation.validationStartTime)
            tRef = max(tRef,update.validation.validationStartTime);
        end
    end
    if isfield(update,'candidateReadyTime') && isfinite(update.candidateReadyTime)
        tRef = max(tRef,update.candidateReadyTime);
    end
end
end

function tNext = next_time_after(t,ref)
idx = find(t > ref+1e-12,1,'first');
if isempty(idx)
    tNext = inf;
else
    tNext = t(idx);
end
end

function D = aggregate_detector_history(history,observations)
D = struct('time',observations.t(:),'triggered',false,'triggerTime',NaN, ...
    'affectedModuleLabel',"",'affectedDeviceType','', 'affectedDeviceIndex',NaN, ...
    'maxModuleTriggerRatio',nan(numel(observations.t),1));
if isempty(history)
    D.table = table(D.time,D.maxModuleTriggerRatio, ...
        'VariableNames',{'Time_s','MaxModuleTriggerRatio'});
    D.history = history;
    return;
end

ratio = nan(numel(observations.t),1);
for i=1:numel(history)
    h = history{i};
    if ~isfield(h,'time') || isempty(h.time) || ~isfield(h,'maxModuleTriggerRatio')
        continue;
    end
    for k=1:numel(h.time)
        idx=find(abs(observations.t(:)-h.time(k))<=1e-12,1,'first');
        if ~isempty(idx)
            ratio(idx)=h.maxModuleTriggerRatio(k);
        end
    end
end
D.maxModuleTriggerRatio = ratio;
D.time = observations.t(:);
D.history = history;
D.table = table(D.time,D.maxModuleTriggerRatio, ...
    'VariableNames',{'Time_s','MaxModuleTriggerRatio'});

for i=1:numel(history)
    h = history{i};
    if isfield(h,'triggered') && h.triggered
        D.triggered = true;
        D.triggerTime = h.triggerTime;
        if isfield(h,'affectedModuleLabel'), D.affectedModuleLabel = string(h.affectedModuleLabel); end
        if isfield(h,'affectedDeviceType'), D.affectedDeviceType = char(h.affectedDeviceType); end
        if isfield(h,'affectedDeviceIndex'), D.affectedDeviceIndex = h.affectedDeviceIndex; end
        break;
    end
end
end

function U = aggregate_update_history(history,acceptedActivationTimes,acceptedModels)
U = empty_aggregate_update();
U.updateCount = numel(history); % legacy alias: number of update attempts
U.attemptCount = numel(history);
U.acceptedUpdateCount = numel(acceptedActivationTimes);
U.rejectedUpdateCount = max(0,U.attemptCount-U.acceptedUpdateCount);
U.activationTimes = acceptedActivationTimes(:).';
U.history = history;
if isempty(history)
    return;
end

first = history{1};
if isfield(first,'strategy'), U.strategy = first.strategy; end

trainTimes = nan(numel(history),1);
readyTimes = nan(numel(history),1);
acceptedMask = false(numel(history),1);
for i=1:numel(history)
    h = history{i};
    if isfield(h,'trainingTimeSeconds'), trainTimes(i)=h.trainingTimeSeconds; end
    if isfield(h,'candidateReadyTime'), readyTimes(i)=h.candidateReadyTime; end
    if isfield(h,'candidateAccepted'), acceptedMask(i)=logical(h.candidateAccepted); end
    if ~U.triggered && isfield(h,'triggered') && h.triggered
        U.triggered = true;
        U.triggerTime = h.triggerTime;
        if isfield(h,'affectedModuleLabel'), U.affectedModuleLabel = string(h.affectedModuleLabel); end
        if isfield(h,'affectedDeviceType'), U.affectedDeviceType = char(h.affectedDeviceType); end
        if isfield(h,'affectedDeviceIndex'), U.affectedDeviceIndex = h.affectedDeviceIndex; end
    end
end
U.trainingTimeSecondsTotal = sum(trainTimes,'omitnan');
U.trainingTimeSeconds = U.trainingTimeSecondsTotal;
U.candidateReadyTimes = readyTimes(:).';
U.acceptedStageIndices = find(acceptedMask).'; % legacy alias
U.acceptedAttemptIndices = U.acceptedStageIndices;
U.candidateAccepted = any(acceptedMask);

if U.candidateAccepted
    idxLast = find(acceptedMask,1,'last');
    last = history{idxLast};
    U.candidateReadyTime = last.candidateReadyTime;
    U.activationTime = acceptedActivationTimes(1); % first activation for post-update metrics
    U.lastActivationTime = acceptedActivationTimes(end);
    U.activatedWithinHorizon = true;
    U.updatedModel = acceptedModels{end};
    if isfield(last,'updatedTrainInfo'), U.updatedTrainInfo = last.updatedTrainInfo; end
    if isfield(last,'dataInfo'), U.dataInfo = last.dataInfo; end
    if isfield(last,'validation'), U.validation = last.validation; end
else
    finiteReady = readyTimes(isfinite(readyTimes));
    if ~isempty(finiteReady), U.candidateReadyTime = finiteReady(end); end
end
end

function T = detector_history_table(history)
if isempty(history)
    T = table();
    return;
end
stage = zeros(0,1);
time = zeros(0,1);
ratio = zeros(0,1);
triggered = false(0,1);
module = strings(0,1);
for i=1:numel(history)
    h = history{i};
    if ~isfield(h,'time') || isempty(h.time), continue; end
    n = numel(h.time);
    stage = [stage;repmat(i,n,1)]; %#ok<AGROW>
    time = [time;h.time(:)]; %#ok<AGROW>
    if isfield(h,'maxModuleTriggerRatio')
        ratio = [ratio;h.maxModuleTriggerRatio(:)]; %#ok<AGROW>
    else
        ratio = [ratio;nan(n,1)]; %#ok<AGROW>
    end
    trig = false(n,1);
    if isfield(h,'triggered') && h.triggered && isfield(h,'triggerTime') && isfinite(h.triggerTime)
        [~,idx] = min(abs(h.time(:)-h.triggerTime));
        trig(idx) = true;
    end
    triggered = [triggered;trig]; %#ok<AGROW>
    thisModule = "";
    if isfield(h,'affectedModuleLabel'), thisModule = string(h.affectedModuleLabel); end
    module = [module;repmat(thisModule,n,1)]; %#ok<AGROW>
end
T = table(stage,time,ratio,triggered,module, ...
    'VariableNames',{'StageIndex','Time_s','MaxModuleTriggerRatio','TriggerPoint','LocalizedModule'});
end

function T = update_history_table(history)
if isempty(history)
    T = table();
    return;
end
n = numel(history);
StageIndex = (1:n).'; % legacy name retained; equals attempt index
AttemptIndex = (1:n).';
AcceptedUpdateIndex = nan(n,1);
AttemptStatus = strings(n,1);
TriggerTimeSec = nan(n,1);
AffectedModule = strings(n,1);
TrainingCompleted = false(n,1);
TrainingTimeSec = nan(n,1);
TrainingDataEndTimeSec = nan(n,1);
SampleAccumulationDelaySec = zeros(n,1);
CandidateReadyTimeSec = nan(n,1);
CandidateAccepted = false(n,1);
ActivationTimeSec = nan(n,1);
ValidationOldScore = nan(n,1);
ValidationNewScore = nan(n,1);
ValidationImprovementPercent = nan(n,1);
FailureMessage = strings(n,1);
for i=1:n
    h = history{i};
    if isfield(h,'triggerTime'), TriggerTimeSec(i)=h.triggerTime; end
    if isfield(h,'acceptedUpdateIndex'), AcceptedUpdateIndex(i)=h.acceptedUpdateIndex; end
    if isfield(h,'affectedModuleLabel'), AffectedModule(i)=string(h.affectedModuleLabel); end
    if isfield(h,'trainingCompleted'), TrainingCompleted(i)=logical(h.trainingCompleted); end
    if isfield(h,'trainingTimeSeconds'), TrainingTimeSec(i)=h.trainingTimeSeconds; end
    if isfield(h,'trainingDataEndTime'), TrainingDataEndTimeSec(i)=h.trainingDataEndTime; end
    if isfield(h,'sampleAccumulationDelaySeconds'), SampleAccumulationDelaySec(i)=h.sampleAccumulationDelaySeconds; end
    if isfield(h,'candidateReadyTime'), CandidateReadyTimeSec(i)=h.candidateReadyTime; end
    if isfield(h,'candidateAccepted'), CandidateAccepted(i)=logical(h.candidateAccepted); end
    if isfield(h,'activationTime'), ActivationTimeSec(i)=h.activationTime; end
    if isfield(h,'validation') && isstruct(h.validation)
        ValidationOldScore(i)=getfield_default(h.validation,'currentModelScore',NaN); %#ok<GFLD>
        ValidationNewScore(i)=getfield_default(h.validation,'candidateModelScore',NaN); %#ok<GFLD>
        rel=getfield_default(h.validation,'relativeImprovement',NaN); %#ok<GFLD>
        ValidationImprovementPercent(i)=100*rel;
    end
    if isfield(h,'failureMessage'), FailureMessage(i)=string(h.failureMessage); end
    if ~TrainingCompleted(i)
        AttemptStatus(i)="update_failed";
    elseif CandidateAccepted(i)
        AttemptStatus(i)="accepted";
    else
        AttemptStatus(i)="rejected";
    end
end
T = table(StageIndex,AttemptIndex,AcceptedUpdateIndex,AttemptStatus,TriggerTimeSec, ...
    AffectedModule,TrainingCompleted,TrainingTimeSec,TrainingDataEndTimeSec, ...
    SampleAccumulationDelaySec,CandidateReadyTimeSec,CandidateAccepted, ...
    ActivationTimeSec,ValidationOldScore,ValidationNewScore, ...
    ValidationImprovementPercent,FailureMessage);
end

function value=getfield_default(S,name,defaultValue)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    value=S.(name);
else
    value=defaultValue;
end
end


function tf = scheduled_update_mode_enabled(cfg)
tf=false;
if ~isstruct(cfg) || ~isfield(cfg,'online') || ~isfield(cfg.online,'update')
    return;
end
U=cfg.online.update;
if isfield(U,'triggerMode') && strlength(string(U.triggerMode))>0
    tf=any(strcmpi(string(U.triggerMode),["scheduled_parameter_changes","scheduled","oracle_schedule"]));
end
end

function times = scheduled_update_times(cfg,observations)
U=cfg.online.update;
if isfield(U,'scheduledTriggerTimes') && ~isempty(U.scheduledTriggerTimes)
    times=double(U.scheduledTriggerTimes(:));
elseif isfield(cfg.online,'parameterMismatch') && ...
        isfield(cfg.online.parameterMismatch,'times') && ...
        ~isempty(cfg.online.parameterMismatch.times)
    times=double(cfg.online.parameterMismatch.times(:));
else
    times=zeros(0,1);
end
t0=min(observations.t(:)); tf=max(observations.t(:));
times=times(isfinite(times) & times>=t0-1e-12 & times<=tf+1e-12);
times=unique(times,'stable');
end

function detector = force_scheduled_update_detector(detector,scheduledTime,cfg,cNominal,layout)
% Convert the regular detector record into a synthetic trigger located at a
% known physical coefficient-jump time.  The residual traces remain stored
% for audit, but they do not decide the update timing in this controlled test.
if isfield(cfg.online.update,'scheduledDeviceType') && ...
        strlength(string(cfg.online.update.scheduledDeviceType))>0
    deviceType=lower(char(string(cfg.online.update.scheduledDeviceType)));
else
    deviceType=lower(char(string(cfg.online.parameterMismatch.deviceType)));
end
if isfield(cfg.online.update,'scheduledDeviceIndex') && ...
        isfinite(cfg.online.update.scheduledDeviceIndex)
    deviceIndex=round(double(cfg.online.update.scheduledDeviceIndex));
else
    dev=double(cfg.online.parameterMismatch.device(:));
    deviceIndex=round(dev(1));
end
label=sprintf('%s%d',upper(deviceType),deviceIndex);
moduleIndex=find(strcmpi(string(detector.moduleLabels),label),1);
if isempty(moduleIndex)
    error('run_iterative_online_model_correction:ScheduledModule', ...
        'Scheduled module %s is not present in detector.moduleLabels.',label);
end
idxTime=find(detector.time>=scheduledTime-1e-12,1,'first');
if isempty(idxTime), idxTime=1; end
switch deviceType
    case 'sg'
        stateIdx=layout.sg{deviceIndex};
    case 'gfm'
        stateIdx=layout.gfm{deviceIndex};
    case 'gfl'
        stateIdx=layout.gfl{deviceIndex};
    otherwise
        error('run_iterative_online_model_correction:ScheduledDeviceType', ...
            'Unsupported scheduled device type: %s.',deviceType);
end

detector.triggered=true;
detector.triggerSource='scheduled_parameter_change';
detector.scheduledTrigger=true;
detector.triggerIndex=idxTime;
detector.triggerTime=scheduledTime;
detector.triggerModuleIndex=moduleIndex;
detector.affectedModuleLabel=string(label);
detector.affectedDeviceType=deviceType;
detector.affectedDeviceIndex=deviceIndex;
detector.affectedStateIndices=stateIdx(:);
detector.triggerModuleThreshold=detector.moduleThresholds(moduleIndex);
if size(detector.moduleRollingScore,1)>=idxTime && size(detector.moduleRollingScore,2)>=moduleIndex
    detector.triggerModuleRollingScore=detector.moduleRollingScore(idxTime,moduleIndex);
else
    detector.triggerModuleRollingScore=NaN;
end
if isfinite(detector.triggerModuleThreshold) && detector.triggerModuleThreshold>0 && ...
        isfinite(detector.triggerModuleRollingScore)
    detector.triggerModuleRatio=detector.triggerModuleRollingScore/detector.triggerModuleThreshold;
else
    detector.triggerModuleRatio=NaN;
end
end
