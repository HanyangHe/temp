function nDim = offline_sampling_dimension(c,layout)
%OFFLINE_SAMPLING_DIMENSION Number of independent Sobol coordinates.

loadBuses = find(abs(c.input.nominal.Sload) > 1e-12);
nSgInputs = numel(c.sg); % Pm
if isfield(c.input.nominal,'sgVref')
    nSgInputs = nSgInputs + numel(c.sg); % AVR Vref
end
nDim = layout.nx ...
    + numel(loadBuses) ...
    + nSgInputs ...
    + 3*numel(c.gfm) ...
    + 2*numel(c.gfl);
end
