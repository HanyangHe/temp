function [x,u] = map_sobol_point_to_state_input(q,xEq,c,layout,cfg)
%MAP_SOBOL_POINT_TO_STATE_INPUT Map one unit-cube Sobol point to (x,u).

q = q(:);
expected = offline_sampling_dimension(c,layout);
if numel(q) ~= expected
    error('map_sobol_point_to_state_input:Dimension', ...
        'Sobol point has %d entries; expected %d.',numel(q),expected);
end

x = xEq(:);
u = c.input.nominal;
p = 0;

% Differential states follow the deterministic state layout.
for k = 1:numel(c.sg)
    idx = layout.sg{k};
    s = cfg.sampling.state.sg;
    x(idx(1)) = xEq(idx(1)) + centered(q(p+1))*getopt(s,'deltaHalfRangeRad',0.080);
    x(idx(2)) = xEq(idx(2)) + centered(q(p+2))*getopt(s,'nuHalfRangePU',0.0020);
    p = p + 2;
    if numel(idx) == 5
        x(idx(3)) = xEq(idx(3)) + centered(q(p+1))*getopt(s,'EqPrimeHalfRangePU',0.040);
        x(idx(4)) = xEq(idx(4)) + centered(q(p+2))*getopt(s,'EdPrimeHalfRangePU',0.030);
        x(idx(5)) = xEq(idx(5)) + centered(q(p+3))*getopt(s,'EfdHalfRangePU',0.080);
        p = p + 3;
    end
end

for k = 1:numel(c.gfm)
    idx = layout.gfm{k};
    s = cfg.sampling.state.gfm;
    pHalf = max(abs(xEq(idx(2)))*s.pFiltRelativeHalfRange,s.pFiltAbsoluteFloor);
    x(idx(1)) = xEq(idx(1)) + centered(q(p+1))*s.deltaHalfRangeRad;
    x(idx(2)) = xEq(idx(2)) + centered(q(p+2))*pHalf;
    x(idx(3)) = xEq(idx(3)) + centered(q(p+3))*s.qFiltHalfRangePU;
    x(idx(4)) = xEq(idx(4)) + centered(q(p+4))*s.EHalfRangePU;
    p = p + 4;
end

for k = 1:numel(c.gfl)
    idx = layout.gfl{k};
    s = cfg.sampling.state.gfl;
    x(idx(1)) = xEq(idx(1)) + centered(q(p+1))*s.thetaHalfRangeRad;
    x(idx(2)) = xEq(idx(2)) + centered(q(p+2))*s.xiPLLHalfRange;
    x(idx(3)) = xEq(idx(3)) + centered(q(p+3))*s.idHalfRangePU;
    x(idx(4)) = xEq(idx(4)) + centered(q(p+4))*s.iqHalfRangePU;
    p = p + 4;
end

% Constant-PQ load levels: one independent Sobol coordinate per active load.
loadBuses = find(abs(c.input.nominal.Sload) > 1e-12);
r = cfg.sampling.input.loadScaleRange;
for kk = 1:numel(loadBuses)
    p = p + 1;
    scale = affine(q(p),r);
    b = loadBuses(kk);
    u.Sload(b) = c.input.nominal.Sload(b)*scale;
end

% SG mechanical-power input.
r = cfg.sampling.input.sgPmScaleRange;
for k = 1:numel(c.sg)
    p = p + 1;
    u.sgPm(k) = c.input.nominal.sgPm(k)*affine(q(p),r);
end

% SG AVR-reference input, when present in the active SG model.
if isfield(c.input.nominal,'sgVref')
    r = getopt(cfg.sampling.input,'sgVrefAddRangePU',[-0.015 +0.015]);
    for k = 1:numel(c.sg)
        p = p + 1;
        u.sgVref(k) = c.input.nominal.sgVref(k) + affine(q(p),r);
    end
end

% GFM P*/Q*/Eref inputs.
for k = 1:numel(c.gfm)
    p = p + 1;
    u.gfmPstar(k) = c.input.nominal.gfmPstar(k) + ...
        affine(q(p),cfg.sampling.input.gfmPstarAddRangePU);
    p = p + 1;
    u.gfmQstar(k) = c.input.nominal.gfmQstar(k) + ...
        affine(q(p),cfg.sampling.input.gfmQstarAddRangePU);
    p = p + 1;
    u.gfmEref(k) = c.input.nominal.gfmEref(k) + ...
        affine(q(p),cfg.sampling.input.gfmErefAddRangePU);
end

% GFL P*/Q* inputs.
for k = 1:numel(c.gfl)
    p = p + 1;
    u.gflPstar(k) = c.input.nominal.gflPstar(k) + ...
        affine(q(p),cfg.sampling.input.gflPstarAddRangePU);
    p = p + 1;
    u.gflQstar(k) = c.input.nominal.gflQstar(k) + ...
        affine(q(p),cfg.sampling.input.gflQstarAddRangePU);
end

if p ~= expected
    error('map_sobol_point_to_state_input:InternalIndex', ...
        'Consumed %d Sobol coordinates; expected %d.',p,expected);
end
end

function y = centered(q)
y = 2*q - 1;
end

function y = affine(q,range)
y = range(1) + q*(range(2)-range(1));
end

function v = getopt(s,name,defaultValue)
if isfield(s,name) && ~isempty(s.(name))
    v = s.(name);
else
    v = defaultValue;
end
end
