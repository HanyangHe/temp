function dataset = generate_offline_trajectory_dataset(c,layout,cfg,projectRoot)
%GENERATE_OFFLINE_TRAJECTORY_DATASET Build nested short-trajectory training data.
%
% v1p7d sampling rule
% --------------------
% By default, exactly ONE complete short trajectory is anchored at the
% formal test scenario initial operating point. The anchor uses the same
% initial differential state and algebraic voltage as the reference case,
% and freezes the test-scenario input at its t0 value over the short segment.
% Therefore it exposes the initial operating neighborhood only; it does NOT
% expose any later test events/actions.
%
% The remaining trajectories are Sobol-started as before. Hence, for total
% sample count N and L saved points/trajectory,
%
%       K = N/L total trajectories
%       = 1 test-initial anchor + (K-1) Sobol trajectories.
%
% The anchor REPLACES one Sobol trajectory, so the total sample budget N is
% unchanged. Flat arrays are retained for pointwise methods; trajectory
% arrays retain grouping for Neural ODE / trajectory-trained methods.

if exist('sobolset','file') ~= 2
    error('generate_offline_trajectory_dataset:MissingSobol', ...
        'sobolset is required (Statistics and Machine Learning Toolbox).');
end
if exist('fsolve','file') ~= 2
    error('generate_offline_trajectory_dataset:MissingFsolve', ...
        'fsolve is required to enforce initial DAE algebraic consistency.');
end

Nmax = max([cfg.typicalSampleCount,cfg.sampleCounts(:).']);
L = cfg.data.pointsPerTrajectory;
if mod(Nmax,L) ~= 0
    error('generate_offline_trajectory_dataset:TrajectoryPacking', ...
        'Nmax=%d must be divisible by pointsPerTrajectory=%d.',Nmax,L);
end
Kmax = Nmax/L;

% v1p7d default: include one test-initial anchor. An explicit config field
% can disable it for ablation/backward-compatibility, but users do not need
% to add the field to activate the new default behavior.
useTestInitialAnchor = true;
if isfield(cfg.data,'includeTestInitialAnchor') && ...
        ~isempty(cfg.data.includeTestInitialAnchor)
    useTestInitialAnchor = logical(cfg.data.includeTestInitialAnchor);
end
if ~isscalar(useTestInitialAnchor)
    error('generate_offline_trajectory_dataset:AnchorSwitch', ...
        'cfg.data.includeTestInitialAnchor must be scalar logical/numeric.');
end
if useTestInitialAnchor && Kmax < 2
    error('generate_offline_trajectory_dataset:TooFewTrajectoriesForAnchor', ...
        ['At least two trajectories are required when the test-initial anchor is enabled ', ...
         '(one anchor plus at least one Sobol trajectory).']);
end
nAnchor = double(useTestInitialAnchor);
nSobolNeeded = Kmax - nAnchor;

outDir = fullfile(projectRoot,'outputs',cfg.output.folderName,'data');
if ~exist(outDir,'dir'), mkdir(outDir); end
dtTag = strrep(sprintf('%.6g',cfg.data.trajectorySampleStep),'.','p');
cacheRevision = get_cache_revision(cfg);
revisionTag = regexprep(cacheRevision,'[^A-Za-z0-9_\-]','_');
if strlength(revisionTag) > 0
    revisionSuffix = ['_' char(revisionTag)];
else
    revisionSuffix = '';
end
cacheFile = fullfile(outDir,sprintf( ...
    'offline_short_trajectories_N%d_K%d_L%d_dt%s_testInitAnchor%d%s.mat', ...
    Nmax,Kmax,L,dtTag,nAnchor,revisionSuffix));

if cfg.data.reuseExisting && ~cfg.data.forceRegenerate && exist(cacheFile,'file') == 2
    try
        s = load_mat_long_path_safe(cacheFile,'dataset');
        if isfield(s,'dataset') && ...
                cache_is_compatible(s.dataset,c,layout,cfg,Nmax,Kmax,L,useTestInitialAnchor)
            dataset = s.dataset;
            fprintf('Reusing cached clean short-trajectory dataset: %s\n',cacheFile);
            return;
        end
        fprintf('Existing trajectory cache is incompatible with current settings; regenerating.\n');
    catch MEcache
        warning('generate_offline_trajectory_dataset:CorruptCache', ...
            ['Could not read the existing trajectory cache even with the long-path-safe ', ...
             'loader; it will be quarantined and regenerated.\n  %s\nReason: %s'],cacheFile,MEcache.message);

        % Move the bad file out of the active cache name so this same file
        % cannot be retried on the next run. If quarantine fails, try delete.
        try
            [cacheFolder,cacheName,cacheExt] = fileparts(cacheFile);
            stamp = datestr(now,'yyyymmdd_HHMMSSFFF');
            quarantineFile = fullfile(cacheFolder, ...
                [cacheName '_CORRUPT_' stamp cacheExt]);
            [moved,msgMove] = movefile(cacheFile,quarantineFile,'f');
            if moved
                fprintf('Quarantined corrupt trajectory cache: %s\n',quarantineFile);
            else
                warning('generate_offline_trajectory_dataset:QuarantineFailed', ...
                    'Could not quarantine corrupt cache (%s). Trying delete.',msgMove);
                delete(cacheFile);
            end
        catch MEquarantine
            warning('generate_offline_trajectory_dataset:CorruptCacheCleanupFailed', ...
                ['Could not quarantine/delete the corrupt cache. Generation will ', ...
                 'still proceed in memory. Cleanup reason: %s'],MEquarantine.message);
        end
    end
end

fprintf('Solving nominal physical-DAE equilibrium before trajectory generation...\n');
eqStart = tic;
[yEq,~,initInfo] = initialize_reference_equilibrium(c,layout);
eqTime = toc(eqStart);
[xEq,VEq] = mg_unpack_dae_state(yEq,c,layout);
fprintf(['Nominal equilibrium initialization SUCCESS in %.3f s; ', ...
    'starting short-trajectory generation.\n'],eqTime);

cNom = c;
if isfield(cNom,'drift') && isfield(cNom.drift,'enabled')
    cNom.drift.enabled = false;
end
pNom = mg_parameter_profile(cNom.sim.t0,cNom);
meta = build_offline_feature_metadata(cNom,layout);
nDim = offline_sampling_dimension(cNom,layout);
maxCandidates = ceil(cfg.data.maxCandidateMultiplier*nSobolNeeded);

if nSobolNeeded > 0
    p = sobolset(nDim,'Skip',cfg.data.sobolSkip,'Leap',cfg.data.sobolLeap);
    if cfg.data.sobolScramble
        % Tie the Sobol scrambling reproducibly to the manuscript
        % data-sampling seed without perturbing the RNG state used by
        % validation splits, neural features, noise, or other methods.
        if isfield(cfg,'randomSeed') && ~isempty(cfg.randomSeed)
            rngState = rng;
            rngGuard = onCleanup(@() rng(rngState));
            rng(double(cfg.randomSeed),'twister');
            p = scramble(p,'MatousekAffineOwen');
            clear rngGuard; % restore the incoming RNG state immediately
        else
            p = scramble(p,'MatousekAffineOwen');
        end
    end
    Q = net(p,maxCandidates);
else
    Q = zeros(0,nDim);
end

opts = optimoptions('fsolve', ...
    'Display','off', ...
    'FunctionTolerance',cfg.data.fsolve.FunctionTolerance, ...
    'StepTolerance',cfg.data.fsolve.StepTolerance, ...
    'OptimalityTolerance',cfg.data.fsolve.OptimalityTolerance, ...
    'MaxIterations',cfg.data.fsolve.MaxIterations, ...
    'MaxFunctionEvaluations',cfg.data.fsolve.MaxFunctionEvaluations);

featuresFlat = zeros(Nmax,meta.nFeatures);
labelsFlat = zeros(Nmax,layout.nx);
xFlat = zeros(Nmax,layout.nx);
zFlat = zeros(Nmax,layout.nvAlg);
VFlat = complex(zeros(Nmax,c.network.N));
trajectoryId = zeros(Nmax,1);
pointInTrajectory = zeros(Nmax,1);

trajX = zeros(L,Kmax,layout.nx);
trajV = complex(zeros(L,Kmax,c.network.N));
trajLabels = zeros(L,Kmax,layout.nx);
trajFeatures = zeros(L,Kmax,meta.nFeatures);
uByTrajectory = cell(Kmax,1);
initialSobol = nan(Kmax,nDim);
trajectorySource = strings(Kmax,1);
isTestInitialAnchor = false(Kmax,1);
forceTrainingMask = false(Kmax,1);

acceptedTraj = 0;
rejectedInitialSolve = 0;
rejectedSegment = 0;
Vwarm = VEq;

fprintf('\nGenerating short-trajectory training data: total N=%d = %d trajectories x %d points\n', ...
    Nmax,Kmax,L);
if useTestInitialAnchor
    fprintf('  composition: 1 test-initial anchor + %d Sobol-started trajectories\n',nSobolNeeded);
    fprintf(['  anchor rule: use test (x0,u0), freeze u at t0 over %.3f s; ', ...
        'later test events are NOT exposed\n'],cfg.data.trajectoryDuration);
else
    fprintf('  composition: %d Sobol-started trajectories (test-initial anchor disabled)\n',nSobolNeeded);
end
fprintf('Sobol dimension=%d | segment duration=%.3f s | saved dt=%.4f s\n', ...
    nDim,cfg.data.trajectoryDuration,cfg.data.trajectorySampleStep);
tStart = tic;

%% 1) Reserve trajectory 1 for the formal test initial operating point.
if useTestInitialAnchor
    % Use exactly the input seen by the formal test case at t=t0, then freeze
    % that input during this short anchor. This calibrates the initial local
    % neighborhood without revealing any future test action sequence.
    uAnchor = mg_input_profile(cNom.sim.t0,cNom);
    [VAnchor,solveInfo] = solve_algebraic_voltage_for_sample( ...
        xEq,uAnchor,VEq,VEq,cNom,layout,pNom,opts);
    if solveInfo.exitflag <= 0 || ...
            solveInfo.residualInf > cfg.data.acceptAlgebraicResidualInf
        error('generate_offline_trajectory_dataset:AnchorAlgebraicSolve', ...
            ['Could not construct the test-initial anchor: algebraic solve failed ', ...
             '(exitflag=%d, residual=%.3e).'], ...
            solveInfo.exitflag,solveInfo.residualInf);
    end
    if min(abs(VAnchor)) < cfg.data.acceptVoltageMinPU || ...
            max(abs(VAnchor)) > cfg.data.acceptVoltageMaxPU
        error('generate_offline_trajectory_dataset:AnchorVoltageRange', ...
            'The test-initial anchor voltage lies outside the accepted training range.');
    end

    [seg,segInfo] = simulate_offline_training_segment( ...
        xEq,VAnchor,uAnchor,pNom,cNom,layout,cfg);
    if ~segInfo.success
        error('generate_offline_trajectory_dataset:AnchorSegment', ...
            'Could not generate the test-initial anchor short trajectory: %s',segInfo.reason);
    end

    store_segment(seg,uAnchor,"test_initial_anchor",nan(1,nDim),true);
    Vwarm = VAnchor;
    fprintf('  inserted test-initial anchor trajectory 1/%d = %d/%d samples\n', ...
        Kmax,L,Nmax);
end

%% 2) Fill the remaining budget with accepted Sobol-started trajectories.
acceptedSobol = 0;
for ic = 1:maxCandidates
    [x0,u0] = map_sobol_point_to_state_input(Q(ic,:),xEq,cNom,layout,cfg);
    [V0,solveInfo] = solve_algebraic_voltage_for_sample( ...
        x0,u0,Vwarm,VEq,cNom,layout,pNom,opts);
    if solveInfo.exitflag <= 0 || ...
            solveInfo.residualInf > cfg.data.acceptAlgebraicResidualInf
        rejectedInitialSolve = rejectedInitialSolve + 1;
        continue;
    end
    if min(abs(V0)) < cfg.data.acceptVoltageMinPU || ...
            max(abs(V0)) > cfg.data.acceptVoltageMaxPU
        rejectedInitialSolve = rejectedInitialSolve + 1;
        continue;
    end

    [seg,segInfo] = simulate_offline_training_segment( ...
        x0,V0,u0,pNom,cNom,layout,cfg);
    if ~segInfo.success
        rejectedSegment = rejectedSegment + 1;
        continue;
    end

    store_segment(seg,u0,"sobol",Q(ic,:),false);
    acceptedSobol = acceptedSobol + 1;
    Vwarm = V0;

    if mod(acceptedSobol,cfg.data.progressEveryAcceptedTrajectory) == 0 || ...
            acceptedSobol == nSobolNeeded
        fprintf(['  accepted Sobol %d/%d | total trajectories %d/%d = %d/%d samples ', ...
            '(candidate %d, elapsed %.1f s)\n'], ...
            acceptedSobol,nSobolNeeded,acceptedTraj,Kmax,acceptedTraj*L,Nmax,ic,toc(tStart));
    end
    if acceptedSobol >= nSobolNeeded
        break;
    end
end

if acceptedSobol < nSobolNeeded
    error('generate_offline_trajectory_dataset:InsufficientAcceptedTrajectories', ...
        ['Only %d/%d required Sobol trajectories were accepted after %d candidates. ', ...
         'Increase maxCandidateMultiplier or narrow the initial-condition/input ranges.'], ...
        acceptedSobol,nSobolNeeded,maxCandidates);
end
if acceptedTraj ~= Kmax
    error('generate_offline_trajectory_dataset:InternalTrajectoryCount', ...
        'Generated %d trajectories; expected %d.',acceptedTraj,Kmax);
end

dataset.features = featuresFlat;
dataset.labelsClean = labelsFlat;
dataset.labels = labelsFlat;
dataset.x = xFlat;
dataset.z = zFlat;
dataset.V = VFlat;
dataset.trajectoryId = trajectoryId;
dataset.pointInTrajectory = pointInTrajectory;
dataset.featureNames = meta.featureNames;
dataset.labelNames = meta.labelNames;

dataset.trajectories.t = (0:L-1).'*cfg.data.trajectorySampleStep;
dataset.trajectories.xClean = trajX;
dataset.trajectories.xObserved = trajX;
dataset.trajectories.V = trajV;
dataset.trajectories.labelsClean = trajLabels;
dataset.trajectories.labels = trajLabels;
dataset.trajectories.features = trajFeatures;
dataset.trajectories.uByTrajectory = uByTrajectory;
dataset.trajectories.initialSobolCoordinates = initialSobol;
dataset.trajectories.sourceType = trajectorySource;
dataset.trajectories.isTestInitialAnchor = isTestInitialAnchor;
% NODE train/validation splitting honors this mask so the anchor cannot be
% accidentally assigned to validation instead of the training set.
dataset.trajectories.forceTrainingMask = forceTrainingMask;
dataset.trajectories.pointsPerTrajectory = L;
dataset.trajectories.nTrajectories = Kmax;

dataset.metadata.caseName = c.name;
dataset.metadata.N = Nmax;
dataset.metadata.nTrajectories = Kmax;
dataset.metadata.nSobolTrajectories = nSobolNeeded;
dataset.metadata.pointsPerTrajectory = L;
dataset.metadata.trajectorySampleStep = cfg.data.trajectorySampleStep;
dataset.metadata.trajectoryDuration = cfg.data.trajectoryDuration;
if useTestInitialAnchor
    dataset.metadata.sampleDefinition = ...
        'N = [1 test-initial frozen-input anchor + remaining Sobol-started short trajectories] * saved points per trajectory';
else
    dataset.metadata.sampleDefinition = ...
        'N = number of Sobol-started short trajectories * saved points per trajectory';
end
dataset.metadata.testInitialAnchor.enabled = useTestInitialAnchor;
dataset.metadata.testInitialAnchor.trajectoryId = double(useTestInitialAnchor);
dataset.metadata.testInitialAnchor.inputMode = 'freeze formal test input at t0 over the short anchor';
dataset.metadata.testInitialAnchor.exposesFutureTestEvents = false;
dataset.metadata.testInitialAnchor.t0 = cNom.sim.t0;
dataset.metadata.testInitialAnchor.duration = cfg.data.trajectoryDuration;
dataset.metadata.sobolDimension = nDim;
dataset.metadata.equilibriumY = yEq;
dataset.metadata.equilibriumInfo = initInfo;
dataset.metadata.featureMetadata = meta;
dataset.metadata.samplingConfig = cfg.sampling;
dataset.metadata.trajectoryConfig = trajectory_config(cfg,useTestInitialAnchor);
dataset.metadata.acceptanceConfig = acceptance_config(cfg);
dataset.metadata.sobolConfig = sobol_config(cfg);
dataset.metadata.generationTimeSeconds = toc(tStart);
dataset.metadata.rejections.initialSolve = rejectedInitialSolve;
dataset.metadata.rejections.segment = rejectedSegment;
dataset.metadata.cacheRevision = char(cacheRevision);
dataset.metadata.cacheFile = cacheFile;

cacheSaved = save_dataset_cache_atomic(cacheFile,dataset);
if cacheSaved
    fprintf('Saved clean short-trajectory dataset: %s\n',cacheFile);
else
    fprintf(['WARNING: clean short-trajectory dataset remains available in memory, ', ...
        'but its disk cache was not written. The current experiment will continue.\n']);
end

    function store_segment(seg,uFixed,sourceType,sobolCoordinates,isAnchor)
        % Nested helper: append one accepted complete trajectory while
        % keeping flat pointwise arrays and trajectory-grouped arrays aligned.
        acceptedTraj = acceptedTraj + 1;
        tr = acceptedTraj;
        if tr > Kmax
            error('generate_offline_trajectory_dataset:StoreOverflow', ...
                'Attempted to store more than Kmax=%d trajectories.',Kmax);
        end

        initialSobol(tr,:) = reshape(sobolCoordinates,1,[]);
        uByTrajectory{tr} = uFixed;
        trajectorySource(tr) = string(sourceType);
        isTestInitialAnchor(tr) = logical(isAnchor);
        forceTrainingMask(tr) = logical(isAnchor);

        trajX(:,tr,:) = reshape(seg.x,[L 1 layout.nx]);
        trajV(:,tr,:) = reshape(seg.V,[L 1 c.network.N]);
        trajLabels(:,tr,:) = reshape(seg.labelsClean,[L 1 layout.nx]);

        flatIdx = (tr-1)*L + (1:L);
        for jj = 1:L
            xj = seg.x(jj,:).';
            Vj = seg.V(jj,:).';
            phi = build_model_feature_vector(xj,Vj,uFixed,cNom,layout,meta);
            trajFeatures(jj,tr,:) = reshape(phi,[1 1 meta.nFeatures]);
            featuresFlat(flatIdx(jj),:) = phi.';
            labelsFlat(flatIdx(jj),:) = seg.labelsClean(jj,:);
            xFlat(flatIdx(jj),:) = seg.x(jj,:);
            zFlat(flatIdx(jj),:) = phi(layout.nx+(1:layout.nvAlg)).';
            VFlat(flatIdx(jj),:) = seg.V(jj,:);
            trajectoryId(flatIdx(jj)) = tr;
            pointInTrajectory(flatIdx(jj)) = jj;
        end
    end
end


function ok = save_dataset_cache_atomic(cacheFile,dataset)
%SAVE_DATASET_CACHE_ATOMIC Robust nonfatal trajectory-cache checkpoint.
%
% Saving directly over an interrupted/corrupted v7.3 (HDF5) MAT can fail on
% Windows with "file appears corrupted". The expensive dataset has already
% been generated at this point, so cache I/O must never abort the experiment.
%
% Procedure:
%   1) save to a unique HDF5-safe temporary MAT on the same filesystem when possible;
%   2) reopen/validate that the variable "dataset" exists;
%   3) remove the old target only after the temporary file is valid;
%   4) move the validated temporary file into place.
%
% If any disk-I/O step still fails, return false and continue using the
% in-memory dataset for the current Part-1 run.

ok = false;
cacheDir = fileparts(cacheFile);
if ~exist(cacheDir,'dir'), mkdir(cacheDir); end
tmpFile = make_hdf5_safe_temp_mat_path(cacheFile);

try
    save(tmpFile,'dataset','-v7.3');

    probe = whos('-file',tmpFile);
    if ~any(string({probe.name}) == "dataset")
        error('generate_offline_trajectory_dataset:CacheValidation', ...
            'Temporary trajectory cache does not contain variable "dataset".');
    end

    if exist(cacheFile,'file') == 2
        try
            delete(cacheFile);
        catch MEdelete
            % A corrupt HDF5 target can occasionally be locked. Preserve it
            % under a diagnostic name if direct deletion fails.
            [folder,name,ext] = fileparts(cacheFile);
            quarantine = fullfile(folder,[name '_corrupt_old' ext]);
            try
                if exist(quarantine,'file') == 2
                    delete(quarantine);
                end
                [moved,msgMoveOld] = movefile(cacheFile,quarantine,'f');
                if ~moved
                    error('Could not remove/quarantine old cache: %s | %s', ...
                        MEdelete.message,msgMoveOld);
                end
            catch
                rethrow(MEdelete);
            end
        end
    end

    [moved,msg] = movefile(tmpFile,cacheFile,'f');
    if ~moved
        error('generate_offline_trajectory_dataset:CacheMove', ...
            'Could not install validated trajectory cache: %s',msg);
    end

    ok = true;

catch ME
    if exist(tmpFile,'file') == 2
        try, delete(tmpFile); catch, end %#ok<CTCH>
    end
    warning('generate_offline_trajectory_dataset:CacheSaveFailed', ...
        ['Trajectory dataset generation completed, but the cache could not ', ...
         'be written to disk. The experiment will CONTINUE using the in-memory ', ...
         'dataset.\n  Target: %s\n  Reason: %s'],cacheFile,ME.message);
end
end

function tf = cache_is_compatible(dataset,c,layout,cfg,Nmax,Kmax,L,useTestInitialAnchor)
tf = false;
try
    tf = strcmp(dataset.metadata.caseName,c.name) && ...
        dataset.metadata.N >= Nmax && ...
        dataset.metadata.nTrajectories >= Kmax && ...
        dataset.metadata.pointsPerTrajectory == L && ...
        size(dataset.features,1) >= Nmax && ...
        size(dataset.labelsClean,2) == layout.nx && ...
        isfield(dataset.metadata,'testInitialAnchor') && ...
        logical(dataset.metadata.testInitialAnchor.enabled) == logical(useTestInitialAnchor) && ...
        isequaln(dataset.metadata.samplingConfig,cfg.sampling) && ...
        isequaln(dataset.metadata.trajectoryConfig,trajectory_config(cfg,useTestInitialAnchor)) && ...
        isequaln(dataset.metadata.acceptanceConfig,acceptance_config(cfg)) && ...
        isequaln(dataset.metadata.sobolConfig,sobol_config(cfg)) && ...
        isfield(dataset.metadata,'cacheRevision') && ...
        strcmp(string(dataset.metadata.cacheRevision),get_cache_revision(cfg));
catch
    tf = false;
end
end


function revision = get_cache_revision(cfg)
%GET_CACHE_REVISION Optional physical/data-generation cache version tag.
revision = "";
if isfield(cfg,'data') && isfield(cfg.data,'cacheRevision') && ...
        ~isempty(cfg.data.cacheRevision)
    revision = string(cfg.data.cacheRevision);
end
if ~isscalar(revision)
    error('generate_offline_trajectory_dataset:CacheRevision', ...
        'cfg.data.cacheRevision must be a scalar string/char value.');
end
end

function s = trajectory_config(cfg,useTestInitialAnchor)
s.pointsPerTrajectory = cfg.data.pointsPerTrajectory;
s.sampleStep = cfg.data.trajectorySampleStep;
s.duration = cfg.data.trajectoryDuration;
s.truthRelTol = cfg.data.truthSegment.RelTol;
s.truthAbsTol = cfg.data.truthSegment.AbsTol;
s.truthMaxStep = cfg.data.truthSegment.MaxStep;
s.includeTestInitialAnchor = logical(useTestInitialAnchor);
s.testInitialAnchorInputMode = 'frozen_at_test_t0';
end

function s = acceptance_config(cfg)
s.voltageMin = cfg.data.acceptVoltageMinPU;
s.voltageMax = cfg.data.acceptVoltageMaxPU;
s.residualInf = cfg.data.acceptAlgebraicResidualInf;
end

function s = sobol_config(cfg)
s.skip = cfg.data.sobolSkip;
s.leap = cfg.data.sobolLeap;
s.scramble = cfg.data.sobolScramble;
if isfield(cfg,'randomSeed') && ~isempty(cfg.randomSeed)
    s.randomSeed = round(double(cfg.randomSeed));
else
    s.randomSeed = [];
end
end
