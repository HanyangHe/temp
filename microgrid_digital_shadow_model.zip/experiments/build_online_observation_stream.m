function obs = build_online_observation_stream(truth,noiseLevel,cfg)
%BUILD_ONLINE_OBSERVATION_STREAM Record the causal online measurement stream.
%
% The detector, module-local RLS updater, and candidate validator use this
% same observed stream. Training sees only data at or before the trigger; the
% candidate validator uses only later observations after the candidate is ready:
%   t, x(t), V(t), u(t), clean xdot(t), and noisy observed xdot(t).
%
% noiseLevel is a fraction, e.g. 0.001 = 0.1%.

validateattributes(noiseLevel,{'numeric'},{'scalar','real','nonnegative','finite'});

Y = truth.xdot.'; % nt x nx
scale = std(Y,0,1);
rmsScale = sqrt(mean(Y.^2,1));
scale = max(scale,0.05*rmsScale);
minimumScale = 1e-12;
if isfield(cfg,'noise') && isfield(cfg.noise,'minimumScale')
    minimumScale = cfg.noise.minimumScale;
end
scale = max(scale,minimumScale);

seed = 20260815;
if isfield(cfg,'online') && isfield(cfg.online,'observationNoiseSeed')
    seed = cfg.online.observationNoiseSeed;
elseif isfield(cfg,'noise') && isfield(cfg.noise,'seed')
    seed = cfg.noise.seed;
end

oldState = rng;
cleanup = onCleanup(@()rng(oldState)); %#ok<NASGU>
rng(seed,'twister');
E = randn(size(Y));
Yobs = Y + noiseLevel*(E.*scale);

obs = struct();
obs.t = truth.t(:);
obs.x = truth.x;
if isfield(truth,'z'), obs.z = truth.z; else, obs.z = []; end
obs.V = truth.V;
obs.inputs = truth.inputs;
obs.xdotClean = truth.xdot;
obs.xdotObserved = Yobs.';
obs.noiseLevel = noiseLevel;
obs.noisePercent = 100*noiseLevel;
obs.noiseScale = scale(:);
obs.noiseSeed = seed;
if isfield(truth,'parameters')
    obs.parameters = truth.parameters;
end
obs.metadata.purpose = [ ...
    "Recorded online x/V/u/xdot stream used by module-wise mismatch detection, local coefficient adaptation, and causal candidate validation."];
end
