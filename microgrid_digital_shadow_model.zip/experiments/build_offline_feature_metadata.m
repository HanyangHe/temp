function meta = build_offline_feature_metadata(c,layout)
%BUILD_OFFLINE_FEATURE_METADATA Deterministic [x,z,u] feature ordering.

stateNames = strings(layout.nx,1);
for k = 1:numel(c.sg)
    idx = layout.sg{k};
    if numel(idx) == 5
        stateNames(idx) = ["SG"+string(k)+"_delta"; "SG"+string(k)+"_nu"; ...
            "SG"+string(k)+"_EqPrime"; "SG"+string(k)+"_EdPrime"; ...
            "SG"+string(k)+"_Efd"];
    else
        stateNames(idx) = ["SG"+string(k)+"_delta"; "SG"+string(k)+"_nu"];
    end
end
for k = 1:numel(c.gfm)
    idx = layout.gfm{k};
    stateNames(idx) = ["GFM"+string(k)+"_delta"; "GFM"+string(k)+"_pFilt"; ...
        "GFM"+string(k)+"_qFilt"; "GFM"+string(k)+"_E"];
end
for k = 1:numel(c.gfl)
    idx = layout.gfl{k};
    stateNames(idx) = ["GFL"+string(k)+"_thetaPLL"; "GFL"+string(k)+"_xiPLL"; ...
        "GFL"+string(k)+"_id"; "GFL"+string(k)+"_iq"];
end

ns = c.network.nonSlackBuses(:);
zNames = ["V"+string(ns)+"_Re"; "V"+string(ns)+"_Im"];

uNames = strings(0,1);
for k = 1:numel(c.sg),  uNames(end+1,1) = "SG"+string(k)+"_Pm"; end %#ok<AGROW>
if isfield(c.input.nominal,'sgVref')
    for k = 1:numel(c.sg), uNames(end+1,1) = "SG"+string(k)+"_Vref"; end %#ok<AGROW>
end
for k = 1:numel(c.gfm), uNames(end+1,1) = "GFM"+string(k)+"_Pstar"; end %#ok<AGROW>
for k = 1:numel(c.gfm), uNames(end+1,1) = "GFM"+string(k)+"_Qstar"; end %#ok<AGROW>
for k = 1:numel(c.gfm), uNames(end+1,1) = "GFM"+string(k)+"_Eref"; end %#ok<AGROW>
for k = 1:numel(c.gfl), uNames(end+1,1) = "GFL"+string(k)+"_Pstar"; end %#ok<AGROW>
for k = 1:numel(c.gfl), uNames(end+1,1) = "GFL"+string(k)+"_Qstar"; end %#ok<AGROW>

loadBuses = find(abs(c.input.nominal.Sload) > 1e-12);
for k = 1:numel(loadBuses), uNames(end+1,1) = "LoadBus"+string(loadBuses(k))+"_P"; end %#ok<AGROW>
for k = 1:numel(loadBuses), uNames(end+1,1) = "LoadBus"+string(loadBuses(k))+"_Q"; end %#ok<AGROW>

meta.stateNames = stateNames;
meta.zNames = zNames;
meta.uNames = uNames;
meta.featureNames = [stateNames;zNames;uNames];
meta.labelNames = stateNames + "_dot";
meta.loadBuses = loadBuses(:);
meta.nFeatures = numel(meta.featureNames);
end
