function F = offline_fixed_input_truth_dae_residual(~,y,yp,uFixed,pNom,c,layout)
%OFFLINE_FIXED_INPUT_TRUTH_DAE_RESIDUAL Truth DAE for one short training segment.
%
% uFixed is the Sobol-sampled operating input for this trajectory. Physical
% parameters are held at their nominal values (offline Part 1 has no drift).

[x,V] = mg_unpack_dae_state(y,c,layout);
[f,g] = mg_evaluate_physics(x,V,uFixed,pNom,c,layout);
F = [yp(1:layout.nx)-f; real(g); imag(g)];
end
