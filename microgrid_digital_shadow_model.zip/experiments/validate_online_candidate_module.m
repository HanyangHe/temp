function validation = validate_online_candidate_module( ...
    initialModel,candidateModel,candidateReadyTime,detector,method, ...
    observations,cNominal,layout,cfg)
%VALIDATE_ONLINE_CANDIDATE_MODULE Causal post-training local-model guard.
%
% The candidate is not deployed immediately after computation. New measured
% samples arriving during a short validation interval are used to compare the
% old and candidate vector-field residuals on the localized DER module. Only
% after a configured improvement is observed is the candidate promoted.

opt = cfg.online.update.validation;
validation = struct();
validation.enabled = logical(opt.enabled);
validation.candidateReadyTime = candidateReadyTime;
validation.validationStartTime = NaN;
validation.validationEndTime = NaN;
validation.sampleCount = 0;
validation.currentModelScore = NaN;
validation.candidateModelScore = NaN;
validation.relativeImprovement = NaN;
validation.absoluteImprovement = NaN;
validation.accepted = false;
validation.activationTime = inf;
validation.reason = "not_evaluated";

if ~isfinite(candidateReadyTime)
    validation.reason = "candidate_not_ready";
    return;
end
if ~validation.enabled
    validation.accepted = candidateReadyTime <= observations.t(end)+1e-12;
    validation.activationTime = candidateReadyTime;
    validation.reason = "validation_disabled";
    return;
end

if ~isfield(detector,'affectedStateIndices') || isempty(detector.affectedStateIndices)
    validation.reason = "missing_localized_module";
    return;
end
stateIdx = detector.affectedStateIndices(:);
t = observations.t(:);
startIdx = find(t >= candidateReadyTime-1e-12,1,'first');
if isempty(startIdx)
    validation.reason = "candidate_ready_beyond_horizon";
    return;
end
startTime = t(startIdx);
targetEnd = startTime + double(opt.windowSeconds);
if t(end) < targetEnd-1e-12
    validation.reason = "validation_window_beyond_horizon";
    validation.validationStartTime = startTime;
    validation.validationEndTime = t(end);
    return;
end
endIdx = find(t <= targetEnd+1e-12,1,'last');
idx = (startIdx:endIdx).';
if numel(idx) < opt.minimumSamples
    validation.reason = "too_few_validation_samples";
    validation.validationStartTime = startTime;
    validation.validationEndTime = t(endIdx);
    validation.sampleCount = numel(idx);
    return;
end

scale = detector.normalizationScale(stateIdx);
scale = max(abs(scale),cfg.online.update.detector.scaleFloor);
oldSq = nan(numel(idx),1);
newSq = nan(numel(idx),1);
for ii=1:numel(idx)
    k = idx(ii);
    u = online_input_at_observation(observations,k);
    try
        f0 = method.predictFcn(initialModel,t(k),observations.x(:,k), ...
            observations.V(:,k),u,cNominal,layout);
        r0 = (observations.xdotObserved(stateIdx,k)-f0(stateIdx))./scale;
        oldSq(ii)=mean(r0.^2);
    catch
        oldSq(ii)=inf;
    end
    try
        f1 = method.predictFcn(candidateModel,t(k),observations.x(:,k), ...
            observations.V(:,k),u,cNominal,layout);
        r1 = (observations.xdotObserved(stateIdx,k)-f1(stateIdx))./scale;
        newSq(ii)=mean(r1.^2);
    catch
        newSq(ii)=inf;
    end
end

oldScore = rms_from_sq(oldSq);
newScore = rms_from_sq(newSq);
validation.validationStartTime = t(idx(1));
validation.validationEndTime = t(idx(end));
validation.sampleCount = numel(idx);
validation.currentModelScore = oldScore;
validation.candidateModelScore = newScore;
validation.absoluteImprovement = oldScore-newScore;
if isfinite(oldScore) && oldScore>eps
    validation.relativeImprovement = (oldScore-newScore)/oldScore;
elseif isinf(oldScore) && isfinite(newScore)
    validation.relativeImprovement = inf;
end

requiredRel = double(opt.requiredRelativeImprovement);
requiredAbs = double(opt.requiredAbsoluteImprovement);
if isfinite(newScore) && ...
        ((isinf(oldScore)) || ...
         (validation.relativeImprovement >= requiredRel && ...
          validation.absoluteImprovement >= requiredAbs))
    validation.accepted = true;
    validation.activationTime = t(idx(end));
    validation.reason = "accepted";
else
    validation.reason = "insufficient_improvement";
end
end

function value = rms_from_sq(v)
if any(isinf(v))
    value = inf;
    return;
end
v = v(isfinite(v));
if isempty(v)
    value = inf;
else
    value = sqrt(mean(v));
end
end
