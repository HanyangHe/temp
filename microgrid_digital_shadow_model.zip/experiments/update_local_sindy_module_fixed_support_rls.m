function [candidateModel,info] = update_local_sindy_module_fixed_support_rls( ...
    initialModel,offlineData,onlineData,method,cfg)
%UPDATE_LOCAL_SINDY_MODULE_FIXED_SUPPORT_RLS Fast local SINDy coefficient update.
%
% The previously learned dictionary (including any compiled LLM-prior bank),
% neural ridge bank, sparse support, and
% all untouched DER modules are frozen. Only the coefficients of one affected
% module are adapted. The update starts from the saved offline coefficients and
% applies exponentially weighted RLS to causal online samples. The original
% nominal feature matrix contributes only to covariance initialization; its
% stale targets are not re-fitted into the new model.

name = lower(string(method.name));
sindyFamily = ["vanilla_sindy","physics_embedded_sindy", ...
    "neural_sindy","physics_neural_sindy","llm_prior_sindy"];
if ~any(name==sindyFamily)
    error('update_local_sindy_module_fixed_support_rls:MethodFamily', ...
        'Fast fixed-support RLS is implemented for the SINDy family only.');
end

rls = cfg.online.update.localRLS;
deviceType = lower(string(onlineData.deviceType));
deviceIndex = onlineData.deviceIndex;
if ~isfield(initialModel,char(deviceType)) || ...
        deviceIndex<1 || deviceIndex>numel(initialModel.(char(deviceType)))
    error('update_local_sindy_module_fixed_support_rls:ModuleIndex', ...
        'Requested %s%d module is not present in the saved model.', ...
        upper(char(deviceType)),deviceIndex);
end
module0 = initialModel.(char(deviceType))(deviceIndex);

[ThetaOff,namesOff] = evaluate_stored_library(module0,offlineData,initialModel,name);
[ThetaOn,namesOn] = evaluate_stored_library(module0,onlineData,initialModel,name);
if numel(namesOff)~=numel(module0.libraryNames) || ...
        any(string(namesOff(:))~=string(module0.libraryNames(:))) || ...
        numel(namesOn)~=numel(module0.libraryNames) || ...
        any(string(namesOn(:))~=string(module0.libraryNames(:)))
    error('update_local_sindy_module_fixed_support_rls:LibraryOrder', ...
        'Stored and online local library columns are inconsistent.');
end

C0 = double(module0.coefficients);
[nTerms,nOut] = size(C0);
if size(ThetaOff,2)~=nTerms || size(ThetaOn,2)~=nTerms
    error('update_local_sindy_module_fixed_support_rls:LibraryWidth', ...
        'Library width does not match saved coefficient rows.');
end
if size(onlineData.Y,2)~=nOut
    error('update_local_sindy_module_fixed_support_rls:OutputWidth', ...
        'Online target width does not match saved coefficient outputs.');
end

colScale = double(module0.libraryColumnScale(:));
yScale = double(module0.outputScale(:));
if numel(colScale)~=nTerms || numel(yScale)~=nOut
    error('update_local_sindy_module_fixed_support_rls:Normalization', ...
        'Saved module normalization metadata are incomplete.');
end
colScale = max(abs(colScale),eps);
yScale = max(abs(yScale),eps);
PhiOff = double(ThetaOff)./colScale.';
PhiOn = double(ThetaOn)./colScale.';
BOn = double(onlineData.Y)./yScale.';

supportTol = double(rls.supportTolerance);
if supportTol<=0
    supportMask = (C0~=0);
else
    ref = max(abs(C0),[],1);
    ref = max(ref,1);
    supportMask = abs(C0) > supportTol.*ref;
end

halfLife = double(rls.forgettingHalfLifeSeconds);
if ~isfinite(halfLife) || halfLife<=0
    error('update_local_sindy_module_fixed_support_rls:HalfLife', ...
        'localRLS.forgettingHalfLifeSeconds must be positive and finite.');
end
sampleStep = double(cfg.online.update.sampleStep);
gamma = exp(log(0.5)*sampleStep/halfLife);
gamma = min(max(gamma,1e-6),1);
offlineWeight = max(0,double(rls.offlineDataWeight));
onlineWeight = 1.0;
if isfield(rls,'onlineSampleWeight') && ~isempty(rls.onlineSampleWeight)
    onlineWeight = double(rls.onlineSampleWeight);
end
if ~isfinite(onlineWeight) || onlineWeight<=0
    error('update_local_sindy_module_fixed_support_rls:OnlineSampleWeight', ...
        'localRLS.onlineSampleWeight must be positive and finite.');
end
priorPrecision = max(0,double(rls.priorPrecision));
jitter = max(0,double(rls.covarianceJitter));

Cnew = C0;
rlsRowsProcessed = size(PhiOn,1);
conditionNumbers = nan(nOut,1);
activeCounts = zeros(nOut,1);
innovationRms = nan(nOut,1);

for j=1:nOut
    active = find(supportMask(:,j));
    activeCounts(j)=numel(active);
    if isempty(active)
        continue;
    end

    % Convert saved physical-unit coefficients back to the normalized
    % coordinates used by the original STLSQ fit.
    theta = C0(active,j).*colScale(active)./yScale(j);

    % Nominal offline rows shape the initial covariance but the saved model
    % remains the prior mean. This avoids pulling the new coefficients back
    % toward stale offline targets while retaining conditioning information.
    G = priorPrecision*eye(numel(active));
    if offlineWeight>0 && ~isempty(PhiOff)
        Aoff = PhiOff(:,active);
        G = G + offlineWeight*(Aoff.'*Aoff);
    end
    if jitter>0
        G = G + jitter*eye(size(G));
    end
    conditionNumbers(j)=cond(G);
    P = G\eye(size(G));

    err2 = zeros(size(PhiOn,1),1);
    for i=1:size(PhiOn,1)
        phi = PhiOn(i,active).';
        yi = BOn(i,j);
        % Weighted RLS: scaling an online sample by sqrt(onlineWeight)
        % gives the exact gain below. onlineWeight=1 reproduces the previous
        % implementation; values >1 make new physical observations more
        % influential relative to the offline covariance initialization.
        q = phi.'*P*phi;
        denom = gamma + onlineWeight*q;
        if ~isfinite(denom) || denom<=eps
            continue;
        end
        K = onlineWeight*(P*phi)/denom;
        innovation = yi - phi.'*theta;
        theta = theta + K*innovation;
        P = (P - K*(phi.'*P))/gamma;
        % Numerical symmetrization keeps roundoff from accumulating.
        P = 0.5*(P+P.');
        err2(i)=innovation.^2;
    end
    innovationRms(j)=sqrt(mean(err2));
    Cnew(active,j) = theta.*yScale(j)./colScale(active);
    % Support is intentionally fixed: coefficients outside the saved support
    % remain exactly zero.
    Cnew(~supportMask(:,j),j)=0;
end

module1 = module0;
module1.coefficients = Cnew;
module1.onlineUpdateStrategy = 'module_local_fixed_support_rls';
module1.onlineSupportFrozen = true;
module1.onlineForgettingFactor = gamma;
module1.onlineForgettingHalfLifeSeconds = halfLife;
module1.onlineOfflineDataWeight = offlineWeight;
module1.onlineSampleWeight = onlineWeight;
module1.onlinePriorPrecision = priorPrecision;
module1.onlineUpdateSampleCount = size(PhiOn,1);
module1.onlineUpdateTimestamp = datetime('now');
module1.activeCoefficientCount = nnz(Cnew~=0);
if isfield(module1,'physicsPriorFeatureMask') && ...
        numel(module1.physicsPriorFeatureMask)==size(Cnew,1)
    pm = repmat(logical(module1.physicsPriorFeatureMask(:)),1,size(Cnew,2));
    module1.activePhysicsCoefficientCount = nnz((Cnew~=0)&pm);
    module1.activeGenericCoefficientCount = nnz((Cnew~=0)&~pm);
end

candidateModel = initialModel;
% IMPORTANT: update the target module field-by-field rather than assigning
% module1 back into one element of an existing struct array. module1 contains
% online-update metadata fields that are not present in the saved offline
% module schema. MATLAB rejects direct element replacement in that situation
% with "Subscripted assignment between dissimilar structures."
moduleField = char(deviceType);
moduleArray = candidateModel.(moduleField);
moduleArray(deviceIndex).coefficients = module1.coefficients;
moduleArray(deviceIndex).onlineUpdateStrategy = module1.onlineUpdateStrategy;
moduleArray(deviceIndex).onlineSupportFrozen = module1.onlineSupportFrozen;
moduleArray(deviceIndex).onlineForgettingFactor = module1.onlineForgettingFactor;
moduleArray(deviceIndex).onlineForgettingHalfLifeSeconds = module1.onlineForgettingHalfLifeSeconds;
moduleArray(deviceIndex).onlineOfflineDataWeight = module1.onlineOfflineDataWeight;
moduleArray(deviceIndex).onlineSampleWeight = module1.onlineSampleWeight;
moduleArray(deviceIndex).onlinePriorPrecision = module1.onlinePriorPrecision;
moduleArray(deviceIndex).onlineUpdateSampleCount = module1.onlineUpdateSampleCount;
moduleArray(deviceIndex).onlineUpdateTimestamp = module1.onlineUpdateTimestamp;
moduleArray(deviceIndex).activeCoefficientCount = module1.activeCoefficientCount;
if isfield(module1,'activePhysicsCoefficientCount')
    moduleArray(deviceIndex).activePhysicsCoefficientCount = module1.activePhysicsCoefficientCount;
end
if isfield(module1,'activeGenericCoefficientCount')
    moduleArray(deviceIndex).activeGenericCoefficientCount = module1.activeGenericCoefficientCount;
end
candidateModel.(moduleField) = moduleArray;
candidateModel.onlineUpdateStrategy = 'module_local_fixed_support_rls';
candidateModel.onlineUpdatedDeviceType = char(deviceType);
candidateModel.onlineUpdatedDeviceIndex = deviceIndex;

info = struct();
info.strategy = 'module_local_fixed_support_rls';
info.deviceType = char(deviceType);
info.deviceIndex = deviceIndex;
info.supportFrozen = true;
info.outputCount = nOut;
info.activeCoefficientCountByOutput = activeCounts;
info.totalActiveCoefficientCount = nnz(supportMask);
info.onlineSampleCount = size(PhiOn,1);
info.offlineCovarianceSampleCount = size(PhiOff,1);
info.forgettingFactorPerSample = gamma;
info.forgettingHalfLifeSeconds = halfLife;
info.offlineDataWeight = offlineWeight;
info.onlineSampleWeight = onlineWeight;
info.priorPrecision = priorPrecision;
info.initialInformationConditionNumber = conditionNumbers;
info.innovationRMSNormalized = innovationRms;
info.libraryNames = string(module0.libraryNames(:));
end

function [Theta,names] = evaluate_stored_library(module,data,model,methodName)
if any(methodName==["neural_sindy","physics_neural_sindy"])
    [Theta,names] = build_neural_sindy_library( ...
        data.X,module.inputNames,module.deviceType,module.variant,model.options, ...
        module.neuralBasisSeed,module.librarySpec);
else
    [Theta,names] = build_sindy_library( ...
        data.X,module.inputNames,module.deviceType,module.variant,model.options, ...
        module.librarySpec);
end
end
