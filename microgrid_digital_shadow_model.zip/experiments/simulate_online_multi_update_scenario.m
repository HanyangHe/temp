function prediction = simulate_online_multi_update_scenario( ...
    initialModel,updatedModels,activationTimes,method,truth,cNominal,layout,cfg,varargin)
%SIMULATE_ONLINE_MULTI_UPDATE_SCENARIO Piecewise rollout with model switching.
%
% Stage-3 extension:
%   StateSynchronization = true  -> at every accepted activation, reset the
%                                   digital state to the measured/reference
%                                   state before using the new model.
%   StateSynchronization = false -> switch model coefficients at the same
%                                   activation times but continue from the
%                                   digital shadow's own predicted state.
%
% The same routine also supports the frozen+sync ablation by passing the
% unchanged initialModel in updatedModels for every activation time.

p = inputParser;
p.FunctionName = mfilename;
addParameter(p,'StateSynchronization',[],@(x)islogical(x) || (isnumeric(x) && isscalar(x)));
parse(p,varargin{:});
stateSync = p.Results.StateSynchronization;
if isempty(stateSync)
    stateSync = true;
    if isfield(cfg,'online') && isfield(cfg.online,'update') && ...
            isfield(cfg.online.update,'stateSynchronizationAtActivation')
        stateSync = logical(cfg.online.update.stateSynchronizationAtActivation);
    end
end
stateSync = logical(stateSync);

if isempty(updatedModels) || isempty(activationTimes)
    prediction = simulate_online_frozen_model_scenario( ...
        initialModel,method,truth,cNominal,layout,cfg);
    prediction.metadata.onlineMode='online_no_activation';
    prediction.metadata.stateResynchronizedAtActivation=false;
    prediction.metadata.modelActivationTimeSeconds=[];
    return;
end

activationTimes = double(activationTimes(:));
[activationTimes,order] = sort(activationTimes);
updatedModels = updatedModels(order);

% Remove non-finite/duplicate activation times while preserving the matching
% updated model for the first occurrence of each physical activation time.
valid = isfinite(activationTimes) & ...
    activationTimes >= truth.t(1)-1e-12 & activationTimes <= truth.t(end)+1e-12;
activationTimes = activationTimes(valid);
updatedModels = updatedModels(valid);
if isempty(activationTimes)
    prediction = simulate_online_frozen_model_scenario( ...
        initialModel,method,truth,cNominal,layout,cfg);
    prediction.metadata.onlineMode='online_no_activation';
    prediction.metadata.stateResynchronizedAtActivation=false;
    prediction.metadata.modelActivationTimeSeconds=[];
    return;
end

[activationTimes,ia] = unique(activationTimes,'stable');
updatedModels = updatedModels(ia);

currentModel = initialModel;
currentIndex = 1;
currentState = truth.y(1,:).';
usedActs = zeros(0,1);
solveTime = 0;
allSucceeded = true;

pieces = cell(0,1);

for j = 1:numel(activationTimes)
    idxAct = find(truth.t >= activationTimes(j)-1e-12,1,'first');
    if isempty(idxAct) || idxAct < currentIndex || idxAct > numel(truth.t)
        continue;
    end

    % Propagate the currently active model up to the activation instant. The
    % endpoint supplies the carry-over state for the no-synchronization branch.
    if idxAct > currentIndex
        subTruth = trim_truth(truth,currentIndex,idxAct);
        part = simulate_offline_model_scenario( ...
            currentModel,method,subTruth,cNominal,layout,cfg, ...
            'InitialState',currentState);
        pieces{end+1,1} = part; %#ok<AGROW>
        solveTime = solveTime + get_meta(part,'modelSolveTimeSeconds',0);
        if ~get_meta(part,'rolloutSucceeded',false)
            allSucceeded = false;
            break;
        end
        carryState = part.y(end,:).';
    else
        carryState = currentState;
    end

    % The model switch occurs at the accepted activation instant. The only
    % difference between the two Stage-3 adaptation ablations is whether the
    % state is synchronized here.
    if stateSync
        currentState = truth.y(idxAct,:).';
    else
        currentState = carryState;
    end
    currentModel = updatedModels{j};
    currentIndex = idxAct;
    usedActs(end+1,1) = truth.t(idxAct); %#ok<AGROW>
end

% Complete the remaining horizon with the last active model.
if allSucceeded && currentIndex <= numel(truth.t)
    subTruth = trim_truth(truth,currentIndex,numel(truth.t));
    part = simulate_offline_model_scenario( ...
        currentModel,method,subTruth,cNominal,layout,cfg, ...
        'InitialState',currentState);
    pieces{end+1,1} = part; %#ok<AGROW>
    solveTime = solveTime + get_meta(part,'modelSolveTimeSeconds',0);
    allSucceeded = allSucceeded && get_meta(part,'rolloutSucceeded',false);
end

[tCombined,yCombined] = concatenate_pieces_replace_boundary(pieces);
if isempty(tCombined)
    prediction = simulate_online_frozen_model_scenario( ...
        initialModel,method,truth,cNominal,layout,cfg);
    prediction.metadata.onlineMode='online_piecewise_empty_fallback';
    prediction.metadata.stateResynchronizedAtActivation=stateSync;
    prediction.metadata.modelActivationTimeSeconds=usedActs(:).';
    return;
end

prediction = mg_postprocess_solution(tCombined,yCombined,cNominal,layout);
prediction.metadata.methodName = method.name;
prediction.metadata.methodDisplayName = method.displayName;
if stateSync
    prediction.metadata.onlineMode = 'module_local_corrected_multi_stage_with_state_sync';
else
    prediction.metadata.onlineMode = 'module_local_corrected_multi_stage_without_state_sync';
end
prediction.metadata.modelActivationTimeSeconds = usedActs(:).';
prediction.metadata.stateResynchronizedAtActivation = stateSync;
prediction.metadata.modelSolveTimeSeconds = solveTime;
prediction.metadata.requestedTimePointCount = numel(truth.t);
prediction.metadata.requestedTimeStart = truth.t(1);
prediction.metadata.requestedTimeEnd = truth.t(end);
prediction.metadata.availableTimePointCount = numel(tCombined);
prediction.metadata.trajectoryCoveragePercent = 100*numel(tCombined)/numel(truth.t);
prediction.metadata.rolloutSucceeded = allSucceeded && ...
    numel(tCombined)==numel(truth.t) && abs(tCombined(end)-truth.t(end))<=1e-10;
if prediction.metadata.rolloutSucceeded
    prediction.metadata.rolloutStatus = "SUCCESS";
    prediction.metadata.failureTimeSeconds = NaN;
    prediction.metadata.failureMessage = "";
else
    prediction.metadata.rolloutStatus = "FAILED_DURING_MULTI_STAGE_ONLINE_UPDATE";
    prediction.metadata.failureTimeSeconds = tCombined(end);
    prediction.metadata.failureMessage = ...
        "One or more rollout segments failed during the multi-stage online simulation.";
end
end

function [tCombined,yCombined] = concatenate_pieces_replace_boundary(pieces)
% At a repeated activation time, keep the FIRST point of the newly activated
% segment. This is essential for the state-synchronization ablation because
% that point contains the measured-state reset. In the no-sync branch the new
% first point equals the carried state, so the operation remains continuous.
tCombined = zeros(0,1);
yCombined = zeros(0,0);
for i=1:numel(pieces)
    P = pieces{i};
    if isempty(P) || ~isfield(P,'t') || isempty(P.t)
        continue;
    end
    tPart = P.t(:);
    yPart = P.y;
    if isempty(tCombined)
        tCombined = tPart;
        yCombined = yPart;
    else
        if abs(tCombined(end)-tPart(1))<=1e-12
            tCombined(end) = [];
            yCombined(end,:) = [];
        end
        tCombined = [tCombined;tPart]; %#ok<AGROW>
        yCombined = [yCombined;yPart]; %#ok<AGROW>
    end
end
end

function S = trim_truth(truth,i1,i2)
S=struct();
S.t=truth.t(i1:i2);
S.y=truth.y(i1:i2,:);
end

function value = get_meta(P,name,defaultValue)
value=defaultValue;
if isstruct(P) && isfield(P,'metadata') && isstruct(P.metadata) && isfield(P.metadata,name)
    v = P.metadata.(name);
    if ~isempty(v), value=v; end
end
end
