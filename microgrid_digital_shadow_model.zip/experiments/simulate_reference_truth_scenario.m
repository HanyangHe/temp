function results = simulate_reference_truth_scenario(c,layout)
%SIMULATE_REFERENCE_TRUTH_SCENARIO Solve and validate the common truth trajectory.
%
% v1p21: ODE15I can return only an integrated prefix after a warning instead
% of throwing an exception. A one-point prefix must never be reported as a
% successfully solved truth trajectory. This function now captures the
% solver warning and requires completion of the entire requested output grid.

[y0,yp0,initInfo] = initialize_reference_equilibrium(c,layout);
residual = @(t,y,yp)mg_dae_residual(t,y,yp,c,layout);

tout = (c.sim.t0:c.sim.outputStep:c.sim.tf).';
if isempty(tout) || abs(tout(end)-c.sim.tf) > 10*eps(max(1,abs(c.sim.tf)))
    tout(end+1,1) = c.sim.tf;
end
if numel(tout) < 2
    error('simulate_reference_truth_scenario:InvalidTimeGrid', ...
        'The configured truth time grid must contain at least two points.');
end

opts = odeset('RelTol',c.sim.RelTol, ...
              'AbsTol',c.sim.AbsTol, ...
              'MaxStep',c.sim.MaxStep, ...
              'Stats','off');

lastwarn('');
tStart = tic;
[t,y] = ode15i(residual,tout,y0,yp0,opts);
solveTime = toc(tStart);
[warnMsg,warnID] = lastwarn;

timeTol = max(1e-10,100*eps(max(1,abs(tout(end)))));
reachedEnd = ~isempty(t) && abs(t(end)-tout(end)) <= timeTol;
sameCount = numel(t) == numel(tout);

if ~(reachedEnd && sameCount)
    if isempty(t)
        reachedTime = c.sim.t0;
    else
        reachedTime = t(end);
    end
    if isempty(warnMsg)
        warnMsg = 'ODE15I returned an incomplete truth trajectory without a warning message.';
    end
    error('simulate_reference_truth_scenario:IncompleteTruthTrajectory', ...
        ['The physical truth DAE did not complete the requested scenario. ', ...
         'ODE15I returned %d/%d saved points and stopped at t=%.9g s ', ...
         '(requested %.9g s). Solver warning: %s'], ...
         numel(t),numel(tout),reachedTime,tout(end),warnMsg);
end

results = mg_postprocess_solution(t,y,c,layout);
results.metadata.solveTimeSeconds = solveTime;
results.metadata.initialization = initInfo;
results.metadata.caseData = c;
results.metadata.solverWarningID = string(warnID);
results.metadata.solverWarningMessage = string(warnMsg);
results.metadata.requestedSavedPointCount = numel(tout);
results.metadata.completedSavedPointCount = numel(t);
results.metadata.completedHorizon = true;
end
