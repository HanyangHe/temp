function F = offline_model_dae_residual(t,y,yp,model,method,c,layout)
%OFFLINE_MODEL_DAE_RESIDUAL DAE residual with learned/oracle vector field.
%
% Differential block: xdot - f_hat(x,z,u) = 0
% Algebraic block:    g(x,z,u) = 0
%
% Part 1 assumes the algebraic network/terminal constraints are known and
% shared by all vector-field comparison methods. Hidden parameter drift is
% intentionally disabled in the offline experiments.

[x,V] = mg_unpack_dae_state(y,c,layout);
u = mg_input_profile(t,c);
fhat = method.predictFcn(model,t,x,V,u,c,layout);

pNow = mg_parameter_profile(t,c);
[~,g] = mg_evaluate_physics(x,V,u,pNow,c,layout);

F = [yp(1:layout.nx)-fhat;real(g);imag(g)];
end
