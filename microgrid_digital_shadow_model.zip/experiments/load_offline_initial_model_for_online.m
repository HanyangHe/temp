function [model,trainInfo,source] = load_offline_initial_model_for_online( ...
    projectRoot,method,cfg,N,noiseLevel)
%LOAD_OFFLINE_INITIAL_MODEL_FOR_ONLINE Load the frozen t=0 digital model.
%
% The online experiment intentionally starts from an already prepared
% offline model. It does not silently retrain a replacement model. The exact
% requested method/N/noise condition must exist in that method's independent
% offline replay bundle.

if ~isfield(cfg,'online') || ~isfield(cfg.online,'offlineOutputFolder')
    error('load_offline_initial_model_for_online:OfflineFolder', ...
        'cfg.online.offlineOutputFolder is required.');
end

methodFolder = 'method_results';
if isfield(cfg,'output') && isfield(cfg.output,'methodResultsFolder') && ...
        ~isempty(cfg.output.methodResultsFolder)
    methodFolder = char(string(cfg.output.methodResultsFolder));
end

replayName = 'offline_part1_method_replay.mat';
if isfield(cfg,'output') && isfield(cfg.output,'methodReplayFileName') && ...
        ~isempty(cfg.output.methodReplayFileName)
    replayName = char(string(cfg.output.methodReplayFileName));
end

offlineRoot = fullfile(projectRoot,'outputs',char(string(cfg.online.offlineOutputFolder)));
if isfield(cfg.online,'initialModelSeed') && ~isempty(cfg.online.initialModelSeed)
    offlineRoot = fullfile(offlineRoot,'seed_runs', ...
        sprintf('seed_%d',round(double(cfg.online.initialModelSeed))));
end
bundlePath = fullfile(offlineRoot,methodFolder, ...
    char(string(method.name)),replayName);

if exist(bundlePath,'file') ~= 2
    error('load_offline_initial_model_for_online:MissingBundle', ...
        ['Required offline model bundle was not found:\n  %s\n', ...
         'Run/save the corresponding offline method before this online experiment.'], ...
        bundlePath);
end

S = load_mat_long_path_safe(bundlePath,'methodBundle');
if ~isfield(S,'methodBundle') || ~isstruct(S.methodBundle)
    error('load_offline_initial_model_for_online:InvalidBundle', ...
        'File does not contain a valid methodBundle: %s',bundlePath);
end
B = S.methodBundle;

% Compatibility is checked after the exact method/N/noise model is selected.
% A framework-wide formulationVersion string is intentionally not used as a
% gate because it can change when another baseline is renamed or revised.

if ~isfield(B,'evaluationCache') || ~isfield(B.evaluationCache,'entries') || ...
        isempty(B.evaluationCache.entries)
    error('load_offline_initial_model_for_online:MissingCache', ...
        'Offline bundle has no evaluation cache containing trained models: %s',bundlePath);
end

E = B.evaluationCache.entries;
match = false(numel(E),1);
for k = 1:numel(E)
    sameMethod = isfield(E(k),'methodName') && ...
        strcmp(char(string(E(k).methodName)),char(string(method.name)));
    sameN = isfield(E(k),'sampleCount') && double(E(k).sampleCount)==double(N);
    sameNoise = isfield(E(k),'noiseLevel') && ...
        abs(double(E(k).noiseLevel)-double(noiseLevel)) <= ...
        max(1e-14,1e-10*max(1,abs(double(noiseLevel))));
    match(k) = sameMethod && sameN && sameNoise;
end
idx = find(match,1,'first');

if isempty(idx)
    avail = strings(numel(E),1);
    for k=1:numel(E)
        avail(k) = sprintf('N=%d, noise=%.6g%%', ...
            E(k).sampleCount,100*E(k).noiseLevel);
    end
    error('load_offline_initial_model_for_online:ConditionMissing', ...
        ['Offline bundle does not contain %s at N=%d, noise=%.6g%%.\n', ...
         'Available saved conditions include:\n  %s'], ...
        method.displayName,N,100*noiseLevel,strjoin(unique(avail,'stable'),'\n  '));
end

EV = E(idx).evaluation;
if ~isfield(EV,'model') || isempty(EV.model)
    error('load_offline_initial_model_for_online:ModelMissing', ...
        'Matched offline evaluation does not contain a trained model.');
end
model = EV.model;
if isfield(EV,'trainInfo'), trainInfo = EV.trainInfo; else, trainInfo = struct(); end

% Fundamental compatibility rule: validate the requested saved model from its
% own mathematical/numerical contract, not from a global SINDy campaign tag.
% This accepts an older bundle only when the requested method itself is
% equivalent to the current implementation (solver, dictionary, priors,
% neural basis, normalization/selection settings, and concrete phys_* terms).
if contains(lower(string(method.name)),'sindy')
    methodName = lower(string(method.name));
    if methodName == "llm_prior_sindy"
        [isCompatible,compatibility] = check_llm_prior_sindy_model_compatibility(model,cfg);
    else
        [isCompatible,compatibility] = check_sindy_model_compatibility( ...
            char(string(method.name)),model,cfg);
    end
    if ~isCompatible
        issueText = strjoin(string(compatibility.issues),sprintf('\n  - '));
        error('load_offline_initial_model_for_online:MethodCompatibilityMismatch', ...
            ['The saved offline %s model is not mathematically compatible with ', ...
             'the current implementation.\n  - %s\n', ...
             'Saved provenance tag: %s\nCurrent provenance tag: %s\n', ...
             'Rerun only this offline method/condition before using it online.'], ...
            method.displayName,issueText,compatibility.savedFormulationVersion, ...
            compatibility.currentFormulationVersion);
    end
    if methodName ~= "llm_prior_sindy"
        model = canonicalize_loaded_sindy_model( ...
            char(string(method.name)),model,compatibility);
    end
else
    compatibility = struct();
end

source = struct();
source.bundlePath = bundlePath;
source.methodName = char(string(method.name));
source.displayName = char(string(method.displayName));
source.sampleCount = N;
source.noiseLevel = noiseLevel;
source.noisePercent = 100*noiseLevel;
source.cacheKey = '';
if isfield(E(idx),'key'), source.cacheKey = E(idx).key; end
source.offlineTrainingTimeSeconds = NaN;
if isfield(EV,'trainingTimeSeconds')
    source.offlineTrainingTimeSeconds = EV.trainingTimeSeconds;
end
if contains(lower(string(method.name)),'sindy')
    source.compatibilitySchema = compatibility.schemaVersion;
    source.savedFormulationVersion = char(compatibility.savedFormulationVersion);
    source.currentFormulationVersion = char(compatibility.currentFormulationVersion);
    source.methodSpecificCompatibilityVerified = logical(compatibility.compatible);
    source.storedModelVariant = char(string(compatibility.storedModelVariant));
    source.canonicalModelVariant = char(string(compatibility.canonicalModelVariant));
    source.legacyVariantAliasApplied = logical(compatibility.legacyVariantAliasApplied);
end
end
