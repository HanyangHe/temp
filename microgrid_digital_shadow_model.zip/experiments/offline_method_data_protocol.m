function protocol = offline_method_data_protocol(dataset,method)
%OFFLINE_METHOD_DATA_PROTOCOL Information protocol actually consumed by a method.
%
% The official manuscript runner treats the Section 1.3 eta=0 point as the
% already-computed clean N=500 anchor and therefore passes the untouched clean
% dataset to this helper. Positive-noise conditions carry an explicit measured-
% state protocol tag and remain scientifically distinct from clean exact-xdot
% evaluations. NODE and weak-form SINDy consume grouped trajectories directly.

methodName = "";
if isstruct(method) && isfield(method,'name')
    methodName = string(method.name);
end

if any(strcmpi(methodName,["neural_ode_modular","weak_sindy", ...
        "weak_physics_neural_sindy"]))
    protocol = "grouped_state_trajectory_v1";
    return;
end

protocol = "clean_exact_vector_field";
if isstruct(dataset) && isfield(dataset,'metadata') && ...
        isstruct(dataset.metadata) && ...
        isfield(dataset.metadata,'trainingNoiseProtocol') && ...
        strlength(string(dataset.metadata.trainingNoiseProtocol)) > 0
    protocol = string(dataset.metadata.trainingNoiseProtocol);
end
end
