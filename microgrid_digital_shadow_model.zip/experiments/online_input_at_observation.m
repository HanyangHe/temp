function u = online_input_at_observation(observations,k)
%ONLINE_INPUT_AT_OBSERVATION Reconstruct one measured input struct at sample k.

if k < 1 || k > numel(observations.t)
    error('online_input_at_observation:Index','Sample index %d is out of range.',k);
end
I = observations.inputs;
u = struct();
copyField('sgPm');
copyField('sgVref');
copyField('gfmPstar');
copyField('gfmQstar');
copyField('gfmEref');
copyField('gflPstar');
copyField('gflQstar');
if isfield(I,'loadP') && isfield(I,'loadQ') && ~isempty(I.loadP)
    u.Sload = I.loadP(:,k) + 1i*I.loadQ(:,k);
end

    function copyField(name)
        if isfield(I,name) && ~isempty(I.(name))
            u.(name) = I.(name)(:,k);
        end
    end
end
