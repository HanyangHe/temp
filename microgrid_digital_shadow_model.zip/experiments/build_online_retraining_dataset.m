function [aug,info] = build_online_retraining_dataset( ...
    base,observations,triggerTime,cfg)
%BUILD_ONLINE_RETRAINING_DATASET Mix nominal and recent online pointwise data.
%
% Online rows are selected only at times <= triggerTime. Recency weighting is
% realized by deterministic integer row replication, preserving the original
% pointwise regression/STLSQ solvers while increasing the penalty on recent
% online residuals.

if ~isfinite(triggerTime)
    error('build_online_retraining_dataset:TriggerTime', ...
        'A finite triggerTime is required for online retraining.');
end

uopt = cfg.online.update;
t = observations.t(:);
startTime = t(1);
if isfinite(uopt.historyWindowSeconds)
    startTime = max(startTime,triggerTime-double(uopt.historyWindowSeconds));
end

step = double(uopt.sampleStep);
if step <= 0
    error('build_online_retraining_dataset:SampleStep','sampleStep must be positive.');
end
candidate = find(t >= startTime-1e-12 & t <= triggerTime+1e-12);
if isempty(candidate)
    error('build_online_retraining_dataset:NoSamples','No online samples precede the trigger.');
end
% Select samples by nearest multiples of sampleStep from the first retained time.
t0 = t(candidate(1));
phase = round((t(candidate)-t0)/step);
target = t0 + phase*step;
tol = max(1e-9,0.25*median(diff(t)));
keep = abs(t(candidate)-target) <= tol;
idx = candidate(keep);
if numel(idx) < uopt.minimumOnlineSamples
    error('build_online_retraining_dataset:TooFewSamples', ...
        ['Only %d online samples are available at trigger t=%.6g s; ', ...
         'minimumOnlineSamples=%d. Increase minimumTriggerTime or reduce sampleStep.'], ...
        numel(idx),triggerTime,uopt.minimumOnlineSamples);
end

wopt = uopt.weighting;
if ~strcmpi(string(wopt.mode),'integer_replication')
    error('build_online_retraining_dataset:WeightingMode', ...
        'Current online pointwise retraining requires weighting.mode=integer_replication.');
end
baseRep = max(1,round(double(wopt.onlineBaseReplication)));
recentMult = max(1,double(wopt.recentMultiplier));
tau = max(eps,double(wopt.recencyTimeConstant));
maxRep = max(baseRep,round(double(wopt.maximumReplication)));
age = max(0,triggerTime-t(idx));
rep = baseRep.*(1+(recentMult-1).*exp(-age/tau));
rep = max(1,min(maxRep,round(rep)));

expandedIdx = repelem(idx(:),rep(:));
nBase = size(base.x,1);
nOnline = numel(expandedIdx);

aug = base;
aug.x = [base.x; observations.x(:,expandedIdx).'];
if isfield(base,'z')
    if isfield(observations,'z') && ~isempty(observations.z)
        aug.z = [base.z; observations.z(:,expandedIdx).'];
    else
        aug.z = [base.z; zeros(nOnline,size(base.z,2))];
    end
end
aug.V = [base.V; observations.V(:,expandedIdx).'];
aug.labelsClean = [base.labelsClean; observations.xdotClean(:,expandedIdx).'];
aug.labels = [base.labels; observations.xdotObserved(:,expandedIdx).'];

if isfield(base,'features')
    aug.features = [base.features; zeros(nOnline,size(base.features,2))];
end

K0 = base.trajectories.nTrajectories;
onlineTrajectoryId = K0+1;
aug.trajectoryId = [base.trajectoryId(:); repmat(onlineTrajectoryId,nOnline,1)];
aug.pointInTrajectory = [base.pointInTrajectory(:); ones(nOnline,1)];

% Explicit per-row input structs make the online block valid even when the
% physical scenario contains reference/load changes inside the collected span.
aug.sampleInputByRow = cell(nBase+nOnline,1);
for i=1:nBase
    aug.sampleInputByRow{i} = base.trajectories.uByTrajectory{base.trajectoryId(i)};
end
for j=1:nOnline
    aug.sampleInputByRow{nBase+j} = online_input_at_observation(observations,expandedIdx(j));
end
aug.xObservedFlat = aug.x;

% The online rows form one forced-training group. They are never selected as
% the nominal validation holdout used for threshold/rank selection.
if isfield(base.trajectories,'forceTrainingMask') && ...
        ~isempty(base.trajectories.forceTrainingMask)
    aug.trajectories.forceTrainingMask = ...
        [logical(base.trajectories.forceTrainingMask(:)); true];
else
    aug.trajectories.forceTrainingMask = [false(K0,1); true];
end
aug.trajectories.nTrajectories = K0+1;
aug.trajectories.uByTrajectory{K0+1,1} = ...
    online_input_at_observation(observations,idx(end));
if isfield(base.trajectories,'sourceType')
    aug.trajectories.sourceType = [string(base.trajectories.sourceType(:)); "online_observation_block"];
end
if isfield(base.trajectories,'isTestInitialAnchor')
    aug.trajectories.isTestInitialAnchor = ...
        [logical(base.trajectories.isTestInitialAnchor(:)); false];
end
if isfield(base.trajectories,'initialSobolCoordinates')
    aug.trajectories.initialSobolCoordinates = [ ...
        base.trajectories.initialSobolCoordinates; ...
        nan(1,size(base.trajectories.initialSobolCoordinates,2))];
end

aug.metadata.onlineAugmented = true;
aug.metadata.offlineSampleCount = nBase;
aug.metadata.onlineUniqueSampleCount = numel(idx);
aug.metadata.onlineReplicatedRowCount = nOnline;
aug.metadata.onlineTriggerTime = triggerTime;
aug.metadata.onlineSelectedTimeRange = [t(idx(1)) t(idx(end))];
aug.metadata.onlineReplicationCount = rep(:);

info = struct();
info.uniqueSampleIndices = idx(:);
info.uniqueSampleTimes = t(idx);
info.replicationCount = rep(:);
info.expandedSampleIndices = expandedIdx(:);
info.offlineSampleCount = nBase;
info.onlineUniqueSampleCount = numel(idx);
info.onlineReplicatedRowCount = nOnline;
info.totalRegressionRows = nBase+nOnline;
info.timeRange = [t(idx(1)) t(idx(end))];
info.meanReplication = mean(rep);
info.maxReplication = max(rep);
end
