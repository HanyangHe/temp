function [evaluations,meta,cache] = run_offline_section_jobs( ...
    jobs,methods,datasets,truth,c,layout,cfg,cache,outRoot,sectionName)
%RUN_OFFLINE_SECTION_JOBS Execute one scientific section with bounded parfor.
%
% Parallelization policy:
%   - sections remain sequential;
%   - data-sampling seeds remain sequential (handled by the multiseed wrapper);
%   - within one section, all missing method/condition evaluations are a flat
%     job queue and may execute concurrently with at most cfg.parallel.numWorkers;
%   - common datasets are prepared by the caller before this function;
%   - each worker writes only its UNIQUE condition checkpoint/cache files;
%   - report tables, replay bundles, figures, and section-level CSV files remain
%     client-side/serial after this function returns.
%
% Required job fields:
%   methodIndex, datasetIndex, sampleCount, noiseLevel, requestTag
%
% This helper preserves the existing identical-condition reuse rule. Cached
% conditions are removed from the compute queue before parfor is entered.

if nargin < 10 || isempty(sectionName)
    sectionName = 'section';
end
sectionName = char(string(sectionName));

if isempty(jobs)
    evaluations = cell(0,1);
    meta = empty_meta_local(sectionName,0);
    cache = ensure_cache_schema_local(cache);
    return;
end
if ~isstruct(jobs)
    error('run_offline_section_jobs:JobsType','jobs must be a struct array.');
end
required = {'methodIndex','datasetIndex','sampleCount','noiseLevel','requestTag'};
for i = 1:numel(required)
    if ~isfield(jobs,required{i})
        error('run_offline_section_jobs:JobField', ...
            'Every job must contain field "%s".',required{i});
    end
end

cache = ensure_cache_schema_local(cache);
nJobs = numel(jobs);
evaluations = cell(nJobs,1);
meta = empty_meta_local(sectionName,nJobs);
missing = zeros(nJobs,1);
nMissing = 0;

reuseEnabled = true;
if isfield(cfg,'reuse') && isfield(cfg.reuse,'identicalConditionsWithinRun')
    reuseEnabled = logical(cfg.reuse.identicalConditionsWithinRun);
end

% -------------------- SERIAL CACHE PREFLIGHT --------------------
% This is deliberately outside parfor. It guarantees that duplicate requests
% (e.g., Section 1.2 N=500 after Section 1.1) are not recomputed.
for j = 1:nJobs
    method = methods(jobs(j).methodIndex);
    d = datasets{jobs(j).datasetIndex};
    requestTag = string(jobs(j).requestTag);
    baseKey = string(make_offline_evaluation_cache_key( ...
        method,jobs(j).sampleCount,jobs(j).noiseLevel,cfg,d));

    idx = [];
    if reuseEnabled && ~isempty(cache.entries)
        keys = string({cache.entries.key});
        idx = find(keys == baseKey,1,'first');
    end

    if ~isempty(idx)
        evaluations{j} = cache.entries(idx).evaluation;
        meta.reused(j) = true;
        meta.cacheKey(j) = string(cache.entries(idx).key);
        meta.sourceRequest(j) = string(cache.entries(idx).firstRequest);
        cache.entries(idx).requestCount = cache.entries(idx).requestCount + 1;
        cache.entries(idx).requests(end+1,1) = requestTag;
        fprintf(['  Reusing existing evaluation: %s | N=%d | noise=%.6g%% ', ...
            '(first computed for %s).\n'],char(string(method.displayName)), ...
            jobs(j).sampleCount,100*jobs(j).noiseLevel, ...
            char(meta.sourceRequest(j)));
    elseif reuseEnabled
        [diskHit,diskEval,diskEntry,diskKey,diskSource] = ...
            try_load_persistent_checkpoint_local(method,d,jobs(j),cfg,outRoot,sectionName);
        if diskHit
            evaluations{j} = diskEval;
            meta.reused(j) = true;
            meta.cacheKey(j) = string(diskKey);
            meta.sourceRequest(j) = string(diskSource);
            cache.entries = merge_entry_local(cache.entries,diskEntry);
            fprintf(['  Reusing completed on-disk checkpoint: %s | N=%d | ', ...
                'noise=%.6g%% (saved from %s).\n'], ...
                char(string(method.displayName)),jobs(j).sampleCount, ...
                100*jobs(j).noiseLevel,char(string(diskSource)));
        else
            nMissing = nMissing + 1;
            missing(nMissing) = j;
        end
    else
        nMissing = nMissing + 1;
        missing(nMissing) = j;
    end
end
missing = missing(1:nMissing);
meta.reusedJobs = nJobs-nMissing;
meta.computeJobs = nMissing;

if nMissing == 0
    fprintf('  %s: all %d requested evaluations were reused; no compute jobs remain.\n', ...
        sectionName,nJobs);
    return;
end

% Reuse-disabled campaigns intentionally preserve the legacy serial helper.
% Parallelizing duplicate identical conditions would require an additional
% per-instance key namespace and is not part of the manuscript workflow.
if ~reuseEnabled
    fprintf(['  %s: identical-condition reuse is OFF; using serial execution to ', ...
        'preserve legacy cache-instance semantics.\n'],sectionName);
    useParallel = false;
    maxWorkers = 1;
    planReason = "reuse_disabled";
else
    [useParallel,maxWorkers,planReason] = resolve_parallel_plan_local( ...
        cfg,sectionName,nMissing);
end

meta.parallelUsed = useParallel;
meta.maxWorkersUsed = maxWorkers;
meta.planReason = string(planReason);

fprintf('  %s job plan: %d requested | %d reused | %d to compute.\n', ...
    sectionName,nJobs,meta.reusedJobs,nMissing);
if useParallel
    fprintf('  %s execution: PARFOR with at most %d worker(s).\n', ...
        sectionName,maxWorkers);
else
    fprintf('  %s execution: SERIAL (%s).\n',sectionName,char(string(planReason)));
end

% Each compute job owns a private runtime cache. Therefore workers never mutate
% the client cache concurrently. The unique condition checkpoint is persisted
% by the existing cache helper, then its one-entry cache record is merged on
% the client after the section compute phase.
workerEval = cell(nMissing,1);
workerEntry = cell(nMissing,1);
workerKey = cell(nMissing,1);
workerSource = cell(nMissing,1);

if useParallel
    parfor (q = 1:nMissing,maxWorkers)
        j = missing(q);
        method = methods(jobs(j).methodIndex);
        d = datasets{jobs(j).datasetIndex};
        localCache = struct();
        [ev,localCache,~,cacheKey,sourceRequest] = ...
            get_or_train_offline_evaluation_cached(localCache,method,d,truth, ...
            c,layout,cfg,jobs(j).sampleCount,jobs(j).noiseLevel, ...
            jobs(j).requestTag,outRoot);

        % Sections 1.2/1.3 do not need dense NODE trajectory/model payloads on
        % the client. The full evaluation is already checkpointed on disk.
        if ~strcmpi(sectionName,'section1p1')
            ev = compact_offline_evaluation_for_memory(ev,cfg);
        end

        workerEval{q} = ev;
        workerEntry{q} = localCache.entries(1);
        workerKey{q} = char(string(cacheKey));
        workerSource{q} = char(string(sourceRequest));
    end
else
    for q = 1:nMissing
        j = missing(q);
        method = methods(jobs(j).methodIndex);
        d = datasets{jobs(j).datasetIndex};

        if reuseEnabled
            localCache = struct();
            [ev,localCache,~,cacheKey,sourceRequest] = ...
                get_or_train_offline_evaluation_cached(localCache,method,d,truth, ...
                c,layout,cfg,jobs(j).sampleCount,jobs(j).noiseLevel, ...
                jobs(j).requestTag,outRoot);
            entry = localCache.entries(1);
        else
            % Preserve the old global-cache instance numbering when reuse is OFF.
            [ev,cache,~,cacheKey,sourceRequest] = ...
                get_or_train_offline_evaluation_cached(cache,method,d,truth, ...
                c,layout,cfg,jobs(j).sampleCount,jobs(j).noiseLevel, ...
                jobs(j).requestTag,outRoot);
            entry = [];
        end

        if ~strcmpi(sectionName,'section1p1')
            ev = compact_offline_evaluation_for_memory(ev,cfg);
        end
        workerEval{q} = ev;
        workerEntry{q} = entry;
        workerKey{q} = char(string(cacheKey));
        workerSource{q} = char(string(sourceRequest));
    end
end

% -------------------- SERIAL MERGE / SYNCHRONIZATION BARRIER --------------------
for q = 1:nMissing
    j = missing(q);
    evaluations{j} = workerEval{q};
    meta.reused(j) = false;
    meta.cacheKey(j) = string(workerKey{q});
    meta.sourceRequest(j) = string(workerSource{q});
    if reuseEnabled
        cache.entries = merge_entry_local(cache.entries,workerEntry{q});
    end
end
end


function meta = empty_meta_local(sectionName,nJobs)
meta = struct();
meta.sectionName = string(sectionName);
meta.reused = false(nJobs,1);
meta.cacheKey = strings(nJobs,1);
meta.sourceRequest = strings(nJobs,1);
meta.reusedJobs = 0;
meta.computeJobs = 0;
meta.parallelUsed = false;
meta.maxWorkersUsed = 1;
meta.planReason = "not_started";
end


function cache = ensure_cache_schema_local(cache)
if isempty(cache) || ~isstruct(cache) || ~isfield(cache,'entries')
    cache = struct();
    cache.entries = struct('key',{},'methodName',{},'displayName',{}, ...
        'sampleCount',{},'noiseLevel',{},'firstRequest',{},'requests',{}, ...
        'requestCount',{},'checkpointPath',{},'evaluationStoredOnDisk',{}, ...
        'evaluationIsCompact',{},'evaluation',{});
end
end


function entries = merge_entry_local(entries,entry)
%MERGE_ENTRY_LOCAL Schema-safe client-side merge of a worker cache record.
if isempty(entry)
    return;
end
if isempty(entries)
    entries = reshape(entry,[],1);
    return;
end

% Duplicate keys should normally have been removed by the serial preflight.
% Handle one defensively so the cache remains valid rather than creating two
% indistinguishable runtime entries.
keys = string({entries.key});
idx = find(keys == string(entry.key),1,'first');
if ~isempty(idx)
    entries(idx).requestCount = entries(idx).requestCount + entry.requestCount;
    entries(idx).requests = [entries(idx).requests(:); entry.requests(:)];
    if (~isfield(entries(idx),'checkpointPath') || isempty(entries(idx).checkpointPath)) && ...
            isfield(entry,'checkpointPath')
        entries(idx).checkpointPath = entry.checkpointPath;
    end
    if isfield(entry,'evaluationStoredOnDisk') && logical(entry.evaluationStoredOnDisk)
        entries(idx).evaluationStoredOnDisk = true;
    end
    if isfield(entry,'evaluationIsCompact')
        entries(idx).evaluationIsCompact = entry.evaluationIsCompact;
    end
    if isfield(entry,'evaluation') && ~isempty(entry.evaluation)
        entries(idx).evaluation = entry.evaluation;
    end
    return;
end

entryFields = fieldnames(entry);
for i = 1:numel(entryFields)
    f = entryFields{i};
    if ~isfield(entries,f)
        [entries.(f)] = deal([]);
    end
end
cacheFields = fieldnames(entries);
for i = 1:numel(cacheFields)
    f = cacheFields{i};
    if ~isfield(entry,f)
        entry.(f) = [];
    end
end
entry = orderfields(entry,entries);
entries(end+1,1) = entry;
end



function [hit,evaluation,entry,cacheKey,sourceRequest] = ...
    try_load_persistent_checkpoint_local(method,dataset,job,cfg,outRoot,sectionName)
%TRY_LOAD_PERSISTENT_CHECKPOINT_LOCAL Resume a condition completed before a crash.
%
% Every unique condition is checkpointed immediately by
% get_or_train_offline_evaluation_cached.  The original section runner only
% reused the in-memory cache, so restarting MATLAB after an exception could
% unnecessarily recompute already-finished jobs.  This preflight validates the
% deterministic cache key and reloads the completed evaluation from disk.

hit = false;
evaluation = [];
entry = [];
cacheKey = string(make_offline_evaluation_cache_key( ...
    method,job.sampleCount,job.noiseLevel,cfg,dataset));
sourceRequest = string(job.requestTag);

if isempty(outRoot) || exist(outRoot,'dir')~=7
    return;
end
if isfield(cfg,'output') && isfield(cfg.output,'saveEvaluationCache') && ...
        ~logical(cfg.output.saveEvaluationCache)
    return;
end

methodFolder = 'method_results';
if isfield(cfg,'output') && isfield(cfg.output,'methodResultsFolder') && ...
        ~isempty(cfg.output.methodResultsFolder)
    methodFolder = char(string(cfg.output.methodResultsFolder));
end
cacheFolder = 'evaluation_cache';
if isfield(cfg,'output') && isfield(cfg.output,'evaluationCacheFolder') && ...
        ~isempty(cfg.output.evaluationCacheFolder)
    cacheFolder = char(string(cfg.output.evaluationCacheFolder));
end

fileTag = condition_file_tag_resume_local( ...
    method,job.sampleCount,job.noiseLevel,dataset);
checkpointPath = fullfile(outRoot,methodFolder,char(string(method.name)), ...
    cacheFolder,[fileTag '.mat']);
if exist(checkpointPath,'file')~=2
    return;
end

try
    S = load_mat_long_path_safe(checkpointPath,'savedEvaluation','condition');
    if ~isfield(S,'savedEvaluation') || ~isfield(S,'condition') || ...
            ~isstruct(S.condition)
        return;
    end
    C = S.condition;
    if ~isfield(C,'cacheKey') || string(C.cacheKey) ~= cacheKey
        return;
    end
    if isfield(C,'methodName') && ...
            ~strcmpi(char(string(C.methodName)),char(string(method.name)))
        return;
    end
    if isfield(C,'sampleCount') && ...
            abs(double(C.sampleCount)-double(job.sampleCount))>1e-12
        return;
    end
    if isfield(C,'noiseLevel') && ...
            abs(double(C.noiseLevel)-double(job.noiseLevel)) > ...
            max(1e-14,1e-10*max(1,abs(double(job.noiseLevel))))
        return;
    end

    evaluation = S.savedEvaluation;
    if ~strcmpi(sectionName,'section1p1')
        evaluation = compact_offline_evaluation_for_memory(evaluation,cfg);
    end

    if isfield(C,'firstRequest') && ~isempty(C.firstRequest)
        sourceRequest = string(C.firstRequest);
    else
        sourceRequest = "persistent_checkpoint";
    end

    entry = struct();
    entry.key = char(cacheKey);
    entry.methodName = char(string(method.name));
    entry.displayName = char(string(method.displayName));
    entry.sampleCount = job.sampleCount;
    entry.noiseLevel = job.noiseLevel;
    entry.firstRequest = char(sourceRequest);
    entry.requests = string(job.requestTag);
    entry.requestCount = 1;
    entry.checkpointPath = checkpointPath;
    entry.evaluationStoredOnDisk = true;
    entry.evaluationIsCompact = isfield(evaluation,'memoryCompacted') && ...
        logical(evaluation.memoryCompacted);
    entry.evaluation = evaluation;
    hit = true;
catch ME
    warning('run_offline_section_jobs:CheckpointResumeReadFailed', ...
        ['Ignoring unreadable/incompatible checkpoint and recomputing the ', ...
         'condition:\n  %s\nReason: %s'],checkpointPath,ME.message);
    hit = false;
    evaluation = [];
    entry = [];
end
end


function tag = condition_file_tag_resume_local(method,N,noiseLevel,dataset)
noiseText = sprintf('%.12g',100*noiseLevel);
noiseText = strrep(noiseText,'-','m');
noiseText = strrep(noiseText,'+','p');
noiseText = strrep(noiseText,'.','p');
protocol = regexprep(char(offline_method_data_protocol(dataset,method)), ...
    '[^A-Za-z0-9_\-]','_');
tag = sprintf('%s_N%d_noise%spct_%s', ...
    char(string(method.name)),N,noiseText,protocol);
tag = regexprep(tag,'[^A-Za-z0-9_\-]','_');
end


function [useParallel,maxWorkers,reason] = resolve_parallel_plan_local(cfg,sectionName,nJobs)
useParallel = false;
maxWorkers = 1;
reason = "parallel_disabled";

if nJobs < 2
    reason = "fewer_than_two_compute_jobs";
    return;
end
if ~isfield(cfg,'parallel') || ~isstruct(cfg.parallel) || ...
        ~isfield(cfg.parallel,'enabled') || ~logical(cfg.parallel.enabled)
    return;
end
if isfield(cfg.parallel,'mode') && ...
        ~strcmpi(char(string(cfg.parallel.mode)),'within_section')
    reason = "parallel_mode_not_within_section";
    return;
end
if isfield(cfg.parallel,sectionName) && ~logical(cfg.parallel.(sectionName))
    reason = "section_parallel_disabled";
    return;
end

requested = 2;
if isfield(cfg.parallel,'numWorkers') && ~isempty(cfg.parallel.numWorkers)
    requested = max(1,round(double(cfg.parallel.numWorkers)));
end
if requested < 2
    reason = "requested_worker_count_is_one";
    return;
end

try
    hasPCT = license('test','Distrib_Computing_Toolbox');
catch
    hasPCT = false;
end
if ~hasPCT
    warning('run_offline_section_jobs:NoParallelToolbox', ...
        ['Parallel Computing Toolbox is unavailable. %s will fall back to ', ...
         'serial execution.'],sectionName);
    reason = "parallel_toolbox_unavailable";
    return;
end

autoStart = true;
if isfield(cfg.parallel,'autoStartPool')
    autoStart = logical(cfg.parallel.autoStartPool);
end
profile = 'local';
if isfield(cfg.parallel,'poolProfile') && ~isempty(cfg.parallel.poolProfile)
    profile = char(string(cfg.parallel.poolProfile));
end

try
    p = gcp('nocreate');
    if isempty(p)
        if ~autoStart
            reason = "no_existing_pool_and_autostart_off";
            return;
        end
        fprintf('  Starting parallel pool "%s" with %d worker(s)...\n',profile,requested);
        p = parpool(profile,requested);
    end
    maxWorkers = min([requested,p.NumWorkers,nJobs]);
    if maxWorkers >= 2
        useParallel = true;
        reason = "enabled";
    else
        reason = "pool_has_fewer_than_two_workers";
    end
catch ME
    warning('run_offline_section_jobs:ParallelStartFailed', ...
        ['Could not prepare the parallel pool for %s (%s). Falling back to ', ...
         'serial execution.'],sectionName,ME.message);
    useParallel = false;
    maxWorkers = 1;
    reason = "parallel_pool_start_failed";
end
end
