function noisy = add_vector_field_label_noise(clean,noiseLevel,cfg)
%ADD_VECTOR_FIELD_LABEL_NOISE Compatibility wrapper for v1p7+.
noisy = add_offline_training_noise(clean,noiseLevel,cfg);
end
