function prediction = simulate_online_adaptive_model_scenario( ...
    initialModel,updatedModel,activationTime,method,truth,cNominal,layout,cfg)
%SIMULATE_ONLINE_ADAPTIVE_MODEL_SCENARIO Delayed local switch with state sync.
%
% A practical digital shadow remains synchronized to measurements. Therefore,
% when the validated local model becomes active, the corrected forecast is
% restarted from the measured/reference DAE state at the activation time.
% This prevents accumulated pre-update state error from being incorrectly
% attributed to the newly updated local vector field.

if nargin<3 || isempty(activationTime), activationTime=inf; end

if isfield(cfg.online.update,'stateSynchronizationAtActivation') && ...
        ~cfg.online.update.stateSynchronizationAtActivation
    prediction = continuous_switch_rollout(initialModel,updatedModel,activationTime, ...
        method,truth,cNominal,layout,cfg);
    return;
end
if isempty(updatedModel) || ~isfinite(activationTime) || ...
        activationTime >= truth.t(end)-1e-12
    prediction = simulate_online_frozen_model_scenario( ...
        initialModel,method,truth,cNominal,layout,cfg);
    prediction.metadata.onlineMode='online_candidate_not_activated';
    prediction.metadata.modelActivationTimeSeconds=activationTime;
    prediction.metadata.stateResynchronizedAtActivation=false;
    return;
end

idxAct = find(truth.t >= activationTime-1e-12,1,'first');
if isempty(idxAct) || idxAct>=numel(truth.t)
    prediction = simulate_online_frozen_model_scenario( ...
        initialModel,method,truth,cNominal,layout,cfg);
    prediction.metadata.onlineMode='online_activation_beyond_horizon';
    prediction.metadata.modelActivationTimeSeconds=activationTime;
    prediction.metadata.stateResynchronizedAtActivation=false;
    return;
end
actualActivationTime = truth.t(idxAct);

% Prefix: the old model is used until the updated model is validated. This
% prefix may itself fail; the real digital shadow can still recover later
% because mismatch detection and parameter updating use measured system data.
prefixPred = empty_prediction();
if idxAct>2
    prefixTruth = trim_truth(truth,1,idxAct-1);
    prefixPred = simulate_offline_model_scenario( ...
        initialModel,method,prefixTruth,cNominal,layout,cfg);
end

% Suffix: synchronize to the measured/reference state exactly when the new
% local model is activated, then forecast with the corrected digital model.
suffixTruth = trim_truth(truth,idxAct,numel(truth.t));
suffixMethod = method;
suffixMethod.displayName = char(string(method.displayName)+" (online)");
suffixPred = simulate_offline_model_scenario( ...
    updatedModel,suffixMethod,suffixTruth,cNominal,layout,cfg);

% Combine every valid saved point. A failed pre-update model may leave a gap;
% the corrected suffix is still a valid online digital-shadow recovery result.
tCombined = zeros(0,1);
yCombined = zeros(0,size(truth.y,2));
if isfield(prefixPred,'t') && ~isempty(prefixPred.t)
    tCombined = prefixPred.t(:);
    yCombined = prefixPred.y;
end
if isfield(suffixPred,'t') && ~isempty(suffixPred.t)
    if ~isempty(tCombined) && abs(tCombined(end)-suffixPred.t(1))<=1e-12
        suffixStart=2;
    else
        suffixStart=1;
    end
    if suffixStart<=numel(suffixPred.t)
        tCombined=[tCombined;suffixPred.t(suffixStart:end)]; %#ok<AGROW>
        yCombined=[yCombined;suffixPred.y(suffixStart:end,:)]; %#ok<AGROW>
    end
end

if isempty(tCombined)
    prediction = suffixPred;
else
    prediction = mg_postprocess_solution(tCombined,yCombined,cNominal,layout);
end

prefixSucceeded = ~isempty(prefixPred.t) && isfield(prefixPred,'metadata') && ...
    isfield(prefixPred.metadata,'rolloutSucceeded') && prefixPred.metadata.rolloutSucceeded;
suffixSucceeded = isfield(suffixPred,'metadata') && ...
    isfield(suffixPred.metadata,'rolloutSucceeded') && suffixPred.metadata.rolloutSucceeded;

prediction.metadata.methodName = method.name;
prediction.metadata.methodDisplayName = char(string(method.displayName)+" (online)");
prediction.metadata.onlineMode = 'module_local_corrected_with_state_sync';
prediction.metadata.modelActivationTimeSeconds = actualActivationTime;
prediction.metadata.parameterMismatchKnownToModel = false;
prediction.metadata.stateResynchronizedAtActivation = true;
prediction.metadata.preActivationRolloutSucceeded = prefixSucceeded;
prediction.metadata.postActivationRolloutSucceeded = suffixSucceeded;
prediction.metadata.preActivationFailureTimeSeconds = get_meta(prefixPred,'failureTimeSeconds',NaN);
prediction.metadata.preActivationRolloutStatus = string(get_meta(prefixPred,'rolloutStatus',"NOT_RUN"));
prediction.metadata.postActivationRolloutStatus = string(get_meta(suffixPred,'rolloutStatus',"NOT_RUN"));
prediction.metadata.modelSolveTimeSeconds = ...
    get_meta(prefixPred,'modelSolveTimeSeconds',0)+get_meta(suffixPred,'modelSolveTimeSeconds',0);
prediction.metadata.requestedTimePointCount = numel(truth.t);
prediction.metadata.requestedTimeStart = truth.t(1);
prediction.metadata.requestedTimeEnd = truth.t(end);
prediction.metadata.availableTimePointCount = numel(tCombined);
prediction.metadata.trajectoryCoveragePercent = 100*numel(tCombined)/numel(truth.t);

if suffixSucceeded
    prediction.metadata.rolloutSucceeded = true;
    prediction.metadata.failureTimeSeconds = NaN;
    prediction.metadata.failureMessage = "";
    if prefixSucceeded || idxAct<=2
        prediction.metadata.rolloutStatus = "SUCCESS";
    else
        prediction.metadata.rolloutStatus = "SUCCESS_AFTER_RESYNCHRONIZATION";
    end
else
    prediction.metadata.rolloutSucceeded = false;
    prediction.metadata.rolloutStatus = "FAILED_AFTER_ONLINE_UPDATE";
    prediction.metadata.failureTimeSeconds = get_meta(suffixPred,'failureTimeSeconds',actualActivationTime);
    prediction.metadata.failureMessage = string(get_meta(suffixPred,'failureMessage',"updated suffix failed"));
end
end

function S = trim_truth(truth,i1,i2)
S=struct();
S.t=truth.t(i1:i2);
S.y=truth.y(i1:i2,:);
end

function P = empty_prediction()
P=struct();
P.t=zeros(0,1);
P.y=zeros(0,0);
P.metadata=struct('rolloutSucceeded',false,'rolloutStatus',"NOT_RUN", ...
    'failureTimeSeconds',NaN,'failureMessage',"",'modelSolveTimeSeconds',0);
end

function value = get_meta(P,name,defaultValue)
value=defaultValue;
if isstruct(P) && isfield(P,'metadata') && isstruct(P.metadata) && ...
        isfield(P.metadata,name) && ~isempty(P.metadata.(name))
    value=P.metadata.(name);
end
end


function prediction = continuous_switch_rollout(initialModel,updatedModel,activationTime, ...
    method,truth,cNominal,layout,cfg)
switchModel=struct('initialModel',initialModel,'updatedModel',updatedModel, ...
    'activationTime',activationTime,'basePredictFcn',method.predictFcn);
switchMethod=method;
switchMethod.predictFcn=@predict_switched;
switchMethod.displayName=char(string(method.displayName)+" (online)");
prediction=simulate_offline_model_scenario( ...
    switchModel,switchMethod,truth,cNominal,layout,cfg);
prediction.metadata.onlineMode='module_local_corrected_continuous_switch';
prediction.metadata.modelActivationTimeSeconds=activationTime;
prediction.metadata.stateResynchronizedAtActivation=false;
    function fhat=predict_switched(M,t,x,V,u,c,L)
        if t<M.activationTime, active=M.initialModel; else, active=M.updatedModel; end
        fhat=M.basePredictFcn(active,t,x,V,u,c,L);
    end
end
