function noisy = add_offline_training_noise(clean,noiseLevel,cfg)
%ADD_OFFLINE_TRAINING_NOISE Common noisy-trajectory protocol for Section 1.3.
%
% One physical corruption is created first:
%
%   x_obs(t) = x_clean(t) + eta * scale_x .* epsilon(t).
%
% Every method then receives information derived from that SAME measured
% trajectory realization:
%   - Neural ODE uses trajectories.xObserved directly as its state target;
%   - pointwise SINDy and CT M-KBF use dataset.x = xObserved and derivative
%     labels reconstructed from xObserved by one common local-polynomial
%     differentiator;
%   - Weak PN-SINDy uses xObserved and the PN candidate dictionary but does
%     not use pointwise derivative labels.
%
% Terminal voltage and commanded inputs remain clean in the formal protocol.
% This isolates state-measurement corruption while keeping exogenous forcing
% common to all methods. In the official manuscript runner this function is
% called only for strictly positive noise levels. The eta=0 point is the clean
% N=500 benchmark from Sections 1.1/1.2 and is reused through the shared cache.

if noiseLevel < 0 || ~isscalar(noiseLevel) || ~isfinite(noiseLevel)
    error('add_offline_training_noise:NoiseLevel', ...
        'noiseLevel must be one nonnegative finite scalar fraction.');
end
if ~isfield(clean,'trajectories') || ~isfield(clean.trajectories,'xClean') || ...
        ~isfield(clean.trajectories,'t')
    error('add_offline_training_noise:TrajectoryDataset', ...
        'A grouped short-trajectory dataset is required.');
end

noisy = clean;
L = clean.trajectories.pointsPerTrajectory;
K = clean.trajectories.nTrajectories;
nx = size(clean.x,2);
if size(clean.x,1) ~= L*K
    error('add_offline_training_noise:TrajectoryPacking', ...
        'Flat state rows do not match L*K trajectory packing.');
end

%% 1) Create ONE noisy measured state trajectory realization.
XcleanFlat = double(clean.x);
xScale = std(XcleanFlat,0,1);
xRms = sqrt(mean(XcleanFlat.^2,1));
xScale = max(xScale,0.05*xRms);
xScale = max(xScale,cfg.noise.minimumScale);

oldState = rng;
cleanup = onCleanup(@()rng(oldState)); %#ok<NASGU>
% Preserve the historical NODE state-noise stream so the new common
% protocol uses exactly the trajectory corruption that NODE previously saw.
rng(cfg.noise.seed + 1009,'twister');
Ex = randn(size(XcleanFlat));
XobsFlat = XcleanFlat + noiseLevel*(Ex.*xScale);
Xobs = reshape(XobsFlat,[L K nx]);

noisy.x = XobsFlat;
noisy.xObservedFlat = XobsFlat;
noisy.trajectories.xObserved = Xobs;

%% 2) Reconstruct pointwise vector-field labels from the SAME noisy states.
if ~isfield(cfg.noise,'derivative') || ~isstruct(cfg.noise.derivative)
    error('add_offline_training_noise:DerivativeConfig', ...
        'cfg.noise.derivative settings are required.');
end
method = lower(string(cfg.noise.derivative.method));
switch method
    case "local_polynomial"
        dX = estimate_trajectory_derivatives_local_poly( ...
            Xobs,clean.trajectories.t, ...
            cfg.noise.derivative.windowPoints, ...
            cfg.noise.derivative.polyOrder);
    otherwise
        error('add_offline_training_noise:DerivativeMethod', ...
            'Unsupported derivative estimator "%s".',char(method));
end

labelsEstimated = reshape(dX,[L*K nx]);
noisy.labels = labelsEstimated;
noisy.trajectories.labels = dX;

%% 3) Audit metadata.
cleanLabels = double(clean.labelsClean);
diffErr = labelsEstimated-cleanLabels;
noisy.metadata.trainingNoiseLevel = noiseLevel;
noisy.metadata.trainingNoisePercent = 100*noiseLevel;
noisy.metadata.trainingNoiseType = cfg.noise.type;
noisy.metadata.trainingNoiseProtocol = 'common_state_measurement_to_derivative_v1';
noisy.metadata.stateMeasurementNoiseScale = xScale;
noisy.metadata.stateMeasurementNoiseSeed = cfg.noise.seed + 1009;
noisy.metadata.terminalVoltageCorrupted = false;
noisy.metadata.commandedInputsCorrupted = false;
noisy.metadata.derivativeEstimator = char(method);
noisy.metadata.derivativeWindowPoints = cfg.noise.derivative.windowPoints;
noisy.metadata.derivativePolynomialOrder = cfg.noise.derivative.polyOrder;
noisy.metadata.derivativeLabelRMSEvsClean = sqrt(mean(diffErr.^2,'all'));
noisy.metadata.derivativeLabelMAEvsClean = mean(abs(diffErr),'all');
noisy.metadata.noiseSourceDescription = [ ...
    'one common noisy state trajectory; NODE uses xObserved; pointwise methods ', ...
    'use local-polynomial derivatives of xObserved; Weak PN-SINDy uses weak integrals'];
end
