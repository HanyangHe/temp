function [cfg,prior] = prepare_offline_llm_prior_config(projectRoot,cfg)
%PREPARE_OFFLINE_LLM_PRIOR_CONFIG Inject the formal policy-specific LLM prior.
%
% The main offline runner calls this automatically whenever llm_prior_sindy is
% part of the configured campaign. Users therefore only choose testCase in the
% root MLX; no manual prior-discovery step is required.

prior=struct();
if nargin<1 || isempty(projectRoot), projectRoot=fileparts(fileparts(mfilename('fullpath'))); end
if nargin<2 || isempty(cfg) || ~isstruct(cfg), return; end
if ~campaign_requests_llm_prior_local(cfg), return; end

if ~isfield(cfg,'sindy') || ~isstruct(cfg.sindy) || ...
        ~isfield(cfg.sindy,'llmPrior') || ~isstruct(cfg.sindy.llmPrior) || ...
        ~isfield(cfg.sindy.llmPrior,'enabled') || ~logical(cfg.sindy.llmPrior.enabled)
    error('prepare_offline_llm_prior_config:Disabled', ...
        ['llm_prior_sindy is requested, but cfg.sindy.llmPrior.enabled is ', ...
         'not true.']);
end
if ~isfield(cfg,'randomSeed') || isempty(cfg.randomSeed)
    error('prepare_offline_llm_prior_config:Seed', ...
        'cfg.randomSeed is required for formal LLM-prior discovery.');
end
% Data sampling and LLM discovery are DISTINCT experimental random sources.
% 69-bus V4 freezes the LLM bank across its three DATA realizations;
% other cases retain their existing independent-discovery behavior.
seed=round(double(cfg.randomSeed));
expectedHash="";
if isfield(cfg,'multiseed') && isstruct(cfg.multiseed) && ...
        isfield(cfg.multiseed,'llmPriorDiscoveryPolicy')
    policy=lower(strtrim(string(cfg.multiseed.llmPriorDiscoveryPolicy)));
    switch policy
        case "fixed_bank"
            if ~isfield(cfg.multiseed,'llmPriorFixedDiscoverySeed') || ...
                    ~isnumeric(cfg.multiseed.llmPriorFixedDiscoverySeed) || ...
                    ~isscalar(cfg.multiseed.llmPriorFixedDiscoverySeed) || ...
                    ~isfinite(double(cfg.multiseed.llmPriorFixedDiscoverySeed))
                error('prepare_offline_llm_prior_config:FixedSeed', ...
                    'Fixed-bank campaign must specify a finite discovery seed.');
            end
            seed=round(double(cfg.multiseed.llmPriorFixedDiscoverySeed));
            if isfield(cfg.multiseed,'llmPriorExpectedBankHash')
                expectedHash=upper(strtrim(string(cfg.multiseed.llmPriorExpectedBankHash)));
            end
        case {"per_data_seed","independent",""}
            % Existing 10/123-bus behavior is intentionally unchanged.
        otherwise
            error('prepare_offline_llm_prior_config:UnknownPolicy', ...
                'Unknown LLM prior discovery policy: %s',char(policy));
    end
end

% If a closed-over single-seed config already carries the correct bank, do not
% even touch the shared discovery cache.
if isfield(cfg.sindy.llmPrior,'priorBankHash') && ...
        strlength(string(cfg.sindy.llmPrior.priorBankHash))>0 && ...
        isfield(cfg.sindy.llmPrior,'discoverySeed') && ...
        round(double(cfg.sindy.llmPrior.discoverySeed))==seed && ...
        prior_bank_nonempty_local(cfg.sindy.llmPrior)
    prior.bank=cfg.sindy.llmPrior.priorBank;
    if isfield(cfg.sindy.llmPrior,'priorItems'), prior.items=cfg.sindy.llmPrior.priorItems; end
    prior.bankHash=char(string(cfg.sindy.llmPrior.priorBankHash));
    prior.discoverySeed=seed;
    local_verify_formal_bank_hash(prior.bankHash,expectedHash);
    return;
end

prior=discover_llm_prior_bank(projectRoot,seed,cfg);
local_verify_formal_bank_hash(prior.bankHash,expectedHash);
cfg.sindy.llmPrior.priorBank=prior.bank;
cfg.sindy.llmPrior.priorItems=prior.items;
cfg.sindy.llmPrior.discoverySeed=seed;
cfg.sindy.llmPrior.priorBankHash=prior.bankHash;
cfg.sindy.llmPrior.discoveryProtocolHash=prior.discoveryProtocolHash;
end

function tf=campaign_requests_llm_prior_local(cfg)
tf=false;
if ~isfield(cfg,'run') || ~isstruct(cfg.run), return; end
fields={'methodsToRun','section1p1MethodsToRun','section1p2MethodsToRun','section1p3MethodsToRun'};
for k=1:numel(fields)
    f=fields{k};
    if ~isfield(cfg.run,f) || isempty(cfg.run.(f)), continue; end
    q=string(cfg.run.(f)); q=q(:);
    if any(strcmpi(q,'llm_prior_sindy')) || any(strcmpi(q,'LLM-Prior SINDy'))
        tf=true; return;
    end
end
end

function tf=prior_bank_nonempty_local(lp)
tf=false;
if ~isfield(lp,'priorBank') || ~isstruct(lp.priorBank), return; end
for t={'sg','gfm','gfl'}
    if ~isfield(lp.priorBank,t{1}) || isempty(lp.priorBank.(t{1})), return; end
end
tf=true;
end

function local_verify_formal_bank_hash(actualHash,expectedHash)
% Hard error prevents accidental re-discovery of an incompatible frozen bank.
if strlength(string(expectedHash))>0 && ...
        ~strcmpi(strtrim(string(actualHash)),strtrim(string(expectedHash)))
    error('prepare_offline_llm_prior_config:BankHashMismatch', ...
        'Frozen official bank hash mismatch: expected %s, got %s.', ...
        char(string(expectedHash)),char(string(actualHash)));
end
end
