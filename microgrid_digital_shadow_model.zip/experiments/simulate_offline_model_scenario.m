function prediction = simulate_offline_model_scenario(model,method,truth,c,layout,cfg,varargin)
%SIMULATE_OFFLINE_MODEL_SCENARIO Propagate one learned vector field on test u(t).
%
% A learned model may be inaccurate enough that ODE15I cannot complete the
% requested test horizon. Such a rollout failure is an experimental result,
% not a reason to abort the remaining method/sample/noise sweep.
%
% v1p14 adds a conservative early-abort guard. If the accepted DAE solution
% exceeds a configured normalized trajectory-error bound, or if an extreme
% absolute state magnitude is encountered, the current rollout is terminated
% and the sweep immediately proceeds to the next condition. Whole-window
% metrics remain NaN for every incomplete rollout, exactly as before.

if nargin < 6 || isempty(cfg)
    cfg = struct();
end

% Optional initial-state override is used only by the Stage-3 online ablation
% when a model is switched without synchronizing the digital state. Offline
% callers remain unchanged and start from truth.y(1,:).
initialStateOverride = [];
if ~isempty(varargin)
    p = inputParser;
    p.FunctionName = mfilename;
    addParameter(p,'InitialState',[],@(x)isnumeric(x) && isvector(x));
    parse(p,varargin{:});
    initialStateOverride = p.Results.InitialState;
end

if isfield(c,'drift') && isfield(c.drift,'enabled') && c.drift.enabled
    error('simulate_offline_model_scenario:OfflineDrift', ...
        'Experiment Part 1 requires c.drift.enabled=false.');
end

guard = get_rollout_guard_options(cfg,truth);

% v1p20: make the ODE15I time grid explicit and validate it before rollout.
% This prevents a malformed/squeezed saved time vector from reaching ODE15I
% as a scalar tspan. For a valid reference trajectory this is exactly
% truth.t(:), so no numerical protocol is changed.
tspan = prepare_rollout_tspan(truth,c);

prediction = struct();
prediction.t = zeros(0,1);
prediction.y = zeros(0,numel(truth.y(1,:)));
prediction.metadata.methodName = method.name;
prediction.metadata.methodDisplayName = method.displayName;
prediction.metadata.modelSolveTimeSeconds = NaN;
prediction.metadata.rolloutSucceeded = false;
prediction.metadata.rolloutStatus = "NOT_STARTED";
prediction.metadata.failureTimeSeconds = NaN;
prediction.metadata.trajectoryCoveragePercent = 0;
prediction.metadata.failureMessage = "";
prediction.metadata.solverWarningID = "";
prediction.metadata.solverWarningMessage = "";
prediction.metadata.rolloutGuardEnabled = guard.enabled;
prediction.metadata.rolloutGuardTriggered = false;
prediction.metadata.rolloutGuardReason = "";
prediction.metadata.rolloutGuardValue = NaN;
prediction.metadata.rolloutGuardThreshold = NaN;
prediction.metadata.residualEvaluationCount = 0;
prediction.metadata.computationGuardMaxWallClockSeconds = guard.maxWallClockSeconds;
prediction.metadata.computationGuardMaxResidualEvaluations = guard.maxResidualEvaluations;
prediction.metadata.requestedTimePointCount = numel(tspan);
prediction.metadata.requestedTimeStart = tspan(1);
prediction.metadata.requestedTimeEnd = tspan(end);

guardAbortTime = NaN;
guardAbortValue = NaN;
residualEvaluationCount = 0;
computationAbortReason = "";

solveStart = tic;
try
    if isempty(initialStateOverride)
        y0 = truth.y(1,:).';
    else
        y0 = double(initialStateOverride(:));
        if numel(y0) ~= size(truth.y,2)
            error('simulate_offline_model_scenario:InitialStateSize', ...
                'InitialState has %d entries; expected %d.',numel(y0),size(truth.y,2));
        end
        if any(~isfinite(y0))
            error('simulate_offline_model_scenario:InitialStateFinite', ...
                'InitialState must contain only finite values.');
        end
    end
    prediction.metadata.initialStateOverridden = ~isempty(initialStateOverride);
    [x0,V0] = mg_unpack_dae_state(y0,c,layout);
    u0 = mg_input_profile(truth.t(1),c);
    f0 = method.predictFcn(model,truth.t(1),x0,V0,u0,c,layout);
    if any(~isfinite(f0(:)))
        error('simulate_offline_model_scenario:NonfiniteInitialVectorField', ...
            'The model returned a non-finite vector field at the initial condition.');
    end
    yp0 = [f0(:);zeros(layout.nvAlg,1)];

    residual = @guarded_residual;
    opts = odeset('RelTol',c.sim.RelTol, ...
                  'AbsTol',c.sim.AbsTol, ...
                  'MaxStep',c.sim.MaxStep, ...
                  'Stats','off');
    if guard.enabled
        opts = odeset(opts,'Events',@rollout_guard_events);
    end

    % ODE15I commonly reports an integration breakdown as a warning and
    % returns the successfully integrated prefix rather than throwing an
    % exception. Capture the warning, but determine success from horizon
    % completion or an explicit terminal guard event.
    lastwarn('');
    if guard.enabled
        [t,y,te,ye,ie] = ode15i(residual,tspan,y0,yp0,opts);
    else
        [t,y] = ode15i(residual,tspan,y0,yp0,opts);
        te = zeros(0,1); ye = zeros(0,numel(y0)); ie = zeros(0,1);
    end
    [warnMsg,warnID] = lastwarn;
    prediction.metadata.modelSolveTimeSeconds = toc(solveStart);
    prediction.metadata.solverWarningID = string(warnID);
    prediction.metadata.solverWarningMessage = string(warnMsg);

    prediction.t = t(:);
    prediction.y = y;

    % Postprocess whatever prefix is available. If postprocessing itself
    % fails because the learned trajectory entered a nonphysical region,
    % preserve raw t/y and report that honestly as a failed rollout.
    try
        processed = mg_postprocess_solution(t,y,c,layout);
        processed.metadata.modelSolveTimeSeconds = prediction.metadata.modelSolveTimeSeconds;
        processed.metadata.methodName = method.name;
        processed.metadata.methodDisplayName = method.displayName;
        processed.metadata.solverWarningID = string(warnID);
        processed.metadata.solverWarningMessage = string(warnMsg);
        processed.metadata.rolloutGuardEnabled = guard.enabled;
        processed.metadata.rolloutGuardTriggered = false;
        processed.metadata.rolloutGuardReason = "";
        processed.metadata.rolloutGuardValue = NaN;
        processed.metadata.rolloutGuardThreshold = NaN;
        processed.metadata.residualEvaluationCount = residualEvaluationCount;
        processed.metadata.computationGuardMaxWallClockSeconds = guard.maxWallClockSeconds;
        processed.metadata.computationGuardMaxResidualEvaluations = guard.maxResidualEvaluations;
        processed.metadata.initialStateOverridden = ~isempty(initialStateOverride);
        prediction = processed;
    catch MEpost
        prediction.metadata.rolloutStatus = "FAILED_POSTPROCESS";
        prediction.metadata.failureMessage = string(MEpost.message);
        prediction.metadata.failureTimeSeconds = t(end);
        prediction.metadata.trajectoryCoveragePercent = coverage_percent(t(end),truth.t);
        prediction.metadata.residualEvaluationCount = residualEvaluationCount;
        return;
    end

    % A terminal event is an intentional early stop. Classify it before the
    % ordinary incomplete-horizon logic so the report makes the reason clear.
    if ~isempty(ie)
        eventIndex = ie(end);
        eventTime = te(end);
        eventState = ye(end,:).';
        prediction.metadata.rolloutSucceeded = false;
        prediction.metadata.rolloutGuardTriggered = true;
        prediction.metadata.failureTimeSeconds = eventTime;
        prediction.metadata.trajectoryCoveragePercent = coverage_percent(eventTime,truth.t);

        if eventIndex == 1
            eventValue = normalized_error_at(eventTime,eventState);
            prediction.metadata.rolloutStatus = "EARLY_ABORT_EXCESSIVE_ERROR";
            prediction.metadata.rolloutGuardReason = "normalized_error";
            prediction.metadata.rolloutGuardValue = eventValue;
            prediction.metadata.rolloutGuardThreshold = guard.maxNormalizedError;
            prediction.metadata.failureMessage = sprintf( ...
                'Rollout guard stopped integration: normalized error %.6g reached limit %.6g.', ...
                eventValue,guard.maxNormalizedError);
        elseif eventIndex == 2
            eventValue = max(abs(eventState));
            prediction.metadata.rolloutStatus = "EARLY_ABORT_EXCESSIVE_STATE";
            prediction.metadata.rolloutGuardReason = "absolute_state";
            prediction.metadata.rolloutGuardValue = eventValue;
            prediction.metadata.rolloutGuardThreshold = guard.maxAbsState;
            prediction.metadata.failureMessage = sprintf( ...
                'Rollout guard stopped integration: max|y| %.6g reached limit %.6g.', ...
                eventValue,guard.maxAbsState);
        else
            prediction.metadata.rolloutStatus = "EARLY_ABORT_GUARD";
            prediction.metadata.rolloutGuardReason = "unknown_guard_event";
            prediction.metadata.failureMessage = sprintf( ...
                'Rollout guard stopped integration at t=%.6g s (event index %d).', ...
                eventTime,eventIndex);
        end
        return;
    end

    % With truth.t supplied as the requested output grid, a successful
    % rollout should reach the final requested time and have the same number
    % of saved points. A partial ODE15I return is therefore classified as a
    % rollout failure and whole-window error metrics are intentionally not
    % computed later.
    timeTol = max(1e-10,100*eps(max(1,abs(tspan(end)))));
    reachedEnd = ~isempty(t) && abs(t(end)-tspan(end)) <= timeTol;
    sameCount = numel(t) == numel(tspan);

    if reachedEnd && sameCount
        prediction.metadata.rolloutSucceeded = true;
        prediction.metadata.rolloutStatus = "SUCCESS";
        prediction.metadata.failureTimeSeconds = NaN;
        prediction.metadata.trajectoryCoveragePercent = 100;
        prediction.metadata.failureMessage = "";
    else
        prediction.metadata.rolloutSucceeded = false;
        prediction.metadata.rolloutStatus = "FAILED_INTEGRATION";
        if isempty(t)
            prediction.metadata.failureTimeSeconds = tspan(1);
            prediction.metadata.trajectoryCoveragePercent = 0;
        else
            prediction.metadata.failureTimeSeconds = t(end);
            prediction.metadata.trajectoryCoveragePercent = coverage_percent(t(end),truth.t);
        end
        if ~isempty(warnMsg)
            prediction.metadata.failureMessage = string(warnMsg);
        else
            prediction.metadata.failureMessage = sprintf( ...
                'ODE15I returned only %d/%d requested saved points and stopped at t=%.6g s.', ...
                numel(t),numel(tspan),prediction.metadata.failureTimeSeconds);
        end
    end

catch ME
    prediction.metadata.modelSolveTimeSeconds = toc(solveStart);
    prediction.metadata.rolloutSucceeded = false;
    prediction.metadata.residualEvaluationCount = residualEvaluationCount;
    if strcmp(ME.identifier,'simulate_offline_model_scenario:StateGuardExceeded')
        prediction.metadata.rolloutStatus = "EARLY_ABORT_EXCESSIVE_STATE";
        prediction.metadata.rolloutGuardTriggered = true;
        prediction.metadata.rolloutGuardReason = "absolute_state_internal";
        prediction.metadata.rolloutGuardValue = guardAbortValue;
        prediction.metadata.rolloutGuardThreshold = guard.maxAbsState;
        if isfinite(guardAbortTime)
            prediction.metadata.failureTimeSeconds = guardAbortTime;
            prediction.metadata.trajectoryCoveragePercent = coverage_percent(guardAbortTime,truth.t);
        else
            prediction.metadata.failureTimeSeconds = tspan(1);
            prediction.metadata.trajectoryCoveragePercent = 0;
        end
        prediction.metadata.failureMessage = sprintf( ...
            'Rollout guard stopped an internal ODE15I evaluation: max|y| %.6g exceeded limit %.6g.', ...
            guardAbortValue,guard.maxAbsState);
    elseif any(strcmp(ME.identifier,{ ...
            'simulate_offline_model_scenario:WallClockGuardExceeded', ...
            'simulate_offline_model_scenario:ResidualEvaluationGuardExceeded'}))
        prediction.metadata.rolloutStatus = "EARLY_ABORT_COMPUTATION_LIMIT";
        prediction.metadata.rolloutGuardTriggered = true;
        prediction.metadata.rolloutGuardReason = computationAbortReason;
        if isfinite(guardAbortTime)
            prediction.metadata.failureTimeSeconds = guardAbortTime;
            prediction.metadata.trajectoryCoveragePercent = coverage_percent(guardAbortTime,truth.t);
        else
            prediction.metadata.failureTimeSeconds = tspan(1);
            prediction.metadata.trajectoryCoveragePercent = 0;
        end
        if strcmp(ME.identifier,'simulate_offline_model_scenario:WallClockGuardExceeded')
            prediction.metadata.rolloutGuardValue = toc(solveStart);
            prediction.metadata.rolloutGuardThreshold = guard.maxWallClockSeconds;
            prediction.metadata.failureMessage = sprintf( ...
                ['Rollout computation guard stopped ODE15I after %.1f s of wall-clock ', ...
                 'time (limit %.1f s). The rollout is recorded as incomplete.'], ...
                prediction.metadata.rolloutGuardValue,guard.maxWallClockSeconds);
        else
            prediction.metadata.rolloutGuardValue = residualEvaluationCount;
            prediction.metadata.rolloutGuardThreshold = guard.maxResidualEvaluations;
            prediction.metadata.failureMessage = sprintf( ...
                ['Rollout computation guard stopped ODE15I after %d residual ', ...
                 'evaluations (limit %d). The rollout is recorded as incomplete.'], ...
                residualEvaluationCount,round(guard.maxResidualEvaluations));
        end
    else
        prediction.metadata.rolloutStatus = "FAILED_EXCEPTION";
        prediction.metadata.failureTimeSeconds = tspan(1);
        prediction.metadata.trajectoryCoveragePercent = 0;
        prediction.metadata.failureMessage = string(ME.message);
        prediction.metadata.failureIdentifier = string(ME.identifier);
        try
            prediction.metadata.failureStack = string(getReport(ME,'extended','hyperlinks','off'));
        catch
            prediction.metadata.failureStack = "";
        end
    end
end

    function F = guarded_residual(tNow,yNow,ypNow)
        % The residual is called during ODE15I Newton iterations, including
        % pathological cases where no output step is ever accepted. Guarding
        % here therefore prevents an unstable learned model from spending
        % tens of minutes shrinking an internal step before MATLAB gives up.
        residualEvaluationCount = residualEvaluationCount + 1;

        if guard.enabled
            if isfinite(guard.maxResidualEvaluations) && ...
                    residualEvaluationCount > guard.maxResidualEvaluations
                guardAbortTime = tNow;
                computationAbortReason = "residual_evaluation_limit";
                error('simulate_offline_model_scenario:ResidualEvaluationGuardExceeded', ...
                    'ODE15I exceeded the configured residual-evaluation limit.');
            end

            % TOC is checked only periodically so the guard adds negligible
            % overhead to healthy rollouts while still interrupting a stalled
            % Newton iteration promptly.
            if isfinite(guard.maxWallClockSeconds) && ...
                    (residualEvaluationCount == 1 || mod(residualEvaluationCount,25) == 0) && ...
                    toc(solveStart) > guard.maxWallClockSeconds
                guardAbortTime = tNow;
                computationAbortReason = "wall_clock_timeout";
                error('simulate_offline_model_scenario:WallClockGuardExceeded', ...
                    'ODE15I exceeded the configured rollout wall-clock limit.');
            end

            % A generous absolute-state guard is also checked inside the DAE
            % residual. This is a fallback for cases in which ODE15I enters an
            % extreme Newton trial before it can reach the terminal event root.
            amax = max(abs(yNow(:)));
            if ~isfinite(amax) || amax > guard.maxAbsState
                guardAbortTime = tNow;
                guardAbortValue = amax;
                error('simulate_offline_model_scenario:StateGuardExceeded', ...
                    'Internal DAE state exceeded the configured rollout guard.');
            end
        end
        F = offline_model_dae_residual(tNow,yNow,ypNow,model,method,c,layout);
    end

    function [value,isterminal,direction] = rollout_guard_events(tNow,yNow,~)
        % ODE15I event functions accept (t,y,yp). Both events terminate on
        % an increasing error/state magnitude crossing its configured bound.
        eNorm = normalized_error_at(tNow,yNow);
        amax = max(abs(yNow(:)));
        value = [guard.maxNormalizedError - eNorm; ...
                 guard.maxAbsState - amax];
        isterminal = [1;1];
        direction = [-1;-1];
    end

    function eNorm = normalized_error_at(tNow,yNow)
        yRef = interp1(truth.t,truth.y,tNow,'linear','extrap').';
        delta = abs(yNow(:)-yRef(:));
        eNorm = max(delta./guard.variableScale(:));
        if ~isfinite(eNorm)
            eNorm = inf;
        end
    end
end


function tspan = prepare_rollout_tspan(truth,c)
%PREPARE_ROLLOUT_TSPAN Return a finite, strictly increasing ODE15I tspan.
%
% The normal path is simply truth.t(:). The fallback is only used when a
% malformed reference time field has been squeezed to fewer than two points;
% in that case the configured common test grid is reconstructed and must
% still match the number of stored truth samples.

if ~isstruct(truth) || ~isfield(truth,'t') || isempty(truth.t)
    error('simulate_offline_model_scenario:MissingTruthTime', ...
        'Reference truth trajectory does not contain a nonempty time vector.');
end

tspan = double(truth.t(:));

if numel(tspan) < 2
    candidate = (double(c.sim.t0):double(c.sim.outputStep):double(c.sim.tf)).';
    if isempty(candidate) || abs(candidate(end)-double(c.sim.tf)) > ...
            10*eps(max(1,abs(double(c.sim.tf))))
        candidate(end+1,1) = double(c.sim.tf);
    end

    if isfield(truth,'y') && size(truth.y,1) == numel(candidate)
        warning('simulate_offline_model_scenario:ReconstructedTruthTimeGrid', ...
            ['truth.t contained fewer than two points; reconstructed the ', ...
             'configured common test grid (%d points) for rollout.'],numel(candidate));
        tspan = candidate;
    else
        nTruthRows = NaN;
        if isfield(truth,'y'), nTruthRows = size(truth.y,1); end
        error('simulate_offline_model_scenario:InvalidTruthTimeGrid', ...
            ['ODE15I requires at least two tspan points. truth.t has %d point(s), ', ...
             'truth.y has %g row(s), and the configured grid has %d points.'], ...
             numel(tspan),nTruthRows,numel(candidate));
    end
end

if any(~isfinite(tspan))
    error('simulate_offline_model_scenario:NonfiniteTruthTime', ...
        'Reference truth time vector contains NaN or Inf.');
end
if any(diff(tspan) <= 0)
    error('simulate_offline_model_scenario:NonmonotoneTruthTime', ...
        'Reference truth time vector must be strictly increasing.');
end
if isfield(truth,'y') && size(truth.y,1) ~= numel(tspan)
    error('simulate_offline_model_scenario:TruthTimeStateSizeMismatch', ...
        'truth.t has %d points but truth.y has %d rows.', ...
        numel(tspan),size(truth.y,1));
end
end

function guard = get_rollout_guard_options(cfg,truth)
guard = struct();
guard.enabled = false;
guard.maxNormalizedError = 100;
guard.maxAbsState = 1e3;
guard.scaleFloorRelative = 1e-3;
guard.scaleFloorAbsolute = 1e-6;
guard.maxWallClockSeconds = inf;
guard.maxResidualEvaluations = inf;

if isfield(cfg,'rolloutGuard') && isstruct(cfg.rolloutGuard)
    rg = cfg.rolloutGuard;
    if isfield(rg,'enabled'), guard.enabled = logical(rg.enabled); end
    if isfield(rg,'maxNormalizedError'), guard.maxNormalizedError = double(rg.maxNormalizedError); end
    if isfield(rg,'maxAbsState'), guard.maxAbsState = double(rg.maxAbsState); end
    if isfield(rg,'scaleFloorRelative'), guard.scaleFloorRelative = double(rg.scaleFloorRelative); end
    if isfield(rg,'scaleFloorAbsolute'), guard.scaleFloorAbsolute = double(rg.scaleFloorAbsolute); end
    if isfield(rg,'maxWallClockSeconds'), guard.maxWallClockSeconds = double(rg.maxWallClockSeconds); end
    if isfield(rg,'maxResidualEvaluations'), guard.maxResidualEvaluations = double(rg.maxResidualEvaluations); end
end

validateattributes(guard.maxNormalizedError,{'numeric'},{'scalar','real','positive','finite'}, ...
    mfilename,'cfg.rolloutGuard.maxNormalizedError');
validateattributes(guard.maxAbsState,{'numeric'},{'scalar','real','positive','finite'}, ...
    mfilename,'cfg.rolloutGuard.maxAbsState');
validateattributes(guard.scaleFloorRelative,{'numeric'},{'scalar','real','nonnegative','finite'}, ...
    mfilename,'cfg.rolloutGuard.scaleFloorRelative');
validateattributes(guard.scaleFloorAbsolute,{'numeric'},{'scalar','real','nonnegative','finite'}, ...
    mfilename,'cfg.rolloutGuard.scaleFloorAbsolute');
if ~(isscalar(guard.maxWallClockSeconds) && isreal(guard.maxWallClockSeconds) && ...
        (isinf(guard.maxWallClockSeconds) || ...
         (isfinite(guard.maxWallClockSeconds) && guard.maxWallClockSeconds > 0)))
    error('simulate_offline_model_scenario:InvalidWallClockGuard', ...
        'cfg.rolloutGuard.maxWallClockSeconds must be positive or Inf.');
end
if ~(isscalar(guard.maxResidualEvaluations) && isreal(guard.maxResidualEvaluations) && ...
        (isinf(guard.maxResidualEvaluations) || ...
         (isfinite(guard.maxResidualEvaluations) && guard.maxResidualEvaluations >= 1)))
    error('simulate_offline_model_scenario:InvalidResidualEvaluationGuard', ...
        'cfg.rolloutGuard.maxResidualEvaluations must be >=1 or Inf.');
end
if isfinite(guard.maxResidualEvaluations)
    guard.maxResidualEvaluations = round(guard.maxResidualEvaluations);
end

rmsScale = sqrt(mean(double(truth.y).^2,1));
globalReference = max([1,max(rmsScale)]);
commonFloor = max(guard.scaleFloorAbsolute,guard.scaleFloorRelative*globalReference);
guard.variableScale = max(rmsScale,commonFloor);
end

function pct = coverage_percent(tLast,tTruth)
% Percentage of the requested physical time horizon that was completed.
t0 = tTruth(1);
tf = tTruth(end);
if tf <= t0
    pct = 100;
else
    pct = 100*max(0,min(1,(tLast-t0)/(tf-t0)));
end
end
