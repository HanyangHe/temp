function [V,info] = solve_algebraic_voltage_for_sample(x,u,Vinitial,Vequilibrium,c,layout,pNom,opts)
%SOLVE_ALGEBRAIC_VOLTAGE_FOR_SAMPLE Solve g(x,V,u)=0 for non-slack V.
%
% The sampled x and u are fixed. Algebraic voltage z is solved so every
% accepted Sobol sample lies on the DAE constraint manifold.

ns = c.network.nonSlackBuses(:);
nv = numel(ns);

[sol,exitflag,fval,output] = solve_once(Vinitial);
if exitflag <= 0 || norm(fval,inf) > 1e-7
    % Retry from the nominal-equilibrium voltage if the warm start failed.
    [sol,exitflag,fval,output] = solve_once(Vequilibrium);
end

V = complex(zeros(c.network.N,1));
V(c.network.slackBus) = c.network.Vslack;
V(ns) = sol(1:nv) + 1i*sol(nv+1:end);

info.exitflag = exitflag;
info.residualInf = norm(fval,inf);
info.output = output;

    function [vsol,ef,rv,out] = solve_once(V0)
        y0 = [real(V0(ns));imag(V0(ns))];
        [vsol,rv,ef,out] = fsolve(@residual,y0,opts);
    end

    function r = residual(v)
        Vtrial = complex(zeros(c.network.N,1));
        Vtrial(c.network.slackBus) = c.network.Vslack;
        Vtrial(ns) = v(1:nv) + 1i*v(nv+1:end);
        [~,g] = mg_evaluate_physics(x,Vtrial,u,pNom,c,layout);
        r = [real(g);imag(g)];
    end
end
