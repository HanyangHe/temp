function [offlineData,onlineData,info] = build_online_local_module_data( ...
    baseDataset,observations,triggerTime,c,layout,deviceType,deviceIndex,cfg)
%BUILD_ONLINE_LOCAL_MODULE_DATA Causal local data for one affected DER module.
%
% The offline block remains the original nominal training pool. The online
% block contains only observations available at/before triggerTime and is
% sampled at cfg.online.update.sampleStep. No future point is exposed.

if ~isfinite(triggerTime)
    error('build_online_local_module_data:TriggerTime', ...
        'A finite triggerTime is required.');
end

uopt = cfg.online.update;
t = observations.t(:);
startTime = t(1);
if isfinite(uopt.historyWindowSeconds)
    startTime = max(startTime,triggerTime-double(uopt.historyWindowSeconds));
end

step = double(uopt.sampleStep);
if step <= 0
    error('build_online_local_module_data:SampleStep', ...
        'cfg.online.update.sampleStep must be positive.');
end
% Retain samples on the requested online-adaptation grid. If a newly
% re-armed detector fires before enough post-regime-change samples have been
% collected, wait causally for the minimum sample pool instead of failing or
% polluting the update with data from the preceding regime.
if numel(t)>1
    dtSaved = median(diff(t));
else
    dtSaved = step;
end
tol = max(1e-9,0.25*abs(dtSaved));
waitForMinimum = true;
if isfield(uopt,'waitForMinimumSamples')
    waitForMinimum = logical(uopt.waitForMinimumSamples);
end

candidateAll = find(t >= startTime-1e-12);
if isempty(candidateAll)
    error('build_online_local_module_data:NoSamples', ...
        'No online samples are available in the current update stage.');
end
t0 = t(candidateAll(1));
phaseAll = round((t(candidateAll)-t0)/step);
targetAll = t0 + phaseAll*step;
keepAll = abs(t(candidateAll)-targetAll) <= tol;
gridIdx = candidateAll(keepAll);

idx = gridIdx(t(gridIdx) <= triggerTime+1e-12);
effectiveDataEndTime = triggerTime;
if numel(idx) < uopt.minimumOnlineSamples
    if ~waitForMinimum
        error('build_online_local_module_data:TooFewSamples', ...
            ['Only %d online samples are available at trigger t=%.6g s; ', ...
             'minimumOnlineSamples=%d.'], ...
            numel(idx),triggerTime,uopt.minimumOnlineSamples);
    end
    if numel(gridIdx) < uopt.minimumOnlineSamples
        error('build_online_local_module_data:TooFewSamplesInRemainingHorizon', ...
            ['Only %d online samples remain after stage start t=%.6g s; ', ...
             'minimumOnlineSamples=%d.'], ...
            numel(gridIdx),startTime,uopt.minimumOnlineSamples);
    end
    idx = gridIdx(1:uopt.minimumOnlineSamples);
    effectiveDataEndTime = t(idx(end));
else
    effectiveDataEndTime = t(idx(end));
end

% Original nominal data for covariance/prior-information initialization.
offlineData = build_sindy_module_data( ...
    baseDataset,c,layout,deviceType,deviceIndex);

% Build a compact synthetic pointwise dataset from the causal observation
% prefix so the same local-data constructor is reused for all SINDy variants.
n = numel(idx);
D = struct();
D.x = observations.x(:,idx).';
D.V = observations.V(:,idx).';
D.labels = observations.xdotObserved(:,idx).';
D.labelsClean = observations.xdotClean(:,idx).';
D.trajectoryId = ones(n,1);
D.pointInTrajectory = (1:n).';
D.sampleInputByRow = cell(n,1);
for i=1:n
    D.sampleInputByRow{i} = online_input_at_observation(observations,idx(i));
end
D.trajectories = struct();
D.trajectories.nTrajectories = 1;
D.trajectories.pointsPerTrajectory = n;
D.trajectories.t = t(idx);
D.trajectories.uByTrajectory = {D.sampleInputByRow{end}};
D.trajectories.forceTrainingMask = true;
D.trajectories.sourceType = "online_observation_prefix";
D.trajectories.isTestInitialAnchor = false;
D.xObservedFlat = D.x;

onlineData = build_sindy_module_data(D,c,layout,deviceType,deviceIndex);

info = struct();
info.deviceType = lower(char(deviceType));
info.deviceIndex = deviceIndex;
info.uniqueSampleIndices = idx(:);
info.uniqueSampleTimes = t(idx);
info.offlineSampleCount = size(baseDataset.x,1);
info.onlineUniqueSampleCount = n;
info.onlineUsedSampleCount = n;
info.onlineReplicatedRowCount = 0; % retained for replay-table compatibility
info.timeRange = [t(idx(1)) t(idx(end))];
info.sampleStep = step;
info.requestedTriggerTime = triggerTime;
info.effectiveDataEndTime = effectiveDataEndTime;
info.sampleAccumulationDelaySeconds = max(0,effectiveDataEndTime-triggerTime);
info.waitedForMinimumSamples = info.sampleAccumulationDelaySeconds > 1e-12;
end
