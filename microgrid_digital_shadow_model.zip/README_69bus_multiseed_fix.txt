69-BUS LLM-PRIOR THREE-SEED FIGURE/TABLE CONSISTENCY FIX (2026-10-08)
=======================================================================

Confirmed cause from user's independent source audit:
  69-bus N=500/clean LLM-Prior saved RMSE by DATA seed:
    20260814: 1.7399e-08
    20260815: 1.4280e-05
    20260816: 2.7701e-08
  All 3 use FROZEN discovery seed 20260814 / prior hash 3755CE11.
  Three-data-seed mean: 4.7750e-06; sample std: 8.2315e-06.
  Old Figure 3 instead used ONLY seed 20260814 (1/1, 1.7399e-08).

REPLACE EXISTING FILES at project-relative paths:
  config_offline_experiment_69bus.m
  experiments/prepare_offline_llm_prior_config.m
  run_offline_model_experiments_multiseed.m
  utils/plot_offline_sample_sensitivity_multiseed.m
  utils/plot_offline_noise_robustness_multiseed.m

ADD TEMPORARY FILE (not a replacement of any existing code):
  tests/temp_fix_rebuild_69bus_llm_multiseed_figures.m

MATLAB, from PROJECT ROOT:
  clear functions;
  rehash toolboxcache;
  addpath(genpath(pwd));
  Report = temp_fix_rebuild_69bus_llm_multiseed_figures(pwd);

WHAT THIS WILL DO:
  1. Verify the frozen LLM bank/hash and each of three official N=500 records.
  2. Back up the existing multiseed_summary folder to an adjacent directory.
  3. Invoke the OFFICIAL run_offline_model_experiments_multiseed with
     aggregateOnly=true (no training, no ODE integration, no LLM API calls).
  4. Validate complete three-data-seed coverage for all six official methods
     and all conditions DISPLAYED in 69-bus sample/noise manuscript figures.
     Missing or incompatible rows STOP execution BEFORE overwriting results.
  5. Re-export the two corrected figures/CSV/MAT into the EXISTING path:
     outputs/offline_model_experiments_69bus/multiseed_summary/
  6. Recheck N=500 LLM three-data-seed mean/std and seed IDs after export.

EXPECTED KEY VALUES AFTER SUCCESS:
   N=250  : mean RMSE 6.4903e-05
   N=500  : mean RMSE 4.7750e-06; sample std 8.2315e-06
   N=2000 : mean RMSE 4.0699e-10
   noise0.5% at N=500: mean RMSE 5.6978e-04
   noise5%   at N=500: mean RMSE 2.0349e-03

NOTE:
- The last two 69-bus data seeds share ONE LLM discovery bank. The 10- and
  123-bus saved results use PER-data-seed discovery and are NOT modified.
- This change repairs the 69-bus official aggregates; it does NOT change
  10-/123-bus experiments nor scientific MAT bundles, dataset caches, or NODE.
- To update IEEE manuscript figures, copy the two newly exported PDFs from
  multiseed_summary into the figures folder used by the LaTeX manuscript
  (use the same filenames). Do not reuse the old one-seed figure PDF.
- The patch was statically checked in this environment. MATLAB execution
  requires your workstation, where the existing official MAT bundles live.
