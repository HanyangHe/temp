function written = write_node_diagnostic_tables(evaluation,outputDir,prefix)
%WRITE_NODE_DIAGNOSTIC_TABLES Export saved NODE diagnostics to CSV files.
%
% This function only writes fields already stored in evaluation.diagnostics;
% it never retrains or reruns the model, so it is safe for result replay.

if nargin < 3 || isempty(prefix)
    prefix = 'node_diagnostic';
end
written = strings(0,1);
if ~isfield(evaluation,'diagnostics') || ~isstruct(evaluation.diagnostics) || ...
        ~isfield(evaluation.diagnostics,'node')
    return;
end
D = evaluation.diagnostics.node;
if ~exist(outputDir,'dir'), mkdir(outputDir); end
prefix = char(string(prefix));

written = write_if_table(D,'validationPerState', ...
    fullfile(outputDir,[prefix '_validation_per_state.csv']),written);
written = write_if_table(D,'validationModuleSummary', ...
    fullfile(outputDir,[prefix '_validation_module_summary.csv']),written);
written = write_if_table(D,'equilibriumPerState', ...
    fullfile(outputDir,[prefix '_equilibrium_per_state.csv']),written);
written = write_if_table(D,'equilibriumModuleSummary', ...
    fullfile(outputDir,[prefix '_equilibrium_module_summary.csv']),written);

if isfield(D,'teacherForced') && isstruct(D.teacherForced)
    TF = D.teacherForced;
    written = write_if_table(TF,'moduleStatus', ...
        fullfile(outputDir,[prefix '_truth_forced_module_status.csv']),written);
    written = write_if_table(TF,'moduleSummary', ...
        fullfile(outputDir,[prefix '_truth_forced_module_summary.csv']),written);
    if isfield(TF,'perStateMetricsAll') && istable(TF.perStateMetricsAll) && ...
            ~isempty(TF.perStateMetricsAll)
        file = fullfile(outputDir,[prefix '_truth_forced_per_state.csv']);
        writetable(strip_nrmse_report_data(TF.perStateMetricsAll),file);
        written(end+1,1) = string(file); %#ok<AGROW>
    elseif isfield(TF,'perStateMetrics') && istable(TF.perStateMetrics) && ...
            ~isempty(TF.perStateMetrics)
        file = fullfile(outputDir,[prefix '_truth_forced_per_state.csv']);
        writetable(strip_nrmse_report_data(TF.perStateMetrics),file);
        written(end+1,1) = string(file); %#ok<AGROW>
    end
end

if isfield(D,'closedLoopState') && isstruct(D.closedLoopState) && ...
        isfield(D.closedLoopState,'perStateMetrics') && ...
        istable(D.closedLoopState.perStateMetrics) && ...
        ~isempty(D.closedLoopState.perStateMetrics)
    file = fullfile(outputDir,[prefix '_closed_loop_state_per_state.csv']);
    writetable(strip_nrmse_report_data(D.closedLoopState.perStateMetrics),file);
    written(end+1,1) = string(file); %#ok<AGROW>
end
end

function written = write_if_table(S,fieldName,file,written)
if isfield(S,fieldName) && istable(S.(fieldName)) && ~isempty(S.(fieldName))
    writetable(strip_nrmse_report_data(S.(fieldName)),file);
    written(end+1,1) = string(file); %#ok<AGROW>
end
end
