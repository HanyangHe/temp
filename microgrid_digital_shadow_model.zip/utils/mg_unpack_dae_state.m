function [x,V] = mg_unpack_dae_state(y,c,layout)
%MG_UNPACK_DAE_STATE Recover x and the full complex bus-voltage vector.

if numel(y) ~= layout.ny
    error('mg_unpack_dae_state:StateSize', ...
        'DAE vector has %d entries; expected %d.',numel(y),layout.ny);
end
x = y(1:layout.nx);
ns = c.network.nonSlackBuses;
nv = numel(ns);
Vr = y(layout.nx + (1:nv));
Vi = y(layout.nx + nv + (1:nv));
V = complex(zeros(c.network.N,1));
V(c.network.slackBus) = c.network.Vslack;
V(ns) = Vr + 1i*Vi;
end
