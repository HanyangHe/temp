function info = plot_receding_horizon_rmse_violin(T,cfg,outDir)
%PLOT_RECEDING_HORIZON_RMSE_VIOLIN Paper-facing violin-only RMSE figure.
%
% The figure reports the distribution of log10(12-s trajectory RMSE) over
% the successful receding-horizon prediction windows. Failed windows are
% not converted into artificial numerical errors; their counts remain in
% the companion summary table through SuccessRate_percent.
%
% Output files:
%   receding_horizon_rmse_violin.fig
%   receding_horizon_rmse_violin.png
%   receding_horizon_rmse_violin.pdf

if exist(outDir,'dir') ~= 7, mkdir(outDir); end
methods = string(cfg.receding.methods(:));
displayNames = strings(size(methods));
for i = 1:numel(methods)
    displayNames(i) = display_name_local(methods(i));
end

fig = figure('Visible',cfg.figures.visible,'Color','w', ...
    'Position',[100 100 760 430]);
ax = axes(fig); hold(ax,'on'); box(ax,'on'); grid(ax,'on');

for i = 1:numel(methods)
    q = T(string(T.Method)==methods(i) & T.RolloutSucceeded & ...
        isfinite(T.RMSE) & T.RMSE>0,:);
    x = log10(double(q.RMSE));
    color = color_local(methods(i));
    if isempty(x), continue; end

    [gridY,dens] = kde_gaussian_local(x);
    if max(dens)>0
        dens = 0.36*dens/max(dens);
    else
        dens = zeros(size(dens));
    end

    patch(ax,[i-dens(:); flipud(i+dens(:))], ...
        [gridY(:); flipud(gridY(:))],color, ...
        'FaceAlpha',0.22,'EdgeColor',color,'LineWidth',1.15, ...
        'HandleVisibility','off');

    % Individual successful windows and the median line.
    plot(ax,repmat(i,size(x)),x,'.','Color',color,'MarkerSize',6, ...
        'HandleVisibility','off');
    plot(ax,[i-0.22 i+0.22],[median(x) median(x)],'-', ...
        'Color',color,'LineWidth',2.2,'HandleVisibility','off');
end

xlim(ax,[0.4 numel(methods)+0.6]);
set(ax,'XTick',1:numel(methods),'XTickLabel',cellstr(displayNames));
xtickangle(ax,20);
ylabel(ax,'log_{10}(12-s trajectory RMSE)','Interpreter','tex');
% Slightly larger axis text for IEEE print, without expanding the canvas.
set(ax,'FontName','Times New Roman','FontSize',11,'LineWidth',0.8);
ax.YLabel.FontName='Times New Roman';
ax.YLabel.FontSize=12;
ax.XLabel.FontName='Times New Roman';
ax.GridAlpha = 0.20;

% Keep the manuscript panel free of an internal title; the IEEE caption
% provides the description.
title(ax,'');

base = fullfile(outDir,'receding_horizon_rmse_violin');
info = export_local(fig,base,cfg);
close(fig);
end

function [gridY,dens] = kde_gaussian_local(x)
x = double(x(:));
n = numel(x);
if n==1
    span = max(0.05,0.05*max(1,abs(x)));
    gridY = linspace(x-span,x+span,160).';
    h = span/3;
else
    sx = std(x,0);
    spread = max(x)-min(x);
    if ~isfinite(sx) || sx<=eps
        sx = max(0.05,spread/4);
    end
    h = 1.06*sx*n^(-1/5);
    h = max(h,max(0.02,0.03*max(spread,1e-3)));
    pad = max(3*h,0.08*max(spread,0.1));
    gridY = linspace(min(x)-pad,max(x)+pad,180).';
end
Z = (gridY-x.')./h;
dens = mean(exp(-0.5*Z.^2),2)/(sqrt(2*pi)*h);
end

function s = display_name_local(method)
switch lower(char(method))
    case 'modular_koopman_kbf', s="M-KBF";
    case 'vanilla_sindy', s="V-SINDy";
    case 'physics_embedded_sindy', s="PE-SINDy";
    case 'edsi', s="ED-SINDy";
    case 'neural_ode_modular', s="NODE";
    case 'llm_prior_sindy', s="LLM-Prior SINDy";
    otherwise, s=string(method);
end
end

function c = color_local(name)
switch lower(char(name))
    case 'modular_koopman_kbf', c=[0.10 0.10 0.10];
    case 'vanilla_sindy', c=[0.00 0.4470 0.7410];
    case 'physics_embedded_sindy', c=[0.4660 0.6740 0.1880];
    case 'edsi', c=[0.4940 0.1840 0.5560];
    case 'neural_ode_modular', c=[0.9290 0.6940 0.1250];
    case 'llm_prior_sindy', c=[0.8500 0.0500 0.0500];
    otherwise, c=[0.3 0.3 0.3];
end
end

function info = export_local(fig,base,cfg)
info = struct('png','','pdf','','fig','');
info.fig = [base '.fig'];
savefig(fig,info.fig);
if ~isfield(cfg.figures,'exportPNG') || cfg.figures.exportPNG
    info.png = [base '.png'];
    exportgraphics(fig,info.png,'Resolution',300);
end
if ~isfield(cfg.figures,'exportPDF') || cfg.figures.exportPDF
    info.pdf = [base '.pdf'];
    exportgraphics(fig,info.pdf,'ContentType','vector');
end
end
