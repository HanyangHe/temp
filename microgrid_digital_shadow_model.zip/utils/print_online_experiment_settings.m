function print_online_experiment_settings(cfg,cNominal,cTruth,plan)
%PRINT_ONLINE_EXPERIMENT_SETTINGS Concise online-experiment reproducibility report.

fprintf('\n---------------- ONLINE MODEL EXPERIMENT SETTINGS ----------------\n');
fprintf('Initial model source : saved Offline Part-1 model\n');
fprintf('Initial condition     : N=%d | training-label noise=%.4g%%\n', ...
    cfg.online.initialModelSampleCount,100*cfg.online.initialModelNoiseLevel);
fprintf('Online observation    : x/V/u/xdot | xdot noise=%.4g%% | seed=%d\n', ...
    100*cfg.online.observationNoiseLevel,cfg.online.observationNoiseSeed);
fprintf('Online adaptation     : %s\n',onoff(cfg.online.update.enabled));
fprintf('Truth horizon         : %.3f to %.3f s\n',cTruth.sim.t0,cTruth.sim.tf);
fprintf('Prediction physics    : nominal algebraic network; parameter mismatch hidden from model\n');

D=cTruth.drift;
fprintf('[Parameter mismatch schedule]\n');
devices=double(D.device(:).');
fprintf('  target              : %s devices %s, parameter %s\n', ...
    upper(char(string(D.deviceType))),mat2str(devices),char(string(D.parameter)));
fprintf('  representative plot : %s device %d\n', ...
    upper(char(string(D.deviceType))),devices(1));
if isfield(D,'component') && ~strcmpi(string(D.component),'all')
    fprintf('  component           : %s\n',char(string(D.component)));
end
fprintf('  profile             : %s\n',char(string(D.profile)));

p0=mg_parameter_profile(cNominal.sim.t0,cNominal);
type=lower(char(D.deviceType));
field=char(D.parameter);
vNom=zeros(1,numel(devices));
for iDev=1:numel(devices)
    vNom(iDev)=p0.(type)(devices(iDev)).(field);
end
fprintf('  nominal values      : %s\n',mat2str(vNom,8));
if isfield(D,'times') && isfield(D,'values') && ~isempty(D.times)
    fprintf('  schedule mode       : %s\n',char(string(D.mode)));
    for iSch=1:numel(D.times)
        ctmp=cNominal;
        ctmp.drift=D;
        ctmp.drift.enabled=true;
        ctmp.drift.times=D.times(iSch);
        ctmp.drift.values=D.values(iSch);
        ctmp.drift.profile='piecewise_constant';
        pNow=mg_parameter_profile(D.times(iSch),ctmp);
        vNow=zeros(1,numel(devices));
        for iDev=1:numel(devices)
            vNow(iDev)=pNow.(type)(devices(iDev)).(field);
        end
        fprintf('  level %d            : t >= %.3f s | control value %.6g | true values %s\n', ...
            iSch,D.times(iSch),D.values(iSch),mat2str(vNow,8));
    end
else
    fprintf('  mode/value          : %s / %s\n',char(string(D.mode)),mat2str(D.value));
    p1=mg_parameter_profile(cTruth.sim.t0,cTruth);
    v1=zeros(1,numel(devices));
    for iDev=1:numel(devices)
        v1(iDev)=p1.(type)(devices(iDev)).(field);
    end
    fprintf('  true test values    : %s\n',mat2str(v1,8));
end

U=cfg.online.update;
fprintf('[Module-wise mismatch detector]\n');
fprintf('  metric              : %s\n',char(string(U.detector.metric)));
fprintf('  rolling window      : %.3f s\n',U.detector.windowSeconds);
fprintf('  base threshold      : %.6g\n',U.detector.threshold);
fprintf('  minimum trigger time: %.3f s\n',U.detector.minimumTriggerTime);
fprintf('  consecutive windows : %d\n',U.detector.requiredConsecutiveWindows);
if isfield(U.detector,'fixedModuleThresholds') && ~isempty(U.detector.fixedModuleThresholds)
    fprintf('  calibration         : FIXED held-out nominal-trajectory thresholds\n');
    fprintf('  fixed thresholds    : %s\n',mat2str(double(U.detector.fixedModuleThresholds(:).'),6));
    if isfield(U.detector,'trajectoryCalibrationQuantile')
        fprintf('  trajectory calib.   : q=%.4f | multiplier=%.3g', ...
            U.detector.trajectoryCalibrationQuantile, ...
            U.detector.trajectoryCalibrationMultiplier);
        if isfield(U.detector,'trajectoryCalibrationNoiseSeed')
            fprintf(' | noise seed=%d',U.detector.trajectoryCalibrationNoiseSeed);
        end
        fprintf('\n');
    end
elseif isfield(U.detector,'calibrateFromOffline') && U.detector.calibrateFromOffline
    fprintf('  offline calibration : ON | q=%.4f | multiplier=%.3g\n', ...
        U.detector.baselineQuantile,U.detector.baselineMultiplier);
else
    fprintf('  calibration         : OFF; base/fixed threshold policy\n');
end
if isfield(U,'maximumUpdateAttempts')
    fprintf('  max update attempts : %d\n',U.maximumUpdateAttempts);
end
if isfield(U,'maximumAcceptedUpdates')
    fprintf('  max accepted updates: %d\n',U.maximumAcceptedUpdates);
end
if isfield(U,'refractorySeconds')
    fprintf('  re-arm refractory   : %.3f s\n',U.refractorySeconds);
end
fprintf('[Fast online model correction]\n');
fprintf('  strategy            : %s\n',char(string(U.strategy)));
fprintf('  localization        : detector re-arms after accepted OR rejected candidates\n');
fprintf('  sample step         : %.4f s | minimum causal samples=%d\n', ...
    U.sampleStep,U.minimumOnlineSamples);
if isfield(U,'waitForMinimumSamples')
    fprintf('  insufficient pool   : %s (wait causally for minimum samples)\n', ...
        onoff(U.waitForMinimumSamples));
end
fprintf('  history window      : %s\n',window_text(U.historyWindowSeconds));
activeMethods=lower(string({plan.methodName}));
if any(activeMethods=="physics_neural_compositional_sindy") && ...
        isfield(U,'pncLayer2') && isstruct(U.pncLayer2)
    P=U.pncLayer2;
    fprintf('  PNC layer 1         : FROZEN Xi_1 / frozen PE-SINDy backbone\n');
    fprintf('  PNC feature banks   : FROZEN flat-PN bank + frozen compositional bank\n');
    fprintf('  PNC layer 2         : Xi_2 only over [PE bypass, flat-PN skip, composition] | support reselection=%s\n', ...
        onoff(P.supportReselection));
    fprintf('  PNC internal val    : %.1f%% causal holdout | min %d samples\n', ...
        100*P.validationFraction,P.minimumValidationSamples);
    fprintf('  PNC threshold grid  : %s\n',mat2str(P.thresholdGrid));
    fprintf('  PNC prior/offline   : prior precision %.3g | offline info weight %.3g\n', ...
        P.priorPrecision,P.offlineInformationWeight);
    fprintf('  PNC online weight   : %.4g per causal observation\n',P.onlineSampleWeight);
    fprintf('  PNC forgetting      : half-life %.3f s\n',P.forgettingHalfLifeSeconds);
end
if any(activeMethods=="llm_prior_sindy") && isfield(U,'localRLS') && isstruct(U.localRLS)
    fprintf('  LLM-Prior dictionary: FROZEN (no online LLM call)\n');
    fprintf('  LLM-Prior support   : FROZEN from offline sparse model\n');
    fprintf('  LLM-Prior update    : localized active coefficient matrix only\n');
    fprintf('  RLS offline weight  : %.4g\n',U.localRLS.offlineDataWeight);
    fprintf('  RLS online weight   : %.4g per causal observation\n',U.localRLS.onlineSampleWeight);
    fprintf('  RLS forgetting      : half-life %.3f s\n',U.localRLS.forgettingHalfLifeSeconds);
    fprintf('  training delay      : measured coefficient-update wall-clock time\n');
elseif isfield(U,'localRLS') && isstruct(U.localRLS) && ...
        any(ismember(activeMethods,["vanilla_sindy","physics_embedded_sindy","physics_neural_sindy"]))
    fprintf('  SINDy local update  : frozen dictionary/support coefficient RLS\n');
end
fprintf('  deployment compute  : %.3g x measured local-update time\n',U.trainingDelayScale);

fprintf('[Candidate validation / activation]\n');
fprintf('  validation          : %s\n',onoff(U.validation.enabled));
if U.validation.enabled
    fprintf('  new-data window     : %.3f s | minimum samples=%d\n', ...
        U.validation.windowSeconds,U.validation.minimumSamples);
    fprintf('  required improvement: %.2f%% relative\n', ...
        100*U.validation.requiredRelativeImprovement);
end
fprintf('  state synchronization at activation: %s (full deployment)\n', ...
    onoff(U.stateSynchronizationAtActivation));

if isfield(cfg.online,'tracking') && isstruct(cfg.online.tracking) && ...
        isfield(cfg.online.tracking,'enabled') && cfg.online.tracking.enabled
    fprintf('[Non-delay tracking metrics]\n');
    fprintf('  definition          : exclude accepted mismatch/update delay intervals\n');
    fprintf('  reporting           : system RMSE/MAE + perturbed-device terminal-voltage RMSE/MAE\n');
    fprintf('  purpose             : separate active-model tracking quality from adaptation latency\n');
end

if isfield(cfg.online,'ablation') && isstruct(cfg.online.ablation) && ...
        isfield(cfg.online.ablation,'enabled') && cfg.online.ablation.enabled
    fprintf('[Stage-3 online attribution ablation]\n');
    fprintf('  factors             : coefficient adaptation x state synchronization\n');
    variants=string(cfg.online.ablation.variants);
    fprintf('  variants            : %s\n',strjoin(cellstr(variants),', '));
    fprintf('  common schedule     : accepted adaptive activation times\n');
    fprintf('  purpose             : separate coefficient correction from state reset\n');
end

fprintf('[Baseline deployment modes]\n');
for k=1:numel(plan)
    fprintf('  %-30s frozen=%s | online=%s\n', ...
        plan(k).methodName,onoff(plan(k).frozen),onoff(plan(k).online));
end
fprintf('Output folder         : outputs/%s\n',cfg.output.folderName);
fprintf('------------------------------------------------------------------\n');
end

function s=onoff(v)
if v
    s='ON';
else
    s='OFF';
end
end

function s=window_text(x)
if isinf(x)
    s='all samples since current update stage began';
else
    s=sprintf('last %.3f s',x);
end
end
