function out = strip_nrmse_report_data(in)
%STRIP_NRMSE_REPORT_DATA Remove NRMSE fields/columns from report-facing data.
%
% Internal trajectory-metric computation may still calculate NRMSE for
% compatibility and diagnostics. This helper is used only at report/export
% boundaries so NRMSE is not written to CSV/MAT report artifacts or shown in
% replay tables. Any table variable or struct field whose name contains
% "NRMSE" (case-insensitive) is removed recursively.

out = in;

if istable(out)
    names = string(out.Properties.VariableNames);
    drop = contains(upper(names),'NRMSE');
    if any(drop)
        out(:,cellstr(names(drop))) = [];
    end
    return;
end

if isstruct(out)
    fn = fieldnames(out);
    drop = contains(upper(string(fn)),'NRMSE');
    if any(drop)
        out = rmfield(out,fn(drop));
    end
    fn = fieldnames(out);
    for iElem = 1:numel(out)
        for k = 1:numel(fn)
            try
                out(iElem).(fn{k}) = strip_nrmse_report_data(out(iElem).(fn{k}));
            catch
                % Leave unsupported/custom values untouched.
            end
        end
    end
    return;
end

if iscell(out)
    for k = 1:numel(out)
        out{k} = strip_nrmse_report_data(out{k});
    end
end
end
