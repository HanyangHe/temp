function layout = mg_build_state_layout(c)
%MG_BUILD_STATE_LAYOUT Deterministic state ordering for all dynamic devices.
%
% SG layouts supported:
%   classical/default     : [delta, nu]                         (2 states)
%   salient_avr_5state    : [delta, nu, EqPrime, EdPrime, Efd] (5 states)

layout.sg = cell(numel(c.sg),1);
layout.gfm = cell(numel(c.gfm),1);
layout.gfl = cell(numel(c.gfl),1);
idx = 0;
for k = 1:numel(c.sg)
    nsg = sg_state_count(c.sg(k));
    layout.sg{k} = idx + (1:nsg);
    idx = idx + nsg;
end
for k = 1:numel(c.gfm)
    layout.gfm{k} = idx + (1:4);
    idx = idx + 4;
end
for k = 1:numel(c.gfl)
    layout.gfl{k} = idx + (1:4);
    idx = idx + 4;
end
layout.nx = idx;
layout.nvAlg = 2*numel(c.network.nonSlackBuses);
layout.ny = layout.nx + layout.nvAlg;
end

function n = sg_state_count(p)
if isfield(p,'model') && strcmpi(string(p.model),'salient_avr_5state')
    n = 5;
else
    n = 2;
end
end
