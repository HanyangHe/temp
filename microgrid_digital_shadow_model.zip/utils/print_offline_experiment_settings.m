function print_offline_experiment_settings(cfg)
%PRINT_OFFLINE_EXPERIMENT_SETTINGS Report active trajectory/model settings.

fprintf('\n---------------- OFFLINE TRAINING-DATA SETTINGS ----------------\n');
fprintf('Typical N       : %d\n',cfg.typicalSampleCount);
fprintf('Sample sweep    : [%s]\n',strtrim(sprintf('%d ',cfg.sampleCounts)));
fprintf('Noise levels (%%): [%s]\n',strtrim(sprintf('%.3g ',100*cfg.noiseLevels)));
if isfield(cfg,'displayTrueSys')
    fprintf('Display oracle  : %s (truth trajectory itself is always retained)\n', ...
        mat2str(cfg.displayTrueSys));
end
if isfield(cfg,'parallel') && isstruct(cfg.parallel)
    enabled = isfield(cfg.parallel,'enabled') && logical(cfg.parallel.enabled);
    nWorkers = 1;
    if isfield(cfg.parallel,'numWorkers') && ~isempty(cfg.parallel.numWorkers)
        nWorkers = round(double(cfg.parallel.numWorkers));
    end
    fprintf('[Section-level parallel execution]\n');
    fprintf('  enabled         : %s | requested workers=%d\n',onoff(enabled),nWorkers);
    fprintf('  hierarchy       : seeds SERIAL -> sections SERIAL -> jobs within each section PARFOR\n');
    fprintf('  section 1.1/1.2/1.3: %s / %s / %s\n', ...
        onoff(parallel_section_enabled_local(cfg,'section1p1')), ...
        onoff(parallel_section_enabled_local(cfg,'section1p2')), ...
        onoff(parallel_section_enabled_local(cfg,'section1p3')));
    fprintf('  common data/noise realizations are prepared serially before each section queue\n');
    fprintf('  section tables/bundles/figures are written serially after the parfor barrier\n');
end
L = cfg.data.pointsPerTrajectory;
useTestInitialAnchor = true;
if isfield(cfg.data,'includeTestInitialAnchor') && ~isempty(cfg.data.includeTestInitialAnchor)
    useTestInitialAnchor = logical(cfg.data.includeTestInitialAnchor);
end
fprintf('Training format : common short DAE truth trajectories\n');
fprintf('Points/trajectory: %d | saved dt %.4f s | duration %.3f s\n', ...
    L,cfg.data.trajectorySampleStep,cfg.data.trajectoryDuration);
for N = cfg.sampleCounts(:).'
    K = N/L;
    if useTestInitialAnchor
        fprintf('  N=%d -> 1 test-initial anchor + %d Sobol trajectories, all x %d points\n',N,K-1,L);
    else
        fprintf('  N=%d -> %d Sobol initial trajectories x %d points\n',N,K,L);
    end
end
if useTestInitialAnchor
    fprintf(['Anchor rule     : formal test (x0,u0); freeze u(t0) for one %.3f-s short trajectory; ', ...
        'future test events are not exposed\n'],cfg.data.trajectoryDuration);
    fprintf('Anchor split    : forced into learned-method training; never assigned to validation\n');
end
fprintf('Clean-data rule : pointwise methods use exact xdot labels; NODE retains grouped trajectories\n');
fprintf('Noise-data rule : one noisy state trajectory is shared by all methods; pointwise xdot labels are reconstructed from it\n');
fprintf('Sobol rule      : remaining trajectories sample (x0,u0); solve z0 from g=0; then run true DAE\n');
fprintf('Accepted |V|    : [%.3f, %.3f] pu over each complete short trajectory\n', ...
    cfg.data.acceptVoltageMinPU,cfg.data.acceptVoltageMaxPU);
fprintf('Load scale      : [%.2f, %.2f] x nominal\n',cfg.sampling.input.loadScaleRange);
fprintf('SG Pm scale     : [%.2f, %.2f] x nominal\n',cfg.sampling.input.sgPmScaleRange);
if isfield(cfg.sampling.input,'sgVrefAddRangePU')
    fprintf('SG Vref add     : [%+.4f, %+.4f] pu\n',cfg.sampling.input.sgVrefAddRangePU);
else
    fprintf('SG Vref add     : [-0.0150, +0.0150] pu (default)\n');
end
fprintf('GFM P* add      : [%+.4f, %+.4f] pu\n',cfg.sampling.input.gfmPstarAddRangePU);
fprintf('GFM Q* add      : [%+.4f, %+.4f] pu\n',cfg.sampling.input.gfmQstarAddRangePU);
fprintf('GFM Eref add    : [%+.4f, %+.4f] pu\n',cfg.sampling.input.gfmErefAddRangePU);
fprintf('GFL P* add      : [%+.4f, %+.4f] pu\n',cfg.sampling.input.gflPstarAddRangePU);
fprintf('GFL Q* add      : [%+.4f, %+.4f] pu\n',cfg.sampling.input.gflQstarAddRangePU);

if isfield(cfg,'node') && isfield(cfg.node,'enabled') && cfg.node.enabled
    fprintf('[Neural ODE baseline]\n');
    fprintf('  scope           : modular DER dynamics; exact algebraic network retained\n');
    fprintf('  objective       : multi-step short-trajectory state loss\n');
    fprintf('  hidden layers   : [%s], tanh\n',strtrim(sprintf('%d ',cfg.node.hiddenSizes)));
    fprintf('  gradient mode   : %s (dlode45)\n',cfg.node.gradientMode);
    if isfield(cfg.node,'trainingProtocolVersion')
        fprintf('  training protocol: %s\n',cfg.node.trainingProtocolVersion);
    end
    fprintf('  validation      : %.1f%% whole-trajectory holdout | restarts=%d\n', ...
        100*cfg.node.validationFraction,cfg.node.numRestarts);
    if isfield(cfg.node,'trainingWindowPoints') && ~isempty(cfg.node.trainingWindowPoints)
        fprintf(['  train windows   : %d points, non-overlapping; all original samples retained ', ...
            '| validation stays full-length\n'],cfg.node.trainingWindowPoints);
    end
    fprintf('  optimizer       : Adam | epochs<=%d | trajectory/window batch=%d | LR=%.2g\n', ...
        cfg.node.maxEpochs,cfg.node.miniBatchTrajectories,cfg.node.initialLearnRate);
    if isfield(cfg.node,'earlyStopping') && isstruct(cfg.node.earlyStopping) && ...
            isfield(cfg.node.earlyStopping,'minRelativeImprovement')
        fprintf(['  early stopping  : validation every %d epochs | patience=%d checks | ', ...
            'meaningful relative improvement >= %.3g%%\n'], ...
            cfg.node.validationFrequencyEpochs,cfg.node.validationPatienceChecks, ...
            100*cfg.node.earlyStopping.minRelativeImprovement);
    end
end


kopt = get_koopman_options(cfg);
if kopt.enabled
    fprintf('[Modular Koopman baseline]\n');
    fprintf('  method          : M-KBF continuous-generator adaptation of Jiang et al. Eq. (16)\n');
    fprintf('  scope           : same local DER x/V/u terminal interface as NODE/SINDy; exact algebraic network retained\n');
    fprintf('  lift            : %s | real monomials through order %d of normalized local DER state\n', ...
        kopt.liftingMode,kopt.polyOrder);
    fprintf('  identification  : zdot=A*z+sum_i q_i*B_i*z from analytic lift derivatives\n');
    fprintf('  regularization  : joint SVD-rank + Tikhonov ridge selection | ridge alpha=[%s]\n', ...
        strtrim(sprintf('%.1e ',kopt.ridgeRelativeGrid)));
    fprintf('                    alpha=0 always included: %s | full usable rank always included: %s\n', ...
        onoff(kopt.alwaysIncludeZeroRidge),onoff(kopt.alwaysIncludeFullUsableRank));
    fprintf('  reconstruction  : exact fixed degree-one derivative selector, xdot=Cdot*zdot; no learned inverse lift\n');
    fprintf('  rollout         : direct xdot vector field inside the common ODE15I DAE (no discrete KBF step)\n');
    fprintf(['  rank window      : %.1f%% to %.1f%% of fixed regression dimension ', ...
        'M*(1+n_q) | %d nominal candidates | clipped by usable rank + full usable rank candidate\n'], ...
        100*kopt.rankFractionFloor,100*kopt.rankFractionCeiling,kopt.rankCandidateCount);
    fprintf('  model selection : %s | max Re(eig(A))<=%.3g 1/s preferred\n', ...
        kopt.selectionRule,kopt.maxAutonomousRealPart);
    fprintf(['                    one-SE multiplier=%.2g | minimum relative near-best band=%.1f%% | ', ...
        'tie-break=min effective DoF then min amplification\n'], ...
        kopt.oneSEMultiplier,100*kopt.oneSERelativeFloor);
    fprintf(['  validation      : %.1f%% target | split=%s | complete trajectories retained ', ...
        'to estimate validation uncertainty\n'], ...
        100*kopt.validationFraction,kopt.validationSplitMode);
end

sopt = get_sindy_options(cfg);
if sopt.enabled
    fprintf('[SINDy baselines]\n');
    fprintf('  common scope    : same local DER x/V/u scope as NODE; exact algebraic network retained\n');
    fprintf('  generic library : constant + Poly_%d(raw chi) + sin(raw chi) + cos(raw chi)\n', ...
        sopt.polyOrderOption);
    fprintf('  sparse solver   : official Brunton-Proctor-Kutz OLS-STLSQ support discovery (Theta\\dXdt; 10 iterations; rho=0)\n');
    fprintf('                     validation-selected thresholds=[%s]\n', ...
        strtrim(sprintf('%.3g ',sopt.stlsq.thresholdGrid)));
    fprintf('  validation      : %.1f%% complete-trajectory holdout; points flattened after split\n', ...
        100*sopt.validationFraction);
    fprintf('  support refit   : %s | policy=%s\n', ...
        onoff(sopt.stlsq.supportRidge.enabled),sopt.stlsq.supportRidge.applicationPolicy);
    if sopt.stlsq.supportRidge.enabled
        fprintf('                     exact xdot -> fixed rho=%.1e on frozen support | reconstructed xdot -> validation-selected ridge\n', ...
            sopt.stlsq.finalSupportRidgeRho);
        fprintf('                     rho=[%s] | ridge tie band=%.2f%%\n', ...
            strtrim(sprintf('%.3g ',sopt.stlsq.supportRidge.relativeAlphaGrid)), ...
            100*sopt.stlsq.supportRidge.tieRelativeValidationTolerance);
    end
    fprintf('  trajectory check: %s | held-out short-trajectory consistency after pointwise near-best screen\n', ...
        onoff(sopt.stlsq.trajectoryValidation.enabled));
    fprintf('  Vanilla SINDy   : %s | no composed physical features\n',onoff(sopt.vanilla.enabled));
    fprintf('  LLM-Prior SINDy : %s | V-SINDy + compact weak-domain LLM physics bank\n', ...
        onoff(sopt.llmPrior.enabled));
    if sopt.llmPrior.enabled
        fprintf('                     discovery=%s | reasoning=%s | seed=%d | prior hash=%s\n', ...
            sopt.llmPrior.discoveryProtocolVersion,sopt.llmPrior.reasoningEffort, ...
            round(double(sopt.llmPrior.discoverySeed)),char(string(sopt.llmPrior.priorBankHash)));
    end
    fprintf('  Physics SINDy   : %s | full PE physics library: dq/rotating terms + SG AVR |V| + full GFL rhoV interactions\n', ...
        onoff(sopt.physicsEmbedded.enabled));
    fprintf('  Prior-weighted  : %s | same full PE dictionary; physics retention weight=%.3g\n', ...
        onoff(sopt.priorWeighted.enabled),sopt.priorWeighted.physicsFeatureWeight);
    fprintf('                     official STLSQ refit; weighted extension changes only thresholds: generic=lambda, physics=lambda/weight\n');
    fprintf('  PNC-SINDy       : %s | v2 [PE bypass, flat-PN skip, %d fixed %s composition features of (chi,PE output)]\n', ...
        onoff(sopt.physicsNeuralCompositional.enabled),sopt.neuralBasis.featureCount,sopt.neuralBasis.activation);
    fprintf('                     PE bypass=%s | flat-PN skip=%s | compositional seed offset=%d\n', ...
        onoff(sopt.physicsNeuralCompositional.includeLayer1BypassCandidate), ...
        onoff(sopt.physicsNeuralCompositional.includeFlatPNSkipCandidate), ...
        sopt.physicsNeuralCompositional.compositionalSeedOffset);
    fprintf('                     nested depth guard: prefer the better exact parent inside the standard validation near-best band; compose only if both parents are outside\n');
    fprintf('  Flat PN ablation: %s | [1, raw chi, %d fixed %s ridge features] + full PE physics in one flat dictionary\n', ...
        onoff(sopt.physicsNeural.enabled),sopt.neuralBasis.featureCount,sopt.neuralBasis.activation);
    fprintf('  Weak SINDy      : %s | V-SINDy dictionary + compact-support weak integral STLSQ; no pointwise xdot labels\n', ...
        onoff(sopt.weakSindy.enabled));
    if sopt.weakSindy.enabled
        fprintf('                     windows=[%s] points | stride=%d | test phi=(1-s^2)^%d\n', ...
            strtrim(sprintf('%d ',sopt.weakSindy.windowPoints)), ...
            sopt.weakSindy.windowStride,sopt.weakSindy.testFunctionPower);
        fprintf('                     weak thresholds=[%s]\n', ...
            strtrim(sprintf('%.3g ',sopt.weakSindy.thresholdGrid)));
    end
    fprintf('  PW Neural SINDy : %s | legacy flat-PN dictionary; physics weight=%.3g\n', ...
        onoff(sopt.priorWeightedNeural.enabled),sopt.priorWeightedNeural.physicsFeatureWeight);
    fprintf('  Legacy N-SINDy  : %s | backward-compatibility switch only; excluded from manuscript ablation\n', ...
        onoff(sopt.neural.enabled));
    fprintf('  neural generator: quantiles=[%s] | scales=[%s] | pool=%.2gx | corr<=%.4f | seed=%d\n', ...
        strtrim(sprintf('%.2g ',sopt.neuralBasis.quantiles)), ...
        strtrim(sprintf('%.2g ',sopt.neuralBasis.scales)), ...
        sopt.neuralBasis.poolRatio,sopt.neuralBasis.correlationThreshold,sopt.neuralBasis.seed);
end

if isfield(cfg,'edsi') && isstruct(cfg.edsi) && ...
        isfield(cfg.edsi,'enabled') && logical(cfg.edsi.enabled)
    eo = get_edsi_options(cfg);
    fprintf('[ED-SINDy]\n');
    fprintf('  baseline method : ED-SINDy | fixed-width V initialization + evolutionary dictionary search\n');
    fprintf('  P/K/Gmax        : %d / %d / %d | stall patience=%d\n', ...
        eo.populationSize,eo.eliteCount,eo.maxGenerations,eo.stallPatience);
    fprintf('  shared backend  : V-SINDy STLSQ + noisy frozen-support ridge = %s\n', ...
        onoff(eo.shareSindyIdentificationBackend));
    fprintf('  STLSQ rho       : %.3g | search turns=%d | final turns=%d\n', ...
        eo.rho,eo.searchStlsqIterations,eo.finalStlsqIterations);
    fprintf('  threshold grid  : identical to V-SINDy; search lambda selected once from initial V dictionary\n');
    fprintf('  noisy refit     : same V-SINDy validation-selected support ridge on frozen support\n');
    fprintf('  mutation slots  : [%s] | probabilities=[%s]\n', ...
        strtrim(sprintf('%d ',eo.mutationSlotCounts)), ...
        strtrim(sprintf('%.2g ',eo.mutationSlotProbabilities)));
    fprintf('  grammar         : product/sin/cos | max depth=%d | max complexity=%d\n', ...
        eo.maxBasisDepth,eo.maxBasisComplexity);
    fprintf('  search seed     : %d (fixed across data-sampling seeds)\n',eo.evolutionSearchSeed);
    if eo.llm.enabled
        fprintf('[LLM-EDSI]\n');
        fprintf('  role            : one-shot semantic sparse-ODE structural advisor\n');
        fprintf('  intervention    : generation %d only | top-%d elites | max calls=%d\n', ...
            eo.llm.initialGeneration,eo.llm.refinedEliteCount,eo.llm.maxCalls);
        fprintf('  semantic input  : variable glossary + sparse fitted ODE + top active terms\n');
        fprintf('  LLM grammar     : 1,x,prod,add,div,sin,cos | depth<=%d | complexity<=%d\n', ...
            eo.llm.maxExpressionDepth,eo.llm.maxExpressionComplexity);
        fprintf('  compact output  : <=%d proposed terms; full fixed-width dictionary reconstructed locally\n', ...
            eo.llm.maxProposedTerms);
        fprintf('  verification    : reconstructed dictionary -> search STLSQ -> same pointwise validation objective\n');
        fprintf('  later LLM calls : NONE in the frozen formal method\n');
    end
end

if isfield(cfg,'rolloutGuard') && isfield(cfg.rolloutGuard,'enabled')
    fprintf('[Rollout guard]\n');
    fprintf('  enabled         : %s\n',onoff(logical(cfg.rolloutGuard.enabled)));
    if cfg.rolloutGuard.enabled
        fprintf('  max norm error  : %.6g | max abs state: %.6g\n', ...
            cfg.rolloutGuard.maxNormalizedError,cfg.rolloutGuard.maxAbsState);
        fprintf('  scale floor     : relative %.3g | absolute %.3g\n', ...
            cfg.rolloutGuard.scaleFloorRelative,cfg.rolloutGuard.scaleFloorAbsolute);
        fprintf('  failed/incomplete rollouts still report NaN whole-window metrics\n');
    end
end

fprintf('Noise semantics  : common noisy state trajectory for all methods; terminal-voltage/input forcing remains clean\n');
if isfield(cfg,'noise') && isfield(cfg.noise,'derivative')
    fprintf('Derivative step  : %s | window=%d points | polynomial order=%d\n', ...
        cfg.noise.derivative.method,cfg.noise.derivative.windowPoints, ...
        cfg.noise.derivative.polyOrder);
end
fprintf('Weak SINDy rule  : same noisy state trajectories as all methods; no pointwise derivative labels\n');
fprintf('All FINAL test metrics use the complete test-scenario trajectory.\n');
fprintf('---------------------------------------------------------------\n');
end

function tf = parallel_section_enabled_local(cfg,fieldName)
tf = false;
if ~isfield(cfg,'parallel') || ~isstruct(cfg.parallel) || ...
        ~isfield(cfg.parallel,'enabled') || ~logical(cfg.parallel.enabled)
    return;
end
tf = true;
if isfield(cfg.parallel,fieldName)
    tf = logical(cfg.parallel.(fieldName));
end
end

function s = onoff(tf)
if tf, s='ON'; else, s='OFF'; end
end
