function bundlePath = save_offline_experiment_replay_bundle( ...
    report,c,layout,evaluationCache,cfg,outRoot)
%SAVE_OFFLINE_EXPERIMENT_REPLAY_BUNDLE Deprecated compatibility wrapper.
%
% v1p17 intentionally does NOT write an aggregate all-method replay MAT.
% Any older runner that still calls this legacy function is redirected to
% the independent per-method saver.

paths = save_offline_method_replay_bundles( ...
    report,c,layout,evaluationCache,cfg,outRoot);
if isempty(paths)
    bundlePath = '';
elseif numel(paths)==1
    bundlePath = char(paths(1));
else
    % Legacy callers accept one path. Return the method-results directory,
    % not an invented aggregate file.
    folder = 'method_results';
    if isfield(cfg,'output') && isfield(cfg.output,'methodResultsFolder') && ...
            ~isempty(cfg.output.methodResultsFolder)
        folder = char(string(cfg.output.methodResultsFolder));
    end
    bundlePath = fullfile(outRoot,folder);
end
end
