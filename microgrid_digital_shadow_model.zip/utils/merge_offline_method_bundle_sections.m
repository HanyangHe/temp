function mergedBundle = merge_offline_method_bundle_sections(oldBundle,newBundle)
%MERGE_OFFLINE_METHOD_BUNDLE_SECTIONS Non-destructive per-method bundle merge.
%
% New conditions replace old conditions having the same
% (section, SampleCount, NoiseLevel) key. Conditions absent from the new run
% are preserved. This is the core rule required for incremental offline runs:
%
%   existing clean/sample-size results + newly run conditions -> merged bundle
%
% In particular, a later NODE/Weak-PN-only clean sweep must never delete
% previously saved M-KBF/V/PE/PN clean results from their own method bundles.

if nargin < 1 || isempty(oldBundle)
    mergedBundle = newBundle;
    return;
end
if nargin < 2 || isempty(newBundle)
    mergedBundle = oldBundle;
    return;
end

mergedBundle = oldBundle;

% Latest ordinary metadata wins. Report/evaluationCache are merged below.
newFields = fieldnames(newBundle);
for i = 1:numel(newFields)
    f = newFields{i};
    if strcmp(f,'report') || strcmp(f,'evaluationCache')
        continue;
    end
    mergedBundle.(f) = newBundle.(f);
end

if isfield(oldBundle,'report')
    oldReport = oldBundle.report;
else
    oldReport = struct();
end
if isfield(newBundle,'report')
    newReport = newBundle.report;
else
    newReport = struct();
end
mergedBundle.report = merge_reports(oldReport,newReport);

oldCache = struct();
newCache = struct();
if isfield(oldBundle,'evaluationCache'), oldCache = oldBundle.evaluationCache; end
if isfield(newBundle,'evaluationCache'), newCache = newBundle.evaluationCache; end
mergedBundle.evaluationCache = merge_evaluation_caches(oldCache,newCache);

mergedBundle.persistenceSchema = 'independent_method_bundle_non_destructive_v2';
mergedBundle.persistencePolicy = [ ...
    'section-condition merge: new matching conditions replace old; ' ...
    'conditions omitted from the current run are preserved'];
mergedBundle.lastMergedAt = char(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));
end


function out = merge_reports(oldReport,newReport)
out = oldReport;

% Latest non-section metadata wins.
newFields = fieldnames(newReport);
for i = 1:numel(newFields)
    f = newFields{i};
    if any(strcmp(f,{'section1p1','section1p2','section1p3','reuseSummary'}))
        continue;
    end
    out.(f) = newReport.(f);
end

sections = {'section1p1','section1p2','section1p3'};
for i = 1:numel(sections)
    s = sections{i};
    oldSec = struct();
    newSec = struct();
    if isfield(oldReport,s), oldSec = oldReport.(s); end
    if isfield(newReport,s), newSec = newReport.(s); end
    out.(s) = merge_section(oldSec,newSec);
end

% Reuse summary is run-local bookkeeping. Keep the latest copy when present;
% otherwise preserve the previous one.
if isfield(newReport,'reuseSummary') && ~isempty(newReport.reuseSummary)
    out.reuseSummary = newReport.reuseSummary;
elseif isfield(oldReport,'reuseSummary')
    out.reuseSummary = oldReport.reuseSummary;
end
end


function out = merge_section(oldSec,newSec)
if section_is_empty(newSec)
    out = oldSec;
    return;
end
if section_is_empty(oldSec)
    out = newSec;
    return;
end

out = oldSec;

% Latest auxiliary section metadata wins, but table/evaluations are merged.
nf = fieldnames(newSec);
for i = 1:numel(nf)
    f = nf{i};
    if strcmp(f,'table') || strcmp(f,'evaluations')
        continue;
    end
    out.(f) = newSec.(f);
end

oldT = get_field_or(oldSec,'table',table());
newT = get_field_or(newSec,'table',table());
oldE = get_field_or(oldSec,'evaluations',cell(0,1));
newE = get_field_or(newSec,'evaluations',cell(0,1));

if isempty(newT) && isempty(newE)
    return;
end
if isempty(oldT)
    out.table = newT;
    out.evaluations = newE;
    return;
end
if isempty(newT)
    % Evaluation-only sections are rare. Do not destroy a valid old table.
    % Append only evaluations that introduce a new condition.
    [oldT2,newT2] = deal(oldT,table());
    %#ok<NASGU>
    out.evaluations = merge_eval_only(oldE,newE);
    return;
end

[oldT,newT] = align_table_variables(oldT,newT);
oldE = pad_eval_cell(oldE,height(oldT));
newE = pad_eval_cell(newE,height(newT));

keys = strings(height(oldT),1);
for i = 1:height(oldT)
    keys(i) = condition_key(oldT(i,:));
end

for j = 1:height(newT)
    kNew = condition_key(newT(j,:));
    hit = find(keys == kNew,1,'first');
    if isempty(hit)
        oldT = [oldT;newT(j,:)]; %#ok<AGROW>
        oldE{end+1,1} = newE{j}; %#ok<AGROW>
        keys(end+1,1) = kNew; %#ok<AGROW>
    else
        oldT(hit,:) = newT(j,:);
        oldE{hit} = newE{j};
    end
end

% Stable manuscript-friendly ordering.
sortVars = {};
if ismember('SampleCount',oldT.Properties.VariableNames)
    sortVars{end+1} = 'SampleCount'; %#ok<AGROW>
end
if ismember('NoiseLevel',oldT.Properties.VariableNames)
    sortVars{end+1} = 'NoiseLevel'; %#ok<AGROW>
elseif ismember('NoisePercent',oldT.Properties.VariableNames)
    sortVars{end+1} = 'NoisePercent'; %#ok<AGROW>
end
if ~isempty(sortVars)
    [oldT,idx] = sortrows(oldT,sortVars);
    oldE = oldE(idx);
end

out.table = oldT;
out.evaluations = oldE;
end


function tf = section_is_empty(sec)
tf = isempty(sec) || ~isstruct(sec);
if tf, return; end
hasTable = isfield(sec,'table') && istable(sec.table) && height(sec.table)>0;
hasEval = isfield(sec,'evaluations') && ~isempty(sec.evaluations) && ...
    any(~cellfun(@isempty,sec.evaluations));
tf = ~(hasTable || hasEval);
end


function val = get_field_or(s,f,defaultVal)
if isstruct(s) && isfield(s,f) && ~isempty(s.(f))
    val = s.(f);
else
    val = defaultVal;
end
end


function E = pad_eval_cell(E,n)
if isempty(E), E = cell(0,1); end
if ~iscell(E), E = num2cell(E); end
E = E(:);
if numel(E) < n
    E(end+1:n,1) = {[]};
elseif numel(E) > n
    E = E(1:n);
end
end


function E = merge_eval_only(oldE,newE)
oldE = oldE(:);
for i = 1:numel(newE)
    if isempty(newE{i}), continue; end
    k = evaluation_condition_key(newE{i});
    found = false;
    for j = 1:numel(oldE)
        if isempty(oldE{j}), continue; end
        if evaluation_condition_key(oldE{j}) == k
            oldE{j} = newE{i};
            found = true;
            break;
        end
    end
    if ~found
        oldE{end+1,1} = newE{i}; %#ok<AGROW>
    end
end
E = oldE;
end


function key = condition_key(row)
method = row_string(row,'Method',"");
N = row_numeric(row,'SampleCount',NaN);
if ismember('NoiseLevel',row.Properties.VariableNames)
    noise = row_numeric(row,'NoiseLevel',NaN);
else
    noise = row_numeric(row,'NoisePercent',NaN)/100;
end
key = sprintf('%s|N=%.15g|noise=%.17g',char(method),N,noise);
end


function key = evaluation_condition_key(ev)
method = "";
N = NaN;
noise = NaN;
if isstruct(ev) && isfield(ev,'method') && isstruct(ev.method)
    if isfield(ev.method,'name'), method = string(ev.method.name); end
end
if isstruct(ev) && isfield(ev,'trainInfo') && isstruct(ev.trainInfo)
    if isfield(ev.trainInfo,'nSamples'), N = double(ev.trainInfo.nSamples); end
    if isfield(ev.trainInfo,'noiseLevel'), noise = double(ev.trainInfo.noiseLevel); end
end
key = sprintf('%s|N=%.15g|noise=%.17g',char(method),N,noise);
end


function x = row_numeric(row,name,defaultVal)
x = defaultVal;
if ismember(name,row.Properties.VariableNames)
    try
        q = double(row.(name)(1));
        if isscalar(q), x = q; end
    catch
    end
end
end


function s = row_string(row,name,defaultVal)
s = string(defaultVal);
if ismember(name,row.Properties.VariableNames)
    try
        s = string(row.(name)(1));
    catch
    end
end
end


function [A,B] = align_table_variables(A,B)
names = unique([A.Properties.VariableNames B.Properties.VariableNames],'stable');
for i = 1:numel(names)
    name = names{i};
    if ~ismember(name,A.Properties.VariableNames)
        A.(name) = missing_column_like(B.(name),height(A));
    end
    if ~ismember(name,B.Properties.VariableNames)
        B.(name) = missing_column_like(A.(name),height(B));
    end
end
A = A(:,names);
B = B(:,names);
end


function col = missing_column_like(example,n)
if isnumeric(example)
    col = NaN(n,size(example,2));
elseif islogical(example)
    col = false(n,size(example,2));
elseif isstring(example)
    col = strings(n,size(example,2));
    col(:) = missing;
elseif iscell(example)
    col = cell(n,size(example,2));
elseif isdatetime(example)
    col = NaT(n,size(example,2));
elseif isduration(example)
    col = seconds(NaN(n,size(example,2)));
elseif iscategorical(example)
    col = categorical(repmat({''},n,size(example,2)));
else
    % Current offline summary tables use numeric/logical/string columns.
    % Keep a conservative cell fallback for any future auxiliary column.
    col = cell(n,size(example,2));
end
end


function out = merge_evaluation_caches(oldCache,newCache)
if isempty(fieldnames_safe(newCache))
    out = oldCache;
    return;
end
if isempty(fieldnames_safe(oldCache))
    out = newCache;
    return;
end
out = oldCache;

if ~(isfield(oldCache,'entries') && isfield(newCache,'entries'))
    out = newCache;
    return;
end

A = oldCache.entries;
B = newCache.entries;
[A,B] = align_struct_fields(A,B);

if isempty(A)
    out = newCache;
    return;
end
if isempty(B)
    return;
end

for j = 1:numel(B)
    keyB = cache_entry_key(B(j));
    hit = [];
    for i = 1:numel(A)
        if cache_entry_key(A(i)) == keyB
            hit = i;
            break;
        end
    end
    if isempty(hit)
        A(end+1) = B(j); %#ok<AGROW>
    else
        A(hit) = B(j);
    end
end
out = newCache;
out.entries = A;
end


function key = cache_entry_key(e)
if isfield(e,'key') && ~isempty(e.key)
    key = string(e.key);
    return;
end
method = field_string(e,'methodName',"");
N = field_numeric(e,'sampleCount',NaN);
noise = field_numeric(e,'noiseLevel',NaN);
key = sprintf('%s|N=%.15g|noise=%.17g',char(method),N,noise);
end


function [A,B] = align_struct_fields(A,B)
if isempty(A) && isempty(B), return; end
fa = fieldnames_safe_struct_array(A);
fb = fieldnames_safe_struct_array(B);
names = unique([fa;fb],'stable');
for i = 1:numel(names)
    f = names{i};
    if ~isempty(A) && ~isfield(A,f), [A.(f)] = deal([]); end
    if ~isempty(B) && ~isfield(B,f), [B.(f)] = deal([]); end
end
if ~isempty(A), A = orderfields(A,names); end
if ~isempty(B), B = orderfields(B,names); end
end


function f = fieldnames_safe_struct_array(s)
if isstruct(s) && ~isempty(s), f = fieldnames(s); else, f = cell(0,1); end
end


function f = fieldnames_safe(s)
if isstruct(s), f = fieldnames(s); else, f = cell(0,1); end
end


function s = field_string(x,name,defaultVal)
s = string(defaultVal);
if isstruct(x) && isfield(x,name) && ~isempty(x.(name))
    s = string(x.(name));
end
end


function v = field_numeric(x,name,defaultVal)
v = defaultVal;
if isstruct(x) && isfield(x,name) && ~isempty(x.(name))
    try
        q = double(x.(name));
        if isscalar(q), v = q; end
    catch
    end
end
end
