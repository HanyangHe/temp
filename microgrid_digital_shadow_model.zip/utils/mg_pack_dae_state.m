function y = mg_pack_dae_state(x,V,c,layout)
%MG_PACK_DAE_STATE Pack differential states and non-slack bus voltages.

if numel(x) ~= layout.nx
    error('mg_pack_dae_state:StateSize','Unexpected differential-state size.');
end
if numel(V) ~= c.network.N
    error('mg_pack_dae_state:VoltageSize','Unexpected bus-voltage size.');
end
ns = c.network.nonSlackBuses;
y = [x(:); real(V(ns)); imag(V(ns))];
end
