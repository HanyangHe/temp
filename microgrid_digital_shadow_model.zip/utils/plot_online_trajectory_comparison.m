function plot_online_trajectory_comparison(truth,evaluations,c,cfg,outDir)
%PLOT_ONLINE_TRAJECTORY_COMPARISON True system vs online ablation deployments.
%
% Stage-3 uses a two-factor visual encoding for PN-SINDy:
%   coefficient adaptation OFF/ON -> color family
%   state synchronization OFF/ON -> dashed/solid line
% The truth is always shown as a black dotted curve.

styleMap=build_method_style_map(evaluations);

%% Representative bus-voltage magnitudes
buses = cfg.figures.voltageBuses(:).';
buses = buses(buses >= 1 & buses <= c.network.N);
fig = figure('Name','Online voltage comparison','Color','w','Visible',cfg.figures.visible);
tl = tiledlayout(numel(buses),1,'TileSpacing','compact','Padding','compact');
for ib = 1:numel(buses)
    b = buses(ib); ax = nexttile; hold(ax,'on');
    [h,labels]=start_truth(ax,truth.t,abs(truth.V(b,:)));
    [h,labels]=add_predictions(ax,h,labels,evaluations,styleMap, ...
        @(p) valid_field(p,'V') && size(p.V,1)>=b, ...
        @(p) abs(p.V(b,:)));
    ylabel(ax,sprintf('|V_{%d}| (pu)',b)); grid(ax,'on');
    if ib==1, add_top_legend(tl,ax,h,labels); end
end
xlabel(tl,'Time (s)');
export_offline_figure(fig,outDir,'online_voltage_trajectory',cfg);

%% Source frequencies
nRows = numel(c.sg)+numel(c.gfm)+numel(c.gfl);
fig = figure('Name','Online frequency comparison','Color','w','Visible',cfg.figures.visible);
increase_height(fig,nRows);
tl = tiledlayout(nRows,1,'TileSpacing','compact','Padding','loose');
r=0;
for j=1:numel(c.sg)
    r=r+1; ax=nexttile; hold(ax,'on');
    [h,labels]=start_truth(ax,truth.t,truth.sg.fHz(j,:));
    [h,labels]=add_predictions(ax,h,labels,evaluations,styleMap, ...
        @(p) valid_nested(p,'sg','fHz') && size(p.sg.fHz,1)>=j, ...
        @(p) p.sg.fHz(j,:));
    ylabel(ax,sprintf('SG%d f (Hz)',j)); grid(ax,'on');
    if r==1, add_top_legend(tl,ax,h,labels); end
end
for j=1:numel(c.gfm)
    r=r+1; ax=nexttile; hold(ax,'on');
    [h,labels]=start_truth(ax,truth.t,truth.gfm.fHz(j,:));
    [h,labels]=add_predictions(ax,h,labels,evaluations,styleMap, ...
        @(p) valid_nested(p,'gfm','fHz') && size(p.gfm.fHz,1)>=j, ...
        @(p) p.gfm.fHz(j,:));
    ylabel(ax,sprintf('GFM%d f (Hz)',j)); grid(ax,'on');
end
for j=1:numel(c.gfl)
    r=r+1; ax=nexttile; hold(ax,'on');
    [h,labels]=start_truth(ax,truth.t,truth.gfl.fHz(j,:));
    [h,labels]=add_predictions(ax,h,labels,evaluations,styleMap, ...
        @(p) valid_nested(p,'gfl','fHz') && size(p.gfl.fHz,1)>=j, ...
        @(p) p.gfl.fHz(j,:));
    ylabel(ax,sprintf('GFL%d f (Hz)',j)); grid(ax,'on');
end
xlabel(tl,'Time (s)');
export_offline_figure(fig,outDir,'online_frequency_trajectory',cfg);

%% Highest-current truth branches
peakI=max(truth.line.Iabs,[],2);
[~,order]=sort(peakI,'descend');
nShow=min(cfg.figures.nCurrentBranches,numel(order));
order=order(1:nShow);
fig=figure('Name','Online current comparison','Color','w','Visible',cfg.figures.visible);
tl=tiledlayout(nShow,1,'TileSpacing','compact','Padding','compact');
for ii=1:nShow
    ell=order(ii); ax=nexttile; hold(ax,'on');
    [h,labels]=start_truth(ax,truth.t,truth.line.Iabs(ell,:));
    [h,labels]=add_predictions(ax,h,labels,evaluations,styleMap, ...
        @(p) valid_nested(p,'line','Iabs') && size(p.line.Iabs,1)>=ell, ...
        @(p) p.line.Iabs(ell,:));
    ylabel(ax,sprintf('|I_{%d-%d}| (pu)',truth.line.from(ell),truth.line.to(ell)));
    grid(ax,'on');
    if ii==1, add_top_legend(tl,ax,h,labels); end
end
xlabel(tl,'Time (s)');
export_offline_figure(fig,outDir,'online_current_trajectory',cfg);

%% Imposed constant parameter mismatch
if isfield(truth,'parameters') && isfield(truth.parameters,'driftValue') && ...
        ~isempty(truth.parameters.driftValue)
    y = truth.parameters.driftValue(:);
    nominal = nominal_parameter_value(truth);
    fig=figure('Name','Online parameter profile','Color','w','Visible',cfg.figures.visible);
    ax=axes(fig); hold(ax,'on');
    if isreal(y)
        plot(ax,truth.t,real(y),'LineWidth',1.8,'DisplayName','True test parameter');
        if isreal(nominal) && isfinite(nominal)
            yline(ax,real(nominal),'--','LineWidth',1.1,'DisplayName','Offline nominal');
            vals=[real(y(:));real(nominal)];
            lo=min(vals); hi=max(vals); span=max(hi-lo,0.05*max(1,max(abs(vals))));
            ylim(ax,[lo-0.08*span hi+0.08*span]);
        end
        ylabel(ax,parameter_ylabel(truth));
        legend(ax,'Location','best','Interpreter','none');
    else
        plot(ax,truth.t,real(y),'LineWidth',1.8,'DisplayName','Real');
        plot(ax,truth.t,imag(y),'LineWidth',1.8,'DisplayName','Imag');
        legend(ax,'Location','best');
        ylabel(ax,parameter_ylabel(truth));
    end
    xlabel(ax,'Time (s)'); grid(ax,'on');
    if isreal(y) && isreal(nominal) && abs(nominal)>eps
        yyaxis(ax,'right');
        rel = 100*(real(y)/real(nominal)-1);
        plot(ax,truth.t,rel,'--','LineWidth',1.1,'HandleVisibility','off');
        ylabel(ax,'Relative parameter mismatch (%)');
        rlo=min([0;rel(:)]); rhi=max([0;rel(:)]); rspan=max(rhi-rlo,10);
        ylim(ax,[rlo-0.05*rspan rhi+0.05*rspan]);
    end
    export_offline_figure(fig,outDir,'online_parameter_profile',cfg);
end
end

function [h,labels]=add_predictions(ax,h,labels,evaluations,styleMap,isValid,getY) %#ok<INUSD>
for k=1:numel(evaluations)
    ev=evaluations{k};
    p=ev.prediction;
    if ~isValid(p), continue; end
    st=deployment_style(ev);
    h(end+1)=plot(ax,p.t,getY(p),'LineWidth',st.LineWidth, ...
        'LineStyle',st.LineStyle,'Color',st.Color); %#ok<AGROW>
    labels(end+1)=method_label(ev.method.displayName)+"-"+deployment_label(get_mode(ev)); %#ok<AGROW>
end
end

function st=deployment_style(ev)
base=get(groot,'defaultAxesColorOrder');
if isempty(base), base=[0 0.4470 0.7410;0.8500 0.3250 0.0980]; end
cFrozen=base(1,:);
cAdapt=base(min(2,size(base,1)),:);
mode=get_mode(ev);
switch mode
    case {"frozen_no_sync","frozen"}
        c=cFrozen; ls='--'; lw=1.15;
    case "frozen_sync"
        c=cFrozen; ls='-'; lw=1.45;
    case "adapted_no_sync"
        c=cAdapt; ls='--'; lw=1.35;
    case {"adapted_sync","online"}
        c=cAdapt; ls='-'; lw=1.80;
    otherwise
        c=cFrozen; ls=':'; lw=1.2;
end
st=struct('Color',c,'LineStyle',ls,'LineWidth',lw);
end

function label=deployment_label(mode)
mode=lower(string(mode));
switch mode
    case "frozen_no_sync", label="F";
    case "frozen_sync", label="F+S";
    case "adapted_no_sync", label="A";
    case "adapted_sync", label="A+S";
    case "frozen", label="F";
    case "online", label="O";
    otherwise, label=upper(mode);
end
end

function map=build_method_style_map(evaluations)
map=containers.Map('KeyType','char','ValueType','any');
order=get(groot,'defaultAxesColorOrder');
if isempty(order), order=[0 0.4470 0.7410]; end
next=1;
for k=1:numel(evaluations)
    key=char(string(evaluations{k}.method.name));
    if ~isKey(map,key)
        map(key)=struct('color',order(mod(next-1,size(order,1))+1,:));
        next=next+1;
    end
end
end

function mode=get_mode(ev)
mode="frozen";
if isfield(ev,'mode') && strlength(string(ev.mode))>0
    mode=lower(string(ev.mode));
end
end

function nominal=nominal_parameter_value(truth)
nominal=NaN;
if ~isfield(truth,'metadata') || ~isfield(truth.metadata,'caseData') || ...
        ~isfield(truth.metadata.caseData,'drift')
    return;
end
D=truth.metadata.caseData.drift;
c0=truth.metadata.caseData;
c0.drift.enabled=false;
p0=mg_parameter_profile(truth.t(1),c0);
type=lower(char(D.deviceType));
field=char(D.parameter);
if isfield(truth,'parameters') && isfield(truth.parameters,'driftDevice') && ~isempty(truth.parameters.driftDevice)
    dev=double(truth.parameters.driftDevice);
else
    dev=double(D.device(1));
end
if isfield(p0,type) && dev>=1 && dev<=numel(p0.(type)) && ...
        isfield(p0.(type)(dev),field)
    nominal=p0.(type)(dev).(field);
end
end

function s=parameter_ylabel(truth)
par=string(truth.parameters.driftParameter);
type=upper(string(truth.parameters.driftDeviceType));
dev=string(truth.parameters.driftDevice);
s=char(type+dev+" "+par);
end

function [h,labels]=start_truth(ax,t,y)
h=gobjects(0); labels=strings(0);
h(end+1)=plot(ax,t,y,'k:','LineWidth',2.2); labels(end+1)="True system";
end
function tf=valid_field(p,f)
tf=isstruct(p)&&isfield(p,'t')&&~isempty(p.t)&&isfield(p,f)&&~isempty(p.(f));
end
function tf=valid_nested(p,a,b)
tf=isstruct(p)&&isfield(p,'t')&&~isempty(p.t)&&isfield(p,a)&&isstruct(p.(a))&&isfield(p.(a),b)&&~isempty(p.(a).(b));
end
function increase_height(fig,nRows)
if nRows<=3, return; end
try
    fig.Units='pixels'; pos=fig.Position; pos(4)=max(pos(4),round(105*nRows+90)); fig.Position=pos;
catch
end
end
function add_top_legend(tl,ax,h,labels)
lgd=legend(ax,h,cellstr(labels),'Orientation','horizontal','Interpreter','none','Box','on');
try, lgd.Layout.Tile='north'; catch, lgd.Location='northoutside'; end
end
function label=method_label(name)
switch lower(strtrim(string(name)))
    case lower("M-KBF"), label="M-KBF";
    case lower("Vanilla SINDy"), label="V-SINDy";
    case lower("Physics-embedded SINDy"), label="PE-SINDy";
    case lower("Neural SINDy"), label="N-SINDy";
    case lower("Physics-Neural SINDy"), label="PN-SINDy";
    case lower("Neural ODE"), label="NODE";
    otherwise, label=string(name);
end
end
