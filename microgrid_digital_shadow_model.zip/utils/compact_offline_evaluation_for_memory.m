function out = compact_offline_evaluation_for_memory(evaluation,cfg)
%COMPACT_OFFLINE_EVALUATION_FOR_MEMORY Drop large NODE-only runtime payloads.
%
% The complete evaluation is checkpointed to disk before this helper is used.
% This compact copy is only for the long in-memory sweep/report structures.
% It deliberately retains everything needed for summary tables and NODE
% diagnostics, while releasing the trained model and dense trajectory arrays.
%
% Non-NODE evaluations are returned unchanged. Older configs that do not opt
% into cfg.node.compactInMemoryEvaluations are also left unchanged.

out = evaluation;
if nargin < 2 || ~isstruct(cfg) || ~isfield(cfg,'node') || ...
        ~isstruct(cfg.node) || ~isfield(cfg.node,'compactInMemoryEvaluations') || ...
        ~logical(cfg.node.compactInMemoryEvaluations)
    return;
end
if ~isstruct(out) || ~isfield(out,'method') || ~isstruct(out.method) || ...
        ~isfield(out.method,'name') || ...
        ~strcmpi(char(string(out.method.name)),'neural_ode_modular')
    return;
end

% The persistent checkpoint/bundle retains the full numeric model. The RAM
% copy does not need it once rollout, metrics, diagnostics, and checkpointing
% have completed.
if isfield(out,'model')
    out.model = [];
end

% Report rows only need prediction.metadata. Full y/x/V/branch trajectories
% are persisted in the checkpoint and do not need to accumulate in secEvals.
if isfield(out,'prediction') && isstruct(out.prediction)
    if isfield(out.prediction,'metadata')
        md = out.prediction.metadata;
    else
        md = struct();
    end
    out.prediction = struct('metadata',md);
end

% NODE diagnostics can contain a dense truth-forced state trajectory. Retain
% its metrics/tables/status but release the raw trajectory arrays in RAM.
if isfield(out,'diagnostics') && isstruct(out.diagnostics) && ...
        isfield(out.diagnostics,'node') && isstruct(out.diagnostics.node)
    D = out.diagnostics.node;
    if isfield(D,'teacherForced') && isstruct(D.teacherForced)
        q = D.teacherForced;
        if isfield(q,'t'), q.t = []; end
        if isfield(q,'x'), q.x = []; end
        D.teacherForced = q;
    end
    out.diagnostics.node = D;
end

% Function handles are unnecessary in the compact report copy and can keep
% code/workspace references alive longer than needed.
if isfield(out,'method') && isstruct(out.method)
    removable = {'trainFcn','predictFcn'};
    for k = 1:numel(removable)
        if isfield(out.method,removable{k})
            out.method = rmfield(out.method,removable{k});
        end
    end
end

out.memoryCompacted = true;
out.memoryCompactionPolicy = ...
    'NODE full model/trajectory payload persisted on disk; compact RAM report copy';
end
