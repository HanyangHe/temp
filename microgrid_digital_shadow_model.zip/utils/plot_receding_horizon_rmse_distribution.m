function info = plot_receding_horizon_rmse_distribution(T,cfg,outDir)
%PLOT_RECEDING_HORIZON_RMSE_DISTRIBUTION Box + violin distribution summary.
%
% Left: conventional box chart with logarithmic RMSE axis.
% Right: dependency-free Gaussian-KDE violin on log10(RMSE), with median bars.

if exist(outDir,'dir') ~= 7, mkdir(outDir); end
methods = string(cfg.receding.methods(:));
displayNames = strings(size(methods));
for i=1:numel(methods)
    q0=T(string(T.Method)==methods(i),:);
    displayNames(i)=display_name_local(q0,methods(i));
end

fig = figure('Visible',cfg.figures.visible,'Color','w', ...
    'Position',[100 100 1100 430]);
tl = tiledlayout(fig,1,2,'TileSpacing','compact','Padding','compact'); %#ok<NASGU>

%% Box plot
ax1 = nexttile; hold(ax1,'on'); box(ax1,'on'); grid(ax1,'on');
allX = categorical(); allY = [];
for i=1:numel(methods)
    q=T(string(T.Method)==methods(i) & T.RolloutSucceeded & isfinite(T.RMSE),:);
    allX=[allX; categorical(repmat(displayNames(i),height(q),1),cellstr(displayNames))]; %#ok<AGROW>
    allY=[allY; q.RMSE]; %#ok<AGROW>
end
if ~isempty(allY)
    boxchart(ax1,allX,allY,'MarkerStyle','.');
    set(ax1,'YScale','log');
end
ylabel(ax1,'12-s trajectory RMSE');
xlabel(ax1,'Method');
xtickangle(ax1,22);
set(ax1,'FontName','Times New Roman','FontSize',9.5,'LineWidth',0.8);

%% Violin plot on log10 scale
ax2 = nexttile; hold(ax2,'on'); box(ax2,'on'); grid(ax2,'on');
for i=1:numel(methods)
    q=T(string(T.Method)==methods(i) & T.RolloutSucceeded & isfinite(T.RMSE) & T.RMSE>0,:);
    x=log10(double(q.RMSE));
    [color,~,~]=style_local(methods(i));
    if isempty(x), continue; end
    [gridY,dens]=kde_gaussian_local(x);
    if max(dens)>0, dens=0.36*dens/max(dens); else, dens=zeros(size(dens)); end
    patch(ax2,[i-dens(:); flipud(i+dens(:))], ...
        [gridY(:); flipud(gridY(:))],color, ...
        'FaceAlpha',0.22,'EdgeColor',color,'LineWidth',1.0, ...
        'HandleVisibility','off');
    plot(ax2,[i-0.22 i+0.22],[median(x) median(x)],'-', ...
        'Color',color,'LineWidth',2.0,'HandleVisibility','off');
    plot(ax2,repmat(i,size(x)),x,'.','Color',color,'MarkerSize',5, ...
        'HandleVisibility','off');
end
xlim(ax2,[0.4 numel(methods)+0.6]);
set(ax2,'XTick',1:numel(methods),'XTickLabel',cellstr(displayNames));
xtickangle(ax2,22);
ylabel(ax2,'log_{10}(12-s trajectory RMSE)');
xlabel(ax2,'Method');
set(ax2,'FontName','Times New Roman','FontSize',9.5,'LineWidth',0.8);

base = fullfile(outDir,'receding_horizon_rmse_distribution');
info = export_local(fig,base,cfg);
close(fig);
end

function [gridY,dens] = kde_gaussian_local(x)
x=double(x(:)); n=numel(x);
if n==1
    span=max(0.05,0.05*max(1,abs(x)));
    gridY=linspace(x-span,x+span,160).';
    h=span/3;
else
    sx=std(x,0);
    spread=max(x)-min(x);
    if ~isfinite(sx) || sx<=eps
        sx=max(0.05,spread/4);
    end
    h=1.06*sx*n^(-1/5);
    h=max(h,max(0.02,0.03*max(spread,1e-3)));
    pad=max(3*h,0.08*max(spread,0.1));
    gridY=linspace(min(x)-pad,max(x)+pad,180).';
end
Z=(gridY-x.')./h;
dens=mean(exp(-0.5*Z.^2),2)/(sqrt(2*pi)*h);
end

function s = display_name_local(~,fallback)
% Use manuscript aliases independent of the registry DisplayName.
switch lower(char(fallback))
    case 'modular_koopman_kbf', s="M-KBF";
    case 'vanilla_sindy', s="V-SINDy";
    case 'physics_embedded_sindy', s="PE-SINDy";
    case 'edsi', s="ED-SINDy";
    case 'neural_ode_modular', s="NODE";
    case 'llm_prior_sindy', s="LLM-Prior SINDy";
    otherwise, s=string(fallback);
end
end

function [c,ls,lw] = style_local(name)
switch lower(char(name))
    case 'modular_koopman_kbf', c=[0.10 0.10 0.10]; ls='-.'; lw=1.35;
    case 'vanilla_sindy', c=[0.00 0.4470 0.7410]; ls='--'; lw=1.55;
    case 'physics_embedded_sindy', c=[0.4660 0.6740 0.1880]; ls=':'; lw=1.45;
    case 'edsi', c=[0.4940 0.1840 0.5560]; ls='-.'; lw=1.45;
    case 'neural_ode_modular', c=[0.9290 0.6940 0.1250]; ls='--'; lw=1.45;
    case 'llm_prior_sindy', c=[0.8500 0.0500 0.0500]; ls='-'; lw=2.20;
    otherwise, c=[0.3 0.3 0.3]; ls='-'; lw=1.3;
end
end

function info = export_local(fig,base,cfg)
info = struct('png','','pdf','','fig','');
info.fig=[base '.fig']; savefig(fig,info.fig);
if ~isfield(cfg.figures,'exportPNG') || cfg.figures.exportPNG
    info.png=[base '.png']; exportgraphics(fig,info.png,'Resolution',220);
end
if ~isfield(cfg.figures,'exportPDF') || cfg.figures.exportPDF
    info.pdf=[base '.pdf']; exportgraphics(fig,info.pdf,'ContentType','vector');
end
end
