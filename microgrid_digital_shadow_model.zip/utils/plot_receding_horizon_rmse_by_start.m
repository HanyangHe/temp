function info = plot_receding_horizon_rmse_by_start(T,cfg,outDir)
%PLOT_RECEDING_HORIZON_RMSE_BY_START Sliding-window RMSE versus anchor time.

if exist(outDir,'dir') ~= 7, mkdir(outDir); end
methods = string(cfg.receding.methods(:));

fig = figure('Visible',cfg.figures.visible,'Color','w', ...
    'Position',[100 100 900 430]);
ax = axes(fig); hold(ax,'on'); box(ax,'on'); grid(ax,'on');

for i = 1:numel(methods)
    q = T(string(T.Method)==methods(i),:);
    [~,ix] = sort(q.StartTime_s); q=q(ix,:);
    [color,ls,lw] = style_local(methods(i));
    y = q.RMSE;
    y(~q.RolloutSucceeded) = NaN;
    semilogy(ax,q.StartTime_s,y,'LineStyle',ls,'Color',color, ...
        'LineWidth',lw,'DisplayName',char(display_name_local(q,methods(i))));
end

xlabel(ax,'Prediction start time, t_k (s)');
ylabel(ax,'12-s trajectory RMSE');
xlim(ax,[min(T.StartTime_s) max(T.StartTime_s)]);
legend(ax,'Location','best','Box','off');
set(ax,'FontName','Times New Roman','FontSize',10,'LineWidth',0.8);

base = fullfile(outDir,'receding_horizon_rmse_vs_start');
info = export_local(fig,base,cfg);
close(fig);
end

function s = display_name_local(q,fallback)
if ~isempty(q) && ismember('DisplayName',q.Properties.VariableNames)
    s=string(q.DisplayName(1));
else
    s=fallback;
end
end

function [c,ls,lw] = style_local(name)
switch lower(char(name))
    case 'modular_koopman_kbf', c=[0.10 0.10 0.10]; ls='-.'; lw=1.35;
    case 'vanilla_sindy', c=[0.00 0.4470 0.7410]; ls='--'; lw=1.55;
    case 'physics_embedded_sindy', c=[0.4660 0.6740 0.1880]; ls=':'; lw=1.45;
    case 'edsi', c=[0.4940 0.1840 0.5560]; ls='-.'; lw=1.45;
    case 'neural_ode_modular', c=[0.9290 0.6940 0.1250]; ls='--'; lw=1.45;
    case 'llm_prior_sindy', c=[0.8500 0.0500 0.0500]; ls='-'; lw=2.20;
    otherwise, c=[0.3 0.3 0.3]; ls='-'; lw=1.3;
end
end

function info = export_local(fig,base,cfg)
info = struct('png','','pdf','','fig','');
info.fig=[base '.fig']; savefig(fig,info.fig);
if ~isfield(cfg.figures,'exportPNG') || cfg.figures.exportPNG
    info.png=[base '.png']; exportgraphics(fig,info.png,'Resolution',220);
end
if ~isfield(cfg.figures,'exportPDF') || cfg.figures.exportPDF
    info.pdf=[base '.pdf']; exportgraphics(fig,info.pdf,'ContentType','vector');
end
end
