function plot_offline_sample_sensitivity_multiseed(S,cfg,outDir)
%PLOT_OFFLINE_SAMPLE_SENSITIVITY_MULTISEED Mean +/- std across sampling seeds.
% All three y-axes use logarithmic scaling so methods spanning orders of
% magnitude remain visible. Error statistics use successful rollouts only.
% A colored x near the top of an error panel indicates that one or more
% seeds failed at that condition.

% Guard against plots silently treating a partial 1/1 as a full 3/3.
if isfield(cfg,'multiseed') && isstruct(cfg.multiseed) && ...
        isfield(cfg.multiseed,'strictPlotSeedCoverage') && ...
        logical(cfg.multiseed.strictPlotSeedCoverage)
    expected=numel(cfg.randomSeeds);
    if ~ismember('PresentSeedCount',S.Properties.VariableNames) || ...
            any(double(S.PresentSeedCount)~=expected)
        error('plot_offline_sample_sensitivity_multiseed:IncompleteCohort', ...
            'Refusing to plot incomplete seed coverage (expected %d).',expected);
    end
end
methodNames = unique(S.DisplayName,'stable');
legendNames = arrayfun(@method_legend_abbrev,methodNames,'UniformOutput',false);
fig = figure('Name','', ...
    'Color','w','Visible',cfg.figures.visible);
tl = tiledlayout(1,3,'TileSpacing','compact','Padding','loose');
% IEEE caption supplies the figure title; no internal or shared title.
title(tl,'');
meanFields = {'RMSEMean','MaxAEMean','TrainingTimeMean'};
stdFields = {'RMSEStd','MaxAEStd','TrainingTimeStd'};
ylabels = {'RMSE','Maximum absolute error','Training time (s)'};
for im=1:3
    ax=nexttile; hold(ax,'on');
    title(ax,'');
    failX=cell(numel(methodNames),1); lineColor=cell(numel(methodNames),1);
    for k=1:numel(methodNames)
        idx=S.DisplayName==methodNames(k);
        [x,ord]=sort(S.SampleCount(idx));
        mu=S.(meanFields{im})(idx); mu=mu(ord);
        sd=S.(stdFields{im})(idx); sd=sd(ord);
        successCount=S.SuccessCount(idx); successCount=successCount(ord);
        seedCount=S.SeedCount(idx); seedCount=seedCount(ord);
        if im<=2
            ok=isfinite(x)&isfinite(mu)&isfinite(sd)&mu>0&successCount>0;
        else
            ok=isfinite(x)&isfinite(mu)&isfinite(sd)&mu>0;
        end
        color=method_color_local(methodNames(k));
        if any(ok)
            h=positive_errorbar_local(ax,x(ok),mu(ok),sd(ok),legendNames{k},color);
        else
            h=plot(ax,nan,nan,'-o','LineWidth',1.35,'Color',color, ...
                'DisplayName',legendNames{k});
        end
        lineColor{k}=color;
        if im<=2
            failX{k}=x(successCount<seedCount);
        end
    end
    if isfield(cfg,'sampleCounts') && ~isempty(cfg.sampleCounts)
        xticks(ax,cfg.sampleCounts(:).');
    end
    ax.XTickLabelRotation=45;
    set(ax,'FontName','Times New Roman');
    ylabel(ax,ylabels{im},'FontName','Times New Roman'); grid(ax,'on');
    set(ax,'YScale','log');
    expand_log_limits_local(ax);
    if im<=2
        mark_failures_log_local(ax,failX,lineColor);
    end
    if im==1
        plot(ax,nan,nan,'x','LineWidth',1.5,'MarkerSize',8, ...
            'Color',[0.15 0.15 0.15],'DisplayName','one or more failed seeds');
        lgd=legend(ax,'Orientation','horizontal', ...
            'NumColumns',preferred_legend_columns(numel(methodNames)+1));
        lgd.Layout.Tile='north'; lgd.Interpreter='none'; lgd.Box='on';
        lgd.FontSize=max(7,lgd.FontSize-1);
        lgd.FontName='Times New Roman';
    end
end
% The previous shared bottom label `Samples` is intentionally omitted.
% The IEEE caption describes the horizontal sample-count axis.
apply_font_to_all_graphics_local(fig);
export_offline_figure(fig,outDir,'section1p2_sample_sensitivity_multiseed',cfg);
end

function h=positive_errorbar_local(ax,x,mu,sd,label,color)
% Keep the numerical mean/std unchanged in tables. Only the graphical lower
% whisker is clipped when mean-std would be nonpositive, because a logarithmic
% axis cannot display zero or negative values.
mu=double(mu(:)); sd=double(sd(:)); x=double(x(:));
lower=sd;
cap=0.95*mu;
lower=min(lower,cap);
lower(~isfinite(lower)|lower<0)=0;
upper=sd;
upper(~isfinite(upper)|upper<0)=0;
h=errorbar(ax,x,mu,lower,upper,'-o','LineWidth',1.35, ...
    'Color',color,'CapSize',5,'DisplayName',label);
end

function mark_failures_log_local(ax,failX,lineColor)
failed=find(~cellfun(@isempty,failX));
if isempty(failed), return; end
expand_log_limits_local(ax);
yl=ylim(ax);
if any(~isfinite(yl)) || any(yl<=0) || yl(2)<=yl(1)
    yl=[1e-12 1];
end
lo=log10(yl(1)); hi=log10(yl(2));
span=max(hi-lo,1);
extra=max(0.16*span,0.055*span*numel(failed));
newHi=hi+extra;
ylim(ax,[10^lo 10^newHi]);
if numel(failed)>1
    yExp=linspace(newHi-0.12*extra,hi+0.12*extra,numel(failed));
else
    yExp=newHi-0.30*extra;
end
for j=1:numel(failed)
    k=failed(j);
    plot(ax,failX{k},repmat(10^yExp(j),size(failX{k})),'x', ...
        'LineWidth',1.5,'MarkerSize',8,'Color',lineColor{k}, ...
        'HandleVisibility','off');
end
end

function expand_log_limits_local(ax)
yl=ylim(ax);
if any(~isfinite(yl)) || any(yl<=0) || yl(2)<=yl(1), return; end
lo=log10(yl(1)); hi=log10(yl(2));
if hi-lo<1
    mid=0.5*(hi+lo);
    lo=mid-0.55; hi=mid+0.55;
    ylim(ax,[10^lo 10^hi]);
end
end

function ncol=preferred_legend_columns(nItems)
if nItems<=4, ncol=nItems; elseif nItems<=8, ncol=ceil(nItems/2); else, ncol=4; end
end

function label=method_legend_abbrev(name)
switch lower(strtrim(string(name)))
    case lower("M-KBF"), label="M-KBF";
    case lower("Vanilla SINDy"), label="V-SINDy";
    case lower("ED-SINDy"), label="ED-SINDy";
    case lower("LLM-Prior SINDy"), label="LLM-Prior SINDy";
    case lower("Physics-embedded SINDy"), label="PE-SINDy";
    case lower("Prior-weighted SINDy"), label="PW-SINDy";
    case lower("PNC-SINDy"), label="PNC-SINDy";
    case lower("PNC-ResidualComp"), label="PNC-ResComp";
    case lower("PNC-v3-Residualized"), label="PNC-v3";
    case lower("Physics-Neural SINDy"), label="PN-SINDy";
    case lower("Weak SINDy"), label="Weak SINDy";
    case lower("Poly-3 SINDy"), label="Poly-3 SINDy";
    case lower("EDSI"), label="ED-SINDy";
    case lower("LLM-EDSI"), label="LLM-EDSI";
    case {lower("Neural ODE"), lower("NODE")}, label="NODE";
    case lower("Prior-weighted Neural SINDy"), label="PWN-SINDy";
    otherwise, label=string(name);
end
end

function color = method_color_local(name)
% Deterministic manuscript colors for the retained methods.
% Explicitly include the 69-bus final5 set so replayed multiseed figures do
% not collapse new methods onto the gray fallback color.
switch lower(strtrim(string(name)))
    case {lower("Vanilla SINDy"), lower("V-SINDy")}, color = [0.0000 0.4470 0.7410];
    case lower("Poly-3 SINDy"), color = [0.8500 0.3250 0.0980];
    case {lower("EDSI"), lower("ED-SINDy")}, color = [0.4940 0.1840 0.5560];
    case lower("LLM-EDSI"), color = [0.4660 0.6740 0.1880];
    case lower("LLM-Prior SINDy"), color = [0.4660 0.6740 0.1880];
    case {lower("Physics-embedded SINDy"), lower("PE-SINDy")}, color = [0.8500 0.3250 0.0980];
    case lower("Physics-Neural SINDy"), color = [0.9290 0.6940 0.1250];
    case lower("PNC-SINDy"), color = [0.4940 0.1840 0.5560];
    case lower("Weak SINDy"), color = [0.3010 0.7450 0.9330];
    case lower("M-KBF"), color = [0.6350 0.0780 0.1840];
    case {lower("Neural ODE"), lower("NODE")}, color = [0.2500 0.2500 0.2500];
    otherwise, color = [0.2000 0.2000 0.2000];
end
end

function apply_font_to_all_graphics_local(fig)
% Includes tick labels, axis labels, legend, and text objects.
objs=findall(fig);
for j=1:numel(objs)
    try
        if isprop(objs(j),'FontName')
            objs(j).FontName='Times New Roman';
        end
    catch
    end
end
end
