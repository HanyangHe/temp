function out = sanitize_offline_evaluation_for_save(evaluation)
%SANITIZE_OFFLINE_EVALUATION_FOR_SAVE Remove executable/report-only content.
%
% Function handles are removed for portable replay bundles. NRMSE fields and
% table columns are also stripped from the persisted report-facing copy. The
% live in-memory evaluation may still compute NRMSE internally; it is simply
% not retained in saved report artifacts.

out = evaluation;
if isfield(out,'method') && isstruct(out.method)
    removable = {'trainFcn','predictFcn'};
    for k = 1:numel(removable)
        if isfield(out.method,removable{k})
            out.method = rmfield(out.method,removable{k});
        end
    end
end
out = strip_nrmse_report_data(out);
end
