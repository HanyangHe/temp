function plot_offline_trajectory_comparison(truth,evaluations,c,cfg,outDir)
%PLOT_OFFLINE_TRAJECTORY_COMPARISON Engineering-variable trajectory figures.
%
% Compact manuscript/replay layout:
%   - preserve normal figure width
%   - enlarge only the frequency-figure HEIGHT when many DER rows exist
%   - one centered top legend
%   - abbreviated method names
%   - truth reference is bold black dotted
%   - GFL frequency y-label uses "GFL# f (Hz)" (PLL text omitted)

%% Representative bus-voltage magnitudes
buses = cfg.figures.voltageBuses(:).';
buses = buses(buses >= 1 & buses <= c.network.N);
fig = figure('Name','Offline 1.1 voltage comparison','Color','w','Visible',cfg.figures.visible);
tl = tiledlayout(numel(buses),1,'TileSpacing','compact','Padding','compact');
for ib = 1:numel(buses)
    b = buses(ib);
    ax = nexttile; hold(ax,'on');
    h = gobjects(0); labels = strings(0);
    h(end+1) = plot_truth(ax,truth.t,abs(truth.V(b,:))); %#ok<AGROW>
    labels(end+1) = "Truth"; %#ok<AGROW>
    for k = 1:numel(evaluations)
        p = evaluations{k}.prediction;
        if has_processed_prediction(p,'V')
            h(end+1) = plot(ax,p.t,abs(p.V(b,:)),'LineWidth',1.15); %#ok<AGROW>
            labels(end+1) = method_legend_abbrev(evaluations{k}.method.displayName); %#ok<AGROW>
        end
    end
    ylabel(ax,sprintf('|V_{%d}| (pu)',b)); grid(ax,'on');
    if ib == 1, add_top_legend(tl,ax,h,labels); end
end
xlabel(tl,'Time (s)');
apply_times_new_roman_all_local(fig);
export_offline_figure(fig,outDir,'section1p1_voltage_trajectory',cfg);

%% Source frequencies
nRows = numel(c.sg)+numel(c.gfm)+numel(c.gfl);
fig = figure('Name','Offline 1.1 frequency comparison','Color','w','Visible',cfg.figures.visible);
% Do not widen the figure. Only add vertical room when 69/123-bus cases
% contain many DER frequency rows.
increase_figure_height_for_rows(fig,nRows);
tl = tiledlayout(nRows,1,'TileSpacing','compact','Padding','loose');
r = 0;
for j = 1:numel(c.sg)
    r=r+1; ax = nexttile; hold(ax,'on');
    [h,labels] = start_truth_curve(ax,truth.t,truth.sg.fHz(j,:));
    for k=1:numel(evaluations)
        p=evaluations{k}.prediction;
        if has_nested_prediction(p,'sg','fHz') && size(p.sg.fHz,1) >= j
            h(end+1)=plot(ax,p.t,p.sg.fHz(j,:),'LineWidth',1.15); %#ok<AGROW>
            labels(end+1)=method_legend_abbrev(evaluations{k}.method.displayName); %#ok<AGROW>
        end
    end
    ylabel(ax,sprintf('SG%d f (Hz)',j)); grid(ax,'on');
    if r==1, add_top_legend(tl,ax,h,labels); end
end
for j = 1:numel(c.gfm)
    r=r+1; ax = nexttile; hold(ax,'on');
    [h,labels] = start_truth_curve(ax,truth.t,truth.gfm.fHz(j,:));
    for k=1:numel(evaluations)
        p=evaluations{k}.prediction;
        if has_nested_prediction(p,'gfm','fHz') && size(p.gfm.fHz,1) >= j
            h(end+1)=plot(ax,p.t,p.gfm.fHz(j,:),'LineWidth',1.15); %#ok<AGROW>
            labels(end+1)=method_legend_abbrev(evaluations{k}.method.displayName); %#ok<AGROW>
        end
    end
    ylabel(ax,sprintf('GFM%d f (Hz)',j)); grid(ax,'on');
end
for j = 1:numel(c.gfl)
    r=r+1; ax = nexttile; hold(ax,'on');
    [h,labels] = start_truth_curve(ax,truth.t,truth.gfl.fHz(j,:));
    for k=1:numel(evaluations)
        p=evaluations{k}.prediction;
        if has_nested_prediction(p,'gfl','fHz') && size(p.gfl.fHz,1) >= j
            h(end+1)=plot(ax,p.t,p.gfl.fHz(j,:),'LineWidth',1.15); %#ok<AGROW>
            labels(end+1)=method_legend_abbrev(evaluations{k}.method.displayName); %#ok<AGROW>
        end
    end
    ylabel(ax,sprintf('GFL%d f (Hz)',j)); grid(ax,'on');
end
xlabel(tl,'Time (s)');
apply_times_new_roman_all_local(fig);
export_offline_figure(fig,outDir,'section1p1_frequency_trajectory',cfg);

%% Branch-current magnitudes: choose highest-peak truth branches
peakI = max(truth.line.Iabs,[],2);
[~,order] = sort(peakI,'descend');
nShow = min(cfg.figures.nCurrentBranches,numel(order));
order = order(1:nShow);
fig = figure('Name','Offline 1.1 current comparison','Color','w','Visible',cfg.figures.visible);
tl = tiledlayout(nShow,1,'TileSpacing','compact','Padding','compact');
for ii = 1:nShow
    ell = order(ii);
    ax = nexttile; hold(ax,'on');
    [h,labels] = start_truth_curve(ax,truth.t,truth.line.Iabs(ell,:));
    for k=1:numel(evaluations)
        p=evaluations{k}.prediction;
        if has_nested_prediction(p,'line','Iabs') && size(p.line.Iabs,1) >= ell
            h(end+1)=plot(ax,p.t,p.line.Iabs(ell,:),'LineWidth',1.15); %#ok<AGROW>
            labels(end+1)=method_legend_abbrev(evaluations{k}.method.displayName); %#ok<AGROW>
        end
    end
    ylabel(ax,sprintf('|I_{%d-%d}| (pu)',truth.line.from(ell),truth.line.to(ell)));
    grid(ax,'on');
    if ii==1, add_top_legend(tl,ax,h,labels); end
end
xlabel(tl,'Time (s)');
apply_times_new_roman_all_local(fig);
export_offline_figure(fig,outDir,'section1p1_current_trajectory',cfg);
end

function increase_figure_height_for_rows(fig,nRows)
if nRows <= 3
    return;
end
try
    fig.Units = 'pixels';
    pos = fig.Position;
    % Preserve pos(3) exactly: no horizontal resizing.
    targetHeight = max(pos(4), round(105*nRows + 90));
    pos(4) = targetHeight;
    fig.Position = pos;
catch
end
end

function h = plot_truth(ax,t,y)
h = plot(ax,t,y,'LineWidth',2.2,'LineStyle',':','Color','k');
end

function [h,labels] = start_truth_curve(ax,t,y)
h = gobjects(0); labels = strings(0);
h(end+1)=plot_truth(ax,t,y);
labels(end+1)="Truth";
end

function add_top_legend(tl,ax,h,labels)
lgd = legend(ax,h,cellstr(labels), ...
    'Orientation','horizontal', ...
    'NumColumns',preferred_legend_columns(numel(labels)), ...
    'Interpreter','none','Box','on');
try
    lgd.Layout.Tile = 'north';
catch
    lgd.Location = 'northoutside';
end
lgd.FontSize = max(7,lgd.FontSize-1);
lgd.FontName = 'Times New Roman';
end

function ncol = preferred_legend_columns(nItems)
if nItems <= 4
    ncol = nItems;
elseif nItems <= 8
    ncol = ceil(nItems/2);
else
    ncol = 4;
end
end

function tf = has_processed_prediction(p,fieldName)
tf = isstruct(p) && isfield(p,'t') && ~isempty(p.t) && ...
    isfield(p,fieldName) && ~isempty(p.(fieldName));
end

function tf = has_nested_prediction(p,parent,child)
tf = isstruct(p) && isfield(p,'t') && ~isempty(p.t) && ...
    isfield(p,parent) && isstruct(p.(parent)) && ...
    isfield(p.(parent),child) && ~isempty(p.(parent).(child));
end

function label = method_legend_abbrev(name)
name = string(name);
switch lower(strtrim(name))
    case lower("M-KBF")
        label = "M-KBF";
    case lower("Vanilla SINDy")
        label = "V-SINDy";
    case lower("ED-SINDy")
        label = "ED-SINDy";
    case lower("LLM-Prior SINDy")
        label = "LLM-Prior SINDy";
    case lower("Physics-embedded SINDy")
        label = "PE-SINDy";
    case lower("Prior-weighted SINDy")
        label = "PW-SINDy";
    case lower("PNC-SINDy"), label="PNC-SINDy";
    case lower("Physics-Neural SINDy")
        label = "PN-SINDy";
    case lower("Weak SINDy")
        label = "Weak SINDy";
    case lower("Prior-weighted Neural SINDy")
        label = "PWN-SINDy";
    otherwise
        label = name;
end
end

function apply_times_new_roman_all_local(fig)
% No internal titles. Leave useful axis labels intact.
axesList=findall(fig,'Type','axes');
for j=1:numel(axesList)
    ax=axesList(j);
    title(ax,'');
    set(ax,'FontName','Times New Roman');
    try, ax.XLabel.FontName='Times New Roman'; catch, end
    try, ax.YLabel.FontName='Times New Roman'; catch, end
end
objs=findall(fig);
for j=1:numel(objs)
    try
        if isprop(objs(j),'FontName')
            objs(j).FontName='Times New Roman';
        end
    catch
    end
end
end
