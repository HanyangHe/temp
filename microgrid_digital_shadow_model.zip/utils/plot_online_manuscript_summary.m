function plot_online_manuscript_summary(truth,evaluations,c,cfg,outDir)
%PLOT_ONLINE_MANUSCRIPT_SUMMARY Official four-row online-ablation manuscript figure.
% Row 1: representative hidden parameter deviation.
% Row 2: voltage magnitude for the four adaptation/synchronization variants.
% Row 3: absolute voltage-magnitude error (not the detector metric).
% Row 4: post-update tracking RMSE by deployment variant.
%
% The four variants separate coefficient adaptation (OFF/ON) from measured-
% state synchronization (OFF/ON). Accepted detection-to-activation intervals
% from the canonical adapted+sync deployment are shaded on Rows 2-3.

if ~isfield(truth,'parameters') || ~isfield(truth.parameters,'driftValue') || isempty(truth.parameters.driftValue)
    return;
end
if ~strcmpi(string(truth.parameters.driftDeviceType),'gfm')
    return;
end
k = truth.parameters.driftDevice;
if k<1 || k>numel(c.gfm) || ~isfield(c.gfm(k),'bus')
    return;
end
bus = c.gfm(k).bus;
truthV = abs(truth.V(bus,:));
nominal = nominal_parameter_value(truth);
if ~isreal(truth.parameters.driftValue) || ~isreal(nominal) || ~isfinite(nominal)
    return;
end
% Plot an absolute parameter deviation rather than a percentage mismatch.
% This keeps the axis directly tied to the physical symbol used in the
% manuscript (for the present case, n_q in the GFM voltage-droop law).
deltaParameter = real(truth.parameters.driftValue(:)) - real(nominal);
canonicalUpdate = canonical_update_record(evaluations);
trackingInfo = get_online_tracking_windows(truth,canonicalUpdate);
delayIntervals = trackingInfo.delayIntervals;

fig = figure('Name','Online manuscript parameter-voltage-error','Color','w', ...
    'Visible',cfg.figures.visible);
set(fig,'Name','');
% Keep the exact original figure width/style; only increase total height by
% 4/3 so four rows have the same per-row height as the original 3-row figure.
try
    fig.Units='pixels';
    pos=fig.Position;
    pos(4)=round(pos(4)*4/3);
    fig.Position=pos;
catch
end
tl = tiledlayout(4,1,'TileSpacing','compact','Padding','compact'); %#ok<NASGU>

ax1 = nexttile; hold(ax1,'on');
plot(ax1,truth.t,deltaParameter,'-','Color',[0.8500 0.3250 0.0980],'LineWidth',1.5, ...
    'DisplayName','Parameter deviation');
ylabel(ax1,parameter_deviation_ylabel(truth),'Interpreter','latex');
grid(ax1,'on');

ax2 = nexttile; hold(ax2,'on');
h2 = gobjects(0); labels2 = strings(0);
h2(end+1)=plot(ax2,truth.t,truthV,'k:','LineWidth',2.0); labels2(end+1)="Truth"; %#ok<AGROW>
for i = 1:numel(evaluations)
    ev = evaluations{i}; p = ev.prediction;
    if ~isstruct(p) || ~isfield(p,'V') || size(p.V,1)<bus || isempty(p.t)
        continue;
    end
    [style,lbl] = get_style(ev);
    h2(end+1)=plot(ax2,p.t,abs(p.V(bus,:)),'LineStyle',style.LineStyle, ...
        'LineWidth',style.LineWidth,'Color',style.Color); %#ok<AGROW>
    labels2(end+1)=lbl; %#ok<AGROW>
end
hDelay2 = shade_update_delay_intervals(ax2,delayIntervals);
if isgraphics(hDelay2)
    h2(end+1)=hDelay2; %#ok<AGROW>
    labels2(end+1)="Delay"; %#ok<AGROW>
end
ylabel(ax2,sprintf('|V_{%d}| (pu)',bus));
grid(ax2,'on');

ax3 = nexttile; hold(ax3,'on');
for i = 1:numel(evaluations)
    ev = evaluations{i}; p = ev.prediction;
    if ~isstruct(p) || ~isfield(p,'V') || size(p.V,1)<bus || isempty(p.t)
        continue;
    end
    if numel(p.t) ~= numel(truth.t) || any(abs(p.t(:)-truth.t(:))>1e-12)
        yPred = interp1(p.t(:),abs(p.V(bus,:)).',truth.t(:),'linear','extrap');
    else
        yPred = abs(p.V(bus,:)).';
    end
    err = abs(yPred - truthV(:));
    [style,~] = get_style(ev);
    plot(ax3,truth.t,err,'LineStyle',style.LineStyle, ...
        'LineWidth',style.LineWidth,'Color',style.Color);
end
shade_update_delay_intervals(ax3,delayIntervals);
ylabel(ax3,'Voltage-magnitude error (pu)','FontName','Times New Roman');
xlabel(ax3,'Time (s)');
grid(ax3,'on');

% Row 4: tracking-window RMSE for the same four Stage-3 variants.
% Four-row layout retained for the manuscript.
ax4 = nexttile; hold(ax4,'on');
[modes4,labels4,colors4] = deployment_summary_spec();
track = nan(1,numel(modes4));
for j=1:numel(modes4)
    evj=find_eval_by_mode(evaluations,modes4(j));
    if isempty(evj), continue; end
    if isfield(evj,'trackingMetrics') && isstruct(evj.trackingMetrics) && ...
            isfield(evj.trackingMetrics,'RMSE') && isfinite(evj.trackingMetrics.RMSE)
        track(j)=double(evj.trackingMetrics.RMSE);
    elseif isfield(evj,'metrics') && isstruct(evj.metrics) && ...
            isfield(evj.metrics,'RMSE') && isfinite(evj.metrics.RMSE)
        track(j)=double(evj.metrics.RMSE);
    end
end
for j=1:numel(track)
    if isfinite(track(j))
        bar(ax4,j,track(j),0.68,'FaceColor',colors4(j,:), ...
            'EdgeColor',[0.15 0.15 0.15],'LineWidth',0.9);
    end
end
set(ax4,'XTick',1:numel(labels4),'XTickLabel',cellstr(labels4));
ylabel(ax4,'RMSE');
xlabel(ax4,'Deployment variant');
grid(ax4,'on');
if any(isfinite(track))
    ymax=max(track(isfinite(track)));
    if ymax>0, ylim(ax4,[0 1.15*ymax]); end
end

lgd = legend(ax2,h2,cellstr(labels2),'Orientation','horizontal', ...
    'NumColumns',4,'Interpreter','none','Box','on');
% Show only actual plotted quantities: truth, the four variants, and delay.
% The detector threshold is a normalized vector-field score, not a voltage limit.
try
    lgd.ItemTokenSize = [22 8];
catch
end
try
    lgd.Layout.Tile='north';
catch
    lgd.Location='northoutside';
end

% IEEE caption supplies title; use Times New Roman for all rendered text.
figureAxes=findall(fig,'Type','axes');
for j=1:numel(figureAxes)
    ax=figureAxes(j);
    title(ax,'');
    set(ax,'FontName','Times New Roman');
    try, ax.XLabel.FontName='Times New Roman'; catch, end
    try, ax.YLabel.FontName='Times New Roman'; catch, end
end
allFonts=findall(fig);
for j=1:numel(allFonts)
    try
        if isprop(allFonts(j),'FontName')
            allFonts(j).FontName='Times New Roman';
        end
    catch
    end
end
export_offline_figure(fig,outDir,'online_manuscript_parameter_voltage_error',cfg);
end

function [style,label] = get_style(ev)
mode = lower(string(ev.mode));
switch mode
    case {"frozen_no_sync","frozen"}
        label="F";              color=[0.0000 0.4470 0.7410]; ls='--'; lw=1.25;
    case "frozen_sync"
        label="F+S";            color=[0.3010 0.7450 0.9330]; ls='-';  lw=1.45;
    case "adapted_no_sync"
        label="A";              color=[0.8500 0.3250 0.0980]; ls='--'; lw=1.35;
    case {"adapted_sync","online"}
        label="A+S (proposed)"; color=[0.8500 0.0500 0.0500]; ls='-';  lw=2.00;
    otherwise
        label=upper(mode);       color=[0.25 0.25 0.25]; ls=':';  lw=1.20;
end
style = struct('Color',color,'LineStyle',ls,'LineWidth',lw);
end

function [modes,labels,colors] = deployment_summary_spec()
modes  = ["frozen_no_sync","frozen_sync","adapted_no_sync","adapted_sync"];
labels = ["F","F+S","A","A+S"];
colors = [ ...
    0.0000 0.4470 0.7410; ...
    0.3010 0.7450 0.9330; ...
    0.8500 0.3250 0.0980; ...
    0.8500 0.0500 0.0500];
end

function ev=find_eval_by_mode(evaluations,mode)
ev=[];
for i=1:numel(evaluations)
    e=evaluations{i};
    if ~isstruct(e) || ~isfield(e,'mode'), continue; end
    if strcmpi(string(e.mode),mode)
        ev=e;
        return;
    end
end
end

function label=deployment_label(mode)
mode=lower(string(mode));
switch mode
    case "frozen_no_sync", label="F";
    case "frozen_sync", label="F+S";
    case "adapted_no_sync", label="A";
    case "adapted_sync", label="A+S";
    case "frozen", label="F";
    case "online", label="O";
    otherwise, label=upper(mode);
end
end

function s=parameter_deviation_ylabel(truth)
% Use the manuscript parameter symbol without a device index. Multi-GFM
% cases may perturb several devices, while this compact figure intentionally
% shows only the representative device profile.
par = lower(strtrim(string(truth.parameters.driftParameter)));
switch par
    case "nq"
        s = '$\Delta n_q$';
    case "mp"
        s = '$\Delta m_p$';
    otherwise
        safePar = regexprep(char(par),'_','\\_');
        s = sprintf('$\\Delta %s$',safePar);
end
end

function nominal=nominal_parameter_value(truth)
nominal=NaN;
if ~isfield(truth,'metadata') || ~isfield(truth.metadata,'caseData') || ~isfield(truth.metadata.caseData,'drift')
    return;
end
D=truth.metadata.caseData.drift;
c0=truth.metadata.caseData; c0.drift.enabled=false;
p0=mg_parameter_profile(truth.t(1),c0);
type=lower(char(D.deviceType));
field=char(D.parameter);
if isfield(truth,'parameters') && isfield(truth.parameters,'driftDevice') && ~isempty(truth.parameters.driftDevice)
    dev=double(truth.parameters.driftDevice);
else
    dev=double(D.device(1));
end
if isfield(p0,type) && dev>=1 && dev<=numel(p0.(type)) && isfield(p0.(type)(dev),field)
    nominal=p0.(type)(dev).(field);
end
end

function update=canonical_update_record(evaluations)
update=struct();
for i=1:numel(evaluations)
    ev=evaluations{i};
    if ~isstruct(ev) || ~isfield(ev,'mode') || ...
            ~is_canonical_update_mode(ev.mode) || ...
            ~isfield(ev,'update') || ~isstruct(ev.update)
        continue;
    end
    update=ev.update;
    return;
end
end

function intervals=collect_update_delay_intervals(evaluations,truth)
% Accepted update-to-activation intervals.
% By default the shade starts at the detector trigger time. However, when a
% known physical mismatch is introduced abruptly (for example the hidden
% piecewise-constant nq jump at t=0 and t=6 s), the compact manuscript figure
% should visually reserve the delay beginning from that physical onset rather
% than from the later detector crossing. Therefore the FIRST accepted update
% after each configured mismatch-change time is anchored back to that change
% time, while other accepted updates keep their actual trigger times.
records=struct('start',{},'trigger',{},'activation',{});
for i=1:numel(evaluations)
    ev=evaluations{i};
    if ~isstruct(ev) || ~isfield(ev,'mode') || ~is_canonical_update_mode(ev.mode) || ...
            ~isfield(ev,'update') || ~isstruct(ev.update)
        continue;
    end
    history={};
    if isfield(ev.update,'history') && iscell(ev.update.history)
        history=ev.update.history;
    elseif isfield(ev.update,'updateHistory') && iscell(ev.update.updateHistory)
        history=ev.update.updateHistory;
    end
    for j=1:numel(history)
        h=history{j};
        if ~isstruct(h) || ~isfield(h,'candidateAccepted') || ~logical(h.candidateAccepted)
            continue;
        end
        if ~isfield(h,'triggerTime') || ~isfield(h,'activationTime') || ...
                ~isfinite(h.triggerTime) || ~isfinite(h.activationTime) || h.activationTime<=h.triggerTime
            continue;
        end
        records(end+1)=struct( ... %#ok<AGROW>
            'start',double(h.triggerTime), ...
            'trigger',double(h.triggerTime), ...
            'activation',double(h.activationTime));
    end
end
if isempty(records)
    intervals=zeros(0,2);
    return;
end
[~,order]=sort([records.trigger]);
records=records(order);

changeTimes=parameter_mismatch_change_times(truth);
tol=1e-9;
for iTime=1:numel(changeTimes)
    tc=changeTimes(iTime);
    idx=find([records.trigger] >= tc-tol & [records.activation] >= tc-tol,1,'first');
    if ~isempty(idx)
        records(idx).start=min(records(idx).start,tc);
    end
end

intervals=zeros(numel(records),2);
for i=1:numel(records)
    intervals(i,:)=[records(i).start,records(i).activation];
end
intervals=sortrows(intervals,1);
% Merge overlaps so several enabled online methods do not darken the same
% physical interval repeatedly.
merged=intervals(1,:);
for i=2:size(intervals,1)
    if intervals(i,1)<=merged(end,2)+1e-12
        merged(end,2)=max(merged(end,2),intervals(i,2));
    else
        merged(end+1,:)=intervals(i,:); %#ok<AGROW>
    end
end
intervals=merged;
end

function changeTimes=parameter_mismatch_change_times(truth)
changeTimes=[];
if ~isstruct(truth) || ~isfield(truth,'t') || isempty(truth.t) || ...
        ~isfield(truth,'metadata') || ~isfield(truth.metadata,'caseData') || ...
        ~isfield(truth.metadata.caseData,'drift')
    return;
end
D=truth.metadata.caseData.drift;
if ~isfield(D,'enabled') || ~logical(D.enabled)
    return;
end
profile='smooth_step';
if isfield(D,'profile') && strlength(string(D.profile))>0
    profile=lower(char(string(D.profile)));
end
switch profile
    case {'piecewise_constant','piecewise','schedule'}
        if isfield(D,'times') && ~isempty(D.times)
            changeTimes=double(D.times(:).');
        end
    case {'constant','constant_from_start','fixed_mismatch'}
        changeTimes=double(truth.t(1));
    case {'smooth_step','step','legacy','linear','linear_ramp','ramp'}
        if isfield(D,'time') && ~isempty(D.time)
            changeTimes=double(D.time(:).');
        end
end
if isempty(changeTimes)
    return;
end
changeTimes=changeTimes(isfinite(changeTimes));
if isempty(changeTimes)
    return;
end
changeTimes=unique(changeTimes,'sorted');
% Clamp tiny roundoff to the first saved sample so a mismatch beginning at
% the start of the horizon shades from the left edge of the axis.
changeTimes(abs(changeTimes-double(truth.t(1)))<=1e-9)=double(truth.t(1));
end

function tf=is_canonical_update_mode(mode)
mode=lower(string(mode));
tf = mode=="adapted_sync" || mode=="online";
end

function hLegend=shade_update_delay_intervals(ax,intervals)
hLegend=gobjects(1);
if isempty(intervals), return; end
yl=ylim(ax);
base=get(groot,'defaultAxesColorOrder');
if isempty(base), base=[0 0.4470 0.7410]; end
% Slightly stronger shading to distinguish causal delay windows without
% obscuring measured/model trajectories or changing their timing.
shadeColor=0.55*base(1,:)+0.45*[1 1 1];
for i=1:size(intervals,1)
    x0=intervals(i,1); x1=intervals(i,2);
    hp=patch(ax,[x0 x1 x1 x0],[yl(1) yl(1) yl(2) yl(2)],shadeColor, ...
        'FaceAlpha',0.40,'EdgeColor','none','HandleVisibility','off');
    try, uistack(hp,'bottom'); catch, end
    if i==1
        hLegend=hp;
        set(hLegend,'HandleVisibility','on');
    end
end
ylim(ax,yl);
end

function label=method_label(name)
switch lower(strtrim(string(name)))
    case lower("M-KBF"), label="M-KBF";
    case lower("Vanilla SINDy"), label="V-SINDy";
    case lower("Physics-embedded SINDy"), label="PE-SINDy";
    case lower("Neural SINDy"), label="N-SINDy";
    case lower("Physics-Neural SINDy"), label="PN-SINDy";
    case lower("Neural ODE"), label="NODE";
    otherwise, label=string(name);
end
end
