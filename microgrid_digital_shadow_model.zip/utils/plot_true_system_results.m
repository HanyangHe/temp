function plot_true_system_results(results,c)
%PLOT_TRUE_SYSTEM_RESULTS Diagnostic plots for the reference physical DAE.
% Figure 1 shows physical responses; Figure 2 shows the imposed operating
% sequences so the user can directly verify what caused each transient.

t = results.t;

%% Physical-system response
figure('Name','True physical microgrid DAE','Color','w');
tl = tiledlayout(2,2,'TileSpacing','compact','Padding','compact');

nexttile;
plot(t,abs(results.V).','LineWidth',1.0);
xlabel('Time (s)'); ylabel('|V| (pu)');
title('Bus-voltage magnitudes'); grid on;
yline(0.90,'--'); yline(1.10,'--');

nexttile;
hold on;
if ~isempty(results.sg.fHz), plot(t,results.sg.fHz.','LineWidth',1.5); end
if ~isempty(results.gfm.fHz), plot(t,results.gfm.fHz.','LineWidth',1.5); end
if ~isempty(results.gfl.fHz), plot(t,results.gfl.fHz.','LineWidth',1.5); end
yline(c.base.f,'--');
xlabel('Time (s)'); ylabel('Frequency (Hz)');
title('Source / PLL frequencies'); grid on;
legend(compose_frequency_legend(c),'Location','best');

nexttile;
hold on;
plot(t,real(results.Sgrid),'LineWidth',1.5);
if ~isempty(results.sg.P), plot(t,results.sg.P.','LineWidth',1.5); end
if ~isempty(results.gfm.P), plot(t,results.gfm.P.','LineWidth',1.5); end
if ~isempty(results.gfl.P), plot(t,results.gfl.P.','LineWidth',1.5); end
xlabel('Time (s)'); ylabel('P injection (pu)');
title('Active-power injections'); grid on;
legend(compose_power_legend(c),'Location','best');

nexttile;
semilogy(t,max(results.networkResidualInf,eps),'LineWidth',1.5);
xlabel('Time (s)'); ylabel('||g||_\infty');
title('Non-slack algebraic residual'); grid on;

if isfield(c,'scenario') && isfield(c.scenario,'name')
    title(tl,sprintf('Grid-connected 10-bus reference DAE: %s',strrep(c.scenario.name,'_',' ')));
else
    title(tl,'Grid-connected 10-bus reference physical DAE');
end

%% Imposed operating-input/reference profiles
if ~isfield(results,'inputs')
    return;
end

figure('Name','Truth-model operating sequences','Color','w');
tl2 = tiledlayout(2,2,'TileSpacing','compact','Padding','compact');

nexttile;
hold on;
plot(t,sum(results.inputs.loadP,1),'LineWidth',1.5);
plot(t,sum(results.inputs.loadQ,1),'LineWidth',1.5);
xlabel('Time (s)'); ylabel('Load (pu)');
title('Total constant-PQ load'); grid on;
legend({'P_L','Q_L'},'Location','best');

nexttile;
hold on;
if ~isempty(results.inputs.sgPm)
    plot(t,results.inputs.sgPm.','LineWidth',1.5);
end
xlabel('Time (s)'); ylabel('P_m (pu)');
title('SG mechanical-power commands'); grid on;
legend(compose_device_labels('SG',size(results.inputs.sgPm,1)),'Location','best');

nexttile;
hold on;
if ~isempty(results.inputs.gfmPstar)
    plot(t,results.inputs.gfmPstar.','LineWidth',1.5);
end
if ~isempty(results.inputs.gfmQstar)
    plot(t,results.inputs.gfmQstar.','--','LineWidth',1.5);
end
xlabel('Time (s)'); ylabel('Reference (pu)');
title('GFM references'); grid on;
legend(compose_pq_reference_labels('GFM',size(results.inputs.gfmPstar,1)),'Location','best');

nexttile;
hold on;
if ~isempty(results.inputs.gflPstar)
    plot(t,results.inputs.gflPstar.','LineWidth',1.5);
end
if ~isempty(results.inputs.gflQstar)
    plot(t,results.inputs.gflQstar.','--','LineWidth',1.5);
end
xlabel('Time (s)'); ylabel('Reference (pu)');
title('GFL references'); grid on;
legend(compose_pq_reference_labels('GFL',size(results.inputs.gflPstar,1)),'Location','best');

if isfield(c,'scenario') && isfield(c.scenario,'name')
    title(tl2,sprintf('Operating sequence: %s',strrep(c.scenario.name,'_',' ')));
else
    title(tl2,'Truth-model operating sequence');
end
end

function labels = compose_frequency_legend(c)
labels = strings(0,1);
for k=1:numel(c.sg), labels(end+1) = "SG"+k; end %#ok<AGROW>
for k=1:numel(c.gfm), labels(end+1) = "GFM"+k; end %#ok<AGROW>
for k=1:numel(c.gfl), labels(end+1) = "GFL-PLL"+k; end %#ok<AGROW>
labels(end+1) = "Nominal";
end

function labels = compose_power_legend(c)
labels = "Grid";
for k=1:numel(c.sg), labels(end+1) = "SG"+k; end %#ok<AGROW>
for k=1:numel(c.gfm), labels(end+1) = "GFM"+k; end %#ok<AGROW>
for k=1:numel(c.gfl), labels(end+1) = "GFL"+k; end %#ok<AGROW>
end

function labels = compose_device_labels(prefix,n)
labels = strings(1,n);
for k = 1:n
    labels(k) = string(prefix)+k;
end
end

function labels = compose_pq_reference_labels(prefix,n)
labels = strings(1,2*n);
idx = 0;
for k = 1:n
    idx = idx + 1;
    labels(idx) = string(prefix)+k+" P*";
end
for k = 1:n
    idx = idx + 1;
    labels(idx) = string(prefix)+k+" Q*";
end
end
