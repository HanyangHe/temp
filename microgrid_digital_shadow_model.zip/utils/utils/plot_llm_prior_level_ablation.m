function figPath = plot_llm_prior_level_ablation(allRunsTbl, outRoot, varargin)
% Paper-oriented official prior-level ablation figure.
% Final design:
%   (a) -log10(Trajectory RMSE)
%   (b) Active coefficients
%   Bars       : blue (central level)
%   Error bars : orange (LLM-generation variability; Lv.2/Lv.3 only)
%   Trend line : charcoal dashed line + white-filled diamond markers
%                (visually distinct from both bar and uncertainty)
%   No legend, no subplot titles, only (a)/(b) labels below panels.

p = inputParser;
p.addParameter('CaseName','',@(x)ischar(x)||isstring(x));
p.addParameter('FixedDataSeed',[],@(x)isempty(x)||(isnumeric(x)&&isscalar(x)));
p.parse(varargin{:});
opt = p.Results;

T = allRunsTbl;
if isempty(T)
    error('plot_llm_prior_level_ablation:EmptyTable','Input table is empty.');
end
T = localNormalizeVarNames(T);

varVariant = localPickVar(T, {'variant','level'});
varRMSE    = localPickVar(T, {'rmse','rolloutrmse'});
varActive  = localPickVar(T, {'activecoefficientcount','activecount','active'});
varDSeed   = localPickVar(T, {'dataseed','seed'});

variants = string(T.(varVariant));
rmseVals = double(T.(varRMSE));
actVals  = double(T.(varActive));
dataSeeds = double(T.(varDSeed));

lv0 = "none";
lv1 = "coordinate_only";
lv2 = "llm_direct";
lv3 = "llm_full";

% Representative fixed data seed. If not explicitly supplied, use the
% available seed giving the lowest V-SINDy RMSE (selection independent of
% the proposed LLM method).
if isempty(opt.FixedDataSeed)
    cand = unique(dataSeeds(~isnan(dataSeeds)))';
    fixedDataSeed = cand(1);
    bestRmse = inf;
    for s = cand
        idx = variants==lv0 & dataSeeds==s;
        if any(idx)
            cur = min(rmseVals(idx));
            if cur < bestRmse
                bestRmse = cur;
                fixedDataSeed = s;
            end
        end
    end
else
    fixedDataSeed = opt.FixedDataSeed;
end

L = [lv0 lv1 lv2 lv3];
accMean   = nan(1,4);   % -log10(RMSE)
accStd    = zeros(1,4);
activeMean = nan(1,4);
activeStd  = zeros(1,4);

for k = 1:4
    idx = variants==L(k) & dataSeeds==fixedDataSeed;
    rv = rmseVals(idx); rv = rv(~isnan(rv) & rv>0);
    av = actVals(idx);  av = av(~isnan(av));
    if isempty(rv), continue; end

    if k <= 2
        accMean(k) = -log10(rv(1));
        accStd(k) = 0;
        activeMean(k) = av(1);
        activeStd(k) = 0;
    else
        z = -log10(rv(:));
        accMean(k) = mean(z);
        if numel(z) > 1, accStd(k) = std(z,0); end
        activeMean(k) = mean(av(:));
        if numel(av) > 1, activeStd(k) = std(av(:),0); end
    end
end

if ~exist(outRoot,'dir'), mkdir(outRoot); end

% Balanced color hierarchy:
%   blue = result bars
%   orange = uncertainty
%   charcoal = trend relation
barColor   = [0.00 0.4470 0.7410];
errColor   = [0.8500 0.3250 0.0980];
trendColor = [0.26 0.26 0.26];

fig = figure('Visible','off','Color','w','Units','pixels','Position',[80 80 1680 620]);
tl = tiledlayout(fig,1,2,'Padding','compact','TileSpacing','compact');

% ---------------- (a) accuracy order ----------------
ax1 = nexttile(tl,1);
bar(ax1,1:4,accMean,0.68, ...
    'FaceColor',barColor,'EdgeColor',[0.12 0.12 0.12],'LineWidth',0.9);
hold(ax1,'on');

% Distinct, subordinate trend line.
plot(ax1,1:4,accMean,'--d', ...
    'Color',trendColor, ...
    'LineWidth',1.9, ...
    'MarkerSize',7.5, ...
    'MarkerFaceColor','w', ...
    'MarkerEdgeColor',trendColor);

% Only stochastic LLM levels carry uncertainty bars.
errorbar(ax1,3:4,accMean(3:4),accStd(3:4), ...
    'LineStyle','none','Color',errColor,'LineWidth',2.0,'CapSize',12);
hold(ax1,'off');

set(ax1,'Box','on','FontName','Times New Roman','FontSize',16,'LineWidth',1.1);
xticks(ax1,1:4);
xticklabels(ax1,{'Lv.0','Lv.1','Lv.2','Lv.3'});
ax1.XAxis.FontSize = 16;
ax1.YAxis.FontSize = 16;
ylabel(ax1,'-log_{10}(Trajectory RMSE)','FontName','Times New Roman','FontSize',18);
grid(ax1,'on'); ax1.GridAlpha=0.17;
finiteY = accMean(isfinite(accMean));
finiteS = accStd(isfinite(accMean));
if ~isempty(finiteY)
    ymin = max(0, min(finiteY-finiteS)-0.35);
    ymax = max(finiteY+finiteS)+0.35;
    ylim(ax1,[ymin ymax]);
end
text(ax1,0.5,-0.14,'(a)','Units','normalized','HorizontalAlignment','center', ...
    'VerticalAlignment','top','FontName','Times New Roman','FontSize',17);

% ---------------- (b) sparsity ----------------
ax2 = nexttile(tl,2);
bar(ax2,1:4,activeMean,0.68, ...
    'FaceColor',barColor,'EdgeColor',[0.12 0.12 0.12],'LineWidth',0.9);
hold(ax2,'on');

plot(ax2,1:4,activeMean,'--d', ...
    'Color',trendColor, ...
    'LineWidth',1.9, ...
    'MarkerSize',7.5, ...
    'MarkerFaceColor','w', ...
    'MarkerEdgeColor',trendColor);

errorbar(ax2,3:4,activeMean(3:4),activeStd(3:4), ...
    'LineStyle','none','Color',errColor,'LineWidth',2.0,'CapSize',12);
hold(ax2,'off');

set(ax2,'Box','on','FontName','Times New Roman','FontSize',16,'LineWidth',1.1);
xticks(ax2,1:4);
xticklabels(ax2,{'Lv.0','Lv.1','Lv.2','Lv.3'});
ax2.XAxis.FontSize = 16;
ax2.YAxis.FontSize = 16;
ylabel(ax2,'Active coefficients','FontName','Times New Roman','FontSize',18);
grid(ax2,'on'); ax2.GridAlpha=0.17;
if any(isfinite(activeMean))
    ymax2 = max(activeMean + activeStd);
    ylim(ax2,[0, ymax2*1.12]);
end
text(ax2,0.5,-0.14,'(b)','Units','normalized','HorizontalAlignment','center', ...
    'VerticalAlignment','top','FontName','Times New Roman','FontSize',17);

figPath = fullfile(outRoot,'llm_prior_level_ablation.pdf');
pngPath = fullfile(outRoot,'llm_prior_level_ablation_preview.png');
exportgraphics(fig,figPath,'ContentType','vector','BackgroundColor','white');
exportgraphics(fig,pngPath,'Resolution',300,'BackgroundColor','white');
close(fig);
end

function T = localNormalizeVarNames(T)
for k = 1:numel(T.Properties.VariableNames)
    vn = T.Properties.VariableNames{k};
    vn = regexprep(lower(vn),'[^a-z0-9]','');
    T.Properties.VariableNames{k} = vn;
end
end

function v = localPickVar(T,candidates)
vars = string(T.Properties.VariableNames);
for i = 1:numel(candidates)
    c = lower(regexprep(candidates{i},'[^a-z0-9]',''));
    hit = vars(strcmp(vars,c));
    if ~isempty(hit)
        v = char(hit(1));
        return;
    end
end
error('plot_llm_prior_level_ablation:MissingColumn','Missing required column. Candidates: %s',strjoin(candidates,', '));
end
