function tmpPath = make_hdf5_safe_temp_mat_path(targetPath)
%MAKE_HDF5_SAFE_TEMP_MAT_PATH Build a short temporary MAT path for v7.3 saves.
%
% MATLAB v7.3 uses HDF5. On Windows, HDF5 can fail with the misleading
% message that a newly created file "appears corrupted" when the temporary
% pathname is near/over the legacy MAX_PATH limit, even when movefile can
% later install a validated MAT file at the requested final path.
%
% Keep the temporary file on the same filesystem whenever possible by
% walking upward from the target directory until the generated temp path has
% comfortable path-length headroom. Non-Windows platforms keep the temp file
% beside the target as before.

if nargin < 1 || isempty(targetPath)
    error('make_hdf5_safe_temp_mat_path:MissingTarget', ...
        'A target file or directory path is required.');
end

targetPath = char(string(targetPath));
if exist(targetPath,'dir') == 7
    candidateDir = targetPath;
else
    candidateDir = fileparts(targetPath);
end
if isempty(candidateDir)
    candidateDir = pwd;
end

% Leave margin below the classic 260-character Windows path boundary because
% HDF5 may add internal suffixes/normalization during file creation.
windowsSafeChars = 240;

while true
    candidate = [tempname(candidateDir) '.mat'];
    if ~ispc || numel(candidate) <= windowsSafeChars
        tmpPath = candidate;
        return;
    end

    parentDir = fileparts(candidateDir);
    if isempty(parentDir) || strcmp(parentDir,candidateDir)
        break;
    end
    candidateDir = parentDir;
end

% Extremely deep/long roots are rare. Fall back to MATLAB's system temp
% location rather than allowing an HDF5 save to fail solely on path length.
tmpPath = [tempname(tempdir) '.mat'];
end
