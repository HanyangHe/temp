function info = get_online_tracking_windows(truth,update)
%GET_ONLINE_TRACKING_WINDOWS Build non-delay tracking windows for online evaluation.
%
% The tracking metric is evaluated only after the first hidden parameter
% mismatch and excludes intervals in which the online algorithm is causally
% waiting/detecting/updating/validating an accepted model candidate.
%
% Delay intervals are defined from the physical mismatch onset to the first
% accepted activation after each mismatch change, and from each later accepted
% detector trigger to its corresponding activation. The remaining intervals
% form the tracking windows. This definition matches the delay shading used in
% the manuscript online figure and avoids mixing adaptation latency with the
% quality of the active digital-shadow model.

info = struct();
info.valid = false;
info.domain = [NaN NaN];
info.changeTimes = zeros(0,1);
info.delayIntervals = zeros(0,2);
info.trackingWindows = zeros(0,2);
info.trackingDurationSeconds = NaN;
info.domainDurationSeconds = NaN;
info.trackingCoveragePercent = NaN;

if ~isstruct(truth) || ~isfield(truth,'t') || isempty(truth.t)
    return;
end

t0 = double(truth.t(1));
tf = double(truth.t(end));
changeTimes = parameter_mismatch_change_times(truth);
if isempty(changeTimes)
    return;
end

domainStart = max(t0,min(changeTimes));
domainEnd = tf;
if ~(isfinite(domainStart) && isfinite(domainEnd) && domainEnd>domainStart)
    return;
end

records = accepted_update_records(update);
if isempty(records)
    % No accepted synchronization event means there is no post-adaptation
    % tracking window to assess.
    info.domain = [domainStart domainEnd];
    info.changeTimes = changeTimes(:);
    return;
end

% Anchor the first accepted update after each known physical mismatch change
% back to that physical onset. Later refinement updates retain their actual
% detector trigger times.
tol = 1e-9;
for i = 1:numel(changeTimes)
    tc = changeTimes(i);
    idx = find([records.trigger] >= tc-tol & [records.activation] >= tc-tol,1,'first');
    if ~isempty(idx)
        records(idx).start = min(records(idx).start,tc);
    end
end

D = zeros(0,2);
for i = 1:numel(records)
    a = max(domainStart,double(records(i).start));
    b = min(domainEnd,double(records(i).activation));
    if isfinite(a) && isfinite(b) && b>a+1e-12
        D(end+1,:) = [a b]; %#ok<AGROW>
    end
end
D = merge_intervals(D);

% Complement of the delay intervals inside the mismatch-evaluation domain.
W = zeros(0,2);
cursor = domainStart;
for i = 1:size(D,1)
    if D(i,1)>cursor+1e-12
        W(end+1,:) = [cursor D(i,1)]; %#ok<AGROW>
    end
    cursor = max(cursor,D(i,2));
end
if cursor<domainEnd-1e-12
    W(end+1,:) = [cursor domainEnd]; %#ok<AGROW>
end

% A non-delay window that precedes the first accepted activation is not a
% post-adaptation tracking interval. This matters only for unusual schedules
% in which the first mismatch begins after the start of the simulation.
firstActivation = min([records.activation]);
if isfinite(firstActivation)
    W = clip_windows_after_time(W,firstActivation);
end

trackingDuration = sum(max(0,W(:,2)-W(:,1)));
domainDuration = domainEnd-domainStart;

info.valid = ~isempty(W) && trackingDuration>0;
info.domain = [domainStart domainEnd];
info.changeTimes = changeTimes(:);
info.delayIntervals = D;
info.trackingWindows = W;
info.trackingDurationSeconds = trackingDuration;
info.domainDurationSeconds = domainDuration;
if domainDuration>0
    info.trackingCoveragePercent = 100*trackingDuration/domainDuration;
end
end

function records = accepted_update_records(update)
records = struct('start',{},'trigger',{},'activation',{});
if ~isstruct(update)
    return;
end

history = {};
if isfield(update,'history') && iscell(update.history)
    history = update.history;
elseif isfield(update,'updateHistory') && iscell(update.updateHistory)
    history = update.updateHistory;
end

for i = 1:numel(history)
    h = history{i};
    if ~isstruct(h) || ~isfield(h,'candidateAccepted') || ~logical(h.candidateAccepted)
        continue;
    end
    if ~isfield(h,'triggerTime') || ~isfield(h,'activationTime') || ...
            ~isfinite(h.triggerTime) || ~isfinite(h.activationTime) || ...
            h.activationTime<=h.triggerTime
        continue;
    end
    records(end+1) = struct( ... %#ok<AGROW>
        'start',double(h.triggerTime), ...
        'trigger',double(h.triggerTime), ...
        'activation',double(h.activationTime));
end

% Fallback for compact saved records that retain activation times but not the
% full update history. The first physical mismatch change is then used as the
% delay start for the first activation; later activations cannot be assigned a
% causal trigger and are intentionally not invented.
if isempty(records) && isfield(update,'activationTimes') && ~isempty(update.activationTimes)
    acts = double(update.activationTimes(:));
    acts = acts(isfinite(acts));
    if ~isempty(acts)
        records(1) = struct('start',acts(1),'trigger',acts(1),'activation',acts(1));
    end
end

if ~isempty(records)
    [~,ord] = sort([records.trigger]);
    records = records(ord);
end
end

function D = merge_intervals(D)
if isempty(D)
    D = zeros(0,2);
    return;
end
D = sortrows(D,1);
M = D(1,:);
for i = 2:size(D,1)
    if D(i,1)<=M(end,2)+1e-12
        M(end,2)=max(M(end,2),D(i,2));
    else
        M(end+1,:)=D(i,:); %#ok<AGROW>
    end
end
D=M;
end

function W = clip_windows_after_time(W,t0)
if isempty(W), return; end
R=zeros(0,2);
for i=1:size(W,1)
    a=max(W(i,1),t0);
    b=W(i,2);
    if b>a+1e-12
        R(end+1,:)=[a b]; %#ok<AGROW>
    end
end
W=R;
end

function changeTimes = parameter_mismatch_change_times(truth)
changeTimes = [];
if ~isstruct(truth) || ~isfield(truth,'metadata') || ...
        ~isfield(truth.metadata,'caseData') || ...
        ~isfield(truth.metadata.caseData,'drift')
    return;
end
D = truth.metadata.caseData.drift;
if ~isfield(D,'enabled') || ~logical(D.enabled)
    return;
end
profile='smooth_step';
if isfield(D,'profile') && strlength(string(D.profile))>0
    profile=lower(char(string(D.profile)));
end
switch profile
    case {'piecewise_constant','piecewise','schedule'}
        if isfield(D,'times') && ~isempty(D.times)
            changeTimes=double(D.times(:).');
        end
    case {'constant','constant_from_start','fixed_mismatch'}
        changeTimes=double(truth.t(1));
    case {'smooth_step','step','legacy','linear','linear_ramp','ramp'}
        if isfield(D,'time') && ~isempty(D.time)
            changeTimes=double(D.time(:).');
        end
end
changeTimes=changeTimes(isfinite(changeTimes));
changeTimes=unique(changeTimes,'sorted');
if isempty(changeTimes), return; end
changeTimes(abs(changeTimes-double(truth.t(1)))<=1e-9)=double(truth.t(1));
end
