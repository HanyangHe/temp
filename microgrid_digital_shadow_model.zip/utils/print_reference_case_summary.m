function print_reference_case_summary(c,projectRoot)
%PRINT_REFERENCE_CASE_SUMMARY Human-readable report of the active v1 case.
% User settings remain in cases/. The reporter expands grouped action
% sequences so the user can see exactly what happens before simulation.

if nargin < 2 || isempty(projectRoot)
    projectRoot = pwd;
end
caseRel = fullfile('cases','case_grid_connected_10bus_true_physics.m');
lineRel = fullfile('cases','line_data_10bus_user_ems.m');
if isfield(c,'sourceFiles') && isstruct(c.sourceFiles)
    if isfield(c.sourceFiles,'case') && ~isempty(c.sourceFiles.case)
        caseRel = char(string(c.sourceFiles.case));
    end
    if isfield(c.sourceFiles,'line') && ~isempty(c.sourceFiles.line)
        lineRel = char(string(c.sourceFiles.line));
    end
end
caseFile = fullfile(projectRoot,caseRel);
lineFile = fullfile(projectRoot,lineRel);

fprintf('\n---------------- ACTIVE CASE / USER SETTINGS ----------------\n');
fprintf('Edit the active case here:\n  %s\n',caseFile);
fprintf('Network line data are defined here:\n  %s\n',lineFile);
fprintf('For ordinary parameter/scenario changes, edit the CASE file;\n');
fprintf('do not edit core solver/model files unless introducing a new event/model type.\n\n');

if isfield(c,'scenario')
    fprintf('[Scenario purpose]\n');
    if isfield(c.scenario,'name'), fprintf('  name       : %s\n',c.scenario.name); end
    if isfield(c.scenario,'description')
        fprintf('  objective  : %s\n',char(c.scenario.description));
    end
end

fprintf('[Network]\n');
fprintf('  mode       : %s\n',c.network.mode);
fprintf('  buses      : %d\n',c.network.N);
fprintf('  branches   : %d%s\n',numel(c.network.line.from),radial_suffix(c));
fprintf('  slack/grid : Bus %d, V = %.4f %+.4fj pu\n', ...
    c.network.slackBus,real(c.network.Vslack),imag(c.network.Vslack));

fprintf('[Bus elements]\n');
fprintf('  SG buses   : %s\n',index_list([c.sg.bus]));
fprintf('  GFM buses  : %s\n',index_list([c.gfm.bus]));
fprintf('  GFL buses  : %s\n',index_list([c.gfl.bus]));
loadBuses = find(abs(c.input.nominal.Sload) > 0).';
fprintf('  load buses : %s\n',index_list(loadBuses));
fprintf('  nominal total load: P = %.5f pu, Q = %.5f pu\n', ...
    sum(real(c.input.nominal.Sload)),sum(imag(c.input.nominal.Sload)));
if isfield(c.network,'fixedShuntCapacitors') && ...
        isstruct(c.network.fixedShuntCapacitors) && ...
        isfield(c.network.fixedShuntCapacitors,'bus') && ...
        ~isempty(c.network.fixedShuntCapacitors.bus)
    cap = c.network.fixedShuntCapacitors;
    fprintf('  fixed capacitor buses: %s\n',index_list(cap.bus(:).'));
    if isfield(cap,'Qkvar')
        fprintf('  fixed capacitors: %d banks, total Q = %.1f kvar\n', ...
            numel(cap.bus),sum(cap.Qkvar));
    else
        fprintf('  fixed capacitors: %d banks\n',numel(cap.bus));
    end
end
if ~isempty(c.sg) && isfield(c.sg(1),'model')
    fprintf('[SG dynamic model]\n');
    fprintf('  model      : %s\n',char(string(c.sg(1).model)));
    if strcmpi(string(c.sg(1).model),'salient_avr_5state')
        fprintf('  states     : [delta, nu, EqPrime, EdPrime, Efd]\n');
        fprintf('  inputs     : Pm, Vref | salient Xd''/Xq'' + first-order AVR\n');
    end
end

fprintf('[Operating-input/reference events]\n');
numActions = 0;
numActions = numActions + print_load_section(c,'load','Load',c.network.N);
numActions = numActions + print_reference_section(c,'sgPm','SG Pm',numel(c.sg));
numActions = numActions + print_reference_section(c,'sgVref','SG Vref',numel(c.sg));
numActions = numActions + print_reference_section(c,'gfmP','GFM Pstar',numel(c.gfm));
numActions = numActions + print_reference_section(c,'gfmQ','GFM Qstar',numel(c.gfm));
numActions = numActions + print_reference_section(c,'gfmEref','GFM Eref',numel(c.gfm));
numActions = numActions + print_reference_section(c,'gflP','GFL Pstar',numel(c.gfl),true);
numActions = numActions + print_reference_section(c,'gflQ','GFL Qstar',numel(c.gfl));
if numActions == 0
    fprintf('  none enabled.\n');
end
fprintf('  Group rule: target bus/device vector may have any length; time and\n');
fprintf('  fraction/delta define the shared sequence and must have equal length.\n');
eventTimes = collect_operating_event_times(c);
if ~isempty(eventTimes)
    fprintf('  Global event centers: [%s] s\n',strtrim(sprintf('%.2f ',eventTimes)));
    if numel(eventTimes) > 1
        minGap = min(diff(eventTimes));
        fprintf('  Minimum separation between distinct event centers: %.3f s',minGap);
        if isfield(c,'scenario') && isfield(c.scenario,'minInterEventSeparation')
            targetGap = c.scenario.minInterEventSeparation;
            if minGap + 1e-12 >= targetGap
                fprintf(' (target >= %.3f s: PASS)\n',targetGap);
            else
                fprintf(' (target >= %.3f s: WARNING)\n',targetGap);
                warning('print_reference_case_summary:EventSeparation', ...
                    'Minimum operating-event separation %.3f s is below configured target %.3f s.', ...
                    minGap,targetGap);
            end
        else
            fprintf('\n');
        end
    end
end
fprintf('  Default paper scenario uses separated persistent operating-point changes\n');
fprintf('  so each response can approach a quasi-steady state before the next event.\n');

fprintf('[Physical-model parameter drift]\n');
if isfield(c,'drift') && isfield(c.drift,'enabled') && c.drift.enabled
    type = lower(char(c.drift.deviceType));
    arr = c.(type);
    p0 = arr(c.drift.device).(char(c.drift.parameter));
    switch lower(char(c.drift.mode))
        case 'relative'
            p1 = p0*(1+c.drift.value);
        case 'additive'
            p1 = p0+c.drift.value;
        case 'set'
            p1 = c.drift.value;
        otherwise
            p1 = NaN;
    end
    fprintf('  ENABLED: t = %.3f s, %s %d, parameter %s, mode %s\n', ...
        c.drift.time,upper(type),c.drift.device,c.drift.parameter,c.drift.mode);
    fprintf('           nominal %s -> target %s (transition %.3f s).\n', ...
        value_string(p0),value_string(p1),c.drift.transition);
else
    fprintf('  disabled: baseline scenario contains operating changes only.\n');
    if isfield(c,'drift') && all(isfield(c.drift,{'deviceType','device','parameter','time','mode','value'}))
        fprintf('  Prepared drift example in the case file: %s %d, %s, %s %s at t = %.3f s.\n', ...
            upper(char(string(c.drift.deviceType))),c.drift.device, ...
            char(string(c.drift.parameter)),char(string(c.drift.mode)), ...
            value_string(c.drift.value),c.drift.time);
    end
end

fprintf('[Simulation]\n');
fprintf('  time       : %.3f to %.3f s\n',c.sim.t0,c.sim.tf);
fprintf('  saved step : %.6f s (ODE15I internal step is adaptive)\n',c.sim.outputStep);
fprintf('  RelTol/AbsTol/MaxStep: %.1e / %.1e / %.6f s\n', ...
    c.sim.RelTol,c.sim.AbsTol,c.sim.MaxStep);
fprintf('  evaluation intent: full-window trajectory accuracy over the complete %.3f-s scenario\n',c.sim.tf-c.sim.t0);
fprintf('-------------------------------------------------------------\n\n');
end

function nActions = print_load_section(c,sectionName,label,nBuses)
nActions = 0;
if ~disturbance_enabled(c,sectionName), return; end
s = c.dist.(sectionName);
if isfield(s,'group') && ~isempty(s.group)
    for r = 1:numel(s.group)
        grp = s.group(r);
        require_fields(grp,{'bus','time','fraction','transition'}, ...
            sprintf('c.dist.%s.group(%d)',sectionName,r));
        buses = validate_indices_for_report(grp.bus,nBuses, ...
            sprintf('c.dist.%s.group(%d).bus',sectionName,r));
        times = grp.time(:);
        vals = grp.fraction(:);
        validate_times_values(c,times,vals, ...
            sprintf('c.dist.%s.group(%d)',sectionName,r),'fraction');
        tau = transition_for_report(grp.transition,numel(times), ...
            sprintf('c.dist.%s.group(%d).transition',sectionName,r));
        fprintf('  %s group %d: buses [%s] share one sequence\n',label,r,index_list(buses));
        cumulative = 0;
        for j = 1:numel(times)
            nActions = nActions + 1;
            cumulative = cumulative + vals(j);
            fprintf(['    action %d: t = %.3f s, increment %+.2f%% of nominal Sload ' ...
                     '(cumulative %+.2f%%, transition %.3f s)\n'], ...
                j,times(j),100*vals(j),100*cumulative,tau(j));
        end
    end
else
    % Legacy flat load format.
    require_fields(s,{'bus','time','fraction','transition'},'c.dist.load');
    buses = validate_indices_for_report(s.bus,nBuses,'c.dist.load.bus');
    fprintf('  Legacy load event: t = %.3f s, buses [%s], change %+.2f%%\n', ...
        s.time,index_list(buses),100*s.fraction);
    nActions = 1;
end
end

function nActions = print_reference_section(c,sectionName,label,nDevices,varargin)
nActions = 0;
allowLegacy = false;
if nargin >= 5 && ~isempty(varargin), allowLegacy = logical(varargin{1}); end
if ~disturbance_enabled(c,sectionName), return; end
s = c.dist.(sectionName);
if isfield(s,'group') && ~isempty(s.group)
    for r = 1:numel(s.group)
        grp = s.group(r);
        require_fields(grp,{'device','time','delta','transition'}, ...
            sprintf('c.dist.%s.group(%d)',sectionName,r));
        devices = validate_indices_for_report(grp.device,nDevices, ...
            sprintf('c.dist.%s.group(%d).device',sectionName,r));
        times = grp.time(:);
        vals = grp.delta(:);
        validate_times_values(c,times,vals, ...
            sprintf('c.dist.%s.group(%d)',sectionName,r),'delta');
        tau = transition_for_report(grp.transition,numel(times), ...
            sprintf('c.dist.%s.group(%d).transition',sectionName,r));
        fprintf('  %s group %d: devices [%s] share one sequence\n', ...
            label,r,index_list(devices));
        cumulative = 0;
        for j = 1:numel(times)
            nActions = nActions + 1;
            cumulative = cumulative + vals(j);
            fprintf(['    action %d: t = %.3f s, increment %+.5f pu ' ...
                     '(cumulative %+.5f pu, transition %.3f s)\n'], ...
                j,times(j),vals(j),cumulative,tau(j));
        end
    end
elseif allowLegacy
    require_fields(s,{'device','time','delta','transition'}, ...
        sprintf('c.dist.%s',sectionName));
    devices = validate_indices_for_report(s.device,nDevices, ...
        sprintf('c.dist.%s.device',sectionName));
    fprintf('  Legacy %s event: t = %.3f s, devices [%s], change %+.5f pu\n', ...
        label,s.time,index_list(devices),s.delta);
    nActions = 1;
else
    error('print_reference_case_summary:MissingGroup', ...
        '%s is enabled but c.dist.%s.group is empty or missing.',label,sectionName);
end
end

function tf = disturbance_enabled(c,name)
tf = false;
if ~isfield(c,'dist') || ~isfield(c.dist,name), return; end
s = c.dist.(name);
if isfield(s,'enabled')
    if isempty(s.enabled)
        tf = false;
    elseif ~isscalar(s.enabled)
        error('print_reference_case_summary:EnabledMustBeScalar', ...
            'c.dist.%s.enabled must be scalar.',name);
    else
        tf = logical(s.enabled);
    end
elseif isfield(s,'group') && ~isempty(s.group)
    tf = true;
else
    switch lower(name)
        case 'load'
            tf = all(isfield(s,{'bus','time','fraction','transition'}));
        case 'gflp'
            tf = all(isfield(s,{'device','time','delta','transition'}));
    end
end
end

function validate_times_values(c,times,values,label,valueField)
if numel(times) ~= numel(values)
    error('print_reference_case_summary:SequenceLength', ...
        '%s.time and .%s must have the same number of elements.',label,valueField);
end
if isempty(times) || any(~isfinite(times)) || any(~isfinite(values))
    error('print_reference_case_summary:InvalidSequence', ...
        '%s time/action vectors must be nonempty and finite.',label);
end
if any(times < c.sim.t0) || any(times > c.sim.tf)
    error('print_reference_case_summary:EventOutsideWindow', ...
        '%s contains an event time outside simulation window [%.3f, %.3f] s.', ...
        label,c.sim.t0,c.sim.tf);
end
if any(diff(times) <= 0)
    error('print_reference_case_summary:EventTimeOrder', ...
        '%s.time must be strictly increasing within each action sequence.',label);
end
end

function require_fields(s,names,label)
for k = 1:numel(names)
    if ~isfield(s,names{k})
        error('print_reference_case_summary:MissingField', ...
            '%s is missing required field "%s".',label,names{k});
    end
end
end

function idx = validate_indices_for_report(idx,nMax,label)
idx = idx(:).';
if isempty(idx) || any(~isfinite(idx)) || any(idx ~= round(idx)) || ...
        any(idx < 1) || any(idx > nMax)
    error('print_reference_case_summary:InvalidTarget', ...
        '%s must contain integer indices inside 1:%d. Current value: [%s].', ...
        label,nMax,strtrim(sprintf('%g ',idx)));
end
end

function tau = transition_for_report(tau,n,label)
if isscalar(tau)
    tau = repmat(tau,n,1);
else
    tau = tau(:);
    if numel(tau) ~= n
        error('print_reference_case_summary:TransitionLength', ...
            '%s must be scalar or have the same length as the action sequence.',label);
    end
end
if any(~isfinite(tau)) || any(tau < 0)
    error('print_reference_case_summary:TransitionValue', ...
        '%s must be finite and nonnegative.',label);
end
end

function times = collect_operating_event_times(c)
% Collect distinct enabled operating-action times across load and DER sections.
times = [];
sections = {'load','sgPm','sgVref','gfmP','gfmQ','gfmEref','gflP','gflQ'};
for ii = 1:numel(sections)
    name = sections{ii};
    if ~disturbance_enabled(c,name), continue; end
    s = c.dist.(name);
    if isfield(s,'group') && ~isempty(s.group)
        for rr = 1:numel(s.group)
            if isfield(s.group(rr),'time')
                times = [times; s.group(rr).time(:)]; %#ok<AGROW>
            end
        end
    elseif isfield(s,'time')
        times = [times; s.time(:)]; %#ok<AGROW>
    end
end
if isempty(times), return; end
times = sort(unique(times(:))).';
end

function s = index_list(v)
if isempty(v)
    s = 'none';
else
    s = strtrim(sprintf('%d ',v));
end
end

function suffix = radial_suffix(c)
if numel(c.network.line.from) == c.network.N-1
    suffix = ' (N-1 radial count)';
else
    suffix = '';
end
end

function s = value_string(v)
if isreal(v)
    s = sprintf('%.8g',v);
else
    s = sprintf('%.8g%+.8gj',real(v),imag(v));
end
end
