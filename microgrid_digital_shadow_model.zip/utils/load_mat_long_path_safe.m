function S = load_mat_long_path_safe(filePath,varargin)
%LOAD_MAT_LONG_PATH_SAFE Load MAT variables with a Windows long-path fallback.
%
% S = load_mat_long_path_safe(filePath,'var1','var2',...)
%
% MATLAB v7.3 MAT files are HDF5 containers. On Windows, HDF5-backed LOAD can
% fail on a long pathname with the misleading message that the file is not a
% binary MAT file, even though the same file loads correctly from a shorter
% pathname. This helper first attempts the ordinary LOAD. If that fails, it
% copies the file to a short temporary MAT pathname, loads it there, and then
% removes the temporary copy. The source file is never modified.

if nargin < 1 || isempty(filePath)
    error('load_mat_long_path_safe:MissingFile', ...
        'A MAT-file path is required.');
end

filePath = char(string(filePath));
if exist(filePath,'file') ~= 2
    error('load_mat_long_path_safe:MissingFile', ...
        'MAT file was not found: %s',filePath);
end

try
    S = load(filePath,varargin{:});
    return;
catch directME
    % Continue to the short-path fallback. This is intentionally attempted
    % for any LOAD failure because the misleading long-path HDF5 error does
    % not expose a reliable platform-specific identifier.
end

tmpPath = make_hdf5_safe_temp_mat_path(filePath);
cleanupObj = onCleanup(@() delete_temp_local(tmpPath));

[ok,msg] = copyfile(filePath,tmpPath,'f');
if ~ok
    E = MException('load_mat_long_path_safe:CopyFailed', ...
        ['Direct LOAD failed and the long-path fallback could not copy the ', ...
         'MAT file to a short temporary pathname.\nSource: %s\nTemp: %s\nCopy error: %s'], ...
        filePath,tmpPath,msg);
    E = addCause(E,directME);
    throw(E);
end

try
    S = load(tmpPath,varargin{:});
catch tempME
    E = MException('load_mat_long_path_safe:LoadFailed', ...
        ['MAT-file loading failed both at the original pathname and after ', ...
         'copying the same bytes to a short temporary pathname. The file may ', ...
         'be genuinely invalid/corrupted.\nSource: %s\nTemp: %s'], ...
        filePath,tmpPath);
    E = addCause(E,directME);
    E = addCause(E,tempME);
    throw(E);
end

clear cleanupObj; % delete the temporary copy now
end

function delete_temp_local(filePath)
if exist(filePath,'file') == 2
    try
        delete(filePath);
    catch
    end
end
end
