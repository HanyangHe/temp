function [summary,perVariable,info] = compute_online_tracking_metrics( ...
    prediction,truth,update,c,layout,cfg)
%COMPUTE_ONLINE_TRACKING_METRICS Quantify non-delay online tracking quality.
%
% Tracking windows are defined by GET_ONLINE_TRACKING_WINDOWS. The metric
% therefore evaluates how well an already active digital-shadow model follows
% the true system, while adaptation latency is kept as a separate engineering
% quantity.

varNames=get_dae_variable_names(c,layout);
info=get_online_tracking_windows(truth,update);
[summary,perVariable]=failed_metrics_local(varNames);
summary.WindowCount=0;
summary.DurationSec=NaN;
summary.CoveragePercent=NaN;
summary.Windows=zeros(0,2);
summary.KeyVoltageBus=NaN;
summary.KeyVoltageRMSE=NaN;
summary.KeyVoltageMAE=NaN;
summary.KeyVoltageMeanError=NaN;

if ~isfield(cfg,'online') || ~isfield(cfg.online,'tracking') || ...
        ~isfield(cfg.online.tracking,'enabled') || ~logical(cfg.online.tracking.enabled)
    return;
end
if ~info.valid || ~isstruct(prediction) || ~isfield(prediction,'t') || ...
        isempty(prediction.t) || ~isfield(prediction,'y') || isempty(prediction.y)
    return;
end

mask=tracking_mask(double(prediction.t(:)),info.trackingWindows);
if nnz(mask)<2
    return;
end

tPred=double(prediction.t(mask));
yPred=prediction.y(mask,:);
yTruth=interp1(double(truth.t(:)),truth.y,tPred,'linear');
if any(~isfinite(yPred),'all') || any(~isfinite(yTruth),'all')
    return;
end

[summary,perVariable]=compute_trajectory_error_metrics(yTruth,yPred,varNames,cfg);
summary.WindowCount=size(info.trackingWindows,1);
summary.DurationSec=info.trackingDurationSeconds;
summary.CoveragePercent=info.trackingCoveragePercent;
summary.Windows=info.trackingWindows;

bus=tracking_voltage_bus(c,truth,cfg);
summary.KeyVoltageBus=bus;
if isfinite(bus) && bus>=1 && isfield(prediction,'V') && ~isempty(prediction.V) && ...
        size(prediction.V,1)>=bus && isfield(truth,'V') && size(truth.V,1)>=bus
    vPred=abs(prediction.V(bus,mask)).';
    vTruth=interp1(double(truth.t(:)),abs(truth.V(bus,:)).',tPred,'linear');
    if all(isfinite(vPred)) && all(isfinite(vTruth))
        e=vPred-vTruth;
        summary.KeyVoltageRMSE=sqrt(mean(e.^2));
        summary.KeyVoltageMAE=mean(abs(e));
        summary.KeyVoltageMeanError=mean(e);
    end
end
end

function mask=tracking_mask(t,windows)
mask=false(numel(t),1);
for i=1:size(windows,1)
    a=windows(i,1); b=windows(i,2);
    if i<size(windows,1)
        mask = mask | (t>=a-1e-12 & t<b-1e-12);
    else
        mask = mask | (t>=a-1e-12 & t<=b+1e-12);
    end
end
end

function bus=tracking_voltage_bus(c,truth,cfg)
bus=NaN;
if isfield(cfg.online,'tracking') && isfield(cfg.online.tracking,'keyVoltageBus') && ...
        ~isempty(cfg.online.tracking.keyVoltageBus) && ...
        isfinite(cfg.online.tracking.keyVoltageBus)
    bus=double(cfg.online.tracking.keyVoltageBus);
    return;
end

if ~isfield(truth,'metadata') || ~isfield(truth.metadata,'caseData') || ...
        ~isfield(truth.metadata.caseData,'drift')
    return;
end
D=truth.metadata.caseData.drift;
if ~isfield(D,'deviceType') || ~isfield(D,'device') || isempty(D.device)
    return;
end
type=lower(char(string(D.deviceType)));
dev=double(D.device(1));
if isfield(c,type) && dev>=1 && dev<=numel(c.(type)) && isfield(c.(type)(dev),'bus')
    bus=double(c.(type)(dev).bus);
end
end

function [summary,perVariable]=failed_metrics_local(varNames)
n=numel(varNames); z=nan(n,1);
summary=struct('RMSE',NaN,'MAE',NaN,'MaxAE',NaN,'NMaxAE_Range',NaN, ...
    'MAPE_percent',NaN,'sMAPE_percent',NaN,'MAPE_valid_fraction',NaN,'MeanR2',NaN);
perVariable=table(string(varNames(:)),z,z,z,z,z,z,z,z, ...
    'VariableNames',{'Variable','RMSE','MAE','MaxAE','NMaxAE_Range', ...
    'MAPE_percent','sMAPE_percent','MAPE_valid_fraction','R2'});
end
