function figPath = plot_llm_prior_level_ablation(allRunsTbl,outRoot,varargin)
%PLOT_LLM_PRIOR_LEVEL_ABLATION Two panels: accuracy and active coefficients.
% Five-bar layout when an independent non-LLM control is present:
%   Lv.0 | Lv.1 | Lv.2 | Lv.3 | C+E (gray, independent)
% C+E is NEVER part of the LLM-level trend line or uncertainty estimate.
% The input should contain the original official per-run data + at most one
% separately computed C+E row at the same fixed data seed. No model training.

p=inputParser;
p.addParameter('CaseName','',@(x)ischar(x)||isstring(x));
p.addParameter('FixedDataSeed',[],@(x)isempty(x)||(isnumeric(x)&&isscalar(x)));
p.parse(varargin{:});
opt=p.Results;
T=allRunsTbl;
if isempty(T), error('plot_prior_ablation:EmptyTable','Input table is empty.'); end
T=normalize_names_local(T);
v=lower(string(T.(pick_var_local(T,{'variant','level'}))));
r=double(T.(pick_var_local(T,{'rmse','rolloutrmse'})));
a=double(T.(pick_var_local(T,{'activecoefficientcount','activecount','active'})));
s=double(T.(pick_var_local(T,{'dataseed','seed'})));

levels=["none","coordinate_only","llm_direct","llm_full"];
if isempty(opt.FixedDataSeed)
    candidates=sort(unique(s(isfinite(s))));
    if isempty(candidates), error('plot_prior_ablation:Seed','No data seeds.'); end
    fixedSeed=candidates(1);
    best=inf;
    for seed=candidates(:).'
        ix=v==levels(1) & s==seed & isfinite(r) & r>0;
        if any(ix)
            score=min(r(ix));
            if score<best, best=score; fixedSeed=seed; end
        end
    end
else
    fixedSeed=double(opt.FixedDataSeed);
end

hasControl=any(v=="coordexp" & s==fixedSeed);
if hasControl
    cats=[levels,"coordexp"];
    labels={'Lv.0','Lv.1','Lv.2','Lv.3','C+E'};
    originalX=1:4;
    nBars=5;
else
    cats=levels;
    labels={'Lv.0','Lv.1','Lv.2','Lv.3'};
    originalX=1:4;
    nBars=4;
end

accMean=nan(1,nBars); accStd=zeros(1,nBars);
activeMean=nan(1,nBars); activeStd=zeros(1,nBars);
for k=1:nBars
    ix=v==cats(k) & s==fixedSeed;
    if ~any(ix)
        error('plot_prior_ablation:MissingLevel', ...
            'No %s result at fixed seed %d.',cats(k),fixedSeed);
    end
    if cats(k)=="coordexp" && nnz(ix)~=1
        error('plot_prior_ablation:ControlMultiplicity', ...
            'C+E must have exactly one deterministic record.');
    end
    rv=r(ix); av=a(ix);
    good=isfinite(rv) & rv>0;
    rv=rv(good);
    if ~isempty(rv)
        if any(cats(k)==levels(3:4))
            z=-log10(rv);
            accMean(k)=mean(z);
            if numel(z)>1, accStd(k)=std(z,0); end
        else
            accMean(k)=-log10(rv(1));
        end
    end
    av=av(isfinite(av));
    if ~isempty(av)
        if any(cats(k)==levels(3:4))
            activeMean(k)=mean(av);
            if numel(av)>1, activeStd(k)=std(av,0); end
        else
            activeMean(k)=av(1);
        end
    end
end

blue=[0.00 0.4470 0.7410];
gray=[0.62 0.62 0.62];
err=[0.8500 0.3250 0.0980];
trend=[0.26 0.26 0.26];
colors=repmat(blue,nBars,1);
if hasControl, colors(5,:)=gray; end

if ~isfolder(outRoot), mkdir(outRoot); end
fig=figure('Visible','off','Color','w','Units','inches','Position',[1 1 7.0 2.65]);
tl=tiledlayout(fig,1,2,'Padding','compact','TileSpacing','compact');

% (a) -log10(RMSE), preserving the paper's mean-of-transformed-runs
% convention and unbiased sample std across the five LLM discoveries.
ax1=nexttile(tl,1);
show_bars_local(ax1,accMean,colors);
hold(ax1,'on');
show_trend_local(ax1,originalX,accMean(originalX),trend);
errX=originalX(3:4);
errorbar(ax1,errX,accMean(errX),accStd(errX), ...
    'LineStyle','none','Color',err,'LineWidth',1.5,'CapSize',8);
if hasControl && ~isfinite(accMean(5))
    % An unsuccessful C+E rollout has undefined RMSE. Mark as failed;
    % never fabricate a log-RMSE bar height.
    yy=accMean(isfinite(accMean));
    if ~isempty(yy), text(ax1,5,min(yy),'FAIL', ...
        'HorizontalAlignment','center','VerticalAlignment','bottom', ...
        'FontSize',9,'Color',gray); end
end
set_axes_local(ax1,labels,nBars);
ylabel(ax1,'-log_{10}(RMSE)','FontName','Times New Roman','FontSize',11);
good=isfinite(accMean);
if any(good)
    low=max(0,min(accMean(good)-accStd(good))-0.35);
    high=max(accMean(good)+accStd(good))+0.35;
    if high>low, ylim(ax1,[low high]); end
end
hold(ax1,'off');

% (b) sparsity, again the single gray C+E bar has NO discovery-error bar.
ax2=nexttile(tl,2);
show_bars_local(ax2,activeMean,colors);
hold(ax2,'on');
show_trend_local(ax2,originalX,activeMean(originalX),trend);
errorbar(ax2,errX,activeMean(errX),activeStd(errX), ...
    'LineStyle','none','Color',err,'LineWidth',1.5,'CapSize',8);
set_axes_local(ax2,labels,nBars);
ylabel(ax2,'Active coefficients','FontName','Times New Roman','FontSize',11);
valid=isfinite(activeMean);
if any(valid)
    ymax=max(activeMean(valid)+activeStd(valid));
    if ymax>0, ylim(ax2,[0 ymax*1.12]); end
end
hold(ax2,'off');

figPath=fullfile(outRoot,'llm_prior_level_ablation.pdf');
png=fullfile(outRoot,'llm_prior_level_ablation_preview.png');
exportgraphics(fig,figPath,'ContentType','vector','BackgroundColor','white');
exportgraphics(fig,png,'Resolution',300,'BackgroundColor','white');
close(fig);
end

function show_bars_local(ax,vals,colors)
b=bar(ax,1:numel(vals),vals,0.68, ...
    'FaceColor','flat','EdgeColor',[0.12 0.12 0.12],'LineWidth',0.8);
b.CData=colors;
end

function show_trend_local(ax,x,y,c)
% Connect only the original cumulative Lv.0--Lv.3 sequence.
% The gray C+E bar, when present, is plotted separately at x=5.
style={'Color',c,'LineWidth',1.6,'MarkerSize',6, ...
    'MarkerFaceColor','w','MarkerEdgeColor',c};
ok=isfinite(y);
if any(ok), plot(ax,x(ok),y(ok),'--d',style{:}); end
end

function set_axes_local(ax,labels,nBars)
set(ax,'Box','on','FontName','Times New Roman', ...
    'FontSize',10,'LineWidth',1.0);
xticks(ax,1:nBars);
xticklabels(ax,labels);
xlim(ax,[0.45 nBars+0.55]);
ax.XAxis.FontSize=10;
ax.YAxis.FontSize=10;
grid(ax,'on'); ax.GridAlpha=0.17;
end

function T=normalize_names_local(T)
T.Properties.VariableNames=cellstr(lower(regexprep( ...
    string(T.Properties.VariableNames),'[^A-Za-z0-9]','')));
end
function v=pick_var_local(T,candidates)
for i=1:numel(candidates)
    if ismember(candidates{i},T.Properties.VariableNames)
        v=candidates{i}; return;
    end
end
error('plot_prior_ablation:MissingColumn', ...
    'Expected one of %s.',strjoin(candidates,', '));
end
