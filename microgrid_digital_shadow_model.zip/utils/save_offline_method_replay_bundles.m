function bundlePaths = save_offline_method_replay_bundles(report,c,layout,evaluationCache,cfg,outRoot)
%SAVE_OFFLINE_METHOD_REPLAY_BUNDLES Save independent per-method replay bundles.
%
% NON-DESTRUCTIVE INCREMENTAL RULE
% --------------------------------
% If a method already has a replay bundle, this function loads it first and
% merges the current run into it by section and condition. A condition that is
% re-run replaces the old condition. Any condition/section omitted from the
% current run is preserved.
%
% This prevents a NODE/Weak-PN-only Section 1.1/1.2 run from deleting the
% previously saved M-KBF/V/PE/PN clean sample-sweep results.
%
% Existing call sites do not need to change.

bundlePaths = strings(0,1);

if nargin < 6 || isempty(outRoot)
    error('save_offline_method_replay_bundles:MissingOutputRoot', ...
        'outRoot is required.');
end

if isfield(cfg,'output') && isfield(cfg.output,'saveMethodBundles') && ...
        ~logical(cfg.output.saveMethodBundles)
    return;
end

methodResultsFolder = 'method_results';
bundleFileName = 'offline_part1_method_replay.mat';
if isfield(cfg,'output') && isfield(cfg.output,'methodResultsFolder') && ...
        ~isempty(cfg.output.methodResultsFolder)
    methodResultsFolder = char(string(cfg.output.methodResultsFolder));
end
if isfield(cfg,'output') && isfield(cfg.output,'methodReplayFileName') && ...
        ~isempty(cfg.output.methodReplayFileName)
    bundleFileName = char(string(cfg.output.methodReplayFileName));
end

rootDir = fullfile(outRoot,methodResultsFolder);
if exist(rootDir,'dir') ~= 7, mkdir(rootDir); end

methodNames = collect_present_methods(report,evaluationCache);
for i = 1:numel(methodNames)
    methodName = char(methodNames(i));
    if isempty(methodName), continue; end

    [methodReport,displayName] = filter_report_for_method(report,methodName);
    methodCache = filter_cache_for_method(evaluationCache,methodName);

    % Long NODE campaigns keep compact evaluations in RAM after each verified
    % per-condition checkpoint. Rehydrate only here, immediately before the
    % persistent method bundle is assembled, so replay/online loading still
    % receives the complete trained model and trajectory payload.
    methodCache = rehydrate_cache_for_persistence(methodCache);
    methodReport = rehydrate_report_from_cache(methodReport,methodCache,methodName);
    methodCache = strip_runtime_cache_fields(methodCache);

    % If this method is not actually represented in the current run, do not
    % touch its existing replay bundle.
    if report_has_no_method_data(methodReport) && cache_is_empty(methodCache)
        continue;
    end

    methodDir = fullfile(rootDir,methodName);
    if exist(methodDir,'dir') ~= 7, mkdir(methodDir); end
    bundlePath = fullfile(methodDir,bundleFileName);

    newBundle = struct();
    newBundle.schemaVersion = 'independent_method_bundle_v2';
    newBundle.methodName = methodName;
    newBundle.displayName = char(displayName);
    newBundle.caseSnapshot = c;
    newBundle.layout = layout;
    newBundle.config = cfg;
    newBundle.report = methodReport;
    newBundle.evaluationCache = methodCache;
    newBundle.savedAt = char(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));

    if exist(bundlePath,'file') == 2
        old = load_method_bundle_safe(bundlePath);
        if isfield(old,'methodBundle') && isstruct(old.methodBundle)
            if strcmp(methodName,'physics_neural_compositional_sindy') && ...
                    pnc_architecture_changed_local(old.methodBundle,newBundle)
                warning('save_offline_method_replay_bundles:PNCArchitectureChanged', ...
                    ['Existing PNC bundle uses an older architecture and will not be ', ...
                     'section-merged with PNC v2. The current-run PNC bundle replaces it: %s'], ...
                    bundlePath);
                methodBundle = newBundle;
            else
                methodBundle = merge_offline_method_bundle_sections( ...
                    old.methodBundle,newBundle);
            end
        else
            warning('save_offline_method_replay_bundles:InvalidOldBundle', ...
                ['Existing bundle does not contain methodBundle and will be ', ...
                 'replaced: %s'],bundlePath);
            methodBundle = newBundle;
        end
    else
        methodBundle = newBundle;
    end

    save_method_bundle_atomic(bundlePath,methodBundle);
    bundlePaths(end+1,1) = string(bundlePath); %#ok<AGROW>
end
end


function tf = pnc_architecture_changed_local(oldBundle,newBundle)
%PNC_ARCHITECTURE_CHANGED_LOCAL Prevent v1/v2 section mixtures in one bundle.
tf = false;
try
    oldCfg = oldBundle.config;
    newCfg = newBundle.config;
    oldHasSkip = isfield(oldCfg,'sindy') && ...
        isfield(oldCfg.sindy,'physicsNeuralCompositional') && ...
        isfield(oldCfg.sindy.physicsNeuralCompositional,'includeFlatPNSkipCandidate') && ...
        logical(oldCfg.sindy.physicsNeuralCompositional.includeFlatPNSkipCandidate);
    newHasSkip = isfield(newCfg,'sindy') && ...
        isfield(newCfg.sindy,'physicsNeuralCompositional') && ...
        isfield(newCfg.sindy.physicsNeuralCompositional,'includeFlatPNSkipCandidate') && ...
        logical(newCfg.sindy.physicsNeuralCompositional.includeFlatPNSkipCandidate);
    if newHasSkip && ~oldHasSkip
        tf = true;
        return;
    end
    oldOffset = NaN; newOffset = NaN;
    if oldHasSkip && isfield(oldCfg.sindy.physicsNeuralCompositional,'compositionalSeedOffset')
        oldOffset = double(oldCfg.sindy.physicsNeuralCompositional.compositionalSeedOffset);
    end
    if newHasSkip && isfield(newCfg.sindy.physicsNeuralCompositional,'compositionalSeedOffset')
        newOffset = double(newCfg.sindy.physicsNeuralCompositional.compositionalSeedOffset);
    end
    if newHasSkip && (~isfinite(oldOffset) || oldOffset~=newOffset)
        tf = true;
    end
catch
    % Correctness-first: if a legacy PNC bundle cannot expose its architecture,
    % do not merge it into the new skip/compositional protocol.
    tf = true;
end
end


function names = collect_present_methods(report,evaluationCache)
names = strings(0,1);
sections = {'section1p1','section1p2','section1p3'};
for isec = 1:numel(sections)
    s = sections{isec};
    if ~isfield(report,s), continue; end
    sec = report.(s);
    if isfield(sec,'evaluations') && iscell(sec.evaluations)
        E = sec.evaluations;
        for i = 1:numel(E)
            n = evaluation_method_name(E{i});
            if strlength(n)>0 && ~any(names==n), names(end+1,1)=n; end %#ok<AGROW>
        end
    end
    if isfield(sec,'table') && istable(sec.table) && ...
            ismember('Method',sec.table.Properties.VariableNames)
        q = string(sec.table.Method);
        for i = 1:numel(q)
            if strlength(q(i))>0 && ~any(names==q(i))
                names(end+1,1)=q(i); %#ok<AGROW>
            end
        end
    end
end

if isstruct(evaluationCache) && isfield(evaluationCache,'entries')
    E = evaluationCache.entries;
    for i = 1:numel(E)
        if isfield(E(i),'methodName') && ~isempty(E(i).methodName)
            q = string(E(i).methodName);
            if strlength(q)>0 && ~any(names==q), names(end+1,1)=q; end %#ok<AGROW>
        end
    end
end
end


function [R,displayName] = filter_report_for_method(report,methodName)
R = report;
displayName = string(methodName);

sections = {'section1p1','section1p2','section1p3'};
for isec = 1:numel(sections)
    s = sections{isec};
    if ~isfield(report,s)
        R.(s) = struct();
        continue;
    end
    [R.(s),displayName] = filter_section(report.(s),methodName,displayName);
end

R.methods = string(methodName);

if isfield(R,'reuseSummary') && isstruct(R.reuseSummary) && ...
        isfield(R.reuseSummary,'table') && istable(R.reuseSummary.table)
    T = R.reuseSummary.table;
    keep = true(height(T),1);
    if ismember('Method',T.Properties.VariableNames)
        q = string(T.Method);
        keep = (q==string(methodName)) | (q==displayName);
    end
    R.reuseSummary.table = T(keep,:);
end
end


function [secOut,displayName] = filter_section(sec,methodName,displayName)
secOut = sec;
T = table();
E = cell(0,1);
if isfield(sec,'table') && istable(sec.table), T = sec.table; end
if isfield(sec,'evaluations') && iscell(sec.evaluations), E = sec.evaluations(:); end

if ~isempty(T) && numel(E)==height(T)
    keep = false(height(T),1);
    for i = 1:height(T)
        q = evaluation_method_name(E{i});
        if strlength(q)==0 && ismember('Method',T.Properties.VariableNames)
            q = string(T.Method(i));
        end
        keep(i) = (q==string(methodName));
        if keep(i)
            d = evaluation_display_name(E{i});
            if strlength(d)>0, displayName=d; end
        end
    end
    secOut.table = T(keep,:);
    secOut.evaluations = E(keep);
    return;
end

if ~isempty(T)
    if ismember('Method',T.Properties.VariableNames)
        keepT = string(T.Method)==string(methodName);
        secOut.table = T(keepT,:);
    else
        secOut.table = table();
    end
else
    secOut.table = table();
end

if ~isempty(E)
    keepE = false(numel(E),1);
    for i = 1:numel(E)
        q = evaluation_method_name(E{i});
        keepE(i) = (q==string(methodName));
        if keepE(i)
            d = evaluation_display_name(E{i});
            if strlength(d)>0, displayName=d; end
        end
    end
    secOut.evaluations = E(keepE);
else
    secOut.evaluations = cell(0,1);
end
end


function cacheOut = filter_cache_for_method(cacheIn,methodName)
cacheOut = cacheIn;
if ~(isstruct(cacheIn) && isfield(cacheIn,'entries'))
    return;
end
E = cacheIn.entries;
keep = false(size(E));
for i = 1:numel(E)
    if isfield(E(i),'methodName') && ~isempty(E(i).methodName)
        keep(i) = strcmp(char(string(E(i).methodName)),methodName);
    end
end
cacheOut.entries = E(keep);
end


function cacheOut = rehydrate_cache_for_persistence(cacheIn)
%REHYDRATE_CACHE_FOR_PERSISTENCE Restore compact RAM entries from checkpoints.
cacheOut = cacheIn;
if ~(isstruct(cacheOut) && isfield(cacheOut,'entries') && ~isempty(cacheOut.entries))
    return;
end
for i = 1:numel(cacheOut.entries)
    e = cacheOut.entries(i);
    isCompact = isfield(e,'evaluationIsCompact') && ~isempty(e.evaluationIsCompact) && ...
        logical(e.evaluationIsCompact);
    if ~isCompact && isfield(e,'evaluation') && isstruct(e.evaluation) && ...
            isfield(e.evaluation,'memoryCompacted') && ...
            logical(e.evaluation.memoryCompacted)
        isCompact = true;
    end
    if ~isCompact
        continue;
    end
    if ~isfield(e,'checkpointPath') || isempty(e.checkpointPath) || ...
            exist(char(string(e.checkpointPath)),'file') ~= 2
        error('save_offline_method_replay_bundles:CompactCheckpointMissing', ...
            ['A compact in-memory evaluation cannot be persisted because its ', ...
             'full checkpoint is missing:\n  %s'],char(string(e.checkpointPath)));
    end
    S = load_mat_long_path_safe(char(string(e.checkpointPath)),'savedEvaluation');
    if ~isfield(S,'savedEvaluation') || ~isstruct(S.savedEvaluation)
        error('save_offline_method_replay_bundles:CompactCheckpointInvalid', ...
            'Checkpoint does not contain savedEvaluation:\n  %s', ...
            char(string(e.checkpointPath)));
    end
    cacheOut.entries(i).evaluation = S.savedEvaluation;
    if isfield(cacheOut.entries,'evaluationIsCompact')
        cacheOut.entries(i).evaluationIsCompact = false;
    end
end
end


function R = rehydrate_report_from_cache(R,cache,methodName)
%REHYDRATE_REPORT_FROM_CACHE Replace compact report cells with full checkpoints.
if ~(isstruct(cache) && isfield(cache,'entries') && ~isempty(cache.entries))
    return;
end
sections = {'section1p1','section1p2','section1p3'};
for isec = 1:numel(sections)
    s = sections{isec};
    if ~isfield(R,s) || ~isstruct(R.(s)), continue; end
    sec = R.(s);
    if ~isfield(sec,'evaluations') || ~iscell(sec.evaluations) || ...
            ~isfield(sec,'table') || ~istable(sec.table) || ...
            numel(sec.evaluations) ~= height(sec.table)
        continue;
    end
    E = sec.evaluations(:);
    T = sec.table;
    for j = 1:numel(E)
        if ~is_compact_evaluation(E{j}), continue; end
        N = table_numeric_local(T(j,:),'SampleCount',NaN);
        if ismember('NoiseLevel',T.Properties.VariableNames)
            noise = table_numeric_local(T(j,:),'NoiseLevel',NaN);
        else
            noise = table_numeric_local(T(j,:),'NoisePercent',NaN)/100;
        end
        idx = find_cache_condition(cache,methodName,N,noise);
        if isempty(idx)
            error('save_offline_method_replay_bundles:CompactReportCacheMissing', ...
                ['Could not rehydrate compact %s report evaluation for ', ...
                 'N=%.15g, noise=%.17g.'],methodName,N,noise);
        end
        E{j} = cache.entries(idx).evaluation;
    end
    sec.evaluations = E;
    R.(s) = sec;
end
end


function tf = is_compact_evaluation(ev)
tf = isstruct(ev) && isfield(ev,'memoryCompacted') && ...
    ~isempty(ev.memoryCompacted) && logical(ev.memoryCompacted);
end


function idx = find_cache_condition(cache,methodName,N,noise)
idx = [];
for i = 1:numel(cache.entries)
    e = cache.entries(i);
    sameMethod = isfield(e,'methodName') && ...
        strcmp(char(string(e.methodName)),char(string(methodName)));
    sameN = isfield(e,'sampleCount') && ...
        abs(double(e.sampleCount)-double(N)) <= 1e-12;
    sameNoise = isfield(e,'noiseLevel') && ...
        abs(double(e.noiseLevel)-double(noise)) <= ...
        max(1e-14,1e-10*max(1,abs(double(noise))));
    if sameMethod && sameN && sameNoise
        idx = i;
        return;
    end
end
end


function x = table_numeric_local(row,name,defaultVal)
x = defaultVal;
if ismember(name,row.Properties.VariableNames)
    try
        q = double(row.(name)(1));
        if isscalar(q), x = q; end
    catch
    end
end
end


function cacheOut = strip_runtime_cache_fields(cacheIn)
%STRIP_RUNTIME_CACHE_FIELDS Keep replay bundles portable across machines.
cacheOut = cacheIn;
if ~(isstruct(cacheOut) && isfield(cacheOut,'entries') && ~isempty(cacheOut.entries))
    return;
end
runtimeFields = {'checkpointPath','evaluationStoredOnDisk','evaluationIsCompact'};
for k = 1:numel(runtimeFields)
    if isfield(cacheOut.entries,runtimeFields{k})
        cacheOut.entries = rmfield(cacheOut.entries,runtimeFields{k});
    end
end
end


function tf = report_has_no_method_data(R)
tf = true;
sections = {'section1p1','section1p2','section1p3'};
for i = 1:numel(sections)
    s = sections{i};
    if ~isfield(R,s), continue; end
    sec = R.(s);
    if isfield(sec,'table') && istable(sec.table) && height(sec.table)>0
        tf = false; return;
    end
    if isfield(sec,'evaluations') && iscell(sec.evaluations) && ...
            any(~cellfun(@isempty,sec.evaluations))
        tf = false; return;
    end
end
end


function tf = cache_is_empty(C)
tf = ~(isstruct(C) && isfield(C,'entries') && ~isempty(C.entries));
end


function name = evaluation_method_name(ev)
name = "";
if ~isstruct(ev) || ~isfield(ev,'method') || ~isstruct(ev.method), return; end
if isfield(ev.method,'name') && ~isempty(ev.method.name)
    name = string(ev.method.name);
end
end


function name = evaluation_display_name(ev)
name = "";
if ~isstruct(ev) || ~isfield(ev,'method') || ~isstruct(ev.method), return; end
if isfield(ev.method,'displayName') && ~isempty(ev.method.displayName)
    name = string(ev.method.displayName);
end
end


function S = load_method_bundle_safe(bundlePath)
try
    S = load(bundlePath,'methodBundle');
    return;
catch firstError
end

tmpDir = tempname;
mkdir(tmpDir);
cleanupObj = onCleanup(@()cleanup_temp_dir(tmpDir));
tmpFile = fullfile(tmpDir,'bundle.mat');
[ok,msg] = copyfile(bundlePath,tmpFile,'f');
if ~ok
    error('save_offline_method_replay_bundles:CopyOldBundleFailed', ...
        'Could not copy existing bundle to a short temporary path: %s',msg);
end
try
    S = load(tmpFile,'methodBundle');
catch
    rethrow(firstError);
end
clear cleanupObj;
cleanup_temp_dir(tmpDir);
end


function save_method_bundle_atomic(bundlePath,methodBundle)
%SAVE_METHOD_BUNDLE_ATOMIC Long-path-safe verified replacement on Windows.
%
% MATLAB v7.3/HDF5 LOAD/WHOS can fail on a valid MAT file solely because the
% pathname is long. File-system COPY operations still work in the affected
% project paths. Therefore no HDF5 operation is ever performed on the long
% destination pathname:
%   1) save + verify the new bundle on a short temporary path;
%   2) back up any previous official bundle to a short path and verify it;
%   3) copy the verified new bytes to the official destination;
%   4) copy the installed official bytes back to a short path and verify them;
%   5) restore the verified old bundle if installation/verification fails.
%
% This intentionally avoids destination-side staging files. In sufficiently
% deep test/output trees, even a filename as short as '_n.mat' can still make
% the complete pathname exceed the legacy Windows/HDF5 limit.

methodDir = fileparts(bundlePath);
if exist(methodDir,'dir') ~= 7, mkdir(methodDir); end

tmpDir = tempname;
mkdir(tmpDir);
cleanupObj = onCleanup(@()cleanup_temp_dir(tmpDir));

newShort = fullfile(tmpDir,'new.mat');
oldShort = fullfile(tmpDir,'old.mat');
verifyShort = fullfile(tmpDir,'verify.mat');

% Build and validate only on a genuinely short pathname.
save(newShort,'methodBundle','-v7.3');
verify_mat_short_path(newShort);

hadOld = (exist(bundlePath,'file') == 2);
if hadOld
    [ok,msg] = copyfile(bundlePath,oldShort,'f');
    if ~ok
        error('save_offline_method_replay_bundles:BackupOldFailed', ...
            'Could not back up existing replay bundle before replacement: %s',msg);
    end
    verify_mat_short_path(oldShort);
end

try
    % Install the already verified bytes. Do not LOAD/WHOS bundlePath here.
    [ok,msg] = copyfile(newShort,bundlePath,'f');
    if ~ok
        error('save_offline_method_replay_bundles:ReplaceFailed', ...
            'Could not install replay bundle at the official pathname: %s',msg);
    end

    % Verify the installed long-path file only through a short-path copy.
    if exist(verifyShort,'file') == 2, delete(verifyShort); end
    [ok,msg] = copyfile(bundlePath,verifyShort,'f');
    if ~ok
        error('save_offline_method_replay_bundles:VerifyCopyFailed', ...
            'Could not copy installed replay bundle to short verification path: %s',msg);
    end
    verify_mat_short_path(verifyShort);

catch ME
    % Best-effort rollback to the previous verified bundle.
    if hadOld
        try
            [okRestore,msgRestore] = copyfile(oldShort,bundlePath,'f');
            if ~okRestore
                warning('save_offline_method_replay_bundles:RollbackFailed', ...
                    'Replacement failed and rollback also failed: %s',msgRestore);
            end
        catch MERestore
            warning('save_offline_method_replay_bundles:RollbackFailed', ...
                'Replacement failed and rollback raised: %s',MERestore.message);
        end
    else
        % No previous official bundle existed. Remove an unverified partial
        % destination when possible so it cannot be mistaken for a valid run.
        try
            if exist(bundlePath,'file') == 2, delete(bundlePath); end
        catch
        end
    end
    rethrow(ME);
end

clear cleanupObj;
cleanup_temp_dir(tmpDir);
end


function verify_mat_short_path(filePath)
%VERIFY_MAT_SHORT_PATH Validate that the staged MAT contains methodBundle.
info = whos('-file',filePath);
names = string({info.name});
if ~any(names == "methodBundle")
    error('save_offline_method_replay_bundles:InvalidStagedBundle', ...
        'MAT-file does not contain methodBundle: %s',filePath);
end
S = load(filePath,'methodBundle');
if ~isfield(S,'methodBundle') || ~isstruct(S.methodBundle)
    error('save_offline_method_replay_bundles:InvalidStagedBundle', ...
        'Saved methodBundle is missing or invalid: %s',filePath);
end
end

function cleanup_temp_dir(d)
if exist(d,'dir')==7
    try
        rmdir(d,'s');
    catch
    end
end
end
