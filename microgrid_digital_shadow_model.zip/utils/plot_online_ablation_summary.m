function plot_online_ablation_summary(evaluations,cfg,outDir)
%PLOT_ONLINE_ABLATION_SUMMARY Standalone four-variant RMSE summary.

if isempty(evaluations), return; end
if ~iscell(evaluations), evaluations=num2cell(evaluations); end

modes=["frozen_no_sync","frozen_sync","adapted_no_sync","adapted_sync"];
labels={'F','F+S','A','A+S'};
colors=[ ...
    0.0000 0.4470 0.7410; ...
    0.3010 0.7450 0.9330; ...
    0.8500 0.3250 0.0980; ...
    0.8500 0.0500 0.0500];
whole=nan(1,4);
track=nan(1,4);
for j=1:4
    ev=find_eval_by_mode(evaluations,modes(j));
    if isempty(ev), continue; end
    if isfield(ev,'metrics') && isstruct(ev.metrics) && ...
            isfield(ev.metrics,'RMSE') && isfinite(ev.metrics.RMSE)
        whole(j)=double(ev.metrics.RMSE);
    end
    if isfield(ev,'trackingMetrics') && isstruct(ev.trackingMetrics) && ...
            isfield(ev.trackingMetrics,'RMSE') && isfinite(ev.trackingMetrics.RMSE)
        track(j)=double(ev.trackingMetrics.RMSE);
    elseif isfinite(whole(j))
        track(j)=whole(j);
    end
end
if all(~isfinite(whole)) && all(~isfinite(track)), return; end

fig=figure('Name','Online four-variant ablation summary','Color','w', ...
    'Visible',cfg.figures.visible,'Units','pixels','Position',[120 80 760 520]);
tl=tiledlayout(2,1,'TileSpacing','compact','Padding','compact'); %#ok<NASGU>

ax1=nexttile; hold(ax1,'on');
for j=1:4
    if isfinite(whole(j))
        bar(ax1,j,whole(j),0.72,'FaceColor',colors(j,:), ...
            'EdgeColor',[0.15 0.15 0.15],'LineWidth',0.9);
    end
end
set(ax1,'XTick',1:4,'XTickLabel',labels);
ylabel(ax1,'Whole-window RMSE');
grid(ax1,'on');
if any(isfinite(whole))
    ymax=max(whole(isfinite(whole))); if ymax>0, ylim(ax1,[0 1.15*ymax]); end
end

ax2=nexttile; hold(ax2,'on');
for j=1:4
    if isfinite(track(j))
        bar(ax2,j,track(j),0.72,'FaceColor',colors(j,:), ...
            'EdgeColor',[0.15 0.15 0.15],'LineWidth',0.9);
    end
end
set(ax2,'XTick',1:4,'XTickLabel',labels);
ylabel(ax2,'Tracking-window RMSE');
xlabel(ax2,'Deployment variant');
grid(ax2,'on');
if any(isfinite(track))
    ymax=max(track(isfinite(track))); if ymax>0, ylim(ax2,[0 1.15*ymax]); end
end

export_offline_figure(fig,outDir,'online_ablation_rmse',cfg);
end

function ev=find_eval_by_mode(evaluations,mode)
ev=[];
for i=1:numel(evaluations)
    e=evaluations{i};
    if ~isstruct(e) || ~isfield(e,'mode'), continue; end
    if strcmpi(string(e.mode),mode)
        ev=e;
        return;
    end
end
end
