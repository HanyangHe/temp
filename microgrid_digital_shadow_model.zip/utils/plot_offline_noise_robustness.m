function plot_offline_noise_robustness(T,cfg,outDir)
%PLOT_OFFLINE_NOISE_ROBUSTNESS State-measurement noise vs trajectory errors.
%
% Successful conditions are shown normally. Failed rollouts break the line and
% are marked by method-colored x symbols in a logarithmic headroom band, using
% the same visual convention as the sample-sensitivity figure.

methodNames = unique(T.DisplayName,'stable');
legendNames = arrayfun(@method_legend_abbrev,methodNames,'UniformOutput',false);

fig = figure('Name','', ...
    'Color','w','Visible',cfg.figures.visible);
tl = tiledlayout(1,2,'TileSpacing','compact','Padding','loose');
% IEEE figure caption is supplied in LaTeX: no plot title or shared x-axis label.

metrics = {'RMSE','MaxAE'};
ylabels = {'RMSE','Maximum absolute error'};

for im = 1:numel(metrics)
    ax = nexttile(tl);
    hold(ax,'on');
    failX = cell(numel(methodNames),1);
    lineColor = cell(numel(methodNames),1);

    for k = 1:numel(methodNames)
        idx = T.DisplayName == methodNames(k);
        [x,ord] = sort(double(T.NoisePercent(idx)));
        vals = double(T.(metrics{im})(idx)); vals = vals(ord);

        succeeded = true(size(x));
        if any(strcmp(T.Properties.VariableNames,'RolloutSucceeded'))
            q = T.RolloutSucceeded(idx);
            q = q(ord);
            succeeded = logical(q);
        end

        valid = isfinite(x) & isfinite(vals) & vals > 0 & succeeded;

        h = plot(ax,nan,nan,'-o', ...
            'LineWidth',1.4,'MarkerSize',5, ...
            'DisplayName',legendNames{k});
        color = h.Color;
        lineColor{k}=color;

        if any(valid)
            plot(ax,x(valid),vals(valid),'o', ...
                'LineStyle','none', ...
                'Color',color, ...
                'LineWidth',1.4, ...
                'MarkerSize',5, ...
                'HandleVisibility','off');
            connect_contiguous_success_local(ax,x,vals,valid,color);
        end
        failX{k}=x(isfinite(x) & ~succeeded);
    end

    % Keep clean (0%) data at x=0, but omit its crowded tick label.
    % Limit the plot to the five formal noise levels (0 through 5%).
    xlim(ax,[0 5]);
    xticks(ax,[0.1 0.5 1 5]);
    xticklabels(ax,{'0.1','0.5','1','5'});

    ax.XTickLabelRotation = 45;
    ax.FontName = 'Times New Roman';
    ylabel(ax,ylabels{im},'FontName','Times New Roman');
    grid(ax,'on');
    box(ax,'on');
    set(ax,'YScale','log');
    expand_log_limits_local(ax);
    mark_failures_log_local(ax,failX,lineColor);

    if im == 1
        if any(~cellfun(@isempty,failX))
            plot(ax,nan,nan,'x','LineWidth',1.5,'MarkerSize',8, ...
                'Color',[0.15 0.15 0.15],'DisplayName','failed rollout');
            nLegend=numel(methodNames)+1;
        else
            nLegend=numel(methodNames);
        end
        lgd = legend(ax,'Orientation','horizontal', ...
            'NumColumns',preferred_legend_columns(nLegend));
        lgd.Layout.Tile = 'north';
        lgd.Interpreter = 'none';
        lgd.Box = 'on';
        lgd.FontSize = max(7,lgd.FontSize-1);
        lgd.FontName = 'Times New Roman';
    end
end

export_offline_figure(fig,outDir,'section1p3_noise_robustness',cfg);
end


function connect_contiguous_success_local(ax,x,vals,valid,color)
idx = find(valid);
if numel(idx) < 2
    return;
end

runStart = 1;
for j = 2:(numel(idx)+1)
    breakRun = (j > numel(idx)) || idx(j) ~= idx(j-1)+1;
    if breakRun
        runIdx = idx(runStart:j-1);
        if numel(runIdx) >= 2
            plot(ax,x(runIdx),vals(runIdx),'-', ...
                'Color',color, ...
                'LineWidth',1.4, ...
                'HandleVisibility','off');
        end
        runStart = j;
    end
end
end


function mark_failures_log_local(ax,failX,lineColor)
failed=find(~cellfun(@isempty,failX));
if isempty(failed), return; end
expand_log_limits_local(ax);
yl=ylim(ax);
if any(~isfinite(yl))||any(yl<=0)||yl(2)<=yl(1), yl=[1e-12 1]; end
lo=log10(yl(1)); hi=log10(yl(2)); span=max(hi-lo,1);
extra=max(0.16*span,0.055*span*numel(failed)); newHi=hi+extra;
ylim(ax,[10^lo 10^newHi]);
if numel(failed)>1
    yExp=linspace(newHi-0.12*extra,hi+0.12*extra,numel(failed));
else
    yExp=newHi-0.30*extra;
end
for j=1:numel(failed)
    k=failed(j);
    plot(ax,failX{k},repmat(10^yExp(j),size(failX{k})),'x', ...
        'LineWidth',1.5,'MarkerSize',8,'Color',lineColor{k}, ...
        'HandleVisibility','off');
end
end


function expand_log_limits_local(ax)
yl=ylim(ax);
if any(~isfinite(yl))||any(yl<=0)||yl(2)<=yl(1), return; end
lo=log10(yl(1)); hi=log10(yl(2));
if hi-lo<1
    mid=0.5*(hi+lo);
    ylim(ax,[10^(mid-0.55) 10^(mid+0.55)]);
end
end


function ncol = preferred_legend_columns(nItems)
if nItems <= 4
    ncol = nItems;
elseif nItems <= 8
    ncol = ceil(nItems/2);
else
    ncol = 4;
end
end


function label = method_legend_abbrev(name)
switch lower(strtrim(string(name)))
    case lower("M-KBF"), label = "M-KBF";
    case lower("Vanilla SINDy"), label = "V-SINDy";
    case lower("ED-SINDy"), label = "ED-SINDy";
    case lower("LLM-Prior SINDy"), label = "LLM-Prior SINDy";
    case lower("Physics-embedded SINDy"), label = "PE-SINDy";
    case lower("PNC-SINDy"), label="PNC-SINDy";
    case lower("Physics-Neural SINDy"), label = "PN-SINDy";
    case {lower("Neural ODE"), lower("NODE")}, label = "NODE";
    case lower("Weak SINDy"), label = "Weak SINDy";
    otherwise, label = string(name);
end
end
