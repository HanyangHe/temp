function print_saved_offline_evaluation_detail(ev,row)
%PRINT_SAVED_OFFLINE_EVALUATION_DETAIL Replay saved training/rollout diagnostics.
%
% This reporter is intentionally read-only: it prints fields already stored
% inside one saved evaluation. It does NOT retrain a model, rebuild a dataset,
% or rerun the DAE rollout.

if nargin < 2 || isempty(row)
    row = table();
end
if isempty(ev)
    fprintf('  [saved evaluation is empty]\n');
    return;
end

methodName = saved_method_display_name(ev);
N = saved_row_numeric(row,'SampleCount',saved_train_sample_count(ev));
noisePercent = saved_row_numeric(row,'NoisePercent',NaN);
reused = saved_row_logical(row,'EvaluationReused',false);
sourceRequest = saved_row_string(row,'EvaluationSource',"");

if reused && strlength(sourceRequest) > 0
    fprintf('  Replaying saved evaluation: %s | N=%g | noise=%s%% | reused from %s\n', ...
        methodName,N,number_or_na(noisePercent),char(sourceRequest));
else
    fprintf('  Replaying saved evaluation: %s | N=%g | noise=%s%%\n', ...
        methodName,N,number_or_na(noisePercent));
end

if isfield(ev,'trainInfo') && isstruct(ev.trainInfo)
    info = ev.trainInfo;
    if isfield(info,'modules') && ~isempty(info.modules)
        modules = info.modules;
        for im = 1:numel(modules)
            print_saved_module(modules(im));
        end
    else
        print_saved_traininfo_fallback(info);
    end
    if isfield(info,'forcedTrainingTrajectoryIds') && ...
            ~isempty(info.forcedTrainingTrajectoryIds)
        fprintf('    Forced into saved training partition: trajectory ID(s) [%s]\n', ...
            strtrim(sprintf('%d ',info.forcedTrainingTrajectoryIds)));
    end
end

print_saved_rollout_status(ev);

trainSec = saved_row_numeric(row,'TrainingTimeSec',saved_field_numeric(ev,'trainingTimeSeconds',NaN));
rolloutSec = saved_row_numeric(row,'TrajectorySolveTimeSec',saved_rollout_solve_time(ev));
if isfinite(trainSec) || isfinite(rolloutSec)
    fprintf('  saved timing: training=%s s | rollout=%s s\n', ...
        number_or_na(trainSec),number_or_na(rolloutSec));
end
end

function print_saved_module(m)
dev = 'MODULE';
if isfield(m,'deviceType') && ~isempty(m.deviceType)
    dev = upper(char(string(m.deviceType)));
end
idx = 1;
if isfield(m,'deviceIndex') && ~isempty(m.deviceIndex), idx = m.deviceIndex; end
if isfield(m,'bus') && ~isempty(m.bus)
    fprintf('    Saved module %s%d (Bus %d):\n',dev,idx,m.bus);
else
    fprintf('    Saved module %s%d:\n',dev,idx);
end

% SINDy-family module report. These are the same saved quantities printed
% during the original fit: selected lambda, active/candidate coefficients,
% train/validation normalized MSE, plus neural/prior counts when applicable.
if isfield(m,'selectedThreshold')
    lib = saved_field_numeric(m,'libraryTermCount',NaN);
    lam = saved_field_numeric(m,'selectedThreshold',NaN);
    active = saved_field_numeric(m,'activeCoefficientCount',NaN);
    candidate = saved_field_numeric(m,'candidateCoefficientCount',NaN);
    tr = saved_field_numeric(m,'trainNormalizedMSE',NaN);
    va = saved_field_numeric(m,'validationNormalizedMSE',NaN);
    nNeu = saved_field_numeric(m,'neuralBasisFeatureCount',NaN);
    nPhys = saved_field_numeric(m,'physicsPriorFeatureCount',0);
    wPhys = saved_field_numeric(m,'physicsPriorFeatureWeight',1);
    aPhys = saved_field_numeric(m,'activePhysicsCoefficientCount',NaN);
    aGeneric = saved_field_numeric(m,'activeGenericCoefficientCount',NaN);
    fitMode = "";
    if isfield(m,'fitMode') && ~isempty(m.fitMode), fitMode = lower(string(m.fitMode)); end

    if isfinite(nNeu)
        if contains(fitMode,'prior') || (nPhys > 0 && wPhys > 1)
            fprintf(['      library=%s (neural=%s, phys=%s) | prior weight=%s | ', ...
                'lambda=%s | active=%s/%s'], ...
                number_or_na(lib),number_or_na(nNeu),number_or_na(nPhys), ...
                number_or_na(wPhys),number_or_na(lam),number_or_na(active), ...
                number_or_na(candidate));
            if isfinite(aPhys) && isfinite(aGeneric)
                fprintf(' (phys=%s, generic=%s)',number_or_na(aPhys),number_or_na(aGeneric));
            end
            fprintf(' | train nMSE=%s | val nMSE=%s\n',scientific_or_na(tr),scientific_or_na(va));
        else
            fprintf(['      library=%s (neural=%s) | lambda=%s | active=%s/%s | ', ...
                'train nMSE=%s | val nMSE=%s\n'], ...
                number_or_na(lib),number_or_na(nNeu),number_or_na(lam), ...
                number_or_na(active),number_or_na(candidate), ...
                scientific_or_na(tr),scientific_or_na(va));
        end
    elseif contains(fitMode,'prior') || (nPhys > 0 && wPhys > 1)
        fprintf(['      library=%s terms | prior weight=%s | lambda=%s | active=%s/%s'], ...
            number_or_na(lib),number_or_na(wPhys),number_or_na(lam), ...
            number_or_na(active),number_or_na(candidate));
        if isfinite(aPhys) && isfinite(aGeneric)
            fprintf(' (phys=%s, generic=%s)',number_or_na(aPhys),number_or_na(aGeneric));
        end
        fprintf(' | train nMSE=%s | val nMSE=%s\n',scientific_or_na(tr),scientific_or_na(va));
    else
        fprintf(['      library=%s terms | lambda=%s | active=%s/%s | ', ...
            'train nMSE=%s | val nMSE=%s\n'], ...
            number_or_na(lib),number_or_na(lam),number_or_na(active), ...
            number_or_na(candidate),scientific_or_na(tr),scientific_or_na(va));
    end
    return;
end

% Modular bilinear Koopman / M-KBF module report.
if isfield(m,'selectedRank') && isfield(m,'observableCount')
    lift = saved_field_numeric(m,'observableCount',NaN);
    force = saved_field_numeric(m,'forceCount',NaN);
    rank = saved_field_numeric(m,'selectedRank',NaN);
    rmax = saved_field_numeric(m,'maxCandidateRank',NaN);
    if isfield(m,'trainVectorFieldScaledMSE')
        tr = saved_field_numeric(m,'trainVectorFieldScaledMSE',NaN);
        va = saved_field_numeric(m,'validationVectorFieldScaledMSE',NaN);
        alpha = saved_field_numeric(m,'autonomousSpectralAbscissa',NaN);
        ridge = saved_field_numeric(m,'selectedRidgeRelative',NaN);
        if isfinite(ridge)
            if isfield(m,'validationTrajectoryMeanScaledMSE')
                vmean = saved_field_numeric(m,'validationTrajectoryMeanScaledMSE',va);
                vse = saved_field_numeric(m,'validationTrajectorySEScaledMSE',NaN);
                band = saved_field_numeric(m,'validationSelectionBand',NaN);
                edf = saved_field_numeric(m,'selectedEffectiveDegreesOfFreedom',NaN);
                amp = saved_field_numeric(m,'selectedNoiseAmplificationProxy',NaN);
                fprintf(['      CT M-KBF Eq.(16) lift=%s | forcing=%s | selected rank=%s/%s | ', ...
                    'ridge=%s | val VF mean=%s +/- SE %s | band=%s | effDF=%s | amp=%s | ', ...
                    'maxReEig(A)=%s 1/s\n'], ...
                    number_or_na(lift),number_or_na(force),number_or_na(rank),number_or_na(rmax), ...
                    scientific_or_na(ridge),scientific_or_na(vmean),scientific_or_na(vse), ...
                    scientific_or_na(band),number_or_na(edf),scientific_or_na(amp),number_or_na(alpha));
            else
                fprintf(['      CT M-KBF Eq.(16) lift=%s | forcing=%s | selected rank=%s/%s | ', ...
                    'ridge=%s | train VF sMSE=%s | val VF sMSE=%s | maxReEig(A)=%s 1/s\n'], ...
                    number_or_na(lift),number_or_na(force),number_or_na(rank),number_or_na(rmax), ...
                    scientific_or_na(ridge),scientific_or_na(tr),scientific_or_na(va),number_or_na(alpha));
            end
        else
            fprintf(['      CT M-KBF Eq.(16) lift=%s | forcing=%s | selected rank=%s/%s | ', ...
                'train VF sMSE=%s | val VF sMSE=%s | maxReEig(A)=%s 1/s\n'], ...
                number_or_na(lift),number_or_na(force),number_or_na(rank),number_or_na(rmax), ...
                scientific_or_na(tr),scientific_or_na(va),number_or_na(alpha));
        end
    else
        tr = saved_field_numeric(m,'trainNormalizedMSE',NaN);
        va = saved_field_numeric(m,'validationNormalizedMSE',NaN);
        rho = saved_field_numeric(m,'autonomousSpectralRadius',NaN);
        fprintf(['      legacy discrete M-KBF lift=%s | forcing=%s | selected rank=%s/%s | ', ...
            'train one-step nMSE=%s | val nMSE=%s | rho(Ad)=%s\n'], ...
            number_or_na(lift),number_or_na(force),number_or_na(rank),number_or_na(rmax), ...
            scientific_or_na(tr),scientific_or_na(va),number_or_na(rho));
    end
    return;
end

% Neural-ODE module report if that baseline is present in an older/newer
% replay bundle.
if isfield(m,'bestValidationTrajectoryMSE_normalized') || isfield(m,'parameterCount')
    restart = saved_field_numeric(m,'selectedRestart',NaN);
    valLoss = saved_field_numeric(m,'bestValidationTrajectoryMSE_normalized',NaN);
    nParam = saved_field_numeric(m,'parameterCount',NaN);
    fprintf('      selected restart=%s | parameters=%s | best val trajectory nMSE=%s\n', ...
        number_or_na(restart),number_or_na(nParam),scientific_or_na(valLoss));
    return;
end

fprintf('      saved module diagnostics are present, but no recognized compact reporter applies.\n');
end

function print_saved_traininfo_fallback(info)
if isfield(info,'activeCoefficientCount') && isfield(info,'candidateCoefficientCount')
    fprintf('    saved active coefficients: %g/%g\n', ...
        info.activeCoefficientCount,info.candidateCoefficientCount);
elseif isfield(info,'parameterCount')
    fprintf('    saved trainable parameter count: %g\n',info.parameterCount);
end
end

function print_saved_rollout_status(ev)
if isfield(ev,'rolloutSucceeded') && logical(ev.rolloutSucceeded)
    fprintf('  rollout: SUCCESS (100%% of requested horizon)\n');
    return;
end
status = "FAILED";
if isfield(ev,'rolloutStatus') && ~isempty(ev.rolloutStatus)
    status = string(ev.rolloutStatus);
end
failureTime = saved_field_numeric(ev,'failureTimeSeconds',NaN);
coverage = saved_field_numeric(ev,'trajectoryCoveragePercent',NaN);
fprintf('  rollout: %s | reached t=%s s | coverage %s%%\n', ...
    char(status),number_or_na(failureTime),number_or_na(coverage));
if isfield(ev,'failureMessage') && strlength(string(ev.failureMessage)) > 0
    fprintf('  failure reason: %s\n',char(string(ev.failureMessage)));
end
fprintf(['  whole-scenario trajectory metrics are recorded as NaN; ', ...
    'this is a replay of the saved failure outcome.\n']);
end

function name = saved_method_display_name(ev)
name = 'saved method';
if isfield(ev,'method') && isstruct(ev.method)
    if isfield(ev.method,'displayName') && ~isempty(ev.method.displayName)
        name = char(string(ev.method.displayName));
    elseif isfield(ev.method,'name') && ~isempty(ev.method.name)
        name = char(string(ev.method.name));
    end
end
end

function N = saved_train_sample_count(ev)
N = NaN;
if isfield(ev,'trainInfo') && isstruct(ev.trainInfo) && ...
        isfield(ev.trainInfo,'nSamples') && ~isempty(ev.trainInfo.nSamples)
    N = double(ev.trainInfo.nSamples);
end
end

function x = saved_rollout_solve_time(ev)
x = NaN;
if isfield(ev,'prediction') && isstruct(ev.prediction) && ...
        isfield(ev.prediction,'metadata') && isstruct(ev.prediction.metadata) && ...
        isfield(ev.prediction.metadata,'solveTimeSeconds') && ...
        ~isempty(ev.prediction.metadata.solveTimeSeconds)
    x = double(ev.prediction.metadata.solveTimeSeconds);
end
end

function x = saved_field_numeric(s,name,default)
x = default;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    try
        q = double(s.(name));
        if isscalar(q), x = q; end
    catch
    end
end
end

function x = saved_row_numeric(row,name,default)
x = default;
if istable(row) && height(row) >= 1 && ismember(name,row.Properties.VariableNames)
    try
        q = double(row.(name)(1));
        if isscalar(q), x = q; end
    catch
    end
end
end

function tf = saved_row_logical(row,name,default)
tf = default;
if istable(row) && height(row) >= 1 && ismember(name,row.Properties.VariableNames)
    try
        tf = logical(row.(name)(1));
    catch
    end
end
end

function s = saved_row_string(row,name,default)
s = string(default);
if istable(row) && height(row) >= 1 && ismember(name,row.Properties.VariableNames)
    try
        s = string(row.(name)(1));
    catch
    end
end
end

function s = number_or_na(x)
if isempty(x) || ~isscalar(x) || ~isfinite(x)
    s = 'n/a';
elseif abs(x-round(x)) < 1e-12 && abs(x) < 1e9
    s = sprintf('%d',round(x));
else
    s = sprintf('%.6g',x);
end
end

function s = scientific_or_na(x)
if isempty(x) || ~isscalar(x) || ~isfinite(x)
    s = 'n/a';
else
    s = sprintf('%.3e',x);
end
end
