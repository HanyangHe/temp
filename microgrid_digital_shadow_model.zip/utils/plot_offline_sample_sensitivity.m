function plot_offline_sample_sensitivity(T,cfg,outDir)
%PLOT_OFFLINE_SAMPLE_SENSITIVITY Sample count vs errors/training cost.
% All three y-axes use logarithmic scaling. Failed error rollouts are marked
% with colored x symbols in a small logarithmic headroom band.

methodNames = unique(T.DisplayName,'stable');
legendNames = arrayfun(@method_legend_abbrev,methodNames,'UniformOutput',false);
fig = figure('Name','Offline 1.2 sample sensitivity','Color','w','Visible',cfg.figures.visible);
tl = tiledlayout(1,3,'TileSpacing','compact','Padding','loose');
metrics = {'RMSE','MaxAE','TrainingTimeSec'};
ylabels = {'RMSE','Maximum absolute error','Training time (s)'};
for im = 1:numel(metrics)
    ax = nexttile; hold(ax,'on');
    nPlotted = 0;
    failX = cell(numel(methodNames),1);
    lineColor = cell(numel(methodNames),1);
    for k = 1:numel(methodNames)
        idx = T.DisplayName == methodNames(k);
        [n,ord] = sort(T.SampleCount(idx));
        vals = T.(metrics{im})(idx); vals = vals(ord);
        succeeded = true(size(n));
        if any(strcmp(T.Properties.VariableNames,'RolloutSucceeded'))
            q = T.RolloutSucceeded(idx); q = q(ord); succeeded = logical(q);
        end
        if im <= 2
            valid = isfinite(n) & isfinite(vals) & vals>0 & succeeded;
        else
            valid = isfinite(n) & isfinite(vals) & vals>0;
        end
        color = method_color_local(methodNames(k));
        if any(valid)
            h = plot(ax,n(valid),vals(valid),'-o','LineWidth',1.4, ...
                'Color',color,'DisplayName',legendNames{k});
            nPlotted = nPlotted + 1;
        else
            h = plot(ax,nan,nan,'-o','LineWidth',1.4, ...
                'Color',color,'DisplayName',legendNames{k});
        end
        lineColor{k} = color;
        if im <= 2, failX{k} = n(isfinite(n) & ~succeeded); end
    end
    if isfield(cfg,'sampleCounts') && ~isempty(cfg.sampleCounts)
        xticks(ax,cfg.sampleCounts(:).');
    end
    ax.XTickLabelRotation = 45;
    ylabel(ax,ylabels{im}); grid(ax,'on');
    set(ax,'YScale','log');
    expand_log_limits_local(ax);
    if im <= 2, mark_failures_log_local(ax,failX,lineColor); end

    if im == 1 && nPlotted > 0
        plot(ax,nan,nan,'x','LineWidth',1.5,'MarkerSize',8,'Color',[0.15 0.15 0.15], ...
            'DisplayName','failed rollout');
        lgd = legend(ax,'Orientation','horizontal', ...
            'NumColumns',preferred_legend_columns(numel(methodNames)+1));
        lgd.Layout.Tile = 'north'; lgd.Interpreter = 'none'; lgd.Box = 'on';
        lgd.FontSize = max(7,lgd.FontSize-1);
    end
end
xlabel(tl,'Samples');
export_offline_figure(fig,outDir,'section1p2_sample_sensitivity',cfg);
end

function mark_failures_log_local(ax,failX,lineColor)
failed=find(~cellfun(@isempty,failX)); if isempty(failed), return; end
expand_log_limits_local(ax); yl=ylim(ax);
if any(~isfinite(yl))||any(yl<=0)||yl(2)<=yl(1), yl=[1e-12 1]; end
lo=log10(yl(1)); hi=log10(yl(2)); span=max(hi-lo,1);
extra=max(0.16*span,0.055*span*numel(failed)); newHi=hi+extra;
ylim(ax,[10^lo 10^newHi]);
if numel(failed)>1, yExp=linspace(newHi-0.12*extra,hi+0.12*extra,numel(failed));
else, yExp=newHi-0.30*extra; end
for j=1:numel(failed)
    k=failed(j);
    plot(ax,failX{k},repmat(10^yExp(j),size(failX{k})),'x','LineWidth',1.5, ...
        'MarkerSize',8,'Color',lineColor{k},'HandleVisibility','off');
end
end

function expand_log_limits_local(ax)
yl=ylim(ax); if any(~isfinite(yl))||any(yl<=0)||yl(2)<=yl(1), return; end
lo=log10(yl(1)); hi=log10(yl(2));
if hi-lo<1, mid=0.5*(hi+lo); ylim(ax,[10^(mid-0.55) 10^(mid+0.55)]); end
end

function ncol = preferred_legend_columns(nItems)
if nItems <= 4, ncol = nItems; elseif nItems <= 8, ncol = ceil(nItems/2); else, ncol = 4; end
end

function label = method_legend_abbrev(name)
switch lower(strtrim(string(name)))
    case lower("M-KBF"), label="M-KBF";
    case lower("Vanilla SINDy"), label="V-SINDy";
    case lower("ED-SINDy"), label="ED-SINDy";
    case lower("LLM-Prior SINDy"), label="LLM-Prior SINDy";
    case lower("Physics-embedded SINDy"), label="PE-SINDy";
    case lower("Prior-weighted SINDy"), label="PW-SINDy";
    case lower("PNC-SINDy"), label="PNC-SINDy";
    case lower("Physics-Neural SINDy"), label="PN-SINDy";
    case lower("Weak SINDy"), label="Weak SINDy";
    case {lower("Neural ODE"), lower("NODE")}, label="NODE";
    case lower("Prior-weighted Neural SINDy"), label="PWN-SINDy";
    otherwise, label=string(name);
end
end

function color = method_color_local(name)
% Deterministic manuscript colors shared with the multi-seed figures.
switch lower(strtrim(string(name)))
    case {lower("Vanilla SINDy"), lower("V-SINDy")}, color = [0.0000 0.4470 0.7410];
    case {lower("Physics-embedded SINDy"), lower("PE-SINDy")}, color = [0.8500 0.3250 0.0980];
    case {lower("EDSI"), lower("ED-SINDy")}, color = [0.4940 0.1840 0.5560];
    case lower("LLM-Prior SINDy"), color = [0.4660 0.6740 0.1880];
    case lower("M-KBF"), color = [0.6350 0.0780 0.1840];
    case {lower("Neural ODE"), lower("NODE")}, color = [0.2500 0.2500 0.2500];
    otherwise, color = [0.2000 0.2000 0.2000];
end
end

