function written = write_sindy_model_tables(evaluation,outDir,prefix)
%WRITE_SINDY_MODEL_TABLES Export saved SINDy structure/coefficient diagnostics.
%
% This function never retrains or reruns a model. It uses only the numerical
% model/trainInfo already stored in an evaluation and is therefore replay-safe.

written = strings(0,1);
if nargin < 3 || isempty(prefix), prefix = 'sindy'; end
if ~isstruct(evaluation) || ~isfield(evaluation,'model') || ...
        ~isstruct(evaluation.model) || ~isfield(evaluation.model,'type') || ...
        ~strcmpi(char(string(evaluation.model.type)),'modular_sindy')
    return;
end
if ~exist(outDir,'dir'), mkdir(outDir); end

if isfield(evaluation,'trainInfo') && isfield(evaluation.trainInfo,'modules') && ...
        ~isempty(evaluation.trainInfo.modules)
    M = evaluation.trainInfo.modules;
    T = table(string({M.deviceType}).',[M.deviceIndex].',[M.bus].', ...
        [M.libraryTermCount].',[M.outputCount].',[M.candidateCoefficientCount].', ...
        [M.activeCoefficientCount].',[M.selectedThreshold].', ...
        [M.trainNormalizedMSE].',[M.validationNormalizedMSE].', ...
        'VariableNames',{'DeviceType','DeviceIndex','Bus','LibraryTermCount', ...
        'OutputCount','CandidateCoefficientCount','ActiveCoefficientCount', ...
        'SelectedThreshold','TrainNormalizedMSE','ValidationNormalizedMSE'});
    if isfield(M,'derivativeLabelProtocol')
        T.DerivativeLabelProtocol = string({M.derivativeLabelProtocol}).';
    end
    if isfield(M,'supportRidgeApplied')
        T.SupportRidgeApplied = logical([M.supportRidgeApplied].');
    end
    if isfield(M,'supportRidgeRelativeAlpha')
        T.SupportRidgeRelativeAlpha = [M.supportRidgeRelativeAlpha].';
    end
    if isfield(M,'normalizedCoefficientFroNorm')
        T.NormalizedCoefficientFroNorm = [M.normalizedCoefficientFroNorm].';
    end
    if isfield(M,'selectedCandidateType')
        T.SelectedCandidateType = string({M.selectedCandidateType}).';
    end
    if isfield(M,'nestedLayer1FallbackSelected')
        T.NestedLayer1FallbackSelected = logical([M.nestedLayer1FallbackSelected].');
    end
    if isfield(M,'nestedShallowPNFallbackSelected')
        T.NestedShallowPNFallbackSelected = logical([M.nestedShallowPNFallbackSelected].');
    end
    if isfield(M,'nestedParentFallbackSelected')
        T.NestedParentFallbackSelected = logical([M.nestedParentFallbackSelected].');
    end
    if isfield(M,'layer1LibraryTermCount')
        T.Layer1LibraryTermCount = [M.layer1LibraryTermCount].';
        T.Layer1ActiveCoefficientCount = [M.layer1ActiveCoefficientCount].';
        T.Layer1SelectedThreshold = [M.layer1SelectedThreshold].';
        T.Layer1ValidationNormalizedMSE = [M.layer1ValidationNormalizedMSE].';
    end
    if isfield(M,'activeBypassCoefficientCount')
        T.ActiveBypassCoefficientCount = [M.activeBypassCoefficientCount].';
    end
    if isfield(M,'activePEBypassCoefficientCount')
        T.ActivePEBypassCoefficientCount = [M.activePEBypassCoefficientCount].';
    end
    if isfield(M,'activeShallowPNCoefficientCount')
        T.ActiveShallowPNCoefficientCount = [M.activeShallowPNCoefficientCount].';
    end
    if isfield(M,'activeCompositionalCoefficientCount')
        T.ActiveCompositionalCoefficientCount = [M.activeCompositionalCoefficientCount].';
    end
    if isfield(M,'activeNeuralCoefficientCount')
        T.ActiveNeuralCoefficientCount = [M.activeNeuralCoefficientCount].';
    end
    p = fullfile(outDir,[prefix '_module_summary.csv']);
    writetable(T,p); written(end+1,1)=string(p); %#ok<AGROW>
end

families = {'sg','gfm','gfl'};
for f = 1:numel(families)
    family = families{f};
    if ~isfield(evaluation.model,family), continue; end
    A = evaluation.model.(family);
    for k = 1:numel(A)
        m = A(k);
        [termIdx,outIdx] = find(abs(m.coefficients)>0);
        if isempty(termIdx)
            TC = table(strings(0,1),strings(0,1),zeros(0,1), ...
                'VariableNames',{'Term','Output','Coefficient'});
        else
            coef = zeros(numel(termIdx),1);
            term = strings(numel(termIdx),1);
            output = strings(numel(termIdx),1);
            for q = 1:numel(termIdx)
                term(q) = m.libraryNames(termIdx(q));
                output(q) = m.outputNames(outIdx(q));
                coef(q) = m.coefficients(termIdx(q),outIdx(q));
            end
            TC = table(term,output,coef,'VariableNames',{'Term','Output','Coefficient'});
        end
        tag = sprintf('%s%d',upper(family),k);
        p = fullfile(outDir,sprintf('%s_coefficients_%s.csv',prefix,tag));
        writetable(TC,p); written(end+1,1)=string(p); %#ok<AGROW>

        % PNC-SINDy stores its frozen PE backbone inside each module. Export
        % that first layer separately so the compositional structure is fully
        % reproducible rather than hiding the backbone behind the layer-2 table.
        if isfield(m,'layer1') && isstruct(m.layer1) && ...
                isfield(m.layer1,'coefficients') && isfield(m.layer1,'libraryNames')
            l1 = m.layer1;
            [t1,o1] = find(abs(l1.coefficients)>0);
            term1 = strings(numel(t1),1);
            out1 = strings(numel(t1),1);
            coef1 = zeros(numel(t1),1);
            for q1 = 1:numel(t1)
                term1(q1) = l1.libraryNames(t1(q1));
                out1(q1) = l1.outputNames(o1(q1));
                coef1(q1) = l1.coefficients(t1(q1),o1(q1));
            end
            TL1 = table(term1,out1,coef1, ...
                'VariableNames',{'Term','Output','Coefficient'});
            p1 = fullfile(outDir,sprintf('%s_layer1_pe_coefficients_%s.csv',prefix,tag));
            writetable(TL1,p1); written(end+1,1)=string(p1); %#ok<AGROW>
        end

        % PNC v2 also stores the exact former flat-PN parent used for the
        % shallow skip candidate. Export it separately for reproducibility.
        if isfield(m,'shallowPNParent') && isstruct(m.shallowPNParent) && ...
                isfield(m.shallowPNParent,'coefficients') && ...
                isfield(m.shallowPNParent,'libraryNames')
            sp = m.shallowPNParent;
            [ts,os] = find(abs(sp.coefficients)>0);
            termS = strings(numel(ts),1);
            outS = strings(numel(ts),1);
            coefS = zeros(numel(ts),1);
            for qs = 1:numel(ts)
                termS(qs) = sp.libraryNames(ts(qs));
                outS(qs) = sp.outputNames(os(qs));
                coefS(qs) = sp.coefficients(ts(qs),os(qs));
            end
            TS = table(termS,outS,coefS, ...
                'VariableNames',{'Term','Output','Coefficient'});
            ps = fullfile(outDir,sprintf('%s_shallow_pn_parent_coefficients_%s.csv',prefix,tag));
            writetable(TS,ps); written(end+1,1)=string(ps); %#ok<AGROW>
        end

        if isfield(evaluation,'trainInfo') && isfield(evaluation.trainInfo,'modules')
            mods = evaluation.trainInfo.modules;
            idx = find(strcmpi({mods.deviceType},family) & [mods.deviceIndex]==k,1);
            if ~isempty(idx) && isfield(mods(idx),'thresholdSweep') && istable(mods(idx).thresholdSweep)
                p2 = fullfile(outDir,sprintf('%s_threshold_sweep_%s.csv',prefix,tag));
                writetable(mods(idx).thresholdSweep,p2); written(end+1,1)=string(p2); %#ok<AGROW>
            end
        end
    end
end
end
