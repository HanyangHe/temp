function plot_offline_noise_robustness_multiseed(S,cfg,outDir)
%PLOT_OFFLINE_NOISE_ROBUSTNESS_MULTISEED Mean/std across sampling seeds.
%
% Reliability-aware manuscript rule (matched to the sample-sensitivity plot):
%   * all seeds succeed: plot mean +/- std and connect adjacent all-pass points;
%   * some but not all seeds succeed: plot ONE isolated point at the mean of
%     the successful seeds, with no error bar/connecting line, AND mark the
%     condition with a colored x near the top of the panel;
%   * no seed succeeds: plot no metric point, but still mark the condition
%     with a colored x near the top of the panel.
%
% A neutral x legend entry denotes "one or more failed seeds". Both y-axes
% use logarithmic scaling.

% The plot excludes eta=10%%; require full seed coverage on the
% displayed 0--5%% conditions before exporting an IEEE manuscript figure.
if isfield(cfg,'multiseed') && isstruct(cfg.multiseed) && ...
        isfield(cfg.multiseed,'strictPlotSeedCoverage') && ...
        logical(cfg.multiseed.strictPlotSeedCoverage)
    expected=numel(cfg.randomSeeds);
    shown=double(S.NoisePercent)<=5+1e-10;
    if ~ismember('PresentSeedCount',S.Properties.VariableNames) || ...
            any(double(S.PresentSeedCount(shown))~=expected)
        error('plot_offline_noise_robustness_multiseed:IncompleteCohort', ...
            'Refusing to plot incomplete seed coverage (expected %d).',expected);
    end
end
methodNames = unique(S.DisplayName,'stable');
legendNames = arrayfun(@method_legend_abbrev,methodNames,'UniformOutput',false);

fig = figure('Name','', ...
    'Color','w','Visible',cfg.figures.visible);
tl = tiledlayout(1,2,'TileSpacing','compact','Padding','loose');
% IEEE figure caption is supplied in LaTeX: no plot title or shared x-axis label.

meanFields = {'RMSEMean','MaxAEMean'};
stdFields  = {'RMSEStd','MaxAEStd'};
ylabels    = {'RMSE','Maximum absolute error'};

for im = 1:2
    ax = nexttile(tl);
    hold(ax,'on');
    failX = cell(numel(methodNames),1);
    lineColor = cell(numel(methodNames),1);

    for k = 1:numel(methodNames)
        idx = S.DisplayName == methodNames(k);

        [x,ord] = sort(double(S.NoisePercent(idx)));
        mu = double(S.(meanFields{im})(idx)); mu = mu(ord);
        sd = double(S.(stdFields{im})(idx));  sd = sd(ord);

        seedCount = double(S.SeedCount(idx));       seedCount = seedCount(ord);
        successCount = double(S.SuccessCount(idx)); successCount = successCount(ord);

        % Stable color + one ordinary method legend entry.
        color = method_color_local(methodNames(k));
        h = plot(ax,nan,nan,'-o', ...
            'LineWidth',1.35,'MarkerSize',5, ...
            'Color',color, ...
            'DisplayName',legendNames{k});
        lineColor{k} = color;

        finiteMetric = isfinite(x) & isfinite(mu) & mu > 0;
        full = finiteMetric & seedCount > 0 & successCount == seedCount;
        partial = finiteMetric & successCount > 0 & successCount < seedCount;

        % Fully successful conditions: ordinary mean +/- std.
        if any(full)
            positive_errorbar_points_local(ax,x(full),mu(full),sd(full),color);
            connect_contiguous_full_success_local(ax,x,mu,full,color);
        end

        % Partial-success conditions retain the mean of successful seeds,
        % but no error bar/connecting line. The x marker added below makes
        % the reduced reliability explicit.
        if any(partial)
            plot(ax,x(partial),mu(partial),'o', ...
                'LineStyle','none', ...
                'Color',color, ...
                'LineWidth',1.35, ...
                'MarkerSize',5, ...
                'HandleVisibility','off');
        end

        % Mark every condition for which one or more seeds failed, including
        % zero-success conditions for which no finite metric point exists.
        failX{k} = x(seedCount > 0 & successCount < seedCount);
    end

    % Keep clean (0%) data at x=0, but omit its crowded tick label.
    % Limit the plot to the five formal noise levels (0 through 5%).
    xlim(ax,[0 5]);
    xticks(ax,[0.1 0.5 1 5]);
    xticklabels(ax,{'0.1','0.5','1','5'});

    ax.XTickLabelRotation = 45;
    ax.FontName = 'Times New Roman';
    ylabel(ax,ylabels{im},'FontName','Times New Roman');
    grid(ax,'on');
    box(ax,'on');
    set(ax,'YScale','log');
    expand_log_limits_local(ax);
    mark_failures_log_local(ax,failX,lineColor);

    if im == 1
        plot(ax,nan,nan,'x','LineWidth',1.5,'MarkerSize',8, ...
            'Color',[0.15 0.15 0.15], ...
            'DisplayName','one or more failed seeds');
        lgd = legend(ax,'Orientation','horizontal', ...
            'NumColumns',preferred_legend_columns(numel(methodNames)+1));
        lgd.Layout.Tile = 'north';
        lgd.Interpreter = 'none';
        lgd.Box = 'on';
        lgd.FontSize = max(7,lgd.FontSize-1);
        lgd.FontName = 'Times New Roman';
    end
end

export_offline_figure(fig,outDir,'section1p3_noise_robustness_multiseed',cfg);
end


function positive_errorbar_points_local(ax,x,mu,sd,color)
x = double(x(:));
mu = double(mu(:));
sd = double(sd(:));

lower = min(sd,0.95*mu);
lower(~isfinite(lower) | lower < 0) = 0;
upper = sd;
upper(~isfinite(upper) | upper < 0) = 0;

errorbar(ax,x,mu,lower,upper, ...
    'LineStyle','none', ...
    'Marker','o', ...
    'Color',color, ...
    'LineWidth',1.35, ...
    'MarkerSize',5, ...
    'CapSize',5, ...
    'HandleVisibility','off');
end


function connect_contiguous_full_success_local(ax,x,mu,full,color)
idx = find(full);
if numel(idx) < 2
    return;
end

runStart = 1;
for j = 2:(numel(idx)+1)
    breakRun = (j > numel(idx)) || idx(j) ~= idx(j-1)+1;
    if breakRun
        runIdx = idx(runStart:j-1);
        if numel(runIdx) >= 2
            plot(ax,x(runIdx),mu(runIdx),'-', ...
                'Color',color, ...
                'LineWidth',1.35, ...
                'HandleVisibility','off');
        end
        runStart = j;
    end
end
end


function mark_failures_log_local(ax,failX,lineColor)
failed = find(~cellfun(@isempty,failX));
if isempty(failed), return; end

expand_log_limits_local(ax);
yl = ylim(ax);
if any(~isfinite(yl)) || any(yl<=0) || yl(2)<=yl(1)
    yl = [1e-12 1];
end
lo = log10(yl(1));
hi = log10(yl(2));
span = max(hi-lo,1);
extra = max(0.16*span,0.055*span*numel(failed));
newHi = hi + extra;
ylim(ax,[10^lo 10^newHi]);

if numel(failed) > 1
    yExp = linspace(newHi-0.12*extra,hi+0.12*extra,numel(failed));
else
    yExp = newHi-0.30*extra;
end

for j = 1:numel(failed)
    k = failed(j);
    plot(ax,failX{k},repmat(10^yExp(j),size(failX{k})),'x', ...
        'LineWidth',1.5,'MarkerSize',8,'Color',lineColor{k}, ...
        'HandleVisibility','off');
end
end


function expand_log_limits_local(ax)
yl = ylim(ax);
if any(~isfinite(yl)) || any(yl<=0) || yl(2)<=yl(1), return; end
lo = log10(yl(1));
hi = log10(yl(2));
if hi-lo < 1
    mid = 0.5*(hi+lo);
    lo = mid-0.55;
    hi = mid+0.55;
    ylim(ax,[10^lo 10^hi]);
end
end


function ncol = preferred_legend_columns(nItems)
if nItems <= 4
    ncol = nItems;
elseif nItems <= 8
    ncol = ceil(nItems/2);
else
    ncol = 4;
end
end


function label = method_legend_abbrev(name)
switch lower(strtrim(string(name)))
    case lower("M-KBF"), label = "M-KBF";
    case lower("Vanilla SINDy"), label = "V-SINDy";
    case lower("ED-SINDy"), label = "ED-SINDy";
    case lower("LLM-Prior SINDy"), label = "LLM-Prior SINDy";
    case lower("Physics-embedded SINDy"), label = "PE-SINDy";
    case lower("Prior-weighted SINDy"), label = "PW-SINDy";
    case lower("PNC-SINDy"), label="PNC-SINDy";
    case lower("PNC-ResidualComp"), label="PNC-ResComp";
    case lower("PNC-v3-Residualized"), label="PNC-v3";
    case lower("Physics-Neural SINDy"), label = "PN-SINDy";
    case {lower("Neural ODE"), lower("NODE")}, label = "NODE";
    case lower("Weak SINDy"), label = "Weak SINDy";
    case lower("Poly-3 SINDy"), label = "Poly-3 SINDy";
    case lower("EDSI"), label = "ED-SINDy";
    case lower("LLM-EDSI"), label = "LLM-EDSI";
    case lower("Prior-weighted Neural SINDy"), label = "PWN-SINDy";
    otherwise, label = string(name);
end
end

function color = method_color_local(name)
% Deterministic manuscript colors for the retained methods.
% Explicitly include the 69-bus final5 set so replayed multiseed figures do
% not collapse new methods onto the gray fallback color.
switch lower(strtrim(string(name)))
    case lower("Vanilla SINDy"), color = [0.0000 0.4470 0.7410];
    case lower("Poly-3 SINDy"), color = [0.8500 0.3250 0.0980];
    case {lower("EDSI"), lower("ED-SINDy")}, color = [0.4940 0.1840 0.5560];
    case lower("LLM-EDSI"), color = [0.4660 0.6740 0.1880];
    case lower("LLM-Prior SINDy"), color = [0.4660 0.6740 0.1880];
    case lower("Physics-embedded SINDy"), color = [0.8500 0.3250 0.0980];
    case lower("Physics-Neural SINDy"), color = [0.9290 0.6940 0.1250];
    case lower("PNC-SINDy"), color = [0.4940 0.1840 0.5560];
    case lower("Weak SINDy"), color = [0.3010 0.7450 0.9330];
    case lower("M-KBF"), color = [0.6350 0.0780 0.1840];
    case {lower("Neural ODE"), lower("NODE")}, color = [0.2500 0.2500 0.2500];
    otherwise, color = [0.2000 0.2000 0.2000];
end
end
