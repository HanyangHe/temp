function plot_online_update_detector(evaluations,cfg,outDir)
%PLOT_ONLINE_UPDATE_DETECTOR Plot localized mismatch and deployment events.
% Supports repeated online corrections and cell-based stage histories.

online={};
for k=1:numel(evaluations)
    ev=evaluations{k};
    if isstruct(ev) && isfield(ev,'mode') && is_canonical_update_mode(ev.mode) && ...
            isfield(ev,'detector') && isstruct(ev.detector) && ...
            isfield(ev.detector,'time') && ~isempty(ev.detector.time)
        online{end+1}=ev; %#ok<AGROW>
    end
end
if isempty(online), return; end

fig=figure('Name','Online update detector','Color','w','Visible',cfg.figures.visible);
increase_height(fig,numel(online));
tl=tiledlayout(numel(online),1,'TileSpacing','compact','Padding','compact');
for k=1:numel(online)
    ev=online{k}; d=ev.detector;
    ax=nexttile; hold(ax,'on');

    if isfield(d,'maxModuleTriggerRatio') && ~isempty(d.maxModuleTriggerRatio)
        plot(ax,d.time,d.maxModuleTriggerRatio,'LineWidth',1.35, ...
            'DisplayName','Max module trigger ratio');
        yline(ax,1,'--','LineWidth',1.1,'DisplayName','Trigger ratio = 1');
        ylabel(ax,'Mismatch / threshold');
    elseif isfield(d,'rollingScore') && ~isempty(d.rollingScore)
        plot(ax,d.time,d.rollingScore,'LineWidth',1.35,'DisplayName','Rolling VF mismatch');
        ylabel(ax,'Normalized VF error');
    end

    showMarkers=~isfield(cfg.figures,'showOnlineUpdateMarkers') || cfg.figures.showOnlineUpdateMarkers;
    if showMarkers
        detectorHist = get_history(ev,'detectorHistory');
        updateHist = get_history(ev,'updateHistory');

        for i=1:numel(detectorHist)
            hi = history_item(detectorHist,i);
            if isempty(hi), continue; end
            if isfield(hi,'triggered') && hi.triggered && isfinite(hi.triggerTime)
                name='Trigger';
                if i>1, name=sprintf('Trigger %d',i); end
                xline(ax,hi.triggerTime,':','LineWidth',1.2,'DisplayName',name);
            end
        end
        for i=1:numel(updateHist)
            ui = history_item(updateHist,i);
            if isempty(ui), continue; end
            if isfield(ui,'candidateReadyTime') && isfinite(ui.candidateReadyTime) && ...
                    ui.candidateReadyTime<=d.time(end)+1e-12
                name='Candidate ready';
                if i>1, name=sprintf('Candidate ready %d',i); end
                xline(ax,ui.candidateReadyTime,'--','LineWidth',1.0,'DisplayName',name);
            end
            if isfield(ui,'activationTime') && isfinite(ui.activationTime) && ...
                    ui.activationTime<=d.time(end)+1e-12 && ...
                    isfield(ui,'candidateAccepted') && ui.candidateAccepted
                name='Updated model active';
                if i>1, name=sprintf('Updated model active %d',i); end
                xline(ax,ui.activationTime,'-.','LineWidth',1.2,'DisplayName',name);
            end
        end
    end

    grid(ax,'on');
    xlim(ax,[d.time(1) d.time(end)]);
    moduleText="";
    if isfield(d,'affectedModuleLabel') && strlength(string(d.affectedModuleLabel))>0
        moduleText=" | localized "+string(d.affectedModuleLabel);
    end
    title(ax,char(short_method_label(ev.method.displayName)+" (A+S)"+moduleText), ...
        'Interpreter','none');
    if k==1
        lgd=legend(ax,'Orientation','horizontal','Interpreter','none','Box','on');
        try
            lgd.Layout.Tile='north';
        catch
            lgd.Location='northoutside';
        end
    end
end
xlabel(tl,'Time (s)');
export_offline_figure(fig,outDir,'online_update_detector',cfg);
end


function tf=is_canonical_update_mode(mode)
mode=lower(string(mode));
tf = mode=="adapted_sync" || mode=="online";
end

function H = get_history(ev,name)
H = cell(0,1);
if isfield(ev,name) && ~isempty(ev.(name))
    H = ev.(name);
elseif isfield(ev,'update') && isstruct(ev.update) && isfield(ev.update,name) && ~isempty(ev.update.(name))
    H = ev.update.(name);
elseif strcmp(name,'detectorHistory') && isfield(ev,'detector') && isfield(ev.detector,'history')
    H = ev.detector.history;
end
end

function item = history_item(H,i)
item=[];
if iscell(H)
    if i<=numel(H), item=H{i}; end
elseif isstruct(H)
    if i<=numel(H), item=H(i); end
end
end

function increase_height(fig,nRows)
if nRows<=2, return; end
try
    fig.Units='pixels';
    pos=fig.Position;
    pos(4)=max(pos(4),round(190*nRows+100));
    fig.Position=pos;
catch
end
end

function label=short_method_label(name)
switch lower(strtrim(string(name)))
    case lower("M-KBF"), label="M-KBF";
    case lower("Vanilla SINDy"), label="V-SINDy";
    case lower("Physics-embedded SINDy"), label="PE-SINDy";
    case lower("Neural SINDy"), label="N-SINDy";
    case lower("Physics-Neural SINDy"), label="PN-SINDy";
    case lower("Neural ODE"), label="NODE";
    otherwise, label=string(name);
end
end
