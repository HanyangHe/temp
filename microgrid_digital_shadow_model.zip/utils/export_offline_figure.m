function export_offline_figure(fig,outDir,baseName,cfg)
%EXPORT_OFFLINE_FIGURE Save FIG and optional PDF/PNG without forcing popups.
if ~exist(outDir,'dir'), mkdir(outDir); end
savefig(fig,fullfile(outDir,[char(baseName) '.fig']));
if isfield(cfg,'figures') && isfield(cfg.figures,'exportPDF') && cfg.figures.exportPDF
    exportgraphics(fig,fullfile(outDir,[char(baseName) '.pdf']),'ContentType','vector');
end
if isfield(cfg,'figures') && isfield(cfg.figures,'exportPNG') && cfg.figures.exportPNG
    exportgraphics(fig,fullfile(outDir,[char(baseName) '.png']),'Resolution',220,'BackgroundColor','white');
end
if isfield(cfg,'figures') && isfield(cfg.figures,'closeAfterExport') && cfg.figures.closeAfterExport
    try, close(fig); catch, end
end
end
