function cfg = config_online_experiment_69bus()
%CONFIG_ONLINE_EXPERIMENT_69BUS Official 69-bus online digital-shadow setup.
%
% This official configuration freezes the manuscript protocol on the
% proposed LLM-Prior SINDy method and integrates the held-out nominal-
% trajectory detector calibration that was previously validated in the
% dedicated smoke test. The actual deployment therefore uses:
%   - saved clean offline initial model (N=500, 0%% label noise)
%   - 0.1%% online xdot observation noise
%   - hidden GFM1 nq mismatch: +0.10, then -0.10 at t = 6 s
%   - no online LLM calls
%   - localized fixed-support coefficient RLS only
%   - Stage-3 four-variant ablation: F, F+S, A, A+S

cfg=config_offline_experiment_69bus();
cfg.name='online_model_experiment_69bus';

%% Saved offline initial-model condition
cfg.online.offlineOutputFolder='offline_model_experiments_69bus';
cfg.online.initialModelSampleCount=500;
cfg.online.initialModelSeed=20260814;
cfg.online.initialModelNoiseLevel=0.0;  % clean offline initial model
cfg.online.observationNoiseLevel=0.001; % 0.1%% online xdot observation noise
cfg.online.observationNoiseSeed=20260815;

%% Online baseline controls
cfg.online.methods.neuralODE.frozen=false;
cfg.online.methods.neuralODE.online=false;
cfg.online.methods.modularKoopman.frozen=false;
cfg.online.methods.modularKoopman.online=false;
cfg.online.methods.vanillaSINDy.frozen=false;
cfg.online.methods.vanillaSINDy.online=false;
cfg.online.methods.physicsEmbeddedSINDy.frozen=false;
cfg.online.methods.physicsEmbeddedSINDy.online=false;
cfg.online.methods.neuralSINDy.frozen=false;
cfg.online.methods.neuralSINDy.online=false;
cfg.online.methods.physicsNeuralCompositionalSINDy.frozen=false;
cfg.online.methods.physicsNeuralCompositionalSINDy.online=false;
cfg.online.methods.physicsNeuralSINDy.frozen=false;
cfg.online.methods.physicsNeuralSINDy.online=false;
cfg.online.methods.llmPriorSINDy=struct('frozen',true,'online',true);

%% LLM-Prior online protocol
cfg.sindy.enabled=true;
if ~isfield(cfg.sindy,'llmPrior') || ~isstruct(cfg.sindy.llmPrior)
    cfg.sindy.llmPrior=struct();
end
cfg.sindy.llmPrior.enabled=true;
cfg.sindy.llmPrior.discoveryProtocolVersion='weak_domain_canonical_deterministic_closure_v4';
if ~isfield(cfg.online,'llmPrior') || ~isstruct(cfg.online.llmPrior)
    cfg.online.llmPrior=struct();
end
cfg.online.llmPrior.discoverySeed=20260814;
cfg.online.llmPrior.priorBankHash='';

%% Stage-3 online attribution ablation
cfg.online.ablation.enabled=true;
cfg.online.ablation.variants={ ...
    'frozen_no_sync', ...
    'frozen_sync', ...
    'adapted_no_sync', ...
    'adapted_sync'};
cfg.online.ablation.primaryVariant='adapted_sync';
cfg.online.ablation.commonActivationSchedule='accepted_adaptive_activation_times';

%% Hidden true-system parameter mismatch
cfg.online.parameterMismatch.enabled=true;
cfg.online.parameterMismatch.deviceType='gfm';
cfg.online.parameterMismatch.device=[1];
cfg.online.parameterMismatch.parameter='nq';
cfg.online.parameterMismatch.component='all';
cfg.online.parameterMismatch.profile='piecewise_constant';
cfg.online.parameterMismatch.mode='additive';
cfg.online.parameterMismatch.times=[0.0,6.0];
cfg.online.parameterMismatch.values=[0.10,-0.10];
cfg.online.parameterMismatch.value=cfg.online.parameterMismatch.values;

%% Online mismatch detector
cfg.online.update.enabled=true;
cfg.online.update.strategy='module_local_fixed_support_rls';
cfg.online.update.maximumUpdateAttempts=10;
cfg.online.update.maximumAcceptedUpdates=4;
cfg.online.update.refractorySeconds=0.05;

cfg.online.update.detector.metric='module_rolling_vector_field_nrmse';
cfg.online.update.detector.windowSeconds=0.10;
cfg.online.update.detector.threshold=0.05;
cfg.online.update.detector.minimumTriggerTime=0.10;
cfg.online.update.detector.requiredConsecutiveWindows=3;
cfg.online.update.detector.scaleFloor=1e-10;

% Official detector policy: held-out nominal-trajectory calibration.
cfg.online.update.detector.calibrateFromOffline=false;
cfg.online.update.detector.trajectoryCalibrationEnabled=true;
cfg.online.update.detector.calibrationSource='heldout_nominal_trajectory';
cfg.online.update.detector.trajectoryCalibrationNoiseSeed=20260814;
cfg.online.update.detector.trajectoryCalibrationQuantile=0.995;
cfg.online.update.detector.trajectoryCalibrationMultiplier=1.10;
cfg.online.update.detector.trajectoryCalibrationMaxSafetyMultiplier=1.02;

%% Fast local coefficient adaptation
cfg.online.update.sampleStep=0.005;
cfg.online.update.minimumOnlineSamples=100;
cfg.online.update.waitForMinimumSamples=true;
cfg.online.update.historyWindowSeconds=inf;

cfg.online.update.localRLS.supportTolerance=0;
cfg.online.update.localRLS.offlineDataWeight=0.05;
cfg.online.update.localRLS.onlineSampleWeight=1.0;
cfg.online.update.localRLS.priorPrecision=1e-6;
cfg.online.update.localRLS.covarianceJitter=1e-10;
cfg.online.update.localRLS.forgettingHalfLifeSeconds=1.0;

cfg.online.update.trainingDelayScale=1.0;
cfg.online.update.minimumTrainingDelaySeconds=0.0;

%% Causal candidate validation and deployment
cfg.online.update.validation.enabled=true;
cfg.online.update.validation.windowSeconds=0.20;
cfg.online.update.validation.minimumSamples=20;
cfg.online.update.validation.requiredRelativeImprovement=0.10;
cfg.online.update.validation.requiredAbsoluteImprovement=0.0;
cfg.online.update.stateSynchronizationAtActivation=true;

%% Tracking metrics
cfg.online.tracking.enabled=true;
cfg.online.tracking.definition='non_delay_after_hidden_mismatch';
cfg.online.tracking.keyVoltageBus=[];

%% Output / figures
cfg.output.folderName='online_model_experiments_69bus';
cfg.figures.exportPDF=true;
cfg.figures.visible='on';
cfg.figures.showOnlineUpdateMarkers=true;
end
