function Iinj = load_injection_current(V,Sload,epsV2)
%LOAD_INJECTION_CURRENT Constant-PQ load current using one sign convention.
%
% Convention: positive current is injection INTO the network. Sload is a
% positive consumption magnitude P+jQ. Therefore the load injection is
% negative:
%       I_load^inj = -conj(Sload ./ V)
%
% Numerically equivalent regularized form below avoids division by exactly
% zero during a failed Newton trial. For normal voltages (~1 pu), epsV2 is
% negligible and the physical equation is unchanged to machine precision.

if nargin < 3
    epsV2 = 1e-10;
end
Iinj = -conj(Sload).*V./(abs(V).^2 + epsV2);
end
