function Ybus = build_ybus(N,line)
%BUILD_YBUS Build sparse nodal admittance matrix from series branches.
%
% No shunt admittances are included in this first reference model.

from = line.from;
to = line.to;
z = line.zPu;
if any(abs(z) <= eps)
    error('build_ybus:ZeroImpedance','A branch has zero/near-zero impedance.');
end

y = 1./z;
Ybus = sparse(N,N);
for k = 1:numel(y)
    i = from(k);
    j = to(k);
    Ybus(i,i) = Ybus(i,i) + y(k);
    Ybus(j,j) = Ybus(j,j) + y(k);
    Ybus(i,j) = Ybus(i,j) - y(k);
    Ybus(j,i) = Ybus(j,i) - y(k);
end
end
