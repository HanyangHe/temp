function data = build_node_module_trajectory_data(dataset,c,layout,deviceType,deviceIndex)
%BUILD_NODE_MODULE_TRAJECTORY_DATA Extract one DER's short-trajectory data.
%
% Returned arrays use [channel, trajectory, time] ordering.

T = dataset.trajectories.t(:).';
L = numel(T);
K = dataset.trajectories.nTrajectories;
XobsAll = dataset.trajectories.xObserved;
XcleanAll = dataset.trajectories.xClean;
Vall = dataset.trajectories.V;

switch lower(char(deviceType))
    case 'sg'
        idx = layout.sg{deviceIndex};
        bus = c.sg(deviceIndex).bus;
        if numel(idx) == 5 && isfield(c.input.nominal,'sgVref')
            forceNames = ["Vterminal_Re";"Vterminal_Im";"Pm";"Vref"];
            nForce = 4;
        else
            forceNames = ["Vterminal_Re";"Vterminal_Im";"Pm"];
            nForce = 3;
        end
    case 'gfm'
        idx = layout.gfm{deviceIndex};
        bus = c.gfm(deviceIndex).bus;
        forceNames = ["Vterminal_Re";"Vterminal_Im";"Pstar";"Qstar";"Eref"];
        nForce = 5;
    case 'gfl'
        idx = layout.gfl{deviceIndex};
        bus = c.gfl(deviceIndex).bus;
        forceNames = ["Vterminal_Re";"Vterminal_Im";"Pstar";"Qstar"];
        nForce = 4;
    otherwise
        error('build_node_module_trajectory_data:DeviceType', ...
            'Unknown deviceType "%s".',char(deviceType));
end

nState = numel(idx);
Xobs = zeros(nState,K,L);
Xclean = zeros(nState,K,L);
forcing = zeros(nForce,K,L);

for tr = 1:K
    uFixed = dataset.trajectories.uByTrajectory{tr};
    hasTimeSeries = isfield(dataset.trajectories,'uTimeSeriesByTrajectory') && ...
        numel(dataset.trajectories.uTimeSeriesByTrajectory)>=tr && ...
        ~isempty(dataset.trajectories.uTimeSeriesByTrajectory{tr});
    if hasTimeSeries
        uSeries = dataset.trajectories.uTimeSeriesByTrajectory{tr};
    else
        uSeries = struct();
    end
    for it = 1:L
        Xobs(:,tr,it) = reshape(XobsAll(it,tr,idx),[nState 1]);
        Xclean(:,tr,it) = reshape(XcleanAll(it,tr,idx),[nState 1]);
        Vb = Vall(it,tr,bus);
        switch lower(char(deviceType))
            case 'sg'
                if nForce == 4
                    forcing(:,tr,it) = [real(Vb);imag(Vb); ...
                    input_value(uFixed,uSeries,'sgPm',deviceIndex,it); ...
                    input_value(uFixed,uSeries,'sgVref',deviceIndex,it)];
                else
                    forcing(:,tr,it) = [real(Vb);imag(Vb); ...
                    input_value(uFixed,uSeries,'sgPm',deviceIndex,it)];
                end
            case 'gfm'
                forcing(:,tr,it) = [real(Vb);imag(Vb); ...
                    input_value(uFixed,uSeries,'gfmPstar',deviceIndex,it); ...
                    input_value(uFixed,uSeries,'gfmQstar',deviceIndex,it); ...
                    input_value(uFixed,uSeries,'gfmEref',deviceIndex,it)];
            case 'gfl'
                forcing(:,tr,it) = [real(Vb);imag(Vb); ...
                    input_value(uFixed,uSeries,'gflPstar',deviceIndex,it); ...
                    input_value(uFixed,uSeries,'gflQstar',deviceIndex,it)];
        end
    end
end

data.deviceType = lower(string(deviceType));
data.deviceIndex = deviceIndex;
data.stateIndices = idx(:);
data.bus = bus;
data.t = T;
data.xObserved = Xobs;
data.xClean = Xclean;
data.forcing = forcing;
data.nState = nState;
data.nForce = nForce;
data.nTrajectories = K;
data.nTimes = L;
data.forceNames = forceNames;
end

function value = input_value(uFixed,uSeries,fieldName,k,it)
if isstruct(uSeries) && isfield(uSeries,fieldName) && ~isempty(uSeries.(fieldName))
    value = uSeries.(fieldName)(k,it);
elseif isstruct(uFixed) && isfield(uFixed,fieldName) && numel(uFixed.(fieldName))>=k
    value = uFixed.(fieldName)(k);
else
    error('build_node_module_trajectory_data:MissingInput', ...
        'Missing %s(%d) for trajectory input construction.',fieldName,k);
end
end
