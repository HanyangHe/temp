function [model,info] = train_llm_prior_sindy(dataset,c,layout,cfg)
%TRAIN_LLM_PRIOR_SINDY Formal V-SINDy + weak-domain LLM prior bank.
%
% Core proposed offline method. The generic V-SINDy library is unchanged;
% a compact seed-specific LLM-discovered physics bank is appended. All
% coefficients/support are identified from data with exactly the same OLS-STLSQ
% and frozen-support ridge policy used by V-SINDy. The LLM never receives the
% hand-written PE-SINDy strong feature bank or numerical coefficients.

opt = get_sindy_options(cfg);
if ~isfield(opt,'llmPrior') || ~logical(opt.llmPrior.enabled)
    error('train_llm_prior_sindy:Disabled', ...
        'cfg.sindy.llmPrior.enabled must be true.');
end

[K,trainIds,valIds,trainMask,valMask,forcedTrainIds] = split_local(dataset,opt);
model.type = 'modular_sindy';
model.formulationVersion = char(string(opt.llmPrior.formulationVersion));
model.variant = 'llmprior';
model.libraryVariant = 'llmprior';
model.fitMode = 'standard';
model.trainingSampleDefinition = 'flattened pointwise samples from common short-trajectory dataset';
model.sg = struct([]); model.gfm = struct([]); model.gfl = struct([]);
model.trainTrajectoryIds = trainIds(:);
model.validationTrajectoryIds = valIds(:);
model.forcedTrainingTrajectoryIds = forcedTrainIds(:);
model.options = opt;

modules = struct([]); mi=0; activeTotal=0; candidateTotal=0;
for k=1:numel(c.sg)
    fprintf('    Training LLM-prior SINDy module SG%d (Bus %d)...\n',k,c.sg(k).bus);
    data=build_sindy_module_data(dataset,c,layout,'sg',k);
    [mk,ik]=fit_sindy_stlsq_module(data,trainMask,valMask,'llmprior',opt,'standard');
    if k==1, model.sg=mk; else, model.sg(k,1)=mk; end
    [modules,mi]=append_info_local(modules,mi,ik);
    activeTotal=activeTotal+ik.activeCoefficientCount;
    candidateTotal=candidateTotal+ik.candidateCoefficientCount;
end
for k=1:numel(c.gfm)
    fprintf('    Training LLM-prior SINDy module GFM%d (Bus %d)...\n',k,c.gfm(k).bus);
    data=build_sindy_module_data(dataset,c,layout,'gfm',k);
    [mk,ik]=fit_sindy_stlsq_module(data,trainMask,valMask,'llmprior',opt,'standard');
    if k==1, model.gfm=mk; else, model.gfm(k,1)=mk; end
    [modules,mi]=append_info_local(modules,mi,ik);
    activeTotal=activeTotal+ik.activeCoefficientCount;
    candidateTotal=candidateTotal+ik.candidateCoefficientCount;
end
for k=1:numel(c.gfl)
    fprintf('    Training LLM-prior SINDy module GFL%d (Bus %d)...\n',k,c.gfl(k).bus);
    data=build_sindy_module_data(dataset,c,layout,'gfl',k);
    [mk,ik]=fit_sindy_stlsq_module(data,trainMask,valMask,'llmprior',opt,'standard');
    if k==1, model.gfl=mk; else, model.gfl(k,1)=mk; end
    [modules,mi]=append_info_local(modules,mi,ik);
    activeTotal=activeTotal+ik.activeCoefficientCount;
    candidateTotal=candidateTotal+ik.candidateCoefficientCount;
end
model.activeCoefficientCount=activeTotal;
model.candidateCoefficientCount=candidateTotal;
model.compatibilitySchema='formal_llm_prior_sindy_v1';
model.compatibilitySignature=struct('method','llm_prior_sindy', ...
    'formulationVersion',char(string(opt.llmPrior.formulationVersion)), ...
    'discoverySeed',double(opt.llmPrior.discoverySeed), ...
    'priorBankHash',char(string(opt.llmPrior.priorBankHash)));

info.method='llm_prior_sindy';
info.displayName='LLM-Prior SINDy';
info.formulationVersion=model.formulationVersion;
info.objective='V-SINDy generic library + weak-domain LLM compiled physical basis bank; shared STLSQ backend';
info.nSamples=size(dataset.x,1);
info.nTrajectories=K;
info.nTrainSamples=nnz(trainMask);
info.nValidationSamples=nnz(valMask);
info.trainTrajectoryIds=trainIds(:);
info.validationTrajectoryIds=valIds(:);
info.forcedTrainingTrajectoryIds=forcedTrainIds(:);
info.modules=modules;
info.activeCoefficientCount=activeTotal;
info.candidateCoefficientCount=candidateTotal;
info.priorBankHash=char(string(opt.llmPrior.priorBankHash));
info.discoverySeed=double(opt.llmPrior.discoverySeed);

if ~isempty(forcedTrainIds) && opt.verbose
    fprintf('    Forced into SINDy training partition: trajectory ID(s) [%s]\n', ...
        strtrim(sprintf('%d ',forcedTrainIds)));
end
end

function [K,trainIds,valIds,trainMask,valMask,forcedTrainIds]=split_local(dataset,opt)
K=dataset.trajectories.nTrajectories;
if K<2, error('train_llm_prior_sindy:TooFewTrajectories','Need at least two trajectories.'); end
forcedTrainIds=[];
if isfield(dataset.trajectories,'forceTrainingMask') && ~isempty(dataset.trajectories.forceTrainingMask)
    m=logical(dataset.trajectories.forceTrainingMask(:));
    if numel(m)~=K, error('train_llm_prior_sindy:ForceTrainingMask','forceTrainingMask size mismatch.'); end
    forcedTrainIds=find(m).';
end
candidates=setdiff(1:K,forcedTrainIds,'stable');
old=rng; cleanup=onCleanup(@()rng(old)); %#ok<NASGU>
rng(opt.validationSeed,'twister');
perm=candidates(randperm(numel(candidates)));
nVal=max(1,round(opt.validationFraction*K)); nVal=min(nVal,numel(candidates));
if nVal>=K, nVal=K-1; end
valIds=sort(perm(1:nVal));
trainIds=sort(setdiff(1:K,valIds,'stable'));
trainMask=ismember(dataset.trajectoryId,trainIds);
valMask=ismember(dataset.trajectoryId,valIds);
end

function [S,mi]=append_info_local(S,mi,ik)
mi=mi+1; if mi==1, S=ik; else, S(mi,1)=ik; end
end
