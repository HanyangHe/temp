function [model,info] = train_physics_neural_compositional_sindy(dataset,c,layout,cfg)
%TRAIN_PHYSICS_NEURAL_COMPOSITIONAL_SINDY Train the proposed PNC-SINDy v2 model.
%
%   H = f_PE_hat(chi)
%   Theta_2 = [H, Theta_PN_flat(chi), Phi_comp(chi,H)]
%   xdot_hat = Theta_2 * Xi_2
%
% The frozen PE bypass and flat-PN skip make both parent models strict
% submodels. A compositional branch is activated only when held-out validation
% improves materially beyond both parents. No backpropagation is used.
[model,info] = train_modular_pnc_sindy(dataset,c,layout,cfg);
end
