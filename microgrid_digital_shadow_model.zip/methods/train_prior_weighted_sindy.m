function [model,info] = train_prior_weighted_sindy(dataset,c,layout,cfg)
%TRAIN_PRIOR_WEIGHTED_SINDY Full PE physics dictionary with weighted sparsity prior.
%
% Uses exactly the same full physics candidate library as
% Physics-embedded SINDy. The only change is the STLSQ sparsity
% selection: composed physics candidates receive a larger retention weight,
% so their effective pruning threshold is lower than that of generic terms.
[model,info] = train_modular_sindy(dataset,c,layout,cfg,'priorweighted');
end
