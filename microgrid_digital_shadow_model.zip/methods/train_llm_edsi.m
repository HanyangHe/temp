function [model,info] = train_llm_edsi(dataset,c,layout,cfg)
%TRAIN_LLM_EDSI Formal one-shot semantic-initialization LLM-EDSI method.
[model,info] = train_edsi_core(dataset,c,layout,cfg,"llm_edsi");
end
