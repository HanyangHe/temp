function [module,info] = fit_koopman_bilinear_module(data,trainIds,valIds,opt)
%FIT_KOOPMAN_BILINEAR_MODULE Identify one continuous lifted KBF generator.
%
% Fixed algebraic lift:
%   s = (x-mu_x)./sigma_x,   z = T(s)
%   q = (u-mu_u)./sigma_u
%
% Analytic chain rule target:
%   sdot = xdot./sigma_x
%   zdot = J_T(s) sdot
%
% Learnable Jiang Eq. (16) matrices:
%   zdot = A z + sum_i q_i B_i z.
%
% This version retains the successful ordinary normalized Poly-3 lift and
% improves low-data conditioning only through JOINT SVD-rank and Tikhonov
% (ridge) regularization selection. No isotypic lift or eigenvalue-pattern
% heuristic is used.
%
% Since degree-one entries of z are exactly s, the physical vector field is
% recovered without inverse lifting:
%   xdot = Cdot * zdot,
% where Cdot is a fixed matrix determined only by the state normalization and
% the locations of the degree-one observables.

trainIds = trainIds(:).';
valIds = valIds(:).';
traj = data.trajectoryId(:).';
allIds = unique(traj,'stable');
if any(~ismember(trainIds,allIds)) || any(~ismember(valIds,allIds))
    error('fit_koopman_bilinear_module:TrajectoryIds','Invalid train/validation trajectory IDs.');
end
if isempty(trainIds) || isempty(valIds)
    error('fit_koopman_bilinear_module:Split','Both training and validation trajectories are required.');
end

trainMask = ismember(traj,trainIds);
valMask = ismember(traj,valIds);
if ~any(trainMask) || ~any(valMask)
    error('fit_koopman_bilinear_module:EmptySplit','Training or validation sample set is empty.');
end

nState = data.nState;
nForce = data.nForce;
Xtr = data.x(:,trainMask);
Ftr = data.forcing(:,trainMask);
Ytr = data.xdot(:,trainMask);
Xva = data.x(:,valMask);
Fva = data.forcing(:,valMask);
Yva = data.xdot(:,valMask);
trajVa = traj(valMask);

stateMean = mean(Xtr,2);
stateStd = robust_scale(Xtr,opt.normalization.stateStdFloor);
forceMean = mean(Ftr,2);
forceStd = robust_scale(Ftr,opt.normalization.forceStdFloor);

stateNames = string(data.stateNames(:));
[Sprobe,observableNames,liftSpec] = build_koopman_monomial_lift( ...
    zeros(nState,1),stateNames,opt.polyOrder,[]);
M = size(Sprobe,1);
linearIdx = liftSpec.linearObservableIndices(:);

[Ztr,dZtr,Qtr] = lifted_generator_data(Xtr,Ftr,Ytr,stateMean,stateStd, ...
    forceMean,forceStd,opt,liftSpec,stateNames);
[Zva,dZva,Qva] = lifted_generator_data(Xva,Fva,Yva,stateMean,stateStd, ...
    forceMean,forceStd,opt,liftSpec,stateNames);

Rtr = build_bilinear_regression(Ztr,Qtr);
[U,S,V] = svd(Rtr,'econ');
svals = diag(S);
if isempty(svals) || ~isfinite(svals(1)) || svals(1) <= 0
    error('fit_koopman_bilinear_module:DegenerateRegression', ...
        'The continuous KBF regression matrix is numerically degenerate.');
end
numericalRank = nnz(svals >= opt.rankRelativeSingularValueFloor*svals(1));
regressionDimension = size(Rtr,1);
rankReferenceDimension = regressionDimension;
rMax = min([numericalRank,size(U,2),size(V,2),floor(opt.maxRank)]);
if rMax < 1
    error('fit_koopman_bilinear_module:ZeroRank','No usable singular direction remains after truncation.');
end
% IMPORTANT: rank fractions are referenced to the FIXED regression
% dimension M*(1+nForce), not to the sample-dependent numerical rank.
% The resulting nominal rank grid is therefore identical for a given DER
% module across all sample sizes. At a low sample size, candidates that
% exceed the currently usable numerical rank are clipped to rMax.
[candidateRanks,nominalCandidateRanks,rankNominalFloor,rankNominalCeiling] = ...
    make_candidate_ranks(rankReferenceDimension,rMax,opt);
ridgeGrid = unique(double(opt.ridgeRelativeGrid(:).'),'stable');
if isempty(ridgeGrid)
    ridgeGrid = 0;
end

outputScale = robust_scale(Ytr,opt.normalization.outputScaleFloor);
liftScale = robust_scale(dZtr,opt.normalization.outputScaleFloor);
Cdot = zeros(nState,M);
Cdot(:,linearIdx) = diag(stateStd);

nRank = numel(candidateRanks);
nRidge = numel(ridgeGrid);
nCand = nRank*nRidge;
rankUsed = zeros(nCand,1);
ridgeRelative = zeros(nCand,1);
ridgeLambda = zeros(nCand,1);
trainScaledMSE = inf(nCand,1);
valScaledMSE = inf(nCand,1);
trainLiftScaledMSE = inf(nCand,1);
valLiftScaledMSE = inf(nCand,1);
spectralAbscissa = inf(nCand,1);
stableCandidate = false(nCand,1);
retainedConditionNumber = inf(nCand,1);
effectiveDegreesOfFreedom = inf(nCand,1);
noiseAmplificationProxy = inf(nCand,1);
valTrajectoryMeanScaledMSE = inf(nCand,1);
valTrajectoryStdScaledMSE = inf(nCand,1);
valTrajectorySEScaledMSE = inf(nCand,1);
validationTrajectoryErrors = nan(nCand,numel(valIds));
models = cell(nCand,1);

% A relative ridge value alpha is converted to the singular-value units of
% the regression matrix by lambda = alpha*sigma_1^2. The filtered inverse is
%   sigma/(sigma^2+lambda),
% which continuously connects the truncated pseudoinverse (alpha=0) to a
% Tikhonov-regularized inverse without changing the KBF model structure.
sigmaRef2 = svals(1)^2;
ic = 0;
for ir = 1:nRank
    r = candidateRanks(ir);
    Ur = U(:,1:r);
    Vr = V(:,1:r);
    sr = svals(1:r);
    retainedCondition = sr(1)/max(sr(end),realmin('double'));
    for ia = 1:nRidge
        ic = ic+1;
        alpha = ridgeGrid(ia);
        lambda = alpha*sigmaRef2;
        if alpha == 0
            filter = 1./sr;
        else
            filter = sr./(sr.^2 + lambda);
        end
        G = (dZtr*Vr) * diag(filter) * Ur';
        if opt.enforceConstantObservableDerivative
            G(liftSpec.constantObservableIndex,:) = 0;
        end
        [A,B] = unpack_G(G,M,nForce);

        dZhatTr = eval_lifted_generator(A,B,Ztr,Qtr);
        dZhatVa = eval_lifted_generator(A,B,Zva,Qva);
        YhatTr = Cdot*dZhatTr;
        YhatVa = Cdot*dZhatVa;

        rankUsed(ic) = r;
        ridgeRelative(ic) = alpha;
        ridgeLambda(ic) = lambda;
        retainedConditionNumber(ic) = retainedCondition;
        effectiveDegreesOfFreedom(ic) = sum(sr.^2./(sr.^2 + lambda));
        noiseAmplificationProxy(ic) = sqrt(sum(filter.^2));
        trainScaledMSE(ic) = scaled_mse(YhatTr,Ytr,outputScale);
        valScaledMSE(ic) = scaled_mse(YhatVa,Yva,outputScale);
        [trajMean,trajStd,trajSE,trajErr] = trajectory_scaled_mse( ...
            YhatVa,Yva,outputScale,trajVa,valIds);
        valTrajectoryMeanScaledMSE(ic) = trajMean;
        valTrajectoryStdScaledMSE(ic) = trajStd;
        valTrajectorySEScaledMSE(ic) = trajSE;
        validationTrajectoryErrors(ic,:) = trajErr(:).';
        trainLiftScaledMSE(ic) = scaled_mse(dZhatTr,dZtr,liftScale);
        valLiftScaledMSE(ic) = scaled_mse(dZhatVa,dZva,liftScale);
        try
            spectralAbscissa(ic) = max(real(eig(A)));
        catch
            spectralAbscissa(ic) = inf;
        end
        stableCandidate(ic) = isfinite(spectralAbscissa(ic)) && ...
            spectralAbscissa(ic) <= opt.maxAutonomousRealPart;
        models{ic} = struct('A',A,'B',B);
    end
end

finiteMask = isfinite(valTrajectoryMeanScaledMSE);
if ~any(finiteMask)
    error('fit_koopman_bilinear_module:NoFiniteCandidate', ...
        'Every regularized continuous KBF candidate produced non-finite validation error.');
end
eligible = finiteMask & stableCandidate;
if ~any(eligible)
    eligible = finiteMask;
end

% Primary criterion: held-out pointwise vector-field error aggregated by
% COMPLETE validation trajectory. This remains a vector-field validation
% procedure; no trajectory rollout is used. The trajectory grouping is used
% only to estimate the uncertainty of the validation error.
[bestVal,bestLocal] = min(valTrajectoryMeanScaledMSE(eligible));
eligibleIdx = find(eligible);
bestIndexForBand = eligibleIdx(bestLocal);
bestSE = valTrajectorySEScaledMSE(bestIndexForBand);
if ~isfinite(bestSE), bestSE = 0; end

selectionRule = lower(string(opt.selectionRule));
switch selectionRule
    case "one_se_effective_df"
        uncertaintyBand = opt.oneSEMultiplier*bestSE;
        relativeFloorBand = opt.oneSERelativeFloor * ...
            max(bestVal,opt.validationAbsoluteTolerance);
        selectionBand = max([opt.validationAbsoluteTolerance, ...
            uncertaintyBand,relativeFloorBand]);
        nearBest = eligible & ...
            (valTrajectoryMeanScaledMSE <= bestVal + selectionBand);
        selectable = find(nearBest);
        if isempty(selectable), selectable = eligibleIdx; end

        % Standard one-SE logic: among candidates whose validation accuracy is
        % statistically indistinguishable from the best, choose the candidate
        % with the smallest effective degrees of freedom. This treats rank and
        % ridge as one common complexity mechanism. If effective complexity is
        % tied numerically, prefer the smaller inverse-noise amplification,
        % then the lower validation error.
        minDf = min(effectiveDegreesOfFreedom(selectable));
        dfTol = 1e-10*max(1,abs(minDf));
        selectable = selectable( ...
            effectiveDegreesOfFreedom(selectable) <= minDf + dfTol);
        if numel(selectable) > 1
            minAmp = min(noiseAmplificationProxy(selectable));
            ampTol = 1e-10*max(1,abs(minAmp));
            selectable = selectable( ...
                noiseAmplificationProxy(selectable) <= minAmp + ampTol);
        end
        if numel(selectable) > 1
            [~,jj] = min(valTrajectoryMeanScaledMSE(selectable));
            selectedIndex = selectable(jj);
        else
            selectedIndex = selectable(1);
        end

    case "legacy_relative_tolerance"
        tol = opt.validationAbsoluteTolerance + ...
            opt.preferSimplerWithinRelativeValidationTolerance* ...
            max(bestVal,opt.validationAbsoluteTolerance);
        selectionBand = tol;
        nearBest = eligible & (valTrajectoryMeanScaledMSE <= bestVal + tol);
        selectable = find(nearBest);
        if isempty(selectable), selectable = eligibleIdx; end
        minRank = min(rankUsed(selectable));
        selectable = selectable(rankUsed(selectable)==minRank);
        if numel(selectable) > 1
            maxRidge = max(ridgeRelative(selectable));
            selectable = selectable(ridgeRelative(selectable)==maxRidge);
        end
        if numel(selectable) > 1
            [~,jj] = min(valTrajectoryMeanScaledMSE(selectable));
            selectedIndex = selectable(jj);
        else
            selectedIndex = selectable(1);
        end

    otherwise
        error('fit_koopman_bilinear_module:SelectionRule', ...
            'Unsupported selection rule: %s',char(selectionRule));
end

withinSelectionBand = eligible & ...
    (valTrajectoryMeanScaledMSE <= bestVal + selectionBand);

selectedRank = rankUsed(selectedIndex);
selectedRidgeRelative = ridgeRelative(selectedIndex);
selectedRidgeLambda = ridgeLambda(selectedIndex);
selected = models{selectedIndex};

module = struct();
module.type = 'bilinear_koopman_kbf_module';
module.formulationVersion = char(opt.formulationVersion);
module.deviceType = char(data.deviceType);
module.deviceIndex = data.deviceIndex;
module.bus = data.bus;
module.stateIndices = data.stateIndices(:);
module.forceNames = string(data.forceNames(:));
module.stateNames = stateNames;
module.stateMean = stateMean(:);
module.stateStd = stateStd(:);
module.forceMean = forceMean(:);
module.forceStd = forceStd(:);
module.liftingMode = char(opt.liftingMode);
module.polyOrder = opt.polyOrder;
module.liftSpec = liftSpec;
module.observableNames = observableNames(:);
module.linearObservableIndices = linearIdx;
module.observableCount = M;
module.forceCount = nForce;
module.A = selected.A;
module.B = selected.B;
module.Cdot = Cdot;
module.identificationForm = char(opt.identificationForm);
module.rolloutForm = char(opt.rolloutForm);
module.selectedRank = selectedRank;
module.selectedRidgeRelative = selectedRidgeRelative;
module.selectedRidgeLambda = selectedRidgeLambda;
module.selectedEffectiveDegreesOfFreedom = effectiveDegreesOfFreedom(selectedIndex);
module.selectedNoiseAmplificationProxy = noiseAmplificationProxy(selectedIndex);
module.selectionRule = char(selectionRule);
module.validationBestMeanScaledMSE = bestVal;
module.validationBestSEScaledMSE = bestSE;
module.validationSelectionBand = selectionBand;
module.numericalRank = numericalRank;
module.maxCandidateRank = rMax;
module.regressionDimension = regressionDimension;
module.rankReferenceDimension = rankReferenceDimension;
module.rankNominalFloor = rankNominalFloor;
module.rankNominalCeiling = rankNominalCeiling;
module.nominalCandidateRanks = nominalCandidateRanks(:);
module.constantObservableDerivativeEnforced = opt.enforceConstantObservableDerivative;

rankSweep = table(rankUsed,ridgeRelative,ridgeLambda,retainedConditionNumber, ...
    effectiveDegreesOfFreedom,noiseAmplificationProxy, ...
    trainScaledMSE,valScaledMSE,valTrajectoryMeanScaledMSE, ...
    valTrajectoryStdScaledMSE,valTrajectorySEScaledMSE, ...
    trainLiftScaledMSE,valLiftScaledMSE,spectralAbscissa,stableCandidate, ...
    withinSelectionBand, ...
    'VariableNames',{'Rank','RidgeRelative','RidgeLambda','RetainedConditionNumber', ...
    'EffectiveDegreesOfFreedom','NoiseAmplificationProxy', ...
    'TrainVectorFieldScaledMSE','ValidationVectorFieldScaledMSE', ...
    'ValidationTrajectoryMeanScaledMSE','ValidationTrajectoryStdScaledMSE', ...
    'ValidationTrajectorySEScaledMSE','TrainLiftDerivativeScaledMSE', ...
    'ValidationLiftDerivativeScaledMSE','AutonomousSpectralAbscissa', ...
    'StableCandidate','WithinSelectionBand'});

info = struct();
info.deviceType = char(data.deviceType);
info.deviceIndex = data.deviceIndex;
info.bus = data.bus;
info.formulationVersion = char(opt.formulationVersion);
info.observableCount = M;
info.forceCount = nForce;
info.selectedRank = selectedRank;
info.selectedRidgeRelative = selectedRidgeRelative;
info.selectedRidgeLambda = selectedRidgeLambda;
info.selectedEffectiveDegreesOfFreedom = effectiveDegreesOfFreedom(selectedIndex);
info.selectedNoiseAmplificationProxy = noiseAmplificationProxy(selectedIndex);
info.selectionRule = char(selectionRule);
info.validationBestMeanScaledMSE = bestVal;
info.validationBestSEScaledMSE = bestSE;
info.validationSelectionBand = selectionBand;
info.validationTrajectoryMeanScaledMSE = valTrajectoryMeanScaledMSE(selectedIndex);
info.validationTrajectoryStdScaledMSE = valTrajectoryStdScaledMSE(selectedIndex);
info.validationTrajectorySEScaledMSE = valTrajectorySEScaledMSE(selectedIndex);
info.validationTrajectoryErrorsScaledMSE = validationTrajectoryErrors(selectedIndex,:).';
info.numericalRank = numericalRank;
info.maxCandidateRank = rMax;
info.regressionDimension = regressionDimension;
info.rankReferenceDimension = rankReferenceDimension;
info.rankNominalFloor = rankNominalFloor;
info.rankNominalCeiling = rankNominalCeiling;
info.nominalCandidateRanks = nominalCandidateRanks(:);
info.trainVectorFieldScaledMSE = trainScaledMSE(selectedIndex);
info.validationVectorFieldScaledMSE = valScaledMSE(selectedIndex);
info.trainLiftDerivativeScaledMSE = trainLiftScaledMSE(selectedIndex);
info.validationLiftDerivativeScaledMSE = valLiftScaledMSE(selectedIndex);
info.autonomousSpectralAbscissa = spectralAbscissa(selectedIndex);
info.selectedStableCandidate = stableCandidate(selectedIndex);
info.retainedConditionNumber = retainedConditionNumber(selectedIndex);
info.rankSweep = rankSweep;
info.trainSampleCount = nnz(trainMask);
info.validationSampleCount = nnz(valMask);
info.polyOrder = opt.polyOrder;
info.liftingMode = char(opt.liftingMode);
info.identificationForm = char(opt.identificationForm);
info.rolloutForm = char(opt.rolloutForm);

if opt.verbose
    fprintf(['      %s%d | CT M-KBF Eq.(16) | lift=%d | forcing=%d | rank=%d ', ...
        '| fixed rank ref=%d | usable rank=%d | ridge=%.1e ', ...
        '| val VF mean=%.3e +/- SE %.2e | one-SE band=%.2e ', ...
        '| effDF=%.2f | amp=%.3e | maxReEig(A)=%.4g 1/s\n'], ...
        upper(char(data.deviceType)),data.deviceIndex,M,nForce,selectedRank, ...
        rankReferenceDimension,rMax,selectedRidgeRelative, ...
        info.validationTrajectoryMeanScaledMSE, ...
        info.validationTrajectorySEScaledMSE,selectionBand, ...
        info.selectedEffectiveDegreesOfFreedom, ...
        info.selectedNoiseAmplificationProxy,info.autonomousSpectralAbscissa);
end
end

function [Z,dZ,Q] = lifted_generator_data(X,F,Y,stateMean,stateStd,forceMean,forceStd,opt,liftSpec,stateNames)
S = (X-stateMean)./stateStd;
Sdot = Y./stateStd;
Q = (F-forceMean)./forceStd;
[Z,~,~,dZ] = build_koopman_monomial_lift(S,stateNames,opt.polyOrder,liftSpec,Sdot);
end

function R = build_bilinear_regression(Z,Q)
R = Z;
for i = 1:size(Q,1)
    R = [R; Z.*Q(i,:)]; %#ok<AGROW>
end
end

function [A,B] = unpack_G(G,M,nForce)
if size(G,2) ~= M*(1+nForce)
    error('fit_koopman_bilinear_module:RegressionWidth','Unexpected KBF regression width.');
end
A = G(:,1:M);
B = zeros(M,M,nForce);
for i = 1:nForce
    cols = M*i + (1:M);
    B(:,:,i) = G(:,cols);
end
end

function dZhat = eval_lifted_generator(A,B,Z,Q)
dZhat = A*Z;
for i = 1:size(Q,1)
    dZhat = dZhat + (B(:,:,i)*Z).*Q(i,:);
end
end

function scale = robust_scale(X,floorValue)
scale = std(X,0,2);
rmsVal = sqrt(mean(X.^2,2));
scale = max(scale,0.05*rmsVal);
scale = max(scale,floorValue);
end

function val = scaled_mse(Yhat,Ytrue,scale)
E = (Yhat-Ytrue)./scale;
if any(~isfinite(E(:)))
    val = inf;
else
    val = mean(E(:).^2);
end
end

function [meanErr,stdErr,seErr,errors] = trajectory_scaled_mse( ...
    Yhat,Ytrue,scale,trajectoryIds,validationIds)
%TRAJECTORY_SCALED_MSE Validation error statistics across complete trajectories.
validationIds = validationIds(:).';
errors = nan(numel(validationIds),1);
for k = 1:numel(validationIds)
    mask = trajectoryIds == validationIds(k);
    if any(mask)
        errors(k) = scaled_mse(Yhat(:,mask),Ytrue(:,mask),scale);
    end
end
finite = isfinite(errors);
if ~any(finite)
    meanErr = inf;
    stdErr = inf;
    seErr = inf;
    return;
end
q = errors(finite);
meanErr = mean(q);
if numel(q) >= 2
    stdErr = std(q,0);
    seErr = stdErr/sqrt(numel(q));
else
    % Inter-trajectory uncertainty is not estimable from one trajectory.
    % The one-SE selector therefore relies on oneSERelativeFloor in this case.
    stdErr = 0;
    seErr = 0;
end
end

function [ranks,nominalRanks,rNominalMin,rNominalCeil] = ...
    make_candidate_ranks(rankReferenceDimension,rMax,opt)
% Build the SVD-rank grid from a FIXED regression-dimension reference.
%
% rankReferenceDimension = M*(1+nForce) for a given DER module and therefore
% does not change with N. This makes the candidate-capacity grid comparable
% across the sample-size sweep. The current sample set can still impose a
% smaller usable numerical rank rMax; nominal candidates above rMax are then
% clipped to rMax and duplicates are removed.
%
% rankCandidateCount controls grid resolution only; it is not itself a rank.
rNominalMin = max(1,min(rankReferenceDimension, ...
    round(opt.rankFractionFloor*rankReferenceDimension)));
rNominalCeil = max(rNominalMin,min(rankReferenceDimension, ...
    round(opt.rankFractionCeiling*rankReferenceDimension)));
if rNominalMin == rNominalCeil
    nominalRanks = rNominalCeil;
else
    % Quadratic spacing keeps more resolution in the low-rank region while
    % preserving one fixed nominal grid for every sample size.
    t = linspace(0,1,opt.rankCandidateCount);
    nominalRanks = round(rNominalMin + (rNominalCeil-rNominalMin)*(t.^2));
    nominalRanks = unique([nominalRanks(:); rNominalCeil]);
    nominalRanks = nominalRanks(nominalRanks>=rNominalMin & ...
        nominalRanks<=rNominalCeil);
end

% Enforce the sample-dependent usable-rank limit only after the fixed grid
% has been constructed. Thus increasing N can reveal additional high-rank
% members of the SAME underlying candidate grid instead of redefining it.
ranks = min(nominalRanks(:),rMax);
if opt.alwaysIncludeFullUsableRank
    ranks = [ranks(:); rMax];
end
ranks = unique(ranks,'stable');
ranks = ranks(ranks>=1 & ranks<=rMax);
if isempty(ranks)
    ranks = rMax;
end
end
