function [module,info] = train_node_module(data,trainIds,valIds,cfg,seedOffset)
%TRAIN_NODE_MODULE Train one controlled DER Neural ODE with trajectory loss.
%
% Runtime policy used by the manuscript baseline:
%   * fit normalization from the original training trajectories;
%   * retain every observed training sample, but split each long training
%     trajectory into shorter non-overlapping windows before adjoint training;
%   * validate on the ORIGINAL full held-out trajectories;
%   * keep maxEpochs as a cap and stop only when validation has made no
%     meaningful relative progress for validationPatienceChecks checks.

opt = cfg.node;
if numel(opt.hiddenSizes) ~= 2
    error('train_node_module:HiddenSizes', ...
        'Current NODE implementation expects exactly two hidden sizes.');
end

% Backward-compatible defaults for older configs.
if ~isfield(opt,'trainingWindowPoints') || isempty(opt.trainingWindowPoints)
    opt.trainingWindowPoints = data.nTimes;
end
if ~isfield(opt,'earlyStopping') || ~isstruct(opt.earlyStopping)
    opt.earlyStopping = struct();
end
if ~isfield(opt.earlyStopping,'minRelativeImprovement') || ...
        isempty(opt.earlyStopping.minRelativeImprovement)
    opt.earlyStopping.minRelativeImprovement = 1e-6;
end
minRelImprove = double(opt.earlyStopping.minRelativeImprovement);
if ~isscalar(minRelImprove) || ~isfinite(minRelImprove) || ...
        minRelImprove < 0 || minRelImprove >= 1
    error('train_node_module:MinRelativeImprovement', ...
        'cfg.node.earlyStopping.minRelativeImprovement must be in [0,1).');
end

% Fit normalizers using ORIGINAL TRAIN trajectories only. Windowing is a
% numerical training device; it must not alter which observations determine
% normalization statistics.
[stateMu,stateStd] = fit_channel_normalizer(data.xObserved(:,trainIds,:), ...
    opt.normalization);
[forceMu,forceStd] = fit_channel_normalizer(data.forcing(:,trainIds,:), ...
    opt.normalization);

XN = normalize_channels(data.xObserved,stateMu,stateStd);
FN = normalize_channels(data.forcing,forceMu,forceStd);

tspanValidation = double(data.t(:).');
[XNtrain,FNtrain,tspanTrain,windowInfo] = build_training_windows( ...
    XN,FN,trainIds,tspanValidation,opt.trainingWindowPoints);

inputDim = data.nState + data.nForce;
outputDim = data.nState;

bestRestartLoss = inf;
bestParams = [];
bestRestart = NaN;
restartTime = nan(opt.numRestarts,1);
restartValLoss = inf(opt.numRestarts,1);
restartEpochs = zeros(opt.numRestarts,1);
restartBadChecks = zeros(opt.numRestarts,1);

for r = 1:opt.numRestarts
    rng(opt.restartSeed + seedOffset + 1000*(r-1),'twister');
    params = initialize_params(inputDim,outputDim,opt.hiddenSizes);
    averageGrad = [];
    averageSqGrad = [];
    iteration = 0;

    % bestLocal* preserves the numerically best validation model.  The
    % separate progressReferenceLoss controls patience so tiny improvements
    % do not reset early stopping indefinitely.
    bestLocalLoss = inf;
    bestLocalParams = params;
    progressReferenceLoss = inf;
    badChecks = 0;
    epochCompleted = 0;
    tRestart = tic;

    for epoch = 1:opt.maxEpochs
        epochCompleted = epoch;
        ids = randperm(windowInfo.nTrainingWindows);
        lr = opt.initialLearnRate * ...
            opt.learnRateDropFactor^floor((epoch-1)/opt.learnRateDropPeriodEpochs);

        for ib = 1:opt.miniBatchTrajectories:numel(ids)
            batchIds = ids(ib:min(ib+opt.miniBatchTrajectories-1,numel(ids)));
            X0 = dlarray(single(XNtrain(:,batchIds,1)));
            targets = dlarray(single(XNtrain(:,batchIds,2:end)));
            forcingN = single(FNtrain(:,batchIds,:));

            iteration = iteration + 1;
            [loss,gradients] = dlfeval(@node_model_loss,params,tspanTrain,X0, ...
                targets,forcingN,opt);
            if ~isfinite(double(gather(extractdata(loss))))
                error('train_node_module:NonfiniteLoss', ...
                    'Non-finite NODE training loss encountered.');
            end
            [params,averageGrad,averageSqGrad] = adamupdate( ...
                params,gradients,averageGrad,averageSqGrad,iteration,lr, ...
                opt.gradientDecayFactor,opt.squaredGradientDecayFactor);
        end

        doValidation = mod(epoch,opt.validationFrequencyEpochs)==0 || ...
            epoch==1 || epoch==opt.maxEpochs;
        if doValidation
            % Validation deliberately remains on the original full-length
            % held-out trajectories. Thus truncated optimization windows do
            % not make the model-selection criterion easier.
            if isempty(valIds)
                valLoss = node_validation_loss(params,tspanValidation,XN,FN,trainIds,opt);
            else
                valLoss = node_validation_loss(params,tspanValidation,XN,FN,valIds,opt);
            end

            % Always preserve the truly best model seen so far.
            if valLoss < bestLocalLoss
                bestLocalLoss = valLoss;
                bestLocalParams = params;
            end

            % Patience resets only after a meaningful relative improvement.
            if ~isfinite(progressReferenceLoss) || ...
                    valLoss < progressReferenceLoss*(1-minRelImprove)
                progressReferenceLoss = valLoss;
                badChecks = 0;
            else
                badChecks = badChecks + 1;
            end

            if opt.verbose
                fprintf(['      NODE %s%d restart %d | epoch %d/%d | ', ...
                    'val MSE %.4e | patience %d/%d\n'], ...
                    upper(char(data.deviceType)),data.deviceIndex,r,epoch, ...
                    opt.maxEpochs,valLoss,badChecks,opt.validationPatienceChecks);
            end
            if badChecks >= opt.validationPatienceChecks
                if opt.verbose
                    fprintf(['      NODE %s%d restart %d early stop at epoch %d: ', ...
                        'no >= %.3g%% relative validation improvement for %d checks.\n'], ...
                        upper(char(data.deviceType)),data.deviceIndex,r,epoch, ...
                        100*minRelImprove,opt.validationPatienceChecks);
                end
                break;
            end
        end
    end

    restartTime(r) = toc(tRestart);
    restartValLoss(r) = bestLocalLoss;
    restartEpochs(r) = epochCompleted;
    restartBadChecks(r) = badChecks;
    if bestLocalLoss < bestRestartLoss
        bestRestartLoss = bestLocalLoss;
        bestParams = bestLocalParams;
        bestRestart = r;
    end
end

if isempty(bestParams) || ~isfinite(bestRestartLoss)
    error('train_node_module:AllRestartsFailed', ...
        'No valid NODE restart was obtained for %s%d.', ...
        char(data.deviceType),data.deviceIndex);
end

% Persist only ordinary numeric network coefficients. No dlarray training
% state, Adam moments, or adjoint graph is allowed to escape this function.
module.deviceType = data.deviceType;
module.deviceIndex = data.deviceIndex;
module.stateIndices = data.stateIndices;
module.bus = data.bus;
module.stateMean = stateMu;
module.stateStd = stateStd;
module.forceMean = forceMu;
module.forceStd = forceStd;
module.forceNames = data.forceNames;
module.numeric = numeric_params(bestParams);
module.hiddenSizes = opt.hiddenSizes;
module.trainingGradientMode = opt.gradientMode;
module.trainingWindowPoints = windowInfo.windowPoints;
module.trainingWindowsPerTrajectory = windowInfo.windowsPerTrajectory;

info.deviceType = data.deviceType;
info.deviceIndex = data.deviceIndex;
info.nState = data.nState;
info.nForce = data.nForce;
info.nTrainTrajectories = numel(trainIds);
info.nValidationTrajectories = numel(valIds);
info.nOriginalPointsPerTrajectory = data.nTimes;
info.trainingWindowPoints = windowInfo.windowPoints;
info.trainingWindowsPerTrajectory = windowInfo.windowsPerTrajectory;
info.nTrainingWindows = windowInfo.nTrainingWindows;
info.trainingWindowDurationSeconds = windowInfo.durationSeconds;
info.trainingUsesAllOriginalSamples = windowInfo.usesAllSamples;
info.trainingWindowMode = 'nonoverlapping_all_samples';
info.validationUsesOriginalFullTrajectories = true;
info.minRelativeValidationImprovement = minRelImprove;
info.selectedRestart = bestRestart;
info.bestValidationTrajectoryMSE_normalized = bestRestartLoss;
info.restartValidationLoss = restartValLoss;
info.restartTrainingTimeSec = restartTime;
info.restartEpochs = restartEpochs;
info.restartFinalBadChecks = restartBadChecks;
info.parameterCount = count_params(module.numeric);
end

function [XW,FW,tspanW,info] = build_training_windows(XN,FN,trainIds,tspan,windowPoints)
%BUILD_TRAINING_WINDOWS Split only NODE optimization trajectories.
%
% The current formal dataset uses 50 points/trajectory. With windowPoints=25,
% each original training trajectory becomes two independent 25-point windows.
% Every observed sample is retained exactly once; only the single transition
% crossing a window boundary is intentionally excluded from the multi-step
% loss. Validation remains on the original full trajectories.

L = size(XN,3);
windowPoints = round(double(windowPoints));
if ~isscalar(windowPoints) || ~isfinite(windowPoints) || windowPoints < 2
    error('train_node_module:TrainingWindowPoints', ...
        'cfg.node.trainingWindowPoints must be an integer >= 2.');
end
if windowPoints > L
    error('train_node_module:TrainingWindowTooLong', ...
        'trainingWindowPoints=%d exceeds points/trajectory=%d.',windowPoints,L);
end
if mod(L,windowPoints) ~= 0
    error('train_node_module:TrainingWindowDoesNotTile', ...
        ['To preserve every original NODE training sample without padding or ', ...
         'deletion, points/trajectory=%d must be divisible by ', ...
         'trainingWindowPoints=%d.'],L,windowPoints);
end

nPer = L/windowPoints;
nTrain = numel(trainIds);
nWindows = nTrain*nPer;
XW = zeros(size(XN,1),nWindows,windowPoints,'like',XN);
FW = zeros(size(FN,1),nWindows,windowPoints,'like',FN);

q = 0;
for itraj = 1:nTrain
    tr = trainIds(itraj);
    for iw = 1:nPer
        q = q + 1;
        jj = (iw-1)*windowPoints + (1:windowPoints);
        XW(:,q,:) = XN(:,tr,jj);
        FW(:,q,:) = FN(:,tr,jj);
    end
end

if numel(tspan) < 2
    error('train_node_module:TrainingTimeGrid', ...
        'NODE training requires at least two trajectory time points.');
end
dt = double(tspan(2)-tspan(1));
% The learned controlled vector field has no explicit absolute-time input;
% only forcing interpolation uses t. Therefore every truncated window can use
% the same local time origin without changing the learned dynamics.
tspanW = (0:windowPoints-1)*dt;

info = struct();
info.windowPoints = windowPoints;
info.windowsPerTrajectory = nPer;
info.nTrainingWindows = nWindows;
info.durationSeconds = (windowPoints-1)*dt;
info.usesAllSamples = (q*windowPoints == nTrain*L);
end

function [mu,sigma] = fit_channel_normalizer(A,opt)
% A is [channel, trajectory, time].
C = size(A,1);
B = reshape(permute(A,[1 3 2]),C,[]);
mu = mean(B,2);
sigma = std(B,0,2);
rmsScale = sqrt(mean(B.^2,2));
reference = max([abs(mu),rmsScale,ones(C,1)],[],2);
floorValue = max(opt.absoluteFloor,opt.relativeFloor*reference);
sigma = max(sigma,floorValue);
end

function Y = normalize_channels(A,mu,sigma)
Y = (A-reshape(mu,[],1,1))./reshape(sigma,[],1,1);
end

function params = initialize_params(inputDim,outputDim,hiddenSizes)
params.fc1.Weights = dlarray(glorot(hiddenSizes(1),inputDim));
params.fc1.Bias = dlarray(zeros(hiddenSizes(1),1,'single'));
params.fc2.Weights = dlarray(glorot(hiddenSizes(2),hiddenSizes(1)));
params.fc2.Bias = dlarray(zeros(hiddenSizes(2),1,'single'));
params.fcOut.Weights = dlarray(glorot(outputDim,hiddenSizes(2)));
params.fcOut.Bias = dlarray(zeros(outputDim,1,'single'));
end

function W = glorot(nOut,nIn)
limit = sqrt(6/(nIn+nOut));
W = single((2*rand(nOut,nIn)-1)*limit);
end

function p = numeric_params(params)
p.W1 = double(gather(extractdata(params.fc1.Weights)));
p.b1 = double(gather(extractdata(params.fc1.Bias)));
p.W2 = double(gather(extractdata(params.fc2.Weights)));
p.b2 = double(gather(extractdata(params.fc2.Bias)));
p.Wout = double(gather(extractdata(params.fcOut.Weights)));
p.bout = double(gather(extractdata(params.fcOut.Bias)));
end

function n = count_params(p)
n = numel(p.W1)+numel(p.b1)+numel(p.W2)+numel(p.b2)+ ...
    numel(p.Wout)+numel(p.bout);
end
