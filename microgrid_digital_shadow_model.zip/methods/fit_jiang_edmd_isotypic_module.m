function [module,info] = fit_jiang_edmd_isotypic_module(data,portParameters,trainIds,valIds,opt)
%FIT_JIANG_EDMD_ISOTYPIC_MODULE Isotypic q=-1 discrete EDMD for a local DER.
%
% The 2024 TSG paper uses isotypic observables and discrete-time bilinear
% EDMD: GFL explicit / GFM implicit, with SVD order truncation. Here SG is
% an explicitly documented source-type extension; the GFM uses a phase-
% equivariant observable (not the original paper's dynamic terminal-voltage
% output). The network coupling and original states remain unchanged.
%
% Unlike the old CT-M-KBF code, this training DOES NOT access data.xdot.

X = double(data.x);
R = double(data.forcing);
traj = double(data.trajectoryId(:).');
point = double(data.pointInTrajectory(:).');
assert(size(X,2)==numel(traj) && size(X,2)==numel(point));
if size(X,1)<2, error('jiang_fit:States','Need phase plus other states.'); end
L = numel(point);
idx=find(traj(1:end-1)==traj(2:end) & point(2:end)==point(1:end-1)+1);
left=idx;
right=idx+1;
trainPairs = ismember(traj(left),trainIds) & ismember(traj(right),trainIds);
valPairs = ismember(traj(left),valIds) & ismember(traj(right),valIds);
if nnz(trainPairs)<4 || nnz(valPairs)<1
    error('jiang_fit:Pairs','Insufficient paired snapshots after split.');
end
trainSamples=ismember(traj,trainIds);
stateMean=mean(X(2:end,trainSamples),2);
stateStd=robust_real_scale(X(2:end,trainSamples),opt.normalizationFloor);
H=(X(2:end,:)-stateMean)./stateStd;

% GFM/SG: paper-inspired q=-1 phase lift with known port transformation.
% GFL: q=-1 phase lift and paper's two complex invariant forcing channels.
V=R(1,:)+1i*R(2,:);
Qraw=build_koopman_isotypic_forcing(data.deviceType,X,V,R(3:end,:),portParameters,opt);
if any(~isfinite(Qraw(:)))
    error('jiang_fit:Forcing','Nonfinite isotypic forcing.');
end
qMean=mean(Qraw(:,trainSamples),2);
qStd=sqrt(mean(abs(Qraw(:,trainSamples)-qMean).^2,2));
qStd=max(qStd,opt.normalizationFloor);
Q=(Qraw-qMean)./qStd;

[z,observableNames,liftSpec]=build_koopman_isotypic_lift( ...
    X(1,:),H,string(data.stateNames(2:end)),opt.polyOrder,[],[],[], ...
    string(data.stateNames(1)));
M=size(z,1); nq=size(Q,1);
Z1=z(:,left); Z2=z(:,right); qPairs=Q(:,left); qNext=Q(:,right);
trIn=find(trainPairs); vaIn=find(valPairs);

isImplicit=~strcmpi(char(string(data.deviceType)),'gfl');
if isImplicit
    % Jiang 2024 Eq.(28b), adapted to SG and reduced GFM.
    regression=make_regression(Z1(:,trIn),Z2(:,trIn),qNext(:,trIn));
else
    % Jiang 2024 Eq.(28a): explicit, endpoint forcing q_(k+1).
    regression=make_regression(Z1(:,trIn),Z1(:,trIn),qNext(:,trIn));
end
[U,S,Vsvd]=svd(regression,'econ');
sig=diag(S);
if isempty(sig) || sig(1)<=0 || ~isfinite(sig(1))
    error('jiang_fit:Rank','Degenerate EDMD regression.');
end
usableRank=nnz(sig>=sig(1)*opt.singularRelativeFloor);
usableRank=min([usableRank,size(U,2),size(Vsvd,2)]);
maxRank=max(1,min(usableRank,floor(opt.maxRankFraction*size(regression,1))));
if maxRank<1,error('jiang_fit:RankZero','No usable SVD directions.');end
ranks=unique(round(linspace(min(opt.minRank,maxRank),maxRank,opt.rankCandidateCount)),'stable');
ranks=unique([ranks maxRank]);
if all(ranks<1),error('jiang_fit:CandidateRank','Empty rank sweep');end
ridge=unique(double(opt.ridgeRelativeGrid(:).'),'stable');

nCandidates=numel(ranks)*numel(ridge);
Rank=zeros(nCandidates,1); Alpha=zeros(nCandidates,1);
ValidationMSE=inf(nCandidates,1);
SpectralGrowth=inf(nCandidates,1);
SpectralPatternCount=zeros(nCandidates,1);
SpectralEigenvalues=cell(nCandidates,1);
Store=cell(nCandidates,1);
idxCandidate=0;
Xvalidation=X(:,right(vaIn)); Xcurrent=X(:,left(vaIn));
% Validation error is on held-out state pairs, NOT on exact derivative labels.
scales=[max(std(X(1,trainSamples),0,2),opt.normalizationFloor);stateStd];
for ir=1:numel(ranks)
    rk=ranks(ir);
    Ur=U(:,1:rk); Vr=Vsvd(:,1:rk); sv=sig(1:rk);
    for ia=1:numel(ridge)
        idxCandidate=idxCandidate+1;
        alpha=ridge(ia);
        filter=sv./(sv.^2+alpha*sig(1)^2);
        G=(Z2(:,trIn)*Vr)*diag(filter)*Ur';
        Ad=G(:,1:M);
        Bd=reshape(G(:,M+1:end),M,M,nq);
        [lambda,growth,pattern]=spectrum_diagnostics(Ad); % discrete eigenvalue logs
        dt=read_dt(data);
        lambda=lambda./dt;
        growth=growth./dt;
        score=validation_score(Ad,Bd,Z1(:,vaIn),qPairs(:,vaIn), ...
            qNext(:,vaIn),Xcurrent,Xvalidation,scales,stateMean,stateStd,isImplicit);
        Rank(idxCandidate)=rk; Alpha(idxCandidate)=alpha;
        ValidationMSE(idxCandidate)=score;
        SpectralGrowth(idxCandidate)=growth;
        SpectralPatternCount(idxCandidate)=pattern;
        SpectralEigenvalues{idxCandidate}=lambda;
        Store{idxCandidate}=struct('Ad',Ad,'Bd',Bd);
    end
end

eligible=isfinite(ValidationMSE);
if ~any(eligible)
    error('jiang_fit:Validation','No candidate yields a finite one-step validation error.');
end
spectralAccept=eligible & SpectralGrowth <= opt.maxEigenGrowthRate;
if any(spectralAccept), eligible=spectralAccept; end
minMSE=min(ValidationMSE(eligible));
nearBest=eligible & ValidationMSE<=minMSE*(1+opt.uncertaintyRelativeBand)+1e-12;
choices=find(nearBest);
% Paper's eigen-pattern truncation criterion is qualitative rather than a
% published numeric algorithm. Here spectrum screens clearly unstable ranks,
% and validation picks the most accurate one; near-ties prefer fewer additive
% eigenvalue patterns followed by smaller SVD rank. This is an explicit,
% reproducible adaptation, not a claim to replicate the authors' rank choice.
[~,ii]=sortrows([SpectralPatternCount(choices),Rank(choices),ValidationMSE(choices)],[1 2 3]);
selected=choices(ii(1));
fit=Store{selected};
module=struct();
module.type='jiang_edmd_isotypic_module';
module.formulationVersion='jiang_isotypic_edmd_snapshot_v1';
module.deviceType=char(string(data.deviceType));
module.deviceIndex=data.deviceIndex;
module.bus=data.bus;
module.stateIndices=data.stateIndices(:);
module.stateNames=string(data.stateNames(:));
module.forceNames=string(data.forceNames(:));
module.forceCount=nq;
module.stateCount=size(X,1);
module.stateMean=stateMean;
module.stateStd=stateStd;
module.forceMean=qMean;
module.forceStd=qStd;
module.portParameters=portParameters;
module.liftSpec=liftSpec;
module.observableNames=observableNames;
module.observableCount=M;
module.polyOrder=opt.polyOrder;
module.liftingMode='isotypic_qminus1';
module.implicit=isImplicit;
module.Ad=fit.Ad;
module.Bd=fit.Bd;
module.dt=dt;
module.odeConversion=char(string(opt.odeConversion));
module.voltageDivisionFloor=opt.voltageDivisionFloor;
module.selectedRank=Rank(selected);
module.selectedRidgeRelative=Alpha(selected);
module.selectedRidgeLambda=Alpha(selected)*sig(1)^2;
module.selectedEffectiveDegreesOfFreedom=sum(sig(1:Rank(selected)).^2./ ...
    (sig(1:Rank(selected)).^2+module.selectedRidgeLambda));
module.selectedNoiseAmplificationProxy=NaN;
module.selectedValidationMSE=ValidationMSE(selected);
module.numericalRank=usableRank;
module.maxCandidateRank=maxRank;
module.regressionDimension=size(regression,1);
module.autonomousSpectralAbscissa=SpectralGrowth(selected);
module.spectralEigenvalues=SpectralEigenvalues{selected};
module.spectralPatternCount=SpectralPatternCount(selected);
module.modelBoundary='SG and reduced GFM adapted, GFL Jiang 2024-style isotypic';
module.rankSweep=table(Rank,Alpha,ValidationMSE,SpectralGrowth,SpectralPatternCount);

info=struct();
info.deviceType=module.deviceType;
info.deviceIndex=module.deviceIndex;
info.bus=module.bus;
info.formulationVersion=module.formulationVersion;
info.observableCount=M;
info.forceCount=nq;
info.selectedRank=module.selectedRank;
info.selectedRidgeRelative=module.selectedRidgeRelative;
info.selectedRidgeLambda=module.selectedRidgeLambda;
info.selectedEffectiveDegreesOfFreedom=module.selectedEffectiveDegreesOfFreedom;
info.selectedNoiseAmplificationProxy=NaN;
info.selectionRule='spectral_screen_one_step_validation';
info.validationBestMeanScaledMSE=module.selectedValidationMSE;
info.validationBestSEScaledMSE=NaN;
info.validationSelectionBand=opt.uncertaintyRelativeBand;
info.validationTrajectoryMeanScaledMSE=module.selectedValidationMSE;
info.validationTrajectoryStdScaledMSE=NaN;
info.validationTrajectorySEScaledMSE=NaN;
info.validationTrajectoryErrorsScaledMSE=nan(numel(valIds),1);
info.numericalRank=usableRank;
info.maxCandidateRank=maxRank;
info.regressionDimension=size(regression,1);
info.rankReferenceDimension=size(regression,1);
info.rankNominalFloor=min(ranks);
info.rankNominalCeiling=max(ranks);
info.nominalCandidateRanks=ranks(:);
info.trainVectorFieldScaledMSE=NaN;
info.validationVectorFieldScaledMSE=NaN;
info.trainLiftDerivativeScaledMSE=NaN;
info.validationLiftDerivativeScaledMSE=NaN;
info.autonomousSpectralAbscissa=module.autonomousSpectralAbscissa;
info.selectedStableCandidate=SpectralGrowth(selected)<=opt.maxEigenGrowthRate;
info.retainedConditionNumber=sig(1)/sig(Rank(selected));
info.rankSweep=module.rankSweep;
info.trainSampleCount=nnz(trainPairs);
info.validationSampleCount=nnz(valPairs);
info.polyOrder=opt.polyOrder;
info.liftingMode=module.liftingMode;
info.identificationForm='discrete_EDMD';
info.rolloutForm='discrete_increment_as_ode';
if opt.verbose
    fprintf(['    %s%d | EDMD q=-1 | M=%d Q=%d | rank=%d/%d ', ...
        '| ridge=%.1e | validation=%.4e | max Re(log eig)/dt=%.3g/s\n'], ...
        upper(module.deviceType),module.deviceIndex,M,nq, ...
        module.selectedRank,maxRank,module.selectedRidgeRelative, ...
        module.selectedValidationMSE,module.autonomousSpectralAbscissa);
end
end

function R=make_regression(Zold,Zforce,Q)
[M,N]=size(Zold);
nq=size(Q,1);
R=zeros(M*(1+nq),N,'like',Zold);
R(1:M,:)=Zold;
for k=1:nq
    R(M*k+(1:M),:)=Zforce.*Q(k,:);
end
end

function S=robust_real_scale(X,floorVal)
S=std(X,0,2);
S=max(S,floorVal);
end

function dt=read_dt(data)
% Data generated with fixed trajectory timestep, equal within each segment.
% The local data object explicitly carries its sampling interval.
if ~isfield(data,'sampleStep')
    error('jiang_fit:MissingDt','Dataset sampling interval is required.');
end
dt=double(data.sampleStep);
if dt<=0 || ~isfinite(dt),error('jiang_fit:DeltaT','Invalid sampling step.');end
end

function [lam,growth,nPattern]=spectrum_diagnostics(Ad)
mu=eig(Ad);
valid=isfinite(mu) & abs(mu)>1e-10;
lam=log(mu(valid));
if isempty(lam)
    growth=inf;
    nPattern=0;
    return;
end
growth=max(real(lam));
% Diagnostic only: near-additive eigenvalue frequencies (NOT a hard theorem
% that such modes are spurious). Avoid the trivial zero-eigenvalue pairs.
nPattern=0;
if numel(lam)<=250
    tol=1e-2*max(1,median(abs(lam)));
    for k=1:numel(lam)
        if abs(lam(k))<tol,continue;end
        for i=1:numel(lam)
            if i==k || abs(lam(i))<tol,continue;end
            remainder=lam(k)-lam(i);
            if abs(remainder)<tol,continue;end
            if any(abs(lam-remainder)<tol)
                nPattern=nPattern+1;break;
            end
        end
    end
end
end

function score=validation_score(Ad,Bd,Zold,Qold,Qnew,Xold,Xtrue,scales,mu,sigma,implicit)
N=size(Zold,2);
score=inf;
try
    Zh=zeros(size(Zold),'like',Zold);
    if ~implicit
        Zh=Ad*Zold;
        for k=1:size(Qnew,1)
            Zh=Zh+(Bd(:,:,k)*Zold).*Qnew(k,:);
        end
    else
        Eye=eye(size(Ad,1),'like',Ad);
        for i=1:N
            Bq=zeros(size(Ad),'like',Ad);
            for k=1:size(Qnew,1)
                Bq=Bq+Qnew(k,i)*Bd(:,:,k);
            end
            M=Eye-Bq;
            if rcond(M)<1e-12,return;end
            Zh(:,i)=M\(Ad*Zold(:,i));
        end
    end
    if any(~isfinite(Zh(:))),return;end
    % e^(j theta) is the first observable, remaining linear ones are H*e^(j theta).
    w0=Zold(1,:); w1=Zh(1,:);
    if any(abs(w1)<1e-8),return;end
    phaseNew=Xold(1,:)+angle(w1./w0);
    Hnew=real(Zh(2:1+numel(mu),:)./w1);
    Xhat=[phaseNew; mu+sigma.*Hnew];
    if any(~isfinite(Xhat(:))),return;end
    E=(Xhat-Xtrue)./scales;
    score=mean(abs(E(:)).^2);
catch
    score=inf;
end
end
