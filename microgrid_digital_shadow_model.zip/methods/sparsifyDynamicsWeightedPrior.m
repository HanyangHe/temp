function Xi = sparsifyDynamicsWeightedPrior(Theta,dXdt,lambda,n,featurePreference)
%SPARSIFYDYNAMICSWEIGHTEDPRIOR Prior-weighted extension of official SINDy STLSQ.
%
% This routine deliberately preserves the numerical procedure of the
% original Brunton-Proctor-Kutz sparsifyDynamics implementation:
%   1) initial least-squares solve with MATLAB backslash,
%   2) coefficient thresholding,
%   3) least-squares refit on the retained support,
%   4) exactly 10 sequential threshold/refit iterations.
%
% The only extension is a feature-specific sparsification threshold used by
% the prior-weighted variants:
%       lambda_j = lambda / featurePreference(j).
% Generic features have preference 1. Physics-prior features have preference
% w_p >= 1 and are therefore harder to remove. Setting all preferences to 1
% exactly recovers the support logic of the official sparsifyDynamics solver.

if nargin < 5 || isempty(featurePreference)
    featurePreference = ones(size(Theta,2),1);
end
featurePreference = featurePreference(:);
if numel(featurePreference) ~= size(Theta,2)
    error('sparsifyDynamicsWeightedPrior:PreferenceSize', ...
        'featurePreference must contain one value per library column.');
end
if any(~isfinite(featurePreference)) || any(featurePreference < 1)
    error('sparsifyDynamicsWeightedPrior:PreferenceValue', ...
        'All feature-preference weights must be finite and >= 1.');
end
if size(dXdt,2) ~= n
    error('sparsifyDynamicsWeightedPrior:OutputSize', ...
        'n must equal the number of columns in dXdt.');
end

% Official SINDy initial least-squares solve.
Xi = Theta\dXdt;

threshold = lambda./featurePreference;
threshold = repmat(threshold,1,n);

% Match the official solver: exactly 10 threshold/refit iterations.
for iter = 1:10 %#ok<NASGU>
    smallinds = (abs(Xi) < threshold);
    Xi(smallinds) = 0;
    for ind = 1:n
        biginds = ~smallinds(:,ind);
        if any(biginds)
            Xi(biginds,ind) = Theta(:,biginds)\dXdt(:,ind);
        else
            Xi(:,ind) = 0;
        end
    end
end
end
