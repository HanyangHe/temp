function [module,info] = fit_pnc_phi_comp_only_module(data,trainMask,valMask,opt,seed)
%FIT_PNC_PHI_COMP_ONLY_MODULE Strict compositional-only PNC diagnostic.
%
% Stage 1: fit PE-SINDy and freeze Xi_1.
%   H = Theta_PE(chi) * Xi_1
%
% Stage 2: build ONLY Phi_comp(chi,H), then identify one sparse readout.
%   xdot = Phi_comp(chi,H) * Xi_2
%
% No direct H bypass, no flat-PN skip, and no other layer-2 features are
% available. This is a diagnostic ablation, not the production PNC method.

if ~any(trainMask) || ~any(valMask)
    error('fit_pnc_phi_comp_only_module:EmptySplit', ...
        'Train and validation masks must both be nonempty.');
end

% Layer 1: identical PE-SINDy backbone used by production PNC.
[layer1,layer1Info] = fit_sindy_stlsq_module( ...
    data,trainMask,valMask,"physics",opt,"standard");
[Theta1,names1] = build_sindy_library( ...
    data.X,data.inputNames,data.deviceType,"physics",opt,layer1.librarySpec);
if numel(names1) ~= numel(layer1.libraryNames) || ...
        any(string(names1(:)) ~= string(layer1.libraryNames(:)))
    error('fit_pnc_phi_comp_only_module:Layer1LibraryOrder', ...
        'Rebuilt PE layer-1 library does not match the fitted ordering.');
end
H = Theta1*layer1.coefficients;
if size(H,2) ~= size(data.Y,2) || any(~isfinite(H),'all')
    error('fit_pnc_phi_comp_only_module:Layer1Output', ...
        'Frozen PE layer produced an invalid intermediate representation.');
end

Xtr = data.X(trainMask,:);
Xval = data.X(valMask,:);
Htr = H(trainMask,:);
Hval = H(valMask,:);
YtrRaw = data.Y(trainMask,:);
YvalRaw = data.Y(valMask,:);

[AtrRaw,names2,spec2] = build_pnc_phi_comp_only_library( ...
    Xtr,Htr,data.inputNames,data.outputNames,opt,seed,[]);
[AvalRaw,names2Val] = build_pnc_phi_comp_only_library( ...
    Xval,Hval,data.inputNames,data.outputNames,opt,seed,spec2);
if numel(names2Val) ~= numel(names2) || ...
        any(string(names2Val(:)) ~= string(names2(:)))
    error('fit_pnc_phi_comp_only_module:Layer2LibraryOrder', ...
        'Training and validation Phi_comp-only libraries have inconsistent ordering.');
end

colScale = sqrt(mean(AtrRaw.^2,1));
colScale = max(colScale,opt.normalization.libraryScaleFloor);
yScale = std(YtrRaw,0,1);
yRms = sqrt(mean(YtrRaw.^2,1));
yScale = max(yScale,0.05*yRms);
yScale = max(yScale,opt.normalization.outputScaleFloor);

Atr = AtrRaw./colScale;
Aval = AvalRaw./colScale;
Btr = YtrRaw./yScale;
Bval = YvalRaw./yScale;

[supportRidgeApplied,supportRidgeConfigured,supportRidgePolicy] = ...
    should_apply_sindy_support_ridge(opt,data);
if supportRidgeApplied
    ridgeGrid = unique(double(opt.stlsq.supportRidge.relativeAlphaGrid(:).'),'stable');
else
    ridgeGrid = 0;
end
lambdas = unique(sort(opt.stlsq.thresholdGrid(:)),'stable');

resultTemplate = struct('lambda',NaN,'supportRidgeRelativeAlpha',NaN, ...
    'trainNormalizedMSE',NaN,'validationNormalizedMSE',NaN, ...
    'activeCoefficientCount',NaN,'normalizedCoefficientFroNorm',NaN, ...
    'supportMask',[],'XiNormalized',[]);
results = repmat(resultTemplate,0,1);

for il = 1:numel(lambdas)
    lambda = lambdas(il);
    XiSupport = sparsifyDynamics(Atr,Btr,lambda,size(Btr,2));
    supportMask = abs(XiSupport)>0;
    for ia = 1:numel(ridgeGrid)
        rho = ridgeGrid(ia);
        if supportRidgeApplied
            Xi = refit_stlsq_support_ridge(Atr,Btr,supportMask,rho);
        else
            Xi = XiSupport;
        end
        r = resultTemplate;
        r.lambda = lambda;
        r.supportRidgeRelativeAlpha = rho;
        r.trainNormalizedMSE = mean((Atr*Xi-Btr).^2,'all');
        r.validationNormalizedMSE = mean((Aval*Xi-Bval).^2,'all');
        r.activeCoefficientCount = nnz(supportMask);
        r.normalizedCoefficientFroNorm = norm(Xi,'fro');
        r.supportMask = supportMask;
        r.XiNormalized = Xi;
        results(end+1,1) = r; %#ok<AGROW>
    end
end
if isempty(results)
    error('fit_pnc_phi_comp_only_module:NoCandidates', ...
        'No Phi_comp-only layer-2 candidate was generated.');
end

% Same pointwise near-best -> sparsity -> ridge-conditioning selector used by
% the other pointwise SINDy methods. No rollout information is used here.
val = [results.validationNormalizedMSE].';
complexity = [results.activeCoefficientCount].';
bestVal = min(val);
tol = opt.stlsq.validationAbsoluteTolerance + ...
    opt.stlsq.preferSparseWithinRelativeValidationTolerance*max(bestVal,eps);
eligible = find(val <= bestVal + tol);
if isempty(eligible)
    [~,bestIdx] = min(val);
else
    bestComplexity = min(complexity(eligible));
    cTol = 100*eps(max(1,bestComplexity));
    candidates = eligible(abs(complexity(eligible)-bestComplexity)<=cTol);
    if supportRidgeApplied
        cVal = val(candidates);
        bestCandidateVal = min(cVal);
        ridgeValTol = opt.stlsq.validationAbsoluteTolerance + ...
            opt.stlsq.supportRidge.tieRelativeValidationTolerance* ...
            max(bestCandidateVal,eps);
        near = candidates(cVal <= bestCandidateVal + ridgeValTol);
        norms = [results(near).normalizedCoefficientFroNorm].';
        bestNorm = min(norms);
        nTol = 100*eps(max(1,bestNorm));
        near2 = near(abs(norms-bestNorm)<=nTol);
        if numel(near2)>1
            [~,loc] = min(val(near2));
            near2 = near2(loc);
        end
        if numel(near2)>1
            rho2 = [results(near2).supportRidgeRelativeAlpha].';
            [~,loc] = min(rho2);
            near2 = near2(loc);
        end
        bestIdx = near2(1);
    else
        [~,loc] = min(val(candidates));
        bestIdx = candidates(loc);
    end
end

best = results(bestIdx);
coef2 = (best.XiNormalized./colScale(:)).*yScale;
active2 = logical(best.supportMask);

module = struct();
module.type = 'modular_sindy_module';
module.formulationVersion = char(opt.formulationVersion);
module.dictionaryFamily = 'phi_comp_only_fixed_neural_ridge';
module.variant = 'pnc_phi_comp_only';
module.fitMode = 'stagewise_frozen_pe_then_phi_comp_only';
module.architectureVersion = 'pnc_phi_comp_only_v1';
module.deviceType = char(data.deviceType);
module.deviceIndex = data.deviceIndex;
module.bus = data.bus;
module.stateIndices = data.stateIndices(:);
module.inputNames = string(data.inputNames(:));
module.outputNames = string(data.outputNames(:));
module.layer1 = layer1;
module.layer1Architecture = 'physics_embedded_sindy';
module.layer1Frozen = true;
module.layer1SelectedThreshold = layer1.selectedThreshold;
module.layer1ActiveCoefficientCount = layer1.activeCoefficientCount;
module.layer1CandidateCoefficientCount = layer1.candidateCoefficientCount;
module.layer1ValidationNormalizedMSE = layer1Info.validationNormalizedMSE;
module.libraryNames = string(names2(:));
module.librarySpec = spec2;
module.coefficients = coef2;
module.selectedCandidateType = 'phi_comp_only_stlsq';
module.selectedThreshold = best.lambda;
module.stlsqSolver = 'official_brunton_2015';
module.stlsqIterations = 10;
module.stlsqRidge = 0;
module.supportRidgeConfigured = supportRidgeConfigured;
module.supportRidgeApplied = supportRidgeApplied;
module.supportRidgeEnabled = supportRidgeApplied;
module.supportRidgeApplicationPolicy = char(supportRidgePolicy);
module.derivativeLabelProtocol = derivative_label_protocol_local(data);
module.supportRidgeRelativeAlpha = best.supportRidgeRelativeAlpha;
module.normalizedCoefficientFroNorm = best.normalizedCoefficientFroNorm;
module.libraryColumnScale = colScale(:);
module.outputScale = yScale(:);
module.activeCoefficientCount = nnz(active2);
module.candidateCoefficientCount = numel(coef2);
module.activePEBypassCoefficientCount = 0;
module.activeShallowPNCoefficientCount = 0;
module.activeCompositionalCoefficientCount = nnz(active2);
module.activeBypassCoefficientCount = 0;
module.activeNeuralCoefficientCount = nnz(active2);
module.physicsPriorFeatureMask = false(size(coef2,1),1);
module.physicsPriorFeatureWeight = 1.0;
module.activePhysicsCoefficientCount = layer1.activePhysicsCoefficientCount;
module.activeGenericCoefficientCount = module.activeCoefficientCount;
module.neuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
module.compositionalNeuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
module.totalFixedNeuralFeatureCount = spec2.compositionalNeural.retainedCount;
module.neuralBasisSeed = seed;
module.compositionalNeuralBasisSeed = spec2.compositionalBasisSeed;
module.compositionalSeedOffset = opt.physicsNeuralCompositional.compositionalSeedOffset;
module.trajectoryValidationEnabled = false;
module.validationTrajectoryNormalizedMSE = NaN;
module.onlineLayer2Updated = false;

sweepTable = table([results.lambda].',[results.supportRidgeRelativeAlpha].', ...
    [results.trainNormalizedMSE].',[results.validationNormalizedMSE].', ...
    [results.activeCoefficientCount].',[results.normalizedCoefficientFroNorm].', ...
    'VariableNames',{'Threshold','SupportRidgeRelativeAlpha', ...
    'TrainNormalizedMSE','ValidationNormalizedMSE','ActiveCoefficientCount', ...
    'NormalizedCoefficientFroNorm'});

info = struct();
info.formulationVersion = char(opt.formulationVersion);
info.architectureVersion = module.architectureVersion;
info.deviceType = char(data.deviceType);
info.deviceIndex = data.deviceIndex;
info.bus = data.bus;
info.nTrainSamples = nnz(trainMask);
info.nValidationSamples = nnz(valMask);
info.libraryTermCount = size(AtrRaw,2);
info.outputCount = size(YtrRaw,2);
info.candidateCoefficientCount = numel(coef2);
info.activeCoefficientCount = module.activeCoefficientCount;
info.selectedCandidateType = module.selectedCandidateType;
info.selectedThreshold = best.lambda;
info.stlsqSolver = module.stlsqSolver;
info.stlsqIterations = module.stlsqIterations;
info.stlsqRidge = 0;
info.supportRidgeConfigured = supportRidgeConfigured;
info.supportRidgeApplied = supportRidgeApplied;
info.supportRidgeEnabled = supportRidgeApplied;
info.supportRidgeApplicationPolicy = char(supportRidgePolicy);
info.derivativeLabelProtocol = module.derivativeLabelProtocol;
info.supportRidgeRelativeAlpha = best.supportRidgeRelativeAlpha;
info.normalizedCoefficientFroNorm = best.normalizedCoefficientFroNorm;
info.trainNormalizedMSE = best.trainNormalizedMSE;
info.validationNormalizedMSE = best.validationNormalizedMSE;
info.thresholdSweep = sweepTable;
info.fitMode = module.fitMode;
info.neuralBasisSeed = seed;
info.neuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
info.compositionalNeuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
info.totalFixedNeuralFeatureCount = spec2.compositionalNeural.retainedCount;
info.neuralCandidatePoolCount = spec2.compositionalNeural.actualCandidateCount;
info.layer1LibraryTermCount = layer1Info.libraryTermCount;
info.layer1CandidateCoefficientCount = layer1Info.candidateCoefficientCount;
info.layer1ActiveCoefficientCount = layer1Info.activeCoefficientCount;
info.layer1SelectedThreshold = layer1Info.selectedThreshold;
info.layer1TrainNormalizedMSE = layer1Info.trainNormalizedMSE;
info.layer1ValidationNormalizedMSE = layer1Info.validationNormalizedMSE;
info.layer1SupportRidgeApplied = layer1Info.supportRidgeApplied;
info.layer1SupportRidgeRelativeAlpha = layer1Info.supportRidgeRelativeAlpha;
info.activePEBypassCoefficientCount = 0;
info.activeShallowPNCoefficientCount = 0;
info.activeCompositionalCoefficientCount = module.activeCompositionalCoefficientCount;
info.activeBypassCoefficientCount = 0;
info.activeNeuralCoefficientCount = module.activeCompositionalCoefficientCount;
info.totalActiveCoefficientCount = layer1Info.activeCoefficientCount + module.activeCoefficientCount;
info.totalCandidateCoefficientCount = layer1Info.candidateCoefficientCount + module.candidateCoefficientCount;
info.physicsPriorFeatureCount = layer1Info.physicsPriorFeatureCount;
info.activePhysicsCoefficientCount = layer1Info.activePhysicsCoefficientCount;
info.activeGenericCoefficientCount = module.activeCoefficientCount;
info.weightedActiveComplexity = module.activeCoefficientCount;
info.trajectoryValidationEnabled = false;
info.validationTrajectoryNormalizedMSE = NaN;

if opt.verbose
    fprintf(['      %s%d | PNC-PhiCompOnly | PE-layer val=%.3e | ', ...
        'Phi_comp=%d terms | lambda=%.3g | active=%d | val nMSE=%.3e\n'], ...
        upper(char(data.deviceType)),data.deviceIndex, ...
        info.layer1ValidationNormalizedMSE,info.libraryTermCount, ...
        info.selectedThreshold,info.activeCoefficientCount, ...
        info.validationNormalizedMSE);
    if info.supportRidgeApplied
        fprintf('      Phi_comp-only support ridge rho=%.3g | normalized coefficient Fro norm=%.3e\n', ...
            info.supportRidgeRelativeAlpha,info.normalizedCoefficientFroNorm);
    end
end
end

function txt = derivative_label_protocol_local(data)
txt = 'unknown';
if isstruct(data) && isfield(data,'derivativeLabelProtocol') && ...
        strlength(string(data.derivativeLabelProtocol)) > 0
    txt = char(string(data.derivativeLabelProtocol));
end
end
