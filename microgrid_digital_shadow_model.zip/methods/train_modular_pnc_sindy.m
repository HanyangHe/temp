function [model,info] = train_modular_pnc_sindy(dataset,c,layout,cfg)
%TRAIN_MODULAR_PNC_SINDY Train stagewise Physics-Neural Compositional SINDy.
%
% PNC-SINDy uses the same whole-trajectory train/validation partition as the
% other pointwise SINDy methods. Each local DER module is fitted stagewise:
%   1) PE-SINDy backbone -> H = f_PE_hat(chi), then freeze Xi_1;
%   2) fit the former flat PN-SINDy parent on the same split;
%   3) identify a sparse readout on
%        [H, Theta_PN_flat(chi), Phi_comp(chi,H)].
%
% Both PE and flat PN are exact selectable submodels. The compositional depth is
% used only when held-out validation improves beyond both parents. No end-to-end
% nonlinear optimization or backpropagation is used.

opt = get_sindy_options(cfg);
K = dataset.trajectories.nTrajectories;
if K < 2
    error('train_modular_pnc_sindy:TooFewTrajectories', ...
        'At least two trajectories are required.');
end

forcedTrainIds = [];
if isfield(dataset.trajectories,'forceTrainingMask') && ...
        ~isempty(dataset.trajectories.forceTrainingMask)
    m = logical(dataset.trajectories.forceTrainingMask(:));
    if numel(m) ~= K
        error('train_modular_pnc_sindy:ForceTrainingMaskSize', ...
            'forceTrainingMask must contain one entry per trajectory.');
    end
    forcedTrainIds = find(m).';
end
validationCandidates = setdiff(1:K,forcedTrainIds,'stable');
if isempty(validationCandidates)
    error('train_modular_pnc_sindy:NoValidationCandidates', ...
        'No trajectory remains for validation.');
end
oldRng = rng;
cleanup = onCleanup(@()rng(oldRng)); %#ok<NASGU>
rng(opt.validationSeed,'twister');
perm = validationCandidates(randperm(numel(validationCandidates)));
nVal = max(1,round(opt.validationFraction*K));
nVal = min(nVal,numel(validationCandidates));
if nVal >= K, nVal = K-1; end
valIds = sort(perm(1:nVal));
trainIds = sort(setdiff(1:K,valIds,'stable'));
trainMask = ismember(dataset.trajectoryId,trainIds);
valMask = ismember(dataset.trajectoryId,valIds);

model = struct();
model.type = 'modular_sindy';
model.formulationVersion = char(opt.formulationVersion);
model.method = 'PNC-SINDy';
model.variant = 'physics_neural_compositional';
model.architectureVersion = 'pnc_skip_composition_v2';
model.libraryVariant = 'pe_bypass_flatpn_skip_then_neural_composition';
model.fitMode = 'stagewise_frozen_two_layer_with_parent_skips';
model.trainingObjective = [ ...
    'stagewise frozen sparse vector-field regression with nested PE and flat-PN ', ...
    'parent skips plus a fixed neural compositional dictionary'];
model.trainingSampleDefinition = ...
    'flattened pointwise samples from common short-trajectory dataset';
model.sg = struct([]); model.gfm = struct([]); model.gfl = struct([]);
model.trainTrajectoryIds = trainIds(:);
model.validationTrajectoryIds = valIds(:);
model.forcedTrainingTrajectoryIds = forcedTrainIds(:);
model.options = opt;

modules = struct([]);
mi = 0;
activeTotal = 0;
candidateTotal = 0;
layer1ActiveTotal = 0;
layer2ActiveTotal = 0;

for k = 1:numel(c.sg)
    fprintf('    Training PNC-SINDy module SG%d (Bus %d)...\n',k,c.sg(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'sg',k);
    seed = module_seed_local(opt.neuralBasis.seed,'sg',k);
    [mk,ik] = fit_pnc_sindy_module(data,trainMask,valMask,opt,seed);
    if k==1, model.sg=mk; else, model.sg(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    activeTotal = activeTotal + ik.totalActiveCoefficientCount;
    candidateTotal = candidateTotal + ik.totalCandidateCoefficientCount;
    layer1ActiveTotal = layer1ActiveTotal + ik.layer1ActiveCoefficientCount;
    layer2ActiveTotal = layer2ActiveTotal + ik.activeCoefficientCount;
end
for k = 1:numel(c.gfm)
    fprintf('    Training PNC-SINDy module GFM%d (Bus %d)...\n',k,c.gfm(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfm',k);
    seed = module_seed_local(opt.neuralBasis.seed,'gfm',k);
    [mk,ik] = fit_pnc_sindy_module(data,trainMask,valMask,opt,seed);
    if k==1, model.gfm=mk; else, model.gfm(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    activeTotal = activeTotal + ik.totalActiveCoefficientCount;
    candidateTotal = candidateTotal + ik.totalCandidateCoefficientCount;
    layer1ActiveTotal = layer1ActiveTotal + ik.layer1ActiveCoefficientCount;
    layer2ActiveTotal = layer2ActiveTotal + ik.activeCoefficientCount;
end
for k = 1:numel(c.gfl)
    fprintf('    Training PNC-SINDy module GFL%d (Bus %d)...\n',k,c.gfl(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfl',k);
    seed = module_seed_local(opt.neuralBasis.seed,'gfl',k);
    [mk,ik] = fit_pnc_sindy_module(data,trainMask,valMask,opt,seed);
    if k==1, model.gfl=mk; else, model.gfl(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    activeTotal = activeTotal + ik.totalActiveCoefficientCount;
    candidateTotal = candidateTotal + ik.totalCandidateCoefficientCount;
    layer1ActiveTotal = layer1ActiveTotal + ik.layer1ActiveCoefficientCount;
    layer2ActiveTotal = layer2ActiveTotal + ik.activeCoefficientCount;
end

model.activeCoefficientCount = activeTotal;
model.candidateCoefficientCount = candidateTotal;
model.layer1ActiveCoefficientCount = layer1ActiveTotal;
model.layer2ActiveCoefficientCount = layer2ActiveTotal;

[okCompatibility,compatibility] = check_sindy_model_compatibility( ...
    'physics_neural_compositional_sindy',model,cfg);
if ~okCompatibility
    error('train_modular_pnc_sindy:CompatibilityContract', ...
        ['Newly trained PNC-SINDy model violates its method contract:\n  - %s'], ...
        strjoin(string(compatibility.issues),sprintf('\n  - ')));
end
model.compatibilitySchema = compatibility.schemaVersion;
model.compatibilitySignature = compatibility.actual;

info = struct();
info.method = 'physics_neural_compositional_sindy';
info.formulationVersion = char(opt.formulationVersion);
info.displayName = 'PNC-SINDy';
info.variant = 'physics_neural_compositional';
info.architectureVersion = 'pnc_skip_composition_v2';
info.libraryVariant = 'pe_bypass_flatpn_skip_then_neural_composition';
info.fitMode = 'stagewise_frozen_two_layer_with_parent_skips';
info.objective = [ ...
    'PNC v2: PE bypass + exact flat-PN skip + fixed-neural compositional ', ...
    'sparse readout'];
info.nSamples = size(dataset.x,1);
info.nTrajectories = K;
info.nTrainSamples = nnz(trainMask);
info.nValidationSamples = nnz(valMask);
info.nTrainTrajectories = numel(trainIds);
info.nValidationTrajectories = numel(valIds);
info.trainTrajectoryIds = trainIds(:);
info.validationTrajectoryIds = valIds(:);
info.forcedTrainingTrajectoryIds = forcedTrainIds(:);
info.modules = modules;
info.activeCoefficientCount = activeTotal;
info.candidateCoefficientCount = candidateTotal;
info.layer1ActiveCoefficientCount = layer1ActiveTotal;
info.layer2ActiveCoefficientCount = layer2ActiveTotal;
info.neuralBasisFeatureCount = opt.neuralBasis.featureCount;
info.neuralBasisActivation = opt.neuralBasis.activation;
info.compatibilitySchema = compatibility.schemaVersion;
info.compatibilitySignature = compatibility.actual;

if ~isempty(forcedTrainIds) && opt.verbose
    fprintf('    Forced into PNC-SINDy training partition: trajectory ID(s) [%s]\n', ...
        strtrim(sprintf('%d ',forcedTrainIds)));
end
end

function [S,mi] = append_info_local(S,mi,ik)
mi = mi+1;
if mi==1, S=ik; else, S(mi,1)=ik; end
end

function seed = module_seed_local(baseSeed,deviceType,k)
switch lower(char(deviceType))
    case 'sg', offset=100*k;
    case 'gfm', offset=10000+100*k;
    case 'gfl', offset=20000+100*k;
    otherwise, offset=30000+100*k;
end
seed = round(double(baseSeed))+offset;
end
