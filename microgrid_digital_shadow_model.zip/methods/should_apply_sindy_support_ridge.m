function [applyRidge,configured,policy] = should_apply_sindy_support_ridge(opt,data)
%SHOULD_APPLY_SINDY_SUPPORT_RIDGE Resolve the shared pointwise-SINDy ridge policy.
%
% The frozen manuscript policy is:
%   - exact vector-field labels: keep the original unregularized STLSQ/OLS refit;
%   - derivative labels reconstructed from measured state trajectories: allow a
%     validation-selected support-preserving Tikhonov refit.
%
% This helper is shared by polynomial and fixed-neural pointwise SINDy variants
% so V-SINDy, PE-SINDy, PNC-SINDy layers, flat PN-SINDy, and inactive legacy pointwise variants follow
% the same numerical conditioning rule whenever they are enabled.

configured = isfield(opt,'stlsq') && isfield(opt.stlsq,'supportRidge') && ...
    isstruct(opt.stlsq.supportRidge) && ...
    isfield(opt.stlsq.supportRidge,'enabled') && ...
    logical(opt.stlsq.supportRidge.enabled);

policy = "never";
if isfield(opt,'stlsq') && isfield(opt.stlsq,'supportRidge') && ...
        isstruct(opt.stlsq.supportRidge) && ...
        isfield(opt.stlsq.supportRidge,'applicationPolicy') && ...
        strlength(string(opt.stlsq.supportRidge.applicationPolicy)) > 0
    policy = lower(strtrim(string(opt.stlsq.supportRidge.applicationPolicy)));
end

if ~configured
    applyRidge = false;
    return;
end

switch policy
    case "always"
        applyRidge = true;
    case "reconstructed_derivative_labels_only"
        applyRidge = isstruct(data) && ...
            isfield(data,'derivativeLabelsReconstructed') && ...
            logical(data.derivativeLabelsReconstructed);
    case "never"
        applyRidge = false;
    otherwise
        error('should_apply_sindy_support_ridge:Policy', ...
            'Unknown support-ridge application policy "%s".',char(policy));
end
end
