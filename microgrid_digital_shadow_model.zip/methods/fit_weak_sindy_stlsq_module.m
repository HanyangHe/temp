function [module,info] = fit_weak_sindy_stlsq_module(data,trainIds,valIds,opt)
%FIT_WEAK_SINDY_STLSQ_MODULE Fit one conventional Weak SINDy device module.
%
% Candidate library: IDENTICAL to Vanilla SINDy
%   [1, Poly_p(raw chi), sin(raw chi), cos(raw chi)].
%
% Identification form: compact-support weak integral regression
%
%   -int x(t) dphi/dt dt = int Theta(x,V,u) phi(t) dt * Xi,
%
% so no pointwise xdot labels are used. Sparse support is discovered by the
% same official unregularized STLSQ solver used by pointwise SINDy.
%
% Fixed support-preserving ridge rule:
%   * ordinary unregularized STLSQ discovers the sparse support;
%   * the support is then frozen;
%   * coefficients on that support are refit with the SAME fixed
%     rho = opt.weakSindy.supportRidgeRelativeAlpha for every section and
%     every noise level.  The manuscript diagnostic sets rho = 1e-10.
%
% Thus rho is not a noise-dependent tuning knob and cannot change support.
% The only structural difference from Vanilla SINDy remains the weak integral
% treatment of trajectory evidence (no pointwise xdot labels).

trainMask = ismember(data.trajectoryId,trainIds);
valMask = ismember(data.trajectoryId,valIds);
if ~any(trainMask) || ~any(valMask)
    error('fit_weak_sindy_stlsq_module:EmptySplit', ...
        'Train and validation trajectories must both be nonempty.');
end

% Exactly the Vanilla-SINDy dictionary; no neural or composed physics terms.
[Theta,names,spec] = build_sindy_library( ...
    data.X,data.inputNames,data.deviceType,'vanilla',opt,[]);

weakOpt = opt.weakSindy;
[AtrRaw,BtrRaw,trainMeta] = build_weak_sindy_regression( ...
    data,Theta,trainIds,weakOpt);
[AvalRaw,BvalRaw,valMeta] = build_weak_sindy_regression( ...
    data,Theta,valIds,weakOpt);

% Training-only normalization, identical in spirit to pointwise SINDy.
colScale = sqrt(mean(AtrRaw.^2,1));
colScale = max(colScale,opt.normalization.libraryScaleFloor);
yScale = std(BtrRaw,0,1);
yRms = sqrt(mean(BtrRaw.^2,1));
yScale = max(yScale,0.05*yRms);
yScale = max(yScale,opt.normalization.outputScaleFloor);

Atr = AtrRaw./colScale;
Aval = AvalRaw./colScale;
Btr = BtrRaw./yScale;
Bval = BvalRaw./yScale;

% Weak SINDy never consumes derivative labels, so its numerical
% conditioning policy must not depend on derivativeLabelsReconstructed.
% Use one fixed rho for clean and noisy weak regressions alike.
if ~isfield(weakOpt,'supportRidgeRelativeAlpha')
    error('fit_weak_sindy_stlsq_module:MissingFixedRho', ...
        'weakSindy.supportRidgeRelativeAlpha must be defined.');
end
fixedRho = double(weakOpt.supportRidgeRelativeAlpha);
validateattributes(fixedRho,{'numeric'},{'scalar','nonnegative','finite'});
supportRidgeConfigured = true;
supportRidgeApplied = true;
supportRidgePolicy = 'fixed_all_weak_constraints';
ridgeGrid = fixedRho;

lambdas = unique(sort(weakOpt.thresholdGrid(:)),'stable');
resultTemplate = struct('lambda',NaN,'supportRidgeRelativeAlpha',NaN, ...
    'trainNormalizedMSE',NaN,'validationNormalizedMSE',NaN, ...
    'activeCoefficientCount',NaN,'normalizedCoefficientFroNorm',NaN, ...
    'supportMask',[],'XiNormalized',[]);
results = repmat(resultTemplate,0,1);

for il = 1:numel(lambdas)
    lambda = lambdas(il);

    % Official unregularized STLSQ discovers support.  The support is frozen
    % before any rho refit is considered.
    XiSupport = sparsifyDynamics(Atr,Btr,lambda,size(Btr,2));
    supportMask = abs(XiSupport)>0;

    for ia = 1:numel(ridgeGrid)
        rho = ridgeGrid(ia);
        % Fixed-rho coefficient stabilization on the frozen STLSQ support.
        % rho=0 would reduce exactly to ordinary LS, but this diagnostic uses
        % rho=1e-10 for every clean/noisy Weak-SINDy fit.
        Xi = refit_stlsq_support_ridge(Atr,Btr,supportMask,rho);

        trPred = Atr*Xi;
        vaPred = Aval*Xi;

        r = resultTemplate;
        r.lambda = lambda;
        r.supportRidgeRelativeAlpha = rho;
        r.trainNormalizedMSE = mean((trPred-Btr).^2,'all');
        r.validationNormalizedMSE = mean((vaPred-Bval).^2,'all');
        r.activeCoefficientCount = nnz(supportMask);
        r.normalizedCoefficientFroNorm = norm(Xi,'fro');
        r.supportMask = supportMask;
        r.XiNormalized = Xi;
        results(end+1,1) = r; %#ok<AGROW>
    end
end

% Exclude the trivial all-zero vector field from model selection. If every
% threshold collapses to zero, fail explicitly rather than silently accepting
% a degenerate weak model.
val = [results.validationNormalizedMSE].';
active = [results.activeCoefficientCount].';
nonzero = find(active>0 & isfinite(val));
if isempty(nonzero)
    error('fit_weak_sindy_stlsq_module:ZeroSupport', ...
        'All Weak SINDy threshold candidates collapsed to zero support.');
end

% Same first-stage near-best/sparsest support selector as the current SINDy
% family.  rho cannot buy a denser support because support complexity is
% decided before the conditioning tie-break.
bestVal = min(val(nonzero));
tol = opt.stlsq.validationAbsoluteTolerance + ...
    opt.stlsq.preferSparseWithinRelativeValidationTolerance*max(bestVal,eps);
eligible = nonzero(val(nonzero) <= bestVal + tol);
if isempty(eligible)
    [~,loc] = min(val(nonzero));
    bestIdx = nonzero(loc);
else
    bestActive = min(active(eligible));
    candidates = eligible(active(eligible)==bestActive);

    % rho is fixed, so validation selects only among lambda/support
    % candidates.  There is no rho search and therefore no rho-dependent
    % model-selection advantage.
    [~,loc] = min(val(candidates));
    bestIdx = candidates(loc);
end

best = results(bestIdx);
XiNorm = best.XiNormalized;

coef = (XiNorm./colScale(:)).*yScale;
coefActiveMask = logical(best.supportMask);
physicsMask = false(numel(names),1);

module.type = 'modular_sindy_module';
module.formulationVersion = char(opt.formulationVersion);
module.dictionaryFamily = 'polytrig';
% Rollout uses the same conventional vanilla library evaluator.
module.variant = 'vanilla';
module.fitMode = 'weak_vanilla';
module.deviceType = char(data.deviceType);
module.deviceIndex = data.deviceIndex;
module.bus = data.bus;
module.stateIndices = data.stateIndices(:);
module.inputNames = string(data.inputNames(:));
module.outputNames = string(data.outputNames(:));
module.libraryNames = string(names(:));
module.librarySpec = spec;
module.coefficients = coef;
module.selectedThreshold = best.lambda;
module.stlsqSolver = 'official_brunton_2015';
module.stlsqIterations = 10;
module.stlsqRidge = 0; % support discovery remains unregularized STLSQ.
module.supportRidgeConfigured = supportRidgeConfigured;
module.supportRidgeApplied = supportRidgeApplied;
module.supportRidgeEnabled = supportRidgeApplied; % compatibility alias
module.supportRidgeApplicationPolicy = supportRidgePolicy;
module.supportRidgeRelativeAlpha = best.supportRidgeRelativeAlpha;
module.normalizedCoefficientFroNorm = best.normalizedCoefficientFroNorm;
module.libraryColumnScale = colScale(:);
module.outputScale = yScale(:);
module.activeCoefficientCount = nnz(coefActiveMask);
module.candidateCoefficientCount = numel(coef);
module.physicsPriorFeatureMask = physicsMask;
module.physicsPriorFeatureWeight = 1.0;
module.activePhysicsCoefficientCount = 0;
module.activeGenericCoefficientCount = module.activeCoefficientCount;
module.neuralBasisFeatureCount = 0;
module.weakTrainMeta = trainMeta;
module.weakValidationMeta = valMeta;
module.weakWindowPoints = weakOpt.windowPoints(:).';
module.weakWindowStride = weakOpt.windowStride;
module.weakTestFunctionPower = weakOpt.testFunctionPower;
module.weakThresholdGrid = weakOpt.thresholdGrid(:).';

sweepTable = table([results.lambda].',[results.supportRidgeRelativeAlpha].', ...
    [results.trainNormalizedMSE].',[results.validationNormalizedMSE].', ...
    [results.activeCoefficientCount].',[results.normalizedCoefficientFroNorm].', ...
    'VariableNames',{'Threshold','SupportRidgeRelativeAlpha', ...
    'TrainNormalizedMSE','ValidationNormalizedMSE', ...
    'ActiveCoefficientCount','NormalizedCoefficientFroNorm'});

info.formulationVersion = char(opt.formulationVersion);
info.deviceType = char(data.deviceType);
info.deviceIndex = data.deviceIndex;
info.bus = data.bus;
info.nTrainSamples = trainMeta.constraintCount;
info.nValidationSamples = valMeta.constraintCount;
info.libraryTermCount = size(AtrRaw,2);
info.neuralBasisFeatureCount = 0;
info.outputCount = size(BtrRaw,2);
info.candidateCoefficientCount = numel(coef);
info.activeCoefficientCount = module.activeCoefficientCount;
info.selectedThreshold = best.lambda;
info.stlsqSolver = 'official_brunton_2015';
info.stlsqIterations = 10;
info.stlsqRidge = 0;
info.supportRidgeConfigured = supportRidgeConfigured;
info.supportRidgeApplied = supportRidgeApplied;
info.supportRidgeEnabled = supportRidgeApplied;
info.supportRidgeApplicationPolicy = supportRidgePolicy;
info.supportRidgeRelativeAlpha = best.supportRidgeRelativeAlpha;
info.normalizedCoefficientFroNorm = best.normalizedCoefficientFroNorm;
info.trainNormalizedMSE = best.trainNormalizedMSE;
info.validationNormalizedMSE = best.validationNormalizedMSE;
info.thresholdSweep = sweepTable;
info.fitMode = 'weak_vanilla';
info.physicsPriorFeatureCount = 0;
info.physicsPriorFeatureWeight = 1.0;
info.activePhysicsCoefficientCount = 0;
info.activeGenericCoefficientCount = module.activeCoefficientCount;
info.weakTrainMeta = trainMeta;
info.weakValidationMeta = valMeta;
info.weakWindowPoints = weakOpt.windowPoints(:).';
info.weakWindowStride = weakOpt.windowStride;
info.weakTestFunctionPower = weakOpt.testFunctionPower;
info.weakThresholdGrid = weakOpt.thresholdGrid(:).';
info.derivativeLabelsUsed = false;
info.physicsEvaluationMode = 'none';

if opt.verbose
    ridgeText = sprintf(' | fixed support-ridge rho=%.3g', ...
        best.supportRidgeRelativeAlpha);
    fprintf(['      %s%d | Weak SINDy | library=%d (Poly-%d+sin/cos) | ', ...
        'weak rows train/val=%d/%d | windows=[%s] | lambda=%.3g%s | ', ...
        'active=%d/%d | train nMSE=%.3e | val nMSE=%.3e\n'], ...
        upper(char(data.deviceType)),data.deviceIndex,info.libraryTermCount, ...
        opt.polyOrderOption,info.nTrainSamples,info.nValidationSamples, ...
        strtrim(sprintf('%d ',weakOpt.windowPoints)),info.selectedThreshold, ...
        ridgeText,info.activeCoefficientCount,info.candidateCoefficientCount, ...
        info.trainNormalizedMSE,info.validationNormalizedMSE);
end
end
