function [model,info] = train_vanilla_sindy(dataset,c,layout,cfg)
%TRAIN_VANILLA_SINDY Vanilla [Poly_p(raw chi), sin(raw chi), cos(raw chi)] SINDy.
[model,info] = train_modular_sindy(dataset,c,layout,cfg,'vanilla');
end
