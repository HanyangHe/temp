function [model,info] = train_coordexp_sindy(dataset,c,layout,cfg)
%TRAIN_COORDEXP_SINDY Non-LLM coordinate-polynomial control (69-bus ablation).
% All regression and validation calculations are delegated to the EXACT
% train_llm_prior_sindy and fit_sindy_stlsq_module implementations used
% for Lv.3. Only the appended priorBank is different: here it contains
% supplied d/q coordinates and deterministic generic quadratic monomials.
% The internal per-module variant remains 'llmprior' ONLY to reuse the
% compiled-DSL numerical evaluator during DAE prediction; no LLM is called.

if ~isfield(cfg,'coordExp') || ~isstruct(cfg.coordExp) || ...
        ~isfield(cfg.coordExp,'enabled') || ~logical(cfg.coordExp.enabled)
    error('train_coordexp_sindy:Disabled','cfg.coordExp.enabled must be true.');
end
if ~isfield(cfg,'sindy') || ~isfield(cfg.sindy,'llmPrior') || ...
        ~isfield(cfg.sindy.llmPrior,'priorBank')
    error('train_coordexp_sindy:NoGenericBank','C+E bank is missing.');
end
if ~strcmpi(char(string(cfg.sindy.llmPrior.priorBankHash)), ...
        char(string(cfg.coordExp.bankHash)))
    error('train_coordexp_sindy:BankHash', ...
        'C+E bank hash does not match the config provenance.');
end

[model,info] = train_llm_prior_sindy(dataset,c,layout,cfg);
model.variant = 'coordexp';
model.formulationVersion = 'coordexp_generic_quadratic_matched_v1';
model.compatibilitySchema = 'coordexp_nonllm_control_v1';
model.compatibilitySignature = struct( ...
    'method','coordexp_sindy','bankHash',char(cfg.coordExp.bankHash), ...
    'referenceLv3Hash',char(cfg.coordExp.referenceLv3Hash), ...
    'sampleCount',size(dataset.x,1));
model.coordExp = cfg.coordExp;
% model.sg/gfm/gfl(*).variant='llmprior' deliberately: this is the DSL
% evaluator compatible with the frozen C+E dictionary and librarySpecs.
info.method = 'coordexp_sindy';
info.displayName = 'Coord+Exp SINDy';
info.formulationVersion = model.formulationVersion;
info.objective = ['V-SINDy + supplied d/q coordinates + fixed ', ...
    'generic quadratic terms; matched Lv.3 bank width'];
info.priorBankHash = char(cfg.coordExp.bankHash);
info.referenceLv3Hash = char(cfg.coordExp.referenceLv3Hash);
info.llmCalls = 0;
end
