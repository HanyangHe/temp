function [model,info] = train_modular_pnc_phi_comp_only_sindy(dataset,c,layout,cfg)
%TRAIN_MODULAR_PNC_PHI_COMP_ONLY_SINDY Train strict Phi_comp-only PNC ablation.
%
% Layer 1: PE-SINDy backbone H=f_PE_hat(chi), then freeze Xi_1.
% Layer 2: ONLY Phi_comp(chi,H) -> sparse linear readout Xi_2.
%
% This is a diagnostic ablation. There is no PE bypass and no flat-PN skip in
% the second-layer readout.

opt = get_sindy_options(cfg);
K = dataset.trajectories.nTrajectories;
if K < 2
    error('train_modular_pnc_phi_comp_only_sindy:TooFewTrajectories', ...
        'At least two trajectories are required.');
end

forcedTrainIds = [];
if isfield(dataset.trajectories,'forceTrainingMask') && ...
        ~isempty(dataset.trajectories.forceTrainingMask)
    m = logical(dataset.trajectories.forceTrainingMask(:));
    if numel(m) ~= K
        error('train_modular_pnc_phi_comp_only_sindy:ForceTrainingMaskSize', ...
            'forceTrainingMask must contain one entry per trajectory.');
    end
    forcedTrainIds = find(m).';
end
validationCandidates = setdiff(1:K,forcedTrainIds,'stable');
if isempty(validationCandidates)
    error('train_modular_pnc_phi_comp_only_sindy:NoValidationCandidates', ...
        'No trajectory remains for validation.');
end
oldRng = rng;
cleanup = onCleanup(@()rng(oldRng)); %#ok<NASGU>
rng(opt.validationSeed,'twister');
perm = validationCandidates(randperm(numel(validationCandidates)));
nVal = max(1,round(opt.validationFraction*K));
nVal = min(nVal,numel(validationCandidates));
if nVal >= K, nVal = K-1; end
valIds = sort(perm(1:nVal));
trainIds = sort(setdiff(1:K,valIds,'stable'));
trainMask = ismember(dataset.trajectoryId,trainIds);
valMask = ismember(dataset.trajectoryId,valIds);

model = struct();
model.type = 'modular_sindy';
model.formulationVersion = char(opt.formulationVersion);
model.method = 'PNC-PhiCompOnly';
model.variant = 'pnc_phi_comp_only';
model.architectureVersion = 'pnc_phi_comp_only_v1';
model.libraryVariant = 'frozen_pe_then_phi_comp_only';
model.fitMode = 'stagewise_frozen_pe_then_phi_comp_only';
model.trainingObjective = [ ...
    'strict diagnostic: frozen PE representation conditions a fixed neural ', ...
    'compositional dictionary with no direct parent skip in layer 2'];
model.trainingSampleDefinition = ...
    'flattened pointwise samples from common short-trajectory dataset';
model.sg = struct([]); model.gfm = struct([]); model.gfl = struct([]);
model.trainTrajectoryIds = trainIds(:);
model.validationTrajectoryIds = valIds(:);
model.forcedTrainingTrajectoryIds = forcedTrainIds(:);
model.options = opt;

modules = struct([]);
mi = 0;
activeTotal = 0;
candidateTotal = 0;
layer1ActiveTotal = 0;
layer2ActiveTotal = 0;

for k = 1:numel(c.sg)
    fprintf('    Training PNC-PhiCompOnly module SG%d (Bus %d)...\n',k,c.sg(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'sg',k);
    seed = module_seed_local(opt.neuralBasis.seed,'sg',k);
    [mk,ik] = fit_pnc_phi_comp_only_module(data,trainMask,valMask,opt,seed);
    if k==1, model.sg=mk; else, model.sg(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    activeTotal = activeTotal + ik.totalActiveCoefficientCount;
    candidateTotal = candidateTotal + ik.totalCandidateCoefficientCount;
    layer1ActiveTotal = layer1ActiveTotal + ik.layer1ActiveCoefficientCount;
    layer2ActiveTotal = layer2ActiveTotal + ik.activeCoefficientCount;
end
for k = 1:numel(c.gfm)
    fprintf('    Training PNC-PhiCompOnly module GFM%d (Bus %d)...\n',k,c.gfm(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfm',k);
    seed = module_seed_local(opt.neuralBasis.seed,'gfm',k);
    [mk,ik] = fit_pnc_phi_comp_only_module(data,trainMask,valMask,opt,seed);
    if k==1, model.gfm=mk; else, model.gfm(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    activeTotal = activeTotal + ik.totalActiveCoefficientCount;
    candidateTotal = candidateTotal + ik.totalCandidateCoefficientCount;
    layer1ActiveTotal = layer1ActiveTotal + ik.layer1ActiveCoefficientCount;
    layer2ActiveTotal = layer2ActiveTotal + ik.activeCoefficientCount;
end
for k = 1:numel(c.gfl)
    fprintf('    Training PNC-PhiCompOnly module GFL%d (Bus %d)...\n',k,c.gfl(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfl',k);
    seed = module_seed_local(opt.neuralBasis.seed,'gfl',k);
    [mk,ik] = fit_pnc_phi_comp_only_module(data,trainMask,valMask,opt,seed);
    if k==1, model.gfl=mk; else, model.gfl(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    activeTotal = activeTotal + ik.totalActiveCoefficientCount;
    candidateTotal = candidateTotal + ik.totalCandidateCoefficientCount;
    layer1ActiveTotal = layer1ActiveTotal + ik.layer1ActiveCoefficientCount;
    layer2ActiveTotal = layer2ActiveTotal + ik.activeCoefficientCount;
end

model.activeCoefficientCount = activeTotal;
model.candidateCoefficientCount = candidateTotal;
model.layer1ActiveCoefficientCount = layer1ActiveTotal;
model.layer2ActiveCoefficientCount = layer2ActiveTotal;

% This ablation is intentionally test-only, so it is not enrolled in the
% production saved-model compatibility contract used by online initialization.
model.compatibilitySchema = 'diagnostic_only';
model.compatibilitySignature = struct('architectureVersion',model.architectureVersion);

info = struct();
info.method = 'pnc_phi_comp_only_sindy';
info.formulationVersion = char(opt.formulationVersion);
info.displayName = 'PNC-CompOnly';
info.variant = model.variant;
info.architectureVersion = model.architectureVersion;
info.libraryVariant = model.libraryVariant;
info.fitMode = model.fitMode;
info.objective = model.trainingObjective;
info.nSamples = size(dataset.x,1);
info.nTrajectories = K;
info.nTrainSamples = nnz(trainMask);
info.nValidationSamples = nnz(valMask);
info.nTrainTrajectories = numel(trainIds);
info.nValidationTrajectories = numel(valIds);
info.trainTrajectoryIds = trainIds(:);
info.validationTrajectoryIds = valIds(:);
info.forcedTrainingTrajectoryIds = forcedTrainIds(:);
info.modules = modules;
info.activeCoefficientCount = activeTotal;
info.candidateCoefficientCount = candidateTotal;
info.layer1ActiveCoefficientCount = layer1ActiveTotal;
info.layer2ActiveCoefficientCount = layer2ActiveTotal;
info.neuralBasisFeatureCount = opt.neuralBasis.featureCount;
info.neuralBasisActivation = opt.neuralBasis.activation;
info.compatibilitySchema = model.compatibilitySchema;
info.compatibilitySignature = model.compatibilitySignature;

if ~isempty(forcedTrainIds) && opt.verbose
    fprintf('    Forced into PNC-PhiCompOnly training partition: trajectory ID(s) [%s]\n', ...
        strtrim(sprintf('%d ',forcedTrainIds)));
end
end

function [S,mi] = append_info_local(S,mi,ik)
mi = mi+1;
if mi==1, S=ik; else, S(mi,1)=ik; end
end

function seed = module_seed_local(baseSeed,deviceType,k)
switch lower(char(deviceType))
    case 'sg', offset=100*k;
    case 'gfm', offset=10000+100*k;
    case 'gfl', offset=20000+100*k;
    otherwise, offset=30000+100*k;
end
seed = round(double(baseSeed))+offset;
end
