function opt = get_edsi_options(cfg)
%GET_EDSI_OPTIONS Formal EDSI / LLM-EDSI configuration.
%
% The formal method uses sparse STLSQ during dictionary evolution and a full
% validation-selected STLSQ refit on the final evolved dictionary.  The
% coefficient-identification backend is intentionally shared with V-SINDy:
% OLS-STLSQ discovers support; clean exact labels then use a fixed rho=1e-10
% refit on that frozen support, while reconstructed noisy labels use the same
% validation-selected support-preserving ridge refit as V-SINDy. Optional cfg.edsi / cfg.llmEdsi fields override defaults.

opt = struct();

% Sparse-STLSQ EDSI
opt.enabled = false;
opt.formulationVersion = 'edsi_sindy_fair_ols_support_fixedrho_v4';
opt.supportDiscoveryRho = 0;
opt.finalSupportRidgeRho = 1e-10;
opt.rho = opt.finalSupportRidgeRho; % legacy/report alias; NOT used for support discovery
opt.shareSindyIdentificationBackend = true;
% Search-stage sparse identification: choose one threshold on the initial
% V-SINDy dictionary, then freeze it while evolution evaluates candidates
% with only two STLSQ threshold/refit turns. This keeps candidate scoring
% cheap while applying explicit sparsity pressure during dictionary search.
opt.searchStlsqIterations = 2;
opt.searchThresholdGrid = [0 1e-6 3e-6 1e-5 3e-5 1e-4 3e-4 1e-3 ...
    3e-3 1e-2 3e-2 1e-1 3e-1];
opt.searchPreferSparseWithinRelativeValidationTolerance = 0.05;
% Final selected dictionary is always refit by the full ten-turn STLSQ
% protocol with OLS support discovery and the same fixed final-support rho.
opt.finalStlsqIterations = 10;
opt.finalThresholdGrid = opt.searchThresholdGrid;
opt.finalPreferSparseWithinRelativeValidationTolerance = 0.05;
opt.populationSize = 32;
opt.eliteCount = 8;
opt.maxGenerations = 30;
opt.stallPatience = 7;
opt.minRelativeImprovement = 1e-4;
opt.mutationSlotCounts = [1 2 3];
opt.mutationSlotProbabilities = [0.60 0.30 0.10];
opt.productProbability = 0.60;
opt.sinProbability = 0.20;
opt.cosProbability = 0.20;
opt.maxBasisDepth = 3;
opt.maxBasisComplexity = 7;
opt.maxBasisAbsValue = 1e8;
opt.libraryScaleFloor = 1e-12;
opt.outputScaleFloor = 1e-12;
opt.maxChildRetries = 50;
opt.printEvery = 5;
% Keep the evolutionary RNG fixed across manuscript data-sampling seeds so
% multi-seed spread continues to isolate the data realization.
opt.evolutionSearchSeed = 1;
% V8 augmented LLM-prior residual refinement.  The LLM enhancement bank is
% identified once and frozen; evolution sees only the remaining residual.
% Final adoption uses held-out short-trajectory rollout validation, never the
% manuscript 12-s test trajectory.
opt.residualRefinementShortRolloutEnabled = true;
opt.residualChampionMinRelativeImprovement = 0.005;

% LLM-EDSI = one-shot compact semantic structural refinement + sparse EDSI.
opt.llm = struct();
opt.llm.enabled = false;
opt.llm.formulationVersion = 'llm_edsi_sindy_fair_semantic_edit_v3';
opt.llm.initialGeneration = 1;
opt.llm.maxCalls = 1;
opt.llm.period = 10; % retained as a method parameter; inactive when maxCalls=1.
opt.llm.refinedEliteCount = 2;
opt.llm.currentOdeTermsPerDerivative = 6;
% Only the strongest sparse parent terms are sent to the cloud. The adapter
% reconstructs a complete fixed-width dictionary locally, so the LLM returns
% only a compact set of proposed structural additions/replacements.
opt.llm.maxActiveDictionaryTerms = 24;
opt.llm.inactiveContextTerms = 0;
opt.llm.maxProposedTerms = 8;
opt.llm.maxExpressionDepth = 6;
opt.llm.maxExpressionComplexity = 20;
opt.llm.adapterPath = '';
opt.llm.configPath = '';

if nargin < 1 || isempty(cfg)
    return;
end

if isfield(cfg,'edsi') && isstruct(cfg.edsi)
    opt = copy_known_fields_local(opt,cfg.edsi);
end

if isfield(cfg,'llmEdsi') && isstruct(cfg.llmEdsi)
    opt.llm = copy_known_fields_local(opt.llm,cfg.llmEdsi);
end

% Fair-comparison invariant: EDSI/LLM-EDSI use the same pointwise SINDy
% identification backend as V-SINDy. Evolution changes only the dictionary.
% Search still uses only 1--3 STLSQ turns for speed, but it shares the same
% threshold grid, near-best sparsity band, OLS support discovery, fixed clean
% final-support rho, and noisy-label support-ridge policy/grid as V-SINDy.
if logical(opt.shareSindyIdentificationBackend) && ...
        isfield(cfg,'sindy') && isstruct(cfg.sindy) && ...
        isfield(cfg.sindy,'stlsq') && isstruct(cfg.sindy.stlsq)
    if isfield(cfg.sindy.stlsq,'ridge') && ~isempty(cfg.sindy.stlsq.ridge)
        opt.supportDiscoveryRho = double(cfg.sindy.stlsq.ridge);
    end
    if isfield(cfg.sindy.stlsq,'finalSupportRidgeRho') && ...
            ~isempty(cfg.sindy.stlsq.finalSupportRidgeRho)
        opt.finalSupportRidgeRho = double(cfg.sindy.stlsq.finalSupportRidgeRho);
    end
    opt.rho = opt.finalSupportRidgeRho;
    if isfield(cfg.sindy.stlsq,'thresholdGrid') && ...
            ~isempty(cfg.sindy.stlsq.thresholdGrid)
        sharedGrid = double(cfg.sindy.stlsq.thresholdGrid(:).');
        opt.searchThresholdGrid = sharedGrid;
        opt.finalThresholdGrid = sharedGrid;
    end
    if isfield(cfg.sindy.stlsq,'preferSparseWithinRelativeValidationTolerance') && ...
            ~isempty(cfg.sindy.stlsq.preferSparseWithinRelativeValidationTolerance)
        sharedTol = double(cfg.sindy.stlsq.preferSparseWithinRelativeValidationTolerance);
        opt.searchPreferSparseWithinRelativeValidationTolerance = sharedTol;
        opt.finalPreferSparseWithinRelativeValidationTolerance = sharedTol;
    end
end

if opt.populationSize <= opt.eliteCount || opt.eliteCount < 1 || ...
        mod(opt.populationSize-opt.eliteCount,opt.eliteCount) ~= 0
    error('get_edsi_options:PopulationArithmetic', ...
        'Require P>K>=1 and (P-K) divisible by K.');
end
if abs(sum(opt.mutationSlotProbabilities)-1) > 1e-12 || ...
        numel(opt.mutationSlotCounts) ~= numel(opt.mutationSlotProbabilities)
    error('get_edsi_options:MutationProbabilities', ...
        'mutationSlotCounts/probabilities are invalid.');
end
if abs(opt.productProbability+opt.sinProbability+opt.cosProbability-1) > 1e-12
    error('get_edsi_options:OperatorProbabilities', ...
        'product/sin/cos probabilities must sum to one.');
end
validateattributes(opt.supportDiscoveryRho,{'numeric'}, ...
    {'scalar','real','finite','nonnegative'});
validateattributes(opt.finalSupportRidgeRho,{'numeric'}, ...
    {'scalar','real','finite','nonnegative'});
validateattributes(opt.residualChampionMinRelativeImprovement,{'numeric'}, ...
    {'scalar','real','finite','>=',0,'<',1});
opt.residualRefinementShortRolloutEnabled = logical(opt.residualRefinementShortRolloutEnabled);
if opt.shareSindyIdentificationBackend && opt.supportDiscoveryRho ~= 0
    error('get_edsi_options:SupportDiscoveryMustBeOLS', ...
        'Shared V-SINDy backend requires supportDiscoveryRho=0.');
end
opt.rho = opt.finalSupportRidgeRho;
opt.shareSindyIdentificationBackend = logical(opt.shareSindyIdentificationBackend);
validateattributes(opt.searchStlsqIterations,{'numeric'}, ...
    {'scalar','integer','>=',1,'<=',3});
validateattributes(opt.finalStlsqIterations,{'numeric'}, ...
    {'scalar','integer','>=',1});
validateattributes(opt.searchThresholdGrid,{'numeric'}, ...
    {'vector','nonempty','nonnegative','finite'});
validateattributes(opt.finalThresholdGrid,{'numeric'}, ...
    {'vector','nonempty','nonnegative','finite'});
validateattributes(opt.searchPreferSparseWithinRelativeValidationTolerance, ...
    {'numeric'},{'scalar','nonnegative','finite'});
validateattributes(opt.finalPreferSparseWithinRelativeValidationTolerance, ...
    {'numeric'},{'scalar','nonnegative','finite'});
opt.searchThresholdGrid = unique(double(opt.searchThresholdGrid(:).'),'stable');
opt.finalThresholdGrid = unique(double(opt.finalThresholdGrid(:).'),'stable');

if opt.llm.enabled
    if strlength(string(opt.llm.adapterPath))==0 || ...
            strlength(string(opt.llm.configPath))==0
        error('get_edsi_options:LLMPaths', ...
            'LLM-EDSI requires cfg.llmEdsi.adapterPath and configPath.');
    end
    validateattributes(opt.llm.currentOdeTermsPerDerivative,{'numeric'}, ...
        {'scalar','integer','>=',1});
    validateattributes(opt.llm.maxActiveDictionaryTerms,{'numeric'}, ...
        {'scalar','integer','>=',1});
    validateattributes(opt.llm.inactiveContextTerms,{'numeric'}, ...
        {'scalar','integer','>=',0});
    validateattributes(opt.llm.maxProposedTerms,{'numeric'}, ...
        {'scalar','integer','>=',1});
end
end


function out = copy_known_fields_local(out,in)
fn = fieldnames(out);
for i = 1:numel(fn)
    f = fn{i};
    if isfield(in,f) && ~isempty(in.(f))
        out.(f) = in.(f);
    end
end
end
