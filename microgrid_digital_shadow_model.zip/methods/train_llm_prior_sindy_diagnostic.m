function [model,info] = train_llm_prior_sindy_diagnostic(dataset,c,layout,cfg)
%TRAIN_LLM_PRIOR_SINDY_DIAGNOSTIC V-SINDy + weak-domain LLM prior bank.
%
% Diagnostic only.  The generic V-SINDy library is unchanged; the LLM prior
% bank is appended and all coefficients/support are identified with the same
% validation-selected STLSQ (+ noisy-label frozen-support ridge) backend as
% V-SINDy and PE-SINDy.

opt = get_sindy_options(cfg);
if ~isfield(opt,'llmPriorDiagnostic') || ~logical(opt.llmPriorDiagnostic.enabled)
    error('train_llm_prior_sindy_diagnostic:Disabled', ...
        'cfg.sindy.llmPriorDiagnostic.enabled must be true.');
end

[K,trainIds,valIds,trainMask,valMask,forcedTrainIds] = split_local(dataset,opt);
model.type = 'modular_sindy';
model.formulationVersion = 'llm_prior_sindy_weak_domain_compiled_dag_diag_v5_motif_closure';
model.variant = 'llmprior';
model.libraryVariant = 'llmprior';
model.fitMode = 'standard';
model.trainingSampleDefinition = 'flattened pointwise samples from common short-trajectory dataset';
model.sg = struct([]); model.gfm = struct([]); model.gfl = struct([]);
model.trainTrajectoryIds = trainIds(:);
model.validationTrajectoryIds = valIds(:);
model.forcedTrainingTrajectoryIds = forcedTrainIds(:);
model.options = opt;

modules = struct([]); mi=0; activeTotal=0; candidateTotal=0;
for k=1:numel(c.sg)
    fprintf('    Training LLM-prior SINDy module SG%d (Bus %d)...\n',k,c.sg(k).bus);
    data=build_sindy_module_data(dataset,c,layout,'sg',k);
    [mk,ik]=fit_sindy_stlsq_module(data,trainMask,valMask,'llmprior',opt,'standard');
    if k==1, model.sg=mk; else, model.sg(k,1)=mk; end
    [modules,mi]=append_info_local(modules,mi,ik);
    activeTotal=activeTotal+ik.activeCoefficientCount;
    candidateTotal=candidateTotal+ik.candidateCoefficientCount;
end
for k=1:numel(c.gfm)
    fprintf('    Training LLM-prior SINDy module GFM%d (Bus %d)...\n',k,c.gfm(k).bus);
    data=build_sindy_module_data(dataset,c,layout,'gfm',k);
    [mk,ik]=fit_sindy_stlsq_module(data,trainMask,valMask,'llmprior',opt,'standard');
    if k==1, model.gfm=mk; else, model.gfm(k,1)=mk; end
    [modules,mi]=append_info_local(modules,mi,ik);
    activeTotal=activeTotal+ik.activeCoefficientCount;
    candidateTotal=candidateTotal+ik.candidateCoefficientCount;
end
for k=1:numel(c.gfl)
    fprintf('    Training LLM-prior SINDy module GFL%d (Bus %d)...\n',k,c.gfl(k).bus);
    data=build_sindy_module_data(dataset,c,layout,'gfl',k);
    [mk,ik]=fit_sindy_stlsq_module(data,trainMask,valMask,'llmprior',opt,'standard');
    if k==1, model.gfl=mk; else, model.gfl(k,1)=mk; end
    [modules,mi]=append_info_local(modules,mi,ik);
    activeTotal=activeTotal+ik.activeCoefficientCount;
    candidateTotal=candidateTotal+ik.candidateCoefficientCount;
end
model.activeCoefficientCount=activeTotal;
model.candidateCoefficientCount=candidateTotal;
model.compatibilitySchema='diagnostic_only';
model.compatibilitySignature=struct('method','llm_prior_sindy_diagnostic', ...
    'priorBankHash',char(string(opt.llmPriorDiagnostic.priorBankHash)));

info.method='llm_prior_sindy_diagnostic';
info.displayName='LLM-Prior SINDy';
info.formulationVersion=model.formulationVersion;
info.objective='V-SINDy generic library + weak-domain LLM compiled physical basis bank; shared STLSQ backend';
info.nSamples=size(dataset.x,1);
info.nTrajectories=K;
info.nTrainSamples=nnz(trainMask);
info.nValidationSamples=nnz(valMask);
info.trainTrajectoryIds=trainIds(:);
info.validationTrajectoryIds=valIds(:);
info.forcedTrainingTrajectoryIds=forcedTrainIds(:);
info.modules=modules;
info.activeCoefficientCount=activeTotal;
info.candidateCoefficientCount=candidateTotal;
info.priorBankHash=char(string(opt.llmPriorDiagnostic.priorBankHash));
info.discoverySeed=double(opt.llmPriorDiagnostic.discoverySeed);

if ~isempty(forcedTrainIds) && opt.verbose
    fprintf('    Forced into SINDy training partition: trajectory ID(s) [%s]\n', ...
        strtrim(sprintf('%d ',forcedTrainIds)));
end
end

function [K,trainIds,valIds,trainMask,valMask,forcedTrainIds]=split_local(dataset,opt)
K=dataset.trajectories.nTrajectories;
if K<2, error('train_llm_prior_sindy_diagnostic:TooFewTrajectories','Need at least two trajectories.'); end
forcedTrainIds=[];
if isfield(dataset.trajectories,'forceTrainingMask') && ~isempty(dataset.trajectories.forceTrainingMask)
    m=logical(dataset.trajectories.forceTrainingMask(:));
    if numel(m)~=K, error('train_llm_prior_sindy_diagnostic:ForceTrainingMask','forceTrainingMask size mismatch.'); end
    forcedTrainIds=find(m).';
end
candidates=setdiff(1:K,forcedTrainIds,'stable');
old=rng; cleanup=onCleanup(@()rng(old)); %#ok<NASGU>
rng(opt.validationSeed,'twister');
perm=candidates(randperm(numel(candidates)));
nVal=max(1,round(opt.validationFraction*K)); nVal=min(nVal,numel(candidates));
if nVal>=K, nVal=K-1; end
valIds=sort(perm(1:nVal));
trainIds=sort(setdiff(1:K,valIds,'stable'));
trainMask=ismember(dataset.trajectoryId,trainIds);
valMask=ismember(dataset.trajectoryId,valIds);
end

function [S,mi]=append_info_local(S,mi,ik)
mi=mi+1; if mi==1, S=ik; else, S(mi,1)=ik; end
end
