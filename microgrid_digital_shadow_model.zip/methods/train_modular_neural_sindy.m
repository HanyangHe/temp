function [model,info] = train_modular_neural_sindy(dataset,c,layout,cfg,mode)
%TRAIN_MODULAR_NEURAL_SINDY Common trainer for compact neural SINDy variants.
%
% All variants use the same whole-trajectory train/validation partition as
% the existing SINDy baselines. Time order is not used by regression.

opt = get_sindy_options(cfg);
mode = lower(string(mode));
if ~any(mode == ["neural","physics_neural","prior_weighted_neural"])
    error('train_modular_neural_sindy:Mode','Unknown mode "%s".',mode);
end

K = dataset.trajectories.nTrajectories;
if K < 2
    error('train_modular_neural_sindy:TooFewTrajectories', ...
        'At least two trajectories are required.');
end

forcedTrainIds = [];
if isfield(dataset.trajectories,'forceTrainingMask') && ...
        ~isempty(dataset.trajectories.forceTrainingMask)
    m = logical(dataset.trajectories.forceTrainingMask(:));
    if numel(m) ~= K
        error('train_modular_neural_sindy:ForceTrainingMaskSize', ...
            'forceTrainingMask must contain one entry per trajectory.');
    end
    forcedTrainIds = find(m).';
end

validationCandidates = setdiff(1:K,forcedTrainIds,'stable');
if isempty(validationCandidates)
    error('train_modular_neural_sindy:NoValidationCandidates', ...
        'No trajectory remains for validation.');
end
oldRng = rng;
cleanup = onCleanup(@()rng(oldRng)); %#ok<NASGU>
rng(opt.validationSeed,'twister');
perm = validationCandidates(randperm(numel(validationCandidates)));
nVal = max(1,round(opt.validationFraction*K));
nVal = min(nVal,numel(validationCandidates));
if nVal >= K, nVal=K-1; end
valIds = sort(perm(1:nVal));
trainIds = sort(setdiff(1:K,valIds,'stable'));
trainMask = ismember(dataset.trajectoryId,trainIds);
valMask = ismember(dataset.trajectoryId,valIds);

model.type = 'modular_sindy'; % reuse common sparse-model export/replay structure
model.formulationVersion = char(opt.formulationVersion);
model.method = mode_label(mode);
model.variant = char(mode);
model.trainingObjective = 'pointwise vector-field STLSQ with compact fixed neural-ridge dictionary';
model.trainingSampleDefinition = 'flattened pointwise samples from common short-trajectory dataset';
model.sg = struct([]); model.gfm = struct([]); model.gfl = struct([]);
model.trainTrajectoryIds = trainIds(:);
model.validationTrajectoryIds = valIds(:);
model.forcedTrainingTrajectoryIds = forcedTrainIds(:);
model.options = opt;

modules = struct([]);
mi = 0;
activeTotal = 0;
candidateTotal = 0;

for k = 1:numel(c.sg)
    fprintf('    Training %s module SG%d (Bus %d)...\n',mode_label(mode),k,c.sg(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'sg',k);
    seed = module_seed_local(opt.neuralBasis.seed,'sg',k);
    [mk,ik] = fit_neural_sindy_stlsq_module(data,trainMask,valMask,mode,opt,seed);
    if k==1, model.sg=mk; else, model.sg(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    activeTotal = activeTotal + ik.activeCoefficientCount;
    candidateTotal = candidateTotal + ik.candidateCoefficientCount;
end
for k = 1:numel(c.gfm)
    fprintf('    Training %s module GFM%d (Bus %d)...\n',mode_label(mode),k,c.gfm(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfm',k);
    seed = module_seed_local(opt.neuralBasis.seed,'gfm',k);
    [mk,ik] = fit_neural_sindy_stlsq_module(data,trainMask,valMask,mode,opt,seed);
    if k==1, model.gfm=mk; else, model.gfm(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    activeTotal = activeTotal + ik.activeCoefficientCount;
    candidateTotal = candidateTotal + ik.candidateCoefficientCount;
end
for k = 1:numel(c.gfl)
    fprintf('    Training %s module GFL%d (Bus %d)...\n',mode_label(mode),k,c.gfl(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfl',k);
    seed = module_seed_local(opt.neuralBasis.seed,'gfl',k);
    [mk,ik] = fit_neural_sindy_stlsq_module(data,trainMask,valMask,mode,opt,seed);
    if k==1, model.gfl=mk; else, model.gfl(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    activeTotal = activeTotal + ik.activeCoefficientCount;
    candidateTotal = candidateTotal + ik.candidateCoefficientCount;
end

model.activeCoefficientCount = activeTotal;
model.candidateCoefficientCount = candidateTotal;

% Embed the method-specific compatibility contract in the trained model.
compatMethodName = compatibility_method_name_local(mode);
[okCompatibility,compatibility] = check_sindy_model_compatibility( ...
    compatMethodName,model,cfg);
if ~okCompatibility
    error('train_modular_neural_sindy:CompatibilityContract', ...
        ['Newly trained %s model violates its method contract:\n  - %s'], ...
        compatMethodName,strjoin(string(compatibility.issues),sprintf('\n  - ')));
end
model.compatibilitySchema = compatibility.schemaVersion;
model.compatibilitySignature = compatibility.actual;

info.method = char(mode);
info.formulationVersion = char(opt.formulationVersion);
info.displayName = mode_label(mode);
info.variant = char(mode);
info.objective = 'pointwise sparse vector-field regression with compact fixed neural-ridge dictionary';
info.nSamples = size(dataset.x,1);
info.nTrajectories = K;
info.nTrainSamples = nnz(trainMask);
info.nValidationSamples = nnz(valMask);
info.nTrainTrajectories = numel(trainIds);
info.nValidationTrajectories = numel(valIds);
info.trainTrajectoryIds = trainIds(:);
info.validationTrajectoryIds = valIds(:);
info.forcedTrainingTrajectoryIds = forcedTrainIds(:);
info.modules = modules;
info.activeCoefficientCount = activeTotal;
info.candidateCoefficientCount = candidateTotal;
info.compatibilitySchema = compatibility.schemaVersion;
info.compatibilitySignature = compatibility.actual;
info.neuralBasisFeatureCount = opt.neuralBasis.featureCount;
info.neuralBasisActivation = opt.neuralBasis.activation;
info.neuralBasisQuantiles = opt.neuralBasis.quantiles;
info.neuralBasisScales = opt.neuralBasis.scales;

if ~isempty(forcedTrainIds) && opt.verbose
    fprintf('    Forced into neural-basis SINDy training partition: trajectory ID(s) [%s]\n', ...
        strtrim(sprintf('%d ',forcedTrainIds)));
end
end

function [S,mi] = append_info_local(S,mi,ik)
mi=mi+1;
if mi==1, S=ik; else, S(mi,1)=ik; end
end

function seed = module_seed_local(baseSeed,deviceType,k)
switch lower(char(deviceType))
    case 'sg', offset=100*k;
    case 'gfm', offset=10000+100*k;
    case 'gfl', offset=20000+100*k;
    otherwise, offset=30000+100*k;
end
seed = round(double(baseSeed))+offset;
end

function name = compatibility_method_name_local(mode)
switch char(mode)
    case 'neural', name = 'neural_sindy';
    case 'physics_neural', name = 'physics_neural_sindy';
    case 'prior_weighted_neural', name = 'prior_weighted_neural_sindy';
    otherwise
        error('train_modular_neural_sindy:CompatibilityMethod','Unknown mode %s.',char(mode));
end
end

function txt = mode_label(mode)
switch char(mode)
    case 'neural', txt='Neural SINDy';
    case 'physics_neural', txt='Physics-Neural SINDy';
    case 'prior_weighted_neural', txt='Prior-weighted Neural SINDy';
    otherwise, txt=char(mode);
end
end
