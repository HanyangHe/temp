function [model,info] = train_neural_sindy(dataset,c,layout,cfg)
%TRAIN_NEURAL_SINDY Compact [1,raw chi,fixed neural-ridge] SINDy baseline.
[model,info] = train_modular_neural_sindy(dataset,c,layout,cfg,'neural');
end
