function [tf,details] = check_llm_prior_sindy_model_compatibility(model,cfg)
%CHECK_LLM_PRIOR_SINDY_MODEL_COMPATIBILITY Strict saved-model check for online use.
%
% The online phase must NEVER rediscover an LLM prior.  It must use the exact
% compiled dictionary stored inside the saved offline model.  Compatibility is
% therefore checked from the saved model itself plus the current formal V4
% protocol tag.  No cloud/API call is made here.

issues = strings(0,1);
expectedOpt = get_sindy_options(cfg);

expectedForm = "";
expectedProtocol = "";
if isfield(expectedOpt,'llmPrior') && isstruct(expectedOpt.llmPrior)
    if isfield(expectedOpt.llmPrior,'formulationVersion')
        expectedForm = string(expectedOpt.llmPrior.formulationVersion);
    end
    if isfield(expectedOpt.llmPrior,'discoveryProtocolVersion')
        expectedProtocol = string(expectedOpt.llmPrior.discoveryProtocolVersion);
    end
end

savedForm = "";
if isfield(model,'formulationVersion'), savedForm=string(model.formulationVersion); end
savedVariant = "";
if isfield(model,'variant'), savedVariant=string(model.variant); end

if ~isfield(model,'type') || ~strcmpi(string(model.type),'modular_sindy')
    issues(end+1,1) = "model.type is not modular_sindy"; %#ok<AGROW>
end
if ~strcmpi(savedVariant,'llmprior')
    issues(end+1,1) = "model.variant is not llmprior"; %#ok<AGROW>
end
if strlength(expectedForm)>0 && ~strcmp(savedForm,expectedForm)
    issues(end+1,1) = "formal LLM-Prior formulationVersion differs"; %#ok<AGROW>
end

savedProtocol = "";
savedSeed = NaN;
savedHash = "";
if isfield(model,'options') && isstruct(model.options) && ...
        isfield(model.options,'llmPrior') && isstruct(model.options.llmPrior)
    lp=model.options.llmPrior;
    if isfield(lp,'discoveryProtocolVersion')
        savedProtocol=string(lp.discoveryProtocolVersion);
    end
    if isfield(lp,'discoverySeed'), savedSeed=double(lp.discoverySeed); end
    if isfield(lp,'priorBankHash'), savedHash=string(lp.priorBankHash); end
    if ~isfield(lp,'priorBank') || ~isstruct(lp.priorBank)
        issues(end+1,1) = "saved model.options.llmPrior.priorBank is missing"; %#ok<AGROW>
    else
        for d={'sg','gfm','gfl'}
            if ~isfield(lp.priorBank,d{1}) || isempty(lp.priorBank.(d{1}))
                issues(end+1,1) = "saved LLM prior bank is missing device type "+string(d{1}); %#ok<AGROW>
            end
        end
    end
else
    issues(end+1,1) = "saved model.options.llmPrior metadata is missing"; %#ok<AGROW>
end

if strlength(expectedProtocol)>0 && ~strcmp(savedProtocol,expectedProtocol)
    issues(end+1,1) = "LLM discovery protocol differs: saved="+savedProtocol+ ...
        ", expected="+expectedProtocol; %#ok<AGROW>
end

% Optional explicit deployment pin.  The smoke test pins the first predefined
% V4 prior realization (20260814) so the online result cannot silently use a
% different discovery bank.
if isfield(cfg,'online') && isfield(cfg.online,'llmPrior') && ...
        isstruct(cfg.online.llmPrior)
    q=cfg.online.llmPrior;
    if isfield(q,'discoverySeed') && ~isempty(q.discoverySeed) && ...
            isfinite(double(q.discoverySeed))
        if ~isfinite(savedSeed) || round(savedSeed)~=round(double(q.discoverySeed))
            issues(end+1,1) = sprintf('saved discovery seed %g differs from required %g', ...
                savedSeed,double(q.discoverySeed)); %#ok<AGROW>
        end
    end
    if isfield(q,'priorBankHash') && strlength(string(q.priorBankHash))>0
        if ~strcmp(savedHash,string(q.priorBankHash))
            issues(end+1,1) = "saved prior-bank hash differs from required deployment hash"; %#ok<AGROW>
        end
    end
end

if strlength(savedHash)==0
    issues(end+1,1) = "saved prior-bank hash is empty"; %#ok<AGROW>
end

% Every module must carry a complete stored evaluator.  This guarantees online
% rollout and RLS evaluate the existing symbolic bank locally without LLM use.
for d={'sg','gfm','gfl'}
    dn=d{1};
    if ~isfield(model,dn) || isempty(model.(dn)), continue; end
    arr=model.(dn);
    for k=1:numel(arr)
        m=arr(k);
        prefix=sprintf('%s%d',upper(dn),k);
        if ~isfield(m,'variant') || ~strcmpi(string(m.variant),'llmprior')
            issues(end+1,1)=prefix+" variant is not llmprior"; %#ok<AGROW>
        end
        if ~isfield(m,'libraryNames') || ~isfield(m,'coefficients') || ...
                numel(m.libraryNames)~=size(m.coefficients,1)
            issues(end+1,1)=prefix+" library/coefficient dimensions are inconsistent"; %#ok<AGROW>
        elseif any(~isfinite(double(m.coefficients)),'all')
            issues(end+1,1)=prefix+" contains nonfinite coefficients"; %#ok<AGROW>
        end
        if ~isfield(m,'librarySpec') || ~isstruct(m.librarySpec) || ...
                ~isfield(m.librarySpec,'llmPriorCompiledSpec') || ...
                isempty(m.librarySpec.llmPriorCompiledSpec)
            issues(end+1,1)=prefix+" is missing compiled LLM-prior DSL metadata"; %#ok<AGROW>
        end
        if ~isfield(m,'libraryColumnScale') || ...
                numel(m.libraryColumnScale)~=size(m.coefficients,1)
            issues(end+1,1)=prefix+" libraryColumnScale is incomplete"; %#ok<AGROW>
        end
        if ~isfield(m,'outputScale') || numel(m.outputScale)~=size(m.coefficients,2)
            issues(end+1,1)=prefix+" outputScale is incomplete"; %#ok<AGROW>
        end
    end
end

% Cross-check compatibility signature if present.
if isfield(model,'compatibilitySignature') && isstruct(model.compatibilitySignature)
    cs=model.compatibilitySignature;
    if isfield(cs,'method') && ~strcmpi(string(cs.method),'llm_prior_sindy')
        issues(end+1,1)="compatibilitySignature.method is not llm_prior_sindy"; %#ok<AGROW>
    end
    if isfield(cs,'discoverySeed') && isfinite(savedSeed) && ...
            round(double(cs.discoverySeed))~=round(savedSeed)
        issues(end+1,1)="compatibilitySignature discovery seed is internally inconsistent"; %#ok<AGROW>
    end
    if isfield(cs,'priorBankHash') && strlength(savedHash)>0 && ...
            ~strcmp(string(cs.priorBankHash),savedHash)
        issues(end+1,1)="compatibilitySignature prior hash is internally inconsistent"; %#ok<AGROW>
    end
end

tf=isempty(issues);
details=struct();
details.schemaVersion='llm_prior_online_compatibility_v1';
details.compatible=tf;
details.methodName='llm_prior_sindy';
details.storedModelVariant=savedVariant;
details.canonicalModelVariant=savedVariant;
details.legacyVariantAliasApplied=false;
details.savedFormulationVersion=savedForm;
details.currentFormulationVersion=expectedForm;
details.discoveryProtocolVersion=savedProtocol;
details.discoverySeed=savedSeed;
details.priorBankHash=savedHash;
details.issues=issues;
if tf
    details.message='Saved formal LLM-Prior SINDy model is self-contained and compatible for online deployment.';
else
    details.message=strjoin(issues,newline);
end
end
