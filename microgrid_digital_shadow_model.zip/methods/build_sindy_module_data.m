function data = build_sindy_module_data(dataset,c,layout,deviceType,deviceIndex)
%BUILD_SINDY_MODULE_DATA Flatten one DER's pointwise [chi -> xdot] samples.
%
% Sample ordering is immaterial to SINDy regression. trajectoryId is retained
% only so train/validation partitioning can be done by complete trajectories.

N = size(dataset.x,1);
if size(dataset.labels,1) ~= N || size(dataset.V,1) ~= N
    error('build_sindy_module_data:SampleSize','Flat dataset arrays have inconsistent row counts.');
end

switch lower(char(deviceType))
    case 'sg'
        idx = layout.sg{deviceIndex};
        bus = c.sg(deviceIndex).bus;
        if numel(idx) == 5 && isfield(c.input.nominal,'sgVref')
            inputNames = ["delta";"nu";"EqPrime";"EdPrime";"Efd"; ...
                "Vterminal_Re";"Vterminal_Im";"Pm";"Vref"];
            outputNames = ["delta_dot";"nu_dot";"EqPrime_dot";"EdPrime_dot";"Efd_dot"];
            nIn = 9;
        else
            inputNames = ["delta";"nu";"Vterminal_Re";"Vterminal_Im";"Pm"];
            outputNames = ["delta_dot";"nu_dot"];
            nIn = 5;
        end
    case 'gfm'
        idx = layout.gfm{deviceIndex};
        bus = c.gfm(deviceIndex).bus;
        inputNames = ["delta";"pFilt";"qFilt";"E"; ...
            "Vterminal_Re";"Vterminal_Im";"Pstar";"Qstar";"Eref"];
        outputNames = ["delta_dot";"pFilt_dot";"qFilt_dot";"E_dot"];
        nIn = 9;
    case 'gfl'
        idx = layout.gfl{deviceIndex};
        bus = c.gfl(deviceIndex).bus;
        inputNames = ["thetaPLL";"xiPLL";"id";"iq"; ...
            "Vterminal_Re";"Vterminal_Im";"Pstar";"Qstar"];
        outputNames = ["thetaPLL_dot";"xiPLL_dot";"id_dot";"iq_dot"];
        nIn = 8;
    otherwise
        error('build_sindy_module_data:DeviceType','Unknown deviceType "%s".',char(deviceType));
end

X = zeros(N,nIn);
X(:,1:numel(idx)) = dataset.x(:,idx);
X(:,numel(idx)+1) = real(dataset.V(:,bus));
X(:,numel(idx)+2) = imag(dataset.V(:,bus));

for i = 1:N
    tr = dataset.trajectoryId(i);
    if tr < 1 || tr > dataset.trajectories.nTrajectories
        error('build_sindy_module_data:TrajectoryId','Invalid trajectoryId=%d at sample %d.',tr,i);
    end
    if isfield(dataset,'sampleInputByRow') && numel(dataset.sampleInputByRow) >= i && ...
            ~isempty(dataset.sampleInputByRow{i})
        u = dataset.sampleInputByRow{i};
    else
        if tr > numel(dataset.trajectories.uByTrajectory)
            error('build_sindy_module_data:TrajectoryInput', ...
                'No input record is available for trajectoryId=%d at sample %d.',tr,i);
        end
        u = dataset.trajectories.uByTrajectory{tr};
    end
    switch lower(char(deviceType))
        case 'sg'
            if nIn == 9
                X(i,end-1:end) = [u.sgPm(deviceIndex),u.sgVref(deviceIndex)];
            else
                X(i,end) = u.sgPm(deviceIndex);
            end
        case 'gfm'
            X(i,end-2:end) = [u.gfmPstar(deviceIndex), ...
                u.gfmQstar(deviceIndex),u.gfmEref(deviceIndex)];
        case 'gfl'
            X(i,end-1:end) = [u.gflPstar(deviceIndex),u.gflQstar(deviceIndex)];
    end
end

Y = dataset.labels(:,idx);
Yclean = dataset.labelsClean(:,idx);

data.deviceType = lower(string(deviceType));
data.deviceIndex = deviceIndex;
data.stateIndices = idx(:);
data.bus = bus;
data.X = X;
data.Y = Y;
data.Yclean = Yclean;
data.inputNames = inputNames;
data.outputNames = outputNames;

% Identification-label provenance controls the shared post-STLSQ numerical
% conditioning policy. Sections 1.1/1.2 use exact physical xdot labels, while
% Section 1.3 reconstructs xdot from the common measured state trajectories.
labelProtocol = "clean_exact_vector_field";
derivativeLabelsReconstructed = false;
if isfield(dataset,'metadata') && isstruct(dataset.metadata) && ...
        isfield(dataset.metadata,'trainingNoiseProtocol') && ...
        strlength(string(dataset.metadata.trainingNoiseProtocol)) > 0
    labelProtocol = string(dataset.metadata.trainingNoiseProtocol);
    derivativeLabelsReconstructed = true;
end
data.derivativeLabelProtocol = char(labelProtocol);
data.derivativeLabelsReconstructed = derivativeLabelsReconstructed;
data.derivativeLabelsExact = ~derivativeLabelsReconstructed;

data.trajectoryId = dataset.trajectoryId(:);
if isfield(dataset,'pointInTrajectory') && ~isempty(dataset.pointInTrajectory)
    data.pointInTrajectory = dataset.pointInTrajectory(:);
else
    L = dataset.trajectories.pointsPerTrajectory;
    data.pointInTrajectory = repmat((1:L).',dataset.trajectories.nTrajectories,1);
end

% Preserve the explicitly observed state trajectory for derivative-free/
% weak-form identification. Under clean training this equals dataset.x. Under
% the common measurement-noise protocol, dataset.x and xObservedFlat are the
% same noisy measured states, so both the candidate dictionary and weak target
% are built from the same physical observation stream.
if isfield(dataset,'xObservedFlat') && ~isempty(dataset.xObservedFlat)
    if size(dataset.xObservedFlat,1) ~= N
        error('build_sindy_module_data:ObservedStateFlatSize', ...
            'dataset.xObservedFlat does not match dataset sample count.');
    end
    data.stateObserved = dataset.xObservedFlat(:,idx);
elseif isfield(dataset,'trajectories') && isfield(dataset.trajectories,'xObserved') && ...
        ~isempty(dataset.trajectories.xObserved)
    XobsAll = reshape(dataset.trajectories.xObserved,[],size(dataset.x,2));
    if size(XobsAll,1) ~= N
        error('build_sindy_module_data:ObservedStateSize', ...
            'Flattened trajectories.xObserved does not match dataset sample count.');
    end
    data.stateObserved = XobsAll(:,idx);
else
    data.stateObserved = dataset.x(:,idx);
end
data.stateClean = dataset.x(:,idx);

if isfield(dataset.trajectories,'t') && ~isempty(dataset.trajectories.t)
    data.trajectoryTime = dataset.trajectories.t(:);
else
    error('build_sindy_module_data:MissingTrajectoryTime', ...
        'MHID-compatible SINDy data require dataset.trajectories.t.');
end
data.nSamples = N;
data.nInputs = nIn;
data.nOutputs = numel(idx);
end
