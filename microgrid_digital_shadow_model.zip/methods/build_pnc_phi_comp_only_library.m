function [Theta,names,spec] = build_pnc_phi_comp_only_library( ...
    X,H,inputNames,outputNames,opt,seed,specIn)
%BUILD_PNC_PHI_COMP_ONLY_LIBRARY Strict Phi_comp-only PNC diagnostic library.
%
%   H = f_PE_hat(chi)                                  (frozen layer 1)
%   Z = [chi, H]
%   Theta_2 = Phi_comp(Z)                              (fixed tanh bank only)
%   xdot_hat = Theta_2 * Xi_2
%
% This is a deliberately strict ablation: the layer-2 readout contains NO
% direct H/PE bypass and NO flat-PN skip. Physics enters layer 2 only through
% the frozen PE representation H used as part of the input to Phi_comp.

if nargin < 7, specIn = []; end
validateattributes(X,{'numeric'},{'2d','real','finite','nonempty'},mfilename,'X');
validateattributes(H,{'numeric'},{'2d','real','finite','nonempty'},mfilename,'H');
if size(X,1) ~= size(H,1)
    error('build_pnc_phi_comp_only_library:RowCount', ...
        'X and H must contain the same number of rows.');
end

inputNames = string(inputNames(:));
outputNames = string(outputNames(:));
if size(X,2) ~= numel(inputNames)
    error('build_pnc_phi_comp_only_library:InputNames', ...
        'X has %d columns but inputNames has %d entries.',size(X,2),numel(inputNames));
end
if size(H,2) ~= numel(outputNames)
    error('build_pnc_phi_comp_only_library:OutputNames', ...
        'H has %d columns but outputNames has %d entries.',size(H,2),numel(outputNames));
end

Z = [X H];
augNames = [inputNames; "pe_hat_" + outputNames];
compSeed = round(double(seed)) + ...
    round(double(opt.physicsNeuralCompositional.compositionalSeedOffset));

if isempty(specIn)
    [PhiComp,compSpec] = make_fixed_neural_ridge_basis( ...
        Z,opt.neuralBasis.featureCount,opt.neuralBasis,compSeed,[]);
    spec = struct();
    spec.architecture = 'phi_comp_only_v1';
    spec.rawInputCount = size(X,2);
    spec.layer1OutputCount = size(H,2);
    spec.inputNames = inputNames;
    spec.outputNames = outputNames;
    spec.augmentedInputNames = augNames;
    spec.compositionalNeural = compSpec;
    spec.neural = compSpec; % compatibility alias for generic diagnostics
    spec.compositionalBasisSeed = compSeed;
else
    spec = specIn;
    required = {'architecture','rawInputCount','layer1OutputCount', ...
        'inputNames','outputNames','augmentedInputNames', ...
        'compositionalNeural','compositionalBasisSeed'};
    for k = 1:numel(required)
        if ~isfield(spec,required{k})
            error('build_pnc_phi_comp_only_library:StoredSpec', ...
                'Stored Phi_comp-only spec is missing field %s.',required{k});
        end
    end
    if ~strcmp(char(string(spec.architecture)),'phi_comp_only_v1')
        error('build_pnc_phi_comp_only_library:ArchitectureVersion', ...
            'Stored library spec is not the strict Phi_comp-only architecture.');
    end
    if size(X,2) ~= double(spec.rawInputCount) || ...
            size(H,2) ~= double(spec.layer1OutputCount)
        error('build_pnc_phi_comp_only_library:StoredDimension', ...
            'Current input dimensions differ from the stored Phi_comp-only spec.');
    end
    [PhiComp,~] = make_fixed_neural_ridge_basis( ...
        Z,opt.neuralBasis.featureCount,opt.neuralBasis, ...
        double(spec.compositionalBasisSeed),spec.compositionalNeural);
end

Theta = PhiComp;
nComp = size(PhiComp,2);
names = compose("pnc_comp_%03d",(1:nComp).');
spec.libraryNames = names;
spec.compositionalNeuralColumnIndices = (1:nComp).';
spec.neuralColumnIndices = spec.compositionalNeuralColumnIndices;
spec.compositionalNeuralFeatureCount = nComp;
spec.retainedNeuralFeatureCount = nComp;
spec.totalFixedNeuralFeatureCount = nComp;

if numel(names) ~= size(Theta,2)
    error('build_pnc_phi_comp_only_library:NameCount', ...
        'Library-name count does not match numeric library width.');
end
if any(~isfinite(Theta),'all')
    error('build_pnc_phi_comp_only_library:Nonfinite', ...
        'Phi_comp-only library contains nonfinite values.');
end
end
