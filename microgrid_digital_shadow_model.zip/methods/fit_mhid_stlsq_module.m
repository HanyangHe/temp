function [module,info] = fit_mhid_stlsq_module(data,trainIds,valIds,opt)
%FIT_MHID_STLSQ_MODULE Fit one modular MHID model by validation-selected STLSQ.
%
% MHID retains the complete pointwise SINDy vector-field objective and adds a
% short-horizon integrated subobjective:
%
%   J = ||Y_vf - Theta_vf Xi||_F^2
%       + beta ||Y_mh - Theta_mh Xi||_F^2.
%
% The second term uses fixed-origin average-vector-field constraints over
% h=1,...,maxHorizonSteps. Both terms are linear in Xi. The objective is
% implemented as one augmented linear regression using sqrt(beta) weighting.

variant = lower(string(opt.dictionaryVariant));
[Theta,names,spec] = build_sindy_library(data.X,data.inputNames, ...
    data.deviceType,variant,opt,[]);

% -------------------------------------------------------------------------
% 1) Recover the COMPLETE original pointwise vector-field regression.
% -------------------------------------------------------------------------
trainMask = ismember(data.trajectoryId,trainIds);
valMask = ismember(data.trajectoryId,valIds);
if ~any(trainMask) || ~any(valMask)
    error('fit_mhid_stlsq_module:EmptyPointwiseSplit', ...
        'MHID training and validation pointwise blocks must both be nonempty.');
end

AvfTrRaw = Theta(trainMask,:);
YvfTrRaw = data.Y(trainMask,:);
AvfValRaw = Theta(valMask,:);
YvfValRaw = data.Y(valMask,:);

% -------------------------------------------------------------------------
% 2) Build only the ADDITIONAL multi-horizon integral subobjective.
% -------------------------------------------------------------------------
[AmhTrRaw,YmhTrRaw,trainMeta] = ...
    build_mhid_equivalent_regression(data,Theta,trainIds,opt);
[AmhValRaw,YmhValRaw,valMeta] = ...
    build_mhid_equivalent_regression(data,Theta,valIds,opt);

beta = opt.integralWeight;
if opt.maxHorizonSteps == 0 || beta == 0
    AtrRaw = AvfTrRaw;
    YtrRaw = YvfTrRaw;
    AvalRaw = AvfValRaw;
    YvalRaw = YvfValRaw;
else
    wb = sqrt(beta);
    AtrRaw = [AvfTrRaw; wb*AmhTrRaw];
    YtrRaw = [YvfTrRaw; wb*YmhTrRaw];
    AvalRaw = [AvfValRaw; wb*AmhValRaw];
    YvalRaw = [YvfValRaw; wb*YmhValRaw];
end

% Training-only normalization, matching the existing pointwise SINDy logic.
colScale = sqrt(mean(AtrRaw.^2,1));
colScale = max(colScale,opt.normalization.libraryScaleFloor);
yScale = std(YtrRaw,0,1);
yRms = sqrt(mean(YtrRaw.^2,1));
yScale = max(yScale,0.05*yRms);
yScale = max(yScale,opt.normalization.outputScaleFloor);

Atr = AtrRaw./colScale;
Aval = AvalRaw./colScale;
Btr = YtrRaw./yScale;
Bval = YvalRaw./yScale;

% Separately normalized diagnostic blocks using the SAME scales selected from
% the augmented training objective. These diagnostics do not affect fitting.
AvfTr = AvfTrRaw./colScale;
AvfVal = AvfValRaw./colScale;
BvfTr = YvfTrRaw./yScale;
BvfVal = YvfValRaw./yScale;
if ~isempty(AmhTrRaw)
    AmhTr = AmhTrRaw./colScale;
    BmhTr = YmhTrRaw./yScale;
else
    AmhTr = zeros(0,size(Atr,2));
    BmhTr = zeros(0,size(Btr,2));
end
if ~isempty(AmhValRaw)
    AmhVal = AmhValRaw./colScale;
    BmhVal = YmhValRaw./yScale;
else
    AmhVal = zeros(0,size(Aval,2));
    BmhVal = zeros(0,size(Bval,2));
end

lambdas = unique(sort(opt.stlsq.thresholdGrid(:)),'stable');
nL = numel(lambdas);
results = repmat(struct('lambda',NaN,'trainNormalizedMSE',NaN, ...
    'validationNormalizedMSE',NaN,'trainPointwiseNormalizedMSE',NaN, ...
    'validationPointwiseNormalizedMSE',NaN,'trainIntegralNormalizedMSE',NaN, ...
    'validationIntegralNormalizedMSE',NaN,'activeCoefficientCount',NaN, ...
    'XiNormalized',[]),nL,1);

for il = 1:nL
    lambda = lambdas(il);
    Xi = stlsq(Atr,Btr,lambda,opt.stlsq.maxIterations,opt.stlsq.ridge);

    trPred = Atr*Xi;
    vaPred = Aval*Xi;
    results(il).lambda = lambda;
    results(il).trainNormalizedMSE = mean((trPred-Btr).^2,'all');
    results(il).validationNormalizedMSE = mean((vaPred-Bval).^2,'all');
    results(il).trainPointwiseNormalizedMSE = ...
        mean((AvfTr*Xi-BvfTr).^2,'all');
    results(il).validationPointwiseNormalizedMSE = ...
        mean((AvfVal*Xi-BvfVal).^2,'all');
    if isempty(AmhTr)
        results(il).trainIntegralNormalizedMSE = NaN;
        results(il).validationIntegralNormalizedMSE = NaN;
    else
        results(il).trainIntegralNormalizedMSE = ...
            mean((AmhTr*Xi-BmhTr).^2,'all');
        results(il).validationIntegralNormalizedMSE = ...
            mean((AmhVal*Xi-BmhVal).^2,'all');
    end
    results(il).activeCoefficientCount = nnz(abs(Xi)>0);
    results(il).XiNormalized = Xi;
end

val = [results.validationNormalizedMSE].';
active = [results.activeCoefficientCount].';
bestVal = min(val);
tol = opt.stlsq.validationAbsoluteTolerance + ...
    opt.stlsq.preferSparseWithinRelativeValidationTolerance*max(bestVal,eps);
eligible = find(val <= bestVal + tol);
if isempty(eligible)
    [~,bestIdx] = min(val);
else
    [~,loc] = min(active(eligible));
    candidates = eligible(active(eligible)==active(eligible(loc)));
    [~,loc2] = min(val(candidates));
    bestIdx = candidates(loc2);
end
best = results(bestIdx);
XiNorm = best.XiNormalized;

% Y/yScale = (Theta/colScale)*XiNorm
% => convert back to physical-unit coefficients for the common rollout path.
coef = (XiNorm./colScale(:)).*yScale;

module.type = 'modular_sindy_module';
module.variant = char(variant);
module.trainingObjective = 'MHID: pointwise vector field + multi-horizon integral subobjective';
module.deviceType = char(data.deviceType);
module.deviceIndex = data.deviceIndex;
module.bus = data.bus;
module.stateIndices = data.stateIndices(:);
module.inputNames = string(data.inputNames(:));
module.outputNames = string(data.outputNames(:));
module.libraryNames = string(names(:));
module.librarySpec = spec;
module.coefficients = coef;
module.selectedThreshold = best.lambda;
module.libraryColumnScale = colScale(:);
module.outputScale = yScale(:);
module.activeCoefficientCount = nnz(abs(coef)>0);
module.candidateCoefficientCount = numel(coef);
module.mhidTrainMeta = trainMeta;
module.mhidValidationMeta = valMeta;
module.mhidMaxHorizonSteps = opt.maxHorizonSteps;
module.mhidIntegralWeight = beta;

sweepTable = table([results.lambda].',[results.trainNormalizedMSE].', ...
    [results.validationNormalizedMSE].',[results.trainPointwiseNormalizedMSE].', ...
    [results.validationPointwiseNormalizedMSE].',[results.trainIntegralNormalizedMSE].', ...
    [results.validationIntegralNormalizedMSE].',[results.activeCoefficientCount].', ...
    'VariableNames',{'Threshold','TrainNormalizedMSE','ValidationNormalizedMSE', ...
    'TrainPointwiseNormalizedMSE','ValidationPointwiseNormalizedMSE', ...
    'TrainIntegralNormalizedMSE','ValidationIntegralNormalizedMSE', ...
    'ActiveCoefficientCount'});

info.deviceType = char(data.deviceType);
info.deviceIndex = data.deviceIndex;
info.bus = data.bus;
info.nTrainSamples = size(AtrRaw,1);
info.nValidationSamples = size(AvalRaw,1);
info.libraryTermCount = size(Theta,2);
info.outputCount = size(YtrRaw,2);
info.candidateCoefficientCount = numel(coef);
info.activeCoefficientCount = module.activeCoefficientCount;
info.selectedThreshold = best.lambda;
info.trainNormalizedMSE = best.trainNormalizedMSE;
info.validationNormalizedMSE = best.validationNormalizedMSE;
info.trainPointwiseNormalizedMSE = best.trainPointwiseNormalizedMSE;
info.validationPointwiseNormalizedMSE = best.validationPointwiseNormalizedMSE;
info.trainIntegralNormalizedMSE = best.trainIntegralNormalizedMSE;
info.validationIntegralNormalizedMSE = best.validationIntegralNormalizedMSE;
info.thresholdSweep = sweepTable;
info.dictionaryVariant = char(variant);
info.trainingConstraintCount = size(AtrRaw,1);
info.validationConstraintCount = size(AvalRaw,1);
info.trainPointwiseConstraintCount = size(AvfTrRaw,1);
info.validationPointwiseConstraintCount = size(AvfValRaw,1);
info.trainIntegralConstraintCount = trainMeta.integralConstraintCount;
info.validationIntegralConstraintCount = valMeta.integralConstraintCount;
info.maxHorizonSteps = max(trainMeta.maxHorizonSteps,valMeta.maxHorizonSteps);
info.maxHorizonSeconds = max(trainMeta.maxHorizonSeconds,valMeta.maxHorizonSeconds);
info.integralWeight = beta;
info.fixedOriginWithinTrajectory = true;

if opt.verbose
    fprintf(['      %s%d | MHID-%s | library=%d terms | rows=%d/%d ', ...
        '(VF=%d/%d + MH=%d/%d) | H=%d | beta=%.3g | lambda=%.3g | ', ...
        'active=%d/%d | train nMSE=%.3e | val nMSE=%.3e'], ...
        upper(char(data.deviceType)),data.deviceIndex,char(variant), ...
        info.libraryTermCount,info.trainingConstraintCount, ...
        info.validationConstraintCount,info.trainPointwiseConstraintCount, ...
        info.validationPointwiseConstraintCount,info.trainIntegralConstraintCount, ...
        info.validationIntegralConstraintCount,info.maxHorizonSteps,beta, ...
        info.selectedThreshold,info.activeCoefficientCount, ...
        info.candidateCoefficientCount,info.trainNormalizedMSE, ...
        info.validationNormalizedMSE);
    if info.maxHorizonSteps > 0 && beta > 0
        fprintf(' | val(VF)=%.3e | val(MH)=%.3e', ...
            info.validationPointwiseNormalizedMSE, ...
            info.validationIntegralNormalizedMSE);
    end
    fprintf('\n');
end
end

function Xi = stlsq(A,B,lambda,maxIter,ridge)
% Keep the same STLSQ numerical structure as the existing SINDy baselines so
% the comparison isolates the objective rather than changing sparse solvers.
Xi = ridge_solve(A,B,ridge);
if lambda <= 0
    return;
end

prevMask = false(size(Xi));
for it = 1:maxIter %#ok<NASGU>
    mask = abs(Xi) >= lambda;
    Xi(~mask) = 0;
    for j = 1:size(B,2)
        active = mask(:,j);
        if any(active)
            Xi(active,j) = ridge_solve(A(:,active),B(:,j),ridge);
        else
            Xi(:,j) = 0;
        end
    end
    newMask = abs(Xi) >= lambda;
    Xi(~newMask) = 0;
    if isequal(newMask,prevMask)
        break;
    end
    prevMask = newMask;
end
end

function X = ridge_solve(A,B,ridge)
if isempty(A)
    X = zeros(0,size(B,2));
    return;
end
G = A.'*A;
if ridge > 0
    G = G + ridge*eye(size(G),'like',G);
end
X = G\(A.'*B);
end
