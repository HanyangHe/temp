function opt = get_mhid_options(cfg)
%GET_MHID_OPTIONS Resolve defaults for the MHID sparse-regression method.
%
% MHID = Multi-Horizon Integrated Dictionary.
%
% Current formulation:
%   1) retain ALL ordinary pointwise vector-field constraints used by SINDy;
%   2) add a fixed-origin multi-horizon integral subobjective for each short
%      trajectory, using horizons h=1,...,H;
%   3) absorb the composite-trapezoidal integration into equivalent linear
%      dictionary rows so Xi remains linear and STLSQ-compatible.
%
% The resulting objective is
%
%   ||Y_vf - Theta_vf*Xi||_F^2
%     + beta ||Y_mh - Theta_mh*Xi||_F^2,
%
% implemented by stacking sqrt(beta)-weighted MHID rows beneath the ordinary
% pointwise SINDy rows.

sopt = get_sindy_options(cfg);
opt = sopt;

opt.enabled = true;
opt.dictionaryVariant = 'physics';
opt.maxHorizonSteps = 4;
opt.integralWeight = 1.0;
opt.verbose = true;

if nargin >= 1 && isstruct(cfg) && isfield(cfg,'mhid') && ~isempty(cfg.mhid)
    opt = merge_struct_recursive(opt,cfg.mhid);
end

variant = lower(string(opt.dictionaryVariant));
if ~any(variant == ["vanilla","physics"])
    error('get_mhid_options:DictionaryVariant', ...
        'cfg.mhid.dictionaryVariant must be vanilla or physics.');
end
opt.dictionaryVariant = char(variant);

validateattributes(opt.maxHorizonSteps,{'numeric'}, ...
    {'scalar','integer','nonnegative','finite'});
validateattributes(opt.integralWeight,{'numeric'}, ...
    {'scalar','nonnegative','finite'});
validateattributes(opt.validationFraction,{'numeric'},{'scalar','>',0,'<',1});
validateattributes(opt.stlsq.thresholdGrid,{'numeric'},{'vector','nonnegative','finite'});
validateattributes(opt.stlsq.maxIterations,{'numeric'},{'scalar','integer','>=',1});
validateattributes(opt.stlsq.ridge,{'numeric'},{'scalar','nonnegative','finite'});

if nargin >= 1 && isstruct(cfg) && isfield(cfg,'data') && ...
        isfield(cfg.data,'pointsPerTrajectory') && ~isempty(cfg.data.pointsPerTrajectory)
    L = cfg.data.pointsPerTrajectory;
    validateattributes(L,{'numeric'},{'scalar','integer','>=',2,'finite'});
    maxAllowed = L-1;
    if opt.maxHorizonSteps > maxAllowed
        error('get_mhid_options:HorizonTooLong', ...
            ['cfg.mhid.maxHorizonSteps=%d exceeds the maximum allowed value ', ...
             'pointsPerTrajectory-1=%d.'],opt.maxHorizonSteps,maxAllowed);
    end
end
end

function a = merge_struct_recursive(a,b)
fields = fieldnames(b);
for k = 1:numel(fields)
    f = fields{k};
    if isstruct(b.(f)) && isfield(a,f) && isstruct(a.(f))
        a.(f) = merge_struct_recursive(a.(f),b.(f));
    else
        a.(f) = b.(f);
    end
end
end
