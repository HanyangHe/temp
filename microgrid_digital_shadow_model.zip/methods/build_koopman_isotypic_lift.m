function [Z,names,spec,dZ] = build_koopman_isotypic_lift(phase,H,invariantNames,polyOrder,spec,phaseDot,Hdot,phaseName)
%BUILD_KOOPMAN_ISOTYPIC_LIFT Jiang-style q=-1 isotypic observable lift.
%
% For the reduced DER models used by this benchmark, the first local state is
% the electrical phase (delta/theta) and the remaining local states are
% expressed in the corresponding internal frame.  Following the q=-1
% isotypic construction used by Jiang et al., we form
%
%       w = exp(1j*phase),
%       z = phi(H) * w,
%
% where phi(H) contains real monomials through the requested polynomial
% order.  Every observable therefore transforms with the same global phase.
%
% If phaseDot and Hdot are supplied, the lifted derivative is obtained
% analytically:
%
%       zdot = ( dphi/dt + 1j*phaseDot*phi ) * w.
%
% No finite-difference derivative or learned lifting/inverse-lifting map is
% used.  The q=-1 phase factor makes the degree-zero observable equal to w;
% the degree-one observables are H_i*w and permit exact algebraic recovery of
% the physical vector field from zdot.

if nargin < 8 || isempty(phaseName)
    phaseName = "phase";
else
    phaseName = string(phaseName);
end
phase = reshape(double(phase),1,[]);
H = double(H);
if size(H,2) ~= numel(phase)
    error('build_koopman_isotypic_lift:SampleSize', ...
        'phase and invariant-coordinate samples must have the same length.');
end
if nargin < 3 || isempty(invariantNames)
    invariantNames = "h" + string((1:size(H,1)).');
else
    invariantNames = string(invariantNames(:));
end
if numel(invariantNames) ~= size(H,1)
    error('build_koopman_isotypic_lift:InvariantNames', ...
        'invariantNames has incorrect length.');
end

computeDerivative = nargin >= 7 && ~isempty(phaseDot) && ~isempty(Hdot);
if computeDerivative
    phaseDot = reshape(double(phaseDot),1,[]);
    Hdot = double(Hdot);
    if numel(phaseDot) ~= numel(phase) || ~isequal(size(Hdot),size(H))
        error('build_koopman_isotypic_lift:DerivativeSize', ...
            'phaseDot/Hdot must match phase/H sample sizes.');
    end
end

if nargin < 5 || isempty(spec)
    [Phi,baseNames,baseSpec,dPhi] = build_koopman_monomial_lift( ...
        H,invariantNames,polyOrder,[],ternary_derivative(Hdot,computeDerivative));
    spec = struct();
    spec.isotypicIndex = -1;
    spec.polyOrder = polyOrder;
    spec.nInvariantState = size(H,1);
    spec.baseSpec = baseSpec;
    spec.observableCount = size(Phi,1);
    spec.constantObservableIndex = baseSpec.constantObservableIndex;
    spec.linearInvariantObservableIndices = baseSpec.linearObservableIndices(:);
else
    if ~isfield(spec,'baseSpec') || ~isfield(spec,'isotypicIndex') || spec.isotypicIndex ~= -1
        error('build_koopman_isotypic_lift:InvalidSpec', ...
            'The supplied lift specification is not a q=-1 isotypic specification.');
    end
    [Phi,baseNames,~,dPhi] = build_koopman_monomial_lift( ...
        H,invariantNames,polyOrder,spec.baseSpec,ternary_derivative(Hdot,computeDerivative));
end

w = exp(1i*phase);
Z = Phi .* w;
names = strings(size(baseNames));
for k = 1:numel(baseNames)
    if k == 1
        names(k) = "exp(j*" + phaseName + ")";
    else
        names(k) = "(" + baseNames(k) + ")*exp(j*" + phaseName + ")";
    end
end
spec.observableNames = names;
spec.phaseName = phaseName;

if computeDerivative
    dZ = (dPhi + 1i*(Phi.*phaseDot)) .* w;
else
    dZ = [];
end
end

function X = ternary_derivative(Hdot,computeDerivative)
if computeDerivative
    X = Hdot;
else
    X = [];
end
end
