function [model,info] = train_llm_prior_edsi_diagnostic(dataset,c,layout,cfg)
%TRAIN_LLM_PRIOR_EDSI_DIAGNOSTIC Weak-domain LLM prior bank + fixed-width EDSI.
%
% The LLM prior bank is discovered once outside the evolutionary search.
% EDSI keeps the ordinary V-SINDy seed as an exact parent and adds a second
% fixed-width seed in which the weakest non-anchor V terms are replaced by
% the LLM-compiled physical candidates. No cloud call occurs inside EDSI.
[model,info] = train_edsi_core(dataset,c,layout,cfg,"llm_prior_edsi");
end
