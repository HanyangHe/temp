function [Theta,names,spec] = build_pnc_residual_comp_library( ...
    X,H,inputNames,outputNames,opt,seed,specIn)
%BUILD_PNC_RESIDUAL_COMP_LIBRARY Physics-conditioned residual-composition bank.
%
%   H = f_PE_hat(chi)                                  (frozen layer 1)
%   Z = [chi, H]
%   Phi_comp = fixed tanh random-feature bank on Z
%
% This helper returns ONLY Phi_comp. The model-level identity path is handled
% outside this library through
%       xdot_hat = H + Phi_comp(chi,H)*Xi_c.
% Therefore Xi_c=0 recovers the PE-SINDy parent exactly.

if nargin < 7, specIn = []; end
validateattributes(X,{'numeric'},{'2d','real','finite','nonempty'},mfilename,'X');
validateattributes(H,{'numeric'},{'2d','real','finite','nonempty'},mfilename,'H');
if size(X,1) ~= size(H,1)
    error('build_pnc_residual_comp_library:RowCount', ...
        'X and H must contain the same number of rows.');
end

inputNames = string(inputNames(:));
outputNames = string(outputNames(:));
if size(X,2) ~= numel(inputNames)
    error('build_pnc_residual_comp_library:InputNames', ...
        'X has %d columns but inputNames has %d entries.',size(X,2),numel(inputNames));
end
if size(H,2) ~= numel(outputNames)
    error('build_pnc_residual_comp_library:OutputNames', ...
        'H has %d columns but outputNames has %d entries.',size(H,2),numel(outputNames));
end

Z = [X H];
augNames = [inputNames; "pe_hat_" + outputNames];
compSeed = round(double(seed)) + ...
    round(double(opt.physicsNeuralCompositional.compositionalSeedOffset));

if isempty(specIn)
    [PhiComp,compSpec] = make_fixed_neural_ridge_basis( ...
        Z,opt.neuralBasis.featureCount,opt.neuralBasis,compSeed,[]);
    spec = struct();
    spec.architecture = 'pnc_residual_comp_v1';
    spec.rawInputCount = size(X,2);
    spec.layer1OutputCount = size(H,2);
    spec.inputNames = inputNames;
    spec.outputNames = outputNames;
    spec.augmentedInputNames = augNames;
    spec.compositionalNeural = compSpec;
    spec.neural = compSpec; % compatibility alias for diagnostics
    spec.compositionalBasisSeed = compSeed;
else
    spec = specIn;
    required = {'architecture','rawInputCount','layer1OutputCount', ...
        'inputNames','outputNames','augmentedInputNames', ...
        'compositionalNeural','compositionalBasisSeed'};
    for k = 1:numel(required)
        if ~isfield(spec,required{k})
            error('build_pnc_residual_comp_library:StoredSpec', ...
                'Stored residual-composition spec is missing field %s.',required{k});
        end
    end
    if ~strcmp(char(string(spec.architecture)),'pnc_residual_comp_v1')
        error('build_pnc_residual_comp_library:ArchitectureVersion', ...
            'Stored library spec is not the residual-composition architecture.');
    end
    if size(X,2) ~= double(spec.rawInputCount) || ...
            size(H,2) ~= double(spec.layer1OutputCount)
        error('build_pnc_residual_comp_library:StoredDimension', ...
            'Current input dimensions differ from the stored residual-composition spec.');
    end
    [PhiComp,~] = make_fixed_neural_ridge_basis( ...
        Z,opt.neuralBasis.featureCount,opt.neuralBasis, ...
        double(spec.compositionalBasisSeed),spec.compositionalNeural);
end

Theta = PhiComp;
nComp = size(PhiComp,2);
names = compose("pnc_rescomp_%03d",(1:nComp).');
spec.libraryNames = names;
spec.compositionalNeuralColumnIndices = (1:nComp).';
spec.neuralColumnIndices = spec.compositionalNeuralColumnIndices;
spec.compositionalNeuralFeatureCount = nComp;
spec.retainedNeuralFeatureCount = nComp;
spec.totalFixedNeuralFeatureCount = nComp;

if numel(names) ~= size(Theta,2)
    error('build_pnc_residual_comp_library:NameCount', ...
        'Library-name count does not match numeric library width.');
end
if any(~isfinite(Theta),'all')
    error('build_pnc_residual_comp_library:Nonfinite', ...
        'Residual-composition library contains nonfinite values.');
end
end
