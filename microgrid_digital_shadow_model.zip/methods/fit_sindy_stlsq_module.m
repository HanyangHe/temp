function [module,info] = fit_sindy_stlsq_module(data,trainMask,valMask,variant,opt,fitMode)
%FIT_SINDY_STLSQ_MODULE Fit one modular pointwise SINDy module.
%
% STLSQ support discovery always uses the official unregularized
% Brunton-Proctor-Kutz algorithm. Coefficients are then refit on the frozen
% support: exact vector-field labels use one fixed tiny Tikhonov rho=1e-10,
% while reconstructed noisy derivative labels use the shared validation-
% selected support-ridge grid. Ridge never changes the discovered support.
%
% Standard mode uses one common STLSQ threshold for every normalized library
% coefficient. Prior-weighted mode uses the SAME physics dictionary but
% assigns the composed physical candidates a larger retention weight w_p>=1:
%
%   lambda_j = lambda                    generic candidate
%   lambda_j = lambda / w_p              physical-prior candidate
%
% where physical-prior candidates are appended columns whose names begin
% with "phys_".

if nargin < 6 || isempty(fitMode)
    fitMode = "standard";
end
fitMode = lower(string(fitMode));
variant = lower(string(variant));
if ~any(fitMode == ["standard","prior_weighted"])
    error('fit_sindy_stlsq_module:FitMode','Unknown fit mode "%s".',fitMode);
end
if fitMode == "prior_weighted" && variant ~= "physics"
    error('fit_sindy_stlsq_module:PriorWeightedLibrary', ...
        'Prior-weighted mode must use the Physics-embedded candidate library.');
end

[Theta,names,spec] = build_sindy_library(data.X,data.inputNames, ...
    data.deviceType,variant,opt,[]);
Y = data.Y;

if ~any(trainMask) || ~any(valMask)
    error('fit_sindy_stlsq_module:EmptySplit', ...
        'Train and validation masks must both be nonempty.');
end

AtrRaw = Theta(trainMask,:);
AvalRaw = Theta(valMask,:);
YtrRaw = Y(trainMask,:);
YvalRaw = Y(valMask,:);

% Training-only normalization makes one threshold grid meaningful across
% polynomial, trigonometric, and physics features with different units/scales.
colScale = sqrt(mean(AtrRaw.^2,1));
colScale = max(colScale,opt.normalization.libraryScaleFloor);
yScale = std(YtrRaw,0,1);
yRms = sqrt(mean(YtrRaw.^2,1));
yScale = max(yScale,0.05*yRms);
yScale = max(yScale,opt.normalization.outputScaleFloor);

Atr = AtrRaw./colScale;
Aval = AvalRaw./colScale;
Btr = YtrRaw./yScale;
Bval = YvalRaw./yScale;

% Feature-specific sparsity preference. All retained physics features receive
% the same user-controlled preference weight in prior-weighted mode.
featurePreference = ones(size(Theta,2),1);
physicsPriorMask = startsWith(string(names(:)),"phys_");
physicsWeight = 1.0;
if fitMode == "prior_weighted"
    physicsWeight = opt.priorWeighted.physicsFeatureWeight;
    featurePreference(physicsPriorMask) = physicsWeight;
end
featureComplexityCost = 1./(featurePreference.^2);

lambdas = unique(sort(opt.stlsq.thresholdGrid(:)),'stable');
[adaptiveSupportRidgeApplied,supportRidgeConfigured,supportRidgePolicy] = ...
    should_apply_sindy_support_ridge(opt,data);
fixedFinalRidgeRho = double(opt.stlsq.finalSupportRidgeRho);
if adaptiveSupportRidgeApplied
    ridgeGrid = unique(double(opt.stlsq.supportRidge.relativeAlphaGrid(:).'),'stable');
else
    ridgeGrid = 0; % one exact-label candidate; coefficients use fixedFinalRidgeRho below
end

resultTemplate = struct('lambda',NaN,'supportRidgeRelativeAlpha',NaN, ...
    'trainNormalizedMSE',NaN,'validationNormalizedMSE',NaN, ...
    'validationTrajectoryNormalizedMSE',NaN, ...
    'activeCoefficientCount',NaN,'weightedActiveComplexity',NaN, ...
    'activePhysicsCoefficientCount',NaN,'activeGenericCoefficientCount',NaN, ...
    'normalizedCoefficientFroNorm',NaN,'supportMask',[],'XiNormalized',[]);
results = repmat(resultTemplate,0,1);

for il = 1:numel(lambdas)
    lambda = lambdas(il);
    if fitMode == "prior_weighted"
        XiSupport = sparsifyDynamicsWeightedPrior(Atr,Btr,lambda,size(Btr,2), ...
            featurePreference);
    else
        % Exact official Brunton-Proctor-Kutz STLSQ: backslash LS followed by
        % ten threshold/refit iterations.  This step alone discovers support.
        XiSupport = sparsifyDynamics(Atr,Btr,lambda,size(Btr,2),0);
    end
    supportMask = abs(XiSupport)>0;

    for ia = 1:numel(ridgeGrid)
        rho = ridgeGrid(ia);
        if adaptiveSupportRidgeApplied
            Xi = refit_stlsq_support_ridge(Atr,Btr,supportMask,rho);
        else
            % Clean exact-label protocol: support is discovered by OLS-STLSQ,
            % then coefficients receive only the fixed tiny rho=1e-10 refit.
            Xi = refit_stlsq_support_fixed_ridge( ...
                Atr,Btr,supportMask,fixedFinalRidgeRho);
        end

        trPred = Atr*Xi;
        vaPred = Aval*Xi;
        priorMask2 = repmat(physicsPriorMask,1,size(Xi,2));
        cost2 = repmat(featureComplexityCost,1,size(Xi,2));

        r = resultTemplate;
        r.lambda = lambda;
        r.supportRidgeRelativeAlpha = rho;
        r.trainNormalizedMSE = mean((trPred-Btr).^2,'all');
        r.validationNormalizedMSE = mean((vaPred-Bval).^2,'all');
        r.activeCoefficientCount = nnz(supportMask);
        r.weightedActiveComplexity = sum(cost2(supportMask));
        r.activePhysicsCoefficientCount = nnz(supportMask & priorMask2);
        r.activeGenericCoefficientCount = nnz(supportMask & ~priorMask2);
        r.normalizedCoefficientFroNorm = norm(Xi,'fro');
        r.supportMask = supportMask;
        r.XiNormalized = Xi;
        results(end+1,1) = r; %#ok<AGROW>
    end
end

val = [results.validationNormalizedMSE].';
if fitMode == "prior_weighted"
    complexity = [results.weightedActiveComplexity].';
else
    complexity = [results.activeCoefficientCount].';
end
bestVal = min(val);
tol = opt.stlsq.validationAbsoluteTolerance + ...
    opt.stlsq.preferSparseWithinRelativeValidationTolerance*max(bestVal,eps);
eligible = find(val <= bestVal + tol);
if isempty(eligible)
    [~,bestIdx] = min(val);
else
    % Optional validation-only trajectory-consistency screen is retained for
    % diagnostics/backward compatibility, but is OFF in the frozen protocol.
    trajectoryValidationEnabled = trajectory_validation_enabled_local(opt);

    selectionPool = eligible;
    if trajectoryValidationEnabled
        trajScore = inf(numel(results),1);
        for ii = reshape(eligible,1,[])
            XiCandidate = results(ii).XiNormalized;
            coefCandidate = (XiCandidate./colScale(:)).*yScale;
            trajScore(ii) = score_sindy_short_trajectory_validation( ...
                data,trainMask,valMask,coefCandidate,'polytrig',variant, ...
                opt,spec,NaN);
            results(ii).validationTrajectoryNormalizedMSE = trajScore(ii);
        end

        stableEligible = eligible(isfinite(trajScore(eligible)));
        if ~isempty(stableEligible)
            bestTraj = min(trajScore(stableEligible));
            trajTol = opt.stlsq.validationAbsoluteTolerance + ...
                opt.stlsq.preferSparseWithinRelativeValidationTolerance*max(bestTraj,eps);
            trajectoryNearBest = stableEligible( ...
                trajScore(stableEligible) <= bestTraj + trajTol);
            if ~isempty(trajectoryNearBest)
                selectionPool = trajectoryNearBest;
            end
        else
            warning('fit_sindy_stlsq_module:NoFiniteTrajectoryCandidate', ...
                ['No pointwise-near-best threshold produced a finite held-out ', ...
                 'short-trajectory rollout for %s%d. Falling back to the ', ...
                 'pointwise validation selector.'], ...
                upper(char(data.deviceType)),data.deviceIndex);
        end
    end

    % Shared SINDy preference: first choose minimum support complexity within
    % the ordinary pointwise near-best validation band.
    bestComplexity = min(complexity(selectionPool));
    cTol = 100*eps(max(1,bestComplexity));
    candidates = selectionPool(abs(complexity(selectionPool)-bestComplexity) <= cTol);

    if adaptiveSupportRidgeApplied
        % Within that fixed minimum-complexity family, permit only essentially
        % tied validation candidates, then prefer the smallest coefficient
        % amplification.  rho=0 is always available.
        cVal = val(candidates);
        bestCandidateVal = min(cVal);
        ridgeValTol = opt.stlsq.validationAbsoluteTolerance + ...
            opt.stlsq.supportRidge.tieRelativeValidationTolerance* ...
            max(bestCandidateVal,eps);
        near = candidates(cVal <= bestCandidateVal + ridgeValTol);
        norms = [results(near).normalizedCoefficientFroNorm].';
        bestNorm = min(norms);
        nTol = 100*eps(max(1,bestNorm));
        near2 = near(abs(norms-bestNorm) <= nTol);
        if numel(near2) > 1
            [~,loc] = min(val(near2));
            near2 = near2(loc);
        end
        if numel(near2) > 1
            rho2 = [results(near2).supportRidgeRelativeAlpha].';
            [~,loc] = min(rho2);
            near2 = near2(loc);
        end
        bestIdx = near2(1);
    elseif trajectoryValidationEnabled && ...
            all(isfinite([results(candidates).validationTrajectoryNormalizedMSE]))
        trajCandidate = [results(candidates).validationTrajectoryNormalizedMSE].';
        bestTrajCandidate = min(trajCandidate);
        tTolTie = 100*eps(max(1,bestTrajCandidate));
        candidates2 = candidates(abs(trajCandidate-bestTrajCandidate) <= tTolTie);
        [~,loc2] = min(val(candidates2));
        bestIdx = candidates2(loc2);
    else
        [~,loc2] = min(val(candidates));
        bestIdx = candidates(loc2);
    end
end

best = results(bestIdx);
XiNorm = best.XiNormalized;

% Y/yScale = (Theta/colScale)*XiNorm
% => Y = Theta * [XiNorm .* yScale ./ colScale]
coef = (XiNorm./colScale(:)).*yScale;
coefActiveMask = logical(best.supportMask);
priorMask2 = repmat(physicsPriorMask,1,size(coef,2));

module.type = 'modular_sindy_module';
module.formulationVersion = char(opt.formulationVersion);
module.dictionaryFamily = 'polytrig';
module.variant = char(variant);
module.fitMode = char(fitMode);
module.deviceType = char(data.deviceType);
module.deviceIndex = data.deviceIndex;
module.bus = data.bus;
module.stateIndices = data.stateIndices(:);
module.inputNames = string(data.inputNames(:));
module.outputNames = string(data.outputNames(:));
module.libraryNames = string(names(:));
module.librarySpec = spec;
module.coefficients = coef;
module.selectedThreshold = best.lambda;
module.stlsqSolver = 'official_brunton_2015';
module.stlsqIterations = 10;
module.stlsqRidge = 0; % STLSQ support discovery remains unregularized.
module.supportRidgeConfigured = supportRidgeConfigured;
module.adaptiveSupportRidgeApplied = adaptiveSupportRidgeApplied;
module.supportRidgeApplied = adaptiveSupportRidgeApplied || fixedFinalRidgeRho>0;
module.supportRidgeEnabled = module.supportRidgeApplied; % backward-compatible alias
module.supportRidgeApplicationPolicy = char(supportRidgePolicy);
module.supportDiscoveryRho = 0;
module.fixedFinalSupportRidgeRho = fixedFinalRidgeRho;
module.derivativeLabelProtocol = derivative_label_protocol_local(data);
module.supportRidgeRelativeAlpha = best.supportRidgeRelativeAlpha;
module.normalizedCoefficientFroNorm = best.normalizedCoefficientFroNorm;
module.libraryColumnScale = colScale(:);
module.outputScale = yScale(:);
module.activeCoefficientCount = nnz(coefActiveMask);
module.candidateCoefficientCount = numel(coef);
module.physicsPriorFeatureMask = physicsPriorMask;
module.physicsPriorFeatureWeight = physicsWeight;
module.activePhysicsCoefficientCount = nnz(coefActiveMask & priorMask2);
module.activeGenericCoefficientCount = nnz(coefActiveMask & ~priorMask2);
module.trajectoryValidationEnabled = trajectory_validation_enabled_local(opt);
module.validationTrajectoryNormalizedMSE = best.validationTrajectoryNormalizedMSE;

sweepTable = table([results.lambda].',[results.supportRidgeRelativeAlpha].', ...
    [results.trainNormalizedMSE].',[results.validationNormalizedMSE].', ...
    [results.validationTrajectoryNormalizedMSE].', ...
    [results.activeCoefficientCount].',[results.weightedActiveComplexity].', ...
    [results.activePhysicsCoefficientCount].',[results.activeGenericCoefficientCount].', ...
    [results.normalizedCoefficientFroNorm].', ...
    'VariableNames',{'Threshold','SupportRidgeRelativeAlpha', ...
    'TrainNormalizedMSE','ValidationNormalizedMSE', ...
    'ValidationTrajectoryNormalizedMSE','ActiveCoefficientCount', ...
    'WeightedActiveComplexity','ActivePhysicsCoefficientCount', ...
    'ActiveGenericCoefficientCount','NormalizedCoefficientFroNorm'});

info.formulationVersion = char(opt.formulationVersion);
info.deviceType = char(data.deviceType);
info.deviceIndex = data.deviceIndex;
info.bus = data.bus;
info.nTrainSamples = nnz(trainMask);
info.nValidationSamples = nnz(valMask);
info.libraryTermCount = size(Theta,2);
info.outputCount = size(Y,2);
info.candidateCoefficientCount = numel(coef);
info.activeCoefficientCount = module.activeCoefficientCount;
info.selectedThreshold = best.lambda;
info.stlsqSolver = 'official_brunton_2015';
info.stlsqIterations = 10;
info.stlsqRidge = 0;
info.supportRidgeConfigured = supportRidgeConfigured;
info.adaptiveSupportRidgeApplied = adaptiveSupportRidgeApplied;
info.supportRidgeApplied = adaptiveSupportRidgeApplied || fixedFinalRidgeRho>0;
info.supportRidgeEnabled = info.supportRidgeApplied;
info.supportRidgeApplicationPolicy = char(supportRidgePolicy);
info.supportDiscoveryRho = 0;
info.fixedFinalSupportRidgeRho = fixedFinalRidgeRho;
info.derivativeLabelProtocol = derivative_label_protocol_local(data);
info.supportRidgeRelativeAlpha = best.supportRidgeRelativeAlpha;
info.normalizedCoefficientFroNorm = best.normalizedCoefficientFroNorm;
info.trainNormalizedMSE = best.trainNormalizedMSE;
info.validationNormalizedMSE = best.validationNormalizedMSE;
info.thresholdSweep = sweepTable;
info.fitMode = char(fitMode);
info.physicsPriorFeatureCount = nnz(physicsPriorMask);
info.physicsPriorFeatureWeight = physicsWeight;
info.activePhysicsCoefficientCount = module.activePhysicsCoefficientCount;
info.activeGenericCoefficientCount = module.activeGenericCoefficientCount;
info.weightedActiveComplexity = best.weightedActiveComplexity;
info.trajectoryValidationEnabled = trajectory_validation_enabled_local(opt);
info.validationTrajectoryNormalizedMSE = best.validationTrajectoryNormalizedMSE;

if opt.verbose
    if fitMode == "prior_weighted"
        fprintf(['      %s%d | library=%d terms | prior weight=%.3g | lambda=%.3g | ', ...
            'active=%d/%d (phys=%d, generic=%d) | train nMSE=%.3e | val nMSE=%.3e\n'], ...
            upper(char(data.deviceType)),data.deviceIndex,info.libraryTermCount, ...
            physicsWeight,info.selectedThreshold,info.activeCoefficientCount, ...
            info.candidateCoefficientCount,info.activePhysicsCoefficientCount, ...
            info.activeGenericCoefficientCount,info.trainNormalizedMSE, ...
            info.validationNormalizedMSE);
    else
        fprintf(['      %s%d | library=%d terms | lambda=%.3g | active=%d/%d | ', ...
            'train nMSE=%.3e | val nMSE=%.3e\n'],upper(char(data.deviceType)), ...
            data.deviceIndex,info.libraryTermCount,info.selectedThreshold, ...
            info.activeCoefficientCount,info.candidateCoefficientCount, ...
            info.trainNormalizedMSE,info.validationNormalizedMSE);
    end
    if info.adaptiveSupportRidgeApplied
        fprintf(['      frozen-support noise ridge alpha=%.3g | normalized ', ...
            'coefficient Fro norm=%.3e\n'], ...
            info.supportRidgeRelativeAlpha,info.normalizedCoefficientFroNorm);
    elseif info.fixedFinalSupportRidgeRho>0
        fprintf(['      OLS-STLSQ support -> fixed frozen-support rho=%.1e | ', ...
            'normalized coefficient Fro norm=%.3e\n'], ...
            info.fixedFinalSupportRidgeRho,info.normalizedCoefficientFroNorm);
    end
    if info.trajectoryValidationEnabled
        fprintf('      held-out short-trajectory validation nMSE=%.3e\n', ...
            info.validationTrajectoryNormalizedMSE);
    end
end
end


function txt = derivative_label_protocol_local(data)
txt = 'unknown';
if isstruct(data) && isfield(data,'derivativeLabelProtocol') && ...
        strlength(string(data.derivativeLabelProtocol)) > 0
    txt = char(string(data.derivativeLabelProtocol));
end
end


function tf = trajectory_validation_enabled_local(opt)
tf = isfield(opt,'stlsq') && isfield(opt.stlsq,'trajectoryValidation') && ...
    isstruct(opt.stlsq.trajectoryValidation) && ...
    isfield(opt.stlsq.trajectoryValidation,'enabled') && ...
    logical(opt.stlsq.trajectoryValidation.enabled);
end
