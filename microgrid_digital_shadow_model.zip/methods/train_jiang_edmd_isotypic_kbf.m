function [model,info] = train_jiang_edmd_isotypic_kbf(dataset,c,layout,cfg)
%TRAIN_JIANG_EDMD_ISOTYPIC_KBF Paper-based EDMD/isotypic M-KBF adaptation.
%
% Jiang, Li & Huang, IEEE TSG 2024, DOI 10.1109/TSG.2024.3399076:
% - q=-1 symmetry-equivariant complex observables, degree-three monomials
% - paired state snapshots (no exact xdot labels consumed)
% - explicit GFL EDMD / implicit source-type EDMD
% - truncated SVD, discrete bilinear matrices, Koopman spectrum diagnostics.
%
% IMPORTANT MODEL BOUNDARY: This project has five-state salient SGs and
% reduced GFM droop models different from the cited paper's DERs. We retain
% the same external [x, Vterminal, references] module interface and known
% DAE network, and use the symmetry-consistent phase lift exp(1i*phase)
% for SG/GFM. This is a paper-based adaptation, NOT the authors' original
% device-specific implementation or a claimed exact reproduction.
%
% The existing CT-M-KBF is untouched unless cfg.koopman.baselineVariant
% explicitly equals 'jiang_edmd_isotypic_v1'. Outputs carry a distinct tag.

if ~isfield(cfg,'koopman') || ~isfield(cfg.koopman,'enabled') || ~cfg.koopman.enabled
    error('train_jiang_edmd_isotypic_kbf:Disabled', ...
        'cfg.koopman.enabled must be true.');
end
if ~isfield(dataset,'trajectoryId') || ...
        ~isfield(dataset,'pointInTrajectory') || ...
        ~isfield(dataset,'trajectories')
    error('train_jiang_edmd_isotypic_kbf:Dataset', ...
        'A grouped short-trajectory dataset with sample positions is required.');
end
opt = jiang_options(cfg);
K = dataset.trajectories.nTrajectories;
forced = [];
if isfield(dataset.trajectories,'forceTrainingMask')
    forced = find(logical(dataset.trajectories.forceTrainingMask(:))).';
end
[trainIds,valIds] = split_ids(K,forced,opt);

model = struct();
model.type = 'modular_koopman_kbf';
model.variant = 'jiang_edmd_isotypic_v1';
model.formulationVersion = 'jiang_isotypic_edmd_snapshot_v1';
model.trainingSampleDefinition = ...
    'paired state snapshots, whole-trajectory train/validation, no derivative labels';
model.deploymentDefinition = ...
    'discrete EDMD bilinear increment mapped to physical xdot for common ode15i DAE';
model.options = opt;
model.trainTrajectoryIds = trainIds(:);
model.validationTrajectoryIds = valIds(:);
model.forcedTrainingTrajectoryIds = forced(:);
model.sg = struct([]); model.gfm = struct([]); model.gfl = struct([]);

mods = struct([]); mi = 0;
for k=1:numel(c.sg)
    data = build_koopman_module_vectorfield_data(dataset,c,layout,'sg',k);
    data.sampleStep = double(dataset.metadata.trajectorySampleStep);
    [m,detail] = fit_jiang_edmd_isotypic_module(data,c.sg(k),trainIds,valIds,opt);
    if k==1, model.sg=m; else, model.sg(k,1)=m; end
    mi=mi+1; if mi==1, mods=detail; else, mods(mi,1)=detail; end
end
for k=1:numel(c.gfm)
    data = build_koopman_module_vectorfield_data(dataset,c,layout,'gfm',k);
    data.sampleStep = double(dataset.metadata.trajectorySampleStep);
    [m,detail] = fit_jiang_edmd_isotypic_module(data,c.gfm(k),trainIds,valIds,opt);
    if k==1, model.gfm=m; else, model.gfm(k,1)=m; end
    mi=mi+1; mods(mi,1)=detail;
end
for k=1:numel(c.gfl)
    data = build_koopman_module_vectorfield_data(dataset,c,layout,'gfl',k);
    data.sampleStep = double(dataset.metadata.trajectorySampleStep);
    [m,detail] = fit_jiang_edmd_isotypic_module(data,c.gfl(k),trainIds,valIds,opt);
    if k==1, model.gfl=m; else, model.gfl(k,1)=m; end
    mi=mi+1; mods(mi,1)=detail;
end
info = struct();
info.method = 'modular_koopman_kbf';
info.displayName = 'Jiang EDMD/isotypic M-KBF adaptation';
info.formulationVersion = model.formulationVersion;
info.objective = 'Complex q=-1 EDMD with truncated-SVD discrete bilinear matrices';
info.identificationForm = 'discrete_edmd_explicit_gfl_implicit_sources';
info.rolloutForm = 'first_order_snapshot_to_ode15i';
info.liftingMode = 'isotypic_qminus1';
info.polyOrder = opt.polyOrder;
info.nSamples = size(dataset.x,1);
info.pointsPerTrajectory = dataset.trajectories.pointsPerTrajectory;
info.nTrajectories = K;
info.nTrainTrajectories = numel(trainIds);
info.nValidationTrajectories = numel(valIds);
info.trainTrajectoryIds = trainIds(:);
info.validationTrajectoryIds = valIds(:);
info.forcedTrainingTrajectoryIds = forced(:);
info.modules = mods;
end

function opt = jiang_options(cfg)
opt = struct();
opt.polyOrder = 3;
opt.rankCandidateCount = 14;
opt.minRank = 3;
opt.maxRankFraction = 1.0;
opt.singularRelativeFloor = 1e-10;
opt.ridgeRelativeGrid = 0; % paper truncated pseudoinverse, not mandatory ridge
opt.validationFraction = 0.2;
opt.validationSeed = 20260816;
opt.maxEigenGrowthRate = 10; % 1/s, soft spectral guard
opt.uncertaintyRelativeBand = 0.05;
opt.voltageDivisionFloor = 1e-6;
opt.normalizationFloor = 1e-8;
opt.odeConversion = 'implicit_step'; % use paper implicit update for SG/GFM
opt.verbose = true;
if isfield(cfg,'koopman') && isstruct(cfg.koopman)
    % Do not inherit the old CT ridge grid: Jiang EDMD uses truncated
    % pseudoinverse by default (ridge=0). An optional Jiang-specific
    % override is provided for a documented sensitivity experiment.
    fields = setdiff(fieldnames(opt),{'ridgeRelativeGrid'});
    for i=1:numel(fields)
        if isfield(cfg.koopman,fields{i})
            opt.(fields{i}) = cfg.koopman.(fields{i});
        end
    end
    if isfield(cfg.koopman,'jiangRidgeRelativeGrid')
        opt.ridgeRelativeGrid = cfg.koopman.jiangRidgeRelativeGrid;
    end
    % preserve original config knob when present
    if isfield(cfg.koopman,'validationFraction')
        opt.validationFraction = cfg.koopman.validationFraction;
    end
    if isfield(cfg.koopman,'validationSeed')
        opt.validationSeed = cfg.koopman.validationSeed;
    end
    if isfield(cfg.koopman,'polyOrder')
        opt.polyOrder = cfg.koopman.polyOrder;
    end
end
validateattributes(opt.polyOrder,{'numeric'},{'scalar','integer','>=',1,'<=',3});
validateattributes(opt.rankCandidateCount,{'numeric'},{'scalar','integer','>=',2});
validateattributes(opt.voltageDivisionFloor,{'numeric'},{'scalar','positive'});
validateattributes(opt.ridgeRelativeGrid,{'numeric'},{'vector','nonnegative','finite'});
if isempty(opt.ridgeRelativeGrid), error('Empty ridge grid'); end
if ~ismember(string(opt.odeConversion),["implicit_step","first_order_generator"])
    error('jiang_options:OdeConversion','Unknown ode conversion policy.');
end
end

function [trainIds,valIds] = split_ids(K,forced,opt)
if K<2, error('jiang_split:Trajectories','At least two trajectories are required.'); end
stride=max(2,round(1/opt.validationFraction));
phase=mod(round(opt.validationSeed),stride);
for j=0:stride-1
    tryPhase=mod(phase+j,stride);
    if isempty(forced) || ~any(mod(forced-tryPhase,stride)==0)
        phase=tryPhase; break
    end
end
candidate=setdiff(1:K,forced,'stable');
valIds=candidate(mod(candidate-phase,stride)==0);
if isempty(valIds)
    if isempty(candidate),error('jiang_split:NoHoldout','No holdout trajectories.');end
    valIds=candidate(1);
end
trainIds=setdiff(1:K,valIds,'stable');
if isempty(trainIds),error('jiang_split:EmptyTrain','No training trajectories.');end
end
