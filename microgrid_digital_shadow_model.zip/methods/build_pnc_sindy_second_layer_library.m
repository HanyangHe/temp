function [Theta,names,spec] = build_pnc_sindy_second_layer_library( ...
    X,H,inputNames,outputNames,deviceType,opt,seed,specIn,shallowPNSpecIn)
%BUILD_PNC_SINDY_SECOND_LAYER_LIBRARY Build PNC-SINDy v2 skip/compositional layer.
%
% Architecture:
%   H = f_PE_hat(chi)                                      (frozen PE layer)
%   Theta_PN(chi) = [1, chi, Phi_PN(chi), Phi_phys(chi)]  (flat-PN skip path)
%   Phi_C(chi,H) = fixed tanh ridge features of [chi,H]   (compositional path)
%
%   Theta_2 = [ H, Theta_PN(chi), Phi_C(chi,H) ]
%   xdot_hat = Theta_2 * Xi_2
%
% Thus both PE-SINDy and the former flat PN-SINDy are strict submodels of
% PNC-SINDy v2. The two neural banks are frozen after construction from the
% training split only. When specIn is supplied, no basis parameter is
% regenerated.
%
% shallowPNSpecIn is optional and is used only during first construction to
% force the PN skip block to reuse the exact flat-PN parent basis already fit
% by fit_neural_sindy_stlsq_module.

if nargin < 9, shallowPNSpecIn = []; end
if nargin < 8, specIn = []; end
validateattributes(X,{'numeric'},{'2d','real','finite','nonempty'},mfilename,'X');
validateattributes(H,{'numeric'},{'2d','real','finite','nonempty'},mfilename,'H');
if size(X,1) ~= size(H,1)
    error('build_pnc_sindy_second_layer_library:RowCount', ...
        'X and H must contain the same number of rows.');
end

inputNames = string(inputNames(:));
outputNames = string(outputNames(:));
deviceType = lower(string(deviceType));
if size(X,2) ~= numel(inputNames)
    error('build_pnc_sindy_second_layer_library:InputNames', ...
        'X has %d columns but inputNames has %d entries.',size(X,2),numel(inputNames));
end
if size(H,2) ~= numel(outputNames)
    error('build_pnc_sindy_second_layer_library:OutputNames', ...
        'H has %d columns but outputNames has %d entries.',size(H,2),numel(outputNames));
end

Z = [X H];
augNames = [inputNames; "pe_hat_" + outputNames];
compSeed = round(double(seed)) + round(double(opt.physicsNeuralCompositional.compositionalSeedOffset));

if isempty(specIn)
    % Exact former flat-PN dictionary on chi. If the caller already fitted the
    % flat PN parent, reuse its basis spec so the explicit PN skip candidate is
    % numerically identical to that parent model.
    [ThetaPN,pnNames,pnSpec] = build_neural_sindy_library( ...
        X,inputNames,deviceType,"physics_neural",opt,seed,shallowPNSpecIn);

    [PhiComp,compSpec] = make_fixed_neural_ridge_basis( ...
        Z,opt.neuralBasis.featureCount,opt.neuralBasis,compSeed,[]);

    spec = struct();
    spec.architecture = 'pe_bypass_plus_flat_pn_skip_plus_fixed_neural_composition_v2';
    spec.rawInputCount = size(X,2);
    spec.layer1OutputCount = size(H,2);
    spec.inputNames = inputNames;
    spec.outputNames = outputNames;
    spec.deviceType = char(deviceType);
    spec.augmentedInputNames = augNames;
    spec.shallowPN = pnSpec;
    spec.compositionalNeural = compSpec;
    % Backward-friendly alias used only by generic diagnostics that expect a
    % single neural spec. It refers to the compositional bank, not the PN skip.
    spec.neural = compSpec;
    spec.shallowPNBasisSeed = round(double(seed));
    spec.compositionalBasisSeed = compSeed;
else
    spec = specIn;
    required = {'architecture','rawInputCount','layer1OutputCount','inputNames', ...
        'outputNames','deviceType','augmentedInputNames','shallowPN', ...
        'compositionalNeural','compositionalBasisSeed'};
    for k = 1:numel(required)
        if ~isfield(spec,required{k})
            error('build_pnc_sindy_second_layer_library:StoredSpec', ...
                'Stored PNC v2 layer-2 spec is missing field %s.',required{k});
        end
    end
    if ~strcmp(char(string(spec.architecture)), ...
            'pe_bypass_plus_flat_pn_skip_plus_fixed_neural_composition_v2')
        error('build_pnc_sindy_second_layer_library:ArchitectureVersion', ...
            'Stored PNC layer-2 spec is not the v2 skip/compositional architecture.');
    end
    if size(X,2) ~= double(spec.rawInputCount) || ...
            size(H,2) ~= double(spec.layer1OutputCount)
        error('build_pnc_sindy_second_layer_library:StoredDimension', ...
            'Current PNC layer-2 input dimensions differ from the stored basis spec.');
    end
    if numel(spec.inputNames) ~= numel(inputNames) || ...
            any(string(spec.inputNames(:)) ~= inputNames)
        error('build_pnc_sindy_second_layer_library:StoredInputNames', ...
            'Current raw input ordering differs from the stored PNC layer-2 spec.');
    end
    if numel(spec.outputNames) ~= numel(outputNames) || ...
            any(string(spec.outputNames(:)) ~= outputNames)
        error('build_pnc_sindy_second_layer_library:StoredOutputNames', ...
            'Current layer-1 output ordering differs from the stored PNC layer-2 spec.');
    end
    if lower(string(spec.deviceType)) ~= deviceType
        error('build_pnc_sindy_second_layer_library:StoredDeviceType', ...
            'Current device type differs from the stored PNC layer-2 spec.');
    end

    [ThetaPN,pnNames] = build_neural_sindy_library( ...
        X,inputNames,deviceType,"physics_neural",opt,seed,spec.shallowPN);
    [PhiComp,~] = make_fixed_neural_ridge_basis( ...
        Z,opt.neuralBasis.featureCount,opt.neuralBasis, ...
        double(spec.compositionalBasisSeed),spec.compositionalNeural);
end

nH = size(H,2);
nPN = size(ThetaPN,2);
nComp = size(PhiComp,2);
identityNames = "pe_hat_" + outputNames;
pnSkipNames = "pnskip_" + string(pnNames(:));
compNames = compose("pnc_comp_%03d",(1:nComp).');
names = [identityNames;pnSkipNames;compNames];
Theta = [H ThetaPN PhiComp];

spec.libraryNames = names;
spec.peBypassColumnIndices = (1:nH).';
spec.shallowPNColumnIndices = (nH+(1:nPN)).';
spec.compositionalNeuralColumnIndices = (nH+nPN+(1:nComp)).';
% Backward-friendly alias: v1 called the PE columns identityColumnIndices.
spec.identityColumnIndices = spec.peBypassColumnIndices;
spec.neuralColumnIndices = spec.compositionalNeuralColumnIndices;
spec.shallowPNLibraryNames = string(pnNames(:));
spec.shallowPNLibraryTermCount = nPN;
spec.shallowPNNeuralFeatureCount = spec.shallowPN.neural.retainedCount;
spec.compositionalNeuralFeatureCount = nComp;
spec.retainedNeuralFeatureCount = nComp;
spec.totalFixedNeuralFeatureCount = ...
    spec.shallowPNNeuralFeatureCount + spec.compositionalNeuralFeatureCount;

if numel(names) ~= size(Theta,2)
    error('build_pnc_sindy_second_layer_library:NameCount', ...
        'PNC v2 layer-2 name count does not match numeric library width.');
end
if any(~isfinite(Theta),'all')
    error('build_pnc_sindy_second_layer_library:Nonfinite', ...
        'PNC v2 layer-2 library contains nonfinite values.');
end
end
