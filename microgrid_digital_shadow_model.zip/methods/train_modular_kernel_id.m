function [model,info] = train_modular_kernel_id(dataset,c,layout,cfg,mode)
%TRAIN_MODULAR_KERNEL_ID Common modular trainer for KRR and exact GP.
%
% mode = 'krr'
%   Hyperparameters are selected by held-out whole-trajectory validation.
%
% mode = 'gp'
%   Hyperparameters are selected by exact Gaussian-process log marginal
%   likelihood on a bounded training-only tuning subset. The final posterior
%   mean is then refit using all training samples.
%
% Both methods learn the same continuous-time map used by SINDy:
%
%       chi_r = [local states, terminal voltage, local references]
%       xdot_r = f_r(chi_r)
%
% and retain the exact network algebraic equations during rollout.
%
% Computational note
% ------------------
% Exact Gaussian kernels scale cubically in the number of fitting samples.
% Hyperparameter selection therefore uses at most opt.tuningSampleCap
% training rows, while the final model is always refit with the complete
% trajectory-level training partition.

mode = lower(string(mode));
if ~any(mode == ["krr","gp"])
    error('train_modular_kernel_id:Mode','Unknown mode "%s".',mode);
end

opt = kernel_id_options_local(cfg);
[trainIds,valIds,trainMask,valMask,forcedTrainIds] = ...
    trajectory_split_local(dataset,opt.validationFraction,opt.validationSeed);

model = struct();
model.type = 'modular_kernel_vector_field';
model.mode = char(mode);
model.formulationVersion = 'rbf_kernel_vector_field_v1';
model.trainingSampleDefinition = ...
    'flattened pointwise samples from common short-trajectory dataset';
model.sg = struct([]);
model.gfm = struct([]);
model.gfl = struct([]);
model.trainTrajectoryIds = trainIds(:);
model.validationTrajectoryIds = valIds(:);
model.forcedTrainingTrajectoryIds = forcedTrainIds(:);
model.options = opt;

modules = struct([]);
mi = 0;

for k = 1:numel(c.sg)
    fprintf('    Training %s module SG%d (Bus %d)...\n', ...
        upper(char(mode)),k,c.sg(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'sg',k);
    [mk,ik] = fit_kernel_module_local(data,trainMask,valMask,opt,mode);
    if k==1, model.sg=mk; else, model.sg(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
end

for k = 1:numel(c.gfm)
    fprintf('    Training %s module GFM%d (Bus %d)...\n', ...
        upper(char(mode)),k,c.gfm(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfm',k);
    [mk,ik] = fit_kernel_module_local(data,trainMask,valMask,opt,mode);
    if k==1, model.gfm=mk; else, model.gfm(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
end

for k = 1:numel(c.gfl)
    fprintf('    Training %s module GFL%d (Bus %d)...\n', ...
        upper(char(mode)),k,c.gfl(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfl',k);
    [mk,ik] = fit_kernel_module_local(data,trainMask,valMask,opt,mode);
    if k==1, model.gfl=mk; else, model.gfl(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
end

info = struct();
info.method = char(mode + "_rbf_vector_field");
info.formulationVersion = model.formulationVersion;
info.objective = char(objective_text_local(mode));
info.nSamples = size(dataset.x,1);
info.nTrajectories = dataset.trajectories.nTrajectories;
info.nTrainSamples = nnz(trainMask);
info.nValidationSamples = nnz(valMask);
info.nTrainTrajectories = numel(trainIds);
info.nValidationTrajectories = numel(valIds);
info.trainTrajectoryIds = trainIds(:);
info.validationTrajectoryIds = valIds(:);
info.forcedTrainingTrajectoryIds = forcedTrainIds(:);
info.modules = modules;

if ~isempty(forcedTrainIds) && opt.verbose
    fprintf('    Forced into kernel-model training partition: trajectory ID(s) [%s]\n', ...
        strtrim(sprintf('%d ',forcedTrainIds)));
end
end


function [module,info] = fit_kernel_module_local( ...
    data,trainMask,valMask,opt,mode)

Xtr = double(data.X(trainMask,:));
Xva = double(data.X(valMask,:));
Ytr = double(data.Y(trainMask,:));
Yva = double(data.Y(valMask,:));

if isempty(Xtr) || isempty(Xva)
    error('train_modular_kernel_id:EmptyPartition', ...
        'Training and validation partitions must both be nonempty.');
end

% Training-only normalization.
xMean = mean(Xtr,1);
xScale = std(Xtr,0,1);
xRms = sqrt(mean((Xtr-xMean).^2,1));
xScale = max(xScale,0.05*xRms);
xScale = max(xScale,opt.inputScaleFloor);

yMean = mean(Ytr,1);
yScale = std(Ytr,0,1);
yRms = sqrt(mean((Ytr-yMean).^2,1));
yScale = max(yScale,0.05*yRms);
yScale = max(yScale,opt.outputScaleFloor);

Ztr = (Xtr-xMean)./xScale;
Zva = (Xva-xMean)./xScale;
Ttr = (Ytr-yMean)./yScale;
Tva = (Yva-yMean)./yScale;

% Deterministic training-only subset for hyperparameter tuning.
nTrain = size(Ztr,1);
nTune = min(nTrain,opt.tuningSampleCap);
tuneIdx = deterministic_tuning_indices_local(nTrain,nTune,opt.tuningSeed);
Ztu = Ztr(tuneIdx,:);
Ttu = Ttr(tuneIdx,:);

ell0 = median_distance_local(Ztu,opt.distanceReferenceCap);
ellGrid = unique(max(opt.minLengthscale, ...
    ell0*opt.lengthscaleFactors(:).'));

switch char(mode)
    case 'krr'
        [ell,reg,selectionScore] = select_krr_hyperparameters_local( ...
            Ztu,Ttu,Zva,Tva,ellGrid,opt);

    case 'gp'
        [ell,reg,selectionScore] = select_gp_hyperparameters_local( ...
            Ztu,Ttu,ellGrid,opt);

    otherwise
        error('train_modular_kernel_id:ModeInternal','Unsupported mode.');
end

% Final exact fit using the complete training partition.
Ktr = rbf_kernel_local(Ztr,Ztr,ell);
[L,usedDiagonal] = stable_chol_local( ...
    Ktr + reg*eye(nTrain),opt.jitterGrid);

alpha = L'\(L\Ttr);

Kva = rbf_kernel_local(Zva,Ztr,ell);
TvaHat = Kva*alpha;
valNMSE = mean((TvaHat-Tva).^2,'all');

% Training fit is useful as an overfit diagnostic.
TtrHat = Ktr*alpha;
trainNMSE = mean((TtrHat-Ttr).^2,'all');

gpMeanLatentStd = NaN;
gpMaxLatentStd = NaN;
if mode == "gp"
    % Posterior latent-function uncertainty, normalized by signal std.
    Ktv = rbf_kernel_local(Ztr,Zva,ell);
    V = L\Ktv;
    latentVar = max(0,1-sum(V.^2,1));
    latentStd = sqrt(latentVar);
    gpMeanLatentStd = mean(latentStd);
    gpMaxLatentStd = max(latentStd);
end

module = struct();
module.type = 'kernel_vector_field_module';
module.mode = char(mode);
module.deviceType = char(data.deviceType);
module.deviceIndex = data.deviceIndex;
module.stateIndices = data.stateIndices(:);
module.bus = data.bus;
module.inputNames = string(data.inputNames(:));
module.outputNames = string(data.outputNames(:));

module.inputMean = xMean(:);
module.inputScale = xScale(:);
module.outputMean = yMean(:);
module.outputScale = yScale(:);

module.xTrainNormalized = Ztr;
module.alphaNormalized = alpha;
module.lengthscale = ell;
module.diagonalRegularization = reg;
module.choleskyAddedJitter = usedDiagonal-reg;

module.trainingSampleCount = nTrain;
module.validationSampleCount = size(Zva,1);
module.tuningSampleCount = nTune;
module.hyperparameterSelectionScore = selectionScore;
module.trainNormalizedMSE = trainNMSE;
module.validationNormalizedMSE = valNMSE;
module.gpMeanValidationLatentStd = gpMeanLatentStd;
module.gpMaxValidationLatentStd = gpMaxLatentStd;

info = module;

fprintf(['      %s%d | ell=%.4g | diag=%.3e | tuneN=%d | ', ...
    'train nMSE=%.3e | val nMSE=%.3e'], ...
    upper(char(data.deviceType)),data.deviceIndex, ...
    ell,reg,nTune,trainNMSE,valNMSE);
if mode == "gp"
    fprintf(' | GP mean std=%.3e',gpMeanLatentStd);
end
fprintf('\n');
end


function [bestEll,bestReg,bestScore] = select_krr_hyperparameters_local( ...
    Ztr,Ytr,Zva,Yva,ellGrid,opt)

bestScore = inf;
bestEll = ellGrid(1);
bestReg = opt.krrRegularizationGrid(1);

for ie = 1:numel(ellGrid)
    ell = ellGrid(ie);
    Ktr = rbf_kernel_local(Ztr,Ztr,ell);
    Kva = rbf_kernel_local(Zva,Ztr,ell);

    for ir = 1:numel(opt.krrRegularizationGrid)
        reg = opt.krrRegularizationGrid(ir);
        try
            [L,~] = stable_chol_local( ...
                Ktr + reg*eye(size(Ktr,1)),opt.jitterGrid);
            alpha = L'\(L\Ytr);
            pred = Kva*alpha;
            score = mean((pred-Yva).^2,'all');
        catch
            score = inf;
        end

        if score < bestScore
            bestScore = score;
            bestEll = ell;
            bestReg = reg;
        end
    end
end
end


function [bestEll,bestNoise,bestScore] = select_gp_hyperparameters_local( ...
    Ztr,Ytr,ellGrid,opt)

bestScore = inf;
bestEll = ellGrid(1);
bestNoise = opt.gpNoiseVarianceGrid(1);
n = size(Ztr,1);
q = size(Ytr,2);

for ie = 1:numel(ellGrid)
    ell = ellGrid(ie);
    K = rbf_kernel_local(Ztr,Ztr,ell);

    for ir = 1:numel(opt.gpNoiseVarianceGrid)
        noiseVar = opt.gpNoiseVarianceGrid(ir);

        try
            [L,~] = stable_chol_local( ...
                K + noiseVar*eye(n),opt.jitterGrid);
            alpha = L'\(L\Ytr);

            dataFit = 0.5*sum(Ytr.*alpha,'all');
            logDet = q*sum(log(diag(L)));
            constant = 0.5*n*q*log(2*pi);

            % Divide by n*q only to keep printed values well scaled.
            score = (dataFit + logDet + constant)/(n*q);
        catch
            score = inf;
        end

        if score < bestScore
            bestScore = score;
            bestEll = ell;
            bestNoise = noiseVar;
        end
    end
end
end


function K = rbf_kernel_local(A,B,ell)
D2 = squared_distance_local(A,B);
K = exp(-0.5*D2/(ell^2));
end


function D2 = squared_distance_local(A,B)
aa = sum(A.^2,2);
bb = sum(B.^2,2).';
D2 = aa + bb - 2*(A*B.');
D2 = max(D2,0);
end


function ell0 = median_distance_local(Z,cap)
n = size(Z,1);
if n < 2
    ell0 = 1;
    return;
end

m = min(n,cap);
idx = round(linspace(1,n,m));
Q = Z(idx,:);
D2 = squared_distance_local(Q,Q);
mask = triu(true(m),1);
d = sqrt(D2(mask));
d = d(isfinite(d) & d>0);

if isempty(d)
    ell0 = 1;
else
    ell0 = median(d);
end

if ~isfinite(ell0) || ell0<=0
    ell0 = 1;
end
end


function idx = deterministic_tuning_indices_local(n,m,seed)
if m >= n
    idx = (1:n).';
    return;
end

old = rng;
cleanup = onCleanup(@()rng(old)); %#ok<NASGU>
rng(seed,'twister');
p = randperm(n,m);
idx = sort(p(:));
end


function [L,usedDiagonal] = stable_chol_local(A,jitterGrid)
A = 0.5*(A+A.');
baseDiag = max(mean(diag(A)),1);

for k = 1:numel(jitterGrid)
    extra = jitterGrid(k)*baseDiag;
    [L,p] = chol(A + extra*eye(size(A,1)),'lower');
    if p==0
        % A already includes the requested KRR/GP diagonal. This return value
        % therefore records the total diagonal only approximately; it is used
        % for diagnostics, not prediction.
        usedDiagonal = extra;
        return;
    end
end

error('train_modular_kernel_id:CholeskyFailure', ...
    'Unable to stabilize the kernel matrix.');
end


function opt = kernel_id_options_local(cfg)
opt = struct();

% Match the existing SINDy whole-trajectory split for a clean baseline.
if exist('get_sindy_options','file') == 2
    sopt = get_sindy_options(cfg);
    opt.validationFraction = sopt.validationFraction;
    opt.validationSeed = sopt.validationSeed;
else
    opt.validationFraction = 0.20;
    opt.validationSeed = 20260816;
end

opt.tuningSeed = 20260820;
opt.tuningSampleCap = 400;
opt.distanceReferenceCap = 300;

opt.lengthscaleFactors = [0.5 1 2 4];
opt.minLengthscale = 1e-3;

% These are diagonal terms in normalized-output space.
opt.krrRegularizationGrid = [1e-8 1e-6 1e-4 1e-2];
opt.gpNoiseVarianceGrid = [1e-8 1e-6 1e-4 1e-2];

% Added only when Cholesky needs numerical stabilization.
opt.jitterGrid = [0 1e-12 1e-10 1e-8 1e-6];

opt.inputScaleFloor = 1e-8;
opt.outputScaleFloor = 1e-10;
opt.verbose = true;

if isfield(cfg,'kernelId') && isstruct(cfg.kernelId)
    src = cfg.kernelId;
    names = fieldnames(src);
    for i = 1:numel(names)
        opt.(names{i}) = src.(names{i});
    end
end

opt.lengthscaleFactors = double(opt.lengthscaleFactors(:).');
opt.krrRegularizationGrid = double(opt.krrRegularizationGrid(:).');
opt.gpNoiseVarianceGrid = double(opt.gpNoiseVarianceGrid(:).');
opt.jitterGrid = double(opt.jitterGrid(:).');

if opt.tuningSampleCap < 2
    error('train_modular_kernel_id:TuningCap', ...
        'kernelId.tuningSampleCap must be at least 2.');
end
end


function [trainIds,valIds,trainMask,valMask,forcedTrainIds] = ...
    trajectory_split_local(dataset,validationFraction,validationSeed)

K = dataset.trajectories.nTrajectories;
if K < 2
    error('train_modular_kernel_id:TooFewTrajectories', ...
        'At least two trajectories are required.');
end

forcedTrainIds = [];
if isfield(dataset.trajectories,'forceTrainingMask') && ...
        ~isempty(dataset.trajectories.forceTrainingMask)
    m = logical(dataset.trajectories.forceTrainingMask(:));
    if numel(m) ~= K
        error('train_modular_kernel_id:ForceTrainingMaskSize', ...
            'forceTrainingMask must contain one entry per trajectory.');
    end
    forcedTrainIds = find(m).';
end

candidates = setdiff(1:K,forcedTrainIds,'stable');
if isempty(candidates)
    error('train_modular_kernel_id:NoValidationCandidates', ...
        'No trajectory remains for validation.');
end

old = rng;
cleanup = onCleanup(@()rng(old)); %#ok<NASGU>
rng(validationSeed,'twister');
perm = candidates(randperm(numel(candidates)));

nVal = max(1,round(validationFraction*K));
nVal = min(nVal,numel(candidates));
if nVal >= K, nVal = K-1; end

valIds = sort(perm(1:nVal));
trainIds = sort(setdiff(1:K,valIds,'stable'));
trainMask = ismember(dataset.trajectoryId,trainIds);
valMask = ismember(dataset.trajectoryId,valIds);
end


function [S,mi] = append_info_local(S,mi,ik)
mi = mi+1;
if mi==1
    S=ik;
else
    S(mi,1)=ik;
end
end


function txt = objective_text_local(mode)
if mode == "krr"
    txt = "exact RBF kernel ridge vector-field regression";
else
    txt = "exact RBF Gaussian-process vector-field regression";
end
end
