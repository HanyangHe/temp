function opt = get_sindy_options(cfg)
%GET_SINDY_OPTIONS Resolve defaults for modular SINDy variants.
%
% The standard numerical settings are shared by the active SINDy variants.
% The final manuscript campaign uses V-SINDy and the proposed LLM-Prior
% SINDy together with M-KBF, ED-SINDy, and replay-only NODE outside this
% helper. PE/Poly-3/neural/weak variants remain available only for ablation or
% hidden-oracle diagnostics and are not part of the primary comparison set.

opt = struct();
opt.enabled = true;
opt.formulationVersion = 'official_brunton_2015_ols_support_fixedrho1e10_noise_ridge_v10';
opt.polyOrderOption = 2;
opt.includeSin = true;
opt.includeCos = true;
opt.validationFraction = 0.20;
opt.validationSeed = 20260816;
opt.verbose = true;

opt.vanilla.enabled = true;
opt.physicsEmbedded.enabled = true;
opt.priorWeighted.enabled = false;
opt.priorWeighted.physicsFeatureWeight = 5.0;


% Formal proposed method: weak-domain LLM prior discovery + ordinary SINDy.
% The bank is discovered once per data/discovery seed and shared across all
% N/noise conditions and all network cases. It is a compact additive bank;
% coefficients and support remain entirely data-identified by the shared SINDy
% backend.
opt.llmPrior.enabled = false;
opt.llmPrior.formulationVersion = 'llm_prior_sindy_weak_domain_compiled_v1';
opt.llmPrior.discoveryProtocolVersion = 'weak_domain_canonical_deterministic_closure_v4';
opt.llmPrior.reasoningEffort = 'medium';
opt.llmPrior.maxOutputTokens = 8000;
opt.llmPrior.maxBasisTerms = 18;
opt.llmPrior.maxLatentFeatures = 8;
opt.llmPrior.priorBank = struct('sg',{{}},'gfm',{{}},'gfl',{{}});
opt.llmPrior.priorItems = struct('sg',struct([]),'gfm',struct([]),'gfl',struct([]));
opt.llmPrior.maxExpressionDepth = 8;
opt.llmPrior.maxExpressionComplexity = 32;
opt.llmPrior.maxBasisAbsValue = 1e10;
opt.llmPrior.discoverySeed = 0;
opt.llmPrior.priorBankHash = '';
opt.llmPrior.discoveryProtocolHash = '';

% Non-production diagnostic: a weak-domain LLM compiles a compact physical
% prior bank from device semantics + d/q coordinate metadata.  The bank is
% appended to the ordinary V-SINDy library and fitted with the SAME STLSQ
% backend.  Disabled unless a dedicated test explicitly activates it.
opt.llmPriorDiagnostic.enabled = false;
opt.llmPriorDiagnostic.priorBank = struct('sg',{{}},'gfm',{{}},'gfl',{{}});
% Per-term metadata from the LLM prior compiler. Each item may contain
% expression/source/reason/confidence/target_derivatives.  EDSI uses this
% only to retain high-confidence, data-admissible LLM terms during evolution;
% coefficient activation remains entirely STLSQ/data selected.
opt.llmPriorDiagnostic.priorItems = struct('sg',struct([]),'gfm',struct([]),'gfl',struct([]));
opt.llmPriorDiagnostic.maxExpressionDepth = 8;
opt.llmPriorDiagnostic.maxExpressionComplexity = 32;
opt.llmPriorDiagnostic.maxBasisAbsValue = 1e10;
opt.llmPriorDiagnostic.discoverySeed = 0;
opt.llmPriorDiagnostic.priorBankHash = '';
opt.llmPriorDiagnostic.highConfidenceThreshold = 0.80;
opt.llmPriorDiagnostic.protectHighConfidenceTerms = true;
opt.llmPriorDiagnostic.protectSuppliedCoordinateTerms = true;
opt.llmPriorDiagnostic.requireActiveForLLMProtection = true;
opt.llmPriorDiagnostic.maxProtectedPriorTerms = 10;
opt.llmPriorDiagnostic.sequentialCompression = true;
opt.llmPriorDiagnostic.compressionMaxRelativeWorsening = 0.25;
% V5 fixed-width quality controls. LLM motif/closure terms may enlarge only a
% temporary proposal pool; every identified/evolved dictionary remains at the
% original V-SINDy width. Numerically redundant LLM proposals are removed
% before compression, and a small fixed-width swap polish reduces path
% dependence of sequential backward deletion.
opt.llmPriorDiagnostic.priorRedundancyRelativeTolerance = 1e-10;
opt.llmPriorDiagnostic.compressionDeletionShortlist = 20;
opt.llmPriorDiagnostic.compressionSwapPolish = true;
opt.llmPriorDiagnostic.compressionSwapPolishMaxPasses = 2;

% Compact fixed-neural-ridge SINDy variants. The neural dictionary replaces
% the polynomial+sin/cos generic library rather than appending to it.
% PNC-SINDy is the active compositional random-feature method. The former
% flat PN-SINDy remains available only as a structure ablation. Legacy
% N-SINDy and prior-weighted variants remain disabled for compatibility.
opt.neural.enabled = false;
opt.physicsNeural.enabled = false;
opt.physicsNeuralCompositional.enabled = true;
% PNC v2 embeds BOTH parent models as exact selectable submodels before
% activating additional compositional depth.
opt.physicsNeuralCompositional.includeLayer1BypassCandidate = true;
opt.physicsNeuralCompositional.includeFlatPNSkipCandidate = true;
% Use a deterministic but distinct random-feature stream for Phi_comp(chi,H).
opt.physicsNeuralCompositional.compositionalSeedOffset = 1000003;
% Strict diagnostic ablation: layer 1 is the same frozen PE-SINDy backbone,
% but layer 2 contains ONLY Phi_comp(chi,H). Disabled in all production runs.
opt.physicsNeuralCompositionalCompOnly.enabled = false;
% Residual-composition diagnostic: layer 1 is the same frozen PE-SINDy
% backbone and layer 2 learns only xdot-H with Phi_comp(chi,H). Xi_c=0 is
% an exact PE parent. Disabled in all production runs.
opt.physicsNeuralCompositionalResidual.enabled = false;
% Residualized PNC-v3 diagnostic: layer 2 learns xdot-H with the full
% [H, flat-PN dictionary, Phi_comp(chi,H)] correction library. Exact PE and
% flat-PN parent models are inserted explicitly. Disabled in production.
opt.physicsNeuralCompositionalResidualizedV3.enabled = false;
opt.priorWeightedNeural.enabled = false;
opt.priorWeightedNeural.physicsFeatureWeight = 5.0;

% Weak SINDy uses the SAME generic polynomial+sin/cos dictionary as
% Vanilla SINDy, but estimates coefficients from compact-support weak
% integral constraints. Thus the weak-form baseline changes the derivative
% treatment without adopting the proposed PNC-SINDy compositional representation.
opt.weakSindy.enabled = true;
opt.weakSindy.windowPoints = [11 21 31];
opt.weakSindy.windowStride = 1;
opt.weakSindy.testFunctionPower = 2;
opt.weakSindy.thresholdGrid = [ ...
    1e-6 3e-6 1e-5 3e-5 1e-4 3e-4 ...
    1e-3 3e-3 1e-2 3e-2 1e-1 3e-1 1 3 10 30];
% Weak-SINDy uses one fixed, support-preserving Tikhonov refit after
% ordinary STLSQ support discovery.  This is intentionally NOT selected
% from the noisy validation data: the same tiny rho is used for clean and
% noisy weak regressions so the diagnostic isolates the weak formulation.
opt.weakSindy.supportRidgeRelativeAlpha = 1e-10;

% Retired Weak PN-SINDy options are kept disabled only so old saved models
% can still be inspected manually if needed. They are not registered.
opt.weakPhysicsNeural.enabled = false;
opt.weakPhysicsNeural.windowPoints = [11 21 31];
opt.weakPhysicsNeural.windowStride = 1;
opt.weakPhysicsNeural.testFunctionPower = 2;
opt.weakPhysicsNeural.thresholdGrid = opt.weakSindy.thresholdGrid;

% Same fixed-neural-ridge construction used by the PhDN neural augmentation:
% training-only normalization, orthogonal random projection blocks, projected
% quantile transition locations, multiple tanh scales, variance/correlation
% screening, and pivoted-QR diversity selection.
opt.neuralBasis.featureCount = 64;
opt.neuralBasis.activation = 'tanh';
opt.neuralBasis.quantiles = [0.20 0.40 0.60 0.80];
opt.neuralBasis.scales = [0.5 1.0 2.0];
opt.neuralBasis.poolRatio = 3.0;
opt.neuralBasis.seed = 1701;
opt.neuralBasis.stdFloor = 1e-10;
opt.neuralBasis.varianceThreshold = 1e-8;
opt.neuralBasis.correlationThreshold = 0.995;
opt.neuralBasis.ensureFullDirectionalSpan = true;

% STLSQ is performed on training-only column/output normalized data. The
% selected physical coefficients are subsequently unnormalized for rollout.
opt.stlsq.thresholdGrid = [0 1e-6 3e-6 1e-5 3e-5 1e-4 3e-4 1e-3 ...
    3e-3 1e-2 3e-2 1e-1 3e-1];
opt.stlsq.solver = 'official_brunton_2015';
opt.stlsq.maxIterations = 10; % documentation: official sparsifyDynamics is fixed at 10
opt.stlsq.ridge = 0;          % support discovery: exact unregularized Brunton STLSQ
opt.stlsq.finalSupportRidgeRho = 1e-10; % clean exact-label frozen-support final refit
opt.stlsq.preferSparseWithinRelativeValidationTolerance = 0.01;
opt.stlsq.validationAbsoluteTolerance = 1e-12;

% Optional validation-only trajectory-consistency screen for pointwise SINDy
% threshold candidates. Disabled by default until the dedicated 10-bus
% confirmation is accepted. When enabled, it uses only the already held-out
% short training trajectories; the manuscript 12-s test trajectory is never
% used for model selection.
opt.stlsq.trajectoryValidation.enabled = false;

% Two-stage coefficient policy after ordinary OLS-STLSQ support discovery.
% Clean exact-vector-field labels receive one fixed tiny Tikhonov refit on the
% frozen support (rho=1e-10). Reconstructed noisy derivative labels instead use
% the validation-selected support-preserving ridge grid below. In both cases
% the discovered support is unchanged by the ridge stage.
opt.stlsq.supportRidge.enabled = false;
opt.stlsq.supportRidge.applicationPolicy = 'reconstructed_derivative_labels_only';
opt.stlsq.supportRidge.relativeAlphaGrid = [ ...
    0 1e-10 1e-9 1e-8 1e-7 1e-6 1e-5 1e-4 1e-3 3e-3 ...
    1e-2 3e-2 1e-1 3e-1 1];
% Within a fixed minimum-complexity support, permit only essentially tied
% pointwise validation candidates before preferring the smaller coefficient
% amplification. This avoids buying conditioning with a material validation loss.
opt.stlsq.supportRidge.tieRelativeValidationTolerance = 0.01;

opt.normalization.libraryScaleFloor = 1e-12;
opt.normalization.outputScaleFloor = 1e-12;

% This floor is numerical protection only. The accepted dataset operates near
% 1 pu voltage, so it should never be active in an ordinary experiment.
opt.physics.voltageMagnitudeSquaredFloor = 1e-8;

if nargin < 1 || ~isstruct(cfg) || ~isfield(cfg,'sindy') || isempty(cfg.sindy)
    return;
end
opt = merge_struct_recursive(opt,cfg.sindy);

% The active SINDy-based methods use the official Brunton-Proctor-Kutz STLSQ
% numerical procedure. Keep these invariants even if an older case config
% still contains the previous internal-solver values.
opt.formulationVersion = 'official_brunton_2015_ols_support_fixedrho1e10_noise_ridge_v10';
opt.stlsq.solver = 'official_brunton_2015';
opt.stlsq.maxIterations = 10;
opt.stlsq.ridge = 0;

if ~isfield(opt,'llmPrior') || ~isstruct(opt.llmPrior)
    error('get_sindy_options:LLMPriorConfig', ...
        'llmPrior configuration is missing.');
end
validateattributes(opt.llmPrior.maxOutputTokens,{'numeric'}, ...
    {'scalar','integer','>=',256,'finite'});
validateattributes(opt.llmPrior.maxBasisTerms,{'numeric'}, ...
    {'scalar','integer','>=',1,'finite'});
validateattributes(opt.llmPrior.maxLatentFeatures,{'numeric'}, ...
    {'scalar','integer','>=',1,'finite'});
validateattributes(opt.llmPrior.maxExpressionDepth,{'numeric'}, ...
    {'scalar','integer','>=',1,'finite'});
validateattributes(opt.llmPrior.maxExpressionComplexity,{'numeric'}, ...
    {'scalar','integer','>=',1,'finite'});
validateattributes(opt.llmPrior.maxBasisAbsValue,{'numeric'}, ...
    {'scalar','>',0,'finite'});
opt.llmPrior.enabled=logical(opt.llmPrior.enabled);
if ~isfield(opt,'llmPriorDiagnostic') || ~isstruct(opt.llmPriorDiagnostic)
    error('get_sindy_options:LLMPriorDiagnosticConfig', ...
        'llmPriorDiagnostic configuration is missing.');
end
validateattributes(opt.llmPriorDiagnostic.highConfidenceThreshold,{'numeric'}, ...
    {'scalar','>=',0,'<=',1,'finite'});
validateattributes(opt.llmPriorDiagnostic.maxProtectedPriorTerms,{'numeric'}, ...
    {'scalar','integer','>=',0,'finite'});
validateattributes(opt.llmPriorDiagnostic.compressionMaxRelativeWorsening,{'numeric'}, ...
    {'scalar','>=',0,'finite'});
validateattributes(opt.llmPriorDiagnostic.priorRedundancyRelativeTolerance,{'numeric'}, ...
    {'scalar','>',0,'<',1,'finite'});
validateattributes(opt.llmPriorDiagnostic.compressionDeletionShortlist,{'numeric'}, ...
    {'scalar','integer','>=',1,'finite'});
validateattributes(opt.llmPriorDiagnostic.compressionSwapPolishMaxPasses,{'numeric'}, ...
    {'scalar','integer','>=',0,'finite'});
opt.llmPriorDiagnostic.protectHighConfidenceTerms = ...
    logical(opt.llmPriorDiagnostic.protectHighConfidenceTerms);
opt.llmPriorDiagnostic.protectSuppliedCoordinateTerms = ...
    logical(opt.llmPriorDiagnostic.protectSuppliedCoordinateTerms);
opt.llmPriorDiagnostic.requireActiveForLLMProtection = ...
    logical(opt.llmPriorDiagnostic.requireActiveForLLMProtection);
opt.llmPriorDiagnostic.sequentialCompression = ...
    logical(opt.llmPriorDiagnostic.sequentialCompression);
opt.llmPriorDiagnostic.compressionSwapPolish = ...
    logical(opt.llmPriorDiagnostic.compressionSwapPolish);

validateattributes(opt.polyOrderOption,{'numeric'},{'scalar','integer','>=',1,'<=',5});
validateattributes(opt.validationFraction,{'numeric'},{'scalar','>',0,'<',1});
validateattributes(opt.stlsq.thresholdGrid,{'numeric'},{'vector','nonnegative','finite'});
validateattributes(opt.stlsq.maxIterations,{'numeric'},{'scalar','integer','>=',1});
validateattributes(opt.stlsq.ridge,{'numeric'},{'scalar','nonnegative','finite'});
validateattributes(opt.stlsq.finalSupportRidgeRho,{'numeric'}, ...
    {'scalar','nonnegative','finite'});
if ~isfield(opt.stlsq,'trajectoryValidation') || ...
        ~isstruct(opt.stlsq.trajectoryValidation) || ...
        ~isfield(opt.stlsq.trajectoryValidation,'enabled')
    error('get_sindy_options:TrajectoryValidationConfig', ...
        'opt.stlsq.trajectoryValidation.enabled must be defined.');
end
opt.stlsq.trajectoryValidation.enabled = ...
    logical(opt.stlsq.trajectoryValidation.enabled);
if ~isfield(opt.stlsq,'supportRidge') || ~isstruct(opt.stlsq.supportRidge) || ...
        ~isfield(opt.stlsq.supportRidge,'enabled') || ...
        ~isfield(opt.stlsq.supportRidge,'applicationPolicy') || ...
        ~isfield(opt.stlsq.supportRidge,'relativeAlphaGrid') || ...
        ~isfield(opt.stlsq.supportRidge,'tieRelativeValidationTolerance')
    error('get_sindy_options:SupportRidgeConfig', ...
        'opt.stlsq.supportRidge enabled/policy/grid/tolerance fields must be defined.');
end
opt.stlsq.supportRidge.enabled = logical(opt.stlsq.supportRidge.enabled);
policy = lower(strtrim(string(opt.stlsq.supportRidge.applicationPolicy)));
allowedPolicy = ["always","reconstructed_derivative_labels_only","never"];
if ~isscalar(policy) || ~any(policy == allowedPolicy)
    error('get_sindy_options:SupportRidgePolicy', ...
        'supportRidge.applicationPolicy must be always, reconstructed_derivative_labels_only, or never.');
end
opt.stlsq.supportRidge.applicationPolicy = char(policy);
validateattributes(opt.stlsq.supportRidge.relativeAlphaGrid,{'numeric'}, ...
    {'vector','nonempty','nonnegative','finite'});
opt.stlsq.supportRidge.relativeAlphaGrid = unique( ...
    double(opt.stlsq.supportRidge.relativeAlphaGrid(:).'),'stable');
if ~any(opt.stlsq.supportRidge.relativeAlphaGrid == 0)
    opt.stlsq.supportRidge.relativeAlphaGrid = ...
        [0 opt.stlsq.supportRidge.relativeAlphaGrid];
end
validateattributes(opt.stlsq.supportRidge.tieRelativeValidationTolerance, ...
    {'numeric'},{'scalar','nonnegative','finite'});
validateattributes(opt.physics.voltageMagnitudeSquaredFloor,{'numeric'}, ...
    {'scalar','positive','finite'});
validateattributes(opt.priorWeighted.physicsFeatureWeight,{'numeric'}, ...
    {'scalar','>=',1,'finite'});
validateattributes(opt.priorWeightedNeural.physicsFeatureWeight,{'numeric'}, ...
    {'scalar','>=',1,'finite'});
if ~isfield(opt,'physicsNeuralCompositional') || ...
        ~isstruct(opt.physicsNeuralCompositional) || ...
        ~isfield(opt.physicsNeuralCompositional,'enabled') || ...
        ~isfield(opt.physicsNeuralCompositional,'includeLayer1BypassCandidate') || ...
        ~isfield(opt.physicsNeuralCompositional,'includeFlatPNSkipCandidate') || ...
        ~isfield(opt.physicsNeuralCompositional,'compositionalSeedOffset')
    error('get_sindy_options:PNCConfig', ...
        ['physicsNeuralCompositional enabled/PE-bypass/flat-PN-skip/', ...
         'compositionalSeedOffset fields must be defined.']);
end
opt.physicsNeuralCompositional.enabled = logical(opt.physicsNeuralCompositional.enabled);
opt.physicsNeuralCompositional.includeLayer1BypassCandidate = ...
    logical(opt.physicsNeuralCompositional.includeLayer1BypassCandidate);
opt.physicsNeuralCompositional.includeFlatPNSkipCandidate = ...
    logical(opt.physicsNeuralCompositional.includeFlatPNSkipCandidate);
validateattributes(opt.physicsNeuralCompositional.compositionalSeedOffset, ...
    {'numeric'},{'scalar','integer','nonnegative','finite'});
if ~isfield(opt,'physicsNeuralCompositionalCompOnly') || ...
        ~isstruct(opt.physicsNeuralCompositionalCompOnly) || ...
        ~isfield(opt.physicsNeuralCompositionalCompOnly,'enabled')
    error('get_sindy_options:PNCCompOnlyConfig', ...
        'physicsNeuralCompositionalCompOnly.enabled must be defined.');
end
opt.physicsNeuralCompositionalCompOnly.enabled = ...
    logical(opt.physicsNeuralCompositionalCompOnly.enabled);
if ~isfield(opt,'physicsNeuralCompositionalResidual') || ...
        ~isstruct(opt.physicsNeuralCompositionalResidual) || ...
        ~isfield(opt.physicsNeuralCompositionalResidual,'enabled')
    error('get_sindy_options:PNCResidualConfig', ...
        'physicsNeuralCompositionalResidual.enabled must be defined.');
end
opt.physicsNeuralCompositionalResidual.enabled = ...
    logical(opt.physicsNeuralCompositionalResidual.enabled);
if ~isfield(opt,'physicsNeuralCompositionalResidualizedV3') || ...
        ~isstruct(opt.physicsNeuralCompositionalResidualizedV3) || ...
        ~isfield(opt.physicsNeuralCompositionalResidualizedV3,'enabled')
    error('get_sindy_options:PNCResidualizedV3Config', ...
        'physicsNeuralCompositionalResidualizedV3.enabled must be defined.');
end
opt.physicsNeuralCompositionalResidualizedV3.enabled = ...
    logical(opt.physicsNeuralCompositionalResidualizedV3.enabled);
validateattributes(opt.neuralBasis.featureCount,{'numeric'}, ...
    {'scalar','integer','>=',1,'finite'});
validateattributes(opt.neuralBasis.quantiles,{'numeric'}, ...
    {'vector','nonempty','finite','>',0,'<',1});
validateattributes(opt.neuralBasis.scales,{'numeric'}, ...
    {'vector','nonempty','finite','positive'});
validateattributes(opt.neuralBasis.poolRatio,{'numeric'}, ...
    {'scalar','>=',1,'finite'});
validateattributes(opt.neuralBasis.seed,{'numeric'}, ...
    {'scalar','integer','nonnegative','finite'});
validateattributes(opt.neuralBasis.stdFloor,{'numeric'}, ...
    {'scalar','positive','finite'});
validateattributes(opt.neuralBasis.varianceThreshold,{'numeric'}, ...
    {'scalar','nonnegative','finite'});
validateattributes(opt.neuralBasis.correlationThreshold,{'numeric'}, ...
    {'scalar','>',0,'<=',1,'finite'});
validateattributes(opt.weakSindy.windowPoints,{'numeric'}, ...
    {'vector','nonempty','integer','>=',3,'finite'});
validateattributes(opt.weakSindy.windowStride,{'numeric'}, ...
    {'scalar','integer','>=',1,'finite'});
validateattributes(opt.weakSindy.testFunctionPower,{'numeric'}, ...
    {'scalar','integer','>=',1,'finite'});
validateattributes(opt.weakSindy.thresholdGrid,{'numeric'}, ...
    {'vector','nonempty','nonnegative','finite'});
validateattributes(opt.weakSindy.supportRidgeRelativeAlpha,{'numeric'}, ...
    {'scalar','nonnegative','finite'});
validateattributes(opt.weakPhysicsNeural.windowPoints,{'numeric'}, ...
    {'vector','nonempty','integer','>=',3,'finite'});
validateattributes(opt.weakPhysicsNeural.windowStride,{'numeric'}, ...
    {'scalar','integer','>=',1,'finite'});
validateattributes(opt.weakPhysicsNeural.testFunctionPower,{'numeric'}, ...
    {'scalar','integer','>=',1,'finite'});
validateattributes(opt.weakPhysicsNeural.thresholdGrid,{'numeric'}, ...
    {'vector','nonempty','nonnegative','finite'});
if nargin >= 1 && isstruct(cfg) && isfield(cfg,'data') && ...
        isfield(cfg.data,'pointsPerTrajectory') && ~isempty(cfg.data.pointsPerTrajectory)
    if opt.weakSindy.enabled && any(opt.weakSindy.windowPoints > cfg.data.pointsPerTrajectory)
        error('get_sindy_options:WeakWindowTooLong', ...
            'Weak SINDy windowPoints must not exceed pointsPerTrajectory.');
    end
    if opt.weakPhysicsNeural.enabled && ...
            any(opt.weakPhysicsNeural.windowPoints > cfg.data.pointsPerTrajectory)
        error('get_sindy_options:LegacyWeakPNWindowTooLong', ...
            'Legacy Weak PN-SINDy windowPoints must not exceed pointsPerTrajectory.');
    end
end
if ~strcmpi(strtrim(char(opt.neuralBasis.activation)),'tanh')
    error('get_sindy_options:NeuralActivation', ...
        'Current compact neural SINDy implementation supports activation=''tanh'' only.');
end
end

function a = merge_struct_recursive(a,b)
%MERGE_STRUCT_RECURSIVE Merge scalar option structs without expanding arrays.
%
% Only scalar structs are recursively merged.  Struct arrays are treated as
% leaf values and copied as a whole.  This matters for LLM-prior metadata:
% fields such as priorItems.sg/gfm/gfl are arrays of per-term structs.  If a
% struct array is recursed into, MATLAB field access (b.(f)) becomes a
% comma-separated list and calls such as isstruct(b.(f)) are interpreted as
% multiple input arguments.
if ~(isstruct(b) && isscalar(b))
    a = b;
    return;
end
if ~(isstruct(a) && isscalar(a))
    a = b;
    return;
end

fields = fieldnames(b);
for k = 1:numel(fields)
    f = fields{k};
    bv = b.(f);
    if isfield(a,f)
        av = a.(f);
    else
        av = [];
    end

    if isstruct(bv) && isscalar(bv) && isstruct(av) && isscalar(av)
        a.(f) = merge_struct_recursive(av,bv);
    else
        % Numeric/string/cell values, empty structs, and struct arrays are
        % leaves.  Preserve their exact shape and metadata.
        a.(f) = bv;
    end
end
end
