function opt = get_koopman_options(cfg)
%GET_KOOPMAN_OPTIONS Options for continuous-generator modular M-KBF.
%
% This benchmark adaptation identifies the continuous lifted bilinear vector
% field from Jiang et al. Eq. (16):
%     zdot = A z + sum_i q_i B_i z,     z = T(x).
% T is a fixed ordinary normalized monomial lift. Because degree-one
% observables are included, xdot is recovered exactly from zdot by a fixed
% linear derivative map. No learned decoder, inverse lift, discrete KBF step,
% isotypic extension, or (x_next-x)/dt surrogate is used during DAE rollout.
%
% v6 selection policy:
%   1) preserve the near-zero-ridge limit by ALWAYS including alpha=0;
%   2) preserve the full usable SVD-rank candidate;
%   3) use a deterministic nested whole-trajectory validation split so that
%      increasing N expands rather than replaces the validation region;
%   4) use a one-standard-error / uncertainty-aware near-best rule;
%   5) within that statistically indistinguishable candidate pool, prefer
%      smaller effective degrees of freedom, then smaller inverse-noise
%      amplification.
%
% This improves finite-sample robustness without imposing a positive lower
% bound on ridge that would prevent alpha -> 0 as the data become sufficient.

opt = struct();
opt.enabled = false;
opt.formulationVersion = 'continuous_generator_eq16_poly3_uncertainty_rank_ridge_v6';
opt.liftingMode = 'normalized_state_monomials';
opt.polyOrder = 3;
opt.validationFraction = 0.20;
opt.validationSeed = 20260816;
opt.validationSplitMode = 'nested_stride';
opt.verbose = true;
opt.identificationForm = 'continuous_generator_eq16';
opt.rolloutForm = 'direct_vector_field';

% Fixed-reference rank sweep. Fractions refer to M*(1+nForce), not to the
% sample-dependent numerical rank. Candidate ranks are clipped to the usable
% numerical rank, and v6 additionally ALWAYS appends the full usable rank.
opt.rankCandidateCount = 18;
opt.rankFractionFloor = 0.05;
opt.rankFractionCeiling = 0.40;
opt.rankRelativeSingularValueFloor = 1e-10;
opt.maxRank = inf;
opt.alwaysIncludeFullUsableRank = true;

% alpha is dimensionless; actual Tikhonov lambda = alpha*sigma_max(Omega)^2.
% alpha=0 exactly recovers the truncated-SVD pseudoinverse. v6 always inserts
% alpha=0 even if an older root config omits it, because the zero-ridge limit
% is required for the high-data model to approach the unregularized solution.
opt.ridgeRelativeGrid = [0 1e-10 1e-8 1e-7 1e-6 1e-5 1e-4 1e-3 1e-2];
opt.alwaysIncludeZeroRidge = true;

% Uncertainty-aware model selection. For each candidate, validation error is
% first aggregated trajectory by trajectory. Let e* be the smallest mean
% validation error and SE* the standard error across validation trajectories.
% The near-best pool is
%   meanError <= e* + max(oneSEMultiplier*SE*, relativeFloor*e*, absTol).
% With one validation trajectory, the relative floor provides a conservative
% nonzero band because an inter-trajectory SE cannot be estimated.
opt.selectionRule = 'one_se_effective_df';
opt.oneSEMultiplier = 1.0;
opt.oneSERelativeFloor = 0.05;
opt.validationAbsoluteTolerance = 1e-12;

% Kept only for backward-compatible config parsing. v6 does NOT use the old
% fixed relative near-best tolerance as its primary selection rule.
opt.preferSimplerWithinRelativeValidationTolerance = 0.01;

% Preference only. If no candidate satisfies it, finite candidates remain
% eligible. This remains a screening preference, not a hard stability proof.
opt.maxAutonomousRealPart = 10.0;
opt.enforceConstantObservableDerivative = true;
opt.normalization.stateStdFloor = 1e-8;
opt.normalization.forceStdFloor = 1e-8;
opt.normalization.outputScaleFloor = 1e-10;

if nargin >= 1 && isstruct(cfg) && isfield(cfg,'koopman') && isstruct(cfg.koopman)
    userKoopman = cfg.koopman;
    opt = merge_struct(opt,userKoopman);
    % Always force the current mathematical formulation. Shared user settings
    % such as enabled/polyOrder/rank window remain configurable, but stale
    % formulation tags from earlier trials must not reactivate old logic.
    opt.formulationVersion = 'continuous_generator_eq16_poly3_uncertainty_rank_ridge_v6';
    opt.liftingMode = 'normalized_state_monomials';
    opt.identificationForm = 'continuous_generator_eq16';
    opt.rolloutForm = 'direct_vector_field';
end

% v6 invariants. These are intentional mathematical requirements rather than
% tuning defaults and therefore remain active even when an older root config
% supplies a ridge grid without zero.
if opt.alwaysIncludeZeroRidge
    opt.ridgeRelativeGrid = unique([0 double(opt.ridgeRelativeGrid(:).')],'stable');
else
    opt.ridgeRelativeGrid = unique(double(opt.ridgeRelativeGrid(:).'),'stable');
end

validateattributes(opt.enabled,{'logical','numeric'},{'scalar'},mfilename,'cfg.koopman.enabled');
opt.enabled = logical(opt.enabled);
validateattributes(opt.polyOrder,{'numeric'},{'scalar','integer','>=',1,'<=',5},mfilename,'cfg.koopman.polyOrder');
validateattributes(opt.validationFraction,{'numeric'},{'scalar','>',0,'<',1},mfilename,'cfg.koopman.validationFraction');
validateattributes(opt.validationSeed,{'numeric'},{'scalar','finite'},mfilename,'cfg.koopman.validationSeed');
if ~ismember(lower(string(opt.validationSplitMode)),["nested_stride","random_holdout"])
    error('get_koopman_options:ValidationSplitMode', ...
        'cfg.koopman.validationSplitMode must be "nested_stride" or "random_holdout".');
end
validateattributes(opt.rankCandidateCount,{'numeric'},{'scalar','integer','>=',2},mfilename,'cfg.koopman.rankCandidateCount');
validateattributes(opt.rankFractionFloor,{'numeric'},{'scalar','>',0,'<=',1},mfilename,'cfg.koopman.rankFractionFloor');
validateattributes(opt.rankFractionCeiling,{'numeric'},{'scalar','>',0,'<=',1},mfilename,'cfg.koopman.rankFractionCeiling');
if opt.rankFractionCeiling < opt.rankFractionFloor
    error('get_koopman_options:RankFractionWindow', ...
        'cfg.koopman.rankFractionCeiling must be >= cfg.koopman.rankFractionFloor.');
end
validateattributes(opt.rankRelativeSingularValueFloor,{'numeric'},{'scalar','>',0},mfilename,'cfg.koopman.rankRelativeSingularValueFloor');
validateattributes(opt.maxRank,{'numeric'},{'scalar','positive'},mfilename,'cfg.koopman.maxRank');
validateattributes(opt.alwaysIncludeFullUsableRank,{'logical','numeric'},{'scalar'},mfilename,'cfg.koopman.alwaysIncludeFullUsableRank');
opt.alwaysIncludeFullUsableRank = logical(opt.alwaysIncludeFullUsableRank);
validateattributes(opt.alwaysIncludeZeroRidge,{'logical','numeric'},{'scalar'},mfilename,'cfg.koopman.alwaysIncludeZeroRidge');
opt.alwaysIncludeZeroRidge = logical(opt.alwaysIncludeZeroRidge);
validateattributes(opt.ridgeRelativeGrid,{'numeric'},{'vector','nonnegative','finite'},mfilename,'cfg.koopman.ridgeRelativeGrid');
if isempty(opt.ridgeRelativeGrid)
    error('get_koopman_options:RidgeGrid','cfg.koopman.ridgeRelativeGrid cannot be empty.');
end
if ~ismember(lower(string(opt.selectionRule)),["one_se_effective_df","legacy_relative_tolerance"])
    error('get_koopman_options:SelectionRule', ...
        'cfg.koopman.selectionRule must be "one_se_effective_df" or "legacy_relative_tolerance".');
end
validateattributes(opt.oneSEMultiplier,{'numeric'},{'scalar','>=',0,'finite'},mfilename,'cfg.koopman.oneSEMultiplier');
validateattributes(opt.oneSERelativeFloor,{'numeric'},{'scalar','>=',0,'finite'},mfilename,'cfg.koopman.oneSERelativeFloor');
validateattributes(opt.preferSimplerWithinRelativeValidationTolerance,{'numeric'}, ...
    {'scalar','>=',0},mfilename,'cfg.koopman.preferSimplerWithinRelativeValidationTolerance');
validateattributes(opt.validationAbsoluteTolerance,{'numeric'},{'scalar','>=',0},mfilename,'cfg.koopman.validationAbsoluteTolerance');
validateattributes(opt.maxAutonomousRealPart,{'numeric'},{'scalar','finite'},mfilename,'cfg.koopman.maxAutonomousRealPart');
validateattributes(opt.enforceConstantObservableDerivative,{'logical','numeric'},{'scalar'},mfilename,'cfg.koopman.enforceConstantObservableDerivative');
opt.enforceConstantObservableDerivative = logical(opt.enforceConstantObservableDerivative);
validateattributes(opt.normalization.stateStdFloor,{'numeric'},{'scalar','>',0},mfilename,'cfg.koopman.normalization.stateStdFloor');
validateattributes(opt.normalization.forceStdFloor,{'numeric'},{'scalar','>',0},mfilename,'cfg.koopman.normalization.forceStdFloor');
validateattributes(opt.normalization.outputScaleFloor,{'numeric'},{'scalar','>',0},mfilename,'cfg.koopman.normalization.outputScaleFloor');

if ~strcmpi(opt.liftingMode,'normalized_state_monomials')
    error('get_koopman_options:LiftingMode', ...
        'Current CT M-KBF implementation supports liftingMode="normalized_state_monomials" only.');
end
if ~strcmpi(opt.identificationForm,'continuous_generator_eq16')
    error('get_koopman_options:IdentificationForm', ...
        'Current M-KBF baseline directly identifies the continuous Eq. (16) generator only.');
end
if ~strcmpi(opt.rolloutForm,'direct_vector_field')
    error('get_koopman_options:RolloutForm', ...
        'Current M-KBF baseline returns xdot directly to the common DAE ODE block.');
end
end

function out = merge_struct(base,override)
out = base;
if isempty(override), return; end
fn = fieldnames(override);
for k = 1:numel(fn)
    name = fn{k};
    if isstruct(override.(name)) && isfield(out,name) && isstruct(out.(name))
        out.(name) = merge_struct(out.(name),override.(name));
    else
        out.(name) = override.(name);
    end
end
end
