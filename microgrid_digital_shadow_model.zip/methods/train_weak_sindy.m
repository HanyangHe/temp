function [model,info] = train_weak_sindy(dataset,c,layout,cfg)
%TRAIN_WEAK_SINDY Conventional weak-form SINDy baseline.
[model,info] = train_modular_weak_sindy(dataset,c,layout,cfg);
end
