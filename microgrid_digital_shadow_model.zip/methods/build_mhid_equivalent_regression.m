function [A,B,meta] = build_mhid_equivalent_regression(data,Theta,trajectoryIds,opt)
%BUILD_MHID_EQUIVALENT_REGRESSION Build the ADDITIONAL MHID integral rows.
%
% Ordinary pointwise vector-field rows are NOT built here; they are retained
% separately by FIT_MHID_STLSQ_MODULE. This function constructs only the
% multi-horizon subobjective.
%
% For one short trajectory r with samples t_1,...,t_L and selected horizon
% h=1,...,H,
%
%   y_{r,h} = [x(t_{h+1})-x(t_1)]/[t_{h+1}-t_1]
%
%   phi_{r,h} = 1/[t_{h+1}-t_1]
%               * integral_{t_1}^{t_{h+1}} Theta(t) dt.
%
% The integral is evaluated by the composite trapezoidal rule along the
% observed truth trajectory. Therefore
%
%   B ~= A*Xi
%
% remains linear in Xi. No integration crosses a trajectory boundary.
%
% opt.maxHorizonSteps = 0 returns empty A/B and disables the integral
% subobjective while leaving the full pointwise vector-field objective intact.

if size(Theta,1) ~= data.nSamples
    error('build_mhid_equivalent_regression:ThetaSize', ...
        'Theta must contain one row per flattened sample.');
end

trajectoryIds = unique(trajectoryIds(:).','stable');
A = zeros(0,size(Theta,2));
B = zeros(0,data.nOutputs);

nIntegral = 0;
usedHorizons = zeros(0,1);
maxHorizonSeconds = 0;

if opt.maxHorizonSteps == 0 || opt.integralWeight == 0
    meta = make_meta(trajectoryIds,nIntegral,usedHorizons,maxHorizonSeconds);
    return;
end

for tr = trajectoryIds
    rows = find(data.trajectoryId == tr);
    if isempty(rows)
        error('build_mhid_equivalent_regression:MissingTrajectory', ...
            'Trajectory ID %d is not present in the dataset.',tr);
    end
    [~,ord] = sort(data.pointInTrajectory(rows));
    rows = rows(ord);
    pointIds = data.pointInTrajectory(rows);
    t = data.trajectoryTime(pointIds);

    if numel(rows) < 2
        error('build_mhid_equivalent_regression:ShortTrajectory', ...
            'Trajectory %d must contain at least two points.',tr);
    end
    if any(diff(t) <= 0)
        error('build_mhid_equivalent_regression:TimeOrder', ...
            'Trajectory time must be strictly increasing.');
    end

    H = min(opt.maxHorizonSteps,numel(rows)-1);
    xObs = data.stateObserved(rows,:);
    th = Theta(rows,:);

    for h = 1:H
        duration = t(h+1)-t(1);
        if ~(isfinite(duration) && duration > 0)
            error('build_mhid_equivalent_regression:Duration', ...
                'Invalid horizon duration in trajectory %d, h=%d.',tr,h);
        end

        % Average observed vector field over the h-step interval.
        yAvg = (xObs(h+1,:)-xObs(1,:))/duration;

        % Average candidate dictionary over the same interval. For uniform dt,
        % this is exactly
        %   1/(2h)[Theta_1 + 2Theta_2 + ... + 2Theta_h + Theta_{h+1}].
        phiAvg = trapz(t(1:h+1),th(1:h+1,:),1)/duration;

        A(end+1,:) = phiAvg; %#ok<AGROW>
        B(end+1,:) = yAvg; %#ok<AGROW>
        nIntegral = nIntegral + 1;
        usedHorizons(end+1,1) = h; %#ok<AGROW>
        maxHorizonSeconds = max(maxHorizonSeconds,duration);
    end
end

meta = make_meta(trajectoryIds,nIntegral,usedHorizons,maxHorizonSeconds);
end

function meta = make_meta(trajectoryIds,nIntegral,usedHorizons,maxHorizonSeconds)
meta.trajectoryIds = trajectoryIds(:);
meta.constraintCount = nIntegral;
meta.integralConstraintCount = nIntegral;
meta.usedHorizons = unique(usedHorizons,'stable');
if isempty(meta.usedHorizons)
    meta.maxHorizonSteps = 0;
else
    meta.maxHorizonSteps = max(meta.usedHorizons);
end
meta.maxHorizonSeconds = maxHorizonSeconds;
meta.fixedOriginWithinTrajectory = true;
meta.integralRule = 'composite trapezoidal';
meta.targetDefinition = 'fixed-origin cumulative average vector fields';
end
