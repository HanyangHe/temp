function [model,info] = train_edsi(dataset,c,layout,cfg)
%TRAIN_EDSI Formal ED-SINDy baseline (evolutionary-dictionary SINDy).
[model,info] = train_edsi_core(dataset,c,layout,cfg,"edsi");
end
