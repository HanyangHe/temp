function fhat = predict_modular_sindy(model,~,x,V,u,c,layout)
%PREDICT_MODULAR_SINDY Evaluate any of the three modular SINDy vector fields.

opt = model.options;
fhat = zeros(layout.nx,1);
for k = 1:numel(c.sg)
    m = model.sg(k);
    if numel(m.stateIndices) == 5 && isfield(u,'sgVref')
        chi = [x(m.stateIndices);real(V(m.bus));imag(V(m.bus));u.sgPm(k);u.sgVref(k)].';
    else
        chi = [x(m.stateIndices);real(V(m.bus));imag(V(m.bus));u.sgPm(k)].';
    end
    fhat(m.stateIndices) = eval_module(m,chi,opt);
end
for k = 1:numel(c.gfm)
    m = model.gfm(k);
    chi = [x(m.stateIndices);real(V(m.bus));imag(V(m.bus)); ...
        u.gfmPstar(k);u.gfmQstar(k);u.gfmEref(k)].';
    fhat(m.stateIndices) = eval_module(m,chi,opt);
end
for k = 1:numel(c.gfl)
    m = model.gfl(k);
    chi = [x(m.stateIndices);real(V(m.bus));imag(V(m.bus)); ...
        u.gflPstar(k);u.gflQstar(k)].';
    fhat(m.stateIndices) = eval_module(m,chi,opt);
end

if any(~isfinite(fhat))
    error('predict_modular_sindy:NonfiniteOutput','SINDy returned a non-finite vector field.');
end
end

function y = eval_module(m,chi,opt)
% librarySpec was frozen and checked during training. During recursive DAE
% rollout evaluate values only: rebuilding/comparing string labels at every
% ODE15I call is unnecessary and was especially costly for nested LLM priors.
Theta = build_sindy_library(double(chi),m.inputNames,m.deviceType, ...
    m.variant,opt,m.librarySpec);
y = (Theta*m.coefficients).';
end
