function [Z,names,spec,dZ] = build_koopman_monomial_lift(X,stateNames,polyOrder,spec,Xdot)
%BUILD_KOOPMAN_MONOMIAL_LIFT Normalized-state monomial Koopman observables.
%
% X is [nState x nSample] and Z is [nObservable x nSample]. The dictionary
% contains the constant and every monomial of total degree 1..polyOrder.
% Degree-one observables are deliberately first after the constant, so the
% normalized physical state is recovered exactly by a fixed linear selector.
%
% If Xdot is supplied, dZ is evaluated analytically by the chain rule. This
% is used by the continuous-generator M-KBF baseline to identify Eq. (16)
% directly, without finite-difference or discrete-map-to-vector-field steps.

if nargin < 4 || isempty(spec)
    spec = make_spec(size(X,1),polyOrder);
end
if size(X,1) ~= spec.nState
    error('build_koopman_monomial_lift:StateSize', ...
        'Expected %d state rows, received %d.',spec.nState,size(X,1));
end
if nargin < 2 || isempty(stateNames)
    stateNames = "s" + string((1:spec.nState).');
else
    stateNames = string(stateNames(:));
end
if numel(stateNames) ~= spec.nState
    error('build_koopman_monomial_lift:StateNames','stateNames has incorrect length.');
end
computeDerivative = nargin >= 5 && ~isempty(Xdot);
if computeDerivative && ~isequal(size(Xdot),size(X))
    error('build_koopman_monomial_lift:DerivativeSize', ...
        'Xdot must have the same size as X.');
end

N = size(X,2);
M = spec.observableCount;
Z = ones(M,N);
names = strings(M,1);
names(1) = "1";
if computeDerivative
    dZ = zeros(M,N);
else
    dZ = [];
end

row = 1;
for d = 1:numel(spec.monomialIndices)
    combos = spec.monomialIndices{d};
    for r = 1:size(combos,1)
        row = row + 1;
        idx = combos(r,:);
        Z(row,:) = prod(X(idx,:),1);
        names(row) = monomial_name(stateNames,idx);
        if computeDerivative
            drow = zeros(1,N);
            for p = 1:numel(idx)
                if numel(idx) == 1
                    otherProduct = ones(1,N);
                else
                    other = idx([1:p-1 p+1:end]);
                    otherProduct = prod(X(other,:),1);
                end
                drow = drow + Xdot(idx(p),:).*otherProduct;
            end
            dZ(row,:) = drow;
        end
    end
end
spec.observableNames = names;
end

function spec = make_spec(n,p)
spec.nState = n;
spec.polyOrder = p;
spec.monomialIndices = cell(p,1);
count = 1;
for d = 1:p
    spec.monomialIndices{d} = combinations_with_repetition(n,d);
    count = count + size(spec.monomialIndices{d},1);
end
spec.constantObservableIndex = 1;
spec.linearObservableIndices = (2:(n+1)).';
spec.observableCount = count;
end

function C = combinations_with_repetition(n,d)
rows = cell(0,1);
recurse([],1,d);
C = zeros(numel(rows),d);
for i = 1:numel(rows), C(i,:) = rows{i}; end

    function recurse(prefix,startValue,remaining)
        if remaining == 0
            rows{end+1,1} = prefix; %#ok<AGROW>
            return;
        end
        for v = startValue:n
            recurse([prefix v],v,remaining-1); %#ok<AGROW>
        end
    end
end

function name = monomial_name(stateNames,idx)
u = unique(idx,'stable');
parts = strings(1,numel(u));
for k = 1:numel(u)
    j = u(k);
    pow = sum(idx==j);
    if pow == 1
        parts(k) = stateNames(j);
    else
        parts(k) = stateNames(j)+"^"+string(pow);
    end
end
name = strjoin(parts,"*");
end
