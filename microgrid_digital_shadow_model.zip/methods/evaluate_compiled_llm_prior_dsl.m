function [Phi,names] = evaluate_compiled_llm_prior_dsl(X,spec,varargin)
%EVALUATE_COMPILED_LLM_PRIOR_DSL Fast evaluation of a precompiled prior DAG.
%
% Every unique symbolic subexpression is evaluated once per call.  This is
% important for ODE/DAE rollouts because d/q transforms and voltage norms are
% reused by several LLM-discovered basis functions.

p=inputParser;
p.addParameter('DenominatorFloor',1e-10,@(v)isnumeric(v)&&isscalar(v)&&isfinite(v)&&v>0);
p.addParameter('MaxAbsValue',1e10,@(v)isnumeric(v)&&isscalar(v)&&isfinite(v)&&v>0);
p.parse(varargin{:});
opt=p.Results;

X=double(X);
if size(X,2)~=double(spec.nRawInputs)
    error('evaluate_compiled_llm_prior_dsl:InputDimension', ...
        'X has %d columns but compiled spec expects %d.',size(X,2),spec.nRawInputs);
end

nNode=numel(spec.nodes);
vals=cell(nNode,1);
for k=1:nNode
    q=spec.nodes(k);
    switch q.op
        case 'const'
            v=ones(size(X,1),1);
        case 'var'
            v=X(:,double(q.varIndex));
        case 'sin'
            v=sin(vals{double(q.args(1))});
        case 'cos'
            v=cos(vals{double(q.args(1))});
        case 'square'
            a=vals{double(q.args(1))}; v=a.^2;
        case 'sqrt_pos'
            a=vals{double(q.args(1))};
            sc=max(1,max(abs(a(:))));
            if any(a < -100*eps(sc))
                v=nan(size(a));
            else
                v=sqrt(max(a,0));
            end
        case 'prod'
            v=ones(size(X,1),1);
            for j=1:numel(q.args), v=v.*vals{double(q.args(j))}; end
        case 'add'
            v=zeros(size(X,1),1);
            for j=1:numel(q.args), v=v+vals{double(q.args(j))}; end
        case 'sub'
            v=vals{double(q.args(1))}-vals{double(q.args(2))};
        case 'div'
            a=vals{double(q.args(1))}; b=vals{double(q.args(2))};
            if any(~isfinite(b)) || any(abs(b)<opt.DenominatorFloor)
                v=nan(size(a));
            else
                v=a./b;
            end
        otherwise
            error('evaluate_compiled_llm_prior_dsl:Operator','Unknown operator %s.',q.op);
    end
    vals{k}=v;
end

roots=double(spec.rootNodeIndices(:));
Phi=zeros(size(X,1),numel(roots));
for j=1:numel(roots), Phi(:,j)=vals{roots(j)}; end
if any(~isfinite(Phi),'all')
    error('evaluate_compiled_llm_prior_dsl:Nonfinite', ...
        'Compiled LLM-prior bank produced non-finite values.');
end
if any(abs(Phi)>opt.MaxAbsValue,'all')
    error('evaluate_compiled_llm_prior_dsl:Magnitude', ...
        'Compiled LLM-prior bank exceeds MaxAbsValue=%.3g.',opt.MaxAbsValue);
end
names=string(spec.names(:));
end
