function Xi = sparsifyDynamics(Theta,dXdt,lambda,n,rho)
%SPARSIFYDYNAMICS Ridge-regularized sequential threshold least squares.
%
% Formal project version (2026-10-02): every least-squares solve used by
% SINDy/STLSQ is Tikhonov regularized with rho = 1e-10 by default,
%
%   min_Xi ||Theta*Xi - dXdt||_F^2 + rho*||Xi||_F^2.
%
% The same rho is used for the initial regression and every active-support
% refit.  The fifth input is optional only for backward compatibility with
% existing call sites; all formal 10/69/123-bus configs set rho=1e-10.
%
% This file preserves the original sequential hard-thresholding structure
% (10 iterations) while replacing unregularized backslash solves by a
% numerically stable augmented Tikhonov least-squares solve.

if nargin < 5 || isempty(rho)
    rho = 1e-10;
end
validateattributes(rho,{'numeric'},{'scalar','real','finite','nonnegative'}, ...
    mfilename,'rho',5);

if nargin < 4 || isempty(n)
    n = size(dXdt,2);
end

% Initial ridge-regularized least-squares estimate.
Xi = ridge_solve_local(Theta,dXdt,rho);

% lambda is the sparsification knob.  lambda<=0 returns the ridge estimate.
if lambda <= 0
    return;
end

for iter = 1:10 %#ok<NASGU> % retain the formal 10-iteration STLSQ protocol
    smallinds = (abs(Xi) < lambda);
    Xi(smallinds) = 0;

    for ind = 1:n
        biginds = ~smallinds(:,ind);
        if any(biginds)
            Xi(biginds,ind) = ridge_solve_local( ...
                Theta(:,biginds),dXdt(:,ind),rho);
        else
            Xi(:,ind) = 0;
        end
    end
end
end

function X = ridge_solve_local(A,B,rho)
% Solve min_X ||A*X-B||_F^2 + rho||X||_F^2 using augmented LS.
% The augmented formulation avoids explicitly forming A'*A and therefore
% does not square the condition number of a rank-deficient SINDy library.

if isempty(A)
    X = zeros(0,size(B,2),'like',B);
    return;
end

if rho <= 0
    X = A\B;
    return;
end

p = size(A,2);
Aaug = [A; sqrt(rho)*eye(p,'like',A)];
Baug = [B; zeros(p,size(B,2),'like',B)];
X = Aaug\Baug;
end
