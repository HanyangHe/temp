function [tf,details] = check_sindy_model_compatibility(methodName,model,cfg)
%CHECK_SINDY_MODEL_COMPATIBILITY Method-specific compatibility validation.
%
% This intentionally does NOT compare the global cfg.sindy.formulationVersion
% string. That tag can change when another SINDy baseline is renamed or its
% dictionary is revised even when the requested method is mathematically
% unchanged. Instead, compatibility is decided from the actual saved model:
% solver, STLSQ settings, dictionary family, neural-basis settings, prior
% weight, and the concrete retained physics-feature names.
%
% This makes saved-model reuse strict where it matters while avoiding false
% incompatibility caused by unrelated framework-wide version labels.

methodName = char(string(methodName));
if nargin < 3 || ~isstruct(cfg)
    error('check_sindy_model_compatibility:Config','cfg is required.');
end
if nargin < 2 || ~isstruct(model)
    error('check_sindy_model_compatibility:Model','A trained SINDy model struct is required.');
end

expected = expected_signature_local(methodName,cfg);
actual = actual_signature_local(methodName,model);
issues = strings(0,1);

issues = compare_text_local(issues,'model type',actual.modelType,expected.modelType);
issues = compare_text_local(issues,'model variant',actual.modelVariant,expected.modelVariant);
issues = compare_text_local(issues,'dictionary family',actual.dictionaryFamily,expected.dictionaryFamily);
issues = compare_text_local(issues,'STLSQ solver',actual.stlsqSolver,expected.stlsqSolver);
issues = compare_number_local(issues,'STLSQ iterations',actual.stlsqIterations,expected.stlsqIterations,0);
issues = compare_number_local(issues,'STLSQ ridge',actual.stlsqRidge,expected.stlsqRidge,1e-15);
issues = compare_vector_local(issues,'threshold grid',actual.thresholdGrid,expected.thresholdGrid,1e-14);
issues = compare_number_local(issues,'validation fraction',actual.validationFraction,expected.validationFraction,1e-14);
issues = compare_number_local(issues,'validation seed',actual.validationSeed,expected.validationSeed,0);
issues = compare_number_local(issues,'relative sparse-selection tolerance', ...
    actual.relativeSparseTolerance,expected.relativeSparseTolerance,1e-14);
issues = compare_number_local(issues,'absolute validation tolerance', ...
    actual.validationAbsoluteTolerance,expected.validationAbsoluteTolerance,1e-18);
issues = compare_number_local(issues,'library normalization floor', ...
    actual.libraryScaleFloor,expected.libraryScaleFloor,1e-18);
issues = compare_number_local(issues,'output normalization floor', ...
    actual.outputScaleFloor,expected.outputScaleFloor,1e-18);

if strcmp(methodName,'physics_neural_compositional_sindy')
    issues = compare_number_local(issues,'PNC layer-1 polynomial order', ...
        actual.layer1PolyOrder,expected.layer1PolyOrder,0);
    issues = compare_logical_local(issues,'PNC layer-1 includeSin', ...
        actual.layer1IncludeSin,expected.layer1IncludeSin);
    issues = compare_logical_local(issues,'PNC layer-1 includeCos', ...
        actual.layer1IncludeCos,expected.layer1IncludeCos);
    issues = compare_logical_local(issues,'PNC explicit PE bypass candidate', ...
        actual.layer1BypassCandidateIncluded,expected.layer1BypassCandidateIncluded);
    issues = compare_logical_local(issues,'PNC explicit flat-PN skip candidate', ...
        actual.flatPNSkipCandidateIncluded,expected.flatPNSkipCandidateIncluded);
    issues = compare_number_local(issues,'PNC compositional seed offset', ...
        actual.compositionalSeedOffset,expected.compositionalSeedOffset,0);
    issues = compare_text_local(issues,'PNC architecture version', ...
        actual.pncArchitectureVersion,expected.pncArchitectureVersion);
end

if ~expected.weakFormEnabled
    issues = compare_logical_local(issues,'support-ridge configured', ...
        actual.supportRidgeConfigured,expected.supportRidgeConfigured);
    issues = compare_text_local(issues,'support-ridge application policy', ...
        actual.supportRidgeApplicationPolicy,expected.supportRidgeApplicationPolicy);
    issues = compare_vector_local(issues,'support-ridge relative-alpha grid', ...
        actual.supportRidgeRelativeAlphaGrid,expected.supportRidgeRelativeAlphaGrid,1e-18);
    issues = compare_number_local(issues,'support-ridge validation tie tolerance', ...
        actual.supportRidgeTieRelativeValidationTolerance, ...
        expected.supportRidgeTieRelativeValidationTolerance,1e-18);
end

if strcmp(expected.dictionaryFamily,'polytrig')
    issues = compare_number_local(issues,'polynomial order',actual.polyOrder,expected.polyOrder,0);
    issues = compare_logical_local(issues,'includeSin',actual.includeSin,expected.includeSin);
    issues = compare_logical_local(issues,'includeCos',actual.includeCos,expected.includeCos);
else
    issues = compare_number_local(issues,'neural feature count',actual.neuralFeatureCount,expected.neuralFeatureCount,0);
    issues = compare_text_local(issues,'neural activation',actual.neuralActivation,expected.neuralActivation);
    issues = compare_vector_local(issues,'neural quantiles',actual.neuralQuantiles,expected.neuralQuantiles,1e-14);
    issues = compare_vector_local(issues,'neural scales',actual.neuralScales,expected.neuralScales,1e-14);
    issues = compare_number_local(issues,'neural pool ratio',actual.neuralPoolRatio,expected.neuralPoolRatio,1e-14);
    issues = compare_number_local(issues,'neural basis seed',actual.neuralSeed,expected.neuralSeed,0);
    issues = compare_number_local(issues,'neural std floor',actual.neuralStdFloor,expected.neuralStdFloor,1e-18);
    issues = compare_number_local(issues,'neural variance threshold', ...
        actual.neuralVarianceThreshold,expected.neuralVarianceThreshold,1e-18);
    issues = compare_number_local(issues,'neural correlation threshold', ...
        actual.neuralCorrelationThreshold,expected.neuralCorrelationThreshold,1e-14);
    issues = compare_logical_local(issues,'neural directional-span rule', ...
        actual.neuralEnsureFullDirectionalSpan,expected.neuralEnsureFullDirectionalSpan);
end

issues = compare_number_local(issues,'physics prior weight',actual.physicsPriorWeight, ...
    expected.physicsPriorWeight,1e-14);

issues = compare_logical_local(issues,'weak-form objective', ...
    actual.weakFormEnabled,expected.weakFormEnabled);
if expected.weakFormEnabled
    issues = compare_vector_local(issues,'weak window points', ...
        actual.weakWindowPoints,expected.weakWindowPoints,0);
    issues = compare_number_local(issues,'weak window stride', ...
        actual.weakWindowStride,expected.weakWindowStride,0);
    issues = compare_number_local(issues,'weak test-function power', ...
        actual.weakTestFunctionPower,expected.weakTestFunctionPower,0);
end

% Compare the actual physics columns stored in each module. This is the key
% distinction between the former weak PE dictionary and the current complete
% PE/PW/PWN dictionary. A renamed global version string cannot substitute for
% this structural check.
deviceTypes = {'sg','gfm','gfl'};
for k = 1:numel(deviceTypes)
    d = deviceTypes{k};
    if actual.devicePresent.(d)
        aRaw = actual.physicsFeatures.(d);
        eRaw = expected.physicsFeatures.(d);
        a = sort(string(aRaw(:)));
        e = sort(string(eRaw(:)));
        if numel(a) ~= numel(e) || any(a ~= e)
            issues(end+1,1) = sprintf('%s physics feature set differs: saved={%s}, expected={%s}', ...
                upper(d),char(strjoin(a,', ')),char(strjoin(e,', '))); %#ok<AGROW>
        end
    end
end

% Sanity-check coefficient/library dimensions for every stored module.
modIssues = validate_module_dimensions_local(model);
if ~isempty(modIssues)
    issues = [issues;modIssues(:)]; %#ok<AGROW>
end

tf = isempty(issues);
details = struct();
details.schemaVersion = 'sindy_method_compatibility_v4';
details.compatible = tf;
details.methodName = methodName;
details.expected = expected;
details.actual = actual;
details.storedModelVariant = string(actual.storedModelVariant);
details.canonicalModelVariant = string(actual.modelVariant);
details.legacyVariantAliasApplied = ~strcmp(char(details.storedModelVariant),char(details.canonicalModelVariant));
details.issues = issues;
details.savedFormulationVersion = provenance_version_local(model);
details.currentFormulationVersion = string(get_sindy_options(cfg).formulationVersion);
if tf
    details.message = 'Method-specific mathematical compatibility verified.';
else
    details.message = strjoin(issues,newline);
end
end

function sig = expected_signature_local(methodName,cfg)
opt = get_sindy_options(cfg);
contract = method_contract_local(methodName);
sig = blank_signature_local();
sig.modelType = 'modular_sindy';
sig.modelVariant = contract.modelVariant;
sig.dictionaryFamily = contract.dictionaryFamily;
sig.stlsqSolver = char(string(opt.stlsq.solver));
sig.stlsqIterations = double(opt.stlsq.maxIterations);
sig.stlsqRidge = double(opt.stlsq.ridge);
sig.thresholdGrid = double(opt.stlsq.thresholdGrid(:).');
sig.validationFraction = double(opt.validationFraction);
sig.validationSeed = double(opt.validationSeed);
sig.relativeSparseTolerance = double(opt.stlsq.preferSparseWithinRelativeValidationTolerance);
sig.validationAbsoluteTolerance = double(opt.stlsq.validationAbsoluteTolerance);
sig.libraryScaleFloor = double(opt.normalization.libraryScaleFloor);
sig.outputScaleFloor = double(opt.normalization.outputScaleFloor);
if ~contract.weakForm
    sig.supportRidgeConfigured = logical(opt.stlsq.supportRidge.enabled);
    sig.supportRidgeApplicationPolicy = char(string(opt.stlsq.supportRidge.applicationPolicy));
    sig.supportRidgeRelativeAlphaGrid = double(opt.stlsq.supportRidge.relativeAlphaGrid(:).');
    sig.supportRidgeTieRelativeValidationTolerance = ...
        double(opt.stlsq.supportRidge.tieRelativeValidationTolerance);
end

if strcmp(contract.dictionaryFamily,'polytrig')
    if strcmp(methodName,'poly3_sindy')
        sig.polyOrder = 3;
    else
        sig.polyOrder = double(opt.polyOrderOption);
    end
    sig.includeSin = logical(opt.includeSin);
    sig.includeCos = logical(opt.includeCos);
else
    sig.neuralFeatureCount = double(opt.neuralBasis.featureCount);
    sig.neuralActivation = char(string(opt.neuralBasis.activation));
    sig.neuralQuantiles = double(opt.neuralBasis.quantiles(:).');
    sig.neuralScales = double(opt.neuralBasis.scales(:).');
    sig.neuralPoolRatio = double(opt.neuralBasis.poolRatio);
    sig.neuralSeed = double(opt.neuralBasis.seed);
    sig.neuralStdFloor = double(opt.neuralBasis.stdFloor);
    sig.neuralVarianceThreshold = double(opt.neuralBasis.varianceThreshold);
    sig.neuralCorrelationThreshold = double(opt.neuralBasis.correlationThreshold);
    sig.neuralEnsureFullDirectionalSpan = logical(opt.neuralBasis.ensureFullDirectionalSpan);
end

if strcmp(methodName,'physics_neural_compositional_sindy')
    sig.layer1PolyOrder = double(opt.polyOrderOption);
    sig.layer1IncludeSin = logical(opt.includeSin);
    sig.layer1IncludeCos = logical(opt.includeCos);
    sig.layer1BypassCandidateIncluded = ...
        logical(opt.physicsNeuralCompositional.includeLayer1BypassCandidate);
    sig.flatPNSkipCandidateIncluded = ...
        logical(opt.physicsNeuralCompositional.includeFlatPNSkipCandidate);
    sig.compositionalSeedOffset = ...
        double(opt.physicsNeuralCompositional.compositionalSeedOffset);
    sig.pncArchitectureVersion = 'pnc_skip_composition_v2';
end

if contract.weightedPhysics
    if strcmp(methodName,'prior_weighted_neural_sindy')
        sig.physicsPriorWeight = double(opt.priorWeightedNeural.physicsFeatureWeight);
    else
        sig.physicsPriorWeight = double(opt.priorWeighted.physicsFeatureWeight);
    end
else
    sig.physicsPriorWeight = 1.0;
end

if contract.hasPhysics
    sig.physicsFeatures = current_full_physics_features_local(opt);
else
    sig.physicsFeatures = empty_physics_features_local();
end
sig.weakFormEnabled = logical(contract.weakForm);
if contract.weakForm
    w = weak_options_for_method_local(methodName,opt);
    sig.thresholdGrid = double(w.thresholdGrid(:).');
    sig.weakWindowPoints = double(w.windowPoints(:).');
    sig.weakWindowStride = double(w.windowStride);
    sig.weakTestFunctionPower = double(w.testFunctionPower);
end
end

function sig = actual_signature_local(methodName,model)
contract = method_contract_local(methodName);
sig = blank_signature_local();
if isfield(model,'type'), sig.modelType = char(string(model.type)); end
if isfield(model,'variant')
    sig.storedModelVariant = char(string(model.variant));
    sig.modelVariant = canonical_model_variant_local(methodName,sig.storedModelVariant);
end
sig.weakFormEnabled = any(strcmp(sig.modelVariant,{'weak_vanilla','weak_physics_neural'}));
sig.dictionaryFamily = '';

opt = struct();
if isfield(model,'options') && isstruct(model.options), opt = model.options; end
mods = all_modules_local(model);
if ~isempty(mods)
    m0 = mods{1};
    if isfield(m0,'dictionaryFamily') && strlength(string(m0.dictionaryFamily))>0
        sig.dictionaryFamily = char(string(m0.dictionaryFamily));
    elseif strcmp(contract.dictionaryFamily,'polytrig')
        sig.dictionaryFamily = 'polytrig';
    end
    if isfield(m0,'stlsqSolver'), sig.stlsqSolver = char(string(m0.stlsqSolver)); end
    if isfield(m0,'stlsqIterations'), sig.stlsqIterations = double(m0.stlsqIterations); end
    if isfield(m0,'stlsqRidge'), sig.stlsqRidge = double(m0.stlsqRidge); end
else
    sig.stlsqSolver = '';
end
if isempty(sig.stlsqSolver) && isfield(opt,'stlsq') && isfield(opt.stlsq,'solver')
    sig.stlsqSolver = char(string(opt.stlsq.solver));
end
if isnan(sig.stlsqIterations) && isfield(opt,'stlsq') && isfield(opt.stlsq,'maxIterations')
    sig.stlsqIterations = double(opt.stlsq.maxIterations);
end
if isnan(sig.stlsqRidge) && isfield(opt,'stlsq') && isfield(opt.stlsq,'ridge')
    sig.stlsqRidge = double(opt.stlsq.ridge);
end

if isfield(opt,'stlsq') && isfield(opt.stlsq,'thresholdGrid')
    sig.thresholdGrid = double(opt.stlsq.thresholdGrid(:).');
end
if isfield(opt,'validationFraction'), sig.validationFraction = double(opt.validationFraction); end
if isfield(opt,'validationSeed'), sig.validationSeed = double(opt.validationSeed); end
if isfield(opt,'stlsq') && isfield(opt.stlsq,'preferSparseWithinRelativeValidationTolerance')
    sig.relativeSparseTolerance = double(opt.stlsq.preferSparseWithinRelativeValidationTolerance);
end
if isfield(opt,'stlsq') && isfield(opt.stlsq,'validationAbsoluteTolerance')
    sig.validationAbsoluteTolerance = double(opt.stlsq.validationAbsoluteTolerance);
end
if isfield(opt,'normalization') && isfield(opt.normalization,'libraryScaleFloor')
    sig.libraryScaleFloor = double(opt.normalization.libraryScaleFloor);
end
if isfield(opt,'normalization') && isfield(opt.normalization,'outputScaleFloor')
    sig.outputScaleFloor = double(opt.normalization.outputScaleFloor);
end
if ~contract.weakForm && isfield(opt,'stlsq') && isfield(opt.stlsq,'supportRidge') && ...
        isstruct(opt.stlsq.supportRidge)
    r = opt.stlsq.supportRidge;
    if isfield(r,'enabled'), sig.supportRidgeConfigured = logical(r.enabled); end
    if isfield(r,'applicationPolicy')
        sig.supportRidgeApplicationPolicy = char(string(r.applicationPolicy));
    end
    if isfield(r,'relativeAlphaGrid')
        sig.supportRidgeRelativeAlphaGrid = double(r.relativeAlphaGrid(:).');
    end
    if isfield(r,'tieRelativeValidationTolerance')
        sig.supportRidgeTieRelativeValidationTolerance = ...
            double(r.tieRelativeValidationTolerance);
    end
end

if strcmp(contract.dictionaryFamily,'polytrig')
    if isfield(opt,'polyOrderOption'), sig.polyOrder = double(opt.polyOrderOption); end
    if isfield(opt,'includeSin'), sig.includeSin = logical(opt.includeSin); end
    if isfield(opt,'includeCos'), sig.includeCos = logical(opt.includeCos); end
else
    if isfield(opt,'neuralBasis')
        n = opt.neuralBasis;
        if isfield(n,'featureCount'), sig.neuralFeatureCount = double(n.featureCount); end
        if isfield(n,'activation'), sig.neuralActivation = char(string(n.activation)); end
        if isfield(n,'quantiles'), sig.neuralQuantiles = double(n.quantiles(:).'); end
        if isfield(n,'scales'), sig.neuralScales = double(n.scales(:).'); end
        if isfield(n,'poolRatio'), sig.neuralPoolRatio = double(n.poolRatio); end
        if isfield(n,'seed'), sig.neuralSeed = double(n.seed); end
        if isfield(n,'stdFloor'), sig.neuralStdFloor = double(n.stdFloor); end
        if isfield(n,'varianceThreshold'), sig.neuralVarianceThreshold = double(n.varianceThreshold); end
        if isfield(n,'correlationThreshold'), sig.neuralCorrelationThreshold = double(n.correlationThreshold); end
        if isfield(n,'ensureFullDirectionalSpan')
            sig.neuralEnsureFullDirectionalSpan = logical(n.ensureFullDirectionalSpan);
        end
    end

end

if strcmp(methodName,'physics_neural_compositional_sindy')
    if isfield(opt,'polyOrderOption'), sig.layer1PolyOrder = double(opt.polyOrderOption); end
    if isfield(opt,'includeSin'), sig.layer1IncludeSin = logical(opt.includeSin); end
    if isfield(opt,'includeCos'), sig.layer1IncludeCos = logical(opt.includeCos); end
    bypassFlags = false(0,1);
    pnSkipFlags = false(0,1);
    seedOffsets = zeros(0,1);
    archVersions = strings(0,1);
    for kk = 1:numel(mods)
        mm = mods{kk};
        if isfield(mm,'layer1BypassCandidateIncluded')
            bypassFlags(end+1,1) = logical(mm.layer1BypassCandidateIncluded); %#ok<AGROW>
        end
        if isfield(mm,'shallowPNSkipCandidateIncluded')
            pnSkipFlags(end+1,1) = logical(mm.shallowPNSkipCandidateIncluded); %#ok<AGROW>
        end
        if isfield(mm,'compositionalSeedOffset')
            seedOffsets(end+1,1) = double(mm.compositionalSeedOffset); %#ok<AGROW>
        end
        if isfield(mm,'architectureVersion')
            archVersions(end+1,1) = string(mm.architectureVersion); %#ok<AGROW>
        end
    end
    if isempty(bypassFlags)
        if isfield(opt,'physicsNeuralCompositional') && ...
                isfield(opt.physicsNeuralCompositional,'includeLayer1BypassCandidate')
            sig.layer1BypassCandidateIncluded = ...
                logical(opt.physicsNeuralCompositional.includeLayer1BypassCandidate);
        end
    elseif all(bypassFlags == bypassFlags(1))
        sig.layer1BypassCandidateIncluded = bypassFlags(1);
    end
    if isempty(pnSkipFlags)
        if isfield(opt,'physicsNeuralCompositional') && ...
                isfield(opt.physicsNeuralCompositional,'includeFlatPNSkipCandidate')
            sig.flatPNSkipCandidateIncluded = ...
                logical(opt.physicsNeuralCompositional.includeFlatPNSkipCandidate);
        end
    elseif all(pnSkipFlags == pnSkipFlags(1))
        sig.flatPNSkipCandidateIncluded = pnSkipFlags(1);
    end
    if isempty(seedOffsets)
        if isfield(opt,'physicsNeuralCompositional') && ...
                isfield(opt.physicsNeuralCompositional,'compositionalSeedOffset')
            sig.compositionalSeedOffset = ...
                double(opt.physicsNeuralCompositional.compositionalSeedOffset);
        end
    elseif all(seedOffsets == seedOffsets(1))
        sig.compositionalSeedOffset = seedOffsets(1);
    end
    if isempty(archVersions)
        sig.pncArchitectureVersion = '';
    elseif all(archVersions == archVersions(1))
        sig.pncArchitectureVersion = char(archVersions(1));
    end
end

if sig.weakFormEnabled
    w = weak_options_for_method_local(methodName,opt);
    if isfield(w,'thresholdGrid'), sig.thresholdGrid = double(w.thresholdGrid(:).'); end
    if isfield(w,'windowPoints'), sig.weakWindowPoints = double(w.windowPoints(:).'); end
    if isfield(w,'windowStride'), sig.weakWindowStride = double(w.windowStride); end
    if isfield(w,'testFunctionPower'), sig.weakTestFunctionPower = double(w.testFunctionPower); end
end

% Prefer the weight actually stored in trained modules.
weights = zeros(0,1);
for k = 1:numel(mods)
    if isfield(mods{k},'physicsPriorFeatureWeight')
        weights(end+1,1) = double(mods{k}.physicsPriorFeatureWeight); %#ok<AGROW>
    end
end
if isempty(weights)
    sig.physicsPriorWeight = 1.0;
else
    sig.physicsPriorWeight = weights(1);
    if any(abs(weights-sig.physicsPriorWeight) > 1e-14)
        sig.physicsPriorWeight = NaN;
    end
end

sig.physicsFeatures = empty_physics_features_local();
sig.devicePresent = struct('sg',false,'gfm',false,'gfl',false);
for dCell = {'sg','gfm','gfl'}
    d = dCell{1};
    if ~isfield(model,d) || isempty(model.(d)), continue; end
    sig.devicePresent.(d) = true;
    names = strings(0,1);
    arr = model.(d);
    for j = 1:numel(arr)
        if strcmp(methodName,'physics_neural_compositional_sindy') && ...
                isfield(arr(j),'layer1') && isstruct(arr(j).layer1) && ...
                isfield(arr(j).layer1,'libraryNames')
            q = string(arr(j).layer1.libraryNames(:));
        elseif isfield(arr(j),'libraryNames')
            q = string(arr(j).libraryNames(:));
        else
            q = strings(0,1);
        end
        q = q(startsWith(q,'phys_'));
        names = [names;q]; %#ok<AGROW>
    end
    sig.physicsFeatures.(d) = unique(names,'stable');
end
end


function v = canonical_model_variant_local(methodName,vStored)
% Map retired metadata aliases only when they represent the same method.
%
% Before PE/SPE consolidation, the complete/full-physics polynomial SINDy
% baseline was stored as variant='strong'.  The current canonical name for
% that SAME dictionary is variant='physics'.  This is a metadata rename, not
% a mathematical relaxation.  We map the alias here only for the PE method;
% the concrete phys_* feature-set comparison below still has to pass, so an
% old weak-PE model cannot be admitted by this alias.
methodName = char(string(methodName));
v = char(string(vStored));
if strcmp(methodName,'physics_embedded_sindy') && strcmp(v,'strong')
    v = 'physics';
end
end

function contract = method_contract_local(methodName)
contract = struct('dictionaryFamily','','modelVariant','','hasPhysics',false, ...
    'weightedPhysics',false,'weakForm',false);
switch char(string(methodName))
    case {'vanilla_sindy','poly3_sindy'}
        contract.dictionaryFamily = 'polytrig';
        contract.modelVariant = 'vanilla';
    case 'physics_embedded_sindy'
        contract.dictionaryFamily = 'polytrig';
        contract.modelVariant = 'physics';
        contract.hasPhysics = true;
    case 'prior_weighted_sindy'
        contract.dictionaryFamily = 'polytrig';
        contract.modelVariant = 'priorweighted';
        contract.hasPhysics = true;
        contract.weightedPhysics = true;
    case 'neural_sindy'
        contract.dictionaryFamily = 'fixed_neural_ridge';
        contract.modelVariant = 'neural';
    case 'physics_neural_sindy'
        contract.dictionaryFamily = 'fixed_neural_ridge';
        contract.modelVariant = 'physics_neural';
        contract.hasPhysics = true;
    case 'physics_neural_compositional_sindy'
        contract.dictionaryFamily = 'skip_compositional_fixed_neural_ridge';
        contract.modelVariant = 'physics_neural_compositional';
        contract.hasPhysics = true;
    case 'weak_sindy'
        contract.dictionaryFamily = 'polytrig';
        contract.modelVariant = 'weak_vanilla';
        contract.weakForm = true;
    case 'weak_physics_neural_sindy'
        contract.dictionaryFamily = 'fixed_neural_ridge';
        contract.modelVariant = 'weak_physics_neural';
        contract.hasPhysics = true;
        contract.weakForm = true;
    case 'prior_weighted_neural_sindy'
        contract.dictionaryFamily = 'fixed_neural_ridge';
        contract.modelVariant = 'prior_weighted_neural';
        contract.hasPhysics = true;
        contract.weightedPhysics = true;
    otherwise
        error('check_sindy_model_compatibility:Method', ...
            'Unsupported SINDy method "%s".',methodName);
end
end

function w = weak_options_for_method_local(methodName,opt)
methodName = char(string(methodName));
if strcmp(methodName,'weak_sindy')
    if ~isfield(opt,'weakSindy') || ~isstruct(opt.weakSindy)
        error('check_sindy_model_compatibility:MissingWeakSindyOptions', ...
            'Weak SINDy options are missing from the saved/current model.');
    end
    w = opt.weakSindy;
elseif strcmp(methodName,'weak_physics_neural_sindy')
    if ~isfield(opt,'weakPhysicsNeural') || ~isstruct(opt.weakPhysicsNeural)
        error('check_sindy_model_compatibility:MissingLegacyWeakPNOptions', ...
            'Legacy Weak PN options are missing from the saved/current model.');
    end
    w = opt.weakPhysicsNeural;
else
    error('check_sindy_model_compatibility:WeakMethod', ...
        'No weak-form options are defined for method %s.',methodName);
end
end

function sig = blank_signature_local()
sig = struct();
sig.modelType = '';
sig.modelVariant = '';
sig.storedModelVariant = '';
sig.dictionaryFamily = '';
sig.stlsqSolver = '';
sig.stlsqIterations = NaN;
sig.stlsqRidge = NaN;
sig.thresholdGrid = [];
sig.validationFraction = NaN;
sig.validationSeed = NaN;
sig.relativeSparseTolerance = NaN;
sig.validationAbsoluteTolerance = NaN;
sig.libraryScaleFloor = NaN;
sig.outputScaleFloor = NaN;
sig.supportRidgeConfigured = false;
sig.supportRidgeApplicationPolicy = '';
sig.supportRidgeRelativeAlphaGrid = [];
sig.supportRidgeTieRelativeValidationTolerance = NaN;
sig.polyOrder = NaN;
sig.includeSin = false;
sig.includeCos = false;
sig.layer1PolyOrder = NaN;
sig.layer1IncludeSin = false;
sig.layer1IncludeCos = false;
sig.layer1BypassCandidateIncluded = false;
sig.flatPNSkipCandidateIncluded = false;
sig.compositionalSeedOffset = NaN;
sig.pncArchitectureVersion = '';
sig.neuralFeatureCount = NaN;
sig.neuralActivation = '';
sig.neuralQuantiles = [];
sig.neuralScales = [];
sig.neuralPoolRatio = NaN;
sig.neuralSeed = NaN;
sig.neuralStdFloor = NaN;
sig.neuralVarianceThreshold = NaN;
sig.neuralCorrelationThreshold = NaN;
sig.neuralEnsureFullDirectionalSpan = false;
sig.physicsPriorWeight = NaN;
sig.weakFormEnabled = false;
sig.weakWindowPoints = [];
sig.weakWindowStride = NaN;
sig.weakTestFunctionPower = NaN;
sig.physicsFeatures = empty_physics_features_local();
sig.devicePresent = struct('sg',false,'gfm',false,'gfl',false);
end

function p = current_full_physics_features_local(opt)
% Derive the expected feature names from the CURRENT canonical physics
% builder itself. This avoids maintaining a second hard-coded dictionary in
% the compatibility layer.
[~,p.sg] = build_sindy_physics_features(zeros(1,9),'sg','physics',opt);
[~,p.gfm] = build_sindy_physics_features(zeros(1,9),'gfm','physics',opt);
[~,p.gfl] = build_sindy_physics_features(zeros(1,8),'gfl','physics',opt);
p.sg = string(p.sg(:));
p.gfm = string(p.gfm(:));
p.gfl = string(p.gfl(:));
end

function p = empty_physics_features_local()
p = struct('sg',strings(0,1),'gfm',strings(0,1),'gfl',strings(0,1));
end

function mods = all_modules_local(model)
mods = cell(0,1);
for dCell = {'sg','gfm','gfl'}
    d = dCell{1};
    if ~isfield(model,d) || isempty(model.(d)), continue; end
    arr = model.(d);
    for k = 1:numel(arr), mods{end+1,1} = arr(k); end %#ok<AGROW>
end
end

function issues = validate_module_dimensions_local(model)
issues = strings(0,1);
for dCell = {'sg','gfm','gfl'}
    d = dCell{1};
    if ~isfield(model,d) || isempty(model.(d)), continue; end
    arr = model.(d);
    for k = 1:numel(arr)
        m = arr(k);
        if ~isfield(m,'libraryNames') || ~isfield(m,'coefficients')
            issues(end+1,1) = sprintf('%s%d is missing libraryNames or coefficients.',upper(d),k); %#ok<AGROW>
            continue;
        end
        if numel(m.libraryNames) ~= size(m.coefficients,1)
            issues(end+1,1) = sprintf('%s%d library width (%d) differs from coefficient rows (%d).', ...
                upper(d),k,numel(m.libraryNames),size(m.coefficients,1)); %#ok<AGROW>
        end
        if any(~isfinite(m.coefficients),'all')
            issues(end+1,1) = sprintf('%s%d contains nonfinite coefficients.',upper(d),k); %#ok<AGROW>
        end
        if isfield(m,'layer1') && isstruct(m.layer1)
            l1 = m.layer1;
            if ~isfield(l1,'libraryNames') || ~isfield(l1,'coefficients')
                issues(end+1,1) = sprintf('%s%d PNC layer1 is missing libraryNames or coefficients.',upper(d),k); %#ok<AGROW>
            elseif numel(l1.libraryNames) ~= size(l1.coefficients,1)
                issues(end+1,1) = sprintf('%s%d PNC layer1 library width (%d) differs from coefficient rows (%d).', ...
                    upper(d),k,numel(l1.libraryNames),size(l1.coefficients,1)); %#ok<AGROW>
            elseif any(~isfinite(l1.coefficients),'all')
                issues(end+1,1) = sprintf('%s%d PNC layer1 contains nonfinite coefficients.',upper(d),k); %#ok<AGROW>
            else
                if ~isfield(l1,'dictionaryFamily') || ~strcmp(char(string(l1.dictionaryFamily)),'polytrig')
                    issues(end+1,1) = sprintf('%s%d PNC layer1 is not a polytrig PE-SINDy module.',upper(d),k); %#ok<AGROW>
                end
                if ~isfield(l1,'variant') || ~strcmp(char(string(l1.variant)),'physics')
                    issues(end+1,1) = sprintf('%s%d PNC layer1 variant is not physics.',upper(d),k); %#ok<AGROW>
                end
            end
        end
    end
end
end

function issues = compare_text_local(issues,label,a,e)
if ~strcmp(char(string(a)),char(string(e)))
    issues(end+1,1) = sprintf('%s differs: saved="%s", expected="%s"',label,char(string(a)),char(string(e))); %#ok<AGROW>
end
end

function issues = compare_number_local(issues,label,a,e,tol)
if ~(isscalar(a) && isscalar(e) && isfinite(a) && isfinite(e) && abs(double(a)-double(e)) <= tol)
    issues(end+1,1) = sprintf('%s differs: saved=%g, expected=%g',label,double(a),double(e)); %#ok<AGROW>
end
end

function issues = compare_vector_local(issues,label,a,e,tol)
a = double(a(:)); e = double(e(:));
if numel(a) ~= numel(e) || any(~isfinite(a)) || any(~isfinite(e)) || ...
        any(abs(a-e) > tol.*max(1,max(abs(a),abs(e))))
    issues(end+1,1) = sprintf('%s differs.',label); %#ok<AGROW>
end
end

function issues = compare_logical_local(issues,label,a,e)
if ~(isscalar(a) && isscalar(e) && logical(a)==logical(e))
    issues(end+1,1) = sprintf('%s differs: saved=%d, expected=%d',label,logical(a),logical(e)); %#ok<AGROW>
end
end

function v = provenance_version_local(model)
v = "";
if isfield(model,'formulationVersion'), v = string(model.formulationVersion); end
end
