function [model,info] = train_llm_prior_augmented_edsi_diagnostic(dataset,c,layout,cfg)
%TRAIN_LLM_PRIOR_AUGMENTED_EDSI_DIAGNOSTIC Immutable-prior residual EDSI.
%
% V8 diagnostic:
%   - keep the compact weak-domain LLM prior bank intact;
%   - identify that prior block once with the formal shared STLSQ backend;
%   - freeze both its symbolic terms and identified coefficients;
%   - evolve only the original V-SINDy-width dictionary on the remaining
%     vector-field residual;
%   - recalibrate search lambda/ridge on that residual problem;
%   - retain the untouched LLM-prior model as a final champion;
%   - accept an evolved residual correction only when it improves held-out
%     short-trajectory rollout validation (never the manuscript 12-s test).
%
% Thus "fixed width" refers to the EVOLUTIONARY bank width, which remains
% identical to V-SINDy/EDSI. The low-dimensional LLM bank is an additive,
% immutable semantic prior block and is not part of the evolutionary width.
[model,info] = train_edsi_core(dataset,c,layout,cfg,"llm_prior_augmented_edsi");
end
