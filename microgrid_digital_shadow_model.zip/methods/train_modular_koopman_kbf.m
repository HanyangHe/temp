function [model,info] = train_modular_koopman_kbf(dataset,c,layout,cfg)
%TRAIN_MODULAR_KOOPMAN_KBF Train continuous-generator modular M-KBF.
%
% The learned object is Jiang et al. Eq. (16) in a fixed lifted space:
%   zdot = A z + sum_i q_i B_i z,  z=T(x).
% Only A and B_i are learned. T and the derivative reconstruction xdot=Cdot*zdot
% are fixed algebraic maps. The exact network algebraic equations remain
% common physics in the final DAE rollout.

% Opt-in paper-based EDMD/isotypic adapter. The existing official CT result is
% deliberately unchanged unless the caller explicitly requests this version.
if isfield(cfg,'koopman') && isfield(cfg.koopman,'baselineVariant') && ...
        strcmpi(char(string(cfg.koopman.baselineVariant)),'jiang_edmd_isotypic_v1')
    [model,info] = train_jiang_edmd_isotypic_kbf(dataset,c,layout,cfg);
    return;
end

opt = get_koopman_options(cfg);
if ~opt.enabled
    error('train_modular_koopman_kbf:Disabled', ...
        'cfg.koopman.enabled must be true to train the M-KBF baseline.');
end
if ~isfield(dataset,'trajectoryId') || isempty(dataset.trajectoryId)
    error('train_modular_koopman_kbf:TrajectoryDatasetRequired', ...
        'M-KBF requires trajectory IDs for complete-trajectory train/validation splitting.');
end

K = dataset.trajectories.nTrajectories;
if K < 2
    error('train_modular_koopman_kbf:TooFewTrajectories', ...
        'At least two short trajectories are required.');
end

forcedTrainIds = [];
if isfield(dataset.trajectories,'forceTrainingMask') && ...
        ~isempty(dataset.trajectories.forceTrainingMask)
    mask = logical(dataset.trajectories.forceTrainingMask(:));
    if numel(mask) ~= K
        error('train_modular_koopman_kbf:ForceTrainingMaskSize', ...
            'forceTrainingMask must contain one entry per trajectory.');
    end
    forcedTrainIds = find(mask).';
end
validationCandidates = setdiff(1:K,forcedTrainIds,'stable');
if isempty(validationCandidates)
    error('train_modular_koopman_kbf:NoValidationCandidates', ...
        'No trajectory remains for Koopman validation.');
end

[trainIds,valIds,splitInfo] = build_koopman_validation_split( ...
    K,forcedTrainIds,validationCandidates,opt);

model = struct();
model.type = 'modular_koopman_kbf';
model.variant = 'jiang_mkbf_continuous_generator_eq16_poly3_ridge_adaptation';
model.formulationVersion = char(opt.formulationVersion);
model.trainingSampleDefinition = 'pointwise local x/u/xdot samples with complete-trajectory train/validation split';
model.deploymentDefinition = 'direct continuous lifted generator Eq.(16) mapped algebraically to local xdot; exact algebraic network retained';
model.options = opt;
model.trainTrajectoryIds = trainIds(:);
model.validationTrajectoryIds = valIds(:);
model.forcedTrainingTrajectoryIds = forcedTrainIds(:);
model.validationSplitInfo = splitInfo;
model.sg = struct([]); model.gfm = struct([]); model.gfl = struct([]);

modules = struct([]);
mi = 0;
for k = 1:numel(c.sg)
    fprintf('    Training CT M-KBF module SG%d (Bus %d)...\n',k,c.sg(k).bus);
    data = build_koopman_module_vectorfield_data(dataset,c,layout,'sg',k);
    [mk,ik] = fit_koopman_bilinear_module(data,trainIds,valIds,opt);
    if k==1, model.sg=mk; else, model.sg(k,1)=mk; end
    [modules,mi] = append_info(modules,mi,ik);
end
for k = 1:numel(c.gfm)
    fprintf('    Training CT M-KBF module GFM%d (Bus %d)...\n',k,c.gfm(k).bus);
    data = build_koopman_module_vectorfield_data(dataset,c,layout,'gfm',k);
    [mk,ik] = fit_koopman_bilinear_module(data,trainIds,valIds,opt);
    if k==1, model.gfm=mk; else, model.gfm(k,1)=mk; end
    [modules,mi] = append_info(modules,mi,ik);
end
for k = 1:numel(c.gfl)
    fprintf('    Training CT M-KBF module GFL%d (Bus %d)...\n',k,c.gfl(k).bus);
    data = build_koopman_module_vectorfield_data(dataset,c,layout,'gfl',k);
    [mk,ik] = fit_koopman_bilinear_module(data,trainIds,valIds,opt);
    if k==1, model.gfl=mk; else, model.gfl(k,1)=mk; end
    [modules,mi] = append_info(modules,mi,ik);
end

info = struct();
info.method = 'modular_koopman_kbf';
info.displayName = 'M-KBF';
info.formulationVersion = char(opt.formulationVersion);
info.objective = 'continuous-time modular bilinear Koopman generator Eq.(16) regression with nested trajectory holdout and uncertainty-aware one-SE SVD-rank/ridge selection';
info.identificationForm = char(opt.identificationForm);
info.rolloutForm = char(opt.rolloutForm);
info.liftingMode = char(opt.liftingMode);
info.polyOrder = opt.polyOrder;
info.nSamples = size(dataset.x,1);
info.pointsPerTrajectory = dataset.trajectories.pointsPerTrajectory;
info.nTrajectories = K;
info.nTrainTrajectories = numel(trainIds);
info.nValidationTrajectories = numel(valIds);
info.trainTrajectoryIds = trainIds(:);
info.validationTrajectoryIds = valIds(:);
info.forcedTrainingTrajectoryIds = forcedTrainIds(:);
info.validationSplitInfo = splitInfo;
info.modules = modules;

if opt.verbose
    fprintf(['    M-KBF validation split: mode=%s | train trajectories=%d | ', ...
        'validation trajectories=%d | validation ID(s) [%s]\n'], ...
        char(string(splitInfo.mode)),numel(trainIds),numel(valIds), ...
        strtrim(sprintf('%d ',valIds)));
    if isfield(splitInfo,'stride') && isfinite(splitInfo.stride)
        fprintf('      nested validation stride=%d | phase=%d | effective fraction=%.1f%%\n', ...
            splitInfo.stride,splitInfo.phase,100*numel(valIds)/K);
    end
    if ~isempty(forcedTrainIds)
        fprintf('    Forced into M-KBF training partition: trajectory ID(s) [%s]\n', ...
            strtrim(sprintf('%d ',forcedTrainIds)));
    end
end
end

function [trainIds,valIds,info] = build_koopman_validation_split( ...
    K,forcedTrainIds,validationCandidates,opt)
%BUILD_KOOPMAN_VALIDATION_SPLIT Whole-trajectory split for M-KBF.
%
% nested_stride provides a deterministic nested validation family across
% sample sizes. For validationFraction=0.20 the nominal stride is 5. A phase
% derived from validationSeed is shifted, when necessary, so that forced
% training trajectories (normally the formal-test anchor) never fall into the
% validation congruence class. Consequently, when datasets are nested prefixes,
% every validation trajectory selected at a smaller N remains validation at
% larger N, while additional validation trajectories are appended.

mode = lower(string(opt.validationSplitMode));
info = struct('mode',char(mode),'stride',NaN,'phase',NaN);

switch mode
    case "nested_stride"
        stride = max(2,round(1/opt.validationFraction));
        phase = mod(round(opt.validationSeed),stride);

        % Keep the congruence class away from forced-training IDs. This is
        % deterministic and depends only on the seed/forced IDs, not on K.
        for shift = 0:stride-1
            phaseTry = mod(phase+shift,stride);
            if isempty(forcedTrainIds) || ...
                    ~any(mod(forcedTrainIds-phaseTry,stride)==0)
                phase = phaseTry;
                break;
            end
        end

        valIds = validationCandidates( ...
            mod(validationCandidates-phase,stride)==0);

        % A very small custom dataset can contain fewer candidates than one
        % complete stride. Use the earliest available trajectory as a
        % deterministic fallback. Standard manuscript datasets (K>=5) do not
        % normally enter this branch.
        if isempty(valIds)
            valIds = validationCandidates(1);
        end
        valIds = sort(unique(valIds,'stable'));
        trainIds = sort(setdiff(1:K,valIds,'stable'));
        info.stride = stride;
        info.phase = phase;

    case "random_holdout"
        oldRng = rng;
        cleanup = onCleanup(@()rng(oldRng)); %#ok<NASGU>
        rng(opt.validationSeed,'twister');
        perm = validationCandidates(randperm(numel(validationCandidates)));
        nVal = max(1,round(opt.validationFraction*K));
        nVal = min(nVal,numel(validationCandidates));
        if nVal >= K, nVal = K-1; end
        valIds = sort(perm(1:nVal));
        trainIds = sort(setdiff(1:K,valIds,'stable'));

    otherwise
        error('train_modular_koopman_kbf:ValidationSplitMode', ...
            'Unsupported validationSplitMode: %s',char(mode));
end

if isempty(trainIds) || isempty(valIds)
    error('train_modular_koopman_kbf:InvalidSplit', ...
        'M-KBF train/validation split produced an empty partition.');
end
if any(ismember(forcedTrainIds,valIds))
    error('train_modular_koopman_kbf:ForcedTrainLeakage', ...
        'A forced-training trajectory was assigned to validation.');
end
end

function [S,mi] = append_info(S,mi,ik)
mi = mi+1;
if mi==1, S=ik; else, S(mi,1)=ik; end
end
