function [bank,meta] = build_coordexp_polynomial_bank(officialPrior)
%BUILD_COORDEXP_POLYNOMIAL_BANK Device-neutral quadratic d/q expansion.
%
%  [bank,meta] = build_coordexp_polynomial_bank(officialPrior)
%
% This is a NON-LLM CONTROL, NOT a fourth prior level. It uses ONLY:
%  (a) the two user-supplied local-voltage coordinate expressions in
%      officialPrior.responses.<device>.supplied_coordinate_terms;
%  (b) the NUMBER of noncoordinate terms in the frozen full Lv.3 bank.
% It does NOT use any LLM proposed term, family, confidence or ranking.
%
% The original V-SINDy library already contains degree <= 2 polynomials
% and sin/cos of raw chi. The new candidate pool is precisely the portion
% of the degree-2 polynomial expansion of [chi; v_d; v_q] that contains at
% least one supplied d/q coordinate and is not already in Lv.1:
%   v_d^2, v_q^2, v_d*v_q, v_d*x_j, v_q*x_j (j=1,...,n_chi).
% A fixed, balanced degree-2 ordering is used for all device types.
%
% K = length(full Lv.3 bank) - 2 is a BUDGET only, not a term-selection
% signal. If K exceeds the degree-2 pool, the program fails explicitly.

if ~isstruct(officialPrior) || ~isfield(officialPrior,'responses') || ...
        ~isfield(officialPrior,'bank')
    error('build_coordexp_polynomial_bank:Prior', ...
        'A saved formal prior with responses and bank is required.');
end

types = {'sg','gfm','gfl'};
nInputs = [9 9 8];
bank = struct();
meta = struct();
meta.schemaVersion = 'coordexp_generic_quadratic_matched_v1';
meta.typeNames = string(types(:));
meta.nInputs = nInputs(:);
meta.coordinateCounts = zeros(3,1);
meta.fullLv3Counts = zeros(3,1);
meta.genericPoolCounts = zeros(3,1);
meta.genericRetainedCounts = zeros(3,1);
meta.finalCounts = zeros(3,1);
meta.selectRule = ['coordinate squares and product, then symmetric ', ...
    'coordinate*raw pairs ordered by increasing raw variable index'];
meta.coordinateExpressions = struct();
meta.genericExpressions = struct();

for it = 1:numel(types)
    t = types{it};
    if ~isfield(officialPrior.responses,t) || ...
            ~isfield(officialPrior.responses.(t),'supplied_coordinate_terms') || ...
            ~isfield(officialPrior.bank,t)
        error('build_coordexp_polynomial_bank:MissingType', ...
            'Saved prior lacks the supplied coordinates or bank for %s.',t);
    end
    coords = string(officialPrior.responses.(t).supplied_coordinate_terms(:));
    fullBank = string(officialPrior.bank.(t)(:));
    if numel(coords) ~= 2 || numel(unique(coords)) ~= 2
        error('build_coordexp_polynomial_bank:TwoCoordinates', ...
            '%s must have exactly two distinct supplied d/q terms.',upper(t));
    end
    if numel(unique(fullBank)) ~= numel(fullBank) || ...
            ~all(ismember(coords,fullBank))
        error('build_coordexp_polynomial_bank:BankMismatch', ...
            '%s full bank has duplicates or omits a supplied coordinate.',upper(t));
    end
    n = nInputs(it);
    aliases = "x"+string((1:n).');
    % Explicitly check that both supplied coordinates compile under the
    % same official DSL; no physical feature templates are inserted.
    compile_llm_prior_dsl(aliases,coords,'MaxDepth',8,'MaxComplexity',32);

    % Standard quadratic monomials involving >=1 new d/q coordinate.
    pool = strings(3+2*n,1);
    pool(1) = "square("+coords(1)+")";
    pool(2) = "square("+coords(2)+")";
    pool(3) = "prod("+coords(1)+","+coords(2)+")";
    for j = 1:n
        pool(3+2*j-1) = "prod("+coords(1)+",x"+string(j)+")";
        pool(3+2*j) = "prod("+coords(2)+",x"+string(j)+")";
    end
    compiled = compile_llm_prior_dsl(aliases,pool,'MaxDepth',8,'MaxComplexity',32);
    keys = string(compiled.canonicalTerms(:));
    if numel(unique(keys)) ~= numel(keys)
        error('build_coordexp_polynomial_bank:DuplicateGeneric', ...
            '%s has duplicated generic quadratic terms.',upper(t));
    end
    extraBudget = numel(fullBank)-numel(coords);
    if extraBudget < 0 || extraBudget > numel(pool)
        error('build_coordexp_polynomial_bank:BudgetExceedsQuadraticPool', ...
            ['%s: Lv.3 requires %d extra candidates but quadratic ', ...
             'coordinate pool has only %d; do not silently use ', ...
             'device-specific or degree-3 terms.'],upper(t),extraBudget,numel(pool));
    end
    % Retain the same number of candidates as the frozen official Lv.3
    % bank, without importing ANY discovered term identity.
    kept = pool(1:extraBudget);
    terms = [coords;kept];
    bank.(t) = cellstr(terms);
    meta.coordinateCounts(it) = 2;
    meta.fullLv3Counts(it) = numel(fullBank);
    meta.genericPoolCounts(it) = numel(pool);
    meta.genericRetainedCounts(it) = extraBudget;
    meta.finalCounts(it) = numel(terms);
    meta.coordinateExpressions.(t) = cellstr(coords);
    meta.genericExpressions.(t) = cellstr(kept);
end

if any(meta.finalCounts ~= meta.fullLv3Counts)
    error('build_coordexp_polynomial_bank:WidthInvariant', ...
        'C+E and full Lv.3 widths must match for every device type.');
end
meta.bankHash = fnv32_local(jsonencode(bank));
if isfield(officialPrior,'bankHash')
    meta.referenceLv3Hash = char(string(officialPrior.bankHash));
else
    meta.referenceLv3Hash = '';
end
end

function h=fnv32_local(s)
% Use uint64 modular arithmetic to avoid MATLAB uint32 overflow saturation.
b=unicode2native(char(s),'UTF-8');
v=uint64(2166136261); p=uint64(16777619); q=uint64(4294967296);
for i=1:numel(b)
    v=mod(bitxor(v,uint64(b(i)))*p,q);
end
h=sprintf('%08X',uint32(v));
end
