function [module,info] = fit_pnc_sindy_module(data,trainMask,valMask,opt,seed)
%FIT_PNC_SINDY_MODULE Fit PNC-SINDy v2 with PE + flat-PN skip + composition.
%
% Stage 1:
%   H = Theta_PE(chi) * Xi_1
%
% Stage 2 fixed dictionary:
%   Theta_2 = [ H, Theta_PN_flat(chi), Phi_comp(chi,H) ]
%   xdot    = Theta_2 * Xi_2
%
% The former flat PN-SINDy dictionary is embedded as an explicit shallow skip
% path, while H embeds PE-SINDy as an explicit physics bypass. Consequently
% both parent model classes are strict submodels of PNC-SINDy v2.
%
% Training is stagewise. Xi_1 is fit and frozen first. The flat-PN and
% compositional neural banks are then frozen, and Xi_2 is identified by the
% same fixed-feature STLSQ/readout machinery used elsewhere. No backpropagation
% or joint nonconvex optimization is used.

if ~any(trainMask) || ~any(valMask)
    error('fit_pnc_sindy_module:EmptySplit', ...
        'Train and validation masks must both be nonempty.');
end
if ~isfield(opt,'physicsNeuralCompositional') || ...
        ~isstruct(opt.physicsNeuralCompositional)
    error('fit_pnc_sindy_module:Options', ...
        'physicsNeuralCompositional options are missing.');
end
pncOpt = opt.physicsNeuralCompositional;
required = {'includeLayer1BypassCandidate','includeFlatPNSkipCandidate', ...
    'compositionalSeedOffset'};
for k = 1:numel(required)
    if ~isfield(pncOpt,required{k})
        error('fit_pnc_sindy_module:Options', ...
            'physicsNeuralCompositional.%s is missing.',required{k});
    end
end

% ----------------------- PARENT 1: PE-SINDy -------------------------
[layer1,layer1Info] = fit_sindy_stlsq_module( ...
    data,trainMask,valMask,"physics",opt,"standard");

[Theta1,names1] = build_sindy_library( ...
    data.X,data.inputNames,data.deviceType,"physics",opt,layer1.librarySpec);
if numel(names1) ~= numel(layer1.libraryNames) || ...
        any(string(names1(:)) ~= string(layer1.libraryNames(:)))
    error('fit_pnc_sindy_module:Layer1LibraryOrder', ...
        'Rebuilt PE layer-1 library does not match the fitted layer-1 ordering.');
end
H = Theta1*layer1.coefficients;
if size(H,2) ~= size(data.Y,2) || any(~isfinite(H),'all')
    error('fit_pnc_sindy_module:Layer1Output', ...
        'Frozen PE layer produced an invalid intermediate representation.');
end

% --------------------- PARENT 2: FLAT PN-SINDy ---------------------
% Fit the former flat PN parent with the identical split, seed, dictionary,
% STLSQ thresholds, and shared support-ridge policy. This parent is used as an
% exact selectable skip candidate inside the second layer; it is not an extra
% source of data or prior knowledge.
optParent = opt;
optParent.verbose = false;
[shallowPN,shallowPNInfo] = fit_neural_sindy_stlsq_module( ...
    data,trainMask,valMask,"physics_neural",optParent,seed);

% ---------------------- LAYER 2: COMPOSITION -------------------------
Xtr = data.X(trainMask,:);
Xval = data.X(valMask,:);
Htr = H(trainMask,:);
Hval = H(valMask,:);
YtrRaw = data.Y(trainMask,:);
YvalRaw = data.Y(valMask,:);

[AtrRaw,names2,spec2] = build_pnc_sindy_second_layer_library( ...
    Xtr,Htr,data.inputNames,data.outputNames,data.deviceType,opt,seed,[], ...
    shallowPN.librarySpec);
[AvalRaw,names2Val] = build_pnc_sindy_second_layer_library( ...
    Xval,Hval,data.inputNames,data.outputNames,data.deviceType,opt,seed,spec2);
if numel(names2Val) ~= numel(names2) || ...
        any(string(names2Val(:)) ~= string(names2(:)))
    error('fit_pnc_sindy_module:Layer2LibraryOrder', ...
        'Training and validation PNC v2 layer-2 libraries have inconsistent ordering.');
end

% Verify that the stored PN-skip block is exactly the parent flat-PN library.
[ThetaPNtr,pnNamesTr] = build_neural_sindy_library( ...
    Xtr,data.inputNames,data.deviceType,"physics_neural",opt,seed,shallowPN.librarySpec);
idxPN = spec2.shallowPNColumnIndices(:);
if numel(idxPN) ~= size(ThetaPNtr,2) || ...
        any(string(spec2.shallowPNLibraryNames(:)) ~= string(pnNamesTr(:))) || ...
        norm(AtrRaw(:,idxPN)-ThetaPNtr,'fro') > ...
            1e-10*max(1,norm(ThetaPNtr,'fro'))
    error('fit_pnc_sindy_module:FlatPNSkipMismatch', ...
        'PNC shallow skip block is not identical to the fitted flat PN parent library.');
end

colScale = sqrt(mean(AtrRaw.^2,1));
colScale = max(colScale,opt.normalization.libraryScaleFloor);
yScale = std(YtrRaw,0,1);
yRms = sqrt(mean(YtrRaw.^2,1));
yScale = max(yScale,0.05*yRms);
yScale = max(yScale,opt.normalization.outputScaleFloor);

Atr = AtrRaw./colScale;
Aval = AvalRaw./colScale;
Btr = YtrRaw./yScale;
Bval = YvalRaw./yScale;

nOut = size(YtrRaw,2);
nLayer2 = size(AtrRaw,2);
peIdx = spec2.peBypassColumnIndices(:);
pnIdx = spec2.shallowPNColumnIndices(:);
compIdx = spec2.compositionalNeuralColumnIndices(:);
peMask = false(nLayer2,1); peMask(peIdx)=true;
pnMask = false(nLayer2,1); pnMask(pnIdx)=true;
compMask = false(nLayer2,1); compMask(compIdx)=true;

[supportRidgeApplied,supportRidgeConfigured,supportRidgePolicy] = ...
    should_apply_sindy_support_ridge(opt,data);
if supportRidgeApplied
    ridgeGrid = unique(double(opt.stlsq.supportRidge.relativeAlphaGrid(:).'),'stable');
else
    ridgeGrid = 0;
end
lambdas = unique(sort(opt.stlsq.thresholdGrid(:)),'stable');

resultTemplate = struct( ...
    'candidateType',"",'lambda',NaN,'supportRidgeRelativeAlpha',NaN, ...
    'trainNormalizedMSE',NaN,'validationNormalizedMSE',NaN, ...
    'activeCoefficientCount',NaN,'activePEBypassCoefficientCount',NaN, ...
    'activeShallowPNCoefficientCount',NaN, ...
    'activeCompositionalCoefficientCount',NaN, ...
    'normalizedCoefficientFroNorm',NaN,'supportMask',[],'XiNormalized',[]);
results = repmat(resultTemplate,0,1);

% ------------------------- EXACT PARENT CANDIDATES -------------------
% PE bypass: [I;0;0] reproduces H exactly.
if logical(pncOpt.includeLayer1BypassCandidate)
    Cpe = zeros(nLayer2,nOut);
    if numel(peIdx) ~= nOut
        error('fit_pnc_sindy_module:PEBypassWidth', ...
            'PE bypass width %d does not equal output count %d.',numel(peIdx),nOut);
    end
    Cpe(peIdx,:) = eye(nOut);
    XiPE = (Cpe.*colScale(:))./yScale;
    results(end+1,1) = make_result_local( ...
        "pe_bypass",NaN,0,XiPE,abs(Cpe)>0,Atr,Aval,Btr,Bval, ...
        peMask,pnMask,compMask); %#ok<AGROW>
end

% Flat-PN skip: insert the already fitted parent coefficients into the exact
% matching Theta_PN block. This candidate reproduces former PN-SINDy exactly.
if logical(pncOpt.includeFlatPNSkipCandidate)
    Cpn = zeros(nLayer2,nOut);
    if numel(pnIdx) ~= size(shallowPN.coefficients,1) || ...
            size(shallowPN.coefficients,2) ~= nOut
        error('fit_pnc_sindy_module:FlatPNSkipWidth', ...
            'Flat PN parent coefficient dimensions do not match the PNC skip block.');
    end
    Cpn(pnIdx,:) = shallowPN.coefficients;
    XiPN = (Cpn.*colScale(:))./yScale;
    results(end+1,1) = make_result_local( ...
        "flat_pn_skip",shallowPN.selectedThreshold, ...
        shallowPN.supportRidgeRelativeAlpha,XiPN,abs(Cpn)>0, ...
        Atr,Aval,Btr,Bval,peMask,pnMask,compMask); %#ok<AGROW>
end

% -------------------- FULL COMPOSITIONAL CANDIDATES ------------------
for il = 1:numel(lambdas)
    lambda = lambdas(il);
    XiSupport = sparsifyDynamics(Atr,Btr,lambda,size(Btr,2));
    supportMask = abs(XiSupport)>0;
    for ia = 1:numel(ridgeGrid)
        rho = ridgeGrid(ia);
        if supportRidgeApplied
            Xi = refit_stlsq_support_ridge(Atr,Btr,supportMask,rho);
        else
            Xi = XiSupport;
        end
        results(end+1,1) = make_result_local( ...
            "stlsq_compositional",lambda,rho,Xi,supportMask, ...
            Atr,Aval,Btr,Bval,peMask,pnMask,compMask); %#ok<AGROW>
    end
end

if isempty(results)
    error('fit_pnc_sindy_module:NoCandidates','No PNC v2 layer-2 candidate was generated.');
end

% ---------------------- NESTED DEPTH SELECTION -----------------------
% Find the ordinary validation near-best band. If either exact parent model
% (PE or flat PN) lies in that band, choose the better parent and do not add
% depth. The compositional path activates only when held-out validation shows
% a material improvement beyond BOTH parent models.
val = [results.validationNormalizedMSE].';
complexity = [results.activeCoefficientCount].';
bestVal = min(val);
tol = opt.stlsq.validationAbsoluteTolerance + ...
    opt.stlsq.preferSparseWithinRelativeValidationTolerance*max(bestVal,eps);
eligible = find(val <= bestVal + tol);
if isempty(eligible)
    [~,bestIdx] = min(val);
else
    parentType = string({results.candidateType}).';
    isParent = parentType=="pe_bypass" | parentType=="flat_pn_skip";
    eligibleParents = eligible(isParent(eligible));
    if ~isempty(eligibleParents)
        % Preserve predictive quality first. Only break effectively exact ties
        % by smaller active readout support, then prefer PE for determinism.
        pv = val(eligibleParents);
        bestParentVal = min(pv);
        exactTol = 100*eps(max(1,bestParentVal));
        p2 = eligibleParents(abs(pv-bestParentVal)<=exactTol);
        if numel(p2)>1
            pc = complexity(p2);
            minPc = min(pc);
            p2 = p2(abs(pc-minPc)<=100*eps(max(1,minPc)));
        end
        if numel(p2)>1
            t2 = string({results(p2).candidateType}).';
            loc = find(t2=="pe_bypass",1,'first');
            if ~isempty(loc), p2=p2(loc); else, p2=p2(1); end
        end
        bestIdx = p2(1);
    else
        compEligible = eligible(parentType(eligible)=="stlsq_compositional");
        if isempty(compEligible)
            [~,bestIdx] = min(val);
        else
            bestComplexity = min(complexity(compEligible));
            cTol = 100*eps(max(1,bestComplexity));
            candidates = compEligible(abs(complexity(compEligible)-bestComplexity)<=cTol);

            if supportRidgeApplied
                cVal = val(candidates);
                bestCandidateVal = min(cVal);
                ridgeValTol = opt.stlsq.validationAbsoluteTolerance + ...
                    opt.stlsq.supportRidge.tieRelativeValidationTolerance* ...
                    max(bestCandidateVal,eps);
                near = candidates(cVal <= bestCandidateVal + ridgeValTol);
                norms = [results(near).normalizedCoefficientFroNorm].';
                bestNorm = min(norms);
                nTol = 100*eps(max(1,bestNorm));
                near2 = near(abs(norms-bestNorm)<=nTol);
                if numel(near2)>1
                    [~,loc] = min(val(near2)); near2=near2(loc);
                end
                if numel(near2)>1
                    rho2 = [results(near2).supportRidgeRelativeAlpha].';
                    [~,loc] = min(rho2); near2=near2(loc);
                end
                bestIdx = near2(1);
            else
                [~,loc] = min(val(candidates));
                bestIdx = candidates(loc);
            end
        end
    end
end

best = results(bestIdx);
XiNorm = best.XiNormalized;
coef2 = (XiNorm./colScale(:)).*yScale;
active2 = logical(best.supportMask);
peMask2 = repmat(peMask,1,nOut);
pnMask2 = repmat(pnMask,1,nOut);
compMask2 = repmat(compMask,1,nOut);

module = struct();
module.type = 'modular_sindy_module';
module.formulationVersion = char(opt.formulationVersion);
module.dictionaryFamily = 'skip_compositional_fixed_neural_ridge';
module.variant = 'physics_neural_compositional';
module.fitMode = 'stagewise_frozen_two_layer_with_parent_skips';
module.architectureVersion = 'pnc_skip_composition_v2';
module.deviceType = char(data.deviceType);
module.deviceIndex = data.deviceIndex;
module.bus = data.bus;
module.stateIndices = data.stateIndices(:);
module.inputNames = string(data.inputNames(:));
module.outputNames = string(data.outputNames(:));

module.layer1 = layer1;
module.layer1Architecture = 'physics_embedded_sindy';
module.layer1Frozen = true;
module.layer1BypassCandidateIncluded = logical(pncOpt.includeLayer1BypassCandidate);
module.layer1SelectedThreshold = layer1.selectedThreshold;
module.layer1ActiveCoefficientCount = layer1.activeCoefficientCount;
module.layer1CandidateCoefficientCount = layer1.candidateCoefficientCount;
module.layer1ValidationNormalizedMSE = layer1Info.validationNormalizedMSE;

module.shallowPNParent = shallowPN;
module.shallowPNFrozen = true;
module.shallowPNSkipCandidateIncluded = logical(pncOpt.includeFlatPNSkipCandidate);
module.shallowPNValidationNormalizedMSE = shallowPNInfo.validationNormalizedMSE;
module.shallowPNSelectedThreshold = shallowPN.selectedThreshold;
module.shallowPNActiveCoefficientCount = shallowPN.activeCoefficientCount;
module.shallowPNCandidateCoefficientCount = shallowPN.candidateCoefficientCount;

module.libraryNames = string(names2(:));
module.librarySpec = spec2;
module.coefficients = coef2;
module.selectedCandidateType = char(best.candidateType);
module.nestedLayer1FallbackSelected = strcmp(best.candidateType,'pe_bypass'); % legacy alias
module.nestedShallowPNFallbackSelected = strcmp(best.candidateType,'flat_pn_skip');
module.nestedParentFallbackSelected = any(strcmp(best.candidateType,{'pe_bypass','flat_pn_skip'}));
module.selectedThreshold = best.lambda;
module.stlsqSolver = 'official_brunton_2015';
module.stlsqIterations = 10;
module.stlsqRidge = 0;
module.supportRidgeConfigured = supportRidgeConfigured;
module.supportRidgeApplied = supportRidgeApplied;
module.supportRidgeEnabled = supportRidgeApplied;
module.supportRidgeApplicationPolicy = char(supportRidgePolicy);
module.derivativeLabelProtocol = derivative_label_protocol_local(data);
module.supportRidgeRelativeAlpha = best.supportRidgeRelativeAlpha;
module.normalizedCoefficientFroNorm = best.normalizedCoefficientFroNorm;
module.libraryColumnScale = colScale(:);
module.outputScale = yScale(:);
module.activeCoefficientCount = nnz(active2);
module.candidateCoefficientCount = numel(coef2);
module.activePEBypassCoefficientCount = nnz(active2 & peMask2);
module.activeShallowPNCoefficientCount = nnz(active2 & pnMask2);
module.activeCompositionalCoefficientCount = nnz(active2 & compMask2);
module.activeBypassCoefficientCount = module.activePEBypassCoefficientCount; % legacy alias
module.activeNeuralCoefficientCount = module.activeCompositionalCoefficientCount; % legacy alias
module.neuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
module.shallowPNNeuralBasisFeatureCount = spec2.shallowPN.neural.retainedCount;
module.compositionalNeuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
module.totalFixedNeuralFeatureCount = spec2.totalFixedNeuralFeatureCount;
module.neuralBasisSeed = seed;
module.compositionalNeuralBasisSeed = spec2.compositionalBasisSeed;
module.compositionalSeedOffset = pncOpt.compositionalSeedOffset;
module.physicsPriorFeatureMask = false(size(coef2,1),1);
module.physicsPriorFeatureWeight = 1.0;
module.activePhysicsCoefficientCount = layer1.activePhysicsCoefficientCount;
module.activeGenericCoefficientCount = module.activeCoefficientCount;
module.trajectoryValidationEnabled = false;
module.validationTrajectoryNormalizedMSE = NaN;
module.onlineLayer2Updated = false;

candidateType = string({results.candidateType}).';
sweepTable = table(candidateType,[results.lambda].', ...
    [results.supportRidgeRelativeAlpha].', ...
    [results.trainNormalizedMSE].',[results.validationNormalizedMSE].', ...
    [results.activeCoefficientCount].',[results.activePEBypassCoefficientCount].', ...
    [results.activeShallowPNCoefficientCount].', ...
    [results.activeCompositionalCoefficientCount].', ...
    [results.normalizedCoefficientFroNorm].', ...
    'VariableNames',{'CandidateType','Threshold','SupportRidgeRelativeAlpha', ...
    'TrainNormalizedMSE','ValidationNormalizedMSE','ActiveCoefficientCount', ...
    'ActivePEBypassCoefficientCount','ActiveShallowPNCoefficientCount', ...
    'ActiveCompositionalCoefficientCount','NormalizedCoefficientFroNorm'});

info = struct();
info.formulationVersion = char(opt.formulationVersion);
info.architectureVersion = module.architectureVersion;
info.deviceType = char(data.deviceType);
info.deviceIndex = data.deviceIndex;
info.bus = data.bus;
info.nTrainSamples = nnz(trainMask);
info.nValidationSamples = nnz(valMask);
info.libraryTermCount = size(AtrRaw,2);
info.outputCount = nOut;
info.candidateCoefficientCount = numel(coef2);
info.activeCoefficientCount = module.activeCoefficientCount;
info.selectedCandidateType = module.selectedCandidateType;
info.nestedLayer1FallbackSelected = module.nestedLayer1FallbackSelected;
info.nestedShallowPNFallbackSelected = module.nestedShallowPNFallbackSelected;
info.nestedParentFallbackSelected = module.nestedParentFallbackSelected;
info.selectedThreshold = best.lambda;
info.stlsqSolver = 'official_brunton_2015';
info.stlsqIterations = 10;
info.stlsqRidge = 0;
info.supportRidgeConfigured = supportRidgeConfigured;
info.supportRidgeApplied = supportRidgeApplied;
info.supportRidgeEnabled = supportRidgeApplied;
info.supportRidgeApplicationPolicy = char(supportRidgePolicy);
info.derivativeLabelProtocol = derivative_label_protocol_local(data);
info.supportRidgeRelativeAlpha = best.supportRidgeRelativeAlpha;
info.normalizedCoefficientFroNorm = best.normalizedCoefficientFroNorm;
info.trainNormalizedMSE = best.trainNormalizedMSE;
info.validationNormalizedMSE = best.validationNormalizedMSE;
info.thresholdSweep = sweepTable;
info.fitMode = module.fitMode;
info.neuralBasisSeed = seed;
info.neuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
info.shallowPNNeuralBasisFeatureCount = spec2.shallowPN.neural.retainedCount;
info.compositionalNeuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
info.totalFixedNeuralFeatureCount = spec2.totalFixedNeuralFeatureCount;
info.neuralCandidatePoolCount = spec2.compositionalNeural.actualCandidateCount;
info.layer1LibraryTermCount = layer1Info.libraryTermCount;
info.layer1CandidateCoefficientCount = layer1Info.candidateCoefficientCount;
info.layer1ActiveCoefficientCount = layer1Info.activeCoefficientCount;
info.layer1SelectedThreshold = layer1Info.selectedThreshold;
info.layer1TrainNormalizedMSE = layer1Info.trainNormalizedMSE;
info.layer1ValidationNormalizedMSE = layer1Info.validationNormalizedMSE;
info.layer1SupportRidgeApplied = layer1Info.supportRidgeApplied;
info.layer1SupportRidgeRelativeAlpha = layer1Info.supportRidgeRelativeAlpha;
info.shallowPNLibraryTermCount = shallowPNInfo.libraryTermCount;
info.shallowPNCandidateCoefficientCount = shallowPNInfo.candidateCoefficientCount;
info.shallowPNActiveCoefficientCount = shallowPNInfo.activeCoefficientCount;
info.shallowPNSelectedThreshold = shallowPNInfo.selectedThreshold;
info.shallowPNTrainNormalizedMSE = shallowPNInfo.trainNormalizedMSE;
info.shallowPNValidationNormalizedMSE = shallowPNInfo.validationNormalizedMSE;
info.shallowPNSupportRidgeApplied = shallowPNInfo.supportRidgeApplied;
info.shallowPNSupportRidgeRelativeAlpha = shallowPNInfo.supportRidgeRelativeAlpha;
info.activePEBypassCoefficientCount = module.activePEBypassCoefficientCount;
info.activeShallowPNCoefficientCount = module.activeShallowPNCoefficientCount;
info.activeCompositionalCoefficientCount = module.activeCompositionalCoefficientCount;
info.activeBypassCoefficientCount = module.activeBypassCoefficientCount;
info.activeNeuralCoefficientCount = module.activeNeuralCoefficientCount;
info.totalActiveCoefficientCount = ...
    layer1Info.activeCoefficientCount + module.activeCoefficientCount;
info.totalCandidateCoefficientCount = ...
    layer1Info.candidateCoefficientCount + module.candidateCoefficientCount;
info.physicsPriorFeatureCount = layer1Info.physicsPriorFeatureCount;
info.activePhysicsCoefficientCount = layer1Info.activePhysicsCoefficientCount;
info.activeGenericCoefficientCount = module.activeCoefficientCount;
info.weightedActiveComplexity = module.activeCoefficientCount;
info.trajectoryValidationEnabled = false;
info.validationTrajectoryNormalizedMSE = NaN;

if opt.verbose
    fprintf(['      %s%d | PNC-SINDy v2 | PE parent val=%.3e | flat-PN parent val=%.3e | ', ...
        'L2=%d terms [PE=%d, PNskip=%d, comp=%d] | selected=%s | ', ...
        'lambda=%.3g | active=%d [PE=%d, PNskip=%d, comp=%d] | val nMSE=%.3e\n'], ...
        upper(char(data.deviceType)),data.deviceIndex, ...
        info.layer1ValidationNormalizedMSE,info.shallowPNValidationNormalizedMSE, ...
        info.libraryTermCount,numel(peIdx),numel(pnIdx),numel(compIdx), ...
        info.selectedCandidateType,info.selectedThreshold,info.activeCoefficientCount, ...
        info.activePEBypassCoefficientCount,info.activeShallowPNCoefficientCount, ...
        info.activeCompositionalCoefficientCount,info.validationNormalizedMSE);
    switch string(info.selectedCandidateType)
        case "pe_bypass"
            fprintf('      PNC depth guard: PE parent selected; PN skip/composition inactive.\n');
        case "flat_pn_skip"
            fprintf('      PNC depth guard: flat-PN parent selected; PE/composition bypassed at readout.\n');
        otherwise
            fprintf('      PNC depth guard: compositional readout activated; both parents were outside the near-best band.\n');
    end
    if info.supportRidgeApplied && ~info.nestedParentFallbackSelected
        fprintf('      PNC layer-2 support ridge rho=%.3g | normalized coefficient Fro norm=%.3e\n', ...
            info.supportRidgeRelativeAlpha,info.normalizedCoefficientFroNorm);
    end
end
end


function r = make_result_local(candidateType,lambda,rho,Xi,supportMask, ...
    Atr,Aval,Btr,Bval,peMask,pnMask,compMask)
trPred = Atr*Xi;
vaPred = Aval*Xi;
activeMask = logical(supportMask);
peMask2 = repmat(peMask,1,size(Xi,2));
pnMask2 = repmat(pnMask,1,size(Xi,2));
compMask2 = repmat(compMask,1,size(Xi,2));
r = struct();
r.candidateType = string(candidateType);
r.lambda = lambda;
r.supportRidgeRelativeAlpha = rho;
r.trainNormalizedMSE = mean((trPred-Btr).^2,'all');
r.validationNormalizedMSE = mean((vaPred-Bval).^2,'all');
r.activeCoefficientCount = nnz(activeMask);
r.activePEBypassCoefficientCount = nnz(activeMask & peMask2);
r.activeShallowPNCoefficientCount = nnz(activeMask & pnMask2);
r.activeCompositionalCoefficientCount = nnz(activeMask & compMask2);
r.normalizedCoefficientFroNorm = norm(Xi,'fro');
r.supportMask = activeMask;
r.XiNormalized = Xi;
end


function txt = derivative_label_protocol_local(data)
txt = 'unknown';
if isstruct(data) && isfield(data,'derivativeLabelProtocol') && ...
        strlength(string(data.derivativeLabelProtocol)) > 0
    txt = char(string(data.derivativeLabelProtocol));
end
end
