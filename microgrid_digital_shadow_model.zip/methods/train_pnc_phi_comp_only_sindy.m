function [model,info] = train_pnc_phi_comp_only_sindy(dataset,c,layout,cfg)
%TRAIN_PNC_PHI_COMP_ONLY_SINDY Strict Phi_comp-only diagnostic ablation.
%
%   H = f_PE_hat(chi)              (fit first, then freeze)
%   xdot_hat = Phi_comp(chi,H)*Xi_2
%
% No PE bypass and no flat-PN skip are available in the layer-2 readout.
[model,info] = train_modular_pnc_phi_comp_only_sindy(dataset,c,layout,cfg);
end
