function [module,info] = fit_pnc_residual_comp_module(data,trainMask,valMask,opt,seed)
%FIT_PNC_RESIDUAL_COMP_MODULE Fit PE + physics-conditioned residual composition.
%
% Stage 1: fit PE-SINDy and freeze Xi_1.
%   H = Theta_PE(chi) * Xi_1
%
% Stage 2: learn ONLY the unexplained residual using Phi_comp(chi,H).
%   R = xdot - H
%   R ~= Phi_comp(chi,H) * Xi_c
%
% Final model:
%   xdot_hat = H + Phi_comp(chi,H) * Xi_c
%
% The zero-correction candidate Xi_c=0 is always included exactly. Hence the
% PE-SINDy parent is a strict submodel and is selected whenever extra depth
% does not provide a material held-out validation improvement.

if ~any(trainMask) || ~any(valMask)
    error('fit_pnc_residual_comp_module:EmptySplit', ...
        'Train and validation masks must both be nonempty.');
end

% ----------------------- LAYER 1: PE-SINDy ---------------------------
[layer1,layer1Info] = fit_sindy_stlsq_module( ...
    data,trainMask,valMask,"physics",opt,"standard");
[Theta1,names1] = build_sindy_library( ...
    data.X,data.inputNames,data.deviceType,"physics",opt,layer1.librarySpec);
if numel(names1) ~= numel(layer1.libraryNames) || ...
        any(string(names1(:)) ~= string(layer1.libraryNames(:)))
    error('fit_pnc_residual_comp_module:Layer1LibraryOrder', ...
        'Rebuilt PE layer-1 library does not match the fitted ordering.');
end
H = Theta1*layer1.coefficients;
if size(H,2) ~= size(data.Y,2) || any(~isfinite(H),'all')
    error('fit_pnc_residual_comp_module:Layer1Output', ...
        'Frozen PE layer produced an invalid intermediate representation.');
end

% ------------------ LAYER 2: RESIDUAL COMPOSITION -------------------
Xtr = data.X(trainMask,:);
Xval = data.X(valMask,:);
Htr = H(trainMask,:);
Hval = H(valMask,:);
YtrRaw = data.Y(trainMask,:);
YvalRaw = data.Y(valMask,:);
RtrRaw = YtrRaw - Htr;
RvalRaw = YvalRaw - Hval;

[AtrRaw,names2,spec2] = build_pnc_residual_comp_library( ...
    Xtr,Htr,data.inputNames,data.outputNames,opt,seed,[]);
[AvalRaw,names2Val] = build_pnc_residual_comp_library( ...
    Xval,Hval,data.inputNames,data.outputNames,opt,seed,spec2);
if numel(names2Val) ~= numel(names2) || ...
        any(string(names2Val(:)) ~= string(names2(:)))
    error('fit_pnc_residual_comp_module:Layer2LibraryOrder', ...
        'Training and validation residual-composition libraries have inconsistent ordering.');
end

% Normalize the correction library by training-only feature RMS. Residual
% targets are normalized with the ORIGINAL xdot scale (not residual scale),
% so validation nMSE is directly comparable to the PE parent and other SINDy
% variants. This also avoids artificially inflating tiny residuals at large N.
colScale = sqrt(mean(AtrRaw.^2,1));
colScale = max(colScale,opt.normalization.libraryScaleFloor);
yScale = std(YtrRaw,0,1);
yRms = sqrt(mean(YtrRaw.^2,1));
yScale = max(yScale,0.05*yRms);
yScale = max(yScale,opt.normalization.outputScaleFloor);

Atr = AtrRaw./colScale;
Aval = AvalRaw./colScale;
Btr = RtrRaw./yScale;
Bval = RvalRaw./yScale;

[supportRidgeApplied,supportRidgeConfigured,supportRidgePolicy] = ...
    should_apply_sindy_support_ridge(opt,data);
if supportRidgeApplied
    ridgeGrid = unique(double(opt.stlsq.supportRidge.relativeAlphaGrid(:).'),'stable');
else
    ridgeGrid = 0;
end
lambdas = unique(sort(opt.stlsq.thresholdGrid(:)),'stable');

resultTemplate = struct('candidateType',"",'lambda',NaN, ...
    'supportRidgeRelativeAlpha',NaN,'trainNormalizedMSE',NaN, ...
    'validationNormalizedMSE',NaN,'activeCoefficientCount',NaN, ...
    'normalizedCoefficientFroNorm',NaN,'supportMask',[],'XiNormalized',[]);
results = repmat(resultTemplate,0,1);

% Exact PE parent / zero-correction candidate.
XiZero = zeros(size(Atr,2),size(Btr,2));
zeroSupport = false(size(XiZero));
results(end+1,1) = make_result_local( ...
    "pe_zero_correction",NaN,0,XiZero,zeroSupport,Atr,Aval,Btr,Bval); %#ok<AGROW>

% Residual-composition candidates use the same official STLSQ support
% discovery and the same support-preserving ridge policy as the other pointwise
% SINDy methods. The ridge step never changes support.
for il = 1:numel(lambdas)
    lambda = lambdas(il);
    XiSupport = sparsifyDynamics(Atr,Btr,lambda,size(Btr,2));
    supportMask = abs(XiSupport)>0;
    for ia = 1:numel(ridgeGrid)
        rho = ridgeGrid(ia);
        if supportRidgeApplied
            Xi = refit_stlsq_support_ridge(Atr,Btr,supportMask,rho);
        else
            Xi = XiSupport;
        end
        results(end+1,1) = make_result_local( ...
            "residual_composition_stlsq",lambda,rho,Xi,supportMask, ...
            Atr,Aval,Btr,Bval); %#ok<AGROW>
    end
end

% --------------------- NESTED DEPTH SELECTION ------------------------
% Use the ordinary validation near-best band. If Xi_c=0 is within the band,
% it wins automatically because it has zero added complexity. Extra depth is
% activated only when held-out validation improves materially over PE.
val = [results.validationNormalizedMSE].';
complexity = [results.activeCoefficientCount].';
bestVal = min(val);
tol = opt.stlsq.validationAbsoluteTolerance + ...
    opt.stlsq.preferSparseWithinRelativeValidationTolerance*max(bestVal,eps);
eligible = find(val <= bestVal + tol);
if isempty(eligible)
    [~,bestIdx] = min(val);
else
    bestComplexity = min(complexity(eligible));
    cTol = 100*eps(max(1,bestComplexity));
    candidates = eligible(abs(complexity(eligible)-bestComplexity)<=cTol);

    % If the zero-correction parent is tied/near-best, choose it deterministically.
    candidateTypes = string({results(candidates).candidateType}).';
    iz = find(candidateTypes=="pe_zero_correction",1,'first');
    if ~isempty(iz)
        bestIdx = candidates(iz);
    elseif supportRidgeApplied
        cVal = val(candidates);
        bestCandidateVal = min(cVal);
        ridgeValTol = opt.stlsq.validationAbsoluteTolerance + ...
            opt.stlsq.supportRidge.tieRelativeValidationTolerance* ...
            max(bestCandidateVal,eps);
        near = candidates(cVal <= bestCandidateVal + ridgeValTol);
        norms = [results(near).normalizedCoefficientFroNorm].';
        bestNorm = min(norms);
        nTol = 100*eps(max(1,bestNorm));
        near2 = near(abs(norms-bestNorm)<=nTol);
        if numel(near2)>1
            [~,loc] = min(val(near2)); near2 = near2(loc);
        end
        if numel(near2)>1
            rho2 = [results(near2).supportRidgeRelativeAlpha].';
            [~,loc] = min(rho2); near2 = near2(loc);
        end
        bestIdx = near2(1);
    else
        [~,loc] = min(val(candidates));
        bestIdx = candidates(loc);
    end
end

best = results(bestIdx);
coef2 = (best.XiNormalized./colScale(:)).*yScale;
active2 = logical(best.supportMask);

module = struct();
module.type = 'modular_sindy_module';
module.formulationVersion = char(opt.formulationVersion);
module.dictionaryFamily = 'physics_conditioned_residual_fixed_neural_ridge';
module.variant = 'pnc_residual_comp';
module.fitMode = 'stagewise_frozen_pe_plus_residual_composition';
module.architectureVersion = 'pnc_residual_comp_v1';
module.deviceType = char(data.deviceType);
module.deviceIndex = data.deviceIndex;
module.bus = data.bus;
module.stateIndices = data.stateIndices(:);
module.inputNames = string(data.inputNames(:));
module.outputNames = string(data.outputNames(:));
module.layer1 = layer1;
module.layer1Architecture = 'physics_embedded_sindy';
module.layer1Frozen = true;
module.layer1SelectedThreshold = layer1.selectedThreshold;
module.layer1ActiveCoefficientCount = layer1.activeCoefficientCount;
module.layer1CandidateCoefficientCount = layer1.candidateCoefficientCount;
module.layer1ValidationNormalizedMSE = layer1Info.validationNormalizedMSE;
module.libraryNames = string(names2(:));
module.librarySpec = spec2;
module.coefficients = coef2;
module.selectedCandidateType = char(best.candidateType);
module.zeroCorrectionSelected = strcmp(best.candidateType,'pe_zero_correction');
module.selectedThreshold = best.lambda;
module.stlsqSolver = 'official_brunton_2015';
module.stlsqIterations = 10;
module.stlsqRidge = 0;
module.supportRidgeConfigured = supportRidgeConfigured;
module.supportRidgeApplied = supportRidgeApplied;
module.supportRidgeEnabled = supportRidgeApplied;
module.supportRidgeApplicationPolicy = char(supportRidgePolicy);
module.derivativeLabelProtocol = derivative_label_protocol_local(data);
module.supportRidgeRelativeAlpha = best.supportRidgeRelativeAlpha;
module.normalizedCoefficientFroNorm = best.normalizedCoefficientFroNorm;
module.libraryColumnScale = colScale(:);
module.outputScale = yScale(:);
module.activeCoefficientCount = nnz(active2);
module.candidateCoefficientCount = numel(coef2);
module.activePEBypassCoefficientCount = 0;
module.activeShallowPNCoefficientCount = 0;
module.activeCompositionalCoefficientCount = nnz(active2);
module.activeBypassCoefficientCount = 0;
module.activeNeuralCoefficientCount = nnz(active2);
module.physicsPriorFeatureMask = false(size(coef2,1),1);
module.physicsPriorFeatureWeight = 1.0;
module.activePhysicsCoefficientCount = layer1.activePhysicsCoefficientCount;
module.activeGenericCoefficientCount = module.activeCoefficientCount;
module.neuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
module.compositionalNeuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
module.totalFixedNeuralFeatureCount = spec2.compositionalNeural.retainedCount;
module.neuralBasisSeed = seed;
module.compositionalNeuralBasisSeed = spec2.compositionalBasisSeed;
module.compositionalSeedOffset = opt.physicsNeuralCompositional.compositionalSeedOffset;
module.trajectoryValidationEnabled = false;
module.validationTrajectoryNormalizedMSE = NaN;
module.onlineLayer2Updated = false;

candidateType = string({results.candidateType}).';
sweepTable = table(candidateType,[results.lambda].', ...
    [results.supportRidgeRelativeAlpha].',[results.trainNormalizedMSE].', ...
    [results.validationNormalizedMSE].',[results.activeCoefficientCount].', ...
    [results.normalizedCoefficientFroNorm].', ...
    'VariableNames',{'CandidateType','Threshold','SupportRidgeRelativeAlpha', ...
    'TrainNormalizedMSE','ValidationNormalizedMSE','ActiveCoefficientCount', ...
    'NormalizedCoefficientFroNorm'});

info = struct();
info.formulationVersion = char(opt.formulationVersion);
info.architectureVersion = module.architectureVersion;
info.deviceType = char(data.deviceType);
info.deviceIndex = data.deviceIndex;
info.bus = data.bus;
info.nTrainSamples = nnz(trainMask);
info.nValidationSamples = nnz(valMask);
info.libraryTermCount = size(AtrRaw,2);
info.outputCount = size(YtrRaw,2);
info.candidateCoefficientCount = numel(coef2);
info.activeCoefficientCount = module.activeCoefficientCount;
info.selectedCandidateType = module.selectedCandidateType;
info.zeroCorrectionSelected = module.zeroCorrectionSelected;
info.selectedThreshold = best.lambda;
info.stlsqSolver = module.stlsqSolver;
info.stlsqIterations = module.stlsqIterations;
info.stlsqRidge = 0;
info.supportRidgeConfigured = supportRidgeConfigured;
info.supportRidgeApplied = supportRidgeApplied;
info.supportRidgeEnabled = supportRidgeApplied;
info.supportRidgeApplicationPolicy = char(supportRidgePolicy);
info.derivativeLabelProtocol = module.derivativeLabelProtocol;
info.supportRidgeRelativeAlpha = best.supportRidgeRelativeAlpha;
info.normalizedCoefficientFroNorm = best.normalizedCoefficientFroNorm;
info.trainNormalizedMSE = best.trainNormalizedMSE;
info.validationNormalizedMSE = best.validationNormalizedMSE;
info.thresholdSweep = sweepTable;
info.fitMode = module.fitMode;
info.neuralBasisSeed = seed;
info.neuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
info.compositionalNeuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
info.totalFixedNeuralFeatureCount = spec2.compositionalNeural.retainedCount;
info.neuralCandidatePoolCount = spec2.compositionalNeural.actualCandidateCount;
info.layer1LibraryTermCount = layer1Info.libraryTermCount;
info.layer1CandidateCoefficientCount = layer1Info.candidateCoefficientCount;
info.layer1ActiveCoefficientCount = layer1Info.activeCoefficientCount;
info.layer1SelectedThreshold = layer1Info.selectedThreshold;
info.layer1TrainNormalizedMSE = layer1Info.trainNormalizedMSE;
info.layer1ValidationNormalizedMSE = layer1Info.validationNormalizedMSE;
info.layer1SupportRidgeApplied = layer1Info.supportRidgeApplied;
info.layer1SupportRidgeRelativeAlpha = layer1Info.supportRidgeRelativeAlpha;
info.activePEBypassCoefficientCount = 0;
info.activeShallowPNCoefficientCount = 0;
info.activeCompositionalCoefficientCount = module.activeCompositionalCoefficientCount;
info.activeBypassCoefficientCount = 0;
info.activeNeuralCoefficientCount = module.activeNeuralCoefficientCount;
info.totalActiveCoefficientCount = ...
    layer1Info.activeCoefficientCount + module.activeCoefficientCount;
info.totalCandidateCoefficientCount = ...
    layer1Info.candidateCoefficientCount + module.candidateCoefficientCount;
info.physicsPriorFeatureCount = layer1Info.physicsPriorFeatureCount;
info.activePhysicsCoefficientCount = layer1Info.activePhysicsCoefficientCount;
info.activeGenericCoefficientCount = module.activeCoefficientCount;
info.weightedActiveComplexity = module.activeCoefficientCount;
info.trajectoryValidationEnabled = false;
info.validationTrajectoryNormalizedMSE = NaN;

if opt.verbose
    fprintf(['      %s%d | PNC-ResidualComp | PE val=%.3e | Phi_comp=%d terms | ', ...
        'selected=%s | lambda=%.3g | active comp=%d | val nMSE=%.3e\n'], ...
        upper(char(data.deviceType)),data.deviceIndex, ...
        info.layer1ValidationNormalizedMSE,info.libraryTermCount, ...
        info.selectedCandidateType,info.selectedThreshold, ...
        info.activeCompositionalCoefficientCount,info.validationNormalizedMSE);
    if info.zeroCorrectionSelected
        fprintf('      Residual depth guard: zero correction selected; exact PE parent retained.\n');
    else
        fprintf('      Residual depth guard: Phi_comp correction activated by held-out validation.\n');
        if info.supportRidgeApplied
            fprintf('      Residual-composition support ridge rho=%.3g | normalized coefficient Fro norm=%.3e\n', ...
                info.supportRidgeRelativeAlpha,info.normalizedCoefficientFroNorm);
        end
    end
end
end

function r = make_result_local(candidateType,lambda,rho,Xi,supportMask, ...
    Atr,Aval,Btr,Bval)
trResidualPred = Atr*Xi;
vaResidualPred = Aval*Xi;
r = struct();
r.candidateType = string(candidateType);
r.lambda = lambda;
r.supportRidgeRelativeAlpha = rho;
r.trainNormalizedMSE = mean((trResidualPred-Btr).^2,'all');
r.validationNormalizedMSE = mean((vaResidualPred-Bval).^2,'all');
r.activeCoefficientCount = nnz(supportMask);
r.normalizedCoefficientFroNorm = norm(Xi,'fro');
r.supportMask = logical(supportMask);
r.XiNormalized = Xi;
end

function txt = derivative_label_protocol_local(data)
txt = 'unknown';
if isstruct(data) && isfield(data,'derivativeLabelProtocol') && ...
        strlength(string(data.derivativeLabelProtocol)) > 0
    txt = char(string(data.derivativeLabelProtocol));
end
end
