function [model,info] = train_prior_weighted_neural_sindy(dataset,c,layout,cfg)
%TRAIN_PRIOR_WEIGHTED_NEURAL_SINDY Compact neural dictionary + weighted physics priors.
[model,info] = train_modular_neural_sindy(dataset,c,layout,cfg,'prior_weighted_neural');
end
