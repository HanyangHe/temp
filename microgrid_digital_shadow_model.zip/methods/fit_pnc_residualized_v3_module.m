function [module,info] = fit_pnc_residualized_v3_module(data,trainMask,valMask,opt,seed)
%FIT_PNC_RESIDUALIZED_V3_MODULE Diagnostic residualized PNC-SINDy v3 module.
%
% Stage 1 (physics backbone):
%   H = Theta_PE(chi) * Xi_1
%
% Parent 2 (flat PN):
%   f_PN(chi) = Theta_PN(chi) * Xi_PN
%
% Residualized layer-2 dictionary:
%   Theta_delta = [H, Theta_PN(chi), Phi_comp(chi,H)]
%   R           = xdot - H
%   R_hat       = Theta_delta * DeltaXi_2
%
% Final model:
%   xdot_hat = H + R_hat
%
% The candidate pool contains two exact nested parents:
%   PE: DeltaXi_2 = 0
%   PN: DeltaXi_H = -I, DeltaXi_PN = Xi_PN, DeltaXi_comp = 0
% plus ordinary STLSQ candidates on the full residual dictionary. Thus both
% PE-SINDy and flat PN-SINDy are exact submodels of this diagnostic v3 form.
%
% Xi_1 and both neural feature banks are frozen before layer-2 fitting. Every
% layer-2 candidate is therefore a fixed-feature sparse linear regression; no
% backpropagation or joint nonlinear optimization is used.

if ~any(trainMask) || ~any(valMask)
    error('fit_pnc_residualized_v3_module:EmptySplit', ...
        'Train and validation masks must both be nonempty.');
end
if ~isfield(opt,'physicsNeuralCompositional') || ...
        ~isstruct(opt.physicsNeuralCompositional) || ...
        ~isfield(opt.physicsNeuralCompositional,'compositionalSeedOffset')
    error('fit_pnc_residualized_v3_module:Options', ...
        'physicsNeuralCompositional.compositionalSeedOffset is missing.');
end

% ----------------------- PARENT 1: PE-SINDy -------------------------
[layer1,layer1Info] = fit_sindy_stlsq_module( ...
    data,trainMask,valMask,"physics",opt,"standard");
[Theta1,names1] = build_sindy_library( ...
    data.X,data.inputNames,data.deviceType,"physics",opt,layer1.librarySpec);
if numel(names1) ~= numel(layer1.libraryNames) || ...
        any(string(names1(:)) ~= string(layer1.libraryNames(:)))
    error('fit_pnc_residualized_v3_module:Layer1LibraryOrder', ...
        'Rebuilt PE layer-1 library does not match the fitted ordering.');
end
H = Theta1*layer1.coefficients;
if size(H,2) ~= size(data.Y,2) || any(~isfinite(H),'all')
    error('fit_pnc_residualized_v3_module:Layer1Output', ...
        'Frozen PE layer produced an invalid intermediate representation.');
end

% --------------------- PARENT 2: FLAT PN-SINDy ---------------------
% Use the identical split, seed, numerical policy, and flat-PN dictionary so
% the explicit PN residual candidate below reproduces the existing baseline.
optParent = opt;
optParent.verbose = false;
[shallowPN,shallowPNInfo] = fit_neural_sindy_stlsq_module( ...
    data,trainMask,valMask,"physics_neural",optParent,seed);

% ------------------ LAYER 2: RESIDUALIZED PNC -----------------------
Xtr = data.X(trainMask,:);
Xval = data.X(valMask,:);
Htr = H(trainMask,:);
Hval = H(valMask,:);
YtrRaw = data.Y(trainMask,:);
YvalRaw = data.Y(valMask,:);
RtrRaw = YtrRaw - Htr;
RvalRaw = YvalRaw - Hval;

[AtrRaw,names2,spec2] = build_pnc_sindy_second_layer_library( ...
    Xtr,Htr,data.inputNames,data.outputNames,data.deviceType,opt,seed,[], ...
    shallowPN.librarySpec);
[AvalRaw,names2Val] = build_pnc_sindy_second_layer_library( ...
    Xval,Hval,data.inputNames,data.outputNames,data.deviceType,opt,seed,spec2);
if numel(names2Val) ~= numel(names2) || ...
        any(string(names2Val(:)) ~= string(names2(:)))
    error('fit_pnc_residualized_v3_module:Layer2LibraryOrder', ...
        'Training and validation residualized PNC libraries have inconsistent ordering.');
end

% Verify the PN-skip block is exactly the already fitted flat-PN library.
[ThetaPNtr,pnNamesTr] = build_neural_sindy_library( ...
    Xtr,data.inputNames,data.deviceType,"physics_neural",opt,seed,shallowPN.librarySpec);
pnIdx = spec2.shallowPNColumnIndices(:);
if numel(pnIdx) ~= size(ThetaPNtr,2) || ...
        any(string(spec2.shallowPNLibraryNames(:)) ~= string(pnNamesTr(:))) || ...
        norm(AtrRaw(:,pnIdx)-ThetaPNtr,'fro') > 1e-10*max(1,norm(ThetaPNtr,'fro'))
    error('fit_pnc_residualized_v3_module:FlatPNSkipMismatch', ...
        'Residualized PNC PN block is not identical to the fitted flat-PN parent.');
end

% Training-only normalization. Residual targets use the ORIGINAL xdot scale,
% not the residual scale, so candidate validation nMSE is directly comparable
% to the PE and flat-PN parent validation errors.
colScale = sqrt(mean(AtrRaw.^2,1));
colScale = max(colScale,opt.normalization.libraryScaleFloor);
yScale = std(YtrRaw,0,1);
yRms = sqrt(mean(YtrRaw.^2,1));
yScale = max(yScale,0.05*yRms);
yScale = max(yScale,opt.normalization.outputScaleFloor);

Atr = AtrRaw./colScale;
Aval = AvalRaw./colScale;
Btr = RtrRaw./yScale;
Bval = RvalRaw./yScale;

nOut = size(YtrRaw,2);
nLayer2 = size(AtrRaw,2);
peIdx = spec2.peBypassColumnIndices(:);
compIdx = spec2.compositionalNeuralColumnIndices(:);
if numel(peIdx) ~= nOut
    error('fit_pnc_residualized_v3_module:PEBlockWidth', ...
        'PE correction block width %d does not equal output count %d.',numel(peIdx),nOut);
end
peMask = false(nLayer2,1); peMask(peIdx)=true;
pnMask = false(nLayer2,1); pnMask(pnIdx)=true;
compMask = false(nLayer2,1); compMask(compIdx)=true;

[supportRidgeApplied,supportRidgeConfigured,supportRidgePolicy] = ...
    should_apply_sindy_support_ridge(opt,data);
if supportRidgeApplied
    ridgeGrid = unique(double(opt.stlsq.supportRidge.relativeAlphaGrid(:).'),'stable');
else
    ridgeGrid = 0;
end
lambdas = unique(sort(opt.stlsq.thresholdGrid(:)),'stable');

resultTemplate = struct( ...
    'candidateType',"",'lambda',NaN,'supportRidgeRelativeAlpha',NaN, ...
    'trainNormalizedMSE',NaN,'validationNormalizedMSE',NaN, ...
    'activeCoefficientCount',NaN,'activePECorrectionCoefficientCount',NaN, ...
    'activeShallowPNCoefficientCount',NaN, ...
    'activeCompositionalCoefficientCount',NaN, ...
    'normalizedCoefficientFroNorm',NaN,'supportMask',[],'XiNormalized',[]);
results = repmat(resultTemplate,0,1);

% ------------------------- EXACT PE PARENT ---------------------------
% DeltaXi_2 = 0 => xdot_hat = H exactly.
Cpe = zeros(nLayer2,nOut);
XiPE = (Cpe.*colScale(:))./yScale;
results(end+1,1) = make_result_local( ...
    "pe_zero_correction",NaN,0,XiPE,false(size(Cpe)), ...
    Atr,Aval,Btr,Bval,peMask,pnMask,compMask); %#ok<AGROW>

% ------------------------- EXACT PN PARENT ---------------------------
% H + [-H + Theta_PN*Xi_PN] = f_PN exactly.
Cpn = zeros(nLayer2,nOut);
Cpn(peIdx,:) = -eye(nOut);
if numel(pnIdx) ~= size(shallowPN.coefficients,1) || ...
        size(shallowPN.coefficients,2) ~= nOut
    error('fit_pnc_residualized_v3_module:FlatPNCoefficientSize', ...
        'Flat-PN parent coefficients do not match the embedded PN residual block.');
end
Cpn(pnIdx,:) = shallowPN.coefficients;
XiPN = (Cpn.*colScale(:))./yScale;
results(end+1,1) = make_result_local( ...
    "flat_pn_exact_residual",shallowPN.selectedThreshold, ...
    shallowPN.supportRidgeRelativeAlpha,XiPN,abs(Cpn)>0, ...
    Atr,Aval,Btr,Bval,peMask,pnMask,compMask); %#ok<AGROW>

% ------------------- FULL RESIDUALIZED CANDIDATES --------------------
for il = 1:numel(lambdas)
    lambda = lambdas(il);
    XiSupport = sparsifyDynamics(Atr,Btr,lambda,size(Btr,2));
    supportMask = abs(XiSupport)>0;
    for ia = 1:numel(ridgeGrid)
        rho = ridgeGrid(ia);
        if supportRidgeApplied
            Xi = refit_stlsq_support_ridge(Atr,Btr,supportMask,rho);
        else
            Xi = XiSupport;
        end
        results(end+1,1) = make_result_local( ...
            "residualized_pnc_stlsq",lambda,rho,Xi,supportMask, ...
            Atr,Aval,Btr,Bval,peMask,pnMask,compMask); %#ok<AGROW>
    end
end

% ---------------------- NESTED MODEL SELECTION -----------------------
% Apply the same held-out validation near-best rule used elsewhere. If either
% exact parent lies in the near-best band, retain the better parent. Full v3
% depth is activated only when it materially improves beyond BOTH parents.
val = [results.validationNormalizedMSE].';
complexity = [results.activeCoefficientCount].';
bestVal = min(val);
tol = opt.stlsq.validationAbsoluteTolerance + ...
    opt.stlsq.preferSparseWithinRelativeValidationTolerance*max(bestVal,eps);
eligible = find(val <= bestVal + tol);
if isempty(eligible)
    [~,bestIdx] = min(val);
else
    types = string({results.candidateType}).';
    isParent = types=="pe_zero_correction" | types=="flat_pn_exact_residual";
    eligibleParents = eligible(isParent(eligible));
    if ~isempty(eligibleParents)
        pv = val(eligibleParents);
        bestParentVal = min(pv);
        exactTol = 100*eps(max(1,bestParentVal));
        p2 = eligibleParents(abs(pv-bestParentVal)<=exactTol);
        if numel(p2)>1
            pc = complexity(p2);
            minPc = min(pc);
            p2 = p2(abs(pc-minPc)<=100*eps(max(1,minPc)));
        end
        if numel(p2)>1
            t2 = types(p2);
            loc = find(t2=="pe_zero_correction",1,'first');
            if ~isempty(loc), p2=p2(loc); else, p2=p2(1); end
        end
        bestIdx = p2(1);
    else
        fullEligible = eligible(types(eligible)=="residualized_pnc_stlsq");
        if isempty(fullEligible)
            [~,bestIdx] = min(val);
        else
            bestComplexity = min(complexity(fullEligible));
            cTol = 100*eps(max(1,bestComplexity));
            candidates = fullEligible(abs(complexity(fullEligible)-bestComplexity)<=cTol);
            if supportRidgeApplied
                cVal = val(candidates);
                bestCandidateVal = min(cVal);
                ridgeValTol = opt.stlsq.validationAbsoluteTolerance + ...
                    opt.stlsq.supportRidge.tieRelativeValidationTolerance* ...
                    max(bestCandidateVal,eps);
                near = candidates(cVal <= bestCandidateVal + ridgeValTol);
                norms = [results(near).normalizedCoefficientFroNorm].';
                bestNorm = min(norms);
                nTol = 100*eps(max(1,bestNorm));
                near2 = near(abs(norms-bestNorm)<=nTol);
                if numel(near2)>1
                    [~,loc] = min(val(near2)); near2=near2(loc);
                end
                if numel(near2)>1
                    rho2 = [results(near2).supportRidgeRelativeAlpha].';
                    [~,loc] = min(rho2); near2=near2(loc);
                end
                bestIdx = near2(1);
            else
                [~,loc] = min(val(candidates));
                bestIdx = candidates(loc);
            end
        end
    end
end

best = results(bestIdx);
coef2 = (best.XiNormalized./colScale(:)).*yScale;
active2 = logical(best.supportMask);
peMask2 = repmat(peMask,1,nOut);
pnMask2 = repmat(pnMask,1,nOut);
compMask2 = repmat(compMask,1,nOut);

module = struct();
module.type = 'modular_sindy_module';
module.formulationVersion = char(opt.formulationVersion);
module.dictionaryFamily = 'residualized_pe_flatpn_composition_fixed_neural_ridge';
module.variant = 'pnc_residualized_v3';
module.fitMode = 'stagewise_frozen_pe_plus_residualized_parent_skip_composition';
module.architectureVersion = 'pnc_residualized_skip_composition_v3';
module.deviceType = char(data.deviceType);
module.deviceIndex = data.deviceIndex;
module.bus = data.bus;
module.stateIndices = data.stateIndices(:);
module.inputNames = string(data.inputNames(:));
module.outputNames = string(data.outputNames(:));

module.layer1 = layer1;
module.layer1Architecture = 'physics_embedded_sindy';
module.layer1Frozen = true;
module.layer1SelectedThreshold = layer1.selectedThreshold;
module.layer1ActiveCoefficientCount = layer1.activeCoefficientCount;
module.layer1CandidateCoefficientCount = layer1.candidateCoefficientCount;
module.layer1ValidationNormalizedMSE = layer1Info.validationNormalizedMSE;

module.shallowPNParent = shallowPN;
module.shallowPNFrozen = true;
module.shallowPNValidationNormalizedMSE = shallowPNInfo.validationNormalizedMSE;
module.shallowPNSelectedThreshold = shallowPN.selectedThreshold;
module.shallowPNActiveCoefficientCount = shallowPN.activeCoefficientCount;
module.shallowPNCandidateCoefficientCount = shallowPN.candidateCoefficientCount;

module.libraryNames = string(names2(:));
module.librarySpec = spec2;
module.coefficients = coef2;
module.selectedCandidateType = char(best.candidateType);
module.peParentSelected = strcmp(best.candidateType,'pe_zero_correction');
module.flatPNParentSelected = strcmp(best.candidateType,'flat_pn_exact_residual');
module.fullResidualizedPNCSelected = strcmp(best.candidateType,'residualized_pnc_stlsq');
module.selectedThreshold = best.lambda;
module.stlsqSolver = 'official_brunton_2015';
module.stlsqIterations = 10;
module.stlsqRidge = 0;
module.supportRidgeConfigured = supportRidgeConfigured;
module.supportRidgeApplied = supportRidgeApplied;
module.supportRidgeEnabled = supportRidgeApplied;
module.supportRidgeApplicationPolicy = char(supportRidgePolicy);
module.derivativeLabelProtocol = derivative_label_protocol_local(data);
module.supportRidgeRelativeAlpha = best.supportRidgeRelativeAlpha;
module.normalizedCoefficientFroNorm = best.normalizedCoefficientFroNorm;
module.libraryColumnScale = colScale(:);
module.outputScale = yScale(:);
module.activeCoefficientCount = nnz(active2);
module.candidateCoefficientCount = numel(coef2);
module.activePECorrectionCoefficientCount = nnz(active2 & peMask2);
module.activeShallowPNCoefficientCount = nnz(active2 & pnMask2);
module.activeCompositionalCoefficientCount = nnz(active2 & compMask2);
module.activePEBypassCoefficientCount = module.activePECorrectionCoefficientCount;
module.activeBypassCoefficientCount = module.activePECorrectionCoefficientCount;
module.activeNeuralCoefficientCount = module.activeCompositionalCoefficientCount;
module.neuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
module.shallowPNNeuralBasisFeatureCount = spec2.shallowPN.neural.retainedCount;
module.compositionalNeuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
module.totalFixedNeuralFeatureCount = spec2.totalFixedNeuralFeatureCount;
module.neuralBasisSeed = seed;
module.compositionalNeuralBasisSeed = spec2.compositionalBasisSeed;
module.compositionalSeedOffset = opt.physicsNeuralCompositional.compositionalSeedOffset;
module.physicsPriorFeatureMask = false(size(coef2,1),1);
module.physicsPriorFeatureWeight = 1.0;
module.activePhysicsCoefficientCount = layer1.activePhysicsCoefficientCount;
module.activeGenericCoefficientCount = module.activeCoefficientCount;
module.trajectoryValidationEnabled = false;
module.validationTrajectoryNormalizedMSE = NaN;
module.onlineLayer2Updated = false;

candidateType = string({results.candidateType}).';
sweepTable = table(candidateType,[results.lambda].', ...
    [results.supportRidgeRelativeAlpha].', ...
    [results.trainNormalizedMSE].',[results.validationNormalizedMSE].', ...
    [results.activeCoefficientCount].', ...
    [results.activePECorrectionCoefficientCount].', ...
    [results.activeShallowPNCoefficientCount].', ...
    [results.activeCompositionalCoefficientCount].', ...
    [results.normalizedCoefficientFroNorm].', ...
    'VariableNames',{'CandidateType','Threshold','SupportRidgeRelativeAlpha', ...
    'TrainNormalizedMSE','ValidationNormalizedMSE','ActiveCoefficientCount', ...
    'ActivePECorrectionCoefficientCount','ActiveShallowPNCoefficientCount', ...
    'ActiveCompositionalCoefficientCount','NormalizedCoefficientFroNorm'});

info = struct();
info.formulationVersion = char(opt.formulationVersion);
info.architectureVersion = module.architectureVersion;
info.deviceType = char(data.deviceType);
info.deviceIndex = data.deviceIndex;
info.bus = data.bus;
info.nTrainSamples = nnz(trainMask);
info.nValidationSamples = nnz(valMask);
info.libraryTermCount = size(AtrRaw,2);
info.outputCount = nOut;
info.candidateCoefficientCount = numel(coef2);
info.activeCoefficientCount = module.activeCoefficientCount;
info.selectedCandidateType = module.selectedCandidateType;
info.peParentSelected = module.peParentSelected;
info.flatPNParentSelected = module.flatPNParentSelected;
info.fullResidualizedPNCSelected = module.fullResidualizedPNCSelected;
info.selectedThreshold = best.lambda;
info.stlsqSolver = module.stlsqSolver;
info.stlsqIterations = module.stlsqIterations;
info.stlsqRidge = 0;
info.supportRidgeConfigured = supportRidgeConfigured;
info.supportRidgeApplied = supportRidgeApplied;
info.supportRidgeEnabled = supportRidgeApplied;
info.supportRidgeApplicationPolicy = char(supportRidgePolicy);
info.derivativeLabelProtocol = module.derivativeLabelProtocol;
info.supportRidgeRelativeAlpha = best.supportRidgeRelativeAlpha;
info.normalizedCoefficientFroNorm = best.normalizedCoefficientFroNorm;
info.trainNormalizedMSE = best.trainNormalizedMSE;
info.validationNormalizedMSE = best.validationNormalizedMSE;
info.thresholdSweep = sweepTable;
info.fitMode = module.fitMode;
info.neuralBasisSeed = seed;
info.neuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
info.shallowPNNeuralBasisFeatureCount = spec2.shallowPN.neural.retainedCount;
info.compositionalNeuralBasisFeatureCount = spec2.compositionalNeural.retainedCount;
info.totalFixedNeuralFeatureCount = spec2.totalFixedNeuralFeatureCount;
info.neuralCandidatePoolCount = spec2.compositionalNeural.actualCandidateCount;

info.layer1LibraryTermCount = layer1Info.libraryTermCount;
info.layer1CandidateCoefficientCount = layer1Info.candidateCoefficientCount;
info.layer1ActiveCoefficientCount = layer1Info.activeCoefficientCount;
info.layer1SelectedThreshold = layer1Info.selectedThreshold;
info.layer1TrainNormalizedMSE = layer1Info.trainNormalizedMSE;
info.layer1ValidationNormalizedMSE = layer1Info.validationNormalizedMSE;
info.layer1SupportRidgeApplied = layer1Info.supportRidgeApplied;
info.layer1SupportRidgeRelativeAlpha = layer1Info.supportRidgeRelativeAlpha;

info.shallowPNLibraryTermCount = shallowPNInfo.libraryTermCount;
info.shallowPNCandidateCoefficientCount = shallowPNInfo.candidateCoefficientCount;
info.shallowPNActiveCoefficientCount = shallowPNInfo.activeCoefficientCount;
info.shallowPNSelectedThreshold = shallowPNInfo.selectedThreshold;
info.shallowPNTrainNormalizedMSE = shallowPNInfo.trainNormalizedMSE;
info.shallowPNValidationNormalizedMSE = shallowPNInfo.validationNormalizedMSE;
info.shallowPNSupportRidgeApplied = shallowPNInfo.supportRidgeApplied;
info.shallowPNSupportRidgeRelativeAlpha = shallowPNInfo.supportRidgeRelativeAlpha;

info.activePECorrectionCoefficientCount = module.activePECorrectionCoefficientCount;
info.activePEBypassCoefficientCount = module.activePEBypassCoefficientCount;
info.activeShallowPNCoefficientCount = module.activeShallowPNCoefficientCount;
info.activeCompositionalCoefficientCount = module.activeCompositionalCoefficientCount;
info.activeBypassCoefficientCount = module.activeBypassCoefficientCount;
info.activeNeuralCoefficientCount = module.activeNeuralCoefficientCount;
info.totalActiveCoefficientCount = ...
    layer1Info.activeCoefficientCount + module.activeCoefficientCount;
info.totalCandidateCoefficientCount = ...
    layer1Info.candidateCoefficientCount + module.candidateCoefficientCount;
info.physicsPriorFeatureCount = layer1Info.physicsPriorFeatureCount;
info.activePhysicsCoefficientCount = layer1Info.activePhysicsCoefficientCount;
info.activeGenericCoefficientCount = module.activeCoefficientCount;
info.weightedActiveComplexity = module.activeCoefficientCount;
info.trajectoryValidationEnabled = false;
info.validationTrajectoryNormalizedMSE = NaN;

if opt.verbose
    fprintf(['      %s%d | PNC-v3 residualized | PE val=%.3e | flat-PN val=%.3e | ', ...
        'DeltaL2=%d terms [Hcorr=%d, PN=%d, comp=%d] | selected=%s | ', ...
        'lambda=%.3g | active=%d [Hcorr=%d, PN=%d, comp=%d] | val nMSE=%.3e\n'], ...
        upper(char(data.deviceType)),data.deviceIndex, ...
        info.layer1ValidationNormalizedMSE,info.shallowPNValidationNormalizedMSE, ...
        info.libraryTermCount,numel(peIdx),numel(pnIdx),numel(compIdx), ...
        info.selectedCandidateType,info.selectedThreshold,info.activeCoefficientCount, ...
        info.activePECorrectionCoefficientCount,info.activeShallowPNCoefficientCount, ...
        info.activeCompositionalCoefficientCount,info.validationNormalizedMSE);
    switch string(info.selectedCandidateType)
        case "pe_zero_correction"
            fprintf('      PNC-v3 gate: PE parent retained exactly (DeltaXi_2=0).\n');
        case "flat_pn_exact_residual"
            fprintf('      PNC-v3 gate: exact flat-PN parent selected through residual parameterization.\n');
        otherwise
            fprintf('      PNC-v3 gate: full residualized sparse correction selected beyond both parents.\n');
    end
    if info.supportRidgeApplied && info.fullResidualizedPNCSelected
        fprintf('      PNC-v3 support ridge rho=%.3g | normalized coefficient Fro norm=%.3e\n', ...
            info.supportRidgeRelativeAlpha,info.normalizedCoefficientFroNorm);
    end
end
end

function r = make_result_local(candidateType,lambda,rho,Xi,supportMask, ...
    Atr,Aval,Btr,Bval,peMask,pnMask,compMask)
trResidualPred = Atr*Xi;
vaResidualPred = Aval*Xi;
activeMask = logical(supportMask);
peMask2 = repmat(peMask,1,size(Xi,2));
pnMask2 = repmat(pnMask,1,size(Xi,2));
compMask2 = repmat(compMask,1,size(Xi,2));
r = struct();
r.candidateType = string(candidateType);
r.lambda = lambda;
r.supportRidgeRelativeAlpha = rho;
r.trainNormalizedMSE = mean((trResidualPred-Btr).^2,'all');
r.validationNormalizedMSE = mean((vaResidualPred-Bval).^2,'all');
r.activeCoefficientCount = nnz(activeMask);
r.activePECorrectionCoefficientCount = nnz(activeMask & peMask2);
r.activeShallowPNCoefficientCount = nnz(activeMask & pnMask2);
r.activeCompositionalCoefficientCount = nnz(activeMask & compMask2);
r.normalizedCoefficientFroNorm = norm(Xi,'fro');
r.supportMask = activeMask;
r.XiNormalized = Xi;
end

function txt = derivative_label_protocol_local(data)
txt = 'unknown';
if isstruct(data) && isfield(data,'derivativeLabelProtocol') && ...
        strlength(string(data.derivativeLabelProtocol)) > 0
    txt = char(string(data.derivativeLabelProtocol));
end
end
