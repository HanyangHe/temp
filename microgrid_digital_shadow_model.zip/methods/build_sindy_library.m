function [Theta,names,spec] = build_sindy_library(X,inputNames,deviceType,variant,opt,spec)
%BUILD_SINDY_LIBRARY Build [Poly_p(raw chi), sin(raw chi), cos(raw chi), Phi_phys].
%
% Poly_p contains the constant and every raw-input monomial of total degree
% 1..p, including all cross-products. Trigonometric atoms are added separately
% and are NOT fed back into Poly_p. Physics variants append composed physical
% primitives after the generic library.
%
% If spec is supplied, its polynomial index patterns are reused. This is used
% during arbitrary-state rollout to guarantee identical feature ordering.

if nargin < 6 || isempty(spec)
    spec = make_spec(size(X,2),opt.polyOrderOption,opt.includeSin,opt.includeCos);
end
if size(X,2) ~= spec.nRawInputs
    error('build_sindy_library:InputSize','Expected %d raw inputs, received %d.', ...
        spec.nRawInputs,size(X,2));
end
if numel(inputNames) ~= spec.nRawInputs
    error('build_sindy_library:InputNames','inputNames has incorrect length.');
end

N = size(X,1);
Theta = ones(N,1);
wantNames = nargout >= 2;
if wantNames, names = "1"; else, names = strings(0,1); end

for d = 1:numel(spec.monomialIndices)
    combos = spec.monomialIndices{d};
    for r = 1:size(combos,1)
        idx = combos(r,:);
        val = prod(X(:,idx),2);
        Theta(:,end+1) = val; %#ok<AGROW>
        if wantNames, names(end+1,1) = monomial_name(inputNames,idx); end %#ok<AGROW>
    end
end

if spec.includeSin
    Theta = [Theta sin(X)]; %#ok<AGROW>
    if wantNames
        for j = 1:spec.nRawInputs
            names(end+1,1) = "sin("+string(inputNames(j))+")"; %#ok<AGROW>
        end
    end
end
if spec.includeCos
    Theta = [Theta cos(X)]; %#ok<AGROW>
    if wantNames
        for j = 1:spec.nRawInputs
            names(end+1,1) = "cos("+string(inputNames(j))+")"; %#ok<AGROW>
        end
    end
end

compiledPhys = [];
if isfield(spec,'llmPriorCompiledSpec')
    compiledPhys = spec.llmPriorCompiledSpec;
end
[Phi,physNames,compiledPhys] = build_sindy_physics_features( ...
    X,deviceType,variant,opt,compiledPhys);
Theta = [Theta Phi];
if wantNames, names = [names;physNames]; end

spec.variant = char(lower(string(variant)));
spec.deviceType = char(lower(string(deviceType)));
if wantNames, spec.libraryNames = names; end
if lower(string(variant)) == "llmprior"
    spec.llmPriorCompiledSpec = compiledPhys;
end
end

function spec = make_spec(n,p,includeSin,includeCos)
spec.nRawInputs = n;
spec.polyOrder = p;
spec.includeSin = logical(includeSin);
spec.includeCos = logical(includeCos);
spec.monomialIndices = cell(p,1);
for d = 1:p
    spec.monomialIndices{d} = combinations_with_repetition(n,d);
end
end

function C = combinations_with_repetition(n,d)
rows = cell(0,1);
recurse([],1,d);
C = zeros(numel(rows),d);
for i = 1:numel(rows), C(i,:) = rows{i}; end

    function recurse(prefix,startValue,remaining)
        if remaining == 0
            rows{end+1,1} = prefix; %#ok<AGROW>
            return;
        end
        for v = startValue:n
            recurse([prefix v],v,remaining-1); %#ok<AGROW>
        end
    end
end

function name = monomial_name(inputNames,idx)
uniqueIdx = unique(idx,'stable');
parts = strings(1,numel(uniqueIdx));
for k = 1:numel(uniqueIdx)
    j = uniqueIdx(k);
    pow = sum(idx==j);
    if pow == 1
        parts(k) = string(inputNames(j));
    else
        parts(k) = string(inputNames(j))+"^"+string(pow);
    end
end
name = strjoin(parts,"*");
end
