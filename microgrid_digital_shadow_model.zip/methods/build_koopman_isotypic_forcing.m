function [Qraw,names] = build_koopman_isotypic_forcing(deviceType,X,Vbus,refs,p,opt)
%BUILD_KOOPMAN_ISOTYPIC_FORCING Jiang-style symmetry-preserving KBF inputs.
%
% The original M-KBF paper uses different causal port inputs for GFM and GFL
% DERs and then non-dimensionalizes them in the same isotypic coordinates as
% the lifted state.  This helper follows those constructions as closely as
% the reduced benchmark models permit:
%
% GFL (paper Eq. 22, q=-1):
%   q1 = Vbus / exp(j*theta)
%   q2 = Sref * exp(j*theta) / Vbus
%
% GFM (paper Eq. 18 adapted to the reduced voltage-source port):
%   q1 = Iport / Vbus
% where Iport is obtained from the known algebraic terminal relation.  The
% benchmark-specific P*/Q*/Eref inputs are appended as invariant real inputs.
%
% SG is not present in Jiang et al.; it uses the same q=-1 phase-symmetry
% extension as a grid-forming source: Iport/Vbus plus Pm/Vref when available.

if nargin < 6 || isempty(opt)
    opt = struct();
end
if ~isfield(opt,'voltageDivisionFloor')
    opt.voltageDivisionFloor = 1e-6;
end

deviceType = lower(char(string(deviceType)));
X = double(X);
if isvector(X), X = X(:); end
Vbus = reshape(Vbus,1,[]);
refs = double(refs);
if isempty(refs), refs = zeros(0,size(X,2)); end
if isvector(refs) && size(X,2)==1, refs = refs(:); end
if size(X,2) ~= numel(Vbus) || size(refs,2) ~= size(X,2)
    error('build_koopman_isotypic_forcing:SampleSize', ...
        'State, terminal-voltage, and reference samples must have equal length.');
end

Vsafe = safe_complex_denominator(Vbus,opt.voltageDivisionFloor);
phase = X(1,:);
w = exp(1i*phase);

switch deviceType
    case 'gfl'
        if size(refs,1) < 2
            error('build_koopman_isotypic_forcing:GFLReferences', ...
                'GFL M-KBF requires Pstar and Qstar.');
        end
        Sref = refs(1,:) + 1i*refs(2,:);
        Qraw = [Vsafe./w; Sref.*w./Vsafe];
        names = ["Vterminal/exp(j*thetaPLL)"; ...
                 "Sref*exp(j*thetaPLL)/Vterminal"];

    case 'gfm'
        if size(X,1) < 4 || ~isfield(p,'Zout')
            error('build_koopman_isotypic_forcing:GFMPort', ...
                'Reduced GFM isotypic forcing requires state [delta,pFilt,qFilt,E] and Zout.');
        end
        Eint = X(4,:).*w;
        Iport = (Eint - Vbus)./p.Zout;
        Qraw = Iport./Vsafe;
        names = "Iport/Vterminal";
        if ~isempty(refs)
            Qraw = [Qraw; refs]; %#ok<AGROW>
            defaultNames = ["Pstar";"Qstar";"Eref"];
            names = [names; defaultNames(1:size(refs,1))]; %#ok<AGROW>
        end

    case 'sg'
        Iport = sg_port_current(X,Vbus,p);
        Qraw = Iport./Vsafe;
        names = "Iport/Vterminal";
        if ~isempty(refs)
            Qraw = [Qraw; refs]; %#ok<AGROW>
            if size(refs,1) == 1
                names = [names;"Pm"];
            else
                defaultNames = ["Pm";"Vref"];
                names = [names;defaultNames(1:size(refs,1))]; %#ok<AGROW>
            end
        end

    otherwise
        error('build_koopman_isotypic_forcing:DeviceType', ...
            'Unsupported device type "%s".',deviceType);
end
end

function Iinj = sg_port_current(X,Vbus,p)
phase = X(1,:);
w = exp(1i*phase);
if size(X,1) == 2
    if ~isfield(p,'Eprime') || ~isfield(p,'XdPrime')
        error('build_koopman_isotypic_forcing:ClassicalSGParameters', ...
            'Classical SG port map requires Eprime and XdPrime.');
    end
    Eint = p.Eprime*w;
    Iinj = (Eint - Vbus)/(1i*p.XdPrime);
elseif size(X,1) == 5
    req = {'Ra','XdPrime','XqPrime'};
    for k = 1:numel(req)
        if ~isfield(p,req{k})
            error('build_koopman_isotypic_forcing:SalientSGParameters', ...
                'Salient SG port map requires parameter %s.',req{k});
        end
    end
    EqPrime = X(3,:);
    EdPrime = X(4,:);
    VR = real(Vbus); VI = imag(Vbus);
    c = cos(phase); s = sin(phase);
    Vq = VR.*c + VI.*s;
    Vd = VR.*s - VI.*c;
    den = p.Ra^2 + p.XdPrime*p.XqPrime;
    Iq = (p.Ra*(EqPrime-Vq) - p.XdPrime*(EdPrime-Vd))/den;
    Id = (p.XqPrime*(EqPrime-Vq) + p.Ra*(EdPrime-Vd))/den;
    Iinj = (Iq - 1i*Id).*w;
else
    error('build_koopman_isotypic_forcing:SGStateSize', ...
        'Supported SG state sizes are 2 and 5, received %d.',size(X,1));
end
end

function z = safe_complex_denominator(z,floorValue)
mag = abs(z);
small = mag < floorValue;
if any(small)
    ang = angle(z(small));
    ang(~isfinite(ang)) = 0;
    z(small) = floorValue*exp(1i*ang);
end
end
