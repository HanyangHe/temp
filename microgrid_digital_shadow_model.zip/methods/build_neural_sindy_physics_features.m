function [P,names] = build_neural_sindy_physics_features(X,inputNames,deviceType,opt)
%BUILD_NEURAL_SINDY_PHYSICS_FEATURES Fast physics-prior feature evaluator.
%
% These columns are used by Physics-Neural SINDy. During training they are
% automatically aligned/verified against the project's existing
% Physics-embedded SINDy library, so PN-SINDy receives the
% same physical-prior feature family rather than a separately invented one.

inputNames = string(inputNames(:));
deviceType = lower(string(deviceType));
if size(X,2) ~= numel(inputNames)
    error('build_neural_sindy_physics_features:Dimension', ...
        'X has %d columns but inputNames contains %d entries.',size(X,2),numel(inputNames));
end

switch deviceType
    case "sg"
        delta = col('delta');
        VR = col('Vterminal_Re');
        VI = col('Vterminal_Im');
        c = cos(delta); s = sin(delta);

        if any(inputNames=="EqPrime") && any(inputNames=="EdPrime")
            EqPrime = col('EqPrime');
            EdPrime = col('EdPrime');
            % Current five-state salient-pole SG convention.
            Vq = VR.*c + VI.*s;
            Vd = VR.*s - VI.*c;
            Vmag = sqrt(VR.^2 + VI.^2);
            P = [Vq,Vd, ...
                EqPrime.*Vq,EqPrime.*Vd, ...
                EdPrime.*Vq,EdPrime.*Vd, ...
                Vq.^2,Vq.*Vd,Vd.^2,Vmag];
            names = ["phys_Vq";"phys_Vd"; ...
                "phys_EqPrime_Vq";"phys_EqPrime_Vd"; ...
                "phys_EdPrime_Vq";"phys_EdPrime_Vd"; ...
                "phys_Vq2";"phys_Vq_Vd";"phys_Vd2";"phys_Vmag"];
        else
            % Backward-compatible two-state SG feature pool.
            vd = VR.*c + VI.*s;
            vq = VI.*c - VR.*s;
            P = [vd,vq];
            names = ["phys_vd";"phys_vq"];
        end

    case "gfm"
        delta = col('delta');
        E = col('E');
        VR = col('Vterminal_Re');
        VI = col('Vterminal_Im');
        c = cos(delta); s = sin(delta);
        vd = VR.*c + VI.*s;
        vq = VI.*c - VR.*s;
        P = [vd,vq,E.*vd,E.*vq];
        names = ["phys_vd";"phys_vq";"phys_E_vd";"phys_E_vq"];

    case "gfl"
        theta = col('thetaPLL');
        VR = col('Vterminal_Re');
        VI = col('Vterminal_Im');
        Pstar = col('Pstar');
        Qstar = col('Qstar');
        c = cos(theta); s = sin(theta);
        vd = VR.*c + VI.*s;
        vq = VI.*c - VR.*s;
        vm2 = VR.^2 + VI.^2;
        vm2 = max(vm2,opt.physics.voltageMagnitudeSquaredFloor);
        rhoV = 1./vm2;
        P = [vd,vq, ...
            Pstar.*vd,Qstar.*vq,Pstar.*vq,Qstar.*vd, ...
            rhoV, ...
            rhoV.*Pstar.*vd,rhoV.*Qstar.*vq, ...
            rhoV.*Pstar.*vq,rhoV.*Qstar.*vd];
        names = ["phys_vd";"phys_vq"; ...
            "phys_Pstar_vd";"phys_Qstar_vq";"phys_Pstar_vq";"phys_Qstar_vd"; ...
            "phys_rhoV"; ...
            "phys_rhoV_Pstar_vd";"phys_rhoV_Qstar_vq"; ...
            "phys_rhoV_Pstar_vq";"phys_rhoV_Qstar_vd"];

    otherwise
        error('build_neural_sindy_physics_features:DeviceType', ...
            'Unknown deviceType "%s".',char(deviceType));
end

if any(~isfinite(P),'all')
    error('build_neural_sindy_physics_features:Nonfinite', ...
        'Physics feature evaluation returned nonfinite values.');
end

    function v = col(name)
        idx = find(inputNames==string(name),1);
        if isempty(idx)
            error('build_neural_sindy_physics_features:MissingInput', ...
                'Required input "%s" is not present for device type %s.',name,char(deviceType));
        end
        v = X(:,idx);
    end
end
