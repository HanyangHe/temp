function lossValue = node_validation_loss(params,tspan,XN,FN,trajectoryIndices,opt)
%NODE_VALIDATION_LOSS Evaluate trajectory MSE without parameter gradients.

if isempty(trajectoryIndices)
    lossValue = NaN;
    return;
end
Bmax = opt.miniBatchTrajectories;
accum = 0;
count = 0;
for s = 1:Bmax:numel(trajectoryIndices)
    ids = trajectoryIndices(s:min(s+Bmax-1,numel(trajectoryIndices)));
    X0 = dlarray(single(XN(:,ids,1)));
    targets = single(XN(:,ids,2:end));
    forcingN = single(FN(:,ids,:));

    theta = params;
    theta.Forcing = forcingN;
    theta.T0 = double(tspan(1));
    theta.Dt = double(tspan(2)-tspan(1));
    theta.NTimes = numel(tspan);

    Y = dlode45(@node_controlled_rhs,tspan,X0,theta, ...
        DataFormat='CB',GradientMode='direct', ...
        RelativeTolerance=opt.solver.RelativeTolerance, ...
        AbsoluteTolerance=opt.solver.AbsoluteTolerance, ...
        MaxStepSize=opt.solver.MaxStepSize);
    Ynum = double(gather(extractdata(Y)));
    targetNum = double(targets);
    accum = accum + sum((Ynum-targetNum).^2,'all');
    count = count + numel(targetNum);
end
lossValue = accum/max(1,count);
end
