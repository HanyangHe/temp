function model = canonicalize_loaded_sindy_model(methodName,model,compatibilityDetails)
%CANONICALIZE_LOADED_SINDY_MODEL Canonicalize semantically equivalent metadata.
%
% Call this only AFTER check_sindy_model_compatibility has returned true.
% It changes no learned coefficients, thresholds, neural basis parameters, or
% physical feature values. It only maps stored dictionary metadata to the
% current canonical PE naming so an older mathematically equivalent model can
% be evaluated by the current predictor.

if nargin < 3 || ~isstruct(compatibilityDetails) || ...
        ~isfield(compatibilityDetails,'compatible') || ~compatibilityDetails.compatible
    error('canonicalize_loaded_sindy_model:Compatibility', ...
        'Model metadata may be canonicalized only after compatibility validation passes.');
end

methodName = char(string(methodName));
usesCompletePhysics = any(strcmp(methodName,{ ...
    'physics_embedded_sindy','physics_neural_sindy','physics_neural_compositional_sindy', ...
    'prior_weighted_sindy','prior_weighted_neural_sindy'}));
if ~usesCompletePhysics
    return;
end

% Polynomial PE/PW rollout rebuilds the library from module.variant.
if any(strcmp(methodName,{'physics_embedded_sindy','prior_weighted_sindy'}))
    % The retired full-physics PE model used top-level variant='strong'.
    % Compatibility has already verified the concrete full physics feature
    % set, so normalize the metadata used by current evaluators.
    if strcmp(methodName,'physics_embedded_sindy') && isfield(model,'variant')
        model.variant = 'physics';
    end
    if isfield(model,'libraryVariant'), model.libraryVariant = 'physics'; end
    for dCell = {'sg','gfm','gfl'}
        d = dCell{1};
        if ~isfield(model,d), continue; end
        for k = 1:numel(model.(d))
            model.(d)(k).variant = 'physics';
            if isfield(model.(d)(k),'librarySpec') && isstruct(model.(d)(k).librarySpec)
                model.(d)(k).librarySpec.variant = 'physics';
            end
        end
    end
end

% PNC-SINDy stores a complete PE-SINDy module as its frozen first layer.
% Canonicalize only that nested metadata; the learned layer-1/layer-2
% coefficients and fixed-neural basis remain unchanged.
if strcmp(methodName,'physics_neural_compositional_sindy')
    for dCell = {'sg','gfm','gfl'}
        d = dCell{1};
        if ~isfield(model,d), continue; end
        for k = 1:numel(model.(d))
            if ~isfield(model.(d)(k),'layer1') || ~isstruct(model.(d)(k).layer1)
                continue;
            end
            l1 = model.(d)(k).layer1;
            if isfield(l1,'variant'), l1.variant = 'physics'; end
            if isfield(l1,'librarySpec') && isstruct(l1.librarySpec)
                l1.librarySpec.variant = 'physics';
            end
            model.(d)(k).layer1 = l1;
        end
    end
end

% PN-SINDy normally stores a fast aligned evaluator and needs no change. If an
% older result stored a reference-library fallback, compatibility validation
% has already proved that its concrete phys_* columns equal the current full
% physics set. Therefore the reference metadata can be safely canonicalized.
if any(strcmp(methodName,{'physics_neural_sindy','prior_weighted_neural_sindy'}))
    for dCell = {'sg','gfm','gfl'}
        d = dCell{1};
        if ~isfield(model,d), continue; end
        for k = 1:numel(model.(d))
            m = model.(d)(k);
            if ~isfield(m,'librarySpec') || ~isstruct(m.librarySpec) || ...
                    ~isfield(m.librarySpec,'physics') || ~isstruct(m.librarySpec.physics)
                continue;
            end
            p = m.librarySpec.physics;
            if isfield(p,'mode')
                q = char(string(p.mode));
                if startsWith(q,'reference_') && endsWith(q,'_library')
                    p.mode = 'reference_physics_library';
                end
            end
            if isfield(p,'referenceLibrarySpec') && isstruct(p.referenceLibrarySpec)
                p.referenceLibrarySpec.variant = 'physics';
            end
            model.(d)(k).librarySpec.physics = p;
        end
    end
end
end
