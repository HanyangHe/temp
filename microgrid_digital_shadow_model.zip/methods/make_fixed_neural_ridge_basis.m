function [Phi,spec] = make_fixed_neural_ridge_basis(X,nTarget,opt,seed,specIn)
%MAKE_FIXED_NEURAL_RIDGE_BASIS Reproducible compact fixed tanh ridge bank.
%
% New-bank construction follows the neural-basis generator used by the PhDN
% project: training-only coordinate standardization, random orthogonal
% projection blocks, projected-data quantile transition locations, multiple
% activation scales, variance/correlation screening, and column-pivoted QR.
%
% X is N-by-d. When specIn is supplied, no parameters are regenerated; the
% already selected physical-coordinate ridge weights/biases are evaluated.

if nargin < 5, specIn = []; end
validateattributes(X,{'numeric'},{'2d','real','finite','nonempty'},mfilename,'X');

if ~isempty(specIn)
    if ~isstruct(specIn) || ~isfield(specIn,'rawWeights') || ~isfield(specIn,'rawBiases')
        error('make_fixed_neural_ridge_basis:InvalidSpec', ...
            'specIn must contain rawWeights and rawBiases.');
    end
    if size(X,2) ~= size(specIn.rawWeights,1)
        error('make_fixed_neural_ridge_basis:InputDimension', ...
            'Input dimension %d does not match stored neural basis dimension %d.', ...
            size(X,2),size(specIn.rawWeights,1));
    end
    Phi = tanh(X*specIn.rawWeights + specIn.rawBiases);
    spec = specIn;
    return;
end

nTarget = max(1,round(double(nTarget)));
activation = lower(strtrim(char(opt.activation)));
if ~strcmp(activation,'tanh')
    error('make_fixed_neural_ridge_basis:Activation', ...
        'Only tanh fixed neural-ridge bases are currently supported.');
end
quantiles = reshape(double(opt.quantiles),1,[]);
scales = reshape(double(opt.scales),1,[]);
quantiles = unique(quantiles(isfinite(quantiles) & quantiles>0 & quantiles<1),'stable');
scales = unique(scales(isfinite(scales) & scales>0),'stable');
if isempty(quantiles) || isempty(scales)
    error('make_fixed_neural_ridge_basis:Grid', ...
        'Neural quantile and activation-scale sets must be nonempty.');
end
poolRatio = max(1,double(opt.poolRatio));
stdFloor = max(eps,double(opt.stdFloor));
varThreshold = max(0,double(opt.varianceThreshold));
corrThreshold = min(max(double(opt.correlationThreshold),0),1);
ensureFullSpan = logical(opt.ensureFullDirectionalSpan);
seed = round(double(seed));

N = size(X,1);
d = size(X,2);
mu = mean(X,1);
coordScale = std(X,0,1);
coordScale(~isfinite(coordScale) | coordScale<stdFloor) = stdFloor;
Xn = (X-mu)./coordScale;

nCandidateTarget = ceil(poolRatio*nTarget);
nPerDirection = numel(quantiles)*numel(scales);
nDirection = ceil(nCandidateTarget/nPerDirection);
if ensureFullSpan
    nDirection = max(nDirection,d);
end
nBlock = ceil(nDirection/max(d,1));

U = zeros(d,nBlock*d);
stream = RandStream('mt19937ar','Seed',max(0,mod(seed,2^31-1)));
for b = 1:nBlock
    G = randn(stream,d,d);
    [Q,R] = qr(G,0);
    signs = sign(diag(R));
    signs(signs==0) = 1;
    Q = Q*diag(signs);
    U(:,(b-1)*d+(1:d)) = Q;
end
U = U(:,1:nDirection);

nActual = nDirection*nPerDirection;
values = zeros(N,nActual);
rawW = zeros(d,nActual);
rawB = zeros(1,nActual);
directionIndex = zeros(1,nActual);
quantileValue = zeros(1,nActual);
activationScale = zeros(1,nActual);
transitionLocation = zeros(1,nActual);
directionalSpread = zeros(1,nActual);

cc = 0;
for j = 1:nDirection
    uj = U(:,j);
    z = Xn*uj;
    sj = std(z,0,1);
    if ~isfinite(sj) || sj<stdFloor, sj = stdFloor; end
    for iq = 1:numel(quantiles)
        q = quantiles(iq);
        tj = empirical_quantile_local(z,q);
        for ia = 1:numel(scales)
            alpha = scales(ia);
            cc = cc+1;
            argument = alpha*(z-tj)/sj;
            values(:,cc) = tanh(argument);
            factor = alpha/sj;
            % Convert from standardized coordinates to raw X coordinates:
            % alpha*(u'*(X-mu)./scale - t)/s = X*w + b.
            w = factor*(uj./coordScale(:));
            b0 = -factor*(sum(uj(:).*(mu(:)./coordScale(:))) + tj);
            rawW(:,cc) = w;
            rawB(cc) = b0;
            directionIndex(cc) = j;
            quantileValue(cc) = q;
            activationScale(cc) = alpha;
            transitionLocation(cc) = tj;
            directionalSpread(cc) = sj;
        end
    end
end

colStd = std(values,0,1);
valid = find(isfinite(colStd) & colStd>=varThreshold & all(isfinite(values),1));
if isempty(valid)
    valid = 1:size(values,2);
end

% Greedy correlation screening before QR diversity selection.
corrKeep = zeros(1,0);
for idx = valid
    if isempty(corrKeep)
        corrKeep(end+1) = idx; %#ok<AGROW>
        continue;
    end
    xj = values(:,idx);
    accept = true;
    for kept = corrKeep
        yj = values(:,kept);
        denom = norm(xj-mean(xj))*norm(yj-mean(yj));
        if denom <= eps
            rho = 1;
        else
            rho = abs(((xj-mean(xj)).'*(yj-mean(yj)))/denom);
        end
        if rho > corrThreshold
            accept = false;
            break;
        end
    end
    if accept
        corrKeep(end+1) = idx; %#ok<AGROW>
    end
end
if numel(corrKeep) < nTarget
    corrKeep = unique([corrKeep,valid],'stable');
end

A = values(:,corrKeep);
A = A-mean(A,1);
sigma = std(A,0,1);
sigma(~isfinite(sigma) | sigma<stdFloor) = 1;
A = A./sigma;
pivot = pivot_order_local(A);
selected = corrKeep(pivot(1:min(nTarget,numel(pivot))));
if numel(selected) < nTarget
    remaining = setdiff(1:size(values,2),selected,'stable');
    selected = [selected,remaining(1:min(nTarget-numel(selected),numel(remaining)))]; %#ok<AGROW>
end
selected = selected(1:min(nTarget,numel(selected)));

rawWsel = rawW(:,selected);
rawBsel = rawB(selected);
Phi = tanh(X*rawWsel + rawBsel);

spec = struct();
spec.activation = activation;
spec.inputDim = d;
spec.trainingSampleCount = N;
spec.targetCount = nTarget;
spec.retainedCount = numel(selected);
spec.candidateTarget = nCandidateTarget;
spec.actualCandidateCount = nActual;
spec.directionCount = nDirection;
spec.orthogonalBlockCount = nBlock;
spec.quantiles = quantiles;
spec.activationScales = scales;
spec.normalizationMean = mu;
spec.normalizationScale = coordScale;
spec.selectedCandidateIndices = selected;
spec.selectedDirectionIndices = directionIndex(selected);
spec.selectedQuantiles = quantileValue(selected);
spec.selectedActivationScales = activationScale(selected);
spec.selectedTransitionLocations = transitionLocation(selected);
spec.selectedDirectionalSpreads = directionalSpread(selected);
spec.rawWeights = rawWsel;
spec.rawBiases = rawBsel;
spec.seed = seed;
spec.poolRatio = poolRatio;
spec.varianceThreshold = varThreshold;
spec.correlationThreshold = corrThreshold;
spec.ensureFullDirectionalSpan = ensureFullSpan;
end

function qv = empirical_quantile_local(x,q)
x = sort(double(x(:)));
n = numel(x);
if n==0, qv=0; return; end
if n==1, qv=x(1); return; end
pos = 1+(n-1)*q;
lo = floor(pos); hi = ceil(pos);
if lo==hi
    qv = x(lo);
else
    qv = x(lo)+(pos-lo)*(x(hi)-x(lo));
end
end

function order = pivot_order_local(A)
%PIVOT_ORDER_LOCAL Return a complete, duplicate-free column-pivot order.
% MATLAB releases differ in the representation of the third QR output, and
% some releases do not support qr(A,0,'vector').  Accept either a
% permutation vector or matrix and fall back to deterministic pivoted
% Gram--Schmidt when necessary.
n = size(A,2);
if n==0
    order = zeros(1,0);
    return;
end

order = zeros(1,0);
try
    [~,~,P] = qr(A,0);
    order = permutation_output_to_vector_local(P,n);
catch
    order = zeros(1,0);
end

if ~is_valid_permutation_local(order,n)
    order = greedy_column_pivot_order_local(A);
end
if ~is_valid_permutation_local(order,n)
    error('make_fixed_neural_ridge_basis:PivotFailure', ...
        'Unable to construct a valid duplicate-free neural-feature pivot order.');
end
end

function order = permutation_output_to_vector_local(P,n)
order = zeros(1,0);
if isvector(P) && numel(P)==n
    candidate = reshape(double(P),1,[]);
elseif ismatrix(P) && size(P,1)==n && size(P,2)==n
    [peak,candidate] = max(abs(double(P)),[],1);
    if any(~isfinite(peak)) || any(peak < 0.5)
        return;
    end
    candidate = reshape(double(candidate),1,[]);
else
    return;
end
if is_valid_permutation_local(candidate,n)
    order = candidate;
end
end

function tf = is_valid_permutation_local(order,n)
tf = isnumeric(order) && isvector(order) && numel(order)==n;
if ~tf, return; end
order = reshape(double(order),1,[]);
tf = all(isfinite(order)) && all(order==round(order)) && ...
    isequal(sort(order),1:n);
end

function order = greedy_column_pivot_order_local(A)
% Deterministic modified Gram--Schmidt column pivoting used only as a robust
% compatibility fallback.
A = double(A);
[m,n] = size(A);
order = zeros(1,n);
remaining = true(1,n);
B = A;
Q = zeros(m,min(m,n));
qCount = 0;
scale = max(1,norm(A,'fro'));
tol = max(size(A))*eps(scale);

for k = 1:n
    scores = sum(abs(B).^2,1);
    scores(~remaining) = -Inf;
    [~,j] = max(scores);
    if ~isfinite(scores(j))
        j = find(remaining,1,'first');
    end
    order(k) = j;
    remaining(j) = false;

    v = B(:,j);
    if qCount > 0
        v = v - Q(:,1:qCount)*(Q(:,1:qCount)'*v);
    end
    nv = norm(v);
    if isfinite(nv) && nv > tol && qCount < size(Q,2)
        qCount = qCount+1;
        Q(:,qCount) = v/nv;
        idx = find(remaining);
        if ~isempty(idx)
            B(:,idx) = B(:,idx) - Q(:,qCount)*(Q(:,qCount)'*B(:,idx));
        end
    end
end
end
