function [model,info] = train_weak_physics_neural_sindy(dataset,c,layout,cfg)
%TRAIN_WEAK_PHYSICS_NEURAL_SINDY Weak-form variation of PN-SINDy.
[model,info] = train_modular_weak_neural_sindy(dataset,c,layout,cfg);
end
