function fhat = predict_modular_kernel_id(model,~,x,V,u,c,layout)
%PREDICT_MODULAR_KERNEL_ID Evaluate modular KRR/GP posterior-mean vector field.

x = x(:);
V = V(:);
fhat = zeros(layout.nx,1);

for k = 1:numel(c.sg)
    m = model.sg(k);
    if numel(m.stateIndices)==5 && isfield(u,'sgVref')
        chi = [x(m.stateIndices);real(V(m.bus));imag(V(m.bus)); ...
            u.sgPm(k);u.sgVref(k)].';
    else
        chi = [x(m.stateIndices);real(V(m.bus));imag(V(m.bus)); ...
            u.sgPm(k)].';
    end
    fhat(m.stateIndices) = eval_module_local(m,chi);
end

for k = 1:numel(c.gfm)
    m = model.gfm(k);
    chi = [x(m.stateIndices);real(V(m.bus));imag(V(m.bus)); ...
        u.gfmPstar(k);u.gfmQstar(k);u.gfmEref(k)].';
    fhat(m.stateIndices) = eval_module_local(m,chi);
end

for k = 1:numel(c.gfl)
    m = model.gfl(k);
    chi = [x(m.stateIndices);real(V(m.bus));imag(V(m.bus)); ...
        u.gflPstar(k);u.gflQstar(k)].';
    fhat(m.stateIndices) = eval_module_local(m,chi);
end

if any(~isfinite(fhat))
    error('predict_modular_kernel_id:NonfiniteOutput', ...
        'Kernel identification model returned a non-finite vector field.');
end
end


function y = eval_module_local(m,chi)
z = (double(chi)-m.inputMean(:).')./m.inputScale(:).';

D2 = sum((m.xTrainNormalized-z).^2,2);
k = exp(-0.5*D2/(m.lengthscale^2)).';

yNorm = k*m.alphaNormalized;
y = yNorm.*m.outputScale(:).' + m.outputMean(:).';
y = y(:);
end
