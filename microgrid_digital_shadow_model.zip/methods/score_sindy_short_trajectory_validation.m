function score = score_sindy_short_trajectory_validation( ...
    data,trainMask,valMask,coef,libraryKind,variant,opt,librarySpec,neuralSeed)
%SCORE_SINDY_SHORT_TRAJECTORY_VALIDATION Held-out local trajectory score.
%
% This is a VALIDATION-ONLY stability/trajectory-consistency diagnostic for
% SINDy threshold candidates. It never uses the manuscript 12-s test rollout.
% For each held-out short trajectory, the local DER state is integrated while
% the recorded terminal voltage and command/reference channels are supplied as
% teacher-forced time-varying inputs. Thus the candidate must remain useful as
% a vector field under recursive state propagation, not merely fit xdot at
% isolated validation points.
%
% libraryKind:
%   'polytrig'           -> build_sindy_library
%   'fixed_neural_ridge' -> build_neural_sindy_library
%
% Returned score is normalized state-trajectory MSE. Inf denotes a candidate
% that cannot produce a finite short validation rollout.

libraryKind = lower(string(libraryKind));
variant = lower(string(variant));

nState = numel(data.stateIndices);
if size(coef,2) ~= nState
    error('score_sindy_short_trajectory_validation:OutputSize', ...
        'Coefficient output width %d does not match nState=%d.',size(coef,2),nState);
end
if ~any(valMask)
    score = Inf;
    return;
end

if isfield(data,'stateObserved') && ~isempty(data.stateObserved)
    Xstate = double(data.stateObserved);
else
    Xstate = double(data.X(:,1:nState));
end

% Training-only state scale: same spirit as the library/output scaling, but
% applied to trajectory-state error so differently scaled states contribute
% comparably. No clean/noiseless target is introduced under noisy training.
scale = std(Xstate(trainMask,:),0,1);
rmsState = sqrt(mean(Xstate(trainMask,:).^2,1));
scale = max(scale,0.05*rmsState);
scale = max(scale,opt.normalization.outputScaleFloor);

valIds = unique(data.trajectoryId(valMask),'stable');
errSS = 0;
errN = 0;

for ii = 1:numel(valIds)
    tid = valIds(ii);
    rows = find(valMask & data.trajectoryId == tid);
    if numel(rows) < 2
        continue;
    end
    [~,ord] = sort(data.pointInTrajectory(rows));
    rows = rows(ord);
    p = double(data.pointInTrajectory(rows));
    if any(p < 1) || any(p > numel(data.trajectoryTime))
        score = Inf;
        return;
    end
    t = double(data.trajectoryTime(p));
    xRef = Xstate(rows,:);
    forcing = double(data.X(rows,nState+1:end));

    x = xRef(1,:);
    for k = 1:(numel(rows)-1)
        h = t(k+1)-t(k);
        if ~(isfinite(h) && h > 0)
            score = Inf;
            return;
        end
        f0 = forcing(k,:);
        f1 = forcing(k+1,:);
        fm = 0.5*(f0+f1);

        k1 = eval_rhs_local(x,f0);
        k2 = eval_rhs_local(x+0.5*h*k1,fm);
        k3 = eval_rhs_local(x+0.5*h*k2,fm);
        k4 = eval_rhs_local(x+h*k3,f1);
        x = x + (h/6)*(k1+2*k2+2*k3+k4);

        if any(~isfinite(x))
            score = Inf;
            return;
        end
        e = (x-xRef(k+1,:))./scale;
        if any(~isfinite(e)) || any(abs(e) > 1e6)
            score = Inf;
            return;
        end
        errSS = errSS + sum(e.^2);
        errN = errN + numel(e);
    end
end

if errN < 1
    score = Inf;
else
    score = errSS/errN;
end

    function dx = eval_rhs_local(xState,forceRow)
        Xrow = [double(xState(:).') double(forceRow(:).')];
        switch libraryKind
            case "polytrig"
                Theta = build_sindy_library(Xrow,data.inputNames, ...
                    data.deviceType,variant,opt,librarySpec);
            case "fixed_neural_ridge"
                Theta = build_neural_sindy_library(Xrow,data.inputNames, ...
                    data.deviceType,variant,opt,neuralSeed,librarySpec);
            otherwise
                error('score_sindy_short_trajectory_validation:LibraryKind', ...
                    'Unknown libraryKind "%s".',libraryKind);
        end
        dx = double(Theta*coef);
        if numel(dx) ~= nState
            error('score_sindy_short_trajectory_validation:RHSSize', ...
                'Candidate RHS returned %d states; expected %d.',numel(dx),nState);
        end
        dx = reshape(dx,1,[]);
    end
end
