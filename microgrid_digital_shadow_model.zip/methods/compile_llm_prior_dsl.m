function spec = compile_llm_prior_dsl(inputNames,terms,varargin)
%COMPILE_LLM_PRIOR_DSL Parse/canonicalize the generic LLM-prior DSL once.
%
% The returned representation is a topologically ordered expression DAG.
% It is intentionally independent of SG/GFM/GFL physics; only the generic
% mathematical grammar is compiled here.  Reusing this spec during DAE
% rollout avoids reparsing nested symbolic strings at every ODE evaluation.
%
% Supported DSL:
%   1, xN,
%   prod(a,b,...), add(a,b,...), sub(a,b), div(a,b),
%   sin(a), cos(a), square(a), sqrt_pos(a)

p = inputParser;
p.addParameter('MaxDepth',8,@(v)isnumeric(v)&&isscalar(v)&&isfinite(v)&&v>=0);
p.addParameter('MaxComplexity',32,@(v)isnumeric(v)&&isscalar(v)&&isfinite(v)&&v>=0);
p.parse(varargin{:});
opt = p.Results;

inputNames = string(inputNames(:));
terms = string(terms(:));
nVar = numel(inputNames);

rootExpr = cell(numel(terms),1);
canon = strings(numel(terms),1);
meta = repmat(struct('key','', 'label','', 'depth',0, 'complexity',0),numel(terms),1);
for j = 1:numel(terms)
    expr = parse_expr_local(char(terms(j)),inputNames);
    if expr.depth > opt.MaxDepth
        error('compile_llm_prior_dsl:Depth', ...
            'Expression depth %d exceeds limit %d: %s',expr.depth,opt.MaxDepth,terms(j));
    end
    if expr.complexity > opt.MaxComplexity
        error('compile_llm_prior_dsl:Complexity', ...
            'Expression complexity %d exceeds limit %d: %s', ...
            expr.complexity,opt.MaxComplexity,terms(j));
    end
    rootExpr{j}=expr;
    canon(j)=string(expr.key);
    meta(j).key=expr.key;
    meta(j).label=expr.label;
    meta(j).depth=expr.depth;
    meta(j).complexity=expr.complexity;
end

% Intern every unique subexpression. Children are inserted first, so node
% order is a valid topological evaluation order.
nodeMap = containers.Map('KeyType','char','ValueType','double');
nodes = repmat(node_template_local(),0,1);
rootIdx = zeros(numel(rootExpr),1,'int32');
for j=1:numel(rootExpr)
    rootIdx(j)=int32(intern_local(rootExpr{j}));
end

spec = struct();
spec.version='generic_llm_prior_dsl_dag_v2';
spec.inputNames=inputNames;
spec.nRawInputs=nVar;
spec.originalTerms=terms;
spec.canonicalTerms=canon;
spec.names=canon;
spec.meta=meta;
spec.nodes=nodes;
spec.rootNodeIndices=rootIdx;
spec.maxDepth=double(opt.MaxDepth);
spec.maxComplexity=double(opt.MaxComplexity);

    function idx=intern_local(expr)
        key=char(expr.key);
        if isKey(nodeMap,key)
            idx=nodeMap(key);
            return;
        end
        argIdx=zeros(1,numel(expr.children),'int32');
        for ii=1:numel(expr.children)
            argIdx(ii)=int32(intern_local(expr.children{ii}));
        end
        q=node_template_local();
        q.op=char(expr.op);
        q.args=argIdx;
        q.varIndex=int32(expr.varIndex);
        q.key=char(expr.key);
        q.label=char(expr.label);
        q.depth=double(expr.depth);
        q.complexity=double(expr.complexity);
        nodes(end+1,1)=q; %#ok<AGROW>
        idx=numel(nodes);
        nodeMap(key)=idx;
    end
end


function expr = parse_expr_local(s,inputNames)
s = regexprep(strtrim(s),'\s+','');
if strcmp(s,'1')
    expr = make_expr_local('const',{},0,'1','1',0,0);
    return;
end

tok = regexp(s,'^x(\d+)$','tokens','once');
if ~isempty(tok)
    idx = str2double(tok{1});
    if ~isfinite(idx) || idx < 1 || idx > numel(inputNames)
        error('compile_llm_prior_dsl:Variable','Invalid variable alias %s.',s);
    end
    expr = make_expr_local('var',{},idx,s,char(inputNames(idx)),0,0);
    return;
end

[op,args] = parse_call_local(s);
switch op
    case {'sin','cos','square','sqrt_pos'}
        if numel(args) ~= 1
            error('compile_llm_prior_dsl:Arity','%s expects one argument.',op);
        end
        a = parse_expr_local(args{1},inputNames);
        key = sprintf('%s(%s)',op,a.key);
        switch op
            case 'square', label = sprintf('(%s)^2',a.label);
            case 'sqrt_pos', label = sprintf('sqrt(max(%s,0))',a.label);
            otherwise, label = sprintf('%s(%s)',op,a.label);
        end
        expr = make_expr_local(op,{a},0,key,label,a.depth+1,a.complexity+1);

    case {'prod','add'}
        if numel(args) < 2
            error('compile_llm_prior_dsl:Arity','%s expects >=2 arguments.',op);
        end
        children = cellfun(@(q)parse_expr_local(q,inputNames),args,'UniformOutput',false);
        flat = {};
        for i = 1:numel(children)
            q = children{i};
            if strcmp(q.op,op)
                flat = [flat q.children]; %#ok<AGROW>
            else
                flat{end+1} = q; %#ok<AGROW>
            end
        end
        keys = cellfun(@(q)q.key,flat,'UniformOutput',false);
        [~,ord] = sort(keys);
        flat = flat(ord); keys = keys(ord);
        labels = cellfun(@(q)q.label,flat,'UniformOutput',false);
        key = sprintf('%s(%s)',op,strjoin(keys,','));
        if strcmp(op,'prod'), label = strjoin(labels,'*');
        else, label = ['(' strjoin(labels,' + ') ')']; end
        depth = 1 + max(cellfun(@(q)q.depth,flat));
        complexity = sum(cellfun(@(q)q.complexity,flat)) + numel(flat)-1;
        expr = make_expr_local(op,flat,0,key,label,depth,complexity);

    case {'sub','div'}
        if numel(args) ~= 2
            error('compile_llm_prior_dsl:Arity','%s expects two arguments.',op);
        end
        a = parse_expr_local(args{1},inputNames);
        b = parse_expr_local(args{2},inputNames);
        key = sprintf('%s(%s,%s)',op,a.key,b.key);
        if strcmp(op,'sub'), label = sprintf('((%s)-(%s))',a.label,b.label);
        else, label = sprintf('((%s)/(%s))',a.label,b.label); end
        depth = 1 + max(a.depth,b.depth);
        complexity = a.complexity + b.complexity + 1;
        expr = make_expr_local(op,{a,b},0,key,label,depth,complexity);

    otherwise
        error('compile_llm_prior_dsl:Operator','Unsupported operator %s.',op);
end
end


function [op,args] = parse_call_local(s)
p = find(s=='(',1,'first');
if isempty(p) || s(end) ~= ')'
    error('compile_llm_prior_dsl:Syntax','Invalid expression %s.',s);
end
op = lower(s(1:p-1));
body = s(p+1:end-1);
args = split_args_local(body);
end


function args = split_args_local(body)
args = {};
depth = 0; start = 1;
for i = 1:length(body)
    ch = body(i);
    if ch == '('
        depth = depth + 1;
    elseif ch == ')'
        depth = depth - 1;
        if depth < 0, error('compile_llm_prior_dsl:Syntax','Unbalanced parentheses.'); end
    elseif ch == ',' && depth == 0
        args{end+1,1}=body(start:i-1); %#ok<AGROW>
        start=i+1;
    end
end
if depth~=0, error('compile_llm_prior_dsl:Syntax','Unbalanced parentheses.'); end
args{end+1,1}=body(start:end);
if any(cellfun(@isempty,args)), error('compile_llm_prior_dsl:Syntax','Empty function argument.'); end
end


function expr = make_expr_local(op,children,varIndex,key,label,depth,complexity)
expr = struct('op',op,'children',{children},'varIndex',varIndex, ...
    'key',key,'label',label,'depth',depth,'complexity',complexity);
end


function q=node_template_local()
q=struct('op','','args',int32([]),'varIndex',int32(0), ...
    'key','','label','','depth',0,'complexity',0);
end
