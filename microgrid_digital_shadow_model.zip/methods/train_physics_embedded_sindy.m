function [model,info] = train_physics_embedded_sindy(dataset,c,layout,cfg)
%TRAIN_PHYSICS_EMBEDDED_SINDY Full physics-embedded SINDy baseline.
%
% Uses the complete physics library: SG/GFM rotating/dq features, SG AVR |V|,
% and the full GFL rhoV=1/(VR^2+VI^2) interactions.
[model,info] = train_modular_sindy(dataset,c,layout,cfg,'physics');
end
