function [Phi,names,meta,compiledSpec] = evaluate_llm_prior_dsl(X,inputNames,terms,varargin)
%EVALUATE_LLM_PRIOR_DSL Compile/evaluate generic symbolic prior expressions.
%
% Supported coefficient-free DSL:
%   1, xN,
%   prod(a,b,...), add(a,b,...), sub(a,b), div(a,b),
%   sin(a), cos(a), square(a), sqrt_pos(a)
%
% Parsing is intentionally separated from numerical evaluation.  The fourth
% output is a reusable expression DAG that can be stored in a trained model
% and evaluated during rollout without reparsing symbolic strings.

p=inputParser;
p.addParameter('MaxDepth',8,@(v)isnumeric(v)&&isscalar(v)&&isfinite(v)&&v>=0);
p.addParameter('MaxComplexity',32,@(v)isnumeric(v)&&isscalar(v)&&isfinite(v)&&v>=0);
p.addParameter('DenominatorFloor',1e-10,@(v)isnumeric(v)&&isscalar(v)&&isfinite(v)&&v>0);
p.addParameter('MaxAbsValue',1e10,@(v)isnumeric(v)&&isscalar(v)&&isfinite(v)&&v>0);
p.parse(varargin{:});
opt=p.Results;

compiledSpec=compile_llm_prior_dsl(inputNames,terms, ...
    'MaxDepth',opt.MaxDepth,'MaxComplexity',opt.MaxComplexity);
[Phi,names]=evaluate_compiled_llm_prior_dsl(X,compiledSpec, ...
    'DenominatorFloor',opt.DenominatorFloor,'MaxAbsValue',opt.MaxAbsValue);
meta=compiledSpec.meta;
end
