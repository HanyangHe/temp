function [module,info] = fit_neural_sindy_stlsq_module(data,trainMask,valMask,mode,opt,seed)
%FIT_NEURAL_SINDY_STLSQ_MODULE Fit compact fixed-neural-ridge SINDy module.
%
% Neural SINDy:
%   [1, raw chi, fixed tanh ridge bank]
%
% Physics-Neural SINDy:
%   [1, raw chi, fixed tanh ridge bank, physics candidates]
% with ordinary equal-threshold STLSQ.
%
% Prior-weighted Neural SINDy uses the IDENTICAL library, with physics
% columns receiving lambda/w_p rather than lambda.

mode = lower(string(mode));
if ~any(mode == ["neural","physics_neural","prior_weighted_neural"])
    error('fit_neural_sindy_stlsq_module:Mode','Unknown mode "%s".',mode);
end
if ~any(trainMask) || ~any(valMask)
    error('fit_neural_sindy_stlsq_module:EmptySplit', ...
        'Train and validation masks must both be nonempty.');
end

Xtr = data.X(trainMask,:);
Xval = data.X(valMask,:);
YtrRaw = data.Y(trainMask,:);
YvalRaw = data.Y(valMask,:);

% IMPORTANT: construct/select the neural ridge bank from TRAINING rows only.
[AtrRaw,names,spec] = build_neural_sindy_library( ...
    Xtr,data.inputNames,data.deviceType,mode,opt,seed,[]);
[AvalRaw,namesVal] = build_neural_sindy_library( ...
    Xval,data.inputNames,data.deviceType,mode,opt,seed,spec);
if numel(namesVal) ~= numel(names) || any(string(namesVal(:))~=string(names(:)))
    error('fit_neural_sindy_stlsq_module:LibraryOrder', ...
        'Training and validation neural libraries have inconsistent column ordering.');
end

colScale = sqrt(mean(AtrRaw.^2,1));
colScale = max(colScale,opt.normalization.libraryScaleFloor);
yScale = std(YtrRaw,0,1);
yRms = sqrt(mean(YtrRaw.^2,1));
yScale = max(yScale,0.05*yRms);
yScale = max(yScale,opt.normalization.outputScaleFloor);

Atr = AtrRaw./colScale;
Aval = AvalRaw./colScale;
Btr = YtrRaw./yScale;
Bval = YvalRaw./yScale;

physicsPriorMask = startsWith(string(names(:)),"phys_");
featurePreference = ones(size(Atr,2),1);
physicsWeight = 1.0;
if mode == "prior_weighted_neural"
    physicsWeight = opt.priorWeightedNeural.physicsFeatureWeight;
    featurePreference(physicsPriorMask) = physicsWeight;
end
featureComplexityCost = 1./(featurePreference.^2);

lambdas = unique(sort(opt.stlsq.thresholdGrid(:)),'stable');
[supportRidgeApplied,supportRidgeConfigured,supportRidgePolicy] = ...
    should_apply_sindy_support_ridge(opt,data);
if supportRidgeApplied
    ridgeGrid = unique(double(opt.stlsq.supportRidge.relativeAlphaGrid(:).'),'stable');
else
    ridgeGrid = 0;
end

resultTemplate = struct('lambda',NaN,'supportRidgeRelativeAlpha',NaN, ...
    'trainNormalizedMSE',NaN,'validationNormalizedMSE',NaN, ...
    'validationTrajectoryNormalizedMSE',NaN, ...
    'activeCoefficientCount',NaN,'weightedActiveComplexity',NaN, ...
    'activePhysicsCoefficientCount',NaN,'activeGenericCoefficientCount',NaN, ...
    'normalizedCoefficientFroNorm',NaN,'XiNormalized',[]);
results = repmat(resultTemplate,0,1);

for il = 1:numel(lambdas)
    lambda = lambdas(il);
    if mode == "prior_weighted_neural"
        XiSupport = sparsifyDynamicsWeightedPrior(Atr,Btr,lambda,size(Btr,2), ...
            featurePreference);
    else
        % Support discovery remains the exact official SINDy STLSQ solver.
        XiSupport = sparsifyDynamics(Atr,Btr,lambda,size(Btr,2));
    end
    supportMask = abs(XiSupport)>0;

    for ia = 1:numel(ridgeGrid)
        rho = ridgeGrid(ia);
        if supportRidgeApplied
            Xi = refit_stlsq_support_ridge(Atr,Btr,supportMask,rho);
        else
            Xi = XiSupport;
        end

        trPred = Atr*Xi;
        vaPred = Aval*Xi;
        activeMask = supportMask; % support is frozen by construction
        priorMask2 = repmat(physicsPriorMask,1,size(Xi,2));
        cost2 = repmat(featureComplexityCost,1,size(Xi,2));

        r = resultTemplate;
        r.lambda = lambda;
        r.supportRidgeRelativeAlpha = rho;
        r.trainNormalizedMSE = mean((trPred-Btr).^2,'all');
        r.validationNormalizedMSE = mean((vaPred-Bval).^2,'all');
        r.activeCoefficientCount = nnz(activeMask);
        r.weightedActiveComplexity = sum(cost2(activeMask));
        r.activePhysicsCoefficientCount = nnz(activeMask & priorMask2);
        r.activeGenericCoefficientCount = nnz(activeMask & ~priorMask2);
        r.normalizedCoefficientFroNorm = norm(Xi,'fro');
        r.XiNormalized = Xi;
        results(end+1,1) = r; %#ok<AGROW>
    end
end

val = [results.validationNormalizedMSE].';
if mode == "prior_weighted_neural"
    complexity = [results.weightedActiveComplexity].';
else
    complexity = [results.activeCoefficientCount].';
end
bestVal = min(val);
tol = opt.stlsq.validationAbsoluteTolerance + ...
    opt.stlsq.preferSparseWithinRelativeValidationTolerance*max(bestVal,eps);
eligible = find(val <= bestVal + tol);
if isempty(eligible)
    [~,bestIdx] = min(val);
else
    % Optional validation-only trajectory-consistency screen.  It remains
    % available as a diagnostic, but the support-ridge confirmation disables
    % it because the previous 10-bus experiment showed that local finite/
    % nonfinite short-trajectory behavior is not a reliable global-rollout
    % discriminator at high noise.
    trajectoryValidationEnabled = trajectory_validation_enabled_local(opt);

    selectionPool = eligible;
    if trajectoryValidationEnabled
        trajScore = inf(numel(results),1);
        for ii = reshape(eligible,1,[])
            XiCandidate = results(ii).XiNormalized;
            coefCandidate = (XiCandidate./colScale(:)).*yScale;
            trajScore(ii) = score_sindy_short_trajectory_validation( ...
                data,trainMask,valMask,coefCandidate,'fixed_neural_ridge', ...
                mode,opt,spec,seed);
            results(ii).validationTrajectoryNormalizedMSE = trajScore(ii);
        end

        stableEligible = eligible(isfinite(trajScore(eligible)));
        if ~isempty(stableEligible)
            bestTraj = min(trajScore(stableEligible));
            trajTol = opt.stlsq.validationAbsoluteTolerance + ...
                opt.stlsq.preferSparseWithinRelativeValidationTolerance*max(bestTraj,eps);
            trajectoryNearBest = stableEligible( ...
                trajScore(stableEligible) <= bestTraj + trajTol);
            if ~isempty(trajectoryNearBest)
                selectionPool = trajectoryNearBest;
            end
        else
            warning('fit_neural_sindy_stlsq_module:NoFiniteTrajectoryCandidate', ...
                ['No pointwise-near-best threshold produced a finite held-out ', ...
                 'short-trajectory rollout for %s%d. Falling back to the ', ...
                 'pointwise validation selector.'], ...
                upper(char(data.deviceType)),data.deviceIndex);
        end
    end

    % Primary shared SINDy preference: minimum support complexity inside the
    % pointwise near-best validation band.
    bestComplexity = min(complexity(selectionPool));
    cTol = 100*eps(max(1,bestComplexity));
    candidates = selectionPool(abs(complexity(selectionPool)-bestComplexity) <= cTol);

    if supportRidgeApplied
        % Ridge changes coefficients, never support.  Within the already
        % selected minimum-complexity support family, first retain candidates
        % whose pointwise validation error is essentially tied, then choose
        % the smallest normalized coefficient amplification.  This is a
        % validation-only numerical-stability tie-break; alpha=0 is always in
        % the grid and wins whenever regularization is not useful.
        cVal = val(candidates);
        bestCandidateVal = min(cVal);
        ridgeValTol = opt.stlsq.validationAbsoluteTolerance + ...
            opt.stlsq.supportRidge.tieRelativeValidationTolerance* ...
            max(bestCandidateVal,eps);
        near = candidates(cVal <= bestCandidateVal + ridgeValTol);
        norms = [results(near).normalizedCoefficientFroNorm].';
        bestNorm = min(norms);
        nTol = 100*eps(max(1,bestNorm));
        near2 = near(abs(norms-bestNorm) <= nTol);
        if numel(near2) > 1
            [~,loc] = min(val(near2));
            near2 = near2(loc);
        end
        if numel(near2) > 1
            rho2 = [results(near2).supportRidgeRelativeAlpha].';
            [~,loc] = min(rho2);
            near2 = near2(loc);
        end
        bestIdx = near2(1);
    elseif trajectoryValidationEnabled && ...
            all(isfinite([results(candidates).validationTrajectoryNormalizedMSE]))
        trajCandidate = [results(candidates).validationTrajectoryNormalizedMSE].';
        bestTrajCandidate = min(trajCandidate);
        tTolTie = 100*eps(max(1,bestTrajCandidate));
        candidates2 = candidates(abs(trajCandidate-bestTrajCandidate) <= tTolTie);
        [~,loc2] = min(val(candidates2));
        bestIdx = candidates2(loc2);
    else
        [~,loc2] = min(val(candidates));
        bestIdx = candidates(loc2);
    end
end
best = results(bestIdx);
XiNorm = best.XiNormalized;

% Undo library/output normalization for direct physical-unit rollout.
coef = (XiNorm./colScale(:)).*yScale;
coefActiveMask = abs(coef)>0;
priorMask2 = repmat(physicsPriorMask,1,size(coef,2));

module.type = 'modular_sindy_module';
module.formulationVersion = char(opt.formulationVersion);
module.dictionaryFamily = 'fixed_neural_ridge';
module.variant = char(mode);
module.fitMode = char(mode);
module.deviceType = char(data.deviceType);
module.deviceIndex = data.deviceIndex;
module.bus = data.bus;
module.stateIndices = data.stateIndices(:);
module.inputNames = string(data.inputNames(:));
module.outputNames = string(data.outputNames(:));
module.libraryNames = string(names(:));
module.librarySpec = spec;
module.coefficients = coef;
module.selectedThreshold = best.lambda;
module.stlsqSolver = 'official_brunton_2015';
module.stlsqIterations = 10;
module.stlsqRidge = 0;
module.supportRidgeConfigured = supportRidgeConfigured;
module.supportRidgeApplied = supportRidgeApplied;
module.supportRidgeEnabled = supportRidgeApplied; % backward-compatible alias
module.supportRidgeApplicationPolicy = char(supportRidgePolicy);
module.derivativeLabelProtocol = derivative_label_protocol_local(data);
module.supportRidgeRelativeAlpha = best.supportRidgeRelativeAlpha;
module.normalizedCoefficientFroNorm = best.normalizedCoefficientFroNorm;
module.libraryColumnScale = colScale(:);
module.outputScale = yScale(:);
module.activeCoefficientCount = nnz(coefActiveMask);
module.candidateCoefficientCount = numel(coef);
module.physicsPriorFeatureMask = physicsPriorMask;
module.physicsPriorFeatureWeight = physicsWeight;
module.activePhysicsCoefficientCount = nnz(coefActiveMask & priorMask2);
module.activeGenericCoefficientCount = nnz(coefActiveMask & ~priorMask2);
module.neuralBasisFeatureCount = spec.neural.retainedCount;
module.neuralBasisSeed = seed;
module.trajectoryValidationEnabled = trajectory_validation_enabled_local(opt);
module.validationTrajectoryNormalizedMSE = best.validationTrajectoryNormalizedMSE;

sweepTable = table([results.lambda].',[results.supportRidgeRelativeAlpha].', ...
    [results.trainNormalizedMSE].',[results.validationNormalizedMSE].', ...
    [results.validationTrajectoryNormalizedMSE].', ...
    [results.activeCoefficientCount].',[results.weightedActiveComplexity].', ...
    [results.activePhysicsCoefficientCount].',[results.activeGenericCoefficientCount].', ...
    [results.normalizedCoefficientFroNorm].', ...
    'VariableNames',{'Threshold','SupportRidgeRelativeAlpha', ...
    'TrainNormalizedMSE','ValidationNormalizedMSE', ...
    'ValidationTrajectoryNormalizedMSE','ActiveCoefficientCount', ...
    'WeightedActiveComplexity','ActivePhysicsCoefficientCount', ...
    'ActiveGenericCoefficientCount','NormalizedCoefficientFroNorm'});

info.formulationVersion = char(opt.formulationVersion);
info.deviceType = char(data.deviceType);
info.deviceIndex = data.deviceIndex;
info.bus = data.bus;
info.nTrainSamples = nnz(trainMask);
info.nValidationSamples = nnz(valMask);
info.libraryTermCount = size(AtrRaw,2);
info.neuralBasisFeatureCount = spec.neural.retainedCount;
info.outputCount = size(YtrRaw,2);
info.candidateCoefficientCount = numel(coef);
info.activeCoefficientCount = module.activeCoefficientCount;
info.selectedThreshold = best.lambda;
info.stlsqSolver = 'official_brunton_2015';
info.stlsqIterations = 10;
info.stlsqRidge = 0;
info.supportRidgeConfigured = supportRidgeConfigured;
info.supportRidgeApplied = supportRidgeApplied;
info.supportRidgeEnabled = supportRidgeApplied; % backward-compatible alias
info.supportRidgeApplicationPolicy = char(supportRidgePolicy);
info.derivativeLabelProtocol = derivative_label_protocol_local(data);
info.supportRidgeRelativeAlpha = best.supportRidgeRelativeAlpha;
info.normalizedCoefficientFroNorm = best.normalizedCoefficientFroNorm;
info.trainNormalizedMSE = best.trainNormalizedMSE;
info.validationNormalizedMSE = best.validationNormalizedMSE;
info.thresholdSweep = sweepTable;
info.fitMode = char(mode);
info.physicsPriorFeatureCount = nnz(physicsPriorMask);
info.physicsPriorFeatureWeight = physicsWeight;
info.activePhysicsCoefficientCount = module.activePhysicsCoefficientCount;
info.activeGenericCoefficientCount = module.activeGenericCoefficientCount;
info.weightedActiveComplexity = best.weightedActiveComplexity;
info.neuralBasisSeed = seed;
info.neuralCandidatePoolCount = spec.neural.actualCandidateCount;
info.trajectoryValidationEnabled = trajectory_validation_enabled_local(opt);
info.validationTrajectoryNormalizedMSE = best.validationTrajectoryNormalizedMSE;
if isfield(spec,'physics') && isfield(spec.physics,'mode')
    info.physicsEvaluationMode = spec.physics.mode;
else
    info.physicsEvaluationMode = 'none';
end

if opt.verbose
    if mode == "prior_weighted_neural"
        fprintf(['      %s%d | PW-Neural SINDy | library=%d (neural=%d, phys=%d) | ', ...
            'prior weight=%.3g | lambda=%.3g | active=%d/%d (phys=%d, generic=%d) | ', ...
            'train nMSE=%.3e | val nMSE=%.3e\n'], ...
            upper(char(data.deviceType)),data.deviceIndex,info.libraryTermCount, ...
            info.neuralBasisFeatureCount,info.physicsPriorFeatureCount,physicsWeight, ...
            info.selectedThreshold,info.activeCoefficientCount,info.candidateCoefficientCount, ...
            info.activePhysicsCoefficientCount,info.activeGenericCoefficientCount, ...
            info.trainNormalizedMSE,info.validationNormalizedMSE);
    elseif mode == "physics_neural"
        fprintf(['      %s%d | Physics-Neural SINDy | library=%d (neural=%d, phys=%d) | ', ...
            'lambda=%.3g | active=%d/%d (phys=%d, generic=%d) | ', ...
            'train nMSE=%.3e | val nMSE=%.3e\n'], ...
            upper(char(data.deviceType)),data.deviceIndex,info.libraryTermCount, ...
            info.neuralBasisFeatureCount,info.physicsPriorFeatureCount, ...
            info.selectedThreshold,info.activeCoefficientCount,info.candidateCoefficientCount, ...
            info.activePhysicsCoefficientCount,info.activeGenericCoefficientCount, ...
            info.trainNormalizedMSE,info.validationNormalizedMSE);
    else
        fprintf(['      %s%d | Neural SINDy | library=%d (neural=%d) | lambda=%.3g | ', ...
            'active=%d/%d | train nMSE=%.3e | val nMSE=%.3e\n'], ...
            upper(char(data.deviceType)),data.deviceIndex,info.libraryTermCount, ...
            info.neuralBasisFeatureCount,info.selectedThreshold, ...
            info.activeCoefficientCount,info.candidateCoefficientCount, ...
            info.trainNormalizedMSE,info.validationNormalizedMSE);
    end
    if info.supportRidgeApplied
        fprintf('      support-preserving ridge rho=%.3g | normalized coefficient Fro norm=%.3e\n', ...
            info.supportRidgeRelativeAlpha,info.normalizedCoefficientFroNorm);
    end
    if info.trajectoryValidationEnabled
        fprintf('      held-out short-trajectory validation nMSE=%.3e\n', ...
            info.validationTrajectoryNormalizedMSE);
    end
end
end


function txt = derivative_label_protocol_local(data)
txt = 'unknown';
if isstruct(data) && isfield(data,'derivativeLabelProtocol') && ...
        strlength(string(data.derivativeLabelProtocol)) > 0
    txt = char(string(data.derivativeLabelProtocol));
end
end


function tf = trajectory_validation_enabled_local(opt)
tf = isfield(opt,'stlsq') && isfield(opt.stlsq,'trajectoryValidation') && ...
    isstruct(opt.stlsq.trajectoryValidation) && ...
    isfield(opt.stlsq.trajectoryValidation,'enabled') && ...
    logical(opt.stlsq.trajectoryValidation.enabled);
end
