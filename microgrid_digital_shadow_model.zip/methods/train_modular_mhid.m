function [model,info] = train_modular_mhid(dataset,c,layout,cfg)
%TRAIN_MODULAR_MHID Train modular Multi-Horizon Integrated Dictionary models.
%
% Current MHID formulation:
%   - complete short trajectories are split between training/validation;
%   - the test-initial anchor is forced into training exactly as for SINDy;
%   - ALL ordinary pointwise [chi,xdot] constraints are retained;
%   - each trajectory additionally contributes fixed-origin integrated average-
%     vector-field constraints for h=1,...,maxHorizonSteps;
%   - integralWeight controls the strength of this additional subobjective;
%   - the augmented problem remains linear and is solved by STLSQ.

opt = get_mhid_options(cfg);
K = dataset.trajectories.nTrajectories;
if K < 2
    error('train_modular_mhid:TooFewTrajectories', ...
        'At least two short trajectories are required for MHID.');
end

forcedTrainIds = [];
if isfield(dataset.trajectories,'forceTrainingMask') && ...
        ~isempty(dataset.trajectories.forceTrainingMask)
    m = logical(dataset.trajectories.forceTrainingMask(:));
    if numel(m) ~= K
        error('train_modular_mhid:ForceTrainingMaskSize', ...
            'forceTrainingMask must contain one entry per trajectory.');
    end
    forcedTrainIds = find(m).';
end

validationCandidates = setdiff(1:K,forcedTrainIds,'stable');
if isempty(validationCandidates)
    error('train_modular_mhid:NoValidationCandidates', ...
        'No trajectory remains for MHID validation.');
end

oldRng = rng;
cleanup = onCleanup(@()rng(oldRng)); %#ok<NASGU>
rng(opt.validationSeed,'twister');
perm = validationCandidates(randperm(numel(validationCandidates)));
nVal = max(1,round(opt.validationFraction*K));
nVal = min(nVal,numel(validationCandidates));
if nVal >= K, nVal = K-1; end
valIds = sort(perm(1:nVal));
trainIds = sort(setdiff(1:K,valIds,'stable'));

model.type = 'modular_sindy'; % reuse common sparse-model rollout/export path
model.method = 'MHID';
model.variant = char(opt.dictionaryVariant);
model.trainingObjective = 'pointwise vector field + fixed-origin multi-horizon integral subobjective';
model.trainingSampleDefinition = [ ...
    'all pointwise xdot rows + short-horizon cumulative average-vector-field rows'];
model.sg = struct([]); model.gfm = struct([]); model.gfl = struct([]);
model.trainTrajectoryIds = trainIds(:);
model.validationTrajectoryIds = valIds(:);
model.forcedTrainingTrajectoryIds = forcedTrainIds(:);
model.options = opt;

modules = struct([]);
mi = 0;
activeTotal = 0;
candidateTotal = 0;

for k = 1:numel(c.sg)
    fprintf('    Training MHID module SG%d (Bus %d)...\n',k,c.sg(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'sg',k);
    [mk,ik] = fit_mhid_stlsq_module(data,trainIds,valIds,opt);
    if k==1, model.sg=mk; else, model.sg(k,1)=mk; end
    [modules,mi] = append_info(modules,mi,ik);
    activeTotal = activeTotal + ik.activeCoefficientCount;
    candidateTotal = candidateTotal + ik.candidateCoefficientCount;
end
for k = 1:numel(c.gfm)
    fprintf('    Training MHID module GFM%d (Bus %d)...\n',k,c.gfm(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfm',k);
    [mk,ik] = fit_mhid_stlsq_module(data,trainIds,valIds,opt);
    if k==1, model.gfm=mk; else, model.gfm(k,1)=mk; end
    [modules,mi] = append_info(modules,mi,ik);
    activeTotal = activeTotal + ik.activeCoefficientCount;
    candidateTotal = candidateTotal + ik.candidateCoefficientCount;
end
for k = 1:numel(c.gfl)
    fprintf('    Training MHID module GFL%d (Bus %d)...\n',k,c.gfl(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfl',k);
    [mk,ik] = fit_mhid_stlsq_module(data,trainIds,valIds,opt);
    if k==1, model.gfl=mk; else, model.gfl(k,1)=mk; end
    [modules,mi] = append_info(modules,mi,ik);
    activeTotal = activeTotal + ik.activeCoefficientCount;
    candidateTotal = candidateTotal + ik.candidateCoefficientCount;
end

model.activeCoefficientCount = activeTotal;
model.candidateCoefficientCount = candidateTotal;

info.method = 'mhid';
info.displayName = 'MHID';
info.objective = [ ...
    'complete pointwise vector-field regression plus a weighted fixed-origin ', ...
    'multi-horizon average-vector-field subobjective'];
info.dictionaryVariant = char(opt.dictionaryVariant);
info.nSamples = size(dataset.x,1);
info.nTrajectories = K;
info.nTrainTrajectories = numel(trainIds);
info.nValidationTrajectories = numel(valIds);
info.trainTrajectoryIds = trainIds(:);
info.validationTrajectoryIds = valIds(:);
info.forcedTrainingTrajectoryIds = forcedTrainIds(:);
info.polyOrderOption = opt.polyOrderOption;
info.maxHorizonSteps = opt.maxHorizonSteps;
info.integralWeight = opt.integralWeight;
info.modules = modules;
info.activeCoefficientCount = activeTotal;
info.candidateCoefficientCount = candidateTotal;

% Every module uses the same trajectory split and therefore the same row count.
if ~isempty(modules)
    info.nTrainSamples = modules(1).trainingConstraintCount;
    info.nValidationSamples = modules(1).validationConstraintCount;
    info.nTrainPointwiseSamples = modules(1).trainPointwiseConstraintCount;
    info.nValidationPointwiseSamples = modules(1).validationPointwiseConstraintCount;
    info.nTrainIntegralSamples = modules(1).trainIntegralConstraintCount;
    info.nValidationIntegralSamples = modules(1).validationIntegralConstraintCount;
else
    info.nTrainSamples = 0;
    info.nValidationSamples = 0;
    info.nTrainPointwiseSamples = 0;
    info.nValidationPointwiseSamples = 0;
    info.nTrainIntegralSamples = 0;
    info.nValidationIntegralSamples = 0;
end

if ~isempty(forcedTrainIds) && opt.verbose
    fprintf('    Forced into MHID training partition: trajectory ID(s) [%s]\n', ...
        strtrim(sprintf('%d ',forcedTrainIds)));
end
end

function [S,mi] = append_info(S,mi,ik)
mi = mi+1;
if mi==1, S=ik; else, S(mi,1)=ik; end
end
