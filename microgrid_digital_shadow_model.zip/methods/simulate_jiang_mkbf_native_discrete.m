function prediction=simulate_jiang_mkbf_native_discrete(model,truth,c,layout,opt)
%SIMULATE_JIANG_MKBF_NATIVE_DISCRETE Native discrete EDMD / network DAE rollout.
%
% Uses ONLY truth initial state, known time-varying input schedule, and known
% device injection / network algebraic equations. No truth voltage/state is
% read after t0. Every time step first advances EDMD in lifted coordinates,
% projects to physical x, and solves the algebraic network at t_(k+1).
%
% The IDENTIFIED EDMD coefficients are reused unchanged. Unlike the former
% discrete-increment-as-ODE adapter, no continuous-time derivative is built.
% Project context: SG and reduced GFM are adaptations of Jiang et al. 2024;
% this predictor is not a claim to reproduce the original authors' code.

if nargin<5 || isempty(opt),opt=struct();end
if ~isfield(opt,'maxWallClockSeconds'),opt.maxWallClockSeconds=1200;end
if ~isfield(opt,'verbose'),opt.verbose=true;end
if ~isfield(model,'variant') || ~strcmpi(model.variant,'jiang_edmd_isotypic_v1')
    error('jiang_native:ModelVariant','Requires jiang_edmd_isotypic_v1 training model.');
end
if isfield(c,'drift') && isfield(c.drift,'enabled') && c.drift.enabled
    error('jiang_native:Drift','This offline test requires drift disabled.');
end
mods=[model.sg(:);model.gfm(:);model.gfl(:)];
dt=double(mods(1).dt);
if any(abs(arrayfun(@(m)double(m.dt),mods)-dt)>1e-12)
    error('jiang_native:DtMismatch','EDMD device models have unequal step sizes.');
end
if numel(truth.t)<2 || size(truth.y,2)~=layout.ny
    error('jiang_native:Truth','Reference truth has invalid time/state dimensions.');
end
t0=double(truth.t(1));tf=double(truth.t(end));
nStep=round((tf-t0)/dt);
if nStep<1 || abs(t0+nStep*dt-tf)>1e-9
    error('jiang_native:TimeGrid','12-s horizon is not a multiple of EDMD dt %.9g.',dt);
end
saveTime=t0+(0:nStep)'*dt;
Y=nan(nStep+1,layout.ny);
Y(1,:)=double(truth.y(1,:));
[x,V]=mg_unpack_dae_state(Y(1,:).',c,layout);
lastSuccessIndex=1;
status='SUCCESS'; reason='';failStepTime=NaN;
voltageResidual=nan(nStep,1);
outerIterations=nan(nStep,1);
networkIterations=nan(nStep,1);
stepStart=tic;
for k=1:nStep
    if toc(stepStart)>opt.maxWallClockSeconds
        status='TIMEOUT';reason=sprintf('Wall-clock budget %.1f s exhausted.',opt.maxWallClockSeconds);
        failStepTime=saveTime(k+1);break
    end
    tNew=saveTime(k+1);
    try
        uNew=mg_input_profile(tNew,c);
        [xNew,VNew,diag]=jiang_mkbf_native_step(model,x,V,uNew,tNew,c,layout,opt);
        if ~diag.success
            status=diag.status;reason=diag.message;
            failStepTime=tNew;break
        end
        yNew=mg_pack_dae_state(xNew,VNew,c,layout);
        if any(~isfinite(yNew)) || max(abs(yNew))>1e4
            status='FAILED_STATE_GUARD';reason='Predicted DAE state exceeds physical/numerical guard.';
            failStepTime=tNew;break
        end
        Y(k+1,:)=yNew(:).';
        lastSuccessIndex=k+1;
        x=xNew;V=VNew;
        voltageResidual(k)=diag.voltageResidualInf;
        outerIterations(k)=diag.outerIterations;
        networkIterations(k)=diag.voltageIterations;
        if opt.verbose && (mod(k,100)==0 || k==nStep)
            fprintf('    EDMD native discrete: %d/%d steps (%.2fs), residual %.3g, elapsed %.1fs\n', ...
                k,nStep,tNew,diag.voltageResidualInf,toc(stepStart));
        end
    catch ME
        status='FAILED_STEP_EXCEPTION';reason=sprintf('%s: %s',ME.identifier,ME.message);
        failStepTime=tNew;break
    end
end
elapsed=toc(stepStart);
idx=1:lastSuccessIndex;
prediction=struct();
prediction.t=saveTime(idx);
prediction.y=Y(idx,:);

% Postprocess only successfully generated state/voltage snapshots. Failure
% to compute auxiliary plots must not convert an incomplete test to success.
try
    prediction=mg_postprocess_solution(prediction.t,prediction.y,c,layout);
    % Prevent accidental interpretation of physics-computed dx as the
    % identified discrete EDMD model's vector field.
    prediction.xdot=nan(size(prediction.x));
catch ME
    warning('jiang_native:Postprocess', ...
        'Postprocess failed, raw t/y retained: %s',ME.message);
    prediction.t=saveTime(idx);
    prediction.y=Y(idx,:);
    prediction.x=prediction.y(:,1:layout.nx).';
end
prediction.metadata.methodName='jiang_mkbf_native_discrete';
prediction.metadata.methodDisplayName='Jiang EDMD/isotypic - native discrete adaptation';
prediction.metadata.modelSolveTimeSeconds=elapsed;
prediction.metadata.rolloutSucceeded=strcmp(status,'SUCCESS') && lastSuccessIndex==nStep+1;
prediction.metadata.rolloutStatus=string(status);
prediction.metadata.failureTimeSeconds=NaN;
if ~prediction.metadata.rolloutSucceeded
    prediction.metadata.failureTimeSeconds=failStepTime;
end
prediction.metadata.failureMessage=string(reason);
prediction.metadata.trajectoryCoveragePercent=100*(saveTime(lastSuccessIndex)-t0)/(tf-t0);
prediction.metadata.requestedTimeStart=t0;
prediction.metadata.requestedTimeEnd=tf;
prediction.metadata.discreteStep=dt;
prediction.metadata.couplingMode=string(get_opt(opt,'couplingMode','endpoint'));
prediction.metadata.lastValidTimeSeconds=saveTime(lastSuccessIndex);
prediction.metadata.attemptedFailureStepTime=failStepTime;
prediction.metadata.voltageResidual=voltageResidual(1:lastSuccessIndex-1);
prediction.metadata.couplingIterations=outerIterations(1:lastSuccessIndex-1);
prediction.metadata.networkNewtonIterations=networkIterations(1:lastSuccessIndex-1);
prediction.metadata.inputOracle='prescribed commands only (no future true voltage or state)';
prediction.metadata.modelScope='Adapted SG/GFM/GFL; not original author implementation';
if ~prediction.metadata.rolloutSucceeded
    fprintf('EDMD native STOP at attempted %.4fs, last valid %.4fs: %s (%s)\n', ...
        failStepTime,saveTime(lastSuccessIndex),status,reason);
end
end

function v=get_opt(s,name,default)
if isfield(s,name),v=s.(name);else,v=default;end
end
