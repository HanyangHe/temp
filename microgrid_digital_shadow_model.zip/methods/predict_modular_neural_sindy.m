function fhat = predict_modular_neural_sindy(model,~,x,V,u,c,layout)
%PREDICT_MODULAR_NEURAL_SINDY Evaluate compact fixed-neural-ridge SINDy modules.
%
% The neural ridge parameters are frozen after training. This predictor only
% evaluates the stored compact dictionary and linear coefficient matrices; no
% network training, basis reselection, or trajectory history is used online.

x = x(:);
V = V(:);
if numel(x) ~= layout.nx
    error('predict_modular_neural_sindy:StateDimension', ...
        'State length %d does not match layout.nx=%d.',numel(x),layout.nx);
end

fhat = zeros(layout.nx,1);
covered = false(layout.nx,1);

for k = 1:numel(model.sg)
    [dx,idx] = evaluate_module_local(model.sg(k),x,V,u,c,model.options);
    fhat(idx) = dx;
    covered(idx) = true;
end
for k = 1:numel(model.gfm)
    [dx,idx] = evaluate_module_local(model.gfm(k),x,V,u,c,model.options);
    fhat(idx) = dx;
    covered(idx) = true;
end
for k = 1:numel(model.gfl)
    [dx,idx] = evaluate_module_local(model.gfl(k),x,V,u,c,model.options);
    fhat(idx) = dx;
    covered(idx) = true;
end

if ~all(covered)
    missing = find(~covered);
    error('predict_modular_neural_sindy:StateCoverage', ...
        'Neural SINDy modules do not cover differential-state indices [%s].', ...
        strtrim(sprintf('%d ',missing)));
end
if any(~isfinite(fhat))
    error('predict_modular_neural_sindy:NonfiniteOutput', ...
        'Neural SINDy returned nonfinite vector-field values.');
end
end

function [dx,idx] = evaluate_module_local(module,x,V,u,c,opt)
idx = module.stateIndices(:);
if module.bus < 1 || module.bus > numel(V)
    error('predict_modular_neural_sindy:BusIndex', ...
        'Stored module bus %d is outside the voltage vector.',module.bus);
end

names = string(module.inputNames(:));
Xrow = zeros(1,numel(names));
nState = numel(idx);
if nState > numel(names)
    error('predict_modular_neural_sindy:InputLayout', ...
        'Module has %d states but only %d local input names.',nState,numel(names));
end
Xrow(1:nState) = x(idx).';

for j = (nState+1):numel(names)
    name = names(j);
    switch name
        case "Vterminal_Re"
            Xrow(j) = real(V(module.bus));
        case "Vterminal_Im"
            Xrow(j) = imag(V(module.bus));
        case "Pm"
            Xrow(j) = indexed_input_local(u,'sgPm',module.deviceIndex,c);
        case "Vref"
            Xrow(j) = indexed_input_local(u,'sgVref',module.deviceIndex,c);
        case "Pstar"
            switch lower(char(module.deviceType))
                case 'gfm'
                    Xrow(j) = indexed_input_local(u,'gfmPstar',module.deviceIndex,c);
                case 'gfl'
                    Xrow(j) = indexed_input_local(u,'gflPstar',module.deviceIndex,c);
                otherwise
                    error('predict_modular_neural_sindy:PstarDevice', ...
                        'Pstar is not defined for device type "%s".',module.deviceType);
            end
        case "Qstar"
            switch lower(char(module.deviceType))
                case 'gfm'
                    Xrow(j) = indexed_input_local(u,'gfmQstar',module.deviceIndex,c);
                case 'gfl'
                    Xrow(j) = indexed_input_local(u,'gflQstar',module.deviceIndex,c);
                otherwise
                    error('predict_modular_neural_sindy:QstarDevice', ...
                        'Qstar is not defined for device type "%s".',module.deviceType);
            end
        case "Eref"
            Xrow(j) = indexed_input_local(u,'gfmEref',module.deviceIndex,c);
        otherwise
            % The state coordinates occupy the prefix of inputNames and have
            % already been populated above. Any unknown non-state name is an
            % interface mismatch and should fail loudly rather than be guessed.
            error('predict_modular_neural_sindy:UnknownInputName', ...
                'Unknown local input name "%s" for %s%d.', ...
                name,upper(char(module.deviceType)),module.deviceIndex);
    end
end

[Theta,namesNow] = build_neural_sindy_library( ...
    Xrow,module.inputNames,module.deviceType,module.variant,opt, ...
    module.neuralBasisSeed,module.librarySpec);
if numel(namesNow) ~= numel(module.libraryNames) || ...
        any(string(namesNow(:)) ~= string(module.libraryNames(:)))
    error('predict_modular_neural_sindy:LibraryOrder', ...
        'Stored and rollout neural-library column orders do not match.');
end
if size(Theta,2) ~= size(module.coefficients,1)
    error('predict_modular_neural_sindy:CoefficientDimension', ...
        'Library width %d does not match coefficient rows %d.', ...
        size(Theta,2),size(module.coefficients,1));
end

dx = (Theta*module.coefficients).';
if numel(dx) ~= nState || any(~isfinite(dx))
    error('predict_modular_neural_sindy:ModuleOutput', ...
        '%s%d returned an invalid state derivative.', ...
        upper(char(module.deviceType)),module.deviceIndex);
end
dx = dx(:);
end

function value = indexed_input_local(u,fieldName,k,c)
if isstruct(u) && isfield(u,fieldName) && numel(u.(fieldName)) >= k
    value = u.(fieldName)(k);
    return;
end
if isstruct(c) && isfield(c,'input') && isfield(c.input,'nominal') && ...
        isfield(c.input.nominal,fieldName) && numel(c.input.nominal.(fieldName)) >= k
    value = c.input.nominal.(fieldName)(k);
    return;
end
error('predict_modular_neural_sindy:MissingInput', ...
    'Neither current input nor c.input.nominal contains %s(%d).',fieldName,k);
end
