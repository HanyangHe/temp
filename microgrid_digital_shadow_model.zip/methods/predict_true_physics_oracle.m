function fhat = predict_true_physics_oracle(model,t,x,V,u,c,layout) %#ok<INUSD>
%PREDICT_TRUE_PHYSICS_ORACLE Evaluate the exact reference vector field.

pNow = mg_parameter_profile(t,c);
[fhat,~,~] = mg_evaluate_physics(x,V,u,pNow,c,layout);
end
