function [model,info] = train_node_vector_field(dataset,c,layout,cfg)
%TRAIN_NODE_VECTOR_FIELD Train modular controlled Neural ODE DER dynamics.
%
% Training objective: multi-step short-trajectory state error.
% Deployment object: instantaneous vector field f_NODE(x,V,u), so the learned
% DER modules can be inserted into the same exact-network DAE rollout used by
% all comparison methods.
%
% v1p7d: if the dataset contains a test-initial anchor trajectory marked by
% trajectories.forceTrainingMask, that trajectory is ALWAYS assigned to the
% training partition and can never be randomly moved into validation.

if exist('dlode45','file') ~= 2 || exist('dlarray','file') ~= 2 || ...
        exist('adamupdate','file') ~= 2
    error('train_node_vector_field:MissingDeepLearningToolbox', ...
        'Neural ODE baseline requires Deep Learning Toolbox (dlode45/dlarray/adamupdate).');
end
if ~isfield(dataset,'trajectories') || ...
        ~isfield(dataset.trajectories,'xObserved')
    error('train_node_vector_field:TrajectoryDatasetRequired', ...
        'NODE requires the v1p7 short-trajectory training dataset.');
end

K = dataset.trajectories.nTrajectories;
if K < 2
    error('train_node_vector_field:TooFewTrajectories', ...
        'At least two short trajectories are required.');
end

% One common split by whole trajectory is used for every DER module.
% Forced-training trajectories (currently the test-initial anchor) are
% removed from the validation candidate pool before random splitting.
forcedTrainIds = [];
if isfield(dataset.trajectories,'forceTrainingMask') && ...
        ~isempty(dataset.trajectories.forceTrainingMask)
    mask = logical(dataset.trajectories.forceTrainingMask(:));
    if numel(mask) ~= K
        error('train_node_vector_field:ForceTrainingMaskSize', ...
            'forceTrainingMask must contain one entry per trajectory.');
    end
    forcedTrainIds = find(mask).';
end
validationCandidates = setdiff(1:K,forcedTrainIds,'stable');
if isempty(validationCandidates)
    error('train_node_vector_field:NoValidationCandidates', ...
        'All trajectories are forced into training; at least one validation candidate is required.');
end

oldRng = rng;
cleanup = onCleanup(@()rng(oldRng)); %#ok<NASGU>
rng(cfg.node.validationSeed,'twister');
permLocal = randperm(numel(validationCandidates));
perm = validationCandidates(permLocal);
nVal = max(1,round(cfg.node.validationFraction*K));
nVal = min(nVal,numel(validationCandidates));
if nVal >= K, nVal = K-1; end
valIds = sort(perm(1:nVal));
trainIds = sort(setdiff(1:K,valIds,'stable'));

if ~isempty(forcedTrainIds) && ~all(ismember(forcedTrainIds,trainIds))
    error('train_node_vector_field:ForcedTrainingSplit', ...
        'Internal error: a forceTrainingMask trajectory was not assigned to training.');
end

model.type = 'modular_controlled_neural_ode';
model.trainingSampleDefinition = 'short trajectories';
if isfield(cfg.node,'trainingProtocolVersion')
    model.trainingProtocolVersion = cfg.node.trainingProtocolVersion;
else
    model.trainingProtocolVersion = 'legacy_full_trajectory';
end
model.sg = struct([]);
model.gfm = struct([]);
model.gfl = struct([]);

moduleInfo = struct([]);
mi = 0;
totalParams = 0;

for k = 1:numel(c.sg)
    fprintf('    Training NODE module SG%d (Bus %d)...\n',k,c.sg(k).bus);
    data = build_node_module_trajectory_data(dataset,c,layout,'sg',k);
    [mk,ik] = train_node_module(data,trainIds,valIds,cfg,100*k);
    if k==1, model.sg=mk; else, model.sg(k,1)=mk; end
    mi = mi + 1;
    if mi == 1
        moduleInfo = ik;
    else
        moduleInfo(mi,1) = ik; %#ok<AGROW>
    end
    totalParams = totalParams + ik.parameterCount;
end
for k = 1:numel(c.gfm)
    fprintf('    Training NODE module GFM%d (Bus %d)...\n',k,c.gfm(k).bus);
    data = build_node_module_trajectory_data(dataset,c,layout,'gfm',k);
    [mk,ik] = train_node_module(data,trainIds,valIds,cfg,10000+100*k);
    if k==1, model.gfm=mk; else, model.gfm(k,1)=mk; end
    mi = mi + 1;
    if mi == 1
        moduleInfo = ik;
    else
        moduleInfo(mi,1) = ik; %#ok<AGROW>
    end
    totalParams = totalParams + ik.parameterCount;
end
for k = 1:numel(c.gfl)
    fprintf('    Training NODE module GFL%d (Bus %d)...\n',k,c.gfl(k).bus);
    data = build_node_module_trajectory_data(dataset,c,layout,'gfl',k);
    [mk,ik] = train_node_module(data,trainIds,valIds,cfg,20000+100*k);
    if k==1, model.gfl=mk; else, model.gfl(k,1)=mk; end
    mi = mi + 1;
    if mi == 1
        moduleInfo = ik;
    else
        moduleInfo(mi,1) = ik; %#ok<AGROW>
    end
    totalParams = totalParams + ik.parameterCount;
end

model.parameterCount = totalParams;
model.trainTrajectoryIds = trainIds;
model.validationTrajectoryIds = valIds;
model.forcedTrainingTrajectoryIds = forcedTrainIds(:);

info.method = 'modular_controlled_neural_ode';
info.objective = 'multi-step short-trajectory state loss';
info.trainingProtocolVersion = model.trainingProtocolVersion;
info.gradientMode = cfg.node.gradientMode;
info.nSamples = size(dataset.features,1);
info.pointsPerTrajectory = dataset.trajectories.pointsPerTrajectory;
if isfield(cfg.node,'trainingWindowPoints')
    info.trainingWindowPoints = cfg.node.trainingWindowPoints;
else
    info.trainingWindowPoints = dataset.trajectories.pointsPerTrajectory;
end
info.trainingWindowsPerTrajectory = ...
    dataset.trajectories.pointsPerTrajectory / info.trainingWindowPoints;
info.nTrainingWindows = numel(trainIds) * info.trainingWindowsPerTrajectory;
info.validationUsesOriginalFullTrajectories = true;
info.nTrajectories = K;
info.nTrainTrajectories = numel(trainIds);
info.nValidationTrajectories = numel(valIds);
info.trainTrajectoryIds = trainIds(:);
info.validationTrajectoryIds = valIds(:);
info.forcedTrainingTrajectoryIds = forcedTrainIds(:);
info.modules = moduleInfo;
info.parameterCount = totalParams;

if ~isempty(forcedTrainIds)
    fprintf('    Forced into NODE training partition: trajectory ID(s) [%s]\n', ...
        strtrim(sprintf('%d ',forcedTrainIds)));
end
end
