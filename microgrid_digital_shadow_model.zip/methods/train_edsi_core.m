function [model,info] = train_edsi_core(dataset,c,layout,cfg,mode)
%TRAIN_EDSI_CORE Formal EDSI / LLM-EDSI trainer used by offline campaigns.
%
% mode:
%   "edsi"     : Full fixed-width EDSI.
%   "llm_edsi" : one-shot semantic LLM initialization refinement followed by
%                the same Full EDSI evolution.
%   "llm_prior_edsi" : diagnostic EDSI initialized by a pre-discovered weak-domain
%                LLM prior bank; no cloud call occurs inside evolution.
%   "llm_prior_fixedwidth_sindy" : same weak-domain LLM proposal/distillation
%                stage, compressed to the original EDSI width, then full
%                STLSQ identification with NO evolutionary search.
%   "llm_prior_augmented_edsi" : immutable LLM-prior residual refinement.
%                The full low-dimensional LLM prior bank is identified once
%                and frozen; ONLY the original V-width bank evolves against
%                the remaining residual. No prior compression is performed.
%
% Both methods learn only DER differential dynamics. The electrical-network
% algebraic equations remain exact and are shared by every offline method.
%
% Scientific invariants:
%   - V-SINDy initialization = [1,x,Q2_narrow,sin(x),cos(x)]
%   - fixed dictionary width throughout evolution
%   - protected anchors [1,x]
%   - search-stage STLSQ with 1--3 cheap threshold/refit turns (formal: 2)
%   - full 10-turn STLSQ final refit with the same identification backend
%     as V-SINDy: OLS-STLSQ support discovery; exact labels get fixed
%     frozen-support rho=1e-10, reconstructed noisy labels get the shared
%     validation-selected support-preserving ridge
%   - pointwise held-out vector-field fitness inside evolution
%   - no trajectory simulation inside generations; one held-out short-rollout
%     champion check is used only after the residual search
%   - Full EDSI P=32, K=8, G<=30, stall patience=7
%
% LLM-EDSI invariant:
%   one semantic LLM intervention at initialization (default generation 1);
%   the LLM sees explicit physical variable meanings plus a compact sparse ODE
%   and active-term summary; it returns only a small structural edit proposal.
%   The local adapter reconstructs the complete fixed-width dictionary. Parent
%   elites survive unchanged and all proposals are re-fit and judged by the
%   same search-stage sparse STLSQ objective.

if nargin < 5 || isempty(mode)
    mode = "edsi";
end
mode = lower(string(mode));

opt = get_edsi_options(cfg);
if ~opt.enabled
    error('train_edsi_core:Disabled','cfg.edsi.enabled is false.');
end

probe = make_edsi_probe_local(opt,mode);

sopt = get_sindy_options(cfg);
if sopt.polyOrderOption ~= 2 || ~logical(sopt.includeSin) || ~logical(sopt.includeCos)
    error('train_edsi_core:VInitialization', ...
        ['EDSI requires V-SINDy initialization [1,x,Q2_narrow,sin,cos] ', ...
         'with cfg.sindy.polyOrderOption=2 and sin/cos enabled.']);
end

[trainIds,valIds,trainMask,valMask,forcedTrainIds] = ...
    trajectory_split_local(dataset,sopt);

model = base_model_local(char(probe.methodName),trainIds,valIds,forcedTrainIds);
model.rho = probe.rho;
model.options = sopt;
model.sg = struct([]);
model.gfm = struct([]);
model.gfl = struct([]);

modules = struct([]);
history = struct([]);
events = table();
apiLog = table();
mi = 0;
hi = 0;

if mode == "llm_edsi"
    if ~opt.llm.enabled
        error('train_edsi_core:LLMDisabled', ...
            'LLM-EDSI was requested but cfg.llmEdsi.enabled is false.');
    end
    refine = make_formal_llm_refine_local(dataset,cfg,opt,probe);
else
    refine = struct();
end
if any(mode == ["llm_prior_edsi","llm_prior_fixedwidth_sindy","llm_prior_augmented_edsi"])
    if ~isfield(sopt,'llmPriorDiagnostic') || ...
            ~logical(sopt.llmPriorDiagnostic.enabled)
        error('train_edsi_core:LLMPriorDiagnosticDisabled', ...
            'cfg.sindy.llmPriorDiagnostic.enabled must be true.');
    end
end

for k = 1:numel(c.sg)
    data = build_sindy_module_data(dataset,c,layout,'sg',k);
    if mode == "llm_edsi"
        [mk,ik,hk,diag] = fit_edsi_module_ode_prior_local( ...
            data,trainMask,valMask,sopt,probe,cfg.randomSeed,refine);
        events = append_table_local(events,diag.events);
        apiLog = append_table_local(apiLog,diag.api);
    elseif any(mode == ["llm_prior_edsi","llm_prior_fixedwidth_sindy","llm_prior_augmented_edsi"])
        [priorTerms,priorMeta] = llm_prior_bank_terms_local(sopt,data.deviceType);
        [mk,ik,hk] = fit_edsi_module_local( ...
            data,trainMask,valMask,sopt,probe,cfg.randomSeed,priorTerms,priorMeta, ...
            mode == "llm_prior_fixedwidth_sindy", ...
            mode == "llm_prior_augmented_edsi");
    else
        [mk,ik,hk] = fit_edsi_module_local( ...
            data,trainMask,valMask,sopt,probe,cfg.randomSeed,strings(0,1),struct([]));
    end
    if k==1, model.sg=mk; else, model.sg(k,1)=mk; end
    [modules,mi] = append_struct_local(modules,mi,ik);
    [history,hi] = append_history_local( ...
        history,hi,hk,data.deviceType,data.deviceIndex);
end

for k = 1:numel(c.gfm)
    data = build_sindy_module_data(dataset,c,layout,'gfm',k);
    if mode == "llm_edsi"
        [mk,ik,hk,diag] = fit_edsi_module_ode_prior_local( ...
            data,trainMask,valMask,sopt,probe,cfg.randomSeed,refine);
        events = append_table_local(events,diag.events);
        apiLog = append_table_local(apiLog,diag.api);
    elseif any(mode == ["llm_prior_edsi","llm_prior_fixedwidth_sindy","llm_prior_augmented_edsi"])
        [priorTerms,priorMeta] = llm_prior_bank_terms_local(sopt,data.deviceType);
        [mk,ik,hk] = fit_edsi_module_local( ...
            data,trainMask,valMask,sopt,probe,cfg.randomSeed,priorTerms,priorMeta, ...
            mode == "llm_prior_fixedwidth_sindy", ...
            mode == "llm_prior_augmented_edsi");
    else
        [mk,ik,hk] = fit_edsi_module_local( ...
            data,trainMask,valMask,sopt,probe,cfg.randomSeed,strings(0,1),struct([]));
    end
    if k==1, model.gfm=mk; else, model.gfm(k,1)=mk; end
    [modules,mi] = append_struct_local(modules,mi,ik);
    [history,hi] = append_history_local( ...
        history,hi,hk,data.deviceType,data.deviceIndex);
end

for k = 1:numel(c.gfl)
    data = build_sindy_module_data(dataset,c,layout,'gfl',k);
    if mode == "llm_edsi"
        [mk,ik,hk,diag] = fit_edsi_module_ode_prior_local( ...
            data,trainMask,valMask,sopt,probe,cfg.randomSeed,refine);
        events = append_table_local(events,diag.events);
        apiLog = append_table_local(apiLog,diag.api);
    elseif any(mode == ["llm_prior_edsi","llm_prior_fixedwidth_sindy","llm_prior_augmented_edsi"])
        [priorTerms,priorMeta] = llm_prior_bank_terms_local(sopt,data.deviceType);
        [mk,ik,hk] = fit_edsi_module_local( ...
            data,trainMask,valMask,sopt,probe,cfg.randomSeed,priorTerms,priorMeta, ...
            mode == "llm_prior_fixedwidth_sindy", ...
            mode == "llm_prior_augmented_edsi");
    else
        [mk,ik,hk] = fit_edsi_module_local( ...
            data,trainMask,valMask,sopt,probe,cfg.randomSeed,strings(0,1),struct([]));
    end
    if k==1, model.gfl=mk; else, model.gfl(k,1)=mk; end
    [modules,mi] = append_struct_local(modules,mi,ik);
    [history,hi] = append_history_local( ...
        history,hi,hk,data.deviceType,data.deviceIndex);
end

info = common_train_info_local(char(probe.methodName), ...
    dataset,trainMask,valMask,trainIds,valIds,forcedTrainIds,modules);
info.displayName = char(probe.displayName);
info.formulationVersion = char(probe.formulationVersion);
info.evolutionSearchSeed = probe.evolutionSearchSeed;
info.rho = probe.rho;
info.evolutionHistory = history;
if mode == "llm_prior_fixedwidth_sindy"
    info.nominalCandidateEvaluationsPerModule = 2; % V parent + one distilled prior candidate
else
    info.nominalCandidateEvaluationsPerModule = ...
        probe.populationSize + probe.maxGenerations*(probe.populationSize-probe.eliteCount);
end
info.noiseLevel = dataset_noise_level_local(dataset);

if mode == "llm_edsi"
    info.objective = [ ...
        'one-shot semantic LLM sparse-structure refinement followed by EDSI; ', ...
        'two-turn STLSQ search fitness + full ten-turn final STLSQ'];
    info.llmInitializationOnly = true;
    info.llmInitialGeneration = refine.generations(1);
    info.llmRefinedEliteCount = refine.parentEliteCount;
    info.llmEvents = events;
    info.llmApiLog = apiLog;
    info.llmCloudCalls = sum_table_numeric_ode_local(apiLog,'CloudCallCount');
    info.llmInputTokens = sum_table_numeric_ode_local(apiLog,'InputTokens');
    info.llmOutputTokens = sum_table_numeric_ode_local(apiLog,'OutputTokens');
    info.llmEstimatedCostUSD = sum_table_numeric_ode_local(apiLog,'EstimatedCostUSD');
    info.llmApiLatencySeconds = sum_table_numeric_ode_local(apiLog,'LatencySeconds');
elseif mode == "llm_prior_edsi"
    info.objective = [ ...
        'weak-domain LLM prior-bank seeded fixed-width EDSI; no cloud call ', ...
        'inside evolution; shared V-SINDy identification backend'];
    info.llmInitializationOnly = true;
    info.llmPriorBankSeeded = true;
    info.llmCloudCalls = 0;
    info.llmEstimatedCostUSD = 0;
    info.llmApiLatencySeconds = 0;
    info.priorBankHash = char(string(sopt.llmPriorDiagnostic.priorBankHash));
elseif mode == "llm_prior_augmented_edsi"
    info.objective = [ ...
        'weak-domain LLM prior bank retained without compression; its identified ', ...
        'basis and coefficients are frozen while the original V-SINDy-width bank ', ...
        'evolves only on the remaining residual; final champion uses held-out ', ...
        'short-trajectory rollout validation'];
    info.llmInitializationOnly = true;
    info.llmPriorBankSeeded = true;
    info.llmPriorAugmentedNoCompression = true;
    info.llmCloudCalls = 0;
    info.llmEstimatedCostUSD = 0;
    info.llmApiLatencySeconds = 0;
    info.priorBankHash = char(string(sopt.llmPriorDiagnostic.priorBankHash));
elseif mode == "llm_prior_fixedwidth_sindy"
    info.objective = [ ...
        'weak-domain LLM prior proposal pool compressed to original fixed width; ', ...
        'full shared STLSQ identification; no evolutionary search'];
    info.llmInitializationOnly = true;
    info.llmPriorBankSeeded = true;
    info.fixedWidthNoEvolution = true;
    info.llmCloudCalls = 0;
    info.llmEstimatedCostUSD = 0;
    info.llmApiLatencySeconds = 0;
    info.priorBankHash = char(string(sopt.llmPriorDiagnostic.priorBankHash));
else
    info.objective = ...
        'Fixed-width EDSI; two-turn STLSQ search fitness + full ten-turn final STLSQ';
    info.llmInitializationOnly = false;
    info.llmCloudCalls = 0;
    info.llmEstimatedCostUSD = 0;
    info.llmApiLatencySeconds = 0;
end
end


function probe = make_edsi_probe_local(opt,mode)
probe = struct();
probe.rho = opt.finalSupportRidgeRho; % legacy/report alias
probe.supportDiscoveryRho = opt.supportDiscoveryRho;
probe.finalSupportRidgeRho = opt.finalSupportRidgeRho;
probe.searchStlsqIterations = opt.searchStlsqIterations;
probe.searchThresholdGrid = opt.searchThresholdGrid;
probe.searchPreferSparseWithinRelativeValidationTolerance = ...
    opt.searchPreferSparseWithinRelativeValidationTolerance;
probe.finalStlsqIterations = opt.finalStlsqIterations;
probe.finalThresholdGrid = opt.finalThresholdGrid;
probe.finalPreferSparseWithinRelativeValidationTolerance = ...
    opt.finalPreferSparseWithinRelativeValidationTolerance;
probe.shareSindyIdentificationBackend = opt.shareSindyIdentificationBackend;
probe.searchLambda = NaN; % base EDSI: initial V; v8 prior EDSI: residual recalibration
probe.searchSupportRidgeRelativeAlpha = 0; % selected on the actual search target
probe.supportRidgeApplied = false;
probe.supportRidgeConfigured = false;
probe.supportRidgePolicy = 'never';
probe.supportRidgeRelativeAlphaGrid = 0;
probe.supportRidgeTieRelativeValidationTolerance = 0;
probe.validationAbsoluteTolerance = 1e-12;
probe.nTrainSamples = NaN;
probe.productProbability = opt.productProbability;
probe.sinProbability = opt.sinProbability;
probe.cosProbability = opt.cosProbability;
probe.maxBasisDepth = opt.maxBasisDepth;
probe.maxBasisComplexity = opt.maxBasisComplexity;
probe.maxBasisAbsValue = opt.maxBasisAbsValue;
probe.libraryScaleFloor = opt.libraryScaleFloor;
probe.outputScaleFloor = opt.outputScaleFloor;
probe.maxChildRetries = opt.maxChildRetries;
probe.printEvery = opt.printEvery;
probe.populationSize = opt.populationSize;
probe.eliteCount = opt.eliteCount;
probe.maxGenerations = opt.maxGenerations;
probe.stallPatience = opt.stallPatience;
probe.minRelativeImprovement = opt.minRelativeImprovement;
probe.mutationSlotCounts = opt.mutationSlotCounts;
probe.mutationSlotProbabilities = opt.mutationSlotProbabilities;
probe.useSaliencyGuidance = false;
probe.guidedReplaceProbability = 0.80;
probe.guidedParentProbability = 0.80;
probe.guidanceFloorFraction = 0.10;
probe.evolutionSearchSeed = opt.evolutionSearchSeed;
probe.residualRefinementShortRolloutEnabled = opt.residualRefinementShortRolloutEnabled;
probe.residualChampionMinRelativeImprovement = opt.residualChampionMinRelativeImprovement;
probe.offspringPerElite = ...
    (probe.populationSize-probe.eliteCount)/probe.eliteCount;

if mode == "llm_edsi"
    probe.methodName = "llm_edsi";
    probe.displayName = "LLM-EDSI";
    probe.variantId = "llm_initialization";
    probe.formulationVersion = string(opt.llm.formulationVersion);
elseif mode == "llm_prior_edsi"
    probe.methodName = "llm_prior_edsi_diagnostic";
    probe.displayName = "LLM-Prior EDSI";
    probe.variantId = "weak_domain_fixed_width_prior_seed_v5";
    probe.formulationVersion = "llm_prior_fixedwidth_motifclosure_seqcompress_swap_v5_ols_support";
elseif mode == "llm_prior_augmented_edsi"
    probe.methodName = "llm_prior_augmented_edsi_diagnostic";
    probe.displayName = "LLM-Prior EDSI";
    probe.variantId = "weak_domain_immutable_prior_residual_refinement_v8";
    probe.formulationVersion = "llm_prior_immutable_bank_residual_edsi_v8_ols_support";
elseif mode == "llm_prior_fixedwidth_sindy"
    probe.methodName = "llm_prior_fixedwidth_sindy_diagnostic";
    probe.displayName = "LLM-Prior FW-SINDy";
    probe.variantId = "weak_domain_fixed_width_no_evolution_v6";
    probe.formulationVersion = "llm_prior_fixedwidth_distilled_noevolution_v6_ols_support";
else
    probe.methodName = "edsi";
    probe.displayName = "ED-SINDy";
    probe.variantId = "full";
    probe.formulationVersion = string(opt.formulationVersion);
end

if probe.eliteCount < 1 || probe.populationSize <= probe.eliteCount || ...
        mod(probe.populationSize-probe.eliteCount,probe.eliteCount) ~= 0
    error('make_edsi_probe_local:PopulationArithmetic', ...
        'EDSI requires P>K and (P-K) divisible by K.');
end
end


function refine = make_formal_llm_refine_local(dataset,cfg,opt,probe)
llm = opt.llm;
refine = struct();

if llm.maxCalls ~= 1
    error('make_formal_llm_refine_local:InitializationOnly', ...
        ['Formal LLM-EDSI is frozen to one initialization refinement. ', ...
         'Set cfg.llmEdsi.maxCalls=1.']);
end
refine.generations = llm.initialGeneration;
if refine.generations < 1 || refine.generations > probe.maxGenerations
    error('make_formal_llm_refine_local:Generation', ...
        'LLM initialization generation must lie inside [1,%d].',probe.maxGenerations);
end

refine.parentEliteCount = llm.refinedEliteCount;
refine.currentOdeTermsPerDerivative = llm.currentOdeTermsPerDerivative;
refine.maxActiveDictionaryTerms = llm.maxActiveDictionaryTerms;
refine.inactiveContextTerms = llm.inactiveContextTerms;
refine.maxProposedTerms = llm.maxProposedTerms;
refine.maxLLMExpressionDepth = llm.maxExpressionDepth;
refine.maxLLMExpressionComplexity = llm.maxExpressionComplexity;
refine.adapterPath = char(llm.adapterPath);
refine.config = load_ode_prior_llm_config_local( ...
    char(llm.configPath),char(llm.adapterPath));

projectRoot = fileparts(fileparts(mfilename('fullpath')));
if isfield(cfg,'output') && isfield(cfg.output,'folderName') && ...
        ~isempty(cfg.output.folderName)
    runOutput = fullfile(projectRoot,'outputs',char(string(cfg.output.folderName)));
else
    runOutput = fullfile(projectRoot,'outputs','offline_model_experiments');
end

conditionTag = llm_condition_tag_local(dataset,cfg);
refine.seedRoot = fullfile(runOutput,'method_results','llm_edsi', ...
    'llm_runtime',conditionTag);
if exist(refine.seedRoot,'dir') ~= 7
    mkdir(refine.seedRoot);
end
end


function tag = llm_condition_tag_local(dataset,cfg)
N = size(dataset.x,1);
noise = dataset_noise_level_local(dataset);
seed = NaN;
if isfield(cfg,'randomSeed'), seed = double(cfg.randomSeed); end

noiseText = sprintf('%.12g',100*noise);
noiseText = strrep(noiseText,'-','m');
noiseText = strrep(noiseText,'+','p');
noiseText = strrep(noiseText,'.','p');

protocol = "clean_exact_vector_field";
if isfield(dataset,'metadata') && isstruct(dataset.metadata) && ...
        isfield(dataset.metadata,'trainingNoiseProtocol') && ...
        strlength(string(dataset.metadata.trainingNoiseProtocol))>0
    protocol = string(dataset.metadata.trainingNoiseProtocol);
end
protocol = string(regexprep(char(protocol),'[^A-Za-z0-9_\-]','_'));

tag = sprintf('seed_%d_N%d_noise%spct_%s',round(seed),N,noiseText,char(protocol));
end


function noise = dataset_noise_level_local(dataset)
noise = 0;
if isfield(dataset,'metadata') && isstruct(dataset.metadata) && ...
        isfield(dataset.metadata,'trainingNoiseLevel') && ...
        ~isempty(dataset.metadata.trainingNoiseLevel)
    q = double(dataset.metadata.trainingNoiseLevel);
    if isscalar(q) && isfinite(q), noise = q; end
end
end


function [module,info,history,diag]=fit_edsi_module_ode_prior_local( ...
    data,trainMask,valMask,opt,probe,dataSeed,refine)

Xtr=double(data.X(trainMask,:));
Xva=double(data.X(valMask,:));
Ytr=double(data.Y(trainMask,:));
Yva=double(data.Y(valMask,:));

yScale=std(Ytr,0,1);
yRms=sqrt(mean(Ytr.^2,1));
yScale=max(yScale,0.05*yRms);
yScale=max(yScale,probe.outputScaleFloor);
Btr=Ytr./yScale;
Bva=Yva./yScale;

% Match V-SINDy numerical identification exactly for this data protocol.
% In noisy reconstructed-derivative cases this activates the same
% validation-selected frozen-support ridge used by V-SINDy.
probe=configure_support_ridge_probe_local(probe,opt,data,size(Xtr,1));

baseBasis=make_initial_v_dictionary_local(string(data.inputNames(:)));
protectedMask=false(numel(baseBasis),1);
protectedMask(1:(1+size(Xtr,2)))=true;

% Fail loudly if semantic context cannot be unambiguously constructed.
semantic=make_semantic_context_ode_local(data);

[ThetaOfficial,namesOfficial]=build_sindy_library( ...
    data.X,data.inputNames,data.deviceType,'vanilla',opt,[]);
ThetaLocal=evaluate_dictionary_raw_local(baseBasis,double(data.X));
basisAgreement=max(abs(ThetaOfficial(:)-ThetaLocal(:)));
if ~isfinite(basisAgreement) || basisAgreement>1e-11
    error('fit_edsi_module_ode_prior_local:VLibraryMismatch', ...
        'V initialization differs from official library: %.3e.',basisAgreement);
end

M=numel(baseBasis);

% EXACT official Full-EDSI RNG construction.
typeCode=device_type_code_local(data.deviceType);
rngSeed=mod(double(dataSeed)+100000*typeCode + ...
    1009*double(data.deviceIndex)+17*size(data.X,1)+ ...
    104729*double(probe.evolutionSearchSeed),2^32-1);
if rngSeed<1, rngSeed=rngSeed+1; end
oldRng=rng;
cleanupRng=onCleanup(@()rng(oldRng)); %#ok<NASGU>
rng(rngSeed,'twister');

featureCache=containers.Map('KeyType','char','ValueType','any');

base=build_candidate_from_scratch_local( ...
    baseBasis,protectedMask,Xtr,Xva,Btr,Bva,probe,featureCache);
[searchFit,~]=select_stlsq_fit_local( ...
    base,Btr,Bva,probe.searchThresholdGrid,probe.searchStlsqIterations, ...
    probe,probe.searchPreferSparseWithinRelativeValidationTolerance);
probe.searchLambda=searchFit.lambda;
probe.searchSupportRidgeRelativeAlpha=searchFit.supportRidgeRelativeAlpha;
base=score_candidate_local(base,Btr,Bva,probe);
baseInitialFitness=base.fitness;

population=cell(probe.populationSize,1);
population{1}=base;
seen=containers.Map('KeyType','char','ValueType','logical');
seen(base.dictionaryKey)=true;

for p=2:probe.populationSize
    child=unique_mutated_child_local( ...
        base,seen,Xtr,Xva,Btr,Bva,probe,featureCache);
    population{p}=child;
    seen(child.dictionaryKey)=true;
end

history=repmat(history_template_local(),0,1);
diag=struct();
diag.events=table();
diag.api=table();

globalBest=base;
stallCount=0;

[elites,stats]=select_elites_local(population,probe.eliteCount);
if elites{1}.fitness<globalBest.fitness
    globalBest=elites{1};
end
history(end+1,1)=make_history_row_local(0,stats,globalBest,stallCount); %#ok<AGROW>

fprintf(['      %s%d | %s init | width=%d | search STLSQ-%d lambda=%.3g ', ...
    '| support-ridge rho=%.3g | V val=%.3e | population best=%.3e\n'], ...
    upper(char(data.deviceType)),data.deviceIndex,char(probe.displayName),M, ...
    probe.searchStlsqIterations,probe.searchLambda, ...
    probe.searchSupportRidgeRelativeAlpha,baseInitialFitness,globalBest.fitness);

lastMeaningfulBest=globalBest.fitness;
lastGeneration=0;

for gen=1:probe.maxGenerations
    intervene=any(gen==refine.generations);
    plans=struct([]);

    if intervene
        nParents=min(refine.parentEliteCount,probe.eliteCount);
        [plans,apiRow]=invoke_ode_prior_llm_local( ...
            elites(1:nParents),data,yScale,semantic,gen,probe,refine);
        if ~isempty(apiRow)
            diag.api=append_table_local(diag.api,apiRow);
        end
    end

    nextPopulation=cell(probe.populationSize,1);
    for e=1:probe.eliteCount
        nextPopulation{e}=elites{e};
    end

    seenNext=containers.Map('KeyType','char','ValueType','logical');
    for e=1:probe.eliteCount
        seenNext(elites{e}.dictionaryKey)=true;
    end

    cursor=probe.eliteCount;

    for e=1:probe.eliteCount
        parent=elites{e};

        for b=1:probe.offspringPerElite
            cursor=cursor+1;

            % IMPORTANT FOR RNG FAIRNESS:
            % Generate the ordinary Full-EDSI child first in every slot, even
            % when an LLM child will replace it.
            ordinary=unique_mutated_child_local( ...
                parent,seenNext,Xtr,Xva,Btr,Bva,probe,featureCache);

            child=ordinary;
            source="ordinary";
            valid=false;
            summary="";
            priorSummary="";
            diagnosis="";
            confidence=NaN;

            doLLM=intervene && ...
                e<=min(refine.parentEliteCount,probe.eliteCount) && b==1;

            if doLLM
                plan=find_ode_prior_plan_local(plans,e);
                [llmChild,valid,summary,priorSummary,diagnosis,confidence]= ...
                    candidate_from_llm_structural_edit_local( ...
                        parent,plan,seenNext,Xtr,Xva,Btr,Bva, ...
                        probe,featureCache,refine,data.inputNames);

                if valid
                    child=llmChild;
                    source="llm_sparse_structural_edit";
                else
                    source="ordinary_fallback_invalid_llm";
                end

                event=ode_prior_event_row_local( ...
                    data,gen,e,source,parent,child,valid,confidence, ...
                    summary,priorSummary,diagnosis);
                diag.events=append_table_local(diag.events,event);
            end

            nextPopulation{cursor}=child;
            seenNext(child.dictionaryKey)=true;
        end
    end

    population=nextPopulation;
    [elites,stats]=select_elites_local(population,probe.eliteCount);

    previousGlobal=globalBest.fitness;
    if elites{1}.fitness<globalBest.fitness
        globalBest=elites{1};
    end

    relativeImprovement=(previousGlobal-globalBest.fitness)/max(previousGlobal,eps);
    if relativeImprovement>probe.minRelativeImprovement
        stallCount=0;
        lastMeaningfulBest=globalBest.fitness;
    else
        stallCount=stallCount+1;
    end

    history(end+1,1)=make_history_row_local( ...
        gen,stats,globalBest,stallCount); %#ok<AGROW>
    lastGeneration=gen;

    if gen==1 || mod(gen,probe.printEvery)==0 || ...
            stallCount>=probe.stallPatience || gen==probe.maxGenerations
        fprintf(['      %s%d | %s gen=%02d | best=%.3e | median=%.3e | ', ...
            'global=%.3e | C=%d | unique=%d/%d | stall=%d\n'], ...
            upper(char(data.deviceType)),data.deviceIndex,char(probe.displayName),gen, ...
            stats.bestFitness,stats.medianFitness,globalBest.fitness, ...
            globalBest.dictionaryComplexity,stats.uniqueCount, ...
            probe.populationSize,stallCount);
    end

    if stallCount>=probe.stallPatience
        break;
    end
end

[finalFit,finalSweep]=select_stlsq_fit_local( ...
    globalBest,Btr,Bva,probe.finalThresholdGrid,probe.finalStlsqIterations, ...
    probe,probe.finalPreferSparseWithinRelativeValidationTolerance);
colScale=globalBest.colScale(:);
finalXi=finalFit.XiNormalized;
coefPhysical=(finalXi./colScale).*yScale;

module=struct();
module.type='edsi_fixed_width_module';
module.formulationVersion=char(probe.formulationVersion);
module.deviceType=char(data.deviceType);
module.deviceIndex=data.deviceIndex;
module.bus=data.bus;
module.stateIndices=data.stateIndices(:);
module.inputNames=string(data.inputNames(:));
module.outputNames=string(data.outputNames(:));
module.dictionary=globalBest.basis;
module.libraryNames=string(cellfun(@(q)q.label,globalBest.basis, ...
    'UniformOutput',false)).';
module.coefficients=coefPhysical;
module.coefficientsNormalized=finalXi;
module.columnScale=colScale;
module.outputScale=yScale(:);
module.rho=probe.finalSupportRidgeRho;
module.supportDiscoveryRho=probe.supportDiscoveryRho;
module.fixedFinalSupportRidgeRho=probe.finalSupportRidgeRho;
module.identificationBackend='shared_v_sindy_ols_support_fixedrho_noise_ridge_v2';
module.supportRidgeApplied=probe.supportRidgeApplied;
module.supportRidgePolicy=probe.supportRidgePolicy;
module.searchSupportRidgeRelativeAlpha=probe.searchSupportRidgeRelativeAlpha;
module.selectedSupportRidgeRelativeAlpha=finalFit.supportRidgeRelativeAlpha;
module.searchStlsqIterations=probe.searchStlsqIterations;
module.searchThreshold=probe.searchLambda;
module.searchValidationNormalizedMSE=globalBest.fitness;
module.searchTrainNormalizedMSE=globalBest.trainFitness;
module.searchActiveCoefficientCount=nnz(abs(globalBest.XiNormalized)>0);
module.finalStlsqIterations=probe.finalStlsqIterations;
module.selectedThreshold=finalFit.lambda;
module.activeCoefficientCount=finalFit.activeCoefficientCount;
module.finalThresholdSweep=finalSweep;
module.dictionaryWidth=M;
module.protectedWidth=nnz(protectedMask);
module.evolvableWidth=M-nnz(protectedMask);
module.dictionaryComplexity=globalBest.dictionaryComplexity;
module.maxBasisDepth=max(cellfun(@(q)q.depth,globalBest.basis));
module.validationNormalizedMSE=finalFit.validationNormalizedMSE;
module.trainNormalizedMSE=finalFit.trainNormalizedMSE;
module.initialValidationNormalizedMSE=baseInitialFitness;
module.evolutionBestValidationNormalizedMSE=globalBest.fitness;
module.fitnessGainLog10=log10(max(baseInitialFitness,realmin)/ ...
    max(finalFit.validationNormalizedMSE,realmin));
module.generationCount=lastGeneration;
module.coefficientFroNorm=norm(coefPhysical,'fro');
module.normalizedCoefficientFroNorm=finalFit.normalizedCoefficientFroNorm;
module.rngSeed=rngSeed;
module.evolutionSearchSeed=probe.evolutionSearchSeed;
module.variantId=char(probe.variantId);
module.variantDisplayName=char(probe.displayName);
module.populationSize=probe.populationSize;
module.eliteCount=probe.eliteCount;
module.maxGenerations=probe.maxGenerations;
module.nominalCandidateEvaluations=probe.populationSize + ...
    lastGeneration*(probe.populationSize-probe.eliteCount);
module.useSaliencyGuidance=probe.useSaliencyGuidance;
module.officialVAgreementMaxAbs=basisAgreement;
module.officialVLibraryNames=string(namesOfficial(:));
module.bestDictionaryKey=string(globalBest.dictionaryKey);
module.referenceMeaningfulBest=lastMeaningfulBest;

info=module;

fprintf(['      %s%d | %s SEARCH BEST | gen=%d | width=%d | val %.3e -> %.3e ', ...
    '| complexity=%d | maxDepth=%d\n'], ...
    upper(char(data.deviceType)),data.deviceIndex,char(probe.displayName),lastGeneration,M, ...
    baseInitialFitness,globalBest.fitness,module.dictionaryComplexity,module.maxBasisDepth);
fprintf(['      %s%d | %s FINAL STLSQ-%d | lambda=%.3g | support-ridge rho=%.3g ', ...
    '| active=%d/%d | train nMSE=%.3e | val nMSE=%.3e\n'], ...
    upper(char(data.deviceType)),data.deviceIndex,char(probe.displayName), ...
    probe.finalStlsqIterations,module.selectedThreshold, ...
    module.selectedSupportRidgeRelativeAlpha,module.activeCoefficientCount, ...
    numel(finalXi),module.trainNormalizedMSE,module.validationNormalizedMSE);
end


%% ========================================================================
% Semantic context: every symbol has an explicit meaning
% ========================================================================


function ctx=make_semantic_context_ode_local(data)
type=lower(string(data.deviceType));
nIn=numel(data.inputNames);
nOut=numel(data.outputNames);

switch type
    case "sg"
        expectedIn=9; expectedOut=5;
        symbols=["delta_g","nu_g","Eq_prime_g","Ed_prime_g","Efd_g", ...
            "V_R_g","V_I_g","P_m_g","V_ref_g"];
        meanings=[ ...
            "rotor electrical angle relative to the network reference", ...
            "normalized rotor speed deviation", ...
            "q-axis transient internal voltage", ...
            "d-axis transient internal voltage", ...
            "excitation/field voltage state", ...
            "real component of terminal-bus voltage in the network reference frame", ...
            "imaginary component of terminal-bus voltage in the network reference frame", ...
            "mechanical power input", ...
            "automatic-voltage-regulator voltage reference"];
        roles=["dynamic state","dynamic state","dynamic state","dynamic state", ...
            "dynamic state","network/algebraic input","network/algebraic input", ...
            "operating input","operating reference"];
        units=["rad","p.u.","p.u.","p.u.","p.u.","p.u.","p.u.","p.u.","p.u."];
        derivativeMeaning=[ ...
            "time derivative of rotor electrical angle", ...
            "time derivative of normalized rotor speed deviation", ...
            "time derivative of q-axis transient internal voltage", ...
            "time derivative of d-axis transient internal voltage", ...
            "time derivative of excitation/field voltage"];
        systemDesc=[ ...
            "A salient-pole synchronous generator with electromechanical ", ...
            "rotor dynamics, transient d/q internal-voltage dynamics, and ", ...
            "a first-order AVR, coupled to the microgrid through terminal voltage."];

    case "gfm"
        expectedIn=9; expectedOut=4;
        symbols=["delta_f","p_f","q_f","E_f","V_R_f","V_I_f", ...
            "P_star_f","Q_star_f","E_star_f"];
        meanings=[ ...
            "internal voltage-source phase angle", ...
            "filtered/measured active-power state", ...
            "filtered/measured reactive-power state", ...
            "internal voltage-magnitude state", ...
            "real component of terminal-bus voltage in the network reference frame", ...
            "imaginary component of terminal-bus voltage in the network reference frame", ...
            "active-power reference", ...
            "reactive-power reference", ...
            "voltage-magnitude reference"];
        roles=["dynamic state","dynamic state","dynamic state","dynamic state", ...
            "network/algebraic input","network/algebraic input", ...
            "operating reference","operating reference","operating reference"];
        units=["rad","p.u.","p.u.","p.u.","p.u.","p.u.","p.u.","p.u.","p.u."];
        derivativeMeaning=[ ...
            "time derivative of the internal GFM phase angle", ...
            "time derivative of the filtered active-power state", ...
            "time derivative of the filtered reactive-power state", ...
            "time derivative of the internal voltage-magnitude state"];
        systemDesc=[ ...
            "A grid-forming inverter represented as a droop-controlled voltage ", ...
            "source behind an output impedance, with active/reactive-power ", ...
            "filter states, active-power/frequency-angle coupling, and ", ...
            "reactive-power/voltage-magnitude control."];

    case "gfl"
        expectedIn=8; expectedOut=4;
        symbols=["theta_l","xi_pll_l","i_d_l","i_q_l","V_R_l","V_I_l", ...
            "P_star_l","Q_star_l"];
        meanings=[ ...
            "PLL/local synchronous-reference-frame angle", ...
            "PLL integral-controller state", ...
            "d-axis current-controller/current state", ...
            "q-axis current-controller/current state", ...
            "real component of terminal-bus voltage in the network reference frame", ...
            "imaginary component of terminal-bus voltage in the network reference frame", ...
            "active-power reference", ...
            "reactive-power reference"];
        roles=["dynamic state","dynamic state","dynamic state","dynamic state", ...
            "network/algebraic input","network/algebraic input", ...
            "operating reference","operating reference"];
        units=["rad","p.u.","p.u.","p.u.","p.u.","p.u.","p.u.","p.u."];
        derivativeMeaning=[ ...
            "time derivative of the PLL/reference-frame angle", ...
            "time derivative of the PLL integral state", ...
            "time derivative of d-axis current", ...
            "time derivative of q-axis current"];
        systemDesc=[ ...
            "A grid-following inverter synchronized by a PLL and controlled ", ...
            "through d/q current dynamics to track active/reactive-power ", ...
            "references using the measured terminal voltage."];

    otherwise
        error('make_semantic_context_ode_local:DeviceType', ...
            'Unsupported device type %s.',type);
end

if nIn~=expectedIn || nOut~=expectedOut
    error('make_semantic_context_ode_local:SemanticDimensionMismatch', ...
        ['Cannot safely construct physical semantics for %s%d: expected ', ...
         '%d inputs/%d derivatives, found %d/%d. Refuse to call the LLM ', ...
         'with ambiguous variable meanings.'], ...
        upper(char(type)),data.deviceIndex,expectedIn,expectedOut,nIn,nOut);
end

vars=repmat(struct( ...
    'alias','','symbol','','project_name','','meaning','','role','','unit',''),nIn,1);
for i=1:nIn
    vars(i).alias=sprintf('x%d',i);
    vars(i).symbol=char(symbols(i));
    vars(i).project_name=char(string(data.inputNames(i)));
    vars(i).meaning=char(meanings(i));
    vars(i).role=char(roles(i));
    vars(i).unit=char(units(i));
end

outs=repmat(struct( ...
    'alias','','physical_symbol','','project_name','','meaning',''),nOut,1);
for i=1:nOut
    outs(i).alias=sprintf('dx%d_dt',i);
    outs(i).physical_symbol=sprintf('d(%s)/dt',char(symbols(i)));
    outs(i).project_name=char(string(data.outputNames(i)));
    outs(i).meaning=char(derivativeMeaning(i));
end

ctx=struct();
ctx.device_type=upper(char(type));
ctx.device_index=data.deviceIndex;
ctx.bus=data.bus;
ctx.system_description=systemDesc;
ctx.variable_glossary=vars;
ctx.target_derivatives=outs;
ctx.alias_rule=[ ...
    'All machine-readable symbolic expressions MUST use aliases x1,x2,... ', ...
    'from the glossary. Physical symbols/meanings are explanatory only.'];
end


%% ========================================================================
% Current fitted ODE reconstruction
% ========================================================================


function candidates=make_ode_prior_candidates_local( ...
    elites,data,yScale,semantic,topK)

candidates=repmat(struct( ...
    'candidate_id',0,'elite_rank',0,'validation_nmse',0, ...
    'dictionary_complexity',0,'complete_dictionary',[], ...
    'current_identified_ode',[]),numel(elites),1);

for e=1:numel(elites)
    q=elites{e};
    coefPhysical=(q.XiNormalized./q.colScale(:)).*yScale;

    dict=repmat(struct( ...
        'index',0,'machine_expression','','human_expression','', ...
        'importance',0,'active',false,'depth',0,'complexity',0),numel(q.basis),1);
    for j=1:numel(q.basis)
        dict(j).index=j;
        dict(j).machine_expression=q.basis{j}.key;
        dict(j).human_expression=q.basis{j}.label;
        if numel(q.basisImportance)>=j
            dict(j).importance=double(q.basisImportance(j));
        end
        if ~isempty(q.XiNormalized) && size(q.XiNormalized,1)>=j
            dict(j).active=any(abs(q.XiNormalized(j,:))>0);
        end
        dict(j).depth=q.basis{j}.depth;
        dict(j).complexity=q.basis{j}.complexity;
    end

    ode=readable_current_ode_local(q,coefPhysical,semantic,topK);

    candidates(e).candidate_id=e;
    candidates(e).elite_rank=e;
    candidates(e).validation_nmse=q.fitness;
    candidates(e).dictionary_complexity=q.dictionaryComplexity;
    candidates(e).complete_dictionary=dict;
    candidates(e).current_identified_ode=ode;
end
end


function ode=readable_current_ode_local(q,coefPhysical,semantic,topK)
nOut=size(coefPhysical,2);
M=size(coefPhysical,1);

ode=repmat(struct( ...
    'derivative_alias','','physical_derivative','','meaning','', ...
    'readable_equation','','dominant_terms',[]),nOut,1);

for k=1:nOut
    if numel(q.basisImportance)==M
        % Equation-independent importance is only a tiebreaker; the actual
        % per-equation ranking uses |coefficient| times feature column scale.
        eqScore=abs(coefPhysical(:,k)).*max(q.colScale(:),eps);
    else
        eqScore=abs(coefPhysical(:,k));
    end

    activeIdx=find(eqScore>0 & isfinite(eqScore));
    [~,loc]=sort(eqScore(activeIdx),'descend');
    ord=activeIdx(loc);
    ord=ord(1:min(topK,numel(ord)));

    terms=repmat(struct( ...
        'coefficient',0,'machine_expression','','human_expression',''), ...
        numel(ord),1);
    pieces=strings(0,1);

    for ii=1:numel(ord)
        j=ord(ii);
        a=coefPhysical(j,k);
        terms(ii).coefficient=a;
        terms(ii).machine_expression=q.basis{j}.key;
        terms(ii).human_expression=q.basis{j}.label;
        pieces(end+1,1)=sprintf('%+.6g*(%s)',a,q.basis{j}.label); %#ok<AGROW>
    end

    ode(k).derivative_alias=semantic.target_derivatives(k).alias;
    ode(k).physical_derivative=semantic.target_derivatives(k).physical_symbol;
    ode(k).meaning=semantic.target_derivatives(k).meaning;
    if isempty(pieces)
        rhs='0';
    else
        rhs=char(strjoin(pieces,' '));
    end
    ode(k).readable_equation=sprintf('%s ~= %s', ...
        semantic.target_derivatives(k).physical_symbol,rhs);
    ode(k).dominant_terms=terms;
end
end


%% ========================================================================
% API invocation
% ========================================================================


function [plans,apiRow]=invoke_ode_prior_llm_local( ...
    elites,data,yScale,semantic,generation,probe,refine)

request=struct();
request.model=char(refine.config.model);
request.reasoning_effort=char(refine.config.reasoningEffort);
request.max_output_tokens=refine.config.maxOutputTokens;
request.store=logical(refine.config.storeResponses);
request.cache_mode=char(refine.config.cacheMode);
request.generation=generation;
request.semantic_system=semantic;
request.objective=[ ...
    'Infer an approximate physical prior ODE from the compact sparse fitted ', ...
    'ODE, then propose only a small set of physically meaningful structural ', ...
    'dictionary edits. The local adapter reconstructs the full fixed-width ', ...
    'dictionary and MATLAB re-fits it with sparse STLSQ.'];
request.dictionary_contract=struct( ...
    'fixed_width',numel(elites{1}.basis), ...
    'required_terms',{{'1'}}, ...
    'required_variable_aliases',{cellstr("x"+(1:numel(data.inputNames)))}, ...
    'allowed_functions',{{'prod','add','sub','div','sin','cos','square','sqrt_pos'}}, ...
    'max_expression_depth',refine.maxLLMExpressionDepth, ...
    'max_expression_complexity',refine.maxLLMExpressionComplexity, ...
    'max_active_dictionary_terms',refine.maxActiveDictionaryTerms, ...
    'inactive_context_terms',refine.inactiveContextTerms, ...
    'max_proposed_terms',refine.maxProposedTerms, ...
    'editing_rule',[ ...
        'Return only a compact list of proposed non-anchor symbolic terms. ', ...
        'The local adapter preserves active parent terms first, fills the ', ...
        'remaining fixed-width slots from the parent dictionary, and MATLAB ', ...
        're-fits/validates the resulting full dictionary.']);
request.candidates=make_ode_prior_candidates_local( ...
    elites,data,yScale,semantic,refine.currentOdeTermsPerDerivative);
request.pricing_usd_per_million=struct( ...
    'input',refine.config.pricingUsdPerMillion.input, ...
    'cached_input',refine.config.pricingUsdPerMillion.cachedInput, ...
    'cache_write',refine.config.pricingUsdPerMillion.cacheWrite, ...
    'output',refine.config.pricingUsdPerMillion.output);

deviceTag=sprintf('%s%d',upper(char(data.deviceType)),data.deviceIndex);
ioRoot=fullfile(refine.seedRoot,'edsi_llm_ode_prior',deviceTag,'llm_io');
cacheRoot=fullfile(refine.seedRoot,'edsi_llm_ode_prior',deviceTag,'llm_cache');
if exist(ioRoot,'dir')~=7, mkdir(ioRoot); end
if exist(cacheRoot,'dir')~=7, mkdir(cacheRoot); end
request.cache_dir=cacheRoot;

baseName=sprintf('%s_gen%02d',deviceTag,generation);
requestPath=fullfile(ioRoot,[baseName '_request.json']);
responsePath=fullfile(ioRoot,[baseName '_response.json']);

fid=fopen(requestPath,'w');
if fid<0
    error('invoke_ode_prior_llm_local:RequestFile', ...
        'Cannot write request JSON: %s',requestPath);
end
fprintf(fid,'%s',jsonencode(request));
fclose(fid);

cmd=sprintf('"%s" "%s" "%s" "%s"', ...
    char(refine.config.pythonExe),char(refine.config.adapterPath), ...
    requestPath,responsePath);
[status,cmdout]=system(cmd);

if exist(responsePath,'file')~=2
    error('invoke_ode_prior_llm_local:NoResponse', ...
        'Adapter status %d without response file: %s',status,cmdout);
end

response=jsondecode(fileread(responsePath));
if status~=0 || ~isfield(response,'ok') || ~logical(response.ok)
    msg=string(cmdout);
    if isfield(response,'error_message'), msg=string(response.error_message); end
    if refine.config.failOnApiError
        error('invoke_ode_prior_llm_local:ApiFailure', ...
            'GPT ODE-prior call failed: %s',msg);
    else
        warning('GPT ODE-prior call failed: %s',msg);
        plans=struct([]);
        apiRow=table();
        return;
    end
end

plans=struct([]);
if isfield(response,'refinements') && isstruct(response.refinements)
    plans=response.refinements;
end

usage=struct();
if isfield(response,'usage'), usage=response.usage; end
cacheHit=false;
if isfield(response,'cache_hit'), cacheHit=logical(response.cache_hit); end

apiRow=table( ...
    generation,string(data.deviceType),data.deviceIndex, ...
    logical(response.ok), ...
    get_struct_number_ode_local(response,'cloud_call_count',double(~cacheHit)), ...
    cacheHit,get_struct_number_ode_local(response,'latency_seconds',NaN), ...
    get_struct_number_ode_local(usage,'input_tokens',0), ...
    get_struct_number_ode_local(usage,'output_tokens',0), ...
    get_struct_number_ode_local(usage,'total_tokens',0), ...
    get_struct_number_ode_local(response,'estimated_cost_usd',0), ...
    numel(plans), ...
    'VariableNames',{ ...
    'Generation','DeviceType','DeviceIndex','OK','CloudCallCount','CacheHit', ...
    'LatencySeconds','InputTokens','OutputTokens','TotalTokens', ...
    'EstimatedCostUSD','ReturnedRefinements'});

fprintf(['        LLM ODE-prior %s g=%02d | sparse structural edits=%d | calls=%d | ', ...
    'tokens=%d+%d | API=$%.6f | latency=%.2fs'], ...
    deviceTag,generation,numel(plans),apiRow.CloudCallCount, ...
    apiRow.InputTokens,apiRow.OutputTokens,apiRow.EstimatedCostUSD, ...
    apiRow.LatencySeconds);
if cacheHit, fprintf(' | CACHE HIT'); end
fprintf('\n');
end


%% ========================================================================
% LLM compact structural edit -> reconstructed internal expression trees
% ========================================================================


function plan=find_ode_prior_plan_local(plans,candidateId)
plan=struct([]);
if isempty(plans), return; end
for i=1:numel(plans)
    id=round(get_struct_number_ode_local(plans(i),'candidate_id',NaN));
    if isfinite(id) && id==candidateId
        plan=plans(i);
        return;
    end
end
end


function [child,valid,summary,priorSummary,diagnosis,confidence]= ...
    candidate_from_llm_structural_edit_local( ...
    parent,plan,seen,Xtr,Xva,Btr,Bva,probe,featureCache,refine,inputNames)

child=parent;
valid=false;
summary="";
priorSummary="";
diagnosis="";
confidence=NaN;

if isempty(plan) || ~isstruct(plan) || ~isfield(plan,'refined_dictionary')
    return;
end

if isfield(plan,'prior_ode_summary')
    priorSummary=string(plan.prior_ode_summary);
end
if isfield(plan,'diagnosis')
    diagnosis=string(plan.diagnosis);
end
confidence=get_struct_number_ode_local(plan,'confidence',NaN);

raw=string(plan.refined_dictionary(:));
M=numel(parent.basis);
if numel(raw)~=M
    return;
end

basis=cell(M,1);
keys=strings(M,1);
for j=1:M
    try
        expr=parse_llm_expression_ode_local( ...
            char(raw(j)),string(inputNames(:)));
    catch
        return;
    end

    if expr.depth>refine.maxLLMExpressionDepth || ...
            expr.complexity>refine.maxLLMExpressionComplexity
        return;
    end
    basis{j}=expr;
    keys(j)=string(expr.key);
end

if numel(unique(keys))~=M
    return;
end

% Every protected anchor must be present, regardless of dictionary ordering.
required=["1"; "x"+string((1:numel(inputNames)).')];
for i=1:numel(required)
    if ~any(keys==required(i))
        return;
    end
end

% Canonical ordering: [1,x1,...,xn] first, then remaining LLM terms in its
% proposed order. This makes the protected mask unambiguous to EDSI.
ordered=cell(M,1);
cursor=0;
for i=1:numel(required)
    idx=find(keys==required(i),1,'first');
    cursor=cursor+1;
    ordered{cursor}=basis{idx};
end
for j=1:M
    if any(keys(j)==required), continue; end
    cursor=cursor+1;
    ordered{cursor}=basis{j};
end
basis=ordered;

protected=false(M,1);
protected(1:numel(required))=true;

% Use relaxed LLM expression-complexity limits only for validating the
% injected dictionary. Ordinary EDSI mutation still uses its original limits.
probeLLM=probe;
probeLLM.maxBasisDepth=refine.maxLLMExpressionDepth;
probeLLM.maxBasisComplexity=refine.maxLLMExpressionComplexity;

try
    child=build_candidate_from_scratch_local( ...
        basis,protected,Xtr,Xva,Btr,Bva,probeLLM,featureCache);
    child=score_candidate_local(child,Btr,Bva,probeLLM);
catch
    child=parent;
    return;
end

if ~isfinite(child.fitness) || strcmp(child.dictionaryKey,parent.dictionaryKey)
    child=parent;
    return;
end
if isKey(seen,child.dictionaryKey)
    child=parent;
    return;
end

valid=true;
summary=sprintf('compact LLM structural edit -> reconstructed dictionary: %d/%d canonical terms differ', ...
    dictionary_difference_count_ode_local(parent.basis,child.basis),M);
end


function n=dictionary_difference_count_ode_local(a,b)
ka=string(cellfun(@(q)q.key,a,'UniformOutput',false));
kb=string(cellfun(@(q)q.key,b,'UniformOutput',false));
n=numel(setxor(ka,kb))/2;
end


function expr=parse_llm_expression_ode_local(s,inputNames)
s=regexprep(strtrim(s),'\s+','');
if strcmp(s,'1')
    expr=make_constant_expression_local();
    return;
end

tok=regexp(s,'^x(\d+)$','tokens','once');
if ~isempty(tok)
    idx=str2double(tok{1});
    if ~isfinite(idx) || idx<1 || idx>numel(inputNames)
        error('parse_llm_expression_ode_local:Variable','Invalid variable %s.',s);
    end
    expr=make_variable_expression_local(idx,inputNames(idx));
    return;
end

[op,args]=parse_function_call_ode_local(s);
switch op
    case {'sin','cos','square','sqrt_pos'}
        if numel(args)~=1
            error('parse_llm_expression_ode_local:Arity','%s expects one arg.',op);
        end
        child=parse_llm_expression_ode_local(args{1},inputNames);
        expr=make_unary_expression_local(op,child);

    case 'prod'
        if numel(args)<2
            error('parse_llm_expression_ode_local:Arity','prod expects >=2 args.');
        end
        expr=parse_llm_expression_ode_local(args{1},inputNames);
        for i=2:numel(args)
            q=parse_llm_expression_ode_local(args{i},inputNames);
            expr=make_product_expression_local(expr,q);
        end

    case 'add'
        if numel(args)<2
            error('parse_llm_expression_ode_local:Arity','add expects >=2 args.');
        end
        children=cell(numel(args),1);
        for i=1:numel(args)
            children{i}=parse_llm_expression_ode_local(args{i},inputNames);
        end
        expr=make_add_expression_ode_local(children);

    case 'sub'
        if numel(args)~=2
            error('parse_llm_expression_ode_local:Arity','sub expects two args.');
        end
        a=parse_llm_expression_ode_local(args{1},inputNames);
        b=parse_llm_expression_ode_local(args{2},inputNames);
        expr=make_sub_expression_ode_local(a,b);

    case 'div'
        if numel(args)~=2
            error('parse_llm_expression_ode_local:Arity','div expects two args.');
        end
        a=parse_llm_expression_ode_local(args{1},inputNames);
        b=parse_llm_expression_ode_local(args{2},inputNames);
        expr=make_div_expression_ode_local(a,b);

    otherwise
        error('parse_llm_expression_ode_local:Operator', ...
            'Unsupported LLM operator %s.',op);
end
end


function [op,args]=parse_function_call_ode_local(s)
p=find(s=='(',1,'first');
if isempty(p) || s(end)~=')'
    error('parse_function_call_ode_local:Syntax','Invalid expression %s.',s);
end
op=lower(s(1:p-1));
body=s(p+1:end-1);
args=split_top_level_args_ode_local(body);
end


function args=split_top_level_args_ode_local(body)
args={};
depth=0;
start=1;
for i=1:length(body)
    ch=body(i);
    if ch=='('
        depth=depth+1;
    elseif ch==')'
        depth=depth-1;
        if depth<0
            error('split_top_level_args_ode_local:Syntax','Unbalanced parentheses.');
        end
    elseif ch==',' && depth==0
        args{end+1,1}=body(start:i-1); %#ok<AGROW>
        start=i+1;
    end
end
if depth~=0
    error('split_top_level_args_ode_local:Syntax','Unbalanced parentheses.');
end
args{end+1,1}=body(start:end);
if any(cellfun(@isempty,args))
    error('split_top_level_args_ode_local:Syntax','Empty function argument.');
end
end


function expr=make_add_expression_ode_local(children)
flat={};
for i=1:numel(children)
    q=children{i};
    if strcmp(q.op,'add')
        flat=[flat q.children]; %#ok<AGROW>
    else
        flat{end+1}=q; %#ok<AGROW>
    end
end
keys=cellfun(@(q)q.key,flat,'UniformOutput',false);
[~,ord]=sort(keys);
flat=flat(ord);
keys=keys(ord);
labels=cellfun(@(q)q.label,flat,'UniformOutput',false);

expr=expression_template_local();
expr.op='add';
expr.children=flat;
expr.key=['add(' strjoin(keys,',') ')'];
expr.label=['(' strjoin(labels,' + ') ')'];
expr.depth=1+max(cellfun(@(q)q.depth,flat));
expr.complexity=sum(cellfun(@(q)q.complexity,flat))+numel(flat)-1;
end


function expr=make_sub_expression_ode_local(a,b)
expr=expression_template_local();
expr.op='sub';
expr.children={a,b};
expr.key=sprintf('sub(%s,%s)',a.key,b.key);
expr.label=sprintf('((%s)-(%s))',a.label,b.label);
expr.depth=1+max(a.depth,b.depth);
expr.complexity=a.complexity+b.complexity+1;
end


function expr=make_div_expression_ode_local(a,b)
expr=expression_template_local();
expr.op='div';
expr.children={a,b};
expr.key=sprintf('div(%s,%s)',a.key,b.key);
expr.label=sprintf('((%s)/(%s))',a.label,b.label);
expr.depth=1+max(a.depth,b.depth);
expr.complexity=a.complexity+b.complexity+1;
end


%% ========================================================================
% Event diagnostics
% ========================================================================


function row=ode_prior_event_row_local( ...
    data,generation,eliteRank,source,parent,child,valid,confidence, ...
    summary,priorSummary,diagnosis)

improvement=100*(parent.fitness-child.fitness)/max(parent.fitness,eps);

row=table( ...
    generation,string(data.deviceType),data.deviceIndex,eliteRank, ...
    string(source),logical(valid),confidence, ...
    parent.fitness,child.fitness,improvement, ...
    dictionary_difference_count_ode_local(parent.basis,child.basis), ...
    string(summary),string(priorSummary),string(diagnosis), ...
    'VariableNames',{ ...
    'Generation','DeviceType','DeviceIndex','EliteRank','ChildSource', ...
    'ValidLLMDictionary','LLMConfidence','ParentValidationNMSE', ...
    'ChildValidationNMSE','ImmediateImprovementPercent', ...
    'ChangedDictionaryTermCount','DictionaryChangeSummary', ...
    'PriorODESummary','LLMDiagnosis'});
end


%% ========================================================================
% Config / report helpers
% ========================================================================


function [terms,meta] = llm_prior_bank_terms_local(sopt,deviceType)
terms = strings(0,1);
meta = struct([]);
if ~isfield(sopt,'llmPriorDiagnostic') || ...
        ~isstruct(sopt.llmPriorDiagnostic) || ...
        ~isfield(sopt.llmPriorDiagnostic,'priorBank')
    return;
end
name = lower(char(string(deviceType)));
if isfield(sopt.llmPriorDiagnostic.priorBank,name)
    terms = string(sopt.llmPriorDiagnostic.priorBank.(name)(:));
end
if isfield(sopt.llmPriorDiagnostic,'priorItems') && ...
        isstruct(sopt.llmPriorDiagnostic.priorItems) && ...
        isfield(sopt.llmPriorDiagnostic.priorItems,name)
    meta = sopt.llmPriorDiagnostic.priorItems.(name);
end
end


function llm=load_ode_prior_llm_config_local(configPath,adapterPath)
q=jsondecode(fileread(configPath));
llm=struct();
llm.model=string(q.model);
llm.pythonExe=string(q.pythonExe);
llm.reasoningEffort=string(q.reasoningEffort);
llm.maxOutputTokens=double(q.maxOutputTokens);
llm.failOnApiError=logical(q.failOnApiError);
llm.storeResponses=logical(q.storeResponses);
llm.cacheMode=string(q.cacheMode);
llm.adapterPath=string(adapterPath);
llm.pricingUsdPerMillion=struct( ...
    'input',double(q.pricingUsdPerMillion.input), ...
    'cachedInput',double(q.pricingUsdPerMillion.cachedInput), ...
    'cacheWrite',double(q.pricingUsdPerMillion.cacheWrite), ...
    'output',double(q.pricingUsdPerMillion.output));
end


function v=get_struct_number_ode_local(s,name,defaultVal)
v=defaultVal;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    q=double(s.(name));
    if isscalar(q) && isfinite(q), v=q; end
end
end


function v=sum_table_numeric_ode_local(T,name)
v=0;
if isempty(T) || ~ismember(name,T.Properties.VariableNames), return; end
q=double(T.(name));
q=q(isfinite(q));
if ~isempty(q), v=sum(q); end
end


function [module,info,history] = fit_edsi_module_local( ...
    data,trainMask,valMask,opt,probe,dataSeed,priorTerms,priorMeta,skipEvolution,augmentPriorNoCompression)

if nargin < 7 || isempty(priorTerms)
    priorTerms = strings(0,1);
else
    priorTerms = string(priorTerms(:));
end
if nargin < 8 || isempty(priorMeta)
    priorMeta = struct([]);
end
if nargin < 9 || isempty(skipEvolution)
    skipEvolution = false;
else
    skipEvolution = logical(skipEvolution);
end
if nargin < 10 || isempty(augmentPriorNoCompression)
    augmentPriorNoCompression = false;
else
    augmentPriorNoCompression = logical(augmentPriorNoCompression);
end
if skipEvolution && augmentPriorNoCompression
    error('fit_edsi_module_local:ModeConflict', ...
        'skipEvolution and augmentPriorNoCompression cannot both be true.');
end

Xtr = double(data.X(trainMask,:));
Xva = double(data.X(valMask,:));
Ytr = double(data.Y(trainMask,:));
Yva = double(data.Y(valMask,:));

% Output normalization exactly once; every evolved dictionary sees the same
% normalized target matrices.
yScale = std(Ytr,0,1);
yRms = sqrt(mean(Ytr.^2,1));
yScale = max(yScale,0.05*yRms);
yScale = max(yScale,probe.outputScaleFloor);
Btr = Ytr./yScale;
Bva = Yva./yScale;

% Match V-SINDy numerical identification exactly for this data protocol.
% In noisy reconstructed-derivative cases this activates the same
% validation-selected frozen-support ridge used by V-SINDy.
probe = configure_support_ridge_probe_local(probe,opt,data,size(Xtr,1));

% Build our expression representation of the EXACT V dictionary and verify
% it numerically against the project's official build_sindy_library.
baseBasis = make_initial_v_dictionary_local(string(data.inputNames(:)));
protectedMask = false(numel(baseBasis),1);
protectedMask(1:(1+size(Xtr,2))) = true;   % [1,x] never replaced

[ThetaOfficial,namesOfficial] = build_sindy_library( ...
    data.X,data.inputNames,data.deviceType,'vanilla',opt,[]);
ThetaLocal = evaluate_dictionary_raw_local(baseBasis,double(data.X));

if size(ThetaOfficial,2) ~= numel(baseBasis)
    error('fit_edsi_module_local:WidthMismatch', ...
        'EDSI V initialization width %d != official V width %d.', ...
        numel(baseBasis),size(ThetaOfficial,2));
end

basisAgreement = max(abs(ThetaOfficial(:)-ThetaLocal(:)));
if ~isfinite(basisAgreement) || basisAgreement > 1e-11
    error('fit_edsi_module_local:VLibraryMismatch', ...
        'EDSI V initialization differs from official V library (max diff %.3e).', ...
        basisAgreement);
end

M = numel(baseBasis);
if nnz(protectedMask) >= M
    error('fit_edsi_module_local:NoEvolvableSlots', ...
        'No evolvable V dictionary slots remain.');
end

% Per-module deterministic evolutionary RNG, independent of parfor scheduling.
typeCode = device_type_code_local(data.deviceType);
rngSeed = mod(double(dataSeed) + 100000*typeCode + ...
    1009*double(data.deviceIndex) + 17*size(data.X,1) + ...
    104729*double(probe.evolutionSearchSeed),2^32-1);
if rngSeed < 1, rngSeed = rngSeed + 1; end
oldRng = rng;
cleanupRng = onCleanup(@()rng(oldRng)); %#ok<NASGU>
rng(rngSeed,'twister');

% Basis-value cache: each unique expression is evaluated only once on the
% train/validation samples. Evolution then updates only changed Gram rows.
featureCache = containers.Map('KeyType','char','ValueType','any');

base = build_candidate_from_scratch_local( ...
    baseBasis,protectedMask,Xtr,Xva,Btr,Bva,probe,featureCache);
[searchFit,~] = select_stlsq_fit_local( ...
    base,Btr,Bva,probe.searchThresholdGrid,probe.searchStlsqIterations, ...
    probe,probe.searchPreferSparseWithinRelativeValidationTolerance);
probe.searchLambda = searchFit.lambda;
probe.searchSupportRidgeRelativeAlpha = searchFit.supportRidgeRelativeAlpha;
base = score_candidate_local(base,Btr,Bva,probe);
baseInitialFitness = base.fitness;

% By default EDSI searches the original target. V8 augmented LLM-prior EDSI
% overrides these after fitting the immutable LLM prior contribution: only the
% residual target is exposed to evolutionary search.
BtrEvolution = Btr;
BvaEvolution = Bva;
evolutionStart = base;
llmPriorBaselineFit = struct();
llmPriorBaselineSweep = table();
llmPriorFixedXi = zeros(0,size(Btr,2));
llmPriorFixedColScale = zeros(0,1);
llmPriorFixedBasis = cell(0,1);
llmPriorBaselineShortRollout = NaN;

% V8 immutable-prior residual path. The ordinary V-SINDy dictionary keeps its
% original M slots as the ONLY evolutionary bank. The complete low-dimensional
% LLM prior bank is appended for the prior baseline, identified once, then its
% terms and coefficients are frozen. Evolution never touches that block and
% learns only the remaining residual with the original M-slot bank.
augmentedStart = [];
augmentedStartValid = false;
augmentedStartFitness = NaN;
augmentedPriorDiag = struct('baseEvolutionWidth',M,'priorBankWidth',0, ...
    'totalWidth',M,'lockedPriorCount',0,'priorKeys',strings(0,1));
if augmentPriorNoCompression
    [augmentedStart,augmentedStartValid,augmentedPriorDiag] = ...
        make_llm_prior_augmented_candidate_local( ...
        base,priorTerms,priorMeta,string(data.inputNames(:)), ...
        Xtr,Xva,Btr,Bva,probe,featureCache,opt);
    if ~augmentedStartValid
        error('fit_edsi_module_local:NoValidAugmentedPrior', ...
            'LLM-prior augmented EDSI requires at least one valid prior-bank term.');
    end

    % V8: identify the complete augmented LLM-prior model first using the
    % SAME formal full STLSQ selector as LLM-Prior SINDy.  The discovered LLM
    % bank is then structurally AND coefficient-wise frozen. Evolution never
    % edits/refits that block; it only learns a V-width correction to the
    % residual left after the immutable LLM-bank contribution.
    [llmPriorBaselineFit,llmPriorBaselineSweep] = select_stlsq_fit_local( ...
        augmentedStart,Btr,Bva,probe.finalThresholdGrid,probe.finalStlsqIterations, ...
        probe,probe.finalPreferSparseWithinRelativeValidationTolerance);
    augmentedStartFitness = llmPriorBaselineFit.validationNormalizedMSE;

    priorIdx = (M+1):numel(augmentedStart.basis);
    llmPriorFixedXi = llmPriorBaselineFit.XiNormalized(priorIdx,:);
    llmPriorFixedColScale = augmentedStart.colScale(priorIdx);
    llmPriorFixedBasis = augmentedStart.basis(priorIdx);
    [ApriorTr,ApriorVa] = normalized_design_block_local( ...
        llmPriorFixedBasis,llmPriorFixedColScale,Xtr,Xva);
    BtrEvolution = Btr - ApriorTr*llmPriorFixedXi;
    BvaEvolution = Bva - ApriorVa*llmPriorFixedXi;

    % Recalibrate sparse-search lambda/ridge AFTER the LLM contribution has
    % been fixed.  This is the residual problem actually seen by evolution,
    % so V-SINDy hyperparameters are no longer inherited blindly.
    evolutionStart = build_candidate_from_scratch_local( ...
        baseBasis,protectedMask,Xtr,Xva,BtrEvolution,BvaEvolution,probe,featureCache);
    [residualSearchFit,~] = select_stlsq_fit_local( ...
        evolutionStart,BtrEvolution,BvaEvolution,probe.searchThresholdGrid, ...
        probe.searchStlsqIterations,probe, ...
        probe.searchPreferSparseWithinRelativeValidationTolerance);
    probe.searchLambda = residualSearchFit.lambda;
    probe.searchSupportRidgeRelativeAlpha = residualSearchFit.supportRidgeRelativeAlpha;
    evolutionStart = score_candidate_local( ...
        evolutionStart,BtrEvolution,BvaEvolution,probe);

    % Held-out short-rollout baseline is computed without the manuscript
    % 12-s test trajectory. It is later used only for final champion choice.
    coefPriorBaselinePhysical = ...
        (llmPriorBaselineFit.XiNormalized./augmentedStart.colScale(:)).*yScale;
    llmPriorBaselineShortRollout = score_edsi_short_trajectory_validation_local( ...
        data,trainMask,valMask,augmentedStart.basis,coefPriorBaselinePhysical,probe);

    fprintf(['      %s%d | LLM PRIOR RESIDUAL-LOCK | evolution bank=%d ', ...
        '| prior bank=%d immutable | total width=%d ', ...
        '| augmented full-STLSQ val=%.3e | residual search lambda=%.3g ', ...
        '| residual ridge=%.3g | short-rollout=%.3e\n'], ...
        upper(char(data.deviceType)),data.deviceIndex,M, ...
        augmentedPriorDiag.priorBankWidth,augmentedPriorDiag.totalWidth, ...
        augmentedStartFitness,probe.searchLambda, ...
        probe.searchSupportRidgeRelativeAlpha,llmPriorBaselineShortRollout);
end

% Optional weak-domain LLM prior seed. The ordinary V dictionary remains an
% explicit parent. LLM terms (including generic motif-closure candidates) enter
% only a temporary proposal pool, are pruned for LLM-internal redundancy, and
% then compete for the SAME fixed number of dictionary slots. Every actual
% EDSI seed/elite/child remains at the original V-SINDy width. High-confidence,
% data-admissible retained terms are mutation-locked; STLSQ may still assign
% them zero coefficient.
priorSeed = [];
priorSeedValid = false;
priorSeedInserted = 0;
priorSeedFitness = NaN;
priorSeedDiag = struct('unionWidth',M,'proposalPoolWidth',M,'validPriorCount',0, ...
    'redundantPriorPrunedCount',0,'retainedPriorCount',0,'lockedPriorCount',0, ...
    'unionValidationNormalizedMSE',NaN,'unionSelectedThreshold',NaN, ...
    'compressedValidationNormalizedMSE',NaN,'compressionSteps',0,'swapPolishSteps',0, ...
    'compressionPolicy','fixed_width_seq_refit_swap_v5', ...
    'retainedPriorKeys',strings(0,1),'lockedPriorKeys',strings(0,1));
if ~augmentPriorNoCompression && ~isempty(priorTerms)
    [priorSeed,priorSeedValid,priorSeedInserted,priorSeedDiag] = ...
        make_llm_prior_union_compressed_seed_local( ...
        base,priorTerms,priorMeta,string(data.inputNames(:)), ...
        Xtr,Xva,Btr,Bva,probe,featureCache,opt);
    if priorSeedValid
        if numel(priorSeed.basis) ~= M
            error('fit_edsi_module_local:PriorSeedWidth', ...
                'LLM prior seed width %d must equal fixed EDSI width %d.', ...
                numel(priorSeed.basis),M);
        end
        priorSeedFitness = priorSeed.fitness;
        fprintf(['      %s%d | LLM PRIOR FIXED-WIDTH-COMPRESS | proposal pool=%d | valid prior=%d ', ...
            '| pruned=%d | retained=%d | locked=%d | delete=%d | swap=%d ', ...
            '| pool val=%.3e | V val=%.3e -> fixed-width seed val=%.3e\n'], ...
            upper(char(data.deviceType)),data.deviceIndex, ...
            priorSeedDiag.proposalPoolWidth,priorSeedDiag.validPriorCount, ...
            priorSeedDiag.redundantPriorPrunedCount,priorSeedDiag.retainedPriorCount, ...
            priorSeedDiag.lockedPriorCount,priorSeedDiag.compressionSteps, ...
            priorSeedDiag.swapPolishSteps,priorSeedDiag.unionValidationNormalizedMSE, ...
            base.fitness,priorSeedFitness);
    end
end

% Optional diagnostic control: stop immediately after fixed-width LLM-prior
% distillation. This isolates compression quality from evolutionary search.
if skipEvolution
    if priorSeedValid
        globalBest = priorSeed;
    else
        globalBest = base;
    end
    history = repmat(history_template_local(),0,1);
    stallCount = 0;
    lastGeneration = 0;
    lastMeaningfulBest = globalBest.fitness;
    fprintf(['      %s%d | %s | width=%d fixed | NO EVOLUTION | V val=%.3e ', ...
        '-> distilled val=%.3e\n'], ...
        upper(char(data.deviceType)),data.deviceIndex,char(probe.displayName),M, ...
        baseInitialFitness,globalBest.fitness);
else
% Initial population. In the V8 augmented path the LLM prior block is not
% part of the chromosome at all: it is frozen outside evolution, and the
% original V-width dictionary learns only the residual. Legacy fixed-width
% paths retain the previous V-parent + optional compressed-prior behavior.
population = cell(probe.populationSize,1);
seen = containers.Map('KeyType','char','ValueType','logical');
if augmentPriorNoCompression
    population{1} = evolutionStart;
    seen(evolutionStart.dictionaryKey) = true;
    seedParents = {evolutionStart};
    nextSlot = 2;
    evolutionWidth = M;
else
    population{1} = base;
    seen(base.dictionaryKey) = true;
    seedParents = {base};
    nextSlot = 2;
    if priorSeedValid && ~strcmp(priorSeed.dictionaryKey,base.dictionaryKey)
        population{2} = priorSeed;
        seen(priorSeed.dictionaryKey) = true;
        seedParents{end+1} = priorSeed; %#ok<AGROW>
        nextSlot = 3;
    end
    evolutionWidth = M;
end

for p = nextSlot:probe.populationSize
    parent0 = seedParents{1+mod(p-nextSlot,numel(seedParents))};
    child = unique_mutated_child_local( ...
        parent0,seen,Xtr,Xva,BtrEvolution,BvaEvolution,probe,featureCache);
    if numel(child.basis) ~= evolutionWidth
        error('fit_edsi_module_local:InitialChildWidth', ...
            'EDSI child total width %d must remain fixed at %d.',numel(child.basis),evolutionWidth);
    end
    population{p} = child;
    seen(child.dictionaryKey) = true;
end

history = repmat(history_template_local(),0,1);

if augmentPriorNoCompression
    globalBest = evolutionStart;
else
    globalBest = base;
end
stallCount = 0;

% Generation 0 selection.
[elites,stats] = select_elites_local(population,probe.eliteCount);
if elites{1}.fitness < globalBest.fitness
    globalBest = elites{1};
end
history(end+1,1) = make_history_row_local(0,stats,globalBest,stallCount); %#ok<AGROW>

if augmentPriorNoCompression
    fprintf(['      %s%d | %s init | residual evolution bank=%d fixed | LLM bank=%d immutable ', ...
        '| final width=%d | residual STLSQ-%d lambda=%.3g | residual ridge=%.3g ', ...
        '| prior-base val=%.3e | residual population best=%.3e\n'], ...
        upper(char(data.deviceType)),data.deviceIndex,char(probe.displayName),M, ...
        augmentedPriorDiag.priorBankWidth,M+augmentedPriorDiag.priorBankWidth, ...
        probe.searchStlsqIterations,probe.searchLambda, ...
        probe.searchSupportRidgeRelativeAlpha,augmentedStartFitness,globalBest.fitness);
else
    fprintf(['      %s%d | %s init | width=%d | search STLSQ-%d lambda=%.3g ', ...
        '| support-ridge rho=%.3g | V val=%.3e | population best=%.3e\n'], ...
        upper(char(data.deviceType)),data.deviceIndex,char(probe.displayName),M, ...
        probe.searchStlsqIterations,probe.searchLambda, ...
        probe.searchSupportRidgeRelativeAlpha,baseInitialFitness,globalBest.fitness);
end

lastMeaningfulBest = globalBest.fitness;
lastGeneration = 0;

for gen = 1:probe.maxGenerations
    nextPopulation = cell(probe.populationSize,1);

    % Elitism = identity operation. Every selected parent survives unchanged.
    for e = 1:probe.eliteCount
        nextPopulation{e} = elites{e};
    end

    seenNext = containers.Map('KeyType','char','ValueType','logical');
    for e = 1:probe.eliteCount
        seenNext(elites{e}.dictionaryKey) = true;
    end

    cursor = probe.eliteCount;
    for e = 1:probe.eliteCount
        parent = elites{e};
        for b = 1:probe.offspringPerElite
            cursor = cursor + 1;
            child = unique_mutated_child_local( ...
                parent,seenNext,Xtr,Xva,BtrEvolution,BvaEvolution,probe,featureCache);
            if numel(child.basis) ~= evolutionWidth
                error('fit_edsi_module_local:EvolutionChildWidth', ...
                    'EDSI offspring total width %d must remain fixed at %d.',numel(child.basis),evolutionWidth);
            end
            nextPopulation{cursor} = child;
            seenNext(child.dictionaryKey) = true;
        end
    end

    population = nextPopulation;
    [elites,stats] = select_elites_local(population,probe.eliteCount);

    currentBest = elites{1};
    previousGlobal = globalBest.fitness;
    if currentBest.fitness < globalBest.fitness
        globalBest = currentBest;
    end

    relativeImprovement = ...
        (previousGlobal-globalBest.fitness)/max(previousGlobal,eps);

    if relativeImprovement > probe.minRelativeImprovement
        stallCount = 0;
        lastMeaningfulBest = globalBest.fitness;
    else
        stallCount = stallCount + 1;
    end

    history(end+1,1) = ...
        make_history_row_local(gen,stats,globalBest,stallCount); %#ok<AGROW>
    lastGeneration = gen;

    if gen == 1 || mod(gen,probe.printEvery)==0 || ...
            stallCount >= probe.stallPatience || gen == probe.maxGenerations
        fprintf(['      %s%d | %s gen=%02d | best=%.3e | median=%.3e | ', ...
            'global=%.3e | C=%d | unique=%d/%d | stall=%d\n'], ...
            upper(char(data.deviceType)),data.deviceIndex,char(probe.displayName),gen, ...
            stats.bestFitness,stats.medianFitness,globalBest.fitness, ...
            globalBest.dictionaryComplexity,stats.uniqueCount, ...
            probe.populationSize,stallCount);
    end

    if stallCount >= probe.stallPatience
        break;
    end
end

end

if augmentPriorNoCompression
    residualEvolutionBestFitness = globalBest.fitness;
    residualEvolutionBestTrainFitness = globalBest.trainFitness;
    residualEvolutionBestActive = nnz(abs(globalBest.XiNormalized)>0);
else
    residualEvolutionBestFitness = NaN;
    residualEvolutionBestTrainFitness = NaN;
    residualEvolutionBestActive = NaN;
end

% Final selected dictionary is refit with the full formal STLSQ protocol.
% V8 augmented LLM-prior EDSI uses an explicit residual decomposition:
%   f_hat = f_LLM_fixed + f_EDSI_residual.
% The LLM bank and its identified coefficients are NEVER mutated/refit by
% evolution. Only the original V-width bank is evolved against the residual.
% Final adoption is decided on held-out short-trajectory rollout validation,
% never on the manuscript 12-s test rollout.
finalChampionSource = "evolved";
finalChampionShortRollout = NaN;
evolvedShortRollout = NaN;
residualFinalFit = struct();
residualFinalSweep = table();

if augmentPriorNoCompression
    [residualFinalFit,residualFinalSweep] = select_stlsq_fit_local( ...
        globalBest,BtrEvolution,BvaEvolution,probe.finalThresholdGrid, ...
        probe.finalStlsqIterations,probe, ...
        probe.finalPreferSparseWithinRelativeValidationTolerance);

    [evolvedCombined,evolvedFinalFit,evolvedCoefPhysical] = ...
        combine_residual_with_fixed_prior_local( ...
        globalBest,residualFinalFit,llmPriorFixedBasis,llmPriorFixedColScale, ...
        llmPriorFixedXi,Xtr,Xva,Btr,Bva,yScale,probe,featureCache);

    evolvedShortRollout = score_edsi_short_trajectory_validation_local( ...
        data,trainMask,valMask,evolvedCombined.basis,evolvedCoefPhysical,probe);

    acceptEvolved = false;
    if probe.residualRefinementShortRolloutEnabled
        if isfinite(evolvedShortRollout) && ~isfinite(llmPriorBaselineShortRollout)
            acceptEvolved = true;
        elseif isfinite(evolvedShortRollout) && isfinite(llmPriorBaselineShortRollout)
            target = llmPriorBaselineShortRollout * ...
                (1-probe.residualChampionMinRelativeImprovement);
            acceptEvolved = evolvedShortRollout <= ...
                target + probe.validationAbsoluteTolerance;
        elseif ~isfinite(evolvedShortRollout) && ~isfinite(llmPriorBaselineShortRollout)
            % If both short rollouts are non-finite, fall back conservatively
            % to pointwise validation, still preferring the untouched prior on ties.
            acceptEvolved = evolvedFinalFit.validationNormalizedMSE < ...
                llmPriorBaselineFit.validationNormalizedMSE - ...
                probe.validationAbsoluteTolerance;
        end
    else
        acceptEvolved = evolvedFinalFit.validationNormalizedMSE < ...
            llmPriorBaselineFit.validationNormalizedMSE - ...
            probe.validationAbsoluteTolerance;
    end

    if acceptEvolved
        globalBest = evolvedCombined;
        finalFit = evolvedFinalFit;
        finalSweep = residualFinalSweep;
        coefPhysical = evolvedCoefPhysical;
        colScale = globalBest.colScale(:);
        finalXi = finalFit.XiNormalized;
        finalChampionSource = "evolved_residual";
        finalChampionShortRollout = evolvedShortRollout;
    else
        globalBest = augmentedStart;
        finalFit = llmPriorBaselineFit;
        finalSweep = llmPriorBaselineSweep;
        colScale = globalBest.colScale(:);
        finalXi = finalFit.XiNormalized;
        coefPhysical = (finalXi./colScale).*yScale;
        finalChampionSource = "llm_prior_base";
        finalChampionShortRollout = llmPriorBaselineShortRollout;
    end
else
    [finalFit,finalSweep] = select_stlsq_fit_local( ...
        globalBest,Btr,Bva,probe.finalThresholdGrid,probe.finalStlsqIterations, ...
        probe,probe.finalPreferSparseWithinRelativeValidationTolerance);
    colScale = globalBest.colScale(:);
    finalXi = finalFit.XiNormalized;
    coefPhysical = (finalXi./colScale).*yScale;
end

module = struct();
if augmentPriorNoCompression
    module.type = 'edsi_augmented_prior_module';
else
    module.type = 'edsi_fixed_width_module';
end
module.formulationVersion = char(probe.formulationVersion);
module.deviceType = char(data.deviceType);
module.deviceIndex = data.deviceIndex;
module.bus = data.bus;
module.stateIndices = data.stateIndices(:);
module.inputNames = string(data.inputNames(:));
module.outputNames = string(data.outputNames(:));
module.dictionary = globalBest.basis;
module.libraryNames = string(cellfun(@(q)q.label,globalBest.basis, ...
    'UniformOutput',false)).';
module.coefficients = coefPhysical;
module.coefficientsNormalized = finalXi;
module.columnScale = colScale;
module.outputScale = yScale(:);
module.rho = probe.finalSupportRidgeRho;
module.supportDiscoveryRho = probe.supportDiscoveryRho;
module.fixedFinalSupportRidgeRho = probe.finalSupportRidgeRho;
module.identificationBackend = 'shared_v_sindy_ols_support_fixedrho_noise_ridge_v2';
module.supportRidgeApplied = probe.supportRidgeApplied;
module.supportRidgePolicy = probe.supportRidgePolicy;
module.searchSupportRidgeRelativeAlpha = probe.searchSupportRidgeRelativeAlpha;
module.selectedSupportRidgeRelativeAlpha = finalFit.supportRidgeRelativeAlpha;
module.searchStlsqIterations = probe.searchStlsqIterations;
module.searchThreshold = probe.searchLambda;
if augmentPriorNoCompression
    module.searchValidationNormalizedMSE = residualEvolutionBestFitness;
    module.searchTrainNormalizedMSE = residualEvolutionBestTrainFitness;
    module.searchActiveCoefficientCount = residualEvolutionBestActive;
else
    module.searchValidationNormalizedMSE = globalBest.fitness;
    module.searchTrainNormalizedMSE = globalBest.trainFitness;
    module.searchActiveCoefficientCount = nnz(abs(globalBest.XiNormalized)>0);
end
module.finalStlsqIterations = probe.finalStlsqIterations;
module.selectedThreshold = finalFit.lambda;
module.activeCoefficientCount = finalFit.activeCoefficientCount;
module.finalThresholdSweep = finalSweep;
module.dictionaryWidth = numel(globalBest.basis);
module.evolutionBaseDictionaryWidth = M;
module.llmPriorEnhancementWidth = max(0,module.dictionaryWidth-M);
module.totalDictionaryWidth = module.dictionaryWidth;
module.protectedWidth = nnz(protectedMask);
module.evolvableWidth = M-nnz(protectedMask);
module.dictionaryComplexity = globalBest.dictionaryComplexity;
module.maxBasisDepth = max(cellfun(@(q)q.depth,globalBest.basis));
module.validationNormalizedMSE = finalFit.validationNormalizedMSE;
module.trainNormalizedMSE = finalFit.trainNormalizedMSE;
if augmentPriorNoCompression
    module.initialValidationNormalizedMSE = augmentedStartFitness;
else
    module.initialValidationNormalizedMSE = baseInitialFitness;
end
module.vanillaInitialValidationNormalizedMSE = baseInitialFitness;
if augmentPriorNoCompression
    module.evolutionBestValidationNormalizedMSE = residualEvolutionBestFitness;
    module.residualEvolutionBestValidationNormalizedMSE = residualEvolutionBestFitness;
    module.llmPriorBaselineValidationNormalizedMSE = augmentedStartFitness;
    module.llmPriorBaselineThreshold = llmPriorBaselineFit.lambda;
    module.llmPriorBaselineSupportRidgeRelativeAlpha = ...
        llmPriorBaselineFit.supportRidgeRelativeAlpha;
    module.llmPriorBaselineShortRolloutValidation = llmPriorBaselineShortRollout;
    module.evolvedResidualShortRolloutValidation = evolvedShortRollout;
    module.finalChampionShortRolloutValidation = finalChampionShortRollout;
    module.residualChampionMinRelativeImprovement = ...
        probe.residualChampionMinRelativeImprovement;
    module.llmPriorCoefficientsFrozenDuringEvolution = true;
    module.residualEvolutionOnly = true;
else
    module.evolutionBestValidationNormalizedMSE = globalBest.fitness;
    module.residualEvolutionBestValidationNormalizedMSE = NaN;
    module.llmPriorBaselineValidationNormalizedMSE = NaN;
    module.llmPriorBaselineThreshold = NaN;
    module.llmPriorBaselineSupportRidgeRelativeAlpha = NaN;
    module.llmPriorBaselineShortRolloutValidation = NaN;
    module.evolvedResidualShortRolloutValidation = NaN;
    module.finalChampionShortRolloutValidation = NaN;
    module.residualChampionMinRelativeImprovement = NaN;
    module.llmPriorCoefficientsFrozenDuringEvolution = false;
    module.residualEvolutionOnly = false;
end
if augmentPriorNoCompression
    module.fitnessGainLog10 = log10(max(augmentedStartFitness,realmin) / ...
        max(finalFit.validationNormalizedMSE,realmin));
else
    module.fitnessGainLog10 = log10(max(baseInitialFitness,realmin) / ...
        max(finalFit.validationNormalizedMSE,realmin));
end
module.generationCount = lastGeneration;
module.evolutionSkipped = logical(skipEvolution);
module.coefficientFroNorm = norm(coefPhysical,'fro');
module.normalizedCoefficientFroNorm = finalFit.normalizedCoefficientFroNorm;
module.rngSeed = rngSeed;
module.evolutionSearchSeed = probe.evolutionSearchSeed;
module.variantId = probe.variantId;
module.variantDisplayName = probe.displayName;
module.llmPriorSeedUsed = logical(priorSeedValid || augmentedStartValid);
if augmentPriorNoCompression
    module.llmPriorSeedInsertedTermCount = augmentedPriorDiag.priorBankWidth;
    module.llmPriorSeedValidationNormalizedMSE = augmentedStartFitness;
else
    module.llmPriorSeedInsertedTermCount = priorSeedInserted;
    module.llmPriorSeedValidationNormalizedMSE = priorSeedFitness;
end
if augmentPriorNoCompression
    module.llmPriorSeedConstruction = 'immutable_prior_bank_residual_refinement_v8';
else
    module.llmPriorSeedConstruction = 'fixed_width_proposal_pool_redundancy_prune_seq_refit_swap_lock_v5';
end
module.fixedWidthDistillationOnly = logical(skipEvolution);
module.llmPriorUnionWidth = priorSeedDiag.unionWidth; % legacy alias for proposal pool width
module.llmPriorProposalPoolWidth = priorSeedDiag.proposalPoolWidth;
module.llmPriorUnionValidPriorCount = priorSeedDiag.validPriorCount;
module.llmPriorRedundantPriorPrunedCount = priorSeedDiag.redundantPriorPrunedCount;
module.llmPriorRetainedPriorCount = priorSeedDiag.retainedPriorCount;
module.llmPriorLockedPriorCount = priorSeedDiag.lockedPriorCount;
module.llmPriorCompressionSteps = priorSeedDiag.compressionSteps;
module.llmPriorSwapPolishSteps = priorSeedDiag.swapPolishSteps;
module.llmPriorRetainedTermKeys = priorSeedDiag.retainedPriorKeys;
module.llmPriorLockedTermKeys = priorSeedDiag.lockedPriorKeys;
module.llmPriorUnionValidationNormalizedMSE = priorSeedDiag.unionValidationNormalizedMSE;
module.llmPriorUnionSelectedThreshold = priorSeedDiag.unionSelectedThreshold;
module.llmPriorAugmentedNoCompression = logical(augmentPriorNoCompression);
module.llmPriorAugmentedBankWidth = augmentedPriorDiag.priorBankWidth;
module.llmPriorAugmentedLockedCount = augmentedPriorDiag.lockedPriorCount;
module.llmPriorAugmentedTermKeys = augmentedPriorDiag.priorKeys;
module.finalChampionSource = char(finalChampionSource);
module.populationSize = probe.populationSize;
module.eliteCount = probe.eliteCount;
module.maxGenerations = probe.maxGenerations;
if skipEvolution
    module.nominalCandidateEvaluations = 1 + double(priorSeedValid);
else
    module.nominalCandidateEvaluations = probe.populationSize + ...
        lastGeneration*(probe.populationSize-probe.eliteCount);
end
module.useSaliencyGuidance = probe.useSaliencyGuidance;
module.officialVAgreementMaxAbs = basisAgreement;
module.officialVLibraryNames = string(namesOfficial(:));
module.bestDictionaryKey = string(globalBest.dictionaryKey);
module.referenceMeaningfulBest = lastMeaningfulBest;

info = module;

if skipEvolution
    fprintf(['      %s%d | %s DISTILLED FIXED-WIDTH | width=%d | val %.3e -> %.3e ', ...
        '| complexity=%d | maxDepth=%d\n'], ...
        upper(char(data.deviceType)),data.deviceIndex,char(probe.displayName),M, ...
        baseInitialFitness,globalBest.fitness,module.dictionaryComplexity,module.maxBasisDepth);
else
    if augmentPriorNoCompression
        fprintf(['      %s%d | %s RESIDUAL SEARCH BEST | gen=%d | evolution bank=%d fixed ', ...
            '| LLM bank=%d immutable | total=%d | residual best=%.3e ', ...
            '| prior short=%.3e | evolved short=%.3e | final champion=%s ', ...
            '| final val=%.3e | complexity=%d | maxDepth=%d\n'], ...
            upper(char(data.deviceType)),data.deviceIndex,char(probe.displayName),lastGeneration,M, ...
            module.llmPriorAugmentedBankWidth,module.dictionaryWidth, ...
            residualEvolutionBestFitness,llmPriorBaselineShortRollout,evolvedShortRollout, ...
            char(finalChampionSource),module.validationNormalizedMSE, ...
            module.dictionaryComplexity,module.maxBasisDepth);
    else
        fprintf(['      %s%d | %s SEARCH BEST | gen=%d | width=%d fixed | val %.3e -> %.3e ', ...
            '| complexity=%d | maxDepth=%d\n'], ...
            upper(char(data.deviceType)),data.deviceIndex,char(probe.displayName),lastGeneration,M, ...
            baseInitialFitness,globalBest.fitness,module.dictionaryComplexity,module.maxBasisDepth);
    end
end
fprintf(['      %s%d | %s FINAL STLSQ-%d | lambda=%.3g | support-ridge rho=%.3g ', ...
    '| active=%d/%d | train nMSE=%.3e | val nMSE=%.3e\n'], ...
    upper(char(data.deviceType)),data.deviceIndex,char(probe.displayName), ...
    probe.finalStlsqIterations,module.selectedThreshold, ...
    module.selectedSupportRidgeRelativeAlpha,module.activeCoefficientCount, ...
    numel(finalXi),module.trainNormalizedMSE,module.validationNormalizedMSE);
end


function [Atr,Ava] = normalized_design_block_local(basis,colScale,Xtr,Xva)
%NORMALIZED_DESIGN_BLOCK_LOCAL Evaluate a fixed symbolic block with the exact
% training-derived column scales used by the sparse regression backend.
colScale = double(colScale(:));
if numel(basis) ~= numel(colScale)
    error('normalized_design_block_local:Width', ...
        'Basis width %d does not match scale width %d.',numel(basis),numel(colScale));
end
rawTr = evaluate_dictionary_raw_local(basis,Xtr);
rawVa = evaluate_dictionary_raw_local(basis,Xva);
Atr = rawTr./reshape(colScale,1,[]);
Ava = rawVa./reshape(colScale,1,[]);
end


function [combined,fit,coefPhysical] = combine_residual_with_fixed_prior_local( ...
    residualCandidate,residualFit,priorBasis,priorColScale,priorXi, ...
    Xtr,Xva,Btr,Bva,yScale,probe,featureCache)
%COMBINE_RESIDUAL_WITH_FIXED_PRIOR_LOCAL Build the final V8 decomposition.
%
% The prior block is copied verbatim and its coefficients are frozen from the
% formal augmented LLM-prior fit. The evolved block is the only component fit
% to the residual. This function recombines both pieces only for scoring and
% deployment; it never re-fits the prior block jointly with the evolved block.

basis = [residualCandidate.basis(:);priorBasis(:)];
protected = [residualCandidate.protectedMask(:);true(numel(priorBasis),1)];
combined = build_candidate_from_scratch_local( ...
    basis,protected,Xtr,Xva,Btr,Bva,probe,featureCache);

% The same training samples and RMS normalization are used in both blocks, so
% their column scales must agree exactly up to numerical roundoff.
if numel(priorBasis)>0
    q = combined.colScale((numel(residualCandidate.basis)+1):end);
    rel = max(abs(q-priorColScale(:))./max(abs(priorColScale(:)),1));
    if ~isfinite(rel) || rel > 1e-10
        error('combine_residual_with_fixed_prior_local:PriorScaleMismatch', ...
            'Frozen LLM-prior column scale changed (relative max %.3e).',rel);
    end
end

Xi = [residualFit.XiNormalized;priorXi];
[Atr,Ava] = normalized_design_block_local( ...
    basis,combined.colScale,Xtr,Xva);
trErr = Atr*Xi-Btr;
vaErr = Ava*Xi-Bva;
trMSE = mean(trErr.^2,'all');
vaMSE = mean(vaErr.^2,'all');

combined.XiNormalized = Xi;
combined.trainFitness = trMSE;
combined.fitness = vaMSE;
combined.basisImportance = sqrt(sum(abs(Xi).^2,2));
combined.mutationLockedMask = true(numel(basis),1); % deployment object only

fit = residualFit;
fit.XiNormalized = Xi;
fit.supportMask = abs(Xi)>0;
fit.trainNormalizedMSE = trMSE;
fit.validationNormalizedMSE = vaMSE;
fit.activeCoefficientCount = nnz(fit.supportMask);
fit.normalizedCoefficientFroNorm = norm(Xi,'fro');

coefPhysical = (Xi./combined.colScale(:)).*yScale;
end


function score = score_edsi_short_trajectory_validation_local( ...
    data,trainMask,valMask,basis,coefPhysical,probe)
%SCORE_EDSI_SHORT_TRAJECTORY_VALIDATION_LOCAL Held-out local rollout score.
%
% The manuscript 12-s test trajectory is NEVER used here. Each held-out short
% trajectory recursively propagates only the local DER state while the recorded
% terminal-voltage and command/reference channels are teacher forced. This is
% the same validation principle as score_sindy_short_trajectory_validation,
% extended to the evolved symbolic DSL used by EDSI.

nState = numel(data.stateIndices);
if size(coefPhysical,2) ~= nState
    error('score_edsi_short_trajectory_validation_local:OutputSize', ...
        'Coefficient output width %d does not match nState=%d.', ...
        size(coefPhysical,2),nState);
end
if ~any(valMask)
    score = Inf;
    return;
end

if isfield(data,'stateObserved') && ~isempty(data.stateObserved)
    Xstate = double(data.stateObserved);
else
    Xstate = double(data.X(:,1:nState));
end
scale = std(Xstate(trainMask,:),0,1);
rmsState = sqrt(mean(Xstate(trainMask,:).^2,1));
scale = max(scale,0.05*rmsState);
scale = max(scale,probe.outputScaleFloor);

valIds = unique(data.trajectoryId(valMask),'stable');
errSS = 0;
errN = 0;
for ii = 1:numel(valIds)
    tid = valIds(ii);
    rows = find(valMask & data.trajectoryId==tid);
    if numel(rows)<2, continue; end
    [~,ord] = sort(data.pointInTrajectory(rows));
    rows = rows(ord);
    p = double(data.pointInTrajectory(rows));
    if any(p<1) || any(p>numel(data.trajectoryTime))
        score = Inf;
        return;
    end
    t = double(data.trajectoryTime(p));
    xRef = Xstate(rows,:);
    forcing = double(data.X(rows,nState+1:end));

    x = xRef(1,:);
    for kk = 1:(numel(rows)-1)
        h = t(kk+1)-t(kk);
        if ~(isfinite(h) && h>0)
            score=Inf; return;
        end
        f0=forcing(kk,:); f1=forcing(kk+1,:); fm=0.5*(f0+f1);
        k1=rhs_local(x,f0);
        k2=rhs_local(x+0.5*h*k1,fm);
        k3=rhs_local(x+0.5*h*k2,fm);
        k4=rhs_local(x+h*k3,f1);
        x=x+(h/6)*(k1+2*k2+2*k3+k4);
        if any(~isfinite(x))
            score=Inf; return;
        end
        e=(x-xRef(kk+1,:))./scale;
        if any(~isfinite(e)) || any(abs(e)>1e6)
            score=Inf; return;
        end
        errSS=errSS+sum(e.^2);
        errN=errN+numel(e);
    end
end
if errN<1, score=Inf; else, score=errSS/errN; end

    function dx=rhs_local(xState,forceRow)
        Xrow=[double(xState(:).') double(forceRow(:).')];
        Theta=evaluate_dictionary_raw_local(basis,Xrow);
        dx=double(Theta*coefPhysical);
        dx=reshape(dx,1,[]);
        if numel(dx)~=nState || any(~isfinite(dx))
            dx=nan(1,nState);
        end
    end
end


%% ========================================================================
% EDSI predictor
% ========================================================================


function candidate = build_candidate_from_scratch_local( ...
    basis,protectedMask,Xtr,Xva,Btr,Bva,probe,featureCache)

M = numel(basis);
Atr = zeros(size(Xtr,1),M);
Aval = zeros(size(Xva,1),M);
colScale = zeros(M,1);

for j = 1:M
    feat = get_feature_local(basis{j},Xtr,Xva,probe,featureCache);
    Atr(:,j) = feat.trNorm;
    Aval(:,j) = feat.vaNorm;
    colScale(j) = feat.scale;
end

candidate = empty_candidate_local();
candidate.basis = basis;
candidate.protectedMask = protectedMask(:);
candidate.mutationLockedMask = protectedMask(:);
candidate.Gtr = Atr.'*Atr;
candidate.Gval = Aval.'*Aval;
candidate.Ctr = Atr.'*Btr;
candidate.Cval = Aval.'*Bva;
candidate.colScale = colScale;
candidate.dictionaryKey = dictionary_key_local(basis);
candidate.dictionaryComplexity = dictionary_complexity_local(basis,protectedMask);
candidate.maxDepth = max(cellfun(@(q)q.depth,basis));
end


function [child,valid,diag] = make_llm_prior_augmented_candidate_local( ...
    parent,priorTerms,priorMeta,inputNames,Xtr,Xva,Btr,Bva,probe,featureCache,opt)
%MAKE_LLM_PRIOR_AUGMENTED_CANDIDATE_LOCAL V8 immutable prior-bank builder.
%
% The original V-SINDy dictionary is kept intact as the M-slot evolutionary
% bank. Every valid weak-domain LLM prior term is appended as a compact K-slot
% enhancement bank. The K prior slots are mutation-locked (but remain fully
% sparse-regression selectable, so STLSQ may set them to zero). Consequently:
%   - evolution-controlled dimension = M, identical to V-SINDy/EDSI;
%   - total regression width = M+K and remains constant during evolution;
%   - there is NO prior compression/distillation stage.

child=parent; valid=false;
diag=struct('baseEvolutionWidth',numel(parent.basis),'priorBankWidth',0, ...
    'totalWidth',numel(parent.basis),'lockedPriorCount',0, ...
    'priorKeys',strings(0,1),'validationNormalizedMSE',NaN);
if isempty(priorTerms), return; end

maxDepth=8; maxComplexity=32;
if isfield(opt,'llmPriorDiagnostic') && isstruct(opt.llmPriorDiagnostic)
    q=opt.llmPriorDiagnostic;
    if isfield(q,'maxExpressionDepth'), maxDepth=double(q.maxExpressionDepth); end
    if isfield(q,'maxExpressionComplexity'), maxComplexity=double(q.maxExpressionComplexity); end
end

parentKeys=string(cellfun(@(q)q.key,parent.basis,'UniformOutput',false));
priorExpr=cell(0,1); priorKeys=strings(0,1);
for i=1:numel(priorTerms)
    try
        expr=parse_llm_expression_ode_local(char(priorTerms(i)),inputNames);
    catch
        continue;
    end
    if expr.depth>maxDepth || expr.complexity>maxComplexity, continue; end
    key=string(expr.key);
    if any(parentKeys==key) || any(priorKeys==key), continue; end
    feat=get_feature_local(expr,Xtr,Xva,probe,featureCache);
    if ~feat.valid, continue; end
    priorExpr{end+1,1}=expr; %#ok<AGROW>
    priorKeys(end+1,1)=key; %#ok<AGROW>
end
if isempty(priorExpr), return; end

basis=[parent.basis(:);priorExpr(:)];
protected=[parent.protectedMask(:);true(numel(priorExpr),1)];
try
    child=build_candidate_from_scratch_local( ...
        basis,protected,Xtr,Xva,Btr,Bva,probe,featureCache);
    % ALL LLM enhancement-bank terms are structurally immutable. V8 does not
    % score the appended bank with a V-dictionary-calibrated search threshold.
    % Instead, the complete augmented model is first identified with the formal
    % selector, its LLM-bank contribution is frozen, and EDSI then learns only
    % the residual with the original V-width evolutionary bank.
    child.mutationLockedMask=[parent.protectedMask(:);true(numel(priorExpr),1)];
catch
    child=parent; return;
end

diag.priorBankWidth=numel(priorExpr);
diag.totalWidth=numel(basis);
diag.lockedPriorCount=numel(priorExpr);
diag.priorKeys=priorKeys;
diag.validationNormalizedMSE=child.fitness;
valid=true;
end


function [child,valid,nRetainedPrior,diag] = make_llm_prior_union_compressed_seed_local( ...
    parent,priorTerms,priorMeta,inputNames,Xtr,Xva,Btr,Bva,probe,featureCache,opt)
%MAKE_LLM_PRIOR_UNION_COMPRESSED_SEED_LOCAL Fixed-width prior injection.
%
% V5 mechanism (fixed dictionary width is a hard invariant):
%   1) Parse the LLM/closure proposal bank and prune only NUMERICALLY REDUNDANT
%      LLM proposals (never prune merely because vanilla features can span them).
%   2) Use a temporary [V + LLM] proposal pool only to score data admissibility.
%      This pool is NOT an EDSI model and is never evolved/rolled out.
%   3) Compress back to the original V width by sequential backward deletion
%      with complete refit/revalidation after every deletion.
%   4) Run a small fixed-width swap polish so a path-dependent early deletion
%      can be corrected without changing dictionary width.
%   5) Mutation-lock supplied d/q coordinates and high-confidence,
%      data-admissible LLM terms. STLSQ may still assign them zero coefficient.
%   6) Keep the exact V parent as a strict no-worse path.

child=parent; valid=false; nRetainedPrior=0;
diag=struct('unionWidth',numel(parent.basis),'proposalPoolWidth',numel(parent.basis), ...
    'validPriorCount',0,'redundantPriorPrunedCount',0, ...
    'retainedPriorCount',0,'lockedPriorCount',0, ...
    'unionValidationNormalizedMSE',NaN,'unionSelectedThreshold',NaN, ...
    'compressedValidationNormalizedMSE',NaN,'compressionSteps',0, ...
    'swapPolishSteps',0, ...
    'compressionPolicy','fixed_width_seq_refit_swap_v5', ...
    'retainedPriorKeys',strings(0,1),'lockedPriorKeys',strings(0,1));
if isempty(priorTerms), return; end

maxDepth=8; maxComplexity=32;
highConf=0.80; protectHigh=true; protectCoord=true; requireActive=true;
maxProtected=10; maxWorsening=0.25; redundancyTol=1e-10;
deletionShortlist=20; swapPolish=true; swapPasses=2;
if isfield(opt,'llmPriorDiagnostic') && isstruct(opt.llmPriorDiagnostic)
    q=opt.llmPriorDiagnostic;
    if isfield(q,'maxExpressionDepth'), maxDepth=double(q.maxExpressionDepth); end
    if isfield(q,'maxExpressionComplexity'), maxComplexity=double(q.maxExpressionComplexity); end
    if isfield(q,'highConfidenceThreshold'), highConf=double(q.highConfidenceThreshold); end
    if isfield(q,'protectHighConfidenceTerms'), protectHigh=logical(q.protectHighConfidenceTerms); end
    if isfield(q,'protectSuppliedCoordinateTerms'), protectCoord=logical(q.protectSuppliedCoordinateTerms); end
    if isfield(q,'requireActiveForLLMProtection'), requireActive=logical(q.requireActiveForLLMProtection); end
    if isfield(q,'maxProtectedPriorTerms'), maxProtected=double(q.maxProtectedPriorTerms); end
    if isfield(q,'compressionMaxRelativeWorsening'), maxWorsening=double(q.compressionMaxRelativeWorsening); end
    if isfield(q,'priorRedundancyRelativeTolerance'), redundancyTol=double(q.priorRedundancyRelativeTolerance); end
    if isfield(q,'compressionDeletionShortlist'), deletionShortlist=double(q.compressionDeletionShortlist); end
    if isfield(q,'compressionSwapPolish'), swapPolish=logical(q.compressionSwapPolish); end
    if isfield(q,'compressionSwapPolishMaxPasses'), swapPasses=double(q.compressionSwapPolishMaxPasses); end
end

% Metadata lookup by canonical expression string.
metaMap=containers.Map('KeyType','char','ValueType','any');
if isstruct(priorMeta)
    for im=1:numel(priorMeta)
        if ~isfield(priorMeta(im),'expression'), continue; end
        k=char(string(priorMeta(im).expression));
        metaMap(k)=priorMeta(im);
    end
end

parentKeys=string(cellfun(@(q)q.key,parent.basis,'UniformOutput',false));
priorExpr=cell(0,1); priorKeys=strings(0,1); priorConf=zeros(0,1); priorSource=strings(0,1);
for i=1:numel(priorTerms)
    try
        expr=parse_llm_expression_ode_local(char(priorTerms(i)),inputNames);
    catch
        continue;
    end
    if expr.depth>maxDepth || expr.complexity>maxComplexity, continue; end
    key=string(expr.key);
    if any(parentKeys==key) || any(priorKeys==key), continue; end
    feat=get_feature_local(expr,Xtr,Xva,probe,featureCache);
    if ~feat.valid, continue; end

    conf=0; src="llm_unknown";
    if isKey(metaMap,char(key))
        m=metaMap(char(key));
        if isfield(m,'confidence') && ~isempty(m.confidence)
            qq=double(m.confidence); if isscalar(qq)&&isfinite(qq), conf=max(0,min(1,qq)); end
        end
        if isfield(m,'source') && strlength(string(m.source))>0
            src=string(m.source);
        end
    end
    priorExpr{end+1,1}=expr; %#ok<AGROW>
    priorKeys(end+1,1)=key; %#ok<AGROW>
    priorConf(end+1,1)=conf; %#ok<AGROW>
    priorSource(end+1,1)=src; %#ok<AGROW>
end
if isempty(priorExpr), return; end

% Remove only LLM-to-LLM numerical redundancies. We deliberately do NOT drop
% a physical LLM motif simply because the generic vanilla library can span it;
% replacing generic slots by a compact physical motif is the point of LLM-EDSI.
[priorExpr,priorKeys,priorConf,priorSource,nPruned] = ...
    prune_redundant_llm_prior_terms_local(priorExpr,priorKeys,priorConf,priorSource, ...
    Xtr,Xva,probe,featureCache,redundancyTol);
if isempty(priorExpr), return; end

diag.validPriorCount=numel(priorExpr);
diag.redundantPriorPrunedCount=nPruned;
poolBasis=[parent.basis(:);priorExpr(:)];
poolProtected=[parent.protectedMask(:);false(numel(priorExpr),1)];
diag.unionWidth=numel(poolBasis); % legacy field
ndiag=numel(poolBasis); diag.proposalPoolWidth=ndiag;

try
    pool=build_candidate_from_scratch_local( ...
        poolBasis,poolProtected,Xtr,Xva,Btr,Bva,probe,featureCache);
    % Full selector is diagnostic only. The fixed-width compression itself
    % uses the frozen search lambda/ridge selected on the V parent.
    [poolFit,~]=select_stlsq_fit_local( ...
        pool,Btr,Bva,probe.searchThresholdGrid,probe.searchStlsqIterations, ...
        probe,probe.searchPreferSparseWithinRelativeValidationTolerance);
    pool=score_candidate_local(pool,Btr,Bva,probe);
catch
    return;
end
if ~isfinite(pool.fitness) || any(~isfinite(pool.XiNormalized),'all')
    return;
end

diag.unionValidationNormalizedMSE=pool.fitness;
diag.unionSelectedThreshold=poolFit.lambda;

% Decide which prior terms qualify for mutation locking.
priorOffset=numel(parent.basis);
lockPrior=false(numel(priorExpr),1);
activeUnion=any(abs(pool.XiNormalized)>0,2);
for j=1:numel(priorExpr)
    isCoord=strcmpi(char(priorSource(j)),'supplied_coordinate');
    isHigh=priorConf(j)>=highConf;
    admissible=true;
    if requireActive && ~isCoord
        admissible=activeUnion(priorOffset+j);
    end
    lockPrior(j)=(protectCoord && isCoord) || (protectHigh && isHigh && admissible);
end

% Bound the number of locked non-anchor terms. Coordinates first, then higher
% confidence and more canonical closure/compiled terms.
if nnz(lockPrior)>maxProtected
    idx=find(lockPrior);
    coordScore=double(strcmpi(priorSource(idx),'supplied_coordinate'));
    srcScore=arrayfun(@(k)llm_source_priority_local(priorSource(k)),idx);
    score=[-coordScore(:),-priorConf(idx),-srcScore(:),double(idx(:))];
    [~,ord]=sortrows(score,[1 2 3 4]);
    keep=idx(ord(1:maxProtected));
    lockPrior(:)=false; lockPrior(keep)=true;
end
poolLocked=[parent.protectedMask(:);lockPrior(:)];
lockMap=containers.Map('KeyType','char','ValueType','logical');
for j=1:numel(priorKeys), lockMap(char(priorKeys(j)))=logical(lockPrior(j)); end

% Sequential backward compression with refit at each deletion. The actual EDSI
% seed is not admitted until it has returned to targetWidth.
current=pool;
currentBasis=poolBasis;
currentProtected=poolProtected;
currentLocked=poolLocked;
targetWidth=numel(parent.basis);
priorKeySet=priorKeys(:);
while numel(currentBasis)>targetWidth
    removable=find(~currentProtected & ~currentLocked);
    if isempty(removable)
        child=parent; return;
    end

    imp=double(current.basisImportance(:));
    if numel(imp)~=numel(currentBasis), imp=zeros(numel(currentBasis),1); end
    imp(~isfinite(imp)|imp<0)=0;
    [~,ord]=sortrows([imp(removable),double(removable(:))],[1 2]);
    shortlist=removable(ord(1:min(deletionShortlist,numel(ord))));

    cand=cell(numel(shortlist),1);
    fit=inf(numel(shortlist),1);
    removedPrior=false(numel(shortlist),1);
    removedComplexity=zeros(numel(shortlist),1);
    for ir=1:numel(shortlist)
        j=shortlist(ir);
        keep=true(numel(currentBasis),1); keep(j)=false;
        try
            cc=build_candidate_from_scratch_local( ...
                currentBasis(keep),currentProtected(keep), ...
                Xtr,Xva,Btr,Bva,probe,featureCache);
            cc.mutationLockedMask=currentLocked(keep);
            cc=score_candidate_local(cc,Btr,Bva,probe);
            cand{ir}=cc;
            fit(ir)=cc.fitness;
            removedPrior(ir)=any(priorKeySet==string(currentBasis{j}.key));
            removedComplexity(ir)=currentBasis{j}.complexity;
        catch
        end
    end
    if all(~isfinite(fit)), child=parent; return; end

    bestFit=min(fit);
    tieTol=probe.validationAbsoluteTolerance + 0.01*max(bestFit,eps);
    eligible=find(isfinite(fit) & fit<=bestFit+tieTol);
    % Within a 1% validation tie, remove a generic term first and preserve the
    % compact physics motif; if still tied, remove the more complex term.
    tieMat=[double(removedPrior(eligible)),-removedComplexity(eligible),fit(eligible),double(eligible(:))];
    [~,oo]=sortrows(tieMat,[1 2 3 4]);
    pick=eligible(oo(1));
    j=shortlist(pick);
    keep=true(numel(currentBasis),1); keep(j)=false;
    currentBasis=currentBasis(keep);
    currentProtected=currentProtected(keep);
    currentLocked=currentLocked(keep);
    current=cand{pick};
    current.mutationLockedMask=currentLocked;
    diag.compressionSteps=diag.compressionSteps+1;
end

if numel(currentBasis)~=targetWidth || ~isfinite(current.fitness)
    child=parent; return;
end

% Fixed-width swap polish: revisit LLM terms that compression removed and let
% each compete against low-importance generic slots. Width NEVER changes.
if swapPolish && swapPasses>0
    [current,currentBasis,currentProtected,currentLocked,nSwap] = ...
        fixed_width_prior_swap_polish_local(current,currentBasis,currentProtected, ...
        currentLocked,priorExpr,priorKeys,lockMap,Xtr,Xva,Btr,Bva,probe, ...
        featureCache,deletionShortlist,swapPasses);
    diag.swapPolishSteps=nSwap;
end

% Reject catastrophically poor compressed seeds. The exact V parent is always
% retained, so an unhelpful LLM proposal cannot dominate initialization.
if current.fitness > parent.fitness*(1+maxWorsening) + probe.validationAbsoluteTolerance
    child=parent; return;
end

child=current;
retainedKeys=string(cellfun(@(q)q.key,currentBasis,'UniformOutput',false));
nRetainedPrior=nnz(ismember(retainedKeys,priorKeys));
diag.retainedPriorCount=nRetainedPrior;
retainedPriorMask=ismember(retainedKeys,priorKeys);
diag.retainedPriorKeys=retainedKeys(retainedPriorMask);
lockedMaskFinal=currentLocked & ~currentProtected;
diag.lockedPriorCount=nnz(lockedMaskFinal);
diag.lockedPriorKeys=retainedKeys(lockedMaskFinal);
diag.compressedValidationNormalizedMSE=child.fitness;
valid=nRetainedPrior>0 && ~strcmp(child.dictionaryKey,parent.dictionaryKey);
if ~valid, child=parent; end
end


function [exprOut,keyOut,confOut,srcOut,nPruned] = prune_redundant_llm_prior_terms_local( ...
    exprIn,keyIn,confIn,srcIn,Xtr,Xva,probe,featureCache,relTol)
%PRUNE_REDUNDANT_LLM_PRIOR_TERMS_LOCAL Remove only LLM-internal span duplicates.
% Ranking prefers supplied coordinates, motif-closure terms, high confidence,
% and lower symbolic complexity. Vanilla-library span is intentionally ignored.

n=numel(exprIn); nPruned=0;
if n<=1
    exprOut=exprIn; keyOut=keyIn; confOut=confIn; srcOut=srcIn; return;
end
priority=zeros(n,1); complexity=zeros(n,1);
for i=1:n
    priority(i)=llm_source_priority_local(srcIn(i));
    complexity(i)=exprIn{i}.complexity;
end
[~,order]=sortrows([-priority(:),-confIn(:),complexity(:),(1:n).'],[1 2 3 4]);
keepIdx=zeros(0,1); K=[];
for io=1:numel(order)
    i=order(io);
    feat=get_feature_local(exprIn{i},Xtr,Xva,probe,featureCache);
    if ~feat.valid, nPruned=nPruned+1; continue; end
    v=[feat.rawTr(:);feat.rawVa(:)];
    nr=norm(v);
    if ~isfinite(nr) || nr<=1e-14, nPruned=nPruned+1; continue; end
    v=v/nr;
    redundant=false;
    if ~isempty(K)
        beta=pinv(K)*v;
        rr=v-K*beta;
        redundant=(norm(rr)/max(norm(v),eps) <= relTol);
    end
    if redundant
        nPruned=nPruned+1;
    else
        keepIdx(end+1,1)=i; %#ok<AGROW>
        K=[K,v]; %#ok<AGROW>
    end
end
keepIdx=sort(keepIdx);
exprOut=exprIn(keepIdx); keyOut=keyIn(keepIdx);
confOut=confIn(keepIdx); srcOut=srcIn(keepIdx);
end


function p=llm_source_priority_local(src)
s=lower(strtrim(string(src)));
if s=="supplied_coordinate"
    p=4;
elseif s=="llm_closure"
    p=3;
elseif s=="llm_compiled"
    p=2;
elseif s=="llm_latent"
    p=1;
else
    p=0;
end
end


function [current,currentBasis,currentProtected,currentLocked,nAccepted] = ...
    fixed_width_prior_swap_polish_local(current,currentBasis,currentProtected, ...
    currentLocked,priorExpr,priorKeys,lockMap,Xtr,Xva,Btr,Bva,probe, ...
    featureCache,shortlistCount,maxPasses)
%FIXED_WIDTH_PRIOR_SWAP_POLISH_LOCAL Reconsider removed LLM motifs at fixed M.

nAccepted=0;
for pass=1:maxPasses
    keys=string(cellfun(@(q)q.key,currentBasis,'UniformOutput',false));
    missing=find(~ismember(priorKeys,keys));
    if isempty(missing), break; end

    % Highest-confidence/canonical order was already used upstream; limit the
    % number of missing priors considered to keep the polish cheap.
    missing=missing(1:min(8,numel(missing)));
    removable=find(~currentProtected & ~currentLocked & ~ismember(keys,priorKeys));
    if isempty(removable), break; end
    imp=double(current.basisImportance(:));
    if numel(imp)~=numel(currentBasis), imp=zeros(numel(currentBasis),1); end
    imp(~isfinite(imp)|imp<0)=0;
    [~,ord]=sortrows([imp(removable),double(removable(:))],[1 2]);
    removable=removable(ord(1:min(shortlistCount,numel(ord))));

    best=current; bestBasis=currentBasis; bestProtected=currentProtected;
    bestLocked=currentLocked; bestFit=current.fitness;
    for im=1:numel(missing)
        pe=priorExpr{missing(im)}; pk=priorKeys(missing(im));
        for ir=1:numel(removable)
            j=removable(ir);
            b=currentBasis; pr=currentProtected; lk=currentLocked;
            b{j}=pe; pr(j)=false;
            lk(j)=isKey(lockMap,char(pk)) && lockMap(char(pk));
            try
                cc=build_candidate_from_scratch_local(b,pr,Xtr,Xva,Btr,Bva,probe,featureCache);
                cc.mutationLockedMask=lk;
                cc=score_candidate_local(cc,Btr,Bva,probe);
                if cc.fitness + probe.validationAbsoluteTolerance < bestFit
                    best=cc; bestBasis=b; bestProtected=pr; bestLocked=lk; bestFit=cc.fitness;
                end
            catch
            end
        end
    end
    if bestFit + probe.validationAbsoluteTolerance < current.fitness
        current=best; currentBasis=bestBasis; currentProtected=bestProtected;
        currentLocked=bestLocked; current.mutationLockedMask=currentLocked;
        nAccepted=nAccepted+1;
    else
        break;
    end
end
end

function child = unique_mutated_child_local( ...
    parent,seen,Xtr,Xva,Btr,Bva,probe,featureCache)

for attempt = 1:probe.maxChildRetries
    child = mutate_candidate_local( ...
        parent,Xtr,Xva,Btr,Bva,probe,featureCache);
    if ~isKey(seen,child.dictionaryKey)
        return;
    end
end

% Extremely rare fallback: return the last candidate even if structurally
% duplicated. Selection still handles duplicate elites conservatively.
end


function child = mutate_candidate_local( ...
    parent,Xtr,Xva,Btr,Bva,probe,featureCache)

child = parent;
sourceBasis = parent.basis;  % offspring uses the parent generation as source
M = numel(sourceBasis);
if isfield(parent,'mutationLockedMask') && numel(parent.mutationLockedMask)==numel(parent.protectedMask)
    mutableSlots = find(~logical(parent.mutationLockedMask));
else
    mutableSlots = find(~parent.protectedMask);
end

nMut = sample_discrete_local( ...
    probe.mutationSlotCounts,probe.mutationSlotProbabilities);
nMut = min(nMut,numel(mutableSlots));
slots = choose_mutation_slots_local(parent,mutableSlots,nMut,probe);

replaced = false(M,1);
currentKeys = cellfun(@(q)q.key,child.basis,'UniformOutput',false);

for s = reshape(slots,1,[])
    oldKey = child.basis{s}.key;
    accepted = false;

    for attempt = 1:40
        newExpr = random_evolution_expression_local( ...
            sourceBasis,parent.basisImportance,probe);
        if isempty(newExpr)
            continue;
        end
        if strcmp(newExpr.key,oldKey)
            continue;
        end
        if newExpr.depth > probe.maxBasisDepth || ...
                newExpr.complexity > probe.maxBasisComplexity
            continue;
        end

        % Reject duplicate basis functions within the fixed-width dictionary.
        duplicateMask = strcmp(currentKeys,newExpr.key);
        duplicateMask(s) = false;
        if any(duplicateMask)
            continue;
        end

        % Evaluate once now so nonfinite/explosive expressions are rejected
        % before they enter the candidate Gram matrix.
        feat = get_feature_local(newExpr,Xtr,Xva,probe,featureCache);
        if ~feat.valid
            continue;
        end

        child.basis{s} = newExpr;
        currentKeys{s} = newExpr.key;
        replaced(s) = true;
        accepted = true;
        break;
    end

    if ~accepted
        child.basis{s} = parent.basis{s};
        currentKeys{s} = oldKey;
    end
end

replacedIdx = find(replaced);
if isempty(replacedIdx)
    % Force at least one mutation if random attempts were all invalid.
    s = mutableSlots(randi(numel(mutableSlots)));
    for attempt = 1:100
        newExpr = random_evolution_expression_local( ...
            sourceBasis,parent.basisImportance,probe);
        if isempty(newExpr), continue; end
        if newExpr.depth > probe.maxBasisDepth || ...
                newExpr.complexity > probe.maxBasisComplexity
            continue;
        end
        duplicateMask = strcmp(currentKeys,newExpr.key);
        duplicateMask(s) = false;
        if any(duplicateMask), continue; end
        feat = get_feature_local(newExpr,Xtr,Xva,probe,featureCache);
        if ~feat.valid, continue; end
        child.basis{s} = newExpr;
        currentKeys{s} = newExpr.key;
        replaced(s) = true;
        break;
    end
    replacedIdx = find(replaced);
end

if isempty(replacedIdx)
    % If bounded grammar truly cannot generate a valid unique mutation, the
    % parent survives unchanged. This is safe under elitism.
    child.dictionaryKey = parent.dictionaryKey;
    return;
end

% Fixed-width speed trick: retain the parent's Gram/cross-target matrices
% and recompute only rows/columns corresponding to replaced slots.
child.Gtr = parent.Gtr;
child.Gval = parent.Gval;
child.Ctr = parent.Ctr;
child.Cval = parent.Cval;
child.colScale = parent.colScale;

for j = reshape(replacedIdx,1,[])
    fj = get_feature_local(child.basis{j},Xtr,Xva,probe,featureCache);
    child.colScale(j) = fj.scale;
    child.Ctr(j,:) = fj.trNorm.'*Btr;
    child.Cval(j,:) = fj.vaNorm.'*Bva;

    for k = 1:M
        fk = get_feature_local(child.basis{k},Xtr,Xva,probe,featureCache);
        gtr = fj.trNorm.'*fk.trNorm;
        gva = fj.vaNorm.'*fk.vaNorm;
        child.Gtr(j,k) = gtr;
        child.Gtr(k,j) = gtr;
        child.Gval(j,k) = gva;
        child.Gval(k,j) = gva;
    end
end

child.dictionaryKey = dictionary_key_local(child.basis);
child.dictionaryComplexity = ...
    dictionary_complexity_local(child.basis,child.protectedMask);
child.maxDepth = max(cellfun(@(q)q.depth,child.basis));
child = score_candidate_local(child,Btr,Bva,probe);
end


function expr = random_evolution_expression_local(sourceBasis,basisImportance,probe)
r = rand;

% Do not choose the constant as a compositional parent; multiplication by 1
% and sin/cos(1) add no useful structure.
parentPool = 2:numel(sourceBasis);

if r < probe.productProbability
    i = choose_expression_parent_local(parentPool,basisImportance,probe);
    j = choose_expression_parent_local(parentPool,basisImportance,probe);
    expr = make_product_expression_local(sourceBasis{i},sourceBasis{j});

elseif r < probe.productProbability + probe.sinProbability
    i = choose_expression_parent_local(parentPool,basisImportance,probe);
    expr = make_unary_expression_local('sin',sourceBasis{i});

else
    i = choose_expression_parent_local(parentPool,basisImportance,probe);
    expr = make_unary_expression_local('cos',sourceBasis{i});
end

if expr.depth > probe.maxBasisDepth || ...
        expr.complexity > probe.maxBasisComplexity
    expr = [];
end
end


function slots = choose_mutation_slots_local(parent,mutableSlots,nMut,probe)
% Low-contribution current bases are preferentially replaced in the guided
% variant. Random exploration is retained by the probability gate.

if ~probe.useSaliencyGuidance || ...
        rand > probe.guidedReplaceProbability || ...
        isempty(parent.basisImportance)

    perm = randperm(numel(mutableSlots),nMut);
    slots = mutableSlots(perm);
    return;
end

imp = double(parent.basisImportance(mutableSlots));
imp(~isfinite(imp) | imp<0) = 0;

positive = imp(imp>0);
if isempty(positive)
    scale = 1;
else
    scale = median(positive);
end

floorVal = max(probe.guidanceFloorFraction*scale,eps);
weights = 1./(imp + floorVal);
slots = weighted_sample_without_replacement_local( ...
    mutableSlots,weights,nMut);
end


function idx = choose_expression_parent_local(parentPool,basisImportance,probe)
% High-contribution current bases are preferentially used as parents in the
% guided variant, while a fixed random-exploration probability is retained.

if ~probe.useSaliencyGuidance || ...
        rand > probe.guidedParentProbability || ...
        isempty(basisImportance)

    idx = parentPool(randi(numel(parentPool)));
    return;
end

imp = double(basisImportance(parentPool));
imp(~isfinite(imp) | imp<0) = 0;
mx = max(imp);

if ~(isfinite(mx) && mx>0)
    idx = parentPool(randi(numel(parentPool)));
    return;
end

weights = imp + probe.guidanceFloorFraction*mx;
idx = weighted_sample_one_local(parentPool,weights);
end


function item = weighted_sample_one_local(items,weights)
weights = double(weights(:));
items = items(:);

weights(~isfinite(weights) | weights<0) = 0;
s = sum(weights);

if ~(isfinite(s) && s>0)
    item = items(randi(numel(items)));
    return;
end

u = rand*s;
cs = cumsum(weights);
k = find(cs>=u,1,'first');
if isempty(k), k=numel(items); end
item = items(k);
end


function selected = weighted_sample_without_replacement_local(items,weights,K)
items = items(:).';
weights = double(weights(:).');
selected = zeros(1,K);

for k = 1:K
    if isempty(items)
        selected = selected(1:k-1);
        return;
    end

    choice = weighted_sample_one_local(1:numel(items),weights);
    selected(k) = items(choice);
    items(choice) = [];
    weights(choice) = [];
end
end


function probe = configure_support_ridge_probe_local(probe,opt,data,nTrain)
%CONFIGURE_SUPPORT_RIDGE_PROBE_LOCAL Mirror the V-SINDy noisy-label backend.
%
% EDSI changes only the dictionary.  The numerical identification backend is
% shared with V-SINDy:
%   1) OLS-STLSQ support discovery;
%   2a) exact labels: fixed rho=1e-10 refit on frozen support;
%   2b) reconstructed noisy labels: validation-selected support ridge.

[applyRidge,configured,policy] = should_apply_sindy_support_ridge(opt,data);
probe.supportRidgeApplied = logical(applyRidge);
probe.supportRidgeConfigured = logical(configured);
probe.supportRidgePolicy = char(policy);
probe.nTrainSamples = double(nTrain);
probe.validationAbsoluteTolerance = double(opt.stlsq.validationAbsoluteTolerance);

if configured
    probe.supportRidgeRelativeAlphaGrid = unique( ...
        double(opt.stlsq.supportRidge.relativeAlphaGrid(:).'),'stable');
    probe.supportRidgeTieRelativeValidationTolerance = ...
        double(opt.stlsq.supportRidge.tieRelativeValidationTolerance);
else
    probe.supportRidgeRelativeAlphaGrid = 0;
    probe.supportRidgeTieRelativeValidationTolerance = 0;
end

if ~probe.supportRidgeApplied
    probe.supportRidgeRelativeAlphaGrid = 0;
end
probe.searchSupportRidgeRelativeAlpha = 0;
end


function candidate = score_candidate_local(candidate,Btr,Bva,probe)
%SEARCH-STAGE FITNESS: cheap fixed-threshold STLSQ plus the same optional
% frozen-support ridge used by V-SINDy for reconstructed noisy derivatives.
%
% lambda and (when applicable) support-ridge rho are selected ONCE from the
% actual search target and then frozen during generations. Ordinary EDSI uses
% the initial V dictionary; V8 LLM-prior EDSI reselects them on the residual
% after freezing the prior contribution.

if ~isfield(probe,'searchLambda') || ~isscalar(probe.searchLambda) || ...
        ~isfinite(probe.searchLambda)
    error('score_candidate_local:SearchLambda', ...
        'probe.searchLambda must be selected before scoring EDSI candidates.');
end

[XiSupport,ok] = stlsq_from_gram_local(candidate.Gtr,candidate.Ctr, ...
    probe.searchLambda,size(Btr,2),probe.supportDiscoveryRho,probe.searchStlsqIterations);
if ~ok || any(~isfinite(XiSupport),'all')
    candidate.fitness = inf;
    candidate.trainFitness = inf;
    candidate.XiNormalized = XiSupport;
    candidate.basisImportance = zeros(size(candidate.Gtr,1),1);
    return;
end

supportMask = abs(XiSupport)>0;
Xi = XiSupport;
if probe.supportRidgeApplied
    [Xi,ok] = refit_support_ridge_from_gram_local( ...
        candidate.Gtr,candidate.Ctr,supportMask, ...
        probe.searchSupportRidgeRelativeAlpha,probe.nTrainSamples);
else
    [Xi,ok] = refit_support_fixed_ridge_from_gram_local( ...
        candidate.Gtr,candidate.Ctr,supportMask,probe.finalSupportRidgeRho);
end

if ~ok || any(~isfinite(Xi),'all')
    candidate.fitness = inf;
    candidate.trainFitness = inf;
    candidate.XiNormalized = Xi;
    candidate.basisImportance = zeros(size(candidate.Gtr,1),1);
    return;
end

valSSE = quadratic_sse_local(candidate.Gval,candidate.Cval,Bva,Xi);
trSSE = quadratic_sse_local(candidate.Gtr,candidate.Ctr,Btr,Xi);

candidate.fitness = max(valSSE,0)/numel(Bva);
candidate.trainFitness = max(trSSE,0)/numel(Btr);
candidate.XiNormalized = Xi;
candidate.basisImportance = sqrt(sum(abs(Xi).^2,2));
end


function [fit,sweep] = select_stlsq_fit_local( ...
    candidate,Btr,Bva,lambdaGrid,nIter,probe,relativeSparseTolerance)
%SELECT_STLSQ_FIT_LOCAL Shared V-SINDy-style model selection on an evolved dict.
%
% Support discovery uses the OLS-STLSQ sequence. For exact labels the support
% receives one fixed tiny-rho refit. For reconstructed derivative labels, each
% discovered support is instead refit over the SAME
% support-preserving ridge grid used by V-SINDy.  Selection follows the same
% near-best-validation -> minimum-support -> ridge tie-break principle.

lambdas = unique(sort(double(lambdaGrid(:))),'stable');
if probe.supportRidgeApplied
    ridgeGrid = unique(double(probe.supportRidgeRelativeAlphaGrid(:).'),'stable');
else
    ridgeGrid = 0;
end
if ~any(ridgeGrid==0)
    ridgeGrid = [0 ridgeGrid];
end

nCand = numel(lambdas)*numel(ridgeGrid);
lambdaCol = nan(nCand,1);
rhoCol = nan(nCand,1);
val = inf(nCand,1);
tr = inf(nCand,1);
active = inf(nCand,1);
normXi = inf(nCand,1);
xis = cell(nCand,1);
supports = cell(nCand,1);

q = 0;
for il = 1:numel(lambdas)
    [XiSupport,okSupport] = stlsq_from_gram_local( ...
        candidate.Gtr,candidate.Ctr,lambdas(il),size(Btr,2), ...
        probe.supportDiscoveryRho,nIter);
    if okSupport && all(isfinite(XiSupport),'all')
        supportMask = abs(XiSupport)>0;
    else
        supportMask = false(size(XiSupport));
    end

    for ia = 1:numel(ridgeGrid)
        q = q+1;
        lambdaCol(q) = lambdas(il);
        rhoCol(q) = ridgeGrid(ia);
        supports{q} = supportMask;

        if ~okSupport || any(~isfinite(XiSupport),'all')
            xis{q} = XiSupport;
            continue;
        end

        if probe.supportRidgeApplied
            [Xi,ok] = refit_support_ridge_from_gram_local( ...
                candidate.Gtr,candidate.Ctr,supportMask,ridgeGrid(ia), ...
                probe.nTrainSamples);
        else
            [Xi,ok] = refit_support_fixed_ridge_from_gram_local( ...
                candidate.Gtr,candidate.Ctr,supportMask,probe.finalSupportRidgeRho);
        end
        xis{q} = Xi;
        if ~ok || any(~isfinite(Xi),'all')
            continue;
        end

        valSSE = quadratic_sse_local(candidate.Gval,candidate.Cval,Bva,Xi);
        trSSE = quadratic_sse_local(candidate.Gtr,candidate.Ctr,Btr,Xi);
        val(q) = max(valSSE,0)/numel(Bva);
        tr(q) = max(trSSE,0)/numel(Btr);
        active(q) = nnz(supportMask);
        normXi(q) = norm(Xi,'fro');
    end
end

finiteIdx = find(isfinite(val));
if isempty(finiteIdx)
    error('select_stlsq_fit_local:NoFiniteCandidate', ...
        'No finite STLSQ/support-ridge candidate was available.');
end

bestVal = min(val(finiteIdx));
tol = probe.validationAbsoluteTolerance + ...
    relativeSparseTolerance*max(bestVal,eps);
eligible = finiteIdx(val(finiteIdx) <= bestVal + tol);

bestActive = min(active(eligible));
cTol = 100*eps(max(1,bestActive));
candidates = eligible(abs(active(eligible)-bestActive) <= cTol);

if probe.supportRidgeApplied
    cVal = val(candidates);
    bestCandidateVal = min(cVal);
    ridgeValTol = probe.validationAbsoluteTolerance + ...
        probe.supportRidgeTieRelativeValidationTolerance* ...
        max(bestCandidateVal,eps);
    near = candidates(cVal <= bestCandidateVal + ridgeValTol);

    norms = normXi(near);
    bestNorm = min(norms);
    nTol = 100*eps(max(1,bestNorm));
    near2 = near(abs(norms-bestNorm) <= nTol);

    if numel(near2)>1
        [~,loc] = min(val(near2));
        near2 = near2(loc);
    end
    if numel(near2)>1
        [~,loc] = min(rhoCol(near2));
        near2 = near2(loc);
    end
    bestIdx = near2(1);
else
    [~,loc] = min(val(candidates));
    bestIdx = candidates(loc);
end

fit = struct();
fit.lambda = lambdaCol(bestIdx);
fit.supportRidgeRelativeAlpha = rhoCol(bestIdx);
fit.supportRidgeApplied = probe.supportRidgeApplied;
fit.XiNormalized = xis{bestIdx};
fit.supportMask = supports{bestIdx};
fit.trainNormalizedMSE = tr(bestIdx);
fit.validationNormalizedMSE = val(bestIdx);
fit.activeCoefficientCount = active(bestIdx);
fit.normalizedCoefficientFroNorm = normXi(bestIdx);

sweep = table(lambdaCol,rhoCol,val,tr,active,normXi, ...
    'VariableNames',{'Threshold','SupportRidgeRelativeAlpha', ...
    'ValidationNormalizedMSE','TrainNormalizedMSE', ...
    'ActiveCoefficientCount','NormalizedCoefficientFroNorm'});
end


function [Xi,ok] = refit_support_ridge_from_gram_local( ...
    G,C,supportMask,relativeAlpha,nTrain)
%REFIT_SUPPORT_RIDGE_FROM_GRAM_LOCAL Gram-form equivalent of
% refit_stlsq_support_ridge.m.  The support is frozen.  As in V-SINDy,
% relativeAlpha is multiplied by Ntrain so it is dimensionless relative to
% the normalized Gram-matrix scale.

validateattributes(relativeAlpha,{'numeric'}, ...
    {'scalar','nonnegative','finite'});
Xi = zeros(size(G,1),size(C,2));
ok = true;
lambda = double(relativeAlpha)*max(double(nTrain),1);

for j = 1:size(C,2)
    active = find(supportMask(:,j));
    if isempty(active)
        continue;
    end
    Gj = G(active,active);
    Cj = C(active,j);
    [beta,okj] = ridge_from_gram_local(Gj,Cj,lambda);
    if ~okj
        ok = false;
        Xi(:) = NaN;
        return;
    end
    Xi(active,j) = beta;
end
end


function [Xi,ok] = refit_support_fixed_ridge_from_gram_local( ...
    G,C,supportMask,rho)
%REFIT_SUPPORT_FIXED_RIDGE_FROM_GRAM_LOCAL Literal fixed-rho refit.
% The support is frozen and rho is NOT scaled by the sample count.
Xi=zeros(size(G,1),size(C,2));
ok=true;
for j=1:size(C,2)
    active=find(supportMask(:,j));
    if isempty(active), continue; end
    [beta,okj]=ridge_from_gram_local(G(active,active),C(active,j),rho);
    if ~okj
        ok=false; Xi(:)=NaN; return;
    end
    Xi(active,j)=beta;
end
end


function [Xi,ok] = stlsq_from_gram_local(G,C,lambda,nOut,rho,nIter)
% Gram-form STLSQ. Formal shared-backend support discovery calls this with rho=0.
% Mathematically this is the same sequence
% of threshold/support-refit operations as sparsifyDynamics, but uses G=A''A
% and C=A''B already maintained by the fixed-width evolutionary search.
M = size(G,1);
Xi = zeros(M,nOut);
[Xi,ok] = ridge_from_gram_local(G,C,rho);
if ~ok || lambda<=0
    return;
end

for iter = 1:nIter %#ok<NASGU>
    small = abs(Xi) < lambda;
    Xi(small) = 0;
    for j = 1:nOut
        active = ~small(:,j);
        if ~any(active)
            Xi(:,j) = 0;
            continue;
        end
        [beta,okj] = ridge_from_gram_local( ...
            G(active,active),C(active,j),rho);
        if ~okj
            ok = false;
            return;
        end
        Xi(:,j) = 0;
        Xi(active,j) = beta;
    end
end
end


function [X,ok] = ridge_from_gram_local(G,C,rho)
G = 0.5*(G+G.');
if rho <= 0
    % V-SINDy's support-ridge grid explicitly includes rho=0.  The direct
    % implementation solves A_S\\b; in Gram form use the Moore-Penrose
    % solution of G beta=C so rank-deficient frozen supports remain valid.
    X = pinv(G)*C;
    ok = all(isfinite(X),'all');
    return;
end

G = G + rho*eye(size(G,1));
[L,p] = chol(G,'lower');
if p ~= 0
    X = nan(size(G,1),size(C,2));
    ok = false;
    return;
end
X = L'\(L\C);
ok = all(isfinite(X),'all');
end


function sse = quadratic_sse_local(G,C,B,Xi)
modelEnergy = sum(Xi.*(G*Xi),'all');
crossEnergy = sum(Xi.*C,'all');
targetEnergy = sum(B.^2,'all');
sse = modelEnergy - 2*crossEnergy + targetEnergy;
end


function [elites,stats] = select_elites_local(population,K)
P = numel(population);
fitness = inf(P,1);
complexity = inf(P,1);
keys = strings(P,1);

for i = 1:P
    fitness(i) = population{i}.fitness;
    complexity(i) = population{i}.dictionaryComplexity;
    keys(i) = string(population{i}.dictionaryKey);
end

[~,ord] = sortrows([fitness complexity],[1 2]);

% Prefer structurally unique elites. If fewer than K unique candidates exist,
% fill remaining slots by score so the evolution never crashes.
elites = cell(K,1);
used = containers.Map('KeyType','char','ValueType','logical');
count = 0;

for ii = 1:numel(ord)
    idx = ord(ii);
    key = char(keys(idx));
    if ~isKey(used,key)
        count = count + 1;
        elites{count} = population{idx};
        used(key) = true;
        if count == K, break; end
    end
end

if count < K
    for ii = 1:numel(ord)
        idx = ord(ii);
        count = count + 1;
        elites{count} = population{idx};
        if count == K, break; end
    end
end

finiteFitness = fitness(isfinite(fitness));
if isempty(finiteFitness)
    med = inf;
else
    med = median(finiteFitness);
end

stats = struct();
stats.bestFitness = elites{1}.fitness;
stats.medianFitness = med;
stats.bestComplexity = elites{1}.dictionaryComplexity;
stats.uniqueCount = numel(unique(keys));
end


%% ========================================================================
% Expression grammar and canonicalization
% ========================================================================


function basis = make_initial_v_dictionary_local(inputNames)
n = numel(inputNames);
basis = cell(0,1);

basis{end+1,1} = make_constant_expression_local();
vars = cell(n,1);
for i = 1:n
    vars{i} = make_variable_expression_local(i,inputNames(i));
    basis{end+1,1} = vars{i}; %#ok<AGROW>
end

% Q2_narrow only: degree-2 monomials, including squares/cross-products.
for i = 1:n
    for j = i:n
        basis{end+1,1} = make_product_expression_local(vars{i},vars{j}); %#ok<AGROW>
    end
end

for i = 1:n
    basis{end+1,1} = make_unary_expression_local('sin',vars{i}); %#ok<AGROW>
end
for i = 1:n
    basis{end+1,1} = make_unary_expression_local('cos',vars{i}); %#ok<AGROW>
end
end


function expr = make_constant_expression_local()
expr = expression_template_local();
expr.op = 'const';
expr.varIndex = 0;
expr.children = {};
expr.key = '1';
expr.label = '1';
expr.depth = 0;
expr.complexity = 0;
end


function expr = make_variable_expression_local(idx,label)
expr = expression_template_local();
expr.op = 'var';
expr.varIndex = idx;
expr.children = {};
expr.key = sprintf('x%d',idx);
expr.label = char(string(label));
expr.depth = 0;
expr.complexity = 0;
end


function expr = make_unary_expression_local(op,child)
expr = expression_template_local();
expr.op = char(op);
expr.varIndex = 0;
expr.children = {child};
expr.key = sprintf('%s(%s)',char(op),child.key);
expr.label = sprintf('%s(%s)',char(op),child.label);
expr.depth = child.depth + 1;
expr.complexity = child.complexity + 1;
end


function expr = make_product_expression_local(a,b)
% Canonical associative/commutative product representation.
factors = {};
if strcmp(a.op,'prod')
    factors = [factors a.children]; %#ok<AGROW>
else
    factors{end+1} = a; %#ok<AGROW>
end
if strcmp(b.op,'prod')
    factors = [factors b.children]; %#ok<AGROW>
else
    factors{end+1} = b; %#ok<AGROW>
end

keys = cellfun(@(q)q.key,factors,'UniformOutput',false);
[~,ord] = sort(keys);
factors = factors(ord);
keys = keys(ord);
labels = cellfun(@(q)q.label,factors,'UniformOutput',false);

expr = expression_template_local();
expr.op = 'prod';
expr.varIndex = 0;
expr.children = factors;
expr.key = ['prod(' strjoin(keys,',') ')'];
expr.label = strjoin(labels,'*');
expr.depth = 1 + max(cellfun(@(q)q.depth,factors));
expr.complexity = sum(cellfun(@(q)q.complexity,factors)) + numel(factors)-1;
end


function expr = expression_template_local()
expr = struct( ...
    'op','', ...
    'varIndex',0, ...
    'children',{{}}, ...
    'key','', ...
    'label','', ...
    'depth',0, ...
    'complexity',0);
end


function feat = get_feature_local(expr,Xtr,Xva,probe,featureCache)
key = expr.key;
if isKey(featureCache,key)
    feat = featureCache(key);
    return;
end

rawTr = evaluate_expression_cached_local(expr,Xtr,probe,featureCache,'train');
rawVa = evaluate_expression_cached_local(expr,Xva,probe,featureCache,'validation');

valid = all(isfinite(rawTr)) && all(isfinite(rawVa));
if valid
    peak = max([abs(rawTr(:));abs(rawVa(:))]);
    valid = isfinite(peak) && peak <= probe.maxBasisAbsValue;
end

if valid
    scale = sqrt(mean(rawTr.^2));
    scale = max(scale,probe.libraryScaleFloor);
    trNorm = rawTr/scale;
    vaNorm = rawVa/scale;
else
    scale = 1;
    trNorm = zeros(size(rawTr));
    vaNorm = zeros(size(rawVa));
end

feat = struct();
feat.rawTr = rawTr;
feat.rawVa = rawVa;
feat.trNorm = trNorm;
feat.vaNorm = vaNorm;
feat.scale = scale;
feat.valid = valid;
featureCache(key) = feat;
end


function value = evaluate_expression_cached_local(expr,X,probe,featureCache,whichSet)
% Reuse full feature-cache entries when possible. During first construction of
% an expression, child entries are recursively created through get_feature.
key = expr.key;
if isKey(featureCache,key)
    q = featureCache(key);
    if strcmp(whichSet,'train')
        value = q.rawTr;
    else
        value = q.rawVa;
    end
    return;
end

switch expr.op
    case 'const'
        value = ones(size(X,1),1);

    case 'var'
        value = X(:,expr.varIndex);

    case 'sin'
        child = expr.children{1};
        value = sin(evaluate_expression_direct_local(child,X));

    case 'cos'
        child = expr.children{1};
        value = cos(evaluate_expression_direct_local(child,X));

    case 'square'
        child = evaluate_expression_direct_local(expr.children{1},X);
        value = child.^2;

    case 'sqrt_pos'
        child = evaluate_expression_direct_local(expr.children{1},X);
        if any(child < -100*eps(max(1,max(abs(child)))))
            value = nan(size(child));
        else
            value = sqrt(max(child,0));
        end

    case 'prod'
        value = ones(size(X,1),1);
        for k = 1:numel(expr.children)
            value = value .* evaluate_expression_direct_local(expr.children{k},X);
        end

    case 'add'
        value = zeros(size(X,1),1);
        for k = 1:numel(expr.children)
            value = value + evaluate_expression_direct_local(expr.children{k},X);
        end

    case 'sub'
        value = evaluate_expression_direct_local(expr.children{1},X) - ...
            evaluate_expression_direct_local(expr.children{2},X);

    case 'div'
        num = evaluate_expression_direct_local(expr.children{1},X);
        den = evaluate_expression_direct_local(expr.children{2},X);
        if any(~isfinite(den)) || any(abs(den)<1e-8)
            value = nan(size(num));
        else
            value = num./den;
        end

    otherwise
        error('evaluate_expression_cached_local:UnknownOperator', ...
            'Unknown expression operator "%s".',expr.op);
end

if any(~isfinite(value)) || any(abs(value)>probe.maxBasisAbsValue)
    % Keep raw values for diagnostics; validity is decided by caller.
end
end


function value = evaluate_expression_direct_local(expr,X)
switch expr.op
    case 'const'
        value = ones(size(X,1),1);
    case 'var'
        value = X(:,expr.varIndex);
    case 'sin'
        value = sin(evaluate_expression_direct_local(expr.children{1},X));
    case 'cos'
        value = cos(evaluate_expression_direct_local(expr.children{1},X));
    case 'square'
        q = evaluate_expression_direct_local(expr.children{1},X);
        value = q.^2;
    case 'sqrt_pos'
        q = evaluate_expression_direct_local(expr.children{1},X);
        if any(q < -100*eps(max(1,max(abs(q)))))
            value = nan(size(q));
        else
            value = sqrt(max(q,0));
        end
    case 'prod'
        value = ones(size(X,1),1);
        for k = 1:numel(expr.children)
            value = value .* evaluate_expression_direct_local(expr.children{k},X);
        end
    case 'add'
        value = zeros(size(X,1),1);
        for k = 1:numel(expr.children)
            value = value + evaluate_expression_direct_local(expr.children{k},X);
        end
    case 'sub'
        value = evaluate_expression_direct_local(expr.children{1},X) - ...
            evaluate_expression_direct_local(expr.children{2},X);
    case 'div'
        num = evaluate_expression_direct_local(expr.children{1},X);
        den = evaluate_expression_direct_local(expr.children{2},X);
        if any(~isfinite(den)) || any(abs(den)<1e-8)
            value = nan(size(num));
        else
            value = num./den;
        end
    otherwise
        error('evaluate_expression_direct_local:UnknownOperator', ...
            'Unknown expression operator "%s".',expr.op);
end
end


function Theta = evaluate_dictionary_raw_local(basis,X)
if isvector(X)
    X = reshape(X,1,[]);
end
Theta = zeros(size(X,1),numel(basis));
for j = 1:numel(basis)
    Theta(:,j) = evaluate_expression_direct_local(basis{j},X);
end
end


function key = dictionary_key_local(basis)
keys = cellfun(@(q)q.key,basis,'UniformOutput',false);
keys = sort(keys);
key = strjoin(keys,'||');
end


function C = dictionary_complexity_local(basis,protectedMask)
% Structural complexity of EVOLVABLE basis functions only. The protected
% [1,x] anchor complexity is zero and constant across all candidates.
idx = find(~protectedMask);
C = sum(cellfun(@(q)q.complexity,basis(idx)));
end


%% ========================================================================
% Closed-form ridge helper
% ========================================================================


function fit = fit_closed_form_ridge_local(ThetaTr,ThetaVa,Ytr,Yva,probe)
colScale = sqrt(mean(ThetaTr.^2,1));
colScale = max(colScale,probe.libraryScaleFloor);

yScale = std(Ytr,0,1);
yRms = sqrt(mean(Ytr.^2,1));
yScale = max(yScale,0.05*yRms);
yScale = max(yScale,probe.outputScaleFloor);

Atr = ThetaTr./colScale;
Aval = ThetaVa./colScale;
Btr = Ytr./yScale;
Bva = Yva./yScale;

G = Atr.'*Atr + probe.rho*eye(size(Atr,2));
C = Atr.'*Btr;
[L,p] = chol(0.5*(G+G.'),'lower');
if p ~= 0
    error('fit_closed_form_ridge_local:Cholesky', ...
        'Fixed-rho ridge matrix was not positive definite.');
end
Xi = L'\(L\C);

fit = struct();
fit.coefficientsNormalized = Xi;
fit.coefficientsPhysical = (Xi./colScale(:)).*yScale;
fit.columnScale = colScale(:);
fit.outputScale = yScale(:);
fit.trainNormalizedMSE = mean((Atr*Xi-Btr).^2,'all');
fit.validationNormalizedMSE = mean((Aval*Xi-Bva).^2,'all');
end


%% ========================================================================
% Common local input construction
% ========================================================================


function [trainIds,valIds,trainMask,valMask,forcedTrainIds] = ...
    trajectory_split_local(dataset,opt)

K = dataset.trajectories.nTrajectories;
if K < 2
    error('trajectory_split_local:TooFewTrajectories', ...
        'At least two trajectories are required.');
end

forcedTrainIds = [];
if isfield(dataset.trajectories,'forceTrainingMask') && ...
        ~isempty(dataset.trajectories.forceTrainingMask)
    m = logical(dataset.trajectories.forceTrainingMask(:));
    if numel(m) ~= K
        error('trajectory_split_local:ForceTrainingMask', ...
            'forceTrainingMask size mismatch.');
    end
    forcedTrainIds = find(m).';
end

candidates = setdiff(1:K,forcedTrainIds,'stable');
if isempty(candidates)
    error('trajectory_split_local:NoValidationCandidates', ...
        'No trajectory remains for validation.');
end

oldRng = rng;
cleanup = onCleanup(@()rng(oldRng)); %#ok<NASGU>
rng(opt.validationSeed,'twister');
perm = candidates(randperm(numel(candidates)));

nVal = max(1,round(opt.validationFraction*K));
nVal = min(nVal,numel(candidates));
if nVal >= K, nVal = K-1; end

valIds = sort(perm(1:nVal));
trainIds = sort(setdiff(1:K,valIds,'stable'));
trainMask = ismember(dataset.trajectoryId,trainIds);
valMask = ismember(dataset.trajectoryId,valIds);
end


%% ========================================================================
% Model/info helpers
% ========================================================================


function model = base_model_local(kind,trainIds,valIds,forcedTrainIds)
model = struct();
model.type = 'edsi_probe_model';
model.kind = char(kind);
model.trainTrajectoryIds = trainIds(:);
model.validationTrajectoryIds = valIds(:);
model.forcedTrainingTrajectoryIds = forcedTrainIds(:);
end


function info = common_train_info_local( ...
    methodName,dataset,trainMask,valMask,trainIds,valIds,forcedTrainIds,modules)

info = struct();
info.method = methodName;
info.nSamples = size(dataset.x,1);
info.nTrajectories = dataset.trajectories.nTrajectories;
info.nTrainSamples = nnz(trainMask);
info.nValidationSamples = nnz(valMask);
info.nTrainTrajectories = numel(trainIds);
info.nValidationTrajectories = numel(valIds);
info.trainTrajectoryIds = trainIds(:);
info.validationTrajectoryIds = valIds(:);
info.forcedTrainingTrajectoryIds = forcedTrainIds(:);
info.modules = modules;
end


function c = empty_candidate_local()
c = struct( ...
    'basis',{{}}, ...
    'protectedMask',[], ...
    'mutationLockedMask',[], ...
    'Gtr',[], ...
    'Gval',[], ...
    'Ctr',[], ...
    'Cval',[], ...
    'colScale',[], ...
    'dictionaryKey','', ...
    'dictionaryComplexity',NaN, ...
    'maxDepth',NaN, ...
    'fitness',inf, ...
    'trainFitness',inf, ...
    'XiNormalized',[], ...
    'basisImportance',[]);
end


function h = history_template_local()
h = struct( ...
    'generation',NaN, ...
    'populationBestFitness',NaN, ...
    'populationMedianFitness',NaN, ...
    'globalBestFitness',NaN, ...
    'globalBestComplexity',NaN, ...
    'globalBestMaxDepth',NaN, ...
    'uniquePopulationCount',NaN, ...
    'stallCount',NaN);
end


function h = make_history_row_local(gen,stats,globalBest,stallCount)
h = history_template_local();
h.generation = gen;
h.populationBestFitness = stats.bestFitness;
h.populationMedianFitness = stats.medianFitness;
h.globalBestFitness = globalBest.fitness;
h.globalBestComplexity = globalBest.dictionaryComplexity;
h.globalBestMaxDepth = globalBest.maxDepth;
h.uniquePopulationCount = stats.uniqueCount;
h.stallCount = stallCount;
end


function code = device_type_code_local(deviceType)
switch lower(char(deviceType))
    case 'sg', code = 1;
    case 'gfm', code = 2;
    case 'gfl', code = 3;
    otherwise, code = 9;
end
end


function value = sample_discrete_local(values,probabilities)
probabilities = probabilities(:).';
probabilities = probabilities/sum(probabilities);
c = cumsum(probabilities);
r = rand;
idx = find(r<=c,1,'first');
if isempty(idx), idx = numel(values); end
value = values(idx);
end


function [S,idx] = append_struct_local(S,idx,x)
idx = idx+1;
if idx==1, S=x; else, S(idx,1)=x; end
end


function [S,idx] = append_history_local(S,idx,H,deviceType,deviceIndex)
for k = 1:numel(H)
    idx = idx+1;
    q = H(k);
    q.deviceType = char(deviceType);
    q.deviceIndex = deviceIndex;
    if idx==1, S=q; else, S(idx,1)=q; end
end
end


%% ========================================================================
% Tables
% ========================================================================


function T = append_table_local(T,row)
if isempty(T), T=row; else, T=[T;row]; end %#ok<AGROW>
end
