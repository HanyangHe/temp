function Xi = refit_stlsq_support_ridge(A,B,supportMask,relativeAlpha)
%REFIT_STLSQ_SUPPORT_RIDGE Refit a frozen STLSQ support with Tikhonov LS.
%
% A and B are the already normalized SINDy regression matrices.  The support
% mask is discovered by the ordinary unregularized STLSQ solver and is never
% changed here.  For each output j, the active coefficients solve
%
%   min_beta ||A_S beta - B_j||_2^2 + rho*N*||beta||_2^2,
%
% where rho=relativeAlpha and N=size(A,1).  Multiplication by N makes rho a
% dimensionless fraction of the typical normalized Gram-matrix scale.
%
% rho=0 exactly reduces to ordinary least squares on the frozen support.

validateattributes(A,{'numeric'},{'2d','finite'});
validateattributes(B,{'numeric'},{'2d','finite'});
validateattributes(relativeAlpha,{'numeric'},{'scalar','nonnegative','finite'});
if size(A,1) ~= size(B,1)
    error('refit_stlsq_support_ridge:RowSize', ...
        'A and B must contain the same number of rows.');
end
if ~isequal(size(supportMask),[size(A,2) size(B,2)])
    error('refit_stlsq_support_ridge:SupportSize', ...
        'supportMask must be [size(A,2) x size(B,2)].');
end
supportMask = logical(supportMask);
Xi = zeros(size(A,2),size(B,2));
N = size(A,1);

for j = 1:size(B,2)
    active = find(supportMask(:,j));
    if isempty(active)
        continue;
    end
    As = A(:,active);
    bj = B(:,j);
    if relativeAlpha == 0
        beta = As\bj;
    else
        lambda = relativeAlpha*max(N,1);
        R = sqrt(lambda)*eye(numel(active));
        beta = [As; R] \ [bj; zeros(numel(active),1)];
    end
    Xi(active,j) = beta;
end
end
