function [model,info] = train_kernel_ridge_id(dataset,c,layout,cfg)
%TRAIN_KERNEL_RIDGE_ID Modular RBF-kernel ridge vector-field identification.
%
% Learns each local DER vector field chi_r -> xdot_r with exact Gaussian
% kernel ridge regression. No device-specific physics features are used.
% The known electrical-network algebraic equations remain unchanged during
% rollout, so this is a drop-in no-prior system-identification baseline.

[model,info] = train_modular_kernel_id(dataset,c,layout,cfg,'krr');
end
