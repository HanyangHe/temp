function [model,info] = train_modular_weak_neural_sindy(dataset,c,layout,cfg)
%TRAIN_MODULAR_WEAK_NEURAL_SINDY Train the Weak PN-SINDy variation.
%
% Weak PN-SINDy shares the PN-SINDy candidate representation and fixed neural
% ridge bank, but estimates the outer coefficients from weak integral
% constraints. Pointwise derivative labels are not used by this variation.

opt = get_sindy_options(cfg);
if ~opt.weakPhysicsNeural.enabled
    error('train_modular_weak_neural_sindy:Disabled', ...
        'cfg.sindy.weakPhysicsNeural.enabled must be true.');
end

K = dataset.trajectories.nTrajectories;
if K < 2
    error('train_modular_weak_neural_sindy:TooFewTrajectories', ...
        'At least two trajectories are required.');
end

forcedTrainIds = [];
if isfield(dataset.trajectories,'forceTrainingMask') && ...
        ~isempty(dataset.trajectories.forceTrainingMask)
    m = logical(dataset.trajectories.forceTrainingMask(:));
    if numel(m) ~= K
        error('train_modular_weak_neural_sindy:ForceTrainingMaskSize', ...
            'forceTrainingMask must contain one entry per trajectory.');
    end
    forcedTrainIds = find(m).';
end

validationCandidates = setdiff(1:K,forcedTrainIds,'stable');
if isempty(validationCandidates)
    error('train_modular_weak_neural_sindy:NoValidationCandidates', ...
        'No trajectory remains for validation.');
end
oldRng = rng;
cleanup = onCleanup(@()rng(oldRng)); %#ok<NASGU>
rng(opt.validationSeed,'twister');
perm = validationCandidates(randperm(numel(validationCandidates)));
nVal = max(1,round(opt.validationFraction*K));
nVal = min(nVal,numel(validationCandidates));
if nVal >= K, nVal = K-1; end
valIds = sort(perm(1:nVal));
trainIds = sort(setdiff(1:K,valIds,'stable'));

model.type = 'modular_sindy';
model.formulationVersion = char(opt.formulationVersion);
model.method = 'Weak Physics-Neural SINDy';
model.variant = 'weak_physics_neural';
model.trainingObjective = [ ...
    'compact-support weak integral regression with the PN-SINDy dictionary'];
model.trainingSampleDefinition = [ ...
    'complete short trajectories; no pointwise derivative labels'];
model.sg = struct([]); model.gfm = struct([]); model.gfl = struct([]);
model.trainTrajectoryIds = trainIds(:);
model.validationTrajectoryIds = valIds(:);
model.forcedTrainingTrajectoryIds = forcedTrainIds(:);
model.options = opt;

modules = struct([]);
mi = 0;
activeTotal = 0;
candidateTotal = 0;

for k = 1:numel(c.sg)
    fprintf('    Training Weak PN-SINDy module SG%d (Bus %d)...\n',k,c.sg(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'sg',k);
    seed = module_seed_local(opt.neuralBasis.seed,'sg',k);
    [mk,ik] = fit_weak_neural_sindy_stlsq_module(data,trainIds,valIds,opt,seed);
    if k==1, model.sg=mk; else, model.sg(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    activeTotal = activeTotal + ik.activeCoefficientCount;
    candidateTotal = candidateTotal + ik.candidateCoefficientCount;
end
for k = 1:numel(c.gfm)
    fprintf('    Training Weak PN-SINDy module GFM%d (Bus %d)...\n',k,c.gfm(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfm',k);
    seed = module_seed_local(opt.neuralBasis.seed,'gfm',k);
    [mk,ik] = fit_weak_neural_sindy_stlsq_module(data,trainIds,valIds,opt,seed);
    if k==1, model.gfm=mk; else, model.gfm(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    activeTotal = activeTotal + ik.activeCoefficientCount;
    candidateTotal = candidateTotal + ik.candidateCoefficientCount;
end
for k = 1:numel(c.gfl)
    fprintf('    Training Weak PN-SINDy module GFL%d (Bus %d)...\n',k,c.gfl(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfl',k);
    seed = module_seed_local(opt.neuralBasis.seed,'gfl',k);
    [mk,ik] = fit_weak_neural_sindy_stlsq_module(data,trainIds,valIds,opt,seed);
    if k==1, model.gfl=mk; else, model.gfl(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    activeTotal = activeTotal + ik.activeCoefficientCount;
    candidateTotal = candidateTotal + ik.candidateCoefficientCount;
end

model.activeCoefficientCount = activeTotal;
model.candidateCoefficientCount = candidateTotal;

[okCompatibility,compatibility] = check_sindy_model_compatibility( ...
    'weak_physics_neural_sindy',model,cfg);
if ~okCompatibility
    error('train_modular_weak_neural_sindy:CompatibilityContract', ...
        ['Newly trained Weak PN-SINDy model violates its method contract:\n  - %s'], ...
        strjoin(string(compatibility.issues),sprintf('\n  - ')));
end
model.compatibilitySchema = compatibility.schemaVersion;
model.compatibilitySignature = compatibility.actual;

info.method = 'weak_physics_neural_sindy';
info.formulationVersion = char(opt.formulationVersion);
info.displayName = 'Weak PN-SINDy';
info.variant = 'weak_physics_neural';
info.objective = 'compact-support weak integral sparse regression with PN-SINDy dictionary';
info.nSamples = size(dataset.x,1);
info.nTrajectories = K;
info.nTrainTrajectories = numel(trainIds);
info.nValidationTrajectories = numel(valIds);
info.trainTrajectoryIds = trainIds(:);
info.validationTrajectoryIds = valIds(:);
info.forcedTrainingTrajectoryIds = forcedTrainIds(:);
info.modules = modules;
info.activeCoefficientCount = activeTotal;
info.candidateCoefficientCount = candidateTotal;
info.compatibilitySchema = compatibility.schemaVersion;
info.compatibilitySignature = compatibility.actual;
info.neuralBasisFeatureCount = opt.neuralBasis.featureCount;
info.neuralBasisActivation = opt.neuralBasis.activation;
info.neuralBasisQuantiles = opt.neuralBasis.quantiles;
info.neuralBasisScales = opt.neuralBasis.scales;
info.weakWindowPoints = opt.weakPhysicsNeural.windowPoints;
info.weakWindowStride = opt.weakPhysicsNeural.windowStride;
info.weakTestFunctionPower = opt.weakPhysicsNeural.testFunctionPower;
info.derivativeLabelsUsed = false;

if ~isempty(forcedTrainIds) && opt.verbose
    fprintf('    Forced into Weak PN-SINDy training partition: trajectory ID(s) [%s]\n', ...
        strtrim(sprintf('%d ',forcedTrainIds)));
end
end

function [S,mi] = append_info_local(S,mi,ik)
mi = mi+1;
if mi==1, S=ik; else, S(mi,1)=ik; end
end

function seed = module_seed_local(baseSeed,deviceType,k)
switch lower(char(deviceType))
    case 'sg', offset=100*k;
    case 'gfm', offset=10000+100*k;
    case 'gfl', offset=20000+100*k;
    otherwise, offset=30000+100*k;
end
seed = round(double(baseSeed))+offset;
end
