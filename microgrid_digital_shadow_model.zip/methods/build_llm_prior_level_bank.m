function [bank,items,meta] = build_llm_prior_level_bank(prior,level)
%BUILD_LLM_PRIOR_LEVEL_BANK Deterministic projection of one LLM discovery.
%
% Prior-level architecture used by the manuscript ablation:
%   coordinate_only : supplied local d/q coordinate terms only.
%   llm_direct      : coordinates + terms explicitly proposed by the LLM;
%                     deterministic closure expansion is excluded.
%   llm_full        : coordinates + direct LLM terms + deterministic closure
%                     expansion (the proposed full LLM-Prior representation).
%
% The same prior discovery response is projected into all three levels, so
% comparisons are not confounded by additional LLM calls/generations.

if nargin < 2 || strlength(string(level)) == 0
    error('build_llm_prior_level_bank:MissingLevel','A prior level is required.');
end
level = lower(strtrim(char(string(level))));
valid = {'coordinate_only','llm_direct','llm_full'};
if ~any(strcmp(level,valid))
    error('build_llm_prior_level_bank:UnknownLevel', ...
        'Unknown level "%s". Use coordinate_only, llm_direct, or llm_full.',level);
end
if ~isstruct(prior) || ~isfield(prior,'responses') || ~isfield(prior,'bank')
    error('build_llm_prior_level_bank:InvalidPrior', ...
        'The formal prior discovery structure is incomplete.');
end

bank = struct();
items = struct();
types = {'sg','gfm','gfl'};
for k = 1:numel(types)
    type = types{k};
    if ~isfield(prior.responses,type)
        error('build_llm_prior_level_bank:MissingResponse', ...
            'Missing %s discovery response.',upper(type));
    end
    resp = prior.responses.(type);

    switch level
        case 'coordinate_only'
            if ~isfield(resp,'supplied_coordinate_terms')
                error('build_llm_prior_level_bank:CoordinateSnapshot', ...
                    'The %s response has no supplied_coordinate_terms snapshot.',upper(type));
            end
            terms = string(resp.supplied_coordinate_terms(:));
            selectedItems = coordinate_items_local(terms);

        case 'llm_direct'
            if ~isfield(resp,'llm_direct_prior_bank') || ...
                    ~isfield(resp,'llm_direct_prior_items')
                error('build_llm_prior_level_bank:DirectSnapshot', ...
                    ['The %s response does not contain the LLM-direct snapshot. ', ...
                     'Use the method-neutral v6+ adapter/protocol.'],upper(type));
            end
            terms = string(resp.llm_direct_prior_bank(:));
            selectedItems = normalize_items_local(resp.llm_direct_prior_items);

        case 'llm_full'
            if ~isfield(prior.bank,type)
                error('build_llm_prior_level_bank:FullBank', ...
                    'The formal prior bank has no %s field.',upper(type));
            end
            terms = string(prior.bank.(type)(:));
            if isfield(prior,'items') && isfield(prior.items,type)
                selectedItems = normalize_items_local(prior.items.(type));
            else
                selectedItems = struct([]);
            end
    end

    if isempty(terms)
        error('build_llm_prior_level_bank:EmptyBank', ...
            '%s produced an empty %s bank.',upper(type),level);
    end
    bank.(type) = cellstr(terms);
    items.(type) = selectedItems;
end

meta = struct();
meta.level = level;
meta.bankHash = bank_hash_local(bank,items);
meta.priorTermCount = bank_term_count_local(bank);
meta.sourceCounts = item_source_counts_local(items);
meta.coordinateTermCount = meta.sourceCounts(1);
meta.llmLatentTermCount = meta.sourceCounts(2);
meta.llmCompiledTermCount = meta.sourceCounts(3);
meta.closureTermCount = meta.sourceCounts(4);
end


function items = coordinate_items_local(terms)
template = struct('expression','','source','supplied_coordinate', ...
    'reason','project d/q coordinate convention','confidence',1.0, ...
    'target_derivatives',[]);
items = repmat(template,numel(terms),1);
for i = 1:numel(terms)
    items(i).expression = char(terms(i));
end
end


function items = normalize_items_local(itemsIn)
if isempty(itemsIn)
    items = struct([]);
elseif iscell(itemsIn)
    if isempty(itemsIn)
        items = struct([]);
    else
        items = vertcat(itemsIn{:});
    end
else
    items = itemsIn(:);
end
end


function n = bank_term_count_local(bank)
n = 0;
for t = {'sg','gfm','gfl'}
    n = n + numel(bank.(t{1}));
end
end


function counts = item_source_counts_local(items)
% [supplied_coordinate, llm_latent, llm_compiled, llm_closure]
counts = zeros(1,4);
labels = ["supplied_coordinate","llm_latent","llm_compiled","llm_closure"];
for t = {'sg','gfm','gfl'}
    if ~isfield(items,t{1}) || isempty(items.(t{1})), continue; end
    q = normalize_items_local(items.(t{1}));
    src = strings(numel(q),1);
    for i = 1:numel(q)
        if isfield(q(i),'source'), src(i)=string(q(i).source); end
    end
    for j = 1:numel(labels)
        counts(j) = counts(j) + nnz(strcmpi(src,labels(j)));
    end
end
end


function h = bank_hash_local(bank,items)
payload = struct('bank',bank,'items',items);
h = fnv1a32_local(jsonencode(payload));
end


function h = fnv1a32_local(txt)
bytes = unicode2native(char(txt),'UTF-8');
hv = uint64(2166136261); prime = uint64(16777619); modulus = uint64(4294967296);
for i = 1:numel(bytes)
    hv = bitxor(hv,uint64(bytes(i)));
    hv = mod(hv*prime,modulus);
end
h = sprintf('%08X',uint32(hv));
end
