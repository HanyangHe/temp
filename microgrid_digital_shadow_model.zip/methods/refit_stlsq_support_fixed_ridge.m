function Xi = refit_stlsq_support_fixed_ridge(A,B,supportMask,rho)
%REFIT_STLSQ_SUPPORT_FIXED_RIDGE Fixed-rho refit on a frozen STLSQ support.
%
% Support must already be discovered by unregularized OLS-STLSQ. This helper
% changes coefficients only and never changes support:
%
%   min_beta ||A_S beta-B_j||_2^2 + rho ||beta||_2^2.
%
% Unlike refit_stlsq_support_ridge, rho here is the literal Tikhonov term and
% is NOT multiplied by the sample count. The formal clean exact-label value is
% rho=1e-10.

validateattributes(A,{'numeric'},{'2d','finite'});
validateattributes(B,{'numeric'},{'2d','finite'});
validateattributes(rho,{'numeric'},{'scalar','nonnegative','finite'});
if size(A,1) ~= size(B,1)
    error('refit_stlsq_support_fixed_ridge:RowSize', ...
        'A and B must contain the same number of rows.');
end
if ~isequal(size(supportMask),[size(A,2) size(B,2)])
    error('refit_stlsq_support_fixed_ridge:SupportSize', ...
        'supportMask must be [size(A,2) x size(B,2)].');
end
supportMask=logical(supportMask);
Xi=zeros(size(A,2),size(B,2));
for j=1:size(B,2)
    active=find(supportMask(:,j));
    if isempty(active), continue; end
    As=A(:,active); bj=B(:,j);
    if rho<=0
        beta=As\bj;
    else
        p=numel(active);
        beta=[As; sqrt(rho)*eye(p)] \ [bj; zeros(p,1)];
    end
    Xi(active,j)=beta;
end
end
