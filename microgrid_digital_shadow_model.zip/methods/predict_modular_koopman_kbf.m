function fhat = predict_modular_koopman_kbf(model,~,x,V,u,c,layout)
%PREDICT_MODULAR_KOOPMAN_KBF Evaluate continuous Eq. (16) in the DAE ODE block.
%
% For every ODE15I residual evaluation the current physical state is lifted
% algebraically, the learned continuous Koopman generator is evaluated, and
% the degree-one lifted derivatives are mapped exactly back to xdot. The
% lifted state is never independently integrated, so manifold drift cannot
% accumulate as an extra numerical state.

if isfield(model,'variant') && ...
        strcmpi(char(string(model.variant)),'jiang_edmd_isotypic_v1')
    fhat = predict_jiang_edmd_isotypic_kbf(model,x,V,u,c,layout);
    return;
end

fhat = zeros(layout.nx,1);
for k = 1:numel(c.sg)
    m = model.sg(k);
    if numel(m.stateIndices) == 5 && isfield(u,'sgVref')
        force = [real(V(m.bus));imag(V(m.bus));u.sgPm(k);u.sgVref(k)];
    else
        force = [real(V(m.bus));imag(V(m.bus));u.sgPm(k)];
    end
    fhat(m.stateIndices) = eval_module(m,x(m.stateIndices),force);
end
for k = 1:numel(c.gfm)
    m = model.gfm(k);
    force = [real(V(m.bus));imag(V(m.bus)); ...
        u.gfmPstar(k);u.gfmQstar(k);u.gfmEref(k)];
    fhat(m.stateIndices) = eval_module(m,x(m.stateIndices),force);
end
for k = 1:numel(c.gfl)
    m = model.gfl(k);
    force = [real(V(m.bus));imag(V(m.bus)); ...
        u.gflPstar(k);u.gflQstar(k)];
    fhat(m.stateIndices) = eval_module(m,x(m.stateIndices),force);
end

if any(~isfinite(fhat))
    error('predict_modular_koopman_kbf:NonfiniteOutput', ...
        'M-KBF returned a non-finite differential vector field.');
end
end

function dxdt = eval_module(m,xLocal,force)
xLocal = double(xLocal(:));
force = double(force(:));
if numel(force) ~= m.forceCount
    error('predict_modular_koopman_kbf:ForceSize', ...
        'Expected %d forcing channels, received %d.',m.forceCount,numel(force));
end
s = (xLocal-m.stateMean(:))./m.stateStd(:);
q = (force-m.forceMean(:))./m.forceStd(:);
[Z,~,~] = build_koopman_monomial_lift(s,m.stateNames,m.polyOrder,m.liftSpec);
z = Z(:,1);
zdot = m.A*z;
for i = 1:m.forceCount
    zdot = zdot + q(i)*(m.B(:,:,i)*z);
end
dxdt = m.Cdot*zdot;
end
