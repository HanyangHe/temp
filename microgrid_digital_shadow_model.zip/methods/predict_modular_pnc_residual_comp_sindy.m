function fhat = predict_modular_pnc_residual_comp_sindy(model,~,x,V,u,c,layout)
%PREDICT_MODULAR_PNC_RESIDUAL_COMP_SINDY Evaluate PE + Phi_comp residual model.

x = x(:);
V = V(:);
if numel(x) ~= layout.nx
    error('predict_modular_pnc_residual_comp_sindy:StateDimension', ...
        'State length %d does not match layout.nx=%d.',numel(x),layout.nx);
end

fhat = zeros(layout.nx,1);
covered = false(layout.nx,1);
for k = 1:numel(model.sg)
    [dx,idx] = evaluate_module_local(model.sg(k),x,V,u,c,model.options);
    fhat(idx)=dx; covered(idx)=true;
end
for k = 1:numel(model.gfm)
    [dx,idx] = evaluate_module_local(model.gfm(k),x,V,u,c,model.options);
    fhat(idx)=dx; covered(idx)=true;
end
for k = 1:numel(model.gfl)
    [dx,idx] = evaluate_module_local(model.gfl(k),x,V,u,c,model.options);
    fhat(idx)=dx; covered(idx)=true;
end

if ~all(covered)
    missing = find(~covered);
    error('predict_modular_pnc_residual_comp_sindy:StateCoverage', ...
        'Modules do not cover differential-state indices [%s].', ...
        strtrim(sprintf('%d ',missing)));
end
if any(~isfinite(fhat))
    error('predict_modular_pnc_residual_comp_sindy:NonfiniteOutput', ...
        'PNC-ResidualComp returned nonfinite vector-field values.');
end
end

function [dx,idx] = evaluate_module_local(module,x,V,u,c,opt)
idx = module.stateIndices(:);
Xrow = build_local_input_row(module,x,V,u,c);

L1 = module.layer1;
[Theta1,names1] = build_sindy_library( ...
    Xrow,L1.inputNames,L1.deviceType,"physics",opt,L1.librarySpec);
if numel(names1) ~= numel(L1.libraryNames) || ...
        any(string(names1(:)) ~= string(L1.libraryNames(:)))
    error('predict_modular_pnc_residual_comp_sindy:Layer1LibraryOrder', ...
        'Stored and rollout PE layer-1 library orders do not match.');
end
Hrow = Theta1*L1.coefficients;

[Theta2,names2] = build_pnc_residual_comp_library( ...
    Xrow,Hrow,module.inputNames,module.outputNames,opt, ...
    module.neuralBasisSeed,module.librarySpec);
if numel(names2) ~= numel(module.libraryNames) || ...
        any(string(names2(:)) ~= string(module.libraryNames(:)))
    error('predict_modular_pnc_residual_comp_sindy:Layer2LibraryOrder', ...
        'Stored and rollout residual-composition library orders do not match.');
end
if size(Theta2,2) ~= size(module.coefficients,1)
    error('predict_modular_pnc_residual_comp_sindy:CoefficientDimension', ...
        'Layer-2 width %d does not match coefficient rows %d.', ...
        size(Theta2,2),size(module.coefficients,1));
end

correction = Theta2*module.coefficients;
dx = (Hrow + correction).';
if numel(dx) ~= numel(idx) || any(~isfinite(dx))
    error('predict_modular_pnc_residual_comp_sindy:ModuleOutput', ...
        '%s%d returned an invalid state derivative.', ...
        upper(char(module.deviceType)),module.deviceIndex);
end
dx = dx(:);
end

function Xrow = build_local_input_row(module,x,V,u,c)
if module.bus < 1 || module.bus > numel(V)
    error('predict_modular_pnc_residual_comp_sindy:BusIndex', ...
        'Stored module bus %d is outside the voltage vector.',module.bus);
end
names = string(module.inputNames(:));
Xrow = zeros(1,numel(names));
nState = numel(module.stateIndices);
if nState > numel(names)
    error('predict_modular_pnc_residual_comp_sindy:InputLayout', ...
        'Module has %d states but only %d local input names.',nState,numel(names));
end
Xrow(1:nState) = x(module.stateIndices(:)).';

for j = (nState+1):numel(names)
    name = names(j);
    switch name
        case "Vterminal_Re"
            Xrow(j) = real(V(module.bus));
        case "Vterminal_Im"
            Xrow(j) = imag(V(module.bus));
        case "Pm"
            Xrow(j) = indexed_input_local(u,'sgPm',module.deviceIndex,c);
        case "Vref"
            Xrow(j) = indexed_input_local(u,'sgVref',module.deviceIndex,c);
        case "Pstar"
            switch lower(char(module.deviceType))
                case 'gfm'
                    Xrow(j) = indexed_input_local(u,'gfmPstar',module.deviceIndex,c);
                case 'gfl'
                    Xrow(j) = indexed_input_local(u,'gflPstar',module.deviceIndex,c);
                otherwise
                    error('predict_modular_pnc_residual_comp_sindy:PstarDevice', ...
                        'Pstar is not defined for device type %s.',module.deviceType);
            end
        case "Qstar"
            switch lower(char(module.deviceType))
                case 'gfm'
                    Xrow(j) = indexed_input_local(u,'gfmQstar',module.deviceIndex,c);
                case 'gfl'
                    Xrow(j) = indexed_input_local(u,'gflQstar',module.deviceIndex,c);
                otherwise
                    error('predict_modular_pnc_residual_comp_sindy:QstarDevice', ...
                        'Qstar is not defined for device type %s.',module.deviceType);
            end
        case "Eref"
            Xrow(j) = indexed_input_local(u,'gfmEref',module.deviceIndex,c);
        otherwise
            error('predict_modular_pnc_residual_comp_sindy:UnknownInputName', ...
                'Unknown local input name %s for %s%d.', ...
                name,upper(char(module.deviceType)),module.deviceIndex);
    end
end
end

function value = indexed_input_local(u,fieldName,k,c)
if isstruct(u) && isfield(u,fieldName) && numel(u.(fieldName)) >= k
    value = u.(fieldName)(k);
    return;
end
if isstruct(c) && isfield(c,'input') && isfield(c.input,'nominal') && ...
        isfield(c.input.nominal,fieldName) && numel(c.input.nominal.(fieldName)) >= k
    value = c.input.nominal.(fieldName)(k);
    return;
end
error('predict_modular_pnc_residual_comp_sindy:MissingInput', ...
    'Neither current input nor c.input.nominal contains %s(%d).',fieldName,k);
end
