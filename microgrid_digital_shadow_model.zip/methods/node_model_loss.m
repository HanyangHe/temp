function [loss,gradients] = node_model_loss(params,tspan,X0,targets,forcingN,opt)
%NODE_MODEL_LOSS Multi-step normalized trajectory loss for one DER NODE.

theta = params;
theta.Forcing = forcingN;
theta.T0 = double(tspan(1));
theta.Dt = double(tspan(2)-tspan(1));
theta.NTimes = numel(tspan);

Y = dlode45(@node_controlled_rhs,tspan,X0,theta, ...
    DataFormat='CB', ...
    GradientMode=opt.gradientMode, ...
    RelativeTolerance=opt.solver.RelativeTolerance, ...
    AbsoluteTolerance=opt.solver.AbsoluteTolerance, ...
    MaxStepSize=opt.solver.MaxStepSize);

% dlode45 returns solutions at tspan(2:end); targets has exactly those times.
loss = l2loss(Y,targets,NormalizationFactor='all-elements',DataFormat='CBT');
gradients = dlgradient(loss,params);
end
