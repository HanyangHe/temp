function fhat = predict_jiang_edmd_isotypic_kbf(model,x,V,u,c,layout)
%PREDICT_JIANG_EDMD_ISOTYPIC_KBF Paper-based discrete EDMD -> DAE ODE adapter.
%
% Jiang's original method propagates lifted states with finite discrete
% steps and jointly solves a hybrid-network algebraic representation. The
% present project uses the same ode15i/algebraic-network comparison for all
% baselines. For compatibility we map the learned *discrete* EDMD increment
% to a physical-state vector field over the identification timestep.
% In the original discrete explicit EDMD, input q_(k+1) is used. The
% shared ODE15I residual supplies only instantaneous ports, so the current
% q is substituted for q_(k+1) during this continuous-time adapter.
% This is a documented numerical adapter, not the original solver.

if ~isfield(model,'variant') || ~strcmpi(model.variant,'jiang_edmd_isotypic_v1')
    error('predict_jiang_edmd_isotypic_kbf:Variant','Unexpected model variant.');
end
fhat=zeros(layout.nx,1);
for k=1:numel(c.sg)
    m=model.sg(k);
    if numel(m.stateIndices)==5 && isfield(u,'sgVref')
        refs=[u.sgPm(k);u.sgVref(k)];
    else
        refs=u.sgPm(k);
    end
    fhat(m.stateIndices)=eval_module(m,x(m.stateIndices),V(m.bus),refs);
end
for k=1:numel(c.gfm)
    m=model.gfm(k);
    refs=[u.gfmPstar(k);u.gfmQstar(k);u.gfmEref(k)];
    fhat(m.stateIndices)=eval_module(m,x(m.stateIndices),V(m.bus),refs);
end
for k=1:numel(c.gfl)
    m=model.gfl(k);
    refs=[u.gflPstar(k);u.gflQstar(k)];
    fhat(m.stateIndices)=eval_module(m,x(m.stateIndices),V(m.bus),refs);
end
if any(~isfinite(fhat))
    error('predict_jiang_edmd_isotypic_kbf:Nonfinite','Nonfinite predicted vector field.');
end
end

function dx=eval_module(m,x,voltage,refs)
x=double(x(:));refs=double(refs(:));
H=(x(2:end)-m.stateMean(:))./m.stateStd(:);
[Z,~,~]=build_koopman_isotypic_lift(x(1),H,m.stateNames(2:end), ...
    m.polyOrder,m.liftSpec,[],[],m.stateNames(1));
z=Z(:,1);
Qraw=build_koopman_isotypic_forcing(m.deviceType,x,voltage,refs,m.portParameters, ...
    struct('voltageDivisionFloor',m.voltageDivisionFloor));
q=(Qraw(:)-m.forceMean(:))./m.forceStd(:);
if numel(q)~=m.forceCount
    error('predict_jiang_edmd_isotypic_kbf:Forcing','Forcing-channel mismatch.');
end

% The discrete EDMD operator is evaluated in the embedded coordinates.
if strcmpi(m.odeConversion,'implicit_step') && m.implicit
    Bq=zeros(size(m.Ad),'like',m.Ad);
    for k=1:numel(q)
        Bq=Bq+q(k)*m.Bd(:,:,k);
    end
    M=eye(size(m.Ad,1),'like',m.Ad)-Bq;
    if rcond(M)<1e-12
        error('predict_jiang_edmd_isotypic_kbf:ImplicitSingular', ...
            'Implicit EDMD step matrix is ill-conditioned.');
    end
    zNext=M\(m.Ad*z);
    if any(~isfinite(zNext)) || abs(zNext(1))<1e-10
        error('predict_jiang_edmd_isotypic_kbf:InvalidProjection', ...
            'Invalid isotypic observable during implicit projection.');
    end
    thetaRate=angle(zNext(1)/z(1))/m.dt;
    Hnext=real(zNext(2:1+numel(H))/zNext(1));
    Hrate=(Hnext-H)/m.dt;
else
    dz=(m.Ad*z-z);
    for k=1:numel(q)
        dz=dz+q(k)*(m.Bd(:,:,k)*z);
    end
    dz=dz/m.dt;
    thetaRate=imag(dz(1)/z(1));
    Hrate=real(dz(2:1+numel(H))/z(1)-H*(dz(1)/z(1)));
end

dx=[thetaRate;m.stateStd(:).*Hrate];
if any(~isfinite(dx))
    error('predict_jiang_edmd_isotypic_kbf:InvalidDerivative', ...
        'Nonfinite physical-state derivative from EDMD projection.');
end
end
