function [model,info] = train_poly3_sindy(dataset,c,layout,cfg)
%TRAIN_POLY3_SINDY Generic Poly-3 + sin/cos SINDy baseline.
%
% This is a method-level wrapper around the established vanilla pointwise
% SINDy implementation.  It changes ONLY the generic polynomial order:
%
%   V-SINDy     : Poly-2(raw chi) + sin(raw chi) + cos(raw chi)
%   Poly-3 SINDy: Poly-3(raw chi) + sin(raw chi) + cos(raw chi)
%
% The trajectory split, STLSQ solver, threshold grid, normalization,
% state-noise derivative protocol, support-preserving noisy-data refit, and
% exact-network rollout are otherwise identical to V-SINDy.

cfg3 = cfg;
if ~isfield(cfg3,'sindy') || ~isstruct(cfg3.sindy)
    cfg3.sindy = struct();
end
cfg3.sindy.polyOrderOption = 3;

[model,info] = train_vanilla_sindy(dataset,c,layout,cfg3);

% Preserve the canonical internal variant='vanilla' because the mathematical
% family is unchanged; record the formal baseline identity separately.
model.methodAlias = 'poly3_sindy';
model.polyOrderBaseline = 3;
model.formulationVersion = 'official_brunton_2015_stlsq_poly3_baseline_v1';

info.method = 'poly3_sindy';
info.displayName = 'Poly-3 SINDy';
info.polyOrderOption = 3;
info.formulationVersion = 'official_brunton_2015_stlsq_poly3_baseline_v1';
end
