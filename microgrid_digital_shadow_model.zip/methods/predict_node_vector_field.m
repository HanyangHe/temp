function fhat = predict_node_vector_field(model,~,x,V,u,c,layout)
%PREDICT_NODE_VECTOR_FIELD Evaluate modular NODE instantaneous vector field.
%
% The exact electrical-network algebraic equations remain outside the NODE.

fhat = zeros(layout.nx,1);
for k = 1:numel(c.sg)
    m = model.sg(k);
    if numel(m.stateIndices) == 5 && isfield(u,'sgVref')
        force = [real(V(m.bus));imag(V(m.bus));u.sgPm(k);u.sgVref(k)];
    else
        force = [real(V(m.bus));imag(V(m.bus));u.sgPm(k)];
    end
    fhat(m.stateIndices) = eval_module(m,x(m.stateIndices),force);
end
for k = 1:numel(c.gfm)
    m = model.gfm(k);
    force = [real(V(m.bus));imag(V(m.bus)); ...
        u.gfmPstar(k);u.gfmQstar(k);u.gfmEref(k)];
    fhat(m.stateIndices) = eval_module(m,x(m.stateIndices),force);
end
for k = 1:numel(c.gfl)
    m = model.gfl(k);
    force = [real(V(m.bus));imag(V(m.bus)); ...
        u.gflPstar(k);u.gflQstar(k)];
    fhat(m.stateIndices) = eval_module(m,x(m.stateIndices),force);
end

if any(~isfinite(fhat))
    error('predict_node_vector_field:NonfiniteOutput', ...
        'NODE returned a non-finite differential vector field.');
end
end

function dxdt = eval_module(m,xLocal,force)
s = (double(xLocal(:))-m.stateMean(:))./m.stateStd(:);
f = (double(force(:))-m.forceMean(:))./m.forceStd(:);
a = [s;f];
a = tanh(m.numeric.W1*a + m.numeric.b1);
a = tanh(m.numeric.W2*a + m.numeric.b2);
dsdt = m.numeric.Wout*a + m.numeric.bout;
dxdt = m.stateStd(:).*dsdt;
end
