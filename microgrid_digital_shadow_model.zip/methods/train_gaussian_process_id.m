function [model,info] = train_gaussian_process_id(dataset,c,layout,cfg)
%TRAIN_GAUSSIAN_PROCESS_ID Modular exact GP vector-field identification.
%
% Uses an RBF Gaussian process with one shared kernel per DER module and
% independent output channels. Hyperparameters are selected by exact
% multi-output log marginal likelihood on a bounded tuning subset.
% The posterior mean is used for DAE rollout.
%
% The GP is intentionally device-physics-free: its only prior is the generic
% smoothness assumption encoded by the RBF kernel.

[model,info] = train_modular_kernel_id(dataset,c,layout,cfg,'gp');
end
