function dsdt = node_controlled_rhs(t,s,theta)
%NODE_CONTROLLED_RHS Controlled normalized-state RHS used inside dlode45.
%
% s is the normalized DER state. theta.Forcing contains normalized terminal
% voltage/reference trajectories with dimensions [force, batch, time].
% Forcing is linearly interpolated at dlode45 internal time points.

% dlode45 supplies scalar time. Time derivatives are not learnable here, so a
% possible dlarray wrapper can be safely unwrapped for the interpolation index.
if isa(t,'dlarray')
    tNumeric = double(extractdata(t));
else
    tNumeric = double(t);
end

pos = (tNumeric-theta.T0)/theta.Dt + 1;
if theta.NTimes <= 1
    i0 = 1;
    alpha = 0;
    U = theta.Forcing(:,:,1);
else
    i0 = floor(pos);
    i0 = max(1,min(theta.NTimes-1,i0));
    alpha = pos-i0;
    alpha = max(0,min(1,alpha));
    U = (1-alpha).*theta.Forcing(:,:,i0) + ...
        alpha.*theta.Forcing(:,:,i0+1);
end

% Y0 is unformatted and DataFormat='CB' is supplied to dlode45, matching
% the MathWorks custom-training pattern. Keep the forcing unformatted too.
Udl = dlarray(U);
phi = [s;Udl];

h = tanh(theta.fc1.Weights*phi + theta.fc1.Bias);
h = tanh(theta.fc2.Weights*h + theta.fc2.Bias);
dsdt = theta.fcOut.Weights*h + theta.fcOut.Bias;
end
