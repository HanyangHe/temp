function [A,B,meta] = build_weak_sindy_regression(data,Theta,trajectoryIds,opt)
%BUILD_WEAK_SINDY_REGRESSION Build compact-support weak-form regression rows.
%
% For each selected trajectory and sliding window [t_a,t_b], choose a smooth
% test function phi that vanishes at both endpoints. Integration by parts gives
%
%   - integral x(t) * dphi/dt dt = integral Theta(t) * phi(t) dt * Xi.
%
% Thus no pointwise derivative labels are required. The candidate dictionary
% is still the Vanilla-SINDy dictionary; only the coefficient-identification
% form changes. All integrals use the composite trapezoidal rule on the measured
% short trajectories.

if size(Theta,1) ~= data.nSamples
    error('build_weak_sindy_regression:ThetaSize', ...
        'Theta must contain one row per flattened sample.');
end
trajectoryIds = unique(trajectoryIds(:).','stable');
windowPoints = unique(round(double(opt.windowPoints(:).')),'stable');
stride = round(double(opt.windowStride));
power = round(double(opt.testFunctionPower));

validateattributes(stride,{'numeric'},{'scalar','integer','>=',1});
validateattributes(power,{'numeric'},{'scalar','integer','>=',1});

A = zeros(0,size(Theta,2));
B = zeros(0,data.nOutputs);
windowPointLog = zeros(0,1);
windowDurationLog = zeros(0,1);
trajectoryLog = zeros(0,1);

for tr = trajectoryIds
    rows = find(data.trajectoryId == tr);
    if isempty(rows)
        error('build_weak_sindy_regression:MissingTrajectory', ...
            'Trajectory ID %d is not present in the dataset.',tr);
    end
    [~,ord] = sort(data.pointInTrajectory(rows));
    rows = rows(ord);
    pointIds = data.pointInTrajectory(rows);
    t = double(data.trajectoryTime(pointIds));
    xObs = double(data.stateObserved(rows,:));
    th = double(Theta(rows,:));

    if any(diff(t) <= 0)
        error('build_weak_sindy_regression:TimeOrder', ...
            'Trajectory time must be strictly increasing.');
    end

    for W = windowPoints
        if W < 3 || W > numel(rows)
            error('build_weak_sindy_regression:WindowPoints', ...
                'Weak-form windowPoints=%d is invalid for a %d-point trajectory.', ...
                W,numel(rows));
        end
        for i0 = 1:stride:(numel(rows)-W+1)
            idx = i0:(i0+W-1);

            % IMPORTANT: every weak equation is assembled from the SAME
            % sliding-window rows.  The previous implementation windowed t
            % but accidentally multiplied the full-trajectory Theta/x arrays
            % by the W-point test function, causing an array-size mismatch
            % as soon as W < pointsPerTrajectory.
            tw = t(idx);
            tw = tw(:);
            thw = th(idx,:);
            xw = xObs(idx,:);

            duration = tw(end)-tw(1);
            if ~(isfinite(duration) && duration > 0)
                error('build_weak_sindy_regression:Duration', ...
                    'Invalid weak-form window duration.');
            end

            % Compact-support polynomial test function on s in [-1,1].
            % Keep phi/dphiDt explicitly column-oriented so the code is
            % dimensionally robust across MATLAB releases.
            s = 2*(tw-(tw(1)+tw(end))/2)/duration;
            base = max(0,1-s.^2);
            phi = base.^power;
            if power == 1
                dphiDs = -2*s;
            else
                dphiDs = -2*power*s.*(base.^(power-1));
            end
            dphiDt = dphiDs*(2/duration);
            phi = phi(:);
            dphiDt = dphiDt(:);

            % Weak equation: Arow*Xi = Brow. Equation scaling is arbitrary,
            % so normalize by the L1 mass of phi. This prevents longer weak
            % windows from receiving larger least-squares weight solely
            % because their integration interval is longer.
            rowMass = trapz(tw,abs(phi));
            if ~(isfinite(rowMass) && rowMass > eps)
                error('build_weak_sindy_regression:TestFunctionMass', ...
                    'Weak test function has invalid integral mass.');
            end

            % bsxfun is used intentionally instead of relying on implicit
            % expansion.  thw is W-by-nTheta and xw is W-by-nState; phi and
            % dphiDt are W-by-1.
            Aintegrand = bsxfun(@times,thw,phi);
            Bintegrand = bsxfun(@times,xw,dphiDt);
            Arow = trapz(tw,Aintegrand,1)/rowMass;
            Brow = -trapz(tw,Bintegrand,1)/rowMass;

            A(end+1,:) = Arow; %#ok<AGROW>
            B(end+1,:) = Brow; %#ok<AGROW>
            windowPointLog(end+1,1) = W; %#ok<AGROW>
            windowDurationLog(end+1,1) = duration; %#ok<AGROW>
            trajectoryLog(end+1,1) = tr; %#ok<AGROW>
        end
    end
end

if isempty(A)
    error('build_weak_sindy_regression:NoConstraints', ...
        'No weak-form regression rows were generated.');
end

meta = struct();
meta.trajectoryIds = trajectoryIds(:);
meta.constraintCount = size(A,1);
meta.windowPoints = windowPoints(:);
meta.windowStride = stride;
meta.testFunction = sprintf('(1-s^2)^%d',power);
meta.testFunctionPower = power;
meta.quadratureRule = 'composite trapezoidal';
meta.rowNormalization = 'divide by integral |phi| dt';
meta.windowPointLog = windowPointLog;
meta.windowDurationLog = windowDurationLog;
meta.trajectoryLog = trajectoryLog;
meta.derivativeLabelsUsed = false;
meta.integrationByParts = true;
end
