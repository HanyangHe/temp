function [model,info] = train_true_physics_oracle(dataset,c,layout,cfg) %#ok<INUSD>
%TRAIN_TRUE_PHYSICS_ORACLE No-op training for the exact reference vector field.

model.type = 'true_physics_oracle';
model.caseName = c.name;
info.usedTrainingData = false;
info.note = 'Exact physical vector field; no data-driven training is performed.';
end
