function methods = get_offline_method_registry(cfg)
%GET_OFFLINE_METHOD_REGISTRY Comparison-method plug-in registry.
%
% Registered learned methods include the final primary manuscript set:
%   Baselines: NODE, M-KBF, V-SINDy, ED-SINDy
%   Proposed:  LLM-Prior SINDy
% Additional legacy/ablation methods remain registered only when explicitly
% enabled by a configuration.
%   Legacy LLM-EDSI
%   Physics-embedded SINDy
%   Physics-Neural Compositional SINDy (PNC-SINDy)
%   Physics-Neural SINDy (flat ablation)
%   Weak SINDy
%
% All learned methods identify only modular DER differential dynamics. The
% electrical-network algebraic equations remain exact and common to every
% method during the final DAE rollout.

if nargin < 1 || isempty(cfg), cfg = struct(); end

methods = struct( ...
    'name',{},'displayName',{},'trainFcn',{},'predictFcn',{}, ...
    'usesTrainingData',{},'isTrueReference',{},'description',{});

methods(1).name = 'true_physics_oracle';
methods(1).displayName = 'True physics (oracle)';
methods(1).trainFcn = @train_true_physics_oracle;
methods(1).predictFcn = @predict_true_physics_oracle;
methods(1).usesTrainingData = false;
methods(1).isTrueReference = true;
methods(1).description = 'Exact physical vector-field oracle for optional debugging only.';

nodeEnabled = true;
if nargin>=1 && isfield(cfg,'node') && isfield(cfg.node,'enabled')
    nodeEnabled = logical(cfg.node.enabled);
end
if nodeEnabled
    k = numel(methods)+1;
    methods(k).name = 'neural_ode_modular';
    methods(k).displayName = 'NODE';
    methods(k).trainFcn = @train_node_vector_field;
    methods(k).predictFcn = @predict_node_vector_field;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Controlled modular Neural ODE trained on short truth trajectories. ', ...
        'Each DER dynamic module is learned with multi-step trajectory loss; ', ...
        'the network algebraic equations remain exact physics.'];
end


kopt = get_koopman_options(cfg);
if kopt.enabled
    k = numel(methods)+1;
    methods(k).name = 'modular_koopman_kbf';
    methods(k).displayName = 'M-KBF';
    methods(k).trainFcn = @train_modular_koopman_kbf;
    methods(k).predictFcn = @predict_modular_koopman_kbf;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Continuous-generator modular Koopman baseline based on Jiang et al. ', ...
        'Eq. (16). A fixed monomial lift maps local DER states to z, only A/B ', ...
        'are learned, and a fixed algebraic derivative map returns xdot. ', ...
        'The exact algebraic network remains shared physics.'];
end

sopt = get_sindy_options(cfg);
if sopt.enabled && sopt.vanilla.enabled
    k = numel(methods)+1;
    methods(k).name = 'vanilla_sindy';
    methods(k).displayName = 'V-SINDy';
    methods(k).trainFcn = @train_vanilla_sindy;
    methods(k).predictFcn = @predict_modular_sindy;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Pointwise modular SINDy with Poly_p(raw local inputs), sin(raw inputs), ', ...
        'and cos(raw inputs); no composed physics features. Reconstructed-derivative ', ...
        'labels use the shared support-preserving numerical refit.'];
end


% Proposed method: V-SINDy augmented by a compact weak-domain LLM-discovered
% physics bank. The bank is discovered once per seed and transferred across
% network sizes; all coefficients/support are still identified from data.
llmPriorEnabled = isfield(sopt,'llmPrior') && isstruct(sopt.llmPrior) && ...
    isfield(sopt.llmPrior,'enabled') && logical(sopt.llmPrior.enabled);
if sopt.enabled && llmPriorEnabled
    k = numel(methods)+1;
    methods(k).name = 'llm_prior_sindy';
    methods(k).displayName = 'LLM-Prior SINDy';
    methods(k).trainFcn = @train_llm_prior_sindy;
    methods(k).predictFcn = @predict_modular_sindy;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Proposed weak-prior SINDy: device semantics, averaged-model context, ', ...
        'and d/q coordinate metadata are compiled by an LLM into a compact ', ...
        'symbolic physics bank. The ordinary V-SINDy dictionary is retained, ', ...
        'and all coefficients/support are learned by the shared STLSQ backend.'];
end

poly3Enabled = isfield(cfg,'sindy') && isstruct(cfg.sindy) && ...
    isfield(cfg.sindy,'poly3Baseline') && isstruct(cfg.sindy.poly3Baseline) && ...
    isfield(cfg.sindy.poly3Baseline,'enabled') && ...
    logical(cfg.sindy.poly3Baseline.enabled);
if sopt.enabled && poly3Enabled
    k = numel(methods)+1;
    methods(k).name = 'poly3_sindy';
    methods(k).displayName = 'Poly-3 SINDy';
    methods(k).trainFcn = @train_poly3_sindy;
    methods(k).predictFcn = @predict_modular_sindy;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Pointwise modular SINDy using the same protocol as V-SINDy but with ', ...
        'the generic polynomial dictionary increased from order 2 to order 3. ', ...
        'The sin/cos atoms, STLSQ settings, validation split, and exact-network ', ...
        'rollout remain unchanged.'];
end


% Formal evolutionary dictionary identification.
edsiEnabled = isfield(cfg,'edsi') && isstruct(cfg.edsi) && ...
    isfield(cfg.edsi,'enabled') && logical(cfg.edsi.enabled);
if edsiEnabled
    k = numel(methods)+1;
    methods(k).name = 'edsi';
    methods(k).displayName = 'ED-SINDy';
    methods(k).trainFcn = @train_edsi;
    methods(k).predictFcn = @predict_edsi;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Evolutionary-Dictionary SINDy (ED-SINDy): fixed-width ', ...
        'evolution initialized from the V-SINDy dictionary, protected [1,x] ', ...
        'anchors, cheap sparse STLSQ search fitness, and the same final ', ...
        'STLSQ + reconstructed-derivative frozen-support ridge backend as ', ...
        'V-SINDy. No trajectory simulation is used inside search.'];
end

llmEdsiEnabled = isfield(cfg,'llmEdsi') && isstruct(cfg.llmEdsi) && ...
    isfield(cfg.llmEdsi,'enabled') && logical(cfg.llmEdsi.enabled);
if llmEdsiEnabled
    k = numel(methods)+1;
    methods(k).name = 'llm_edsi';
    methods(k).displayName = 'LLM-EDSI';
    methods(k).trainFcn = @train_llm_edsi;
    methods(k).predictFcn = @predict_edsi;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'LLM-EDSI: one-shot semantic refinement of selected sparse EDSI elites. ', ...
        'The LLM receives physical variable semantics, a compact sparse fitted ', ...
        'ODE, and top active terms; it proposes only a few structural terms. ', ...
        'The complete fixed-width dictionary is reconstructed locally and all ', ...
        'proposals are judged by the same V-SINDy-shared sparse identification ', ...
        'backend.'];
end

% Non-production weak-domain LLM prior-discovery diagnostic methods.
llmPriorDiagEnabled = isfield(sopt,'llmPriorDiagnostic') && ...
    isstruct(sopt.llmPriorDiagnostic) && ...
    isfield(sopt.llmPriorDiagnostic,'enabled') && ...
    logical(sopt.llmPriorDiagnostic.enabled);
if llmPriorDiagEnabled
    k = numel(methods)+1;
    methods(k).name = 'llm_prior_sindy_diagnostic';
    methods(k).displayName = 'LLM-Prior SINDy';
    methods(k).trainFcn = @train_llm_prior_sindy_diagnostic;
    methods(k).predictFcn = @predict_modular_sindy;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Diagnostic V-SINDy augmented only by a weak-domain LLM-compiled ', ...
        'prior bank. No hand-written PE-SINDy strong feature block is shown ', ...
        'to the LLM; coefficient identification is identical to V-SINDy.'];

    k = numel(methods)+1;
    methods(k).name = 'llm_prior_fixedwidth_sindy_diagnostic';
    methods(k).displayName = 'LLM-Prior FW-SINDy';
    methods(k).trainFcn = @train_llm_prior_fixedwidth_sindy_diagnostic;
    methods(k).predictFcn = @predict_edsi;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Diagnostic fixed-width distillation control: the weak-domain LLM prior ', ...
        'proposal pool is compressed to the original EDSI width (73/73/61), ', ...
        'then identified with the shared full STLSQ backend and stopped before ', ...
        'any evolutionary mutation/search.'];

    k = numel(methods)+1;
    methods(k).name = 'llm_prior_edsi_diagnostic';
    methods(k).displayName = 'LLM-Prior EDSI';
    methods(k).trainFcn = @train_llm_prior_edsi_diagnostic;
    methods(k).predictFcn = @predict_edsi;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Diagnostic fixed-width EDSI initialized by weak-domain LLM priors via ', ...
        'union-fit-compress. Generic and LLM terms compete under held-out ', ...
        'validation before compression; the exact V-SINDy seed is retained.'];


    k = numel(methods)+1;
    methods(k).name = 'llm_prior_augmented_edsi_diagnostic';
    methods(k).displayName = 'LLM-Prior EDSI';
    methods(k).trainFcn = @train_llm_prior_augmented_edsi_diagnostic;
    methods(k).predictFcn = @predict_edsi;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Diagnostic immutable-prior residual EDSI: the compact LLM prior bank ', ...
        'is identified once and then frozen; the original V-SINDy-width bank ', ...
        'evolves only against the remaining residual. Final adoption is chosen ', ...
        'by held-out short-trajectory rollout validation, not the manuscript test.'];
end

if sopt.enabled && sopt.physicsEmbedded.enabled
    k = numel(methods)+1;
    methods(k).name = 'physics_embedded_sindy';
    methods(k).displayName = 'Physics-embedded SINDy';
    methods(k).trainFcn = @train_physics_embedded_sindy;
    methods(k).predictFcn = @predict_modular_sindy;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
         'Physics-embedded SINDy with the complete physics candidate ', ...
        'library: rotating-frame/dq terms, SG AVR |V|, and full GFL rhoV interactions. ', ...
        'Reconstructed-derivative labels use the shared support-preserving numerical refit.' ];
end

if sopt.enabled && sopt.physicsNeuralCompositional.enabled
    k = numel(methods)+1;
    methods(k).name = 'physics_neural_compositional_sindy';
    methods(k).displayName = 'PNC-SINDy';
    methods(k).trainFcn = @train_physics_neural_compositional_sindy;
    methods(k).predictFcn = @predict_modular_pnc_sindy;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Physics-Neural Compositional SINDy v2. A PE-SINDy first layer is fitted ', ...
        'and frozen. The second sparse readout uses [f_PE_hat, the exact former ', ...
        'flat-PN dictionary on chi, and fixed tanh compositional features of ', ...
        '(chi,f_PE_hat)]. Exact PE and flat-PN parent candidates are embedded; ', ...
        'additional compositional depth is activated only by held-out validation.'];
end

% Residual-composition PNC diagnostic. This is never enabled by the production
% 10/69/123-bus configs; dedicated test scripts activate it explicitly.
if sopt.enabled && sopt.physicsNeuralCompositionalResidual.enabled
    k = numel(methods)+1;
    methods(k).name = 'pnc_residual_comp_sindy';
    methods(k).displayName = 'PNC-ResidualComp';
    methods(k).trainFcn = @train_pnc_residual_comp_sindy;
    methods(k).predictFcn = @predict_modular_pnc_residual_comp_sindy;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Diagnostic two-layer PNC form: fit/freeze a PE-SINDy backbone H, ', ...
        'then identify a sparse fixed-tanh correction to the residual ', ...
        'xdot-H using Phi_comp(chi,H). Xi_c=0 exactly recovers PE-SINDy.'];
end

% Residualized PNC-v3 diagnostic. This is never enabled by production
% 10/69/123-bus configs; the dedicated test script activates it explicitly.
if sopt.enabled && sopt.physicsNeuralCompositionalResidualizedV3.enabled
    k = numel(methods)+1;
    methods(k).name = 'pnc_residualized_v3_sindy';
    methods(k).displayName = 'PNC-v3-Residualized';
    methods(k).trainFcn = @train_pnc_residualized_v3_sindy;
    methods(k).predictFcn = @predict_modular_pnc_residualized_v3_sindy;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Diagnostic residualized PNC-v3: fit/freeze a PE-SINDy backbone H, ', ...
        'fit the same flat-PN parent, then identify xdot-H using ', ...
        '[H, the exact flat-PN dictionary, Phi_comp(chi,H)]. Exact PE and ', ...
        'flat-PN parent candidates are embedded before full residualized STLSQ.'];
end

% Strict Phi_comp-only PNC diagnostic. This is never enabled by the production
% 10/69/123-bus configs; dedicated test scripts activate it explicitly.
if sopt.enabled && sopt.physicsNeuralCompositionalCompOnly.enabled
    k = numel(methods)+1;
    methods(k).name = 'pnc_phi_comp_only_sindy';
    methods(k).displayName = 'PNC-CompOnly';
    methods(k).trainFcn = @train_pnc_phi_comp_only_sindy;
    methods(k).predictFcn = @predict_modular_pnc_phi_comp_only_sindy;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Strict PNC composition ablation: fit/freeze the PE-SINDy first layer, ', ...
        'construct fixed tanh Phi_comp(chi,f_PE_hat), and identify Xi_2 using ', ...
        'ONLY that compositional bank. No PE bypass or flat-PN skip is available.'];
end

% Former flat PN-SINDy is retained as an optional structure ablation only.
if sopt.enabled && sopt.physicsNeural.enabled
    k = numel(methods)+1;
    methods(k).name = 'physics_neural_sindy';
    methods(k).displayName = 'Physics-Neural SINDy';
    methods(k).trainFcn = @train_physics_neural_sindy;
    methods(k).predictFcn = @predict_modular_neural_sindy;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Flat PN-SINDy ablation: compact [1, raw chi, fixed tanh neural-ridge ', ...
        'features] concatenated with the complete PE-SINDy physics family ', ...
        'before one ordinary STLSQ readout.'];
end


if sopt.enabled && sopt.weakSindy.enabled
    k = numel(methods)+1;
    methods(k).name = 'weak_sindy';
    methods(k).displayName = 'Weak SINDy';
    methods(k).trainFcn = @train_weak_sindy;
    methods(k).predictFcn = @predict_modular_sindy;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Conventional weak-form SINDy using the same generic Poly-p + ', ...
        'sin/cos candidate library as Vanilla SINDy. Coefficients are ', ...
        'identified from compact-support integral constraints without ', ...
        'pointwise derivative labels.'];
end

% Legacy N-SINDy support is retained for backward compatibility only.
if sopt.enabled && sopt.neural.enabled
    k = numel(methods)+1;
    methods(k).name = 'neural_sindy';
    methods(k).displayName = 'Neural SINDy';
    methods(k).trainFcn = @train_neural_sindy;
    methods(k).predictFcn = @predict_modular_neural_sindy;
    methods(k).usesTrainingData = true;
    methods(k).isTrueReference = false;
    methods(k).description = [ ...
        'Compact pointwise SINDy with [1, raw local chi, fixed tanh neural-ridge ', ...
        'features]. The neural bank replaces the polynomial+sin/cos generic ', ...
        'dictionary and is fixed after training-only construction.'];
end

end
