function [model,info] = train_pnc_residual_comp_sindy(dataset,c,layout,cfg)
%TRAIN_PNC_RESIDUAL_COMP_SINDY Diagnostic PE + Phi_comp residual model.
%
%   H = f_PE_hat(chi)                              (fit/freeze Xi_1)
%   R = xdot - H
%   R_hat = Phi_comp(chi,H)*Xi_c
%   xdot_hat = H + R_hat
%
% Xi_c=0 is an exact selectable PE parent.
[model,info] = train_modular_pnc_residual_comp_sindy(dataset,c,layout,cfg);
end
