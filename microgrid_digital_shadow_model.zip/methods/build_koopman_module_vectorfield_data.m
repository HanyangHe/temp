function data = build_koopman_module_vectorfield_data(dataset,c,layout,deviceType,deviceIndex)
%BUILD_KOOPMAN_MODULE_VECTORFIELD_DATA Local x/u/xdot data for CT M-KBF.
%
% The external terminal boundary is identical to the other learned ODE
% baselines. In the measurement-noise study, dataset.x contains the common
% noisy observed state trajectory and dataset.labels contains derivatives
% reconstructed from that SAME trajectory by the shared numerical estimator.
% Terminal/reference forcing remains common to all methods.

base = build_sindy_module_data(dataset,c,layout,deviceType,deviceIndex);
nState = numel(base.stateIndices);
if size(base.X,2) <= nState
    error('build_koopman_module_vectorfield_data:MissingForcing', ...
        'Expected at least one terminal/reference forcing channel.');
end

data = struct();
data.deviceType = base.deviceType;
data.deviceIndex = base.deviceIndex;
data.stateIndices = base.stateIndices(:);
data.bus = base.bus;
data.stateNames = string(base.inputNames(1:nState));
data.forceNames = string(base.inputNames(nState+1:end));
data.x = base.X(:,1:nState).';
data.forcing = base.X(:,nState+1:end).';
data.xdot = base.Y.';
data.xdotClean = base.Yclean.';
data.trajectoryId = base.trajectoryId(:).';
data.pointInTrajectory = base.pointInTrajectory(:).';
data.nState = nState;
data.nForce = numel(data.forceNames);
data.nSamples = size(data.x,2);
end
