function [Phi,names,compiledSpec] = build_sindy_physics_features(X,deviceType,variant,opt,compiledSpec)
%BUILD_SINDY_PHYSICS_FEATURES Complete retained physics feature dictionary.
%
% variant = 'vanilla' : no additional physics features
%           'physics' : complete physics feature set used by PE-SINDy/PW-SINDy
%           'llmprior': formal weak-domain LLM-discovered basis bank
%
% SG+AVR (5-state) convention:
%   chi=[delta,nu,EqPrime,EdPrime,Efd,VR,VI,Pm,Vref]
%   Vq=VR*cos(delta)+VI*sin(delta)
%   Vd=VR*sin(delta)-VI*cos(delta)
% Physics features include the parameter-free electromagnetic coordinate
% products and |V|=sqrt(VR^2+VI^2), which is required by the AVR nonlinearity.
%
% For GFL modules, the dictionary includes the rotated dq coordinates and the
% rhoV=1/(VR^2+VI^2) interactions needed by the current-reference equations.
%
% Direct full equations with fixed parameter values are NOT inserted. Sparse
% regression still learns the coefficient structure from data.

if nargin < 5, compiledSpec = []; end
variant = lower(string(variant));
if variant == "vanilla"
    Phi = zeros(size(X,1),0);
    names = strings(0,1);
    compiledSpec = [];
    return;
end
if variant == "llmprior"
    priorOpt=[];
    if isfield(opt,'llmPrior') && isstruct(opt.llmPrior) && ...
            isfield(opt.llmPrior,'enabled') && logical(opt.llmPrior.enabled) && ...
            isfield(opt.llmPrior,'priorBank')
        priorOpt=opt.llmPrior;
    elseif isfield(opt,'llmPriorDiagnostic') && isstruct(opt.llmPriorDiagnostic) && ...
            isfield(opt.llmPriorDiagnostic,'priorBank')
        % Backward compatibility for old diagnostic runners.
        priorOpt=opt.llmPriorDiagnostic;
    end
    if isempty(priorOpt)
        error('build_sindy_physics_features:LLMPriorMissing', ...
            'LLM-prior basis construction requires a configured prior bank.');
    end
    t = lower(char(deviceType));
    if ~isfield(priorOpt.priorBank,t) || isempty(priorOpt.priorBank.(t))
        error('build_sindy_physics_features:LLMPriorDeviceMissing', ...
            'No LLM prior bank is available for device type %s.',t);
    end
    terms = string(priorOpt.priorBank.(t)(:));
    aliases = "x" + string((1:size(X,2)).');
    if isempty(compiledSpec)
        compiledSpec = compile_llm_prior_dsl(aliases,terms, ...
            'MaxDepth',priorOpt.maxExpressionDepth, ...
            'MaxComplexity',priorOpt.maxExpressionComplexity);
    end
    [Phi,canon] = evaluate_compiled_llm_prior_dsl(X,compiledSpec, ...
        'MaxAbsValue',priorOpt.maxBasisAbsValue);
    names = "llm_prior_" + canon(:);
    return;
end
if variant ~= "physics"
    error('build_sindy_physics_features:Variant','Unknown SINDy variant "%s".',variant);
end

compiledSpec = [];

switch lower(char(deviceType))
    case 'sg'
        if size(X,2) >= 9
            delta = X(:,1); Eq = X(:,3); Ed = X(:,4); VR = X(:,6); VI = X(:,7);
            Vq = VR.*cos(delta) + VI.*sin(delta);
            Vd = VR.*sin(delta) - VI.*cos(delta);
            Vmag = sqrt(VR.^2 + VI.^2);
            Phi = [Vq Vd Eq.*Vq Eq.*Vd Ed.*Vq Ed.*Vd Vq.^2 Vq.*Vd Vd.^2 Vmag];
            names = ["phys_Vq_rotor";"phys_Vd_rotor"; ...
                "phys_EqPrime_Vq";"phys_EqPrime_Vd"; ...
                "phys_EdPrime_Vq";"phys_EdPrime_Vd"; ...
                "phys_Vq2";"phys_Vq_Vd";"phys_Vd2";"phys_Vmag_AVR"];
        else
            % Backward-compatible classical SG feature set.
            delta = X(:,1); VR = X(:,3); VI = X(:,4);
            vd = VR.*cos(delta) + VI.*sin(delta);
            vq = VI.*cos(delta) - VR.*sin(delta);
            Phi = [vd vq];
            names = ["phys_vd_delta";"phys_vq_delta"];
        end

    case 'gfm'
        delta = X(:,1); E = X(:,4); VR = X(:,5); VI = X(:,6);
        vd = VR.*cos(delta) + VI.*sin(delta);
        vq = VI.*cos(delta) - VR.*sin(delta);
        Phi = [vd vq E.*vd E.*vq];
        names = ["phys_vd_delta";"phys_vq_delta";"phys_E_vd";"phys_E_vq"];

    case 'gfl'
        theta = X(:,1); VR = X(:,5); VI = X(:,6); Pstar = X(:,7); Qstar = X(:,8);
        vd = VR.*cos(theta) + VI.*sin(theta);
        vq = VI.*cos(theta) - VR.*sin(theta);
        Pvd = Pstar.*vd; Qvq = Qstar.*vq;
        Pvq = Pstar.*vq; Qvd = Qstar.*vd;
        v2 = VR.^2 + VI.^2;
        rho = 1./max(v2,opt.physics.voltageMagnitudeSquaredFloor);
        Phi = [vd vq Pvd Qvq Pvq Qvd rho rho.*Pvd rho.*Qvq rho.*Pvq rho.*Qvd];
        names = ["phys_vd";"phys_vq";"phys_Pstar_vd";"phys_Qstar_vq"; ...
            "phys_Pstar_vq";"phys_Qstar_vd";"phys_rhoV"; ...
            "phys_rhoV_Pstar_vd";"phys_rhoV_Qstar_vq"; ...
            "phys_rhoV_Pstar_vq";"phys_rhoV_Qstar_vd"];

    otherwise
        error('build_sindy_physics_features:DeviceType', ...
            'Unknown deviceType "%s".',char(deviceType));
end
end
