function [model,info] = train_mhid(dataset,c,layout,cfg)
%TRAIN_MHID Entry point for Multi-Horizon Integrated Dictionary identification.
[model,info] = train_modular_mhid(dataset,c,layout,cfg);
end
