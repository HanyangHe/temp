function fhat = predict_edsi(model,~,x,V,u,c,layout)
%PREDICT_EDSI Evaluate a trained EDSI / LLM-EDSI modular vector field.

fhat = zeros(layout.nx,1);

for k = 1:numel(c.sg)
    m = model.sg(k);
    chi = build_local_input_row_local(m,x,V,u,c);
    Theta = evaluate_dictionary_raw_local(m.dictionary,double(chi));
    fhat(m.stateIndices) = (Theta*m.coefficients).';
end

for k = 1:numel(c.gfm)
    m = model.gfm(k);
    chi = build_local_input_row_local(m,x,V,u,c);
    Theta = evaluate_dictionary_raw_local(m.dictionary,double(chi));
    fhat(m.stateIndices) = (Theta*m.coefficients).';
end

for k = 1:numel(c.gfl)
    m = model.gfl(k);
    chi = build_local_input_row_local(m,x,V,u,c);
    Theta = evaluate_dictionary_raw_local(m.dictionary,double(chi));
    fhat(m.stateIndices) = (Theta*m.coefficients).';
end

if any(~isfinite(fhat))
    error('predict_edsi:NonfiniteOutput', ...
        'EDSI/LLM-EDSI returned a non-finite vector field.');
end
end


function Xrow = build_local_input_row_local(m,x,V,u,c)
names = string(m.inputNames(:));
Xrow = zeros(1,numel(names));

nState = numel(m.stateIndices);
Xrow(1:nState) = x(m.stateIndices(:)).';

for j = (nState+1):numel(names)
    name = names(j);
    switch name
        case "Vterminal_Re"
            Xrow(j) = real(V(m.bus));
        case "Vterminal_Im"
            Xrow(j) = imag(V(m.bus));
        case "Pm"
            Xrow(j) = indexed_input_local(u,'sgPm',m.deviceIndex,c);
        case "Vref"
            Xrow(j) = indexed_input_local(u,'sgVref',m.deviceIndex,c);
        case "Pstar"
            if strcmpi(m.deviceType,'gfm')
                Xrow(j) = indexed_input_local(u,'gfmPstar',m.deviceIndex,c);
            elseif strcmpi(m.deviceType,'gfl')
                Xrow(j) = indexed_input_local(u,'gflPstar',m.deviceIndex,c);
            else
                error('predict_edsi:Pstar', ...
                    'Pstar is undefined for device type %s.',m.deviceType);
            end
        case "Qstar"
            if strcmpi(m.deviceType,'gfm')
                Xrow(j) = indexed_input_local(u,'gfmQstar',m.deviceIndex,c);
            elseif strcmpi(m.deviceType,'gfl')
                Xrow(j) = indexed_input_local(u,'gflQstar',m.deviceIndex,c);
            else
                error('predict_edsi:Qstar', ...
                    'Qstar is undefined for device type %s.',m.deviceType);
            end
        case "Eref"
            Xrow(j) = indexed_input_local(u,'gfmEref',m.deviceIndex,c);
        otherwise
            error('predict_edsi:UnknownInput', ...
                'Unknown input name "%s".',name);
    end
end
end


function value = indexed_input_local(u,fieldName,k,c)
if isstruct(u) && isfield(u,fieldName) && numel(u.(fieldName))>=k
    value = u.(fieldName)(k);
    return;
end
if isstruct(c) && isfield(c,'input') && isfield(c.input,'nominal') && ...
        isfield(c.input.nominal,fieldName) && ...
        numel(c.input.nominal.(fieldName))>=k
    value = c.input.nominal.(fieldName)(k);
    return;
end
error('predict_edsi:MissingInput','Input %s(%d) is unavailable.',fieldName,k);
end


function Theta = evaluate_dictionary_raw_local(basis,X)
Theta = zeros(size(X,1),numel(basis));
for j = 1:numel(basis)
    Theta(:,j) = evaluate_expression_direct_local(basis{j},X);
end
end


function value = evaluate_expression_direct_local(expr,X)
switch expr.op
    case 'const'
        value = ones(size(X,1),1);
    case 'var'
        value = X(:,expr.varIndex);
    case 'sin'
        value = sin(evaluate_expression_direct_local(expr.children{1},X));
    case 'cos'
        value = cos(evaluate_expression_direct_local(expr.children{1},X));
    case 'square'
        q = evaluate_expression_direct_local(expr.children{1},X);
        value = q.^2;
    case 'sqrt_pos'
        q = evaluate_expression_direct_local(expr.children{1},X);
        if any(q < -100*eps(max(1,max(abs(q)))))
            value = nan(size(q));
        else
            value = sqrt(max(q,0));
        end
    case 'prod'
        value = ones(size(X,1),1);
        for k = 1:numel(expr.children)
            value = value .* evaluate_expression_direct_local(expr.children{k},X);
        end
    case 'add'
        value = zeros(size(X,1),1);
        for k = 1:numel(expr.children)
            value = value + evaluate_expression_direct_local(expr.children{k},X);
        end
    case 'sub'
        value = evaluate_expression_direct_local(expr.children{1},X) - ...
            evaluate_expression_direct_local(expr.children{2},X);
    case 'div'
        num = evaluate_expression_direct_local(expr.children{1},X);
        den = evaluate_expression_direct_local(expr.children{2},X);
        if any(~isfinite(den)) || any(abs(den)<1e-8)
            value = nan(size(num));
        else
            value = num./den;
        end
    otherwise
        error('predict_edsi:UnknownOperator', ...
            'Unknown expression operator "%s".',expr.op);
end
end
