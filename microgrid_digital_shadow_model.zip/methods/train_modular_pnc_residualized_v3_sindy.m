function [model,info] = train_modular_pnc_residualized_v3_sindy(dataset,c,layout,cfg)
%TRAIN_MODULAR_PNC_RESIDUALIZED_V3_SINDY Train diagnostic PNC-v3 modules.

opt = get_sindy_options(cfg);
K = dataset.trajectories.nTrajectories;
if K < 2
    error('train_modular_pnc_residualized_v3_sindy:TooFewTrajectories', ...
        'At least two trajectories are required.');
end

forcedTrainIds = [];
if isfield(dataset.trajectories,'forceTrainingMask') && ...
        ~isempty(dataset.trajectories.forceTrainingMask)
    m = logical(dataset.trajectories.forceTrainingMask(:));
    if numel(m) ~= K
        error('train_modular_pnc_residualized_v3_sindy:ForceTrainingMaskSize', ...
            'forceTrainingMask must contain one entry per trajectory.');
    end
    forcedTrainIds = find(m).';
end
validationCandidates = setdiff(1:K,forcedTrainIds,'stable');
if isempty(validationCandidates)
    error('train_modular_pnc_residualized_v3_sindy:NoValidationCandidates', ...
        'No trajectory remains for validation.');
end
oldRng = rng;
cleanup = onCleanup(@()rng(oldRng)); %#ok<NASGU>
rng(opt.validationSeed,'twister');
perm = validationCandidates(randperm(numel(validationCandidates)));
nVal = max(1,round(opt.validationFraction*K));
nVal = min(nVal,numel(validationCandidates));
if nVal >= K, nVal = K-1; end
valIds = sort(perm(1:nVal));
trainIds = sort(setdiff(1:K,valIds,'stable'));
trainMask = ismember(dataset.trajectoryId,trainIds);
valMask = ismember(dataset.trajectoryId,valIds);

model = struct();
model.type = 'modular_sindy';
model.formulationVersion = char(opt.formulationVersion);
model.method = 'PNC-v3-Residualized';
model.variant = 'pnc_residualized_v3';
model.architectureVersion = 'pnc_residualized_skip_composition_v3';
model.libraryVariant = 'pe_backbone_plus_residualized_h_flatpn_composition';
model.fitMode = 'stagewise_frozen_pe_plus_residualized_parent_skip_composition';
model.trainingObjective = [ ...
    'diagnostic: freeze a PE-SINDy backbone, then identify the residual with ', ...
    '[H, exact flat-PN dictionary, fixed neural composition], including exact ', ...
    'PE and flat-PN parent candidates'];
model.trainingSampleDefinition = ...
    'flattened pointwise samples from common short-trajectory dataset';
model.sg = struct([]); model.gfm = struct([]); model.gfl = struct([]);
model.trainTrajectoryIds = trainIds(:);
model.validationTrajectoryIds = valIds(:);
model.forcedTrainingTrajectoryIds = forcedTrainIds(:);
model.options = opt;

modules = struct([]);
mi = 0;
activeTotal = 0;
candidateTotal = 0;
layer1ActiveTotal = 0;
layer2ActiveTotal = 0;
peParentCount = 0;
pnParentCount = 0;
fullCount = 0;
trueCompCount = 0;

for k = 1:numel(c.sg)
    fprintf('    Training PNC-v3 residualized module SG%d (Bus %d)...\n',k,c.sg(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'sg',k);
    seed = module_seed_local(opt.neuralBasis.seed,'sg',k);
    [mk,ik] = fit_pnc_residualized_v3_module(data,trainMask,valMask,opt,seed);
    if k==1, model.sg=mk; else, model.sg(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    [activeTotal,candidateTotal,layer1ActiveTotal,layer2ActiveTotal, ...
        peParentCount,pnParentCount,fullCount,trueCompCount] = ...
        accumulate_local(ik,activeTotal,candidateTotal,layer1ActiveTotal, ...
        layer2ActiveTotal,peParentCount,pnParentCount,fullCount,trueCompCount);
end
for k = 1:numel(c.gfm)
    fprintf('    Training PNC-v3 residualized module GFM%d (Bus %d)...\n',k,c.gfm(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfm',k);
    seed = module_seed_local(opt.neuralBasis.seed,'gfm',k);
    [mk,ik] = fit_pnc_residualized_v3_module(data,trainMask,valMask,opt,seed);
    if k==1, model.gfm=mk; else, model.gfm(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    [activeTotal,candidateTotal,layer1ActiveTotal,layer2ActiveTotal, ...
        peParentCount,pnParentCount,fullCount,trueCompCount] = ...
        accumulate_local(ik,activeTotal,candidateTotal,layer1ActiveTotal, ...
        layer2ActiveTotal,peParentCount,pnParentCount,fullCount,trueCompCount);
end
for k = 1:numel(c.gfl)
    fprintf('    Training PNC-v3 residualized module GFL%d (Bus %d)...\n',k,c.gfl(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfl',k);
    seed = module_seed_local(opt.neuralBasis.seed,'gfl',k);
    [mk,ik] = fit_pnc_residualized_v3_module(data,trainMask,valMask,opt,seed);
    if k==1, model.gfl=mk; else, model.gfl(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    [activeTotal,candidateTotal,layer1ActiveTotal,layer2ActiveTotal, ...
        peParentCount,pnParentCount,fullCount,trueCompCount] = ...
        accumulate_local(ik,activeTotal,candidateTotal,layer1ActiveTotal, ...
        layer2ActiveTotal,peParentCount,pnParentCount,fullCount,trueCompCount);
end

model.activeCoefficientCount = activeTotal;
model.candidateCoefficientCount = candidateTotal;
model.layer1ActiveCoefficientCount = layer1ActiveTotal;
model.layer2ActiveCoefficientCount = layer2ActiveTotal;
model.peParentSelectedModuleCount = peParentCount;
model.flatPNParentSelectedModuleCount = pnParentCount;
model.fullResidualizedPNCSelectedModuleCount = fullCount;
model.trueCompositionUsedModuleCount = trueCompCount;
model.compatibilitySchema = 'diagnostic_only';
model.compatibilitySignature = struct('architectureVersion',model.architectureVersion);

info = struct();
info.method = 'pnc_residualized_v3_sindy';
info.formulationVersion = char(opt.formulationVersion);
info.displayName = 'PNC-v3-Residualized';
info.variant = model.variant;
info.architectureVersion = model.architectureVersion;
info.libraryVariant = model.libraryVariant;
info.fitMode = model.fitMode;
info.objective = model.trainingObjective;
info.nSamples = size(dataset.x,1);
info.nTrajectories = K;
info.nTrainSamples = nnz(trainMask);
info.nValidationSamples = nnz(valMask);
info.nTrainTrajectories = numel(trainIds);
info.nValidationTrajectories = numel(valIds);
info.trainTrajectoryIds = trainIds(:);
info.validationTrajectoryIds = valIds(:);
info.forcedTrainingTrajectoryIds = forcedTrainIds(:);
info.modules = modules;
info.activeCoefficientCount = activeTotal;
info.candidateCoefficientCount = candidateTotal;
info.layer1ActiveCoefficientCount = layer1ActiveTotal;
info.layer2ActiveCoefficientCount = layer2ActiveTotal;
info.peParentSelectedModuleCount = peParentCount;
info.flatPNParentSelectedModuleCount = pnParentCount;
info.fullResidualizedPNCSelectedModuleCount = fullCount;
info.trueCompositionUsedModuleCount = trueCompCount;
info.neuralBasisFeatureCount = opt.neuralBasis.featureCount;
info.neuralBasisActivation = opt.neuralBasis.activation;
info.compatibilitySchema = model.compatibilitySchema;
info.compatibilitySignature = model.compatibilitySignature;

if ~isempty(forcedTrainIds) && opt.verbose
    fprintf('    Forced into PNC-v3 residualized training partition: trajectory ID(s) [%s]\n', ...
        strtrim(sprintf('%d ',forcedTrainIds)));
end
end

function [a,c,l1,l2,npe,npn,nfull,ncomp] = accumulate_local(ik,a,c,l1,l2,npe,npn,nfull,ncomp)
a = a + ik.totalActiveCoefficientCount;
c = c + ik.totalCandidateCoefficientCount;
l1 = l1 + ik.layer1ActiveCoefficientCount;
l2 = l2 + ik.activeCoefficientCount;
npe = npe + logical(ik.peParentSelected);
npn = npn + logical(ik.flatPNParentSelected);
nfull = nfull + logical(ik.fullResidualizedPNCSelected);
ncomp = ncomp + (ik.activeCompositionalCoefficientCount > 0);
end

function [S,mi] = append_info_local(S,mi,ik)
mi = mi+1;
if mi==1, S=ik; else, S(mi,1)=ik; end
end

function seed = module_seed_local(baseSeed,deviceType,k)
switch lower(char(deviceType))
    case 'sg', offset=100*k;
    case 'gfm', offset=10000+100*k;
    case 'gfl', offset=20000+100*k;
    otherwise, offset=30000+100*k;
end
seed = round(double(baseSeed))+offset;
end
