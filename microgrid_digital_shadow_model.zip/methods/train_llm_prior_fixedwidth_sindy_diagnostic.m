function [model,info] = train_llm_prior_fixedwidth_sindy_diagnostic(dataset,c,layout,cfg)
%TRAIN_LLM_PRIOR_FIXEDWIDTH_SINDY_DIAGNOSTIC Fixed-width LLM-prior baseline.
%
% Diagnostic control method used to isolate the effect of fixed-width
% distillation from the subsequent EDSI evolution:
%
%   V-SINDy dictionary + weak-domain LLM prior proposal pool
%       -> fixed-width proposal competition/compression (73/73/61)
%       -> full shared STLSQ identification
%       -> STOP (no evolutionary mutation/search)
%
% Thus this method has exactly the same fixed dictionary width as EDSI but
% no evolutionary search. It is the direct bridge between expanded
% LLM-Prior SINDy and LLM-Prior EDSI.
[model,info] = train_edsi_core(dataset,c,layout,cfg,"llm_prior_fixedwidth_sindy");
end
