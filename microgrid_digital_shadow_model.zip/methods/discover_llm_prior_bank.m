function prior = discover_llm_prior_bank(projectRoot,discoverySeed,cfg)
%DISCOVER_LLM_PRIOR_BANK Formal weak-domain LLM prior discovery.
%
% One device-type prior is discovered for SG, GFM, and GFL under each
% discovery seed. The prior is deliberately NETWORK-INDEPENDENT: the prompt
% contains only device class, variable semantics, averaged-model context, and
% the local d/q coordinate convention. Therefore the same seed-specific prior
% bank is reused across 10/69/123-bus cases and across every N/noise condition.
%
% A compact MAT summary is cached under
%   outputs/llm_prior_discovery_shared/seed_<seed>/
% and is invalidated automatically when the discovery protocol source/settings
% change. The Python adapter retains its own record/replay cache as a second
% layer of protection against unnecessary cloud calls.

if nargin<1 || isempty(projectRoot)
    projectRoot=fileparts(fileparts(mfilename('fullpath')));
end
if nargin<2 || isempty(discoverySeed), discoverySeed=20260814; end
if nargin<3 || isempty(cfg), cfg=config_offline_experiment_10bus(); end
addpath(genpath(projectRoot));

if ~isfield(cfg,'sindy') || ~isstruct(cfg.sindy) || ...
        ~isfield(cfg.sindy,'llmPrior') || ~isstruct(cfg.sindy.llmPrior)
    error('discover_llm_prior_bank:MissingConfig', ...
        'cfg.sindy.llmPrior must be defined.');
end
lp=cfg.sindy.llmPrior;

runtimeRoot=fullfile(projectRoot,'outputs','llm_prior_discovery_shared', ...
    sprintf('seed_%d',round(double(discoverySeed))));
if exist(runtimeRoot,'dir')~=7, mkdir(runtimeRoot); end
summaryFile=fullfile(runtimeRoot,'llm_prior_bank.mat');

configPath=fullfile(projectRoot,'config','llm_edsi_ode_prior_config.json');
adapterPath=fullfile(projectRoot,'adapters','llm_prior_discovery_adapter.py');
semanticPath=fullfile(projectRoot,'methods','build_llm_prior_semantic_context.m');
if exist(configPath,'file')~=2 || exist(adapterPath,'file')~=2 || exist(semanticPath,'file')~=2
    error('discover_llm_prior_bank:MissingRuntimeFile', ...
        'LLM prior adapter/config/semantic helper is missing.');
end
q=jsondecode(fileread(configPath));

protocol=struct();
protocol.formulationVersion=char(string(lp.formulationVersion));
protocol.discoveryProtocolVersion=char(string(lp.discoveryProtocolVersion));
protocol.model=char(string(q.model));
protocol.reasoningEffort=char(string(lp.reasoningEffort));
protocol.maxOutputTokens=double(lp.maxOutputTokens);
protocol.maxExpressionDepth=double(lp.maxExpressionDepth);
protocol.maxExpressionComplexity=double(lp.maxExpressionComplexity);
protocol.maxBasisTerms=double(lp.maxBasisTerms);
protocol.maxLatentFeatures=double(lp.maxLatentFeatures);
protocol.adapterHash=fnv1a32_local(fileread(adapterPath));
protocol.semanticHash=fnv1a32_local(fileread(semanticPath));
protocolHash=fnv1a32_local(jsonencode(protocol));

% Fast formal cache: reuse only if both seed and protocol hash match.
if exist(summaryFile,'file')==2
    try
        S=load(summaryFile,'prior');
        if isfield(S,'prior') && isstruct(S.prior) && ...
                isfield(S.prior,'discoverySeed') && ...
                round(double(S.prior.discoverySeed))==round(double(discoverySeed)) && ...
                isfield(S.prior,'discoveryProtocolHash') && ...
                strcmpi(char(string(S.prior.discoveryProtocolHash)),protocolHash)
            prior=S.prior;
            prior.totalCloudCalls=0;
            prior.wallLatencySeconds=0;
            fprintf(['\n[LLM PRIOR] Reusing shared formal prior bank | seed=%d | ', ...
                'hash=%s | protocol=%s\n'],round(double(discoverySeed)), ...
                char(string(prior.bankHash)),protocolHash);
            return;
        end
    catch ME
        warning('discover_llm_prior_bank:CachedSummaryInvalid', ...
            'Ignoring invalid cached prior summary: %s',ME.message);
    end
end

adapterCfg=q;
types={'sg','gfm','gfl'};
results=cell(numel(types),1);

useParallel=false;
try
    useParallel=license('test','Distrib_Computing_Toolbox');
catch
end
requestedWorkers=6;
if isfield(cfg,'parallel') && isstruct(cfg.parallel) && ...
        isfield(cfg.parallel,'numWorkers') && ~isempty(cfg.parallel.numWorkers)
    requestedWorkers=max(1,round(double(cfg.parallel.numWorkers)));
end
if useParallel
    pool=gcp('nocreate');
    if isempty(pool)
        try
            profile='local';
            if isfield(cfg,'parallel') && isfield(cfg.parallel,'poolProfile') && ...
                    ~isempty(cfg.parallel.poolProfile)
                profile=char(string(cfg.parallel.poolProfile));
            end
            parpool(profile,requestedWorkers);
        catch
            useParallel=false;
        end
    end
end

wallStart=tic;
if useParallel
    parfor it=1:numel(types)
        try
            results{it}=call_one_local(projectRoot,discoverySeed,runtimeRoot, ...
                adapterCfg,adapterPath,types{it},lp);
        catch ME
            results{it}=struct('failed',true,'errorMessage',ME.message);
        end
    end
    % Retry only failed concurrent requests so successful cached/cloud results
    % are never wasted.
    for it=1:numel(types)
        if isstruct(results{it}) && isfield(results{it},'failed') && results{it}.failed
            warning('discover_llm_prior_bank:ParallelRetry', ...
                'Parallel %s discovery failed (%s). Retrying serially.', ...
                upper(types{it}),results{it}.errorMessage);
            results{it}=call_one_local(projectRoot,discoverySeed,runtimeRoot, ...
                adapterCfg,adapterPath,types{it},lp);
        end
    end
else
    for it=1:numel(types)
        results{it}=call_one_local(projectRoot,discoverySeed,runtimeRoot, ...
            adapterCfg,adapterPath,types{it},lp);
    end
end
wallLatency=toc(wallStart);

prior=struct();
prior.discoverySeed=double(discoverySeed);
prior.formulationVersion=char(string(lp.formulationVersion));
prior.discoveryProtocolVersion=char(string(lp.discoveryProtocolVersion));
prior.discoveryProtocolHash=protocolHash;
prior.bank=struct();
prior.items=struct();
prior.responses=struct();
prior.totalCloudCalls=0;
prior.totalInputTokens=0;
prior.totalOutputTokens=0;
prior.totalCostUSD=0;
prior.totalLatencySeconds=0;
prior.wallLatencySeconds=wallLatency;
prior.parallelDiscovery=useParallel;

for it=1:numel(types)
    type=types{it}; r=results{it}; resp=r.response;
    fprintf('\n[LLM PRIOR DISCOVERY] %s | seed=%d\n%s\n', ...
        upper(type),round(double(discoverySeed)),strtrim(r.cmdout));
    terms=string(resp.compiled_prior_bank(:));
    prior.bank.(type)=cellstr(terms);
    if isfield(resp,'compiled_prior_items')
        prior.items.(type)=resp.compiled_prior_items;
    else
        prior.items.(type)=struct([]);
    end
    prior.responses.(type)=resp;
    prior.totalCloudCalls=prior.totalCloudCalls+get_num_local(resp,'cloud_call_count',0);
    if isfield(resp,'usage')
        prior.totalInputTokens=prior.totalInputTokens+get_num_local(resp.usage,'input_tokens',0);
        prior.totalOutputTokens=prior.totalOutputTokens+get_num_local(resp.usage,'output_tokens',0);
    end
    prior.totalCostUSD=prior.totalCostUSD+get_num_local(resp,'estimated_cost_usd',0);
    prior.totalLatencySeconds=prior.totalLatencySeconds+get_num_local(resp,'latency_seconds',0);
    fprintf('  supplied d/q coordinate terms : %d\n',numel(resp.supplied_coordinate_terms));
    fprintf('  LLM-discovered extra terms    : %d\n',numel(resp.llm_discovered_terms));
    if isfield(resp,'interaction_closures')
        fprintf('  interaction closure groups    : %d\n',numel(resp.interaction_closures));
    end
    if isfield(resp,'closure_generated_terms')
        fprintf('  closure-generated terms       : %d\n',numel(resp.closure_generated_terms));
    end
    fprintf('  compiled bank size            : %d\n',numel(resp.compiled_prior_bank));
end
hashPayload=struct('bank',prior.bank,'items',prior.items);
prior.bankHash=fnv1a32_local(jsonencode(hashPayload));

save(summaryFile,'prior','-v7.3');
fprintf('\nFormal prior-bank hash: %s | protocol=%s\n',prior.bankHash,protocolHash);
fprintf(['Total cloud calls=%d | tokens=%d+%d | API=$%.6f | ', ...
    'sum API latency=%.2fs | wall discovery=%.2fs | parallel=%d\n'], ...
    prior.totalCloudCalls,prior.totalInputTokens,prior.totalOutputTokens, ...
    prior.totalCostUSD,prior.totalLatencySeconds,prior.wallLatencySeconds, ...
    prior.parallelDiscovery);
end


function out=call_one_local(projectRoot,discoverySeed,runtimeRoot,q,adapterPath,type,lp)
[inputNames,outputNames]=prototype_names_local(type);
% Bus 0 is intentional: the prior is device-type knowledge and contains no
% network-size/bus-location information. This is what permits direct transfer
% of the same seed-specific prior bank across 10/69/123-bus cases.
sem=build_llm_prior_semantic_context(type,1,0,inputNames,outputNames);
typeRoot=fullfile(runtimeRoot,upper(type));
if exist(typeRoot,'dir')~=7, mkdir(typeRoot); end
requestPath=fullfile(typeRoot,'request.json');
responsePath=fullfile(typeRoot,'response.json');

req=struct();
req.model=char(string(q.model));
req.reasoning_effort=char(string(lp.reasoningEffort));
req.max_output_tokens=double(lp.maxOutputTokens);
req.store=logical(q.storeResponses);
req.cache_mode=char(string(q.cacheMode));
req.discovery_seed=double(discoverySeed);
req.semantic_system=sem;
req.max_expression_depth=double(lp.maxExpressionDepth);
req.max_expression_complexity=double(lp.maxExpressionComplexity);
req.max_basis_terms=double(lp.maxBasisTerms);
req.max_latent_features=double(lp.maxLatentFeatures);
req.cache_dir=fullfile(typeRoot,'cache');
req.pricing_usd_per_million=struct( ...
    'input',double(q.pricingUsdPerMillion.input), ...
    'cached_input',double(q.pricingUsdPerMillion.cachedInput), ...
    'cache_write',double(q.pricingUsdPerMillion.cacheWrite), ...
    'output',double(q.pricingUsdPerMillion.output));

fid=fopen(requestPath,'w');
if fid<0, error('Cannot write %s.',requestPath); end
fprintf(fid,'%s',jsonencode(req)); fclose(fid);
cmd=sprintf('"%s" "%s" "%s" "%s"', ...
    char(string(q.pythonExe)),adapterPath,requestPath,responsePath);
[status,cmdout]=system(cmd);
if exist(responsePath,'file')~=2
    error('discover_llm_prior_bank:NoResponse','No LLM response file for %s.',type);
end
resp=jsondecode(fileread(responsePath));
if status~=0 || ~isfield(resp,'ok') || ~logical(resp.ok)
    msg='unknown LLM prior-discovery failure';
    if isfield(resp,'error_message'), msg=char(string(resp.error_message)); end
    error('discover_llm_prior_bank:LLMFailure', ...
        '%s prior discovery failed: %s',upper(type),msg);
end

% Independent MATLAB compiler contract check before any identified model uses
% the discovered expressions.
terms=string(resp.compiled_prior_bank(:));
aliases="x"+string((1:numel(inputNames)).');
spec=compile_llm_prior_dsl(aliases,terms, ...
    'MaxDepth',double(lp.maxExpressionDepth), ...
    'MaxComplexity',double(lp.maxExpressionComplexity));
evaluate_compiled_llm_prior_dsl(ones(3,numel(inputNames)),spec, ...
    'MaxAbsValue',double(lp.maxBasisAbsValue));
out=struct('response',resp,'cmdout',cmdout);
end


function [inputNames,outputNames]=prototype_names_local(type)
switch lower(type)
    case 'sg'
        inputNames=["delta";"nu";"EqPrime";"EdPrime";"Efd"; ...
            "Vterminal_Re";"Vterminal_Im";"Pm";"Vref"];
        outputNames=["delta_dot";"nu_dot";"EqPrime_dot";"EdPrime_dot";"Efd_dot"];
    case 'gfm'
        inputNames=["delta";"pFilt";"qFilt";"E";"Vterminal_Re"; ...
            "Vterminal_Im";"Pstar";"Qstar";"Eref"];
        outputNames=["delta_dot";"pFilt_dot";"qFilt_dot";"E_dot"];
    case 'gfl'
        inputNames=["thetaPLL";"xiPLL";"id";"iq";"Vterminal_Re"; ...
            "Vterminal_Im";"Pstar";"Qstar"];
        outputNames=["thetaPLL_dot";"xiPLL_dot";"id_dot";"iq_dot"];
    otherwise
        error('Unknown type %s.',type);
end
end

function v=get_num_local(s,name,defaultVal)
v=defaultVal;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    q=double(s.(name));
    if isscalar(q)&&isfinite(q), v=q; end
end
end

function h=fnv1a32_local(txt)
bytes=unicode2native(char(txt),'UTF-8');
hv=uint64(2166136261); prime=uint64(16777619); modulus=uint64(4294967296);
for i=1:numel(bytes)
    hv=bitxor(hv,uint64(bytes(i))); hv=mod(hv*prime,modulus);
end
h=sprintf('%08X',uint32(hv));
end
