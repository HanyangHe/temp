function [xNext,VNext,info] = jiang_mkbf_native_step(model,xPrev,VPrev,uNext,tNext,c,layout,opt)
%JIANG_MKBF_NATIVE_STEP Causal step of a DISCRETE isotypic EDMD model.
%
% EDMD maps lifted states z_k directly to z_(k+1). No division by dt and
% no ODE15I conversion. Known electrical port equations are used ONLY to
% close the network algebraic balance. No future measured voltages/states.
%
% Endpoint mode: alternate between EDMD q_(k+1) and g(x_(k+1),V_(k+1))=0.
% Lagged mode: one causal q_k predictor + network solve, diagnostic ONLY.
% This is an adaptation to the project's SG/GFM/GFL, not original author code.

if nargin<8, opt=struct(); end
opt=apply_defaults(opt);
nx=layout.nx;
if numel(xPrev)~=nx || numel(VPrev)~=c.network.N
    error('jiang_native_step:Dimensions','State/voltage dimension mismatch.');
end
xPrev=double(xPrev(:)); VPrev=double(VPrev(:));
mods=[model.sg(:);model.gfm(:);model.gfl(:)];
nMod=numel(mods);
baseZ=cell(nMod,1);
for j=1:nMod
    m=mods(j);
    xi=xPrev(m.stateIndices(:));
    h=(xi(2:end)-m.stateMean(:))./m.stateStd(:);
    [Z,~,~]=build_koopman_isotypic_lift(xi(1),h,m.stateNames(2:end), ...
        m.polyOrder,m.liftSpec,[],[],m.stateNames(1));
    baseZ{j}=Z(:,1);
end

xGuess=xPrev;
VGuess=VPrev;
info=struct('success',false,'status','NOT_STARTED','message','', ...
    'outerIterations',0,'voltageIterations',0,'voltageResidualInf',NaN, ...
    'stepChangeInf',NaN,'mode',opt.couplingMode);
if strcmpi(opt.couplingMode,'lagged')
    xCandidate=propose(xPrev,VPrev);
    [VNext,net]=voltage_newton(xCandidate,VPrev,uNext,tNext,c,layout,opt);
    xNext=xCandidate;
    info=fill_info(info,net,1,0);
    if ~net.success
        info.status='ALGEBRAIC_NOT_CONVERGED';info.message=net.message;return
    end
    info.success=true; info.status='SUCCESS'; return
end

lastX=inf(nx,1);
for it=1:opt.maxCouplingIterations
    try
        xCandidate=propose(xGuess,VGuess);
    catch ME
        xNext=xGuess; VNext=VGuess;
        info.status='EDMD_STEP_FAILURE';info.message=ME.message;
        info.outerIterations=it;return
    end
    if any(~isfinite(xCandidate)) || max(abs(xCandidate))>opt.maxAbsState
        xNext=xGuess;VNext=VGuess;
        info.status='EDMD_STATE_GUARD';
        info.message='EDMD predicted nonfinite or excessive state magnitude.';
        info.outerIterations=it;return
    end
    [vCandidate,net]=voltage_newton(xCandidate,VGuess,uNext,tNext,c,layout,opt);
    info.voltageIterations=info.voltageIterations+net.iterations;
    info.voltageResidualInf=net.residualInf;
    if ~net.success
        xNext=xGuess;VNext=VGuess;
        info.status='ALGEBRAIC_NOT_CONVERGED';info.message=net.message;
        info.outerIterations=it;return
    end
    sx=max(1,abs(xCandidate));
    stepChange=max(abs(xCandidate-xGuess)./sx);
    sv=max(1,abs(vCandidate));
    voltageChange=max(abs(vCandidate-VGuess)./sv);
    info.stepChangeInf=max(stepChange,voltageChange);
    if info.stepChangeInf<=opt.couplingTolerance
        xNext=xCandidate;VNext=vCandidate;
        info.success=true;info.status='SUCCESS';info.outerIterations=it;
        return
    end
    % Under-relax the fixed-point iteration. This is NOT an actual time
    % step, only a numerical solver for the jointly coupled step.
    xGuess=xGuess+opt.couplingRelaxation*(xCandidate-xGuess);
    VGuess=VGuess+opt.couplingRelaxation*(vCandidate-VGuess);
    lastX=xCandidate;
end
xNext=xGuess;VNext=VGuess;
info.status='COUPLING_NOT_CONVERGED';
info.message=sprintf('Endpoint fixed point failed in %d iterations; residual=%.3g.', ...
    opt.maxCouplingIterations,info.stepChangeInf);
info.outerIterations=opt.maxCouplingIterations;

    function xa=propose(xPort,voltagePort)
        xa=zeros(nx,1);
        for kk=1:nMod
            m=mods(kk);
            ids=m.stateIndices(:);
            xForPort=xPort(ids);
            if strcmpi(m.deviceType,'sg')
                j=m.deviceIndex;
                if isfield(uNext,'sgVref') && numel(uNext.sgVref)>=j
                    refs=[uNext.sgPm(j);uNext.sgVref(j)];
                else
                    refs=uNext.sgPm(j);
                end
            elseif strcmpi(m.deviceType,'gfm')
                j=m.deviceIndex;
                refs=[uNext.gfmPstar(j);uNext.gfmQstar(j);uNext.gfmEref(j)];
            else
                j=m.deviceIndex;
                refs=[uNext.gflPstar(j);uNext.gflQstar(j)];
            end
            qRaw=build_koopman_isotypic_forcing(m.deviceType,xForPort, ...
                voltagePort(m.bus),refs,m.portParameters, ...
                struct('voltageDivisionFloor',m.voltageDivisionFloor));
            q=(qRaw(:)-m.forceMean(:))./m.forceStd(:);
            if numel(q)~=size(m.Bd,3)
                error('jiang_native_step:Qsize','Forcing size mismatch in %s%d.', ...
                    m.deviceType,m.deviceIndex);
            end
            zOld=baseZ{kk};
            if m.implicit
                Mmat=eye(size(m.Ad,1),'like',m.Ad);
                for iq=1:numel(q)
                    Mmat=Mmat-q(iq)*m.Bd(:,:,iq);
                end
                if rcond(Mmat)<opt.minImplicitRcond
                    error('jiang_native_step:IllConditionedImplicit', ...
                        'Implicit map ill-conditioned on %s%d, rcond=%.3g.', ...
                        m.deviceType,m.deviceIndex,rcond(Mmat));
                end
                zNew=Mmat\(m.Ad*zOld);
            else
                zNew=m.Ad*zOld;
                for iq=1:numel(q)
                    zNew=zNew+q(iq)*(m.Bd(:,:,iq)*zOld);
                end
            end
            % Observable-manifold correction: recover the real physical
            % states from the shared phase, then RE-LIFT from physical x
            % at the following step. No integration of unconstrained z.
            if any(~isfinite(zNew)) || abs(zNew(1))<opt.minPhaseObservable
                error('jiang_native_step:InvalidObservable', ...
                    'Invalid q=-1 phase observable on %s%d.',m.deviceType,m.deviceIndex);
            end
            phaseStep=angle(zNew(1)/zOld(1));
            if abs(phaseStep)>opt.maxPhaseStep
                error('jiang_native_step:PhaseJump', ...
                    'Phase jump %.4g rad on %s%d.',phaseStep,m.deviceType,m.deviceIndex);
            end
            Hnew=real(zNew(2:numel(ids))./zNew(1));
            xa(ids)=[xPrev(ids(1))+phaseStep;m.stateMean(:)+m.stateStd(:).*Hnew];
        end
    end
end

function [V,info]=voltage_newton(x,Vinitial,u,t,c,layout,opt)
% Sparsity-preserving network Newton solver. Device/load current at bus i
% depends on V_i only, so all local dI/dVr can be obtained by perturbing
% every non-slack V real-part simultaneously (and similarly for imaginary).
% This takes 3 physics port evaluations per Newton iteration, not 2N.
V=Vinitial(:);V(c.network.slackBus)=c.network.Vslack;
ns=c.network.nonSlackBuses(:); n=numel(ns);
Y=c.network.Ybus(ns,ns);
pNow=mg_parameter_profile(t,c);
info=struct('success',false,'iterations',0,'residualInf',inf,'message','');
for it=1:opt.maxVoltageIterations
    try
        [~,g,aux]=mg_evaluate_physics(x,V,u,pNow,c,layout);
    catch ME
        info.message=['Network port evaluation: ' ME.message];return
    end
    rv=norm(g,inf);info.residualInf=rv;info.iterations=it;
    if ~isfinite(rv),info.message='Nonfinite network residual.';return;end
    if rv<opt.voltageTolerance
        info.success=true;return
    end
    h=opt.derivativeStep*max(1,abs(V(ns)));
    Vre=V; Vim=V;
    Vre(ns)=V(ns)+h;
    Vim(ns)=V(ns)+1i*h;
    try
        [~,~,aRe]=mg_evaluate_physics(x,Vre,u,pNow,c,layout);
        [~,~,aIm]=mg_evaluate_physics(x,Vim,u,pNow,c,layout);
    catch ME
        info.message=['Port Jacobian evaluation: ' ME.message];return
    end
    dR=(aRe.IlocalInjection(ns)-aux.IlocalInjection(ns))./h;
    dI=(aIm.IlocalInjection(ns)-aux.IlocalInjection(ns))./h;
    jac=[real(Y)-spdiags(real(dR),0,n,n), -imag(Y)-spdiags(real(dI),0,n,n); ...
         imag(Y)-spdiags(imag(dR),0,n,n),  real(Y)-spdiags(imag(dI),0,n,n)];
    if any(~isfinite(nonzeros(jac)))
        info.message='Nonfinite network Jacobian.';return
    end
    try
        dx=jac\(-[real(g);imag(g)]);
    catch ME
        info.message=['Network Newton solve: ' ME.message];return
    end
    if any(~isfinite(dx))
        info.message='Nonfinite network Newton step.';return
    end
    step=dx(1:n)+1i*dx(n+1:end);
    accepted=false;
    for trial=0:opt.maxVoltageBacktracks
        fac=2^(-trial);
        VV=V;VV(ns)=V(ns)+fac*step;
        if any(abs(VV(ns))<opt.minVoltageMagnitude) || ...
                any(abs(VV(ns))>opt.maxVoltageMagnitude)
            continue
        end
        try
            [~,gt]=mg_evaluate_physics(x,VV,u,pNow,c,layout);
            err=norm(gt,inf);
        catch
            continue
        end
        if isfinite(err) && err<rv
            V=VV;accepted=true;break
        end
    end
    if ~accepted
        info.message=sprintf('No residual-decreasing Newton step at residual %.3g.',rv);
        return
    end
end
info.message=sprintf('Network residual %.3g after %d Newton iterations.', ...
    info.residualInf,opt.maxVoltageIterations);
end

function info=fill_info(info,net,it,change)
info.success=net.success;info.outerIterations=it;
info.voltageIterations=net.iterations;
info.voltageResidualInf=net.residualInf;
info.stepChangeInf=change;
info.message=net.message;
end

function opt=apply_defaults(opt)
defaults=struct('couplingMode','endpoint','maxCouplingIterations',16, ...
    'couplingTolerance',1e-6,'couplingRelaxation',0.6, ...
    'voltageTolerance',1e-8,'maxVoltageIterations',12, ...
    'maxVoltageBacktracks',10,'derivativeStep',1e-6, ...
    'minVoltageMagnitude',0.2,'maxVoltageMagnitude',2.0, ...
    'maxAbsState',1e4,'minImplicitRcond',1e-12, ...
    'minPhaseObservable',1e-10,'maxPhaseStep',2.5);
keys=fieldnames(defaults);
for i=1:numel(keys)
    if ~isfield(opt,keys{i}) || isempty(opt.(keys{i}))
        opt.(keys{i})=defaults.(keys{i});
    end
end
if ~any(strcmpi(char(opt.couplingMode),{'endpoint','lagged'}))
    error('jiang_native_step:Mode','couplingMode must be endpoint or lagged.');
end
end
