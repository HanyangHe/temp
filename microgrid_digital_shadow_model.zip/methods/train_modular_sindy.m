function [model,info] = train_modular_sindy(dataset,c,layout,cfg,variant)
%TRAIN_MODULAR_SINDY Common trainer for pointwise modular SINDy variants.
%
% All points from the multi-short-trajectory dataset are ordinary independent
% regression constraints [chi_k -> xdot_k]. Time ordering is NOT used by the
% regression. Complete trajectory IDs are retained only for a leakage-resistant
% train/validation split and to force the test-initial anchor into training.

opt = get_sindy_options(cfg);
requestedVariant = lower(string(variant));
if ~any(requestedVariant == ["vanilla","physics","priorweighted"])
    error('train_modular_sindy:Variant','Unknown SINDy variant "%s".',requestedVariant);
end

% Active pointwise SINDy variants:
%   vanilla       -> generic Poly3+sin/cos library only
%   physics       -> generic library + complete retained physics library
%   priorweighted -> the same physics library + weighted pruning
if requestedVariant == "priorweighted"
    libraryVariant = "physics";
    fitMode = "prior_weighted";
else
    libraryVariant = requestedVariant;
    fitMode = "standard";
end

K = dataset.trajectories.nTrajectories;
if K < 2
    error('train_modular_sindy:TooFewTrajectories','At least two trajectories are required.');
end

forcedTrainIds = [];
if isfield(dataset.trajectories,'forceTrainingMask') && ...
        ~isempty(dataset.trajectories.forceTrainingMask)
    m = logical(dataset.trajectories.forceTrainingMask(:));
    if numel(m) ~= K
        error('train_modular_sindy:ForceTrainingMaskSize', ...
            'forceTrainingMask must contain one entry per trajectory.');
    end
    forcedTrainIds = find(m).';
end

validationCandidates = setdiff(1:K,forcedTrainIds,'stable');
if isempty(validationCandidates)
    error('train_modular_sindy:NoValidationCandidates','No trajectory remains for validation.');
end
oldRng = rng;
cleanup = onCleanup(@()rng(oldRng)); %#ok<NASGU>
rng(opt.validationSeed,'twister');
perm = validationCandidates(randperm(numel(validationCandidates)));
nVal = max(1,round(opt.validationFraction*K));
nVal = min(nVal,numel(validationCandidates));
if nVal >= K, nVal = K-1; end
valIds = sort(perm(1:nVal));
trainIds = sort(setdiff(1:K,valIds,'stable'));
trainMask = ismember(dataset.trajectoryId,trainIds);
valMask = ismember(dataset.trajectoryId,valIds);

model.type = 'modular_sindy';
model.formulationVersion = char(opt.formulationVersion);
model.variant = char(requestedVariant);
model.libraryVariant = char(libraryVariant);
model.fitMode = char(fitMode);
model.trainingSampleDefinition = 'flattened pointwise samples from common short-trajectory dataset';
model.sg = struct([]); model.gfm = struct([]); model.gfl = struct([]);
model.trainTrajectoryIds = trainIds(:);
model.validationTrajectoryIds = valIds(:);
model.forcedTrainingTrajectoryIds = forcedTrainIds(:);
model.options = opt;

modules = struct([]);
mi = 0;
activeTotal = 0;
candidateTotal = 0;

for k = 1:numel(c.sg)
    fprintf('    Training %s SINDy module SG%d (Bus %d)...\n',variant_label(requestedVariant),k,c.sg(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'sg',k);
    [mk,ik] = fit_sindy_stlsq_module(data,trainMask,valMask,libraryVariant,opt,fitMode);
    if k==1, model.sg=mk; else, model.sg(k,1)=mk; end
    [modules,mi] = append_info(modules,mi,ik);
    activeTotal = activeTotal + ik.activeCoefficientCount;
    candidateTotal = candidateTotal + ik.candidateCoefficientCount;
end
for k = 1:numel(c.gfm)
    fprintf('    Training %s SINDy module GFM%d (Bus %d)...\n',variant_label(requestedVariant),k,c.gfm(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfm',k);
    [mk,ik] = fit_sindy_stlsq_module(data,trainMask,valMask,libraryVariant,opt,fitMode);
    if k==1, model.gfm=mk; else, model.gfm(k,1)=mk; end
    [modules,mi] = append_info(modules,mi,ik);
    activeTotal = activeTotal + ik.activeCoefficientCount;
    candidateTotal = candidateTotal + ik.candidateCoefficientCount;
end
for k = 1:numel(c.gfl)
    fprintf('    Training %s SINDy module GFL%d (Bus %d)...\n',variant_label(requestedVariant),k,c.gfl(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfl',k);
    [mk,ik] = fit_sindy_stlsq_module(data,trainMask,valMask,libraryVariant,opt,fitMode);
    if k==1, model.gfl=mk; else, model.gfl(k,1)=mk; end
    [modules,mi] = append_info(modules,mi,ik);
    activeTotal = activeTotal + ik.activeCoefficientCount;
    candidateTotal = candidateTotal + ik.candidateCoefficientCount;
end

model.activeCoefficientCount = activeTotal;
model.candidateCoefficientCount = candidateTotal;

% Embed a method-specific compatibility signature directly in every newly
% trained model so future offline replay and online replacement do not depend
% on a framework-wide version string.
compatMethodName = compatibility_method_name_local(requestedVariant);
[okCompatibility,compatibility] = check_sindy_model_compatibility( ...
    compatMethodName,model,cfg);
if ~okCompatibility
    error('train_modular_sindy:CompatibilityContract', ...
        ['Newly trained %s model violates its method contract:\n  - %s'], ...
        compatMethodName,strjoin(string(compatibility.issues),sprintf('\n  - ')));
end
model.compatibilitySchema = compatibility.schemaVersion;
model.compatibilitySignature = compatibility.actual;

info.method = char(requestedVariant + "_modular_sindy");
info.formulationVersion = char(opt.formulationVersion);
info.variant = char(requestedVariant);
info.libraryVariant = char(libraryVariant);
info.fitMode = char(fitMode);
info.objective = 'pointwise sparse vector-field regression (STLSQ)';
info.nSamples = size(dataset.x,1);
info.nTrajectories = K;
info.nTrainSamples = nnz(trainMask);
info.nValidationSamples = nnz(valMask);
info.nTrainTrajectories = numel(trainIds);
info.nValidationTrajectories = numel(valIds);
info.trainTrajectoryIds = trainIds(:);
info.validationTrajectoryIds = valIds(:);
info.forcedTrainingTrajectoryIds = forcedTrainIds(:);
info.polyOrderOption = opt.polyOrderOption;
info.modules = modules;
info.activeCoefficientCount = activeTotal;
info.candidateCoefficientCount = candidateTotal;
info.compatibilitySchema = compatibility.schemaVersion;
info.compatibilitySignature = compatibility.actual;

if ~isempty(forcedTrainIds) && opt.verbose
    fprintf('    Forced into SINDy training partition: trajectory ID(s) [%s]\n', ...
        strtrim(sprintf('%d ',forcedTrainIds)));
end
end

function [S,mi] = append_info(S,mi,ik)
mi = mi+1;
if mi==1, S=ik; else, S(mi,1)=ik; end
end

function name = compatibility_method_name_local(v)
switch char(v)
    case 'vanilla', name = 'vanilla_sindy';
    case 'physics', name = 'physics_embedded_sindy';
    case 'priorweighted', name = 'prior_weighted_sindy';
    otherwise
        error('train_modular_sindy:CompatibilityMethod','Unknown variant %s.',char(v));
end
end

function txt = variant_label(v)
switch char(v)
    case 'vanilla', txt = 'vanilla';
    case 'physics', txt = 'physics-embedded';
    case 'priorweighted', txt = 'prior-weighted';
    otherwise, txt = char(v);
end
end
