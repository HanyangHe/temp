function diagnostics = compute_node_diagnostics(model,trainInfo,dataset,truth,prediction,c,layout,cfg)
%COMPUTE_NODE_DIAGNOSTICS Diagnostics for the modular Neural ODE baseline.
%
% This diagnostic intentionally does NOT alter the trained model. It reports:
%   1) per-state short-trajectory validation errors on whole held-out
%      trajectories;
%   2) vector-field residual at the reference initial/equilibrium point;
%   3) a 10-s truth-forced terminal-input rollout, in which the learned DER
%      state evolves recursively but the terminal-voltage trajectory V(t) is
%      clamped to the TRUE reference trajectory. This isolates local DER-model
%      error from closed-loop network-feedback amplification.
%
% The third item is sometimes called "teacher forcing" in this project. More
% precisely, it is terminal-input teacher forcing: the NODE state itself is
% NOT reset to truth at every time step.

if nargin < 8
    error('compute_node_diagnostics:Inputs','Eight inputs are required.');
end

stateNamesAll = get_dae_variable_names(c,layout);
stateNamesAll = string(stateNamesAll(1:layout.nx));

diagnostics = struct();
diagnostics.schemaVersion = 'node_diagnostics_v1';
diagnostics.succeeded = true;
diagnostics.failureMessage = "";

%% 1) Per-state held-out short-trajectory validation diagnostics.
try
    [valPerState,valModules] = validation_diagnostics( ...
        model,trainInfo,dataset,c,layout,cfg,stateNamesAll);
    diagnostics.validationPerState = valPerState;
    diagnostics.validationModuleSummary = valModules;
    diagnostics.validationSucceeded = true;
    diagnostics.validationFailureMessage = "";
catch ME
    diagnostics.validationPerState = table();
    diagnostics.validationModuleSummary = table();
    diagnostics.validationSucceeded = false;
    diagnostics.validationFailureMessage = string(ME.message);
    diagnostics.succeeded = false;
end

%% 2) Reference initial/equilibrium vector-field residual.
try
    [eqPerState,eqModules,eqSummary] = equilibrium_diagnostics( ...
        model,truth,c,layout,stateNamesAll);
    diagnostics.equilibriumPerState = eqPerState;
    diagnostics.equilibriumModuleSummary = eqModules;
    diagnostics.equilibriumSummary = eqSummary;
    diagnostics.equilibriumSucceeded = true;
    diagnostics.equilibriumFailureMessage = "";
catch ME
    diagnostics.equilibriumPerState = table();
    diagnostics.equilibriumModuleSummary = table();
    diagnostics.equilibriumSummary = struct();
    diagnostics.equilibriumSucceeded = false;
    diagnostics.equilibriumFailureMessage = string(ME.message);
    diagnostics.succeeded = false;
end

%% 3) 10-s truth-forced terminal-input NODE rollout.
try
    tf = teacher_forced_diagnostics(model,truth,c,layout,cfg,stateNamesAll);
    diagnostics.teacherForced = tf;
    diagnostics.teacherForcedSucceeded = tf.succeeded;
    diagnostics.teacherForcedFailureMessage = tf.failureMessage;
    if ~tf.succeeded
        diagnostics.succeeded = false;
    end
catch ME
    diagnostics.teacherForced = empty_teacher_forced();
    diagnostics.teacherForced.succeeded = false;
    diagnostics.teacherForced.failureMessage = string(ME.message);
    diagnostics.teacherForcedSucceeded = false;
    diagnostics.teacherForcedFailureMessage = string(ME.message);
    diagnostics.succeeded = false;
end

%% Apples-to-apples state-only error for the ordinary closed-loop DAE rollout.
try
    diagnostics.closedLoopState = closed_loop_state_diagnostics( ...
        truth,prediction,stateNamesAll,cfg);
catch ME
    diagnostics.closedLoopState = struct('succeeded',false, ...
        'failureMessage',string(ME.message),'metrics',struct(), ...
        'perStateMetrics',table());
end

% A useful scalar diagnosis: values >>1 mean network feedback amplifies a
% model that is substantially better under true terminal-voltage forcing.
diagnostics.closedLoopToTeacherForcedRMSEratio = NaN;
if isfield(diagnostics,'teacherForced') && diagnostics.teacherForced.succeeded && ...
        isfield(diagnostics.teacherForced,'metrics') && ...
        isfield(diagnostics.teacherForced.metrics,'RMSE') && ...
        diagnostics.teacherForced.metrics.RMSE > 0 && ...
        diagnostics.closedLoopState.succeeded && ...
        isfield(diagnostics.closedLoopState.metrics,'RMSE')
    diagnostics.closedLoopToTeacherForcedRMSEratio = ...
        diagnostics.closedLoopState.metrics.RMSE / diagnostics.teacherForced.metrics.RMSE;
end

messages = strings(0,1);
if ~diagnostics.validationSucceeded
    messages(end+1) = "validation: " + diagnostics.validationFailureMessage; %#ok<AGROW>
end
if ~diagnostics.equilibriumSucceeded
    messages(end+1) = "equilibrium: " + diagnostics.equilibriumFailureMessage; %#ok<AGROW>
end
if ~diagnostics.teacherForcedSucceeded
    messages(end+1) = "truth-forced: " + diagnostics.teacherForcedFailureMessage; %#ok<AGROW>
end
if ~isempty(messages)
    diagnostics.failureMessage = strjoin(messages,' | ');
end
end

function [perState,moduleSummary] = validation_diagnostics( ...
    model,trainInfo,dataset,c,layout,cfg,stateNamesAll)
% Re-integrate the SELECTED best model on all held-out short trajectories.
% The reported clean error uses xClean even in a noisy-training experiment;
% the observed-target error additionally reports agreement with what the
% optimizer actually saw.

valIds = model.validationTrajectoryIds(:).';
if isempty(valIds)
    error('compute_node_diagnostics:NoValidationTrajectories', ...
        'The trained NODE model does not contain validation trajectory IDs.');
end

rows = cell(0,1);
moduleRows = cell(0,1);
for type = ["sg","gfm","gfl"]
    nDevice = numel(c.(char(type)));
    for k = 1:nDevice
        m = model.(char(type))(k);
        data = build_node_module_trajectory_data(dataset,c,layout,type,k);
        Xpred = integrate_short_trajectories(m,data,valIds,cfg);
        Xclean = data.xClean(:,valIds,:);
        Xobs = data.xObserved(:,valIds,:);

        % Match the actual NODE objective: the initial condition is supplied,
        % and loss is evaluated on t_1,...,t_{L-1}.
        predEval = Xpred(:,:,2:end);
        cleanEval = Xclean(:,:,2:end);
        obsEval = Xobs(:,:,2:end);
        Eclean = predEval-cleanEval;
        Eobs = predEval-obsEval;
        nState = size(Eclean,1);

        for j = 1:nState
            eC = reshape(Eclean(j,:,:),[],1);
            eO = reshape(Eobs(j,:,:),[],1);
            rmseC = sqrt(mean(eC.^2));
            maeC = mean(abs(eC));
            maxC = max(abs(eC));
            rmseNormClean = rmseC/m.stateStd(j);
            rmseNormObserved = sqrt(mean((eO/m.stateStd(j)).^2));
            r = table(type,k,stateNamesAll(m.stateIndices(j)),rmseC,maeC,maxC, ...
                rmseNormClean,rmseNormObserved, ...
                'VariableNames',{'DeviceType','DeviceIndex','StateName', ...
                'RMSE_Clean','MAE_Clean','MaxAE_Clean', ...
                'RMSE_NormalizedByTrainStd_Clean', ...
                'RMSE_NormalizedByTrainStd_Observed'});
            rows{end+1,1} = r; %#ok<AGROW>
        end

        cleanNormMSE = mean((Eclean./reshape(m.stateStd,[],1,1)).^2,'all');
        observedNormMSE = mean((Eobs./reshape(m.stateStd,[],1,1)).^2,'all');
        selectedLoss = selected_training_validation_loss(trainInfo,type,k);
        mr = table(type,k,m.bus,numel(valIds),cleanNormMSE,observedNormMSE,selectedLoss, ...
            'VariableNames',{'DeviceType','DeviceIndex','Bus', ...
            'ValidationTrajectories','CleanNormalizedTrajectoryMSE', ...
            'ObservedNormalizedTrajectoryMSE','SelectedTrainingValidationMSE'});
        moduleRows{end+1,1} = mr; %#ok<AGROW>
    end
end
perState = vertcat(rows{:});
moduleSummary = vertcat(moduleRows{:});
end

function Xpred = integrate_short_trajectories(m,data,ids,cfg)
tspan = double(data.t(:).');
XN = normalize_array(data.xObserved,m.stateMean,m.stateStd);
FN = normalize_array(data.forcing,m.forceMean,m.forceStd);
X0 = dlarray(single(XN(:,ids,1)));
forcingN = single(FN(:,ids,:));
Y = run_dlode45_numeric_module(m,tspan,X0,forcingN,cfg);
Yraw = double(gather(extractdata(Y)));
Yraw = reshape(Yraw,data.nState,numel(ids),numel(tspan)-1);
XpredN = zeros(data.nState,numel(ids),numel(tspan));
XpredN(:,:,1) = XN(:,ids,1);
XpredN(:,:,2:end) = Yraw;
Xpred = denormalize_array(XpredN,m.stateMean,m.stateStd);
end

function selectedLoss = selected_training_validation_loss(trainInfo,type,k)
selectedLoss = NaN;
if ~isstruct(trainInfo) || ~isfield(trainInfo,'modules') || isempty(trainInfo.modules)
    return;
end
for i = 1:numel(trainInfo.modules)
    q = trainInfo.modules(i);
    if string(q.deviceType)==string(type) && q.deviceIndex==k && ...
            isfield(q,'bestValidationTrajectoryMSE_normalized')
        selectedLoss = q.bestValidationTrajectoryMSE_normalized;
        return;
    end
end
end

function [perState,moduleSummary,summary] = equilibrium_diagnostics( ...
    model,truth,c,layout,stateNamesAll)
% The reference truth is initialized from the physical equilibrium solver.
% We nevertheless report the TRUE derivative too, so the diagnostic remains
% honest if a scenario has a tiny smooth-transition residue at t0.

y0 = truth.y(1,:).';
[x0,V0] = mg_unpack_dae_state(y0,c,layout);
u0 = mg_input_profile(truth.t(1),c);
fPred = predict_node_vector_field(model,truth.t(1),x0,V0,u0,c,layout);
[fTrue,~,~,~] = mg_system_equations(truth.t(1),x0,V0,c,layout);
fPred = fPred(:);
fTrue = fTrue(:);
err = fPred-fTrue;

rows = cell(0,1);
moduleRows = cell(0,1);
for type = ["sg","gfm","gfl"]
    nDevice = numel(c.(char(type)));
    for k = 1:nDevice
        m = model.(char(type))(k);
        idx = m.stateIndices(:);
        for j = 1:numel(idx)
            ii = idx(j);
            predNorm = fPred(ii)/m.stateStd(j);
            errNorm = err(ii)/m.stateStd(j);
            r = table(type,k,stateNamesAll(ii),fPred(ii),fTrue(ii), ...
                abs(fPred(ii)),abs(err(ii)),predNorm,errNorm, ...
                'VariableNames',{'DeviceType','DeviceIndex','StateName', ...
                'PredictedDerivative','TrueDerivative','AbsPredictedDerivative', ...
                'AbsErrorVsTruth','PredictedNormalizedDerivativePerSec', ...
                'ErrorNormalizedDerivativePerSec'});
            rows{end+1,1} = r; %#ok<AGROW>
        end
        predN = fPred(idx)./m.stateStd(:);
        trueN = fTrue(idx)./m.stateStd(:);
        errN = err(idx)./m.stateStd(:);
        mr = table(type,k,m.bus,norm(fPred(idx),inf),norm(fTrue(idx),inf), ...
            norm(err(idx),inf),sqrt(mean(err(idx).^2)), ...
            norm(predN,inf),norm(trueN,inf),norm(errN,inf), ...
            'VariableNames',{'DeviceType','DeviceIndex','Bus', ...
            'PredictedDerivativeInfNorm','TrueDerivativeInfNorm', ...
            'ErrorDerivativeInfNorm','ErrorDerivativeRMS', ...
            'PredictedNormalizedDerivativeInfNormPerSec', ...
            'TrueNormalizedDerivativeInfNormPerSec', ...
            'ErrorNormalizedDerivativeInfNormPerSec'});
        moduleRows{end+1,1} = mr; %#ok<AGROW>
    end
end
perState = vertcat(rows{:});
moduleSummary = vertcat(moduleRows{:});
summary = struct();
summary.referenceTime = truth.t(1);
summary.predictedDerivativeInfNorm = norm(fPred,inf);
summary.trueDerivativeInfNorm = norm(fTrue,inf);
summary.errorDerivativeInfNorm = norm(err,inf);
summary.errorDerivativeRMS = sqrt(mean(err.^2));
end

function tf = teacher_forced_diagnostics(model,truth,c,layout,cfg,stateNamesAll)
% Truth-forced TERMINAL INPUT rollout.
%
% The learned state x_hat(t) evolves recursively from its own previous value.
% Only V_terminal(t) is clamped to the true reference trajectory. Known control
% inputs/references u(t) are also the true commanded inputs, as they are in the
% ordinary closed-loop test. Therefore this diagnostic removes voltage/network
% feedback error without resetting the NODE state to truth.

tf = empty_teacher_forced();
tf.definition = [ ...
    "Learned NODE states evolve recursively; true terminal-voltage trajectories " + ...
    "and known commanded inputs are supplied as external forcing. States are not reset to truth." ...
    ];
tf.t = truth.t(:);
tf.x = nan(layout.nx,numel(truth.t));
statusRows = cell(0,1);
moduleRows = cell(0,1);
perRows = cell(0,1);
allSuccess = true;

for type = ["sg","gfm","gfl"]
    nDevice = numel(c.(char(type)));
    for k = 1:nDevice
        m = model.(char(type))(k);
        tStart = tic;
        success = true;
        msg = "";
        Xpred = nan(numel(m.stateIndices),numel(truth.t));
        try
            forcing = truth_module_forcing(truth,type,k,m.bus);
            Xpred = integrate_teacher_forced_module(m,truth.t, ...
                truth.x(m.stateIndices,1),forcing,cfg);
            tf.x(m.stateIndices,:) = Xpred;
        catch ME
            success = false;
            allSuccess = false;
            msg = string(ME.message);
        end
        solveTime = toc(tStart);
        statusRows{end+1,1} = table(type,k,m.bus,success,solveTime,msg, ...
            'VariableNames',{'DeviceType','DeviceIndex','Bus','Succeeded', ...
            'SolveTimeSec','FailureMessage'}); %#ok<AGROW>

        if success
            trueLocal = truth.x(m.stateIndices,:);
            [sumM,perM] = compute_trajectory_error_metrics( ...
                trueLocal.',Xpred.',stateNamesAll(m.stateIndices),cfg);
            trainStdNRMSE = sqrt(mean(((Xpred-trueLocal)./m.stateStd(:)).^2,'all'));
            moduleRows{end+1,1} = table(type,k,m.bus,sumM.RMSE,sumM.MAE,sumM.MaxAE, ...
                sumM.NRMSE_Range,sumM.NRMSE_RMS,sumM.NRMSE_Std, ...
                trainStdNRMSE,sumM.MeanR2, ...
                'VariableNames',{'DeviceType','DeviceIndex','Bus','RMSE','MAE','MaxAE', ...
                'NRMSE_Range','NRMSE_RMS','NRMSE_Std', ...
                'NRMSE_TrainStateStd','MeanR2'}); %#ok<AGROW>
            perM.DeviceType = repmat(type,height(perM),1);
            perM.DeviceIndex = repmat(k,height(perM),1);
            perM = movevars(perM,{'DeviceType','DeviceIndex'},'Before',1);
            perRows{end+1,1} = perM; %#ok<AGROW>
        else
            moduleRows{end+1,1} = table(type,k,m.bus,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN, ...
                'VariableNames',{'DeviceType','DeviceIndex','Bus','RMSE','MAE','MaxAE', ...
                'NRMSE_Range','NRMSE_RMS','NRMSE_Std', ...
                'NRMSE_TrainStateStd','MeanR2'}); %#ok<AGROW>
        end
    end
end

tf.moduleStatus = vertcat(statusRows{:});
tf.moduleSummary = vertcat(moduleRows{:});
if isempty(perRows)
    tf.perStateMetrics = table();
else
    tf.perStateMetrics = vertcat(perRows{:});
end

tf.succeeded = allSuccess;
if allSuccess
    [tf.metrics,tf.perStateMetricsAll] = compute_trajectory_error_metrics( ...
        truth.x.',tf.x.',stateNamesAll,cfg);
    tf.failureMessage = "";
else
    tf.metrics = nan_metric_summary();
    tf.perStateMetricsAll = table();
    failed = tf.moduleStatus(~tf.moduleStatus.Succeeded,:);
    if ~isempty(failed)
        tf.failureMessage = strjoin(failed.DeviceType + string(failed.DeviceIndex) + ...
            ": " + failed.FailureMessage,' | ');
    else
        tf.failureMessage = "One or more truth-forced modules failed.";
    end
end
end

function forcing = truth_module_forcing(truth,type,k,bus)
Vb = truth.V(bus,:);
switch char(type)
    case 'sg'
        if isfield(truth.inputs,'sgVref') && ~isempty(truth.inputs.sgVref)
            forcing = [real(Vb);imag(Vb);truth.inputs.sgPm(k,:);truth.inputs.sgVref(k,:)];
        else
            forcing = [real(Vb);imag(Vb);truth.inputs.sgPm(k,:)];
        end
    case 'gfm'
        forcing = [real(Vb);imag(Vb);truth.inputs.gfmPstar(k,:); ...
            truth.inputs.gfmQstar(k,:);truth.inputs.gfmEref(k,:)];
    case 'gfl'
        forcing = [real(Vb);imag(Vb);truth.inputs.gflPstar(k,:); ...
            truth.inputs.gflQstar(k,:)];
    otherwise
        error('compute_node_diagnostics:DeviceType','Unknown device type %s.',char(type));
end
forcing = reshape(forcing,size(forcing,1),1,size(forcing,2));
end

function Xpred = integrate_teacher_forced_module(m,t,x0,forcing,cfg)
tspan = double(t(:).');
forcingN = normalize_array(forcing,m.forceMean,m.forceStd);
s0 = (double(x0(:))-m.stateMean(:))./m.stateStd(:);
X0 = dlarray(single(s0));
Y = run_dlode45_numeric_module(m,tspan,X0,single(forcingN),cfg);
Yraw = double(gather(extractdata(Y)));
Yraw = reshape(Yraw,numel(s0),1,numel(tspan)-1);
SN = zeros(numel(s0),numel(tspan));
SN(:,1) = s0;
SN(:,2:end) = reshape(Yraw,numel(s0),numel(tspan)-1);
Xpred = m.stateMean(:) + m.stateStd(:).*SN;
end

function Y = run_dlode45_numeric_module(m,tspan,X0,forcingN,cfg)
theta.fc1.Weights = dlarray(single(m.numeric.W1));
theta.fc1.Bias = dlarray(single(m.numeric.b1));
theta.fc2.Weights = dlarray(single(m.numeric.W2));
theta.fc2.Bias = dlarray(single(m.numeric.b2));
theta.fcOut.Weights = dlarray(single(m.numeric.Wout));
theta.fcOut.Bias = dlarray(single(m.numeric.bout));
theta.Forcing = forcingN;
theta.T0 = double(tspan(1));
if numel(tspan) > 1
    theta.Dt = double(tspan(2)-tspan(1));
else
    theta.Dt = 1;
end
theta.NTimes = numel(tspan);
Y = dlode45(@node_controlled_rhs,tspan,X0,theta, ...
    DataFormat='CB',GradientMode='direct', ...
    RelativeTolerance=cfg.node.solver.RelativeTolerance, ...
    AbsoluteTolerance=cfg.node.solver.AbsoluteTolerance, ...
    MaxStepSize=cfg.node.solver.MaxStepSize);
end

function out = closed_loop_state_diagnostics(truth,prediction,stateNamesAll,cfg)
out = struct();
out.succeeded = false;
out.failureMessage = "";
out.metrics = struct();
out.perStateMetrics = table();
if ~isfield(prediction,'metadata') || ~prediction.metadata.rolloutSucceeded
    out.failureMessage = "Ordinary closed-loop rollout did not complete the requested horizon.";
    return;
end
if ~isfield(prediction,'x') || ~isequal(size(prediction.x),size(truth.x))
    out.failureMessage = "Closed-loop state trajectory size does not match truth.";
    return;
end
[out.metrics,out.perStateMetrics] = compute_trajectory_error_metrics( ...
    truth.x.',prediction.x.',stateNamesAll,cfg);
out.succeeded = true;
end

function A = normalize_array(A,mu,sigma)
A = (A-reshape(mu,[],1,1))./reshape(sigma,[],1,1);
end

function A = denormalize_array(A,mu,sigma)
A = A.*reshape(sigma,[],1,1)+reshape(mu,[],1,1);
end

function tf = empty_teacher_forced()
tf = struct();
tf.succeeded = false;
tf.failureMessage = "";
tf.definition = "";
tf.t = [];
tf.x = [];
tf.metrics = struct();
tf.perStateMetrics = table();
tf.perStateMetricsAll = table();
tf.moduleSummary = table();
tf.moduleStatus = table();
end

function m = nan_metric_summary()
names = {'RMSE','MAE','MaxAE','NRMSE_Range','NRMSE_RMS','NRMSE_Std', ...
    'NMaxAE_Range','MAPE_percent','sMAPE_percent','MAPE_valid_fraction','MeanR2'};
m = struct();
for k = 1:numel(names)
    m.(names{k}) = NaN;
end
end
