function [Theta,names,spec] = build_neural_sindy_library(X,inputNames,deviceType,mode,opt,seed,specIn)
%BUILD_NEURAL_SINDY_LIBRARY Compact neural candidate dictionaries.
%
% mode='neural'
%   Theta = [1, raw chi, fixed neural-ridge features]
%
% mode='physics_neural'
%   Theta = [1, raw chi, fixed neural-ridge features, physics features]
% A legacy 'prior_weighted_neural' mode is retained only for backward
% compatibility with historical saved models.
%
% A new neural bank is generated only when specIn is empty, using the rows X
% supplied by the TRAINING split. Validation/rollout reuse its stored weights.

if nargin < 7, specIn = []; end
mode = lower(string(mode));
if ~any(mode == ["neural","physics_neural","prior_weighted_neural"])
    error('build_neural_sindy_library:Mode','Unknown neural SINDy mode "%s".',mode);
end
inputNames = string(inputNames(:));
if size(X,2) ~= numel(inputNames)
    error('build_neural_sindy_library:Dimension', ...
        'X has %d columns but inputNames has %d.',size(X,2),numel(inputNames));
end

if isempty(specIn)
    [PhiNeu,neuSpec] = make_fixed_neural_ridge_basis( ...
        X,opt.neuralBasis.featureCount,opt.neuralBasis,seed,[]);
    spec = struct();
    spec.mode = char(mode);
    spec.inputNames = inputNames;
    spec.neural = neuSpec;
    spec.includePhysics = any(mode == ["physics_neural","prior_weighted_neural"]);

    if spec.includePhysics
        [Pphys,physNames,physSpec] = make_aligned_physics_local(X,inputNames,deviceType,opt);
        spec.physics = physSpec;
    else
        Pphys = zeros(size(X,1),0);
        physNames = strings(0,1);
        spec.physics = struct('mode','none','names',strings(0,1));
    end
else
    spec = specIn;
    [PhiNeu,~] = make_fixed_neural_ridge_basis( ...
        X,opt.neuralBasis.featureCount,opt.neuralBasis,seed,spec.neural);
    if logical(spec.includePhysics)
        [Pphys,physNames] = evaluate_aligned_physics_local(X,inputNames,deviceType,opt,spec.physics);
    else
        Pphys = zeros(size(X,1),0);
        physNames = strings(0,1);
    end
end

nNeu = size(PhiNeu,2);
neuNames = compose("neu_%03d",(1:nNeu).');
names = ["1"; inputNames; neuNames; string(physNames(:))];
Theta = [ones(size(X,1),1), X, PhiNeu, Pphys];

if numel(names) ~= size(Theta,2)
    error('build_neural_sindy_library:NameCount', ...
        'Library name count does not match numeric column count.');
end
if any(~isfinite(Theta),'all')
    error('build_neural_sindy_library:Nonfinite','Neural SINDy library contains nonfinite values.');
end
end

function [P,names,spec] = make_aligned_physics_local(X,inputNames,deviceType,opt)
% Use the Physics-embedded SINDy builder as the reference definition, then
% align the fast explicit evaluator to it. This keeps both methods matched.
[Tref,refNames,refSpec] = build_sindy_library( ...
    X,inputNames,deviceType,"physics",opt,[]);
refMask = startsWith(string(refNames(:)),"phys_");
Pref = Tref(:,refMask);
names = string(refNames(refMask));

[Pcustom,customNames] = build_neural_sindy_physics_features( ...
    X,inputNames,deviceType,opt);

spec = struct();
spec.names = names;
spec.referenceLibrarySpec = refSpec;
spec.referenceColumnIndices = find(refMask);
spec.customNames = string(customNames(:));
spec.mode = 'fast_aligned';
spec.customColumnIndices = zeros(numel(names),1);
spec.customColumnSigns = ones(numel(names),1);
spec.maxRelativeMismatch = NaN;

if isempty(Pref)
    P = zeros(size(X,1),0);
    return;
end

[map,sgn,maxMismatch,ok] = align_columns_local(Pref,Pcustom);
if ok
    spec.customColumnIndices = map(:);
    spec.customColumnSigns = sgn(:);
    spec.maxRelativeMismatch = maxMismatch;
    P = Pcustom(:,map).*reshape(sgn,1,[]);
else
    % Correctness-first fallback. This should not normally be used; it exists
    % only to preserve exact compatibility if an older/local physics library
    % uses a feature convention that differs from this update's fast formulas.
    warning('build_neural_sindy_library:PhysicsAlignmentFallback', ...
        ['Fast physics-feature alignment did not match the existing ', ...
         'Physics-embedded SINDy library (best max relative mismatch %.3e). ', ...
         'Physics-Neural SINDy will use the reference physics-library ', ...
         'subset directly during rollout.'],maxMismatch);
    spec.mode = 'reference_physics_library';
    spec.maxRelativeMismatch = maxMismatch;
    P = Pref;
end
end

function [P,names] = evaluate_aligned_physics_local(X,inputNames,deviceType,opt,spec)
names = string(spec.names(:));
switch lower(char(spec.mode))
    case 'fast_aligned'
        [Pcustom,~] = build_neural_sindy_physics_features( ...
            X,inputNames,deviceType,opt);
        idx = spec.customColumnIndices(:).';
        sgn = spec.customColumnSigns(:).';
        P = Pcustom(:,idx).*sgn;
    case 'reference_physics_library'
        [Tref,refNames] = build_sindy_library( ...
            X,inputNames,deviceType,"physics",opt,spec.referenceLibrarySpec);
        idx = spec.referenceColumnIndices(:).';
        if max(idx) > size(Tref,2)
            error('build_neural_sindy_library:ReferencePhysicsColumns', ...
                'Stored physics-library indices exceed the rebuilt library width.');
        end
        P = Tref(:,idx);
        rebuiltNames = string(refNames(idx));
        if numel(rebuiltNames) ~= numel(names) || any(rebuiltNames(:) ~= names(:))
            error('build_neural_sindy_library:ReferencePhysicsNames', ...
                'Physics-library term ordering changed since training.');
        end
    otherwise
        error('build_neural_sindy_library:PhysicsMode', ...
            'Unknown stored physics evaluation mode "%s".',char(spec.mode));
end
end

function [map,sgn,maxMismatch,ok] = align_columns_local(A,B)
% Match every reference column A to one column of B, allowing a sign flip.
na = size(A,2); nb = size(B,2);
map = zeros(1,na); sgn = ones(1,na);
used = false(1,nb);
maxMismatch = 0;
if na > nb
    maxMismatch = Inf; ok = false; return;
end
for ia = 1:na
    best = Inf; bestJ = 0; bestS = 1;
    denom = max(norm(A(:,ia)),1e-12);
    for jb = 1:nb
        if used(jb), continue; end
        ePlus = norm(A(:,ia)-B(:,jb))/denom;
        eMinus = norm(A(:,ia)+B(:,jb))/denom;
        if ePlus < best
            best=ePlus; bestJ=jb; bestS=1;
        end
        if eMinus < best
            best=eMinus; bestJ=jb; bestS=-1;
        end
    end
    if bestJ==0
        maxMismatch=Inf; ok=false; return;
    end
    map(ia)=bestJ; sgn(ia)=bestS; used(bestJ)=true;
    maxMismatch=max(maxMismatch,best);
end
ok = isfinite(maxMismatch) && maxMismatch <= 1e-8;
end
