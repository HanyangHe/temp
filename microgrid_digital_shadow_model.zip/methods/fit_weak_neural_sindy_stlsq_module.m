function [module,info] = fit_weak_neural_sindy_stlsq_module( ...
    data,trainIds,valIds,opt,seed)
%FIT_WEAK_NEURAL_SINDY_STLSQ_MODULE Fit one Weak PN-SINDy device module.
%
% The candidate dictionary is IDENTICAL to PN-SINDy:
%   [1, raw chi, fixed neural ridge features, explicit physics candidates].
% The distinction is only the identification form. Coefficients are fitted
% from compact-support weak integral constraints, so pointwise xdot labels are
% not used. The same official STLSQ solver and validation-based threshold
% selection policy are retained.

trainMask = ismember(data.trajectoryId,trainIds);
valMask = ismember(data.trajectoryId,valIds);
if ~any(trainMask) || ~any(valMask)
    error('fit_weak_neural_sindy_stlsq_module:EmptySplit', ...
        'Train and validation trajectories must both be nonempty.');
end

% Construct/select the fixed neural ridge bank from TRAINING samples only,
% exactly as in PN-SINDy. Then evaluate that frozen dictionary on all rows.
Xtr = data.X(trainMask,:);
[~,names,spec] = build_neural_sindy_library( ...
    Xtr,data.inputNames,data.deviceType,'physics_neural',opt,seed,[]);
[Theta,namesAll] = build_neural_sindy_library( ...
    data.X,data.inputNames,data.deviceType,'physics_neural',opt,seed,spec);
if numel(namesAll) ~= numel(names) || any(string(namesAll(:))~=string(names(:)))
    error('fit_weak_neural_sindy_stlsq_module:LibraryOrder', ...
        'Training and full weak-form neural libraries have inconsistent ordering.');
end

weakOpt = opt.weakPhysicsNeural;
[AtrRaw,BtrRaw,trainMeta] = build_weak_sindy_regression( ...
    data,Theta,trainIds,weakOpt);
[AvalRaw,BvalRaw,valMeta] = build_weak_sindy_regression( ...
    data,Theta,valIds,weakOpt);

colScale = sqrt(mean(AtrRaw.^2,1));
colScale = max(colScale,opt.normalization.libraryScaleFloor);
yScale = std(BtrRaw,0,1);
yRms = sqrt(mean(BtrRaw.^2,1));
yScale = max(yScale,0.05*yRms);
yScale = max(yScale,opt.normalization.outputScaleFloor);

Atr = AtrRaw./colScale;
Aval = AvalRaw./colScale;
Btr = BtrRaw./yScale;
Bval = BvalRaw./yScale;

physicsMask = startsWith(string(names(:)),"phys_");
lambdas = unique(sort(weakOpt.thresholdGrid(:)),'stable');
nL = numel(lambdas);
results = repmat(struct('lambda',NaN,'trainNormalizedMSE',NaN, ...
    'validationNormalizedMSE',NaN,'activeCoefficientCount',NaN, ...
    'activePhysicsCoefficientCount',NaN,'activeGenericCoefficientCount',NaN, ...
    'XiNormalized',[]),nL,1);

for il = 1:nL
    lambda = lambdas(il);
    Xi = sparsifyDynamics(Atr,Btr,lambda,size(Btr,2));
    trPred = Atr*Xi;
    vaPred = Aval*Xi;
    activeMask = abs(Xi)>0;
    physicsMask2 = repmat(physicsMask,1,size(Xi,2));

    results(il).lambda = lambda;
    results(il).trainNormalizedMSE = mean((trPred-Btr).^2,'all');
    results(il).validationNormalizedMSE = mean((vaPred-Bval).^2,'all');
    results(il).activeCoefficientCount = nnz(activeMask);
    results(il).activePhysicsCoefficientCount = nnz(activeMask & physicsMask2);
    results(il).activeGenericCoefficientCount = nnz(activeMask & ~physicsMask2);
    results(il).XiNormalized = Xi;
end

val = [results.validationNormalizedMSE].';
active = [results.activeCoefficientCount].';
bestVal = min(val);
tol = opt.stlsq.validationAbsoluteTolerance + ...
    opt.stlsq.preferSparseWithinRelativeValidationTolerance*max(bestVal,eps);
eligible = find(val <= bestVal + tol);
if isempty(eligible)
    [~,bestIdx] = min(val);
else
    bestActive = min(active(eligible));
    candidates = eligible(active(eligible)==bestActive);
    [~,loc] = min(val(candidates));
    bestIdx = candidates(loc);
end
best = results(bestIdx);
XiNorm = best.XiNormalized;

coef = (XiNorm./colScale(:)).*yScale;
coefActiveMask = abs(coef)>0;
physicsMask2 = repmat(physicsMask,1,size(coef,2));

module.type = 'modular_sindy_module';
module.formulationVersion = char(opt.formulationVersion);
module.dictionaryFamily = 'fixed_neural_ridge';
% Rollout uses the same PN dictionary evaluator.
module.variant = 'physics_neural';
module.fitMode = 'weak_physics_neural';
module.deviceType = char(data.deviceType);
module.deviceIndex = data.deviceIndex;
module.bus = data.bus;
module.stateIndices = data.stateIndices(:);
module.inputNames = string(data.inputNames(:));
module.outputNames = string(data.outputNames(:));
module.libraryNames = string(names(:));
module.librarySpec = spec;
module.coefficients = coef;
module.selectedThreshold = best.lambda;
module.stlsqSolver = 'official_brunton_2015';
module.stlsqIterations = 10;
module.stlsqRidge = 0;
module.libraryColumnScale = colScale(:);
module.outputScale = yScale(:);
module.activeCoefficientCount = nnz(coefActiveMask);
module.candidateCoefficientCount = numel(coef);
module.physicsPriorFeatureMask = physicsMask;
module.physicsPriorFeatureWeight = 1.0;
module.activePhysicsCoefficientCount = nnz(coefActiveMask & physicsMask2);
module.activeGenericCoefficientCount = nnz(coefActiveMask & ~physicsMask2);
module.neuralBasisFeatureCount = spec.neural.retainedCount;
module.neuralBasisSeed = seed;
module.weakTrainMeta = trainMeta;
module.weakValidationMeta = valMeta;
module.weakWindowPoints = weakOpt.windowPoints(:).';
module.weakWindowStride = weakOpt.windowStride;
module.weakTestFunctionPower = weakOpt.testFunctionPower;
module.weakThresholdGrid = weakOpt.thresholdGrid(:).';

sweepTable = table([results.lambda].',[results.trainNormalizedMSE].', ...
    [results.validationNormalizedMSE].',[results.activeCoefficientCount].', ...
    [results.activePhysicsCoefficientCount].',[results.activeGenericCoefficientCount].', ...
    'VariableNames',{'Threshold','TrainNormalizedMSE','ValidationNormalizedMSE', ...
    'ActiveCoefficientCount','ActivePhysicsCoefficientCount', ...
    'ActiveGenericCoefficientCount'});

info.formulationVersion = char(opt.formulationVersion);
info.deviceType = char(data.deviceType);
info.deviceIndex = data.deviceIndex;
info.bus = data.bus;
info.nTrainSamples = trainMeta.constraintCount;
info.nValidationSamples = valMeta.constraintCount;
info.libraryTermCount = size(AtrRaw,2);
info.neuralBasisFeatureCount = spec.neural.retainedCount;
info.outputCount = size(BtrRaw,2);
info.candidateCoefficientCount = numel(coef);
info.activeCoefficientCount = module.activeCoefficientCount;
info.selectedThreshold = best.lambda;
info.stlsqSolver = 'official_brunton_2015';
info.stlsqIterations = 10;
info.stlsqRidge = 0;
info.trainNormalizedMSE = best.trainNormalizedMSE;
info.validationNormalizedMSE = best.validationNormalizedMSE;
info.thresholdSweep = sweepTable;
info.fitMode = 'weak_physics_neural';
info.physicsPriorFeatureCount = nnz(physicsMask);
info.physicsPriorFeatureWeight = 1.0;
info.activePhysicsCoefficientCount = module.activePhysicsCoefficientCount;
info.activeGenericCoefficientCount = module.activeGenericCoefficientCount;
info.neuralBasisSeed = seed;
info.neuralCandidatePoolCount = spec.neural.actualCandidateCount;
info.weakTrainMeta = trainMeta;
info.weakValidationMeta = valMeta;
info.weakWindowPoints = weakOpt.windowPoints(:).';
info.weakWindowStride = weakOpt.windowStride;
info.weakTestFunctionPower = weakOpt.testFunctionPower;
info.weakThresholdGrid = weakOpt.thresholdGrid(:).';
info.derivativeLabelsUsed = false;
if isfield(spec,'physics') && isfield(spec.physics,'mode')
    info.physicsEvaluationMode = spec.physics.mode;
else
    info.physicsEvaluationMode = 'none';
end

if opt.verbose
    fprintf(['      %s%d | Weak PN-SINDy | library=%d (neural=%d, phys=%d) | ', ...
        'weak rows train/val=%d/%d | windows=[%s] | lambda=%.3g | ', ...
        'active=%d/%d | train nMSE=%.3e | val nMSE=%.3e\n'], ...
        upper(char(data.deviceType)),data.deviceIndex,info.libraryTermCount, ...
        info.neuralBasisFeatureCount,info.physicsPriorFeatureCount, ...
        info.nTrainSamples,info.nValidationSamples, ...
        strtrim(sprintf('%d ',weakOpt.windowPoints)),info.selectedThreshold, ...
        info.activeCoefficientCount,info.candidateCoefficientCount, ...
        info.trainNormalizedMSE,info.validationNormalizedMSE);
end
end
