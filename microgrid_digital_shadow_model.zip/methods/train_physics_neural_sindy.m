function [model,info] = train_physics_neural_sindy(dataset,c,layout,cfg)
%TRAIN_PHYSICS_NEURAL_SINDY Neural dictionary + physics candidates, unweighted STLSQ.
%
% PN-SINDy uses [raw chi + fixed neural ridge + explicit physics] as its
% candidate family. All outer coefficients are identified by ordinary STLSQ;
% no prior-weighted pruning is used in the final manuscript method.
[model,info] = train_modular_neural_sindy(dataset,c,layout,cfg,'physics_neural');
end
