function [model,info] = train_modular_weak_sindy(dataset,c,layout,cfg)
%TRAIN_MODULAR_WEAK_SINDY Train conventional Weak SINDy modules.
%
% Weak SINDy uses exactly the Vanilla-SINDy candidate representation
% (constant + Poly_p(raw chi) + sin/cos(raw chi)) and changes only the
% coefficient-identification form to compact-support weak integral equations.
% Pointwise derivative labels are not used.

opt = get_sindy_options(cfg);
if ~opt.weakSindy.enabled
    error('train_modular_weak_sindy:Disabled', ...
        'cfg.sindy.weakSindy.enabled must be true.');
end

K = dataset.trajectories.nTrajectories;
if K < 2
    error('train_modular_weak_sindy:TooFewTrajectories', ...
        'At least two trajectories are required.');
end

forcedTrainIds = [];
if isfield(dataset.trajectories,'forceTrainingMask') && ...
        ~isempty(dataset.trajectories.forceTrainingMask)
    m = logical(dataset.trajectories.forceTrainingMask(:));
    if numel(m) ~= K
        error('train_modular_weak_sindy:ForceTrainingMaskSize', ...
            'forceTrainingMask must contain one entry per trajectory.');
    end
    forcedTrainIds = find(m).';
end

validationCandidates = setdiff(1:K,forcedTrainIds,'stable');
if isempty(validationCandidates)
    error('train_modular_weak_sindy:NoValidationCandidates', ...
        'No trajectory remains for validation.');
end
oldRng = rng;
cleanup = onCleanup(@()rng(oldRng)); %#ok<NASGU>
rng(opt.validationSeed,'twister');
perm = validationCandidates(randperm(numel(validationCandidates)));
nVal = max(1,round(opt.validationFraction*K));
nVal = min(nVal,numel(validationCandidates));
if nVal >= K, nVal = K-1; end
valIds = sort(perm(1:nVal));
trainIds = sort(setdiff(1:K,valIds,'stable'));

model.type = 'modular_sindy';
model.formulationVersion = char(opt.formulationVersion);
model.method = 'Weak SINDy';
model.variant = 'weak_vanilla';
model.libraryVariant = 'vanilla';
model.fitMode = 'weak_vanilla';
model.trainingObjective = 'compact-support weak integral sparse regression';
model.trainingSampleDefinition = ...
    'complete short trajectories; no pointwise derivative labels';
model.sg = struct([]); model.gfm = struct([]); model.gfl = struct([]);
model.trainTrajectoryIds = trainIds(:);
model.validationTrajectoryIds = valIds(:);
model.forcedTrainingTrajectoryIds = forcedTrainIds(:);
model.options = opt;

modules = struct([]);
mi = 0;
activeTotal = 0;
candidateTotal = 0;

for k = 1:numel(c.sg)
    fprintf('    Training Weak SINDy module SG%d (Bus %d)...\n',k,c.sg(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'sg',k);
    [mk,ik] = fit_weak_sindy_stlsq_module(data,trainIds,valIds,opt);
    if k==1, model.sg=mk; else, model.sg(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    activeTotal = activeTotal + ik.activeCoefficientCount;
    candidateTotal = candidateTotal + ik.candidateCoefficientCount;
end
for k = 1:numel(c.gfm)
    fprintf('    Training Weak SINDy module GFM%d (Bus %d)...\n',k,c.gfm(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfm',k);
    [mk,ik] = fit_weak_sindy_stlsq_module(data,trainIds,valIds,opt);
    if k==1, model.gfm=mk; else, model.gfm(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    activeTotal = activeTotal + ik.activeCoefficientCount;
    candidateTotal = candidateTotal + ik.candidateCoefficientCount;
end
for k = 1:numel(c.gfl)
    fprintf('    Training Weak SINDy module GFL%d (Bus %d)...\n',k,c.gfl(k).bus);
    data = build_sindy_module_data(dataset,c,layout,'gfl',k);
    [mk,ik] = fit_weak_sindy_stlsq_module(data,trainIds,valIds,opt);
    if k==1, model.gfl=mk; else, model.gfl(k,1)=mk; end
    [modules,mi] = append_info_local(modules,mi,ik);
    activeTotal = activeTotal + ik.activeCoefficientCount;
    candidateTotal = candidateTotal + ik.candidateCoefficientCount;
end

model.activeCoefficientCount = activeTotal;
model.candidateCoefficientCount = candidateTotal;

[okCompatibility,compatibility] = check_sindy_model_compatibility( ...
    'weak_sindy',model,cfg);
if ~okCompatibility
    error('train_modular_weak_sindy:CompatibilityContract', ...
        ['Newly trained Weak SINDy model violates its method contract:\n  - %s'], ...
        strjoin(string(compatibility.issues),sprintf('\n  - ')));
end
model.compatibilitySchema = compatibility.schemaVersion;
model.compatibilitySignature = compatibility.actual;

info.method = 'weak_sindy';
info.displayName = 'Weak SINDy';
info.formulationVersion = char(opt.formulationVersion);
info.variant = 'weak_vanilla';
info.libraryVariant = 'vanilla';
info.fitMode = 'weak_vanilla';
info.objective = 'weak-form sparse vector-field regression (STLSQ)';
info.derivativeLabelsUsed = false;
info.nSamples = size(dataset.x,1);
info.nTrajectories = K;
info.nTrainTrajectories = numel(trainIds);
info.nValidationTrajectories = numel(valIds);
info.trainTrajectoryIds = trainIds(:);
info.validationTrajectoryIds = valIds(:);
info.forcedTrainingTrajectoryIds = forcedTrainIds(:);
info.polyOrderOption = opt.polyOrderOption;
info.modules = modules;
info.activeCoefficientCount = activeTotal;
info.candidateCoefficientCount = candidateTotal;
info.weakWindowPoints = opt.weakSindy.windowPoints;
info.weakWindowStride = opt.weakSindy.windowStride;
info.weakTestFunctionPower = opt.weakSindy.testFunctionPower;
info.weakThresholdGrid = opt.weakSindy.thresholdGrid;
info.compatibilitySchema = compatibility.schemaVersion;
info.compatibilitySignature = compatibility.actual;

if ~isempty(forcedTrainIds) && opt.verbose
    fprintf('    Forced into Weak SINDy training partition: trajectory ID(s) [%s]\n', ...
        strtrim(sprintf('%d ',forcedTrainIds)));
end
end

function [S,mi] = append_info_local(S,mi,ik)
mi = mi+1;
if mi==1, S=ik; else, S(mi,1)=ik; end
end
