function [model,info] = train_pnc_residualized_v3_sindy(dataset,c,layout,cfg)
%TRAIN_PNC_RESIDUALIZED_V3_SINDY Diagnostic residualized PNC-SINDy v3.
%
%   H = f_PE_hat(chi)
%   R = xdot - H
%   Theta_delta = [H, Theta_PN_flat(chi), Phi_comp(chi,H)]
%   xdot_hat = H + Theta_delta*DeltaXi_2
%
% PE and flat PN are inserted as exact parent candidates. This diagnostic is
% intentionally separate from the production PNC-v2 implementation.
[model,info] = train_modular_pnc_residualized_v3_sindy(dataset,c,layout,cfg);
end
