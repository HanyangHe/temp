function results = run_true_physical_system(projectRoot)
%RUN_TRUE_PHYSICAL_SYSTEM Solve the first reference microgrid DAE with ODE15I.
%
% results = run_true_physical_system()
% results = run_true_physical_system(projectRoot)

if nargin < 1 || isempty(projectRoot)
    projectRoot = fileparts(mfilename('fullpath'));
end
addpath(genpath(projectRoot));

c = case_grid_connected_10bus_true_physics();
layout = mg_build_state_layout(c);

fprintf('============================================================\n');
fprintf('Microgrid digital shadow: true physical DAE\n');
fprintf('Case: %s\n',c.name);
fprintf('DAE variables: nx=%d differential, %d algebraic voltage variables\n', ...
    layout.nx,layout.nvAlg);
fprintf('============================================================\n');

% Report the active topology, devices, operating events, and optional model
% drift before solving so the trajectory can be interpreted by the user.
print_reference_case_summary(c,projectRoot);

[y0,yp0,initInfo] = initialize_reference_equilibrium(c,layout);
fprintf('Initial equilibrium: fsolve exitflag = %d, ||F0||_inf = %.3e\n', ...
    initInfo.exitflag,initInfo.daeResidualInf);

residual = @(t,y,yp)mg_dae_residual(t,y,yp,c,layout);
tout = (c.sim.t0:c.sim.outputStep:c.sim.tf).';
if abs(tout(end)-c.sim.tf) > 10*eps(c.sim.tf)
    tout(end+1,1) = c.sim.tf;
end
opts = odeset('RelTol',c.sim.RelTol, ...
              'AbsTol',c.sim.AbsTol, ...
              'MaxStep',c.sim.MaxStep, ...
              'Stats','off');

tStart = tic;
[t,y] = ode15i(residual,tout,y0,yp0,opts);
solveTime = toc(tStart);

results = mg_postprocess_solution(t,y,c,layout);
results.metadata.solveTimeSeconds = solveTime;
results.metadata.initialization = initInfo;
results.metadata.caseData = c;

fprintf('ODE15I solve time: %.3f s\n',solveTime);
fprintf('Max algebraic residual over saved trajectory: %.3e\n', ...
    max(results.networkResidualInf));
fprintf('Voltage range: [%.4f, %.4f] pu\n', ...
    min(abs(results.V),[],'all'),max(abs(results.V),[],'all'));

plot_true_system_results(results,c);

if c.sim.saveResults
    outDir = fullfile(projectRoot,'outputs');
    if ~exist(outDir,'dir'), mkdir(outDir); end
    save(fullfile(outDir,'true_physical_system_10bus_ode15i.mat'),'results','-v7.3');
end
end
