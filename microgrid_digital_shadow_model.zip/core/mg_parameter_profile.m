function p = mg_parameter_profile(t,c)
%MG_PARAMETER_PROFILE Time-varying true physical-model parameters.
%
% The nominal parameter structures live in the case file (c.sg/c.gfm/c.gfl).
% c.drift optionally modifies one OR MORE devices of the same type and
% parameter while leaving the nominal case data unchanged. A device vector,
% e.g. c.drift.device=[2 1], applies the same configured schedule to each
% listed device. The first device is treated as the representative device by
% compact plotting/reporting code. The supported temporal profiles are:
%
%   legacy/default smooth step:
%       c.drift.profile = 'smooth_step' (or omit profile)
%       c.drift.time, c.drift.transition
%
%   linear ramp:
%       c.drift.profile = 'linear'
%       c.drift.time      = ramp start time
%       c.drift.endTime   = ramp end time
%       c.drift.value     = TOTAL endpoint change under the selected mode
%
%   constant mismatch from the beginning of the test:
%       c.drift.profile = 'constant'
%       a(t)=1 for the complete test window
%
%   piecewise-constant schedule:
%       c.drift.profile = 'piecewise_constant'
%       c.drift.times  = [t1 t2 ...] starting times of each level
%       c.drift.values = [v1 v2 ...] values under the selected mode
%       The level vi is active on [ti, t_{i+1}), and the final level stays
%       active through the end of the simulation.
%
% Drift modes retain their original meaning:
%   relative : p(end) = p0*(1 + value)
%   additive : p(end) = p0 + value
%   set        : p(end) = value
%   multiplier : p(end) = p0*value
%
% For a complex-valued parameter such as GFM Zout, an optional component
% selector can drift only its resistance or reactance:
%   c.drift.component = 'real' | 'imag' | 'all' (default 'all').
%
% This remains separate from mg_input_profile: operating-reference/load
% actions change inputs, while c.drift changes the true physical vector field.

p.sg = c.sg;
p.gfm = c.gfm;
p.gfl = c.gfl;

if ~isfield(c,'drift') || ~isfield(c.drift,'enabled') || ~c.drift.enabled
    return;
end

profile = "smooth_step";
if isfield(c.drift,'profile') && strlength(string(c.drift.profile)) > 0
    profile = lower(string(c.drift.profile));
end

piecewiseValue = [];
piecewiseBeforeFirst = false;
switch profile
    case {"smooth_step","step","legacy"}
        a = smooth_transition(t,c.drift.time,c.drift.transition);
    case {"constant","constant_from_start","fixed_mismatch"}
        a = 1;
    case {"linear","linear_ramp","ramp"}
        if ~isfield(c.drift,'endTime') || isempty(c.drift.endTime)
            error('mg_parameter_profile:LinearEndTime', ...
                'Linear drift requires c.drift.endTime.');
        end
        if c.drift.endTime <= c.drift.time
            error('mg_parameter_profile:LinearWindow', ...
                'Linear drift requires endTime > time.');
        end
        a = (t-c.drift.time)/(c.drift.endTime-c.drift.time);
        a = max(0,min(1,a));
    case {"piecewise_constant","piecewise","schedule"}
        if ~isfield(c.drift,'times') || ~isfield(c.drift,'values') || isempty(c.drift.times) || isempty(c.drift.values)
            error('mg_parameter_profile:PiecewiseSchedule', ...
                'Piecewise-constant drift requires c.drift.times and c.drift.values.');
        end
        times = c.drift.times(:);
        values = c.drift.values(:);
        if numel(times) ~= numel(values)
            error('mg_parameter_profile:PiecewiseLength', ...
                'Piecewise-constant drift requires equal-length times and values vectors.');
        end
        if any(diff(times) < 0)
            error('mg_parameter_profile:PiecewiseOrder', ...
                'Piecewise-constant drift times must be nondecreasing.');
        end
        idx = find(t >= times,1,'last');
        if isempty(idx)
            piecewiseBeforeFirst = true;
            piecewiseValue = NaN;
        else
            piecewiseValue = values(idx);
        end
        a = NaN;
    otherwise
        error('mg_parameter_profile:Profile', ...
            'Unsupported drift profile "%s". Use smooth_step, constant, linear, or piecewise_constant.',profile);
end

deviceType = lower(string(c.drift.deviceType));
deviceIndices = double(c.drift.device(:).');
fieldName = char(c.drift.parameter);

if ~isfield(p,char(deviceType))
    error('mg_parameter_profile:DeviceType', ...
        'Unsupported drift deviceType "%s". Use sg, gfm, or gfl.',deviceType);
end

arr = p.(char(deviceType));
if isempty(deviceIndices) || any(~isfinite(deviceIndices)) || ...
        any(deviceIndices < 1) || any(deviceIndices > numel(arr)) || ...
        any(fix(deviceIndices) ~= deviceIndices)
    error('mg_parameter_profile:DeviceIndex', ...
        'Drift device indices must be integers inside 1:%d for %s.', ...
        numel(arr),deviceType);
end
if numel(unique(deviceIndices)) ~= numel(deviceIndices)
    error('mg_parameter_profile:DuplicateDeviceIndex', ...
        'Drift device indices must be unique.');
end

component = "all";
if isfield(c.drift,'component') && strlength(string(c.drift.component)) > 0
    component = lower(string(c.drift.component));
end
modeString = lower(string(c.drift.mode));

for iDevice = 1:numel(deviceIndices)
    k = deviceIndices(iDevice);
    if ~isfield(arr(k),fieldName)
        error('mg_parameter_profile:ParameterName', ...
            'Parameter "%s" is not a field of %s device %d.',fieldName,deviceType,k);
    end

    p0full = arr(k).(fieldName);
    switch component
        case {"all","full"}
            p0 = p0full;
        case {"real","resistance","r"}
            p0 = real(p0full);
        case {"imag","reactance","x"}
            p0 = imag(p0full);
        otherwise
            error('mg_parameter_profile:Component', ...
                'Unsupported drift component "%s". Use all, real, or imag.',component);
    end

    if piecewiseBeforeFirst
        pChanged = p0;
    elseif ~isempty(piecewiseValue)
        switch modeString
            case "relative"
                pChanged = p0.*(1 + piecewiseValue);
            case "additive"
                pChanged = p0 + piecewiseValue;
            case "set"
                pChanged = piecewiseValue;
            case "multiplier"
                pChanged = p0.*piecewiseValue;
            otherwise
                error('mg_parameter_profile:Mode', ...
                    'Unsupported drift mode "%s". Use relative, additive, set, or multiplier.',c.drift.mode);
        end
    else
        switch modeString
            case "relative"
                pChanged = p0.*(1 + c.drift.value.*a);
            case "additive"
                pChanged = p0 + c.drift.value.*a;
            case "set"
                pChanged = p0 + (c.drift.value - p0).*a;
            case "multiplier"
                pChanged = p0.*(1 + (c.drift.value-1).*a);
            otherwise
                error('mg_parameter_profile:Mode', ...
                    'Unsupported drift mode "%s". Use relative, additive, set, or multiplier.',c.drift.mode);
        end
    end

    switch component
        case {"all","full"}
            pNow = pChanged;
        case {"real","resistance","r"}
            pNow = complex(pChanged,imag(p0full));
        case {"imag","reactance","x"}
            pNow = complex(real(p0full),pChanged);
    end

    arr(k).(fieldName) = pNow;
end
p.(char(deviceType)) = arr;
end

function a = smooth_transition(t,t0,tau)
if tau <= 0
    a = double(t >= t0);
else
    a = 0.5*(1 + tanh((t-t0)/tau));
end
end
