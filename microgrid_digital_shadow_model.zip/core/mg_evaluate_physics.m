function [f,g,aux] = mg_evaluate_physics(x,V,u,pNow,c,layout)
%MG_EVALUATE_PHYSICS Evaluate the physical DAE for explicit inputs/parameters.
%
% [f,g,aux] = mg_evaluate_physics(x,V,u,pNow,c,layout)
%
% This is the explicit-input backend shared by the time-domain truth model
% and the offline Sobol data generator. It avoids hiding arbitrary sampled
% inputs behind mg_input_profile(t,c).
%
% f : differential vector field, xdot = f(x,V,u;pNow)
% g : complex current-balance residual at NON-SLACK buses
%     g = (Y*V - I_local_injection)(nonSlack)
%
% Sign convention throughout the project:
%   positive current/power = injection INTO the electrical network.

f = zeros(layout.nx,1);
Ilocal = complex(zeros(c.network.N,1));

aux.sg = struct([]);
aux.gfm = struct([]);
aux.gfl = struct([]);

for k = 1:numel(c.sg)
    idx = layout.sg{k};
    uk.Pm = u.sgPm(k);
    b = c.sg(k).bus;
    if isfield(c.sg(k),'model') && strcmpi(string(c.sg(k).model),'salient_avr_5state')
        if ~isfield(u,'sgVref') || numel(u.sgVref) < k
            error('mg_evaluate_physics:MissingSGVref', ...
                'Salient SG+AVR requires u.sgVref(%d).',k);
        end
        uk.Vref = u.sgVref(k);
        [dx,I,ak] = sg_salient_avr_model(x(idx),V(b),uk,pNow.sg(k),c.base);
    else
        [dx,I,ak] = sg_classical_model(x(idx),V(b),uk,pNow.sg(k),c.base);
    end
    f(idx) = dx;
    Ilocal(b) = Ilocal(b) + I;
    ak.Iinj = I;
    ak.bus = b;
    if k == 1
        aux.sg = ak;
    else
        aux.sg(k,1) = ak;
    end
end

for k = 1:numel(c.gfm)
    idx = layout.gfm{k};
    uk.Pstar = u.gfmPstar(k);
    uk.Qstar = u.gfmQstar(k);
    uk.Eref = u.gfmEref(k);
    b = c.gfm(k).bus;
    [dx,I,ak] = gfm_droop_model(x(idx),V(b),uk,pNow.gfm(k),c.base);
    f(idx) = dx;
    Ilocal(b) = Ilocal(b) + I;
    ak.Iinj = I;
    ak.bus = b;
    if k == 1
        aux.gfm = ak;
    else
        aux.gfm(k,1) = ak;
    end
end

for k = 1:numel(c.gfl)
    idx = layout.gfl{k};
    uk.Pstar = u.gflPstar(k);
    uk.Qstar = u.gflQstar(k);
    b = c.gfl(k).bus;
    [dx,I,ak] = gfl_pll_current_model(x(idx),V(b),uk,pNow.gfl(k),c.base);
    f(idx) = dx;
    Ilocal(b) = Ilocal(b) + I;
    ak.Iinj = I;
    ak.bus = b;
    if k == 1
        aux.gfl = ak;
    else
        aux.gfl(k,1) = ak;
    end
end

% Constant-PQ load. Positive Sload is consumption, so the network-injection
% current is negative.
Iload = load_injection_current(V,u.Sload,1e-10);
Ilocal = Ilocal + Iload;

Inet = c.network.Ybus*V;
balance = Inet - Ilocal;
ns = c.network.nonSlackBuses;
g = balance(ns);

% Slack current closes KCL and is interpreted as external-grid injection.
Igrid = balance(c.network.slackBus);
Sgrid = V(c.network.slackBus)*conj(Igrid);

aux.IlocalInjection = Ilocal;
aux.IloadInjection = Iload;
aux.Inet = Inet;
aux.fullBalance = balance;
aux.grid.Iinj = Igrid;
aux.grid.Sinj = Sgrid;
aux.grid.Pe = real(Sgrid);
aux.grid.Qe = imag(Sgrid);
end
