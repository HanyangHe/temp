function results = mg_postprocess_solution(t,y,c,layout)
%MG_POSTPROCESS_SOLUTION Recover states, voltages, inputs, powers, currents.
%
% The exact truth-model vector field xdot=f(x,V,u) is stored for synthetic
% identification studies. Branch-current magnitudes are also stored so the
% offline comparison can report engineering-relevant current trajectories.

nt = numel(t);
N = c.network.N;
nLine = numel(c.network.line.from);
results.t = t(:);
results.y = y;
results.x = y(:,1:layout.nx).'; % nx x nt
results.z = y(:,layout.nx+1:end).'; % algebraic DAE variables, nvAlg x nt
results.xdot = zeros(layout.nx,nt);
results.V = complex(zeros(N,nt));
results.networkResidualInf = zeros(nt,1);
results.Sgrid = complex(zeros(nt,1));
results.SloadTotal = complex(zeros(nt,1));

results.line.from = c.network.line.from(:);
results.line.to = c.network.line.to(:);
results.line.I = complex(zeros(nLine,nt));
results.line.Iabs = zeros(nLine,nt);

results.sg.P = zeros(numel(c.sg),nt);
results.sg.Q = zeros(numel(c.sg),nt);
results.sg.fHz = zeros(numel(c.sg),nt);
results.sg.Pairgap = nan(numel(c.sg),nt);
results.sg.EqPrime = nan(numel(c.sg),nt);
results.sg.EdPrime = nan(numel(c.sg),nt);
results.sg.Efd = nan(numel(c.sg),nt);
results.sg.Vt = nan(numel(c.sg),nt);
results.gfm.P = zeros(numel(c.gfm),nt);
results.gfm.Q = zeros(numel(c.gfm),nt);
results.gfm.fHz = zeros(numel(c.gfm),nt);
results.gfl.P = zeros(numel(c.gfl),nt);
results.gfl.Q = zeros(numel(c.gfl),nt);
results.gfl.fHz = zeros(numel(c.gfl),nt);

results.inputs.sgPm = zeros(numel(c.sg),nt);
if isfield(c.input.nominal,'sgVref')
    results.inputs.sgVref = zeros(numel(c.sg),nt);
else
    results.inputs.sgVref = [];
end
results.inputs.gfmPstar = zeros(numel(c.gfm),nt);
results.inputs.gfmQstar = zeros(numel(c.gfm),nt);
results.inputs.gfmEref = zeros(numel(c.gfm),nt);
results.inputs.gflPstar = zeros(numel(c.gfl),nt);
results.inputs.gflQstar = zeros(numel(c.gfl),nt);
results.inputs.loadP = zeros(N,nt);
results.inputs.loadQ = zeros(N,nt);

results.parameters.driftEnabled = isfield(c,'drift') && ...
    isfield(c.drift,'enabled') && c.drift.enabled;
if results.parameters.driftEnabled
    driftDevices = double(c.drift.device(:).');
    results.parameters.driftDevices = driftDevices;
    results.parameters.driftDevice = driftDevices(1); % representative device
    results.parameters.driftDeviceType = c.drift.deviceType;
    results.parameters.driftParameter = c.drift.parameter;
    results.parameters.driftValues = complex(zeros(numel(driftDevices),nt));
    results.parameters.driftValue = complex(zeros(1,nt)); % representative profile
else
    results.parameters.driftDevices = [];
    results.parameters.driftDevice = [];
    results.parameters.driftValues = [];
    results.parameters.driftValue = [];
end

for kk = 1:nt
    [xk,Vk] = mg_unpack_dae_state(y(kk,:).',c,layout);
    [fk,g,aux,u] = mg_system_equations(t(kk),xk,Vk,c,layout);

    results.xdot(:,kk) = fk;
    results.V(:,kk) = Vk;
    results.networkResidualInf(kk) = norm(g,inf);
    results.Sgrid(kk) = aux.grid.Sinj;
    results.SloadTotal(kk) = sum(u.Sload);

    for ell = 1:nLine
        a = c.network.line.from(ell);
        b = c.network.line.to(ell);
        Iab = (Vk(a)-Vk(b))/c.network.line.zPu(ell);
        results.line.I(ell,kk) = Iab;
        results.line.Iabs(ell,kk) = abs(Iab);
    end

    results.inputs.sgPm(:,kk) = u.sgPm;
    if ~isempty(results.inputs.sgVref)
        results.inputs.sgVref(:,kk) = u.sgVref;
    end
    results.inputs.gfmPstar(:,kk) = u.gfmPstar;
    results.inputs.gfmQstar(:,kk) = u.gfmQstar;
    results.inputs.gfmEref(:,kk) = u.gfmEref;
    results.inputs.gflPstar(:,kk) = u.gflPstar;
    results.inputs.gflQstar(:,kk) = u.gflQstar;
    results.inputs.loadP(:,kk) = real(u.Sload);
    results.inputs.loadQ(:,kk) = imag(u.Sload);

    for jj = 1:numel(c.sg)
        results.sg.P(jj,kk) = aux.sg(jj).Pe;
        results.sg.Q(jj,kk) = aux.sg(jj).Qe;
        results.sg.fHz(jj,kk) = aux.sg(jj).fHz;
        if isfield(aux.sg(jj),'Pairgap'), results.sg.Pairgap(jj,kk) = aux.sg(jj).Pairgap; end
        if isfield(aux.sg(jj),'EqPrime'), results.sg.EqPrime(jj,kk) = aux.sg(jj).EqPrime; end
        if isfield(aux.sg(jj),'EdPrime'), results.sg.EdPrime(jj,kk) = aux.sg(jj).EdPrime; end
        if isfield(aux.sg(jj),'Efd'), results.sg.Efd(jj,kk) = aux.sg(jj).Efd; end
        if isfield(aux.sg(jj),'Vt'), results.sg.Vt(jj,kk) = aux.sg(jj).Vt; end
    end
    for jj = 1:numel(c.gfm)
        results.gfm.P(jj,kk) = aux.gfm(jj).Pe;
        results.gfm.Q(jj,kk) = aux.gfm(jj).Qe;
        results.gfm.fHz(jj,kk) = aux.gfm(jj).fHz;
    end
    for jj = 1:numel(c.gfl)
        results.gfl.P(jj,kk) = aux.gfl(jj).Pe;
        results.gfl.Q(jj,kk) = aux.gfl(jj).Qe;
        results.gfl.fHz(jj,kk) = aux.gfl(jj).fHz;
    end

    if results.parameters.driftEnabled
        pNow = mg_parameter_profile(t(kk),c);
        type = lower(char(c.drift.deviceType));
        field = char(c.drift.parameter);
        for iDrift = 1:numel(results.parameters.driftDevices)
            dev = results.parameters.driftDevices(iDrift);
            results.parameters.driftValues(iDrift,kk) = pNow.(type)(dev).(field);
        end
        results.parameters.driftValue(kk) = results.parameters.driftValues(1,kk);
    end
end

results.metadata.caseName = c.name;
results.metadata.referenceNotes = c.referenceNotes;
results.metadata.stateLayout = layout;
if isfield(c,'scenario')
    results.metadata.scenario = c.scenario;
end
end
