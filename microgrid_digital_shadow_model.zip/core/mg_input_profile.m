function u = mg_input_profile(t,c)
%MG_INPUT_PROFILE Time-varying physical inputs/references for the truth model.
%
% Grouped action-sequence interface
% ---------------------------------
% Load group:
%   .bus        = arbitrary-length target-bus vector
%   .time       = N action times
%   .fraction   = N incremental relative changes to nominal complex load
%   .transition = scalar or N transition widths
%
% DER-reference group:
%   .device     = arbitrary-length target-device vector
%   .time       = N action times
%   .delta      = N additive reference increments in pu
%   .transition = scalar or N transition widths
%
% Every target in one group executes the SAME action sequence. Different
% groups can use independent sequences. Explicit enabled=false disables the
% whole section. The legacy v1 load and GFL-P flat formats remain supported.

u = c.input.nominal;

%% Constant-PQ load action sequences
if disturbance_enabled(c,'load')
    s = c.dist.load;
    if isfield(s,'group') && ~isempty(s.group)
        for r = 1:numel(s.group)
            grp = s.group(r);
            require_fields(grp,{'bus','time','fraction','transition'}, ...
                sprintf('c.dist.load.group(%d)',r));

            buses = validate_indices(grp.bus,c.network.N, ...
                sprintf('c.dist.load.group(%d).bus',r));
            times = column_vector(grp.time);
            fracs = column_vector(grp.fraction);
            validate_sequence_lengths(times,fracs, ...
                sprintf('c.dist.load.group(%d)',r),'fraction');
            tau = expand_transition(grp.transition,numel(times), ...
                sprintf('c.dist.load.group(%d).transition',r));

            a = smooth_transition_vector(t,times,tau);
            totalFraction = sum(fracs .* a);

            % P and Q move together because Sload is scaled as one complex
            % constant-PQ load, preserving the nominal load power factor.
            u.Sload(buses) = u.Sload(buses) + ...
                c.input.nominal.Sload(buses) .* totalFraction;
        end
    else
        % Legacy v1 flat format.
        require_fields(s,{'bus','time','fraction','transition'},'c.dist.load');
        buses = validate_indices(s.bus,c.network.N,'c.dist.load.bus');
        a = smooth_transition_scalar(t,s.time,s.transition);
        u.Sload(buses) = c.input.nominal.Sload(buses) .* (1 + s.fraction*a);
    end
end

%% SG mechanical-power and AVR-reference command sequences
u.sgPm = apply_additive_reference_groups( ...
    t,c,'sgPm',u.sgPm,numel(c.sg),'SG Pm');
if isfield(u,'sgVref')
    u.sgVref = apply_additive_reference_groups( ...
        t,c,'sgVref',u.sgVref,numel(c.sg),'SG Vref');
end

%% GFM reference sequences
u.gfmPstar = apply_additive_reference_groups( ...
    t,c,'gfmP',u.gfmPstar,numel(c.gfm),'GFM Pstar');
u.gfmQstar = apply_additive_reference_groups( ...
    t,c,'gfmQ',u.gfmQstar,numel(c.gfm),'GFM Qstar');
u.gfmEref = apply_additive_reference_groups( ...
    t,c,'gfmEref',u.gfmEref,numel(c.gfm),'GFM Eref');

%% GFL reference sequences
% Keep legacy v1 flat GFL-P compatibility; grouped format is preferred.
u.gflPstar = apply_additive_reference_groups( ...
    t,c,'gflP',u.gflPstar,numel(c.gfl),'GFL Pstar',true);
u.gflQstar = apply_additive_reference_groups( ...
    t,c,'gflQ',u.gflQstar,numel(c.gfl),'GFL Qstar');
end

function values = apply_additive_reference_groups(t,c,sectionName,values,nDevices,label,varargin)
% Apply grouped additive reference increments to one DER input vector.
allowLegacy = false;
if nargin >= 7 && ~isempty(varargin)
    allowLegacy = logical(varargin{1});
end

if ~disturbance_enabled(c,sectionName)
    return;
end

s = c.dist.(sectionName);
if isfield(s,'group') && ~isempty(s.group)
    for r = 1:numel(s.group)
        grp = s.group(r);
        require_fields(grp,{'device','time','delta','transition'}, ...
            sprintf('c.dist.%s.group(%d)',sectionName,r));

        devices = validate_indices(grp.device,nDevices, ...
            sprintf('c.dist.%s.group(%d).device',sectionName,r));
        times = column_vector(grp.time);
        deltas = column_vector(grp.delta);
        validate_sequence_lengths(times,deltas, ...
            sprintf('c.dist.%s.group(%d)',sectionName,r),'delta');
        tau = expand_transition(grp.transition,numel(times), ...
            sprintf('c.dist.%s.group(%d).transition',sectionName,r));

        a = smooth_transition_vector(t,times,tau);
        totalDelta = sum(deltas .* a);
        values(devices) = values(devices) + totalDelta;
    end
elseif allowLegacy
    % Legacy v1 GFL-P flat format.
    require_fields(s,{'device','time','delta','transition'}, ...
        sprintf('c.dist.%s',sectionName));
    devices = validate_indices(s.device,nDevices, ...
        sprintf('c.dist.%s.device',sectionName));
    a = smooth_transition_scalar(t,s.time,s.transition);
    values(devices) = values(devices) + s.delta*a;
else
    error('mg_input_profile:MissingGroup', ...
        '%s is enabled but c.dist.%s.group is empty or missing.',label,sectionName);
end
end

function tf = disturbance_enabled(c,name)
% Robust master-switch logic. Explicit enabled=false always wins.
tf = false;
if ~isfield(c,'dist') || ~isfield(c.dist,name)
    return;
end
s = c.dist.(name);
if isfield(s,'enabled')
    if isempty(s.enabled)
        tf = false;
    elseif ~isscalar(s.enabled)
        error('mg_input_profile:EnabledMustBeScalar', ...
            'c.dist.%s.enabled must be a scalar logical/numeric value.',name);
    else
        tf = logical(s.enabled);
    end
elseif isfield(s,'group') && ~isempty(s.group)
    tf = true;
else
    % Legacy flat sections without .enabled.
    switch lower(name)
        case 'load'
            tf = all(isfield(s,{'bus','time','fraction','transition'}));
        case 'gflp'
            tf = all(isfield(s,{'device','time','delta','transition'}));
    end
end
end

function validate_sequence_lengths(times,values,label,valueField)
if numel(times) ~= numel(values)
    error('mg_input_profile:SequenceLength', ...
        '%s.time and .%s must have the same number of elements.',label,valueField);
end
if isempty(times)
    error('mg_input_profile:EmptySequence','%s action sequence cannot be empty.',label);
end
if any(~isfinite(times)) || any(~isfinite(values))
    error('mg_input_profile:NonfiniteSequence', ...
        '%s time/action values must be finite.',label);
end
end

function require_fields(s,names,label)
for k = 1:numel(names)
    if ~isfield(s,names{k})
        error('mg_input_profile:MissingField', ...
            '%s is missing required field "%s".',label,names{k});
    end
end
end

function v = column_vector(v)
v = v(:);
end

function idx = validate_indices(idx,nMax,label)
idx = idx(:);
if isempty(idx)
    error('mg_input_profile:EmptyTarget','%s cannot be empty.',label);
end
if any(~isfinite(idx)) || any(idx ~= round(idx)) || any(idx < 1) || any(idx > nMax)
    error('mg_input_profile:InvalidTarget', ...
        '%s must contain integer indices inside 1:%d. Current value: [%s].', ...
        label,nMax,strtrim(sprintf('%g ',idx)));
end
end

function tau = expand_transition(tau,n,label)
if isscalar(tau)
    tau = repmat(tau,n,1);
else
    tau = tau(:);
    if numel(tau) ~= n
        error('mg_input_profile:TransitionLength', ...
            '%s must be scalar or have the same length as the action sequence.',label);
    end
end
if any(~isfinite(tau)) || any(tau < 0)
    error('mg_input_profile:TransitionValue','%s must be finite and nonnegative.',label);
end
end

function a = smooth_transition_vector(t,t0,tau)
t0 = t0(:);
tau = tau(:);
a = zeros(size(t0));
instant = (tau <= 0);
a(instant) = double(t >= t0(instant));
smooth = ~instant;
a(smooth) = 0.5*(1 + tanh((t-t0(smooth))./tau(smooth)));
end

function a = smooth_transition_scalar(t,t0,tau)
if tau <= 0
    a = double(t >= t0);
else
    a = 0.5*(1 + tanh((t-t0)/tau));
end
end
