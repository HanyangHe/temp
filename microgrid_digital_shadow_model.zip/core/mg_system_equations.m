function [f,g,aux,u] = mg_system_equations(t,x,V,c,layout)
%MG_SYSTEM_EQUATIONS Evaluate the time-driven physical DAE.
%
% The time profile is kept separate from the explicit physics evaluator so
% the offline experiment can sample arbitrary physically admissible (x,z,u)
% points without pretending that every sample lies on one time trajectory.

u = mg_input_profile(t,c);
pNow = mg_parameter_profile(t,c);
[f,g,aux] = mg_evaluate_physics(x,V,u,pNow,c,layout);
end
