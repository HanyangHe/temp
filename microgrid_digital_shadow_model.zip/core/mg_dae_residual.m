function F = mg_dae_residual(t,y,yp,c,layout)
%MG_DAE_RESIDUAL Fully implicit residual supplied to ODE15I.
%
% y  = [x; Re(V_nonSlack); Im(V_nonSlack)]
% yp = time derivative candidate supplied internally by ODE15I.
%
% Residual:
%   [ xdot - f(x,V,u) ; Re(g(x,V,u)) ; Im(g(x,V,u)) ] = 0

[x,V] = mg_unpack_dae_state(y,c,layout);
xdot = yp(1:layout.nx);
[f,g] = mg_system_equations(t,x,V,c,layout);
F = [xdot - f; real(g); imag(g)];
end
