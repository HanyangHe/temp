function T = verify_official_llm_prior_level_ablation_setup(projectRoot)
if nargin < 1 || isempty(projectRoot), projectRoot = pwd; end
checks = strings(0,1); pass = false(0,1); details = strings(0,1);

f1 = fullfile(projectRoot,'utils','plot_llm_prior_level_ablation.m');
f2 = fullfile(projectRoot,'tools','rebuild_official_llm_prior_level_ablation_figure.m');

checks(end+1,1) = "Plotter exists";
pass(end+1,1) = exist(f1,'file')==2;
details(end+1,1) = string(f1);

checks(end+1,1) = "Rebuild helper exists";
pass(end+1,1) = exist(f2,'file')==2;
details(end+1,1) = string(f2);

if exist(f1,'file')==2
    txt = fileread(f1);
    checks(end+1,1) = "Correct tiledlayout handle usage";
    pass(end+1,1) = contains(txt,'nexttile(tl,1)') && contains(txt,'nexttile(tl,2)');
    details(end+1,1) = "nexttile uses tl, not figure handle";

    checks(end+1,1) = "Two-panel compact layout";
    pass(end+1,1) = contains(txt,"tiledlayout(fig,1,2");
    details(end+1,1) = "(a) log10 RMSE, (b) sparsity";

    checks(end+1,1) = "No legend / no subplot title";
    pass(end+1,1) = ~contains(lower(txt),'legend(') && ~contains(lower(txt),'title(');
    details(end+1,1) = "panel labels only";

    checks(end+1,1) = "Both panels include error bars";
    pass(end+1,1) = count(lower(txt),'errorbar(')>=2;
    details(end+1,1) = "LLM variability shown in RMSE and sparsity";
end

T = table(checks,pass,details,'VariableNames',{'Check','Pass','Details'});
disp(T);
if all(pass)
    fprintf('\nOfficial LLM prior-level figure setup verification PASSED.\n');
else
    fprintf('\nOfficial LLM prior-level figure setup has FAILED checks.\n');
end
end
