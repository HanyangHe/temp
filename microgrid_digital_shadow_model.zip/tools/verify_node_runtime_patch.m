function T = verify_node_runtime_patch(projectRoot)
%VERIFY_NODE_RUNTIME_PATCH Zero-cost verification of the NODE runtime patch.
%
% Usage from the project root:
%   T = verify_node_runtime_patch(pwd);
%
% No dataset generation, training, rollout, or saved-result modification is
% performed. This only checks the three offline configs and required files.

if nargin < 1 || isempty(projectRoot)
    projectRoot = fileparts(fileparts(mfilename('fullpath')));
end
projectRoot = char(string(projectRoot));
addpath(genpath(projectRoot));

cfgFcns = {@config_offline_experiment_10bus, ...
    @config_offline_experiment_69bus, ...
    @config_offline_experiment_123bus};
caseName = ["10bus";"69bus";"123bus"];
n = numel(cfgFcns);

PointsPerTrajectory = nan(n,1);
TrainingWindowPoints = nan(n,1);
WindowsPerTrajectory = nan(n,1);
MaxEpochs = nan(n,1);
ValidationFrequency = nan(n,1);
PatienceChecks = nan(n,1);
MinRelativeImprovement = nan(n,1);
CompactInMemory = false(n,1);

for i = 1:n
    cfg = cfgFcns{i}();
    PointsPerTrajectory(i) = cfg.data.pointsPerTrajectory;
    TrainingWindowPoints(i) = cfg.node.trainingWindowPoints;
    WindowsPerTrajectory(i) = PointsPerTrajectory(i)/TrainingWindowPoints(i);
    MaxEpochs(i) = cfg.node.maxEpochs;
    ValidationFrequency(i) = cfg.node.validationFrequencyEpochs;
    PatienceChecks(i) = cfg.node.validationPatienceChecks;
    MinRelativeImprovement(i) = cfg.node.earlyStopping.minRelativeImprovement;
    CompactInMemory(i) = logical(cfg.node.compactInMemoryEvaluations);

    assert(mod(PointsPerTrajectory(i),TrainingWindowPoints(i))==0, ...
        '%s NODE training windows do not tile the formal trajectory.',caseName(i));
    assert(MaxEpochs(i)==500,'%s NODE maxEpochs is not 500.',caseName(i));
    assert(abs(MinRelativeImprovement(i)-0.002)<1e-12, ...
        '%s NODE meaningful-improvement threshold is not 0.002.',caseName(i));
    assert(CompactInMemory(i), ...
        '%s NODE in-memory compaction is not enabled.',caseName(i));
end

required = { ...
    fullfile(projectRoot,'methods','train_node_module.m'), ...
    fullfile(projectRoot,'methods','train_node_vector_field.m'), ...
    fullfile(projectRoot,'utils','compact_offline_evaluation_for_memory.m'), ...
    fullfile(projectRoot,'utils','save_offline_method_replay_bundles.m'), ...
    fullfile(projectRoot,'experiments','get_or_train_offline_evaluation_cached.m')};
for i = 1:numel(required)
    assert(exist(required{i},'file')==2,'Required patch file missing: %s',required{i});
end

T = table(caseName,PointsPerTrajectory,TrainingWindowPoints, ...
    WindowsPerTrajectory,MaxEpochs,ValidationFrequency,PatienceChecks, ...
    MinRelativeImprovement,CompactInMemory);

disp(T);
fprintf(['NODE runtime patch configuration check PASSED.\n', ...
    'This verification performed no training or rollout.\n']);
end
