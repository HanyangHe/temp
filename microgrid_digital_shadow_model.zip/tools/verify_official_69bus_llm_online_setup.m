function T=verify_official_69bus_llm_online_setup(projectRoot)
%VERIFY_OFFICIAL_69BUS_LLM_ONLINE_SETUP Verify final official 69-bus online protocol.
if nargin<1 || isempty(projectRoot), projectRoot=pwd; end
checks=strings(0,1); pass=false(0,1); details=strings(0,1);

cfg=config_online_experiment_69bus();
add('Output folder restored',strcmp(cfg.output.folderName,'online_model_experiments_69bus'),cfg.output.folderName);
add('Clean offline initial model',abs(cfg.online.initialModelNoiseLevel)<eps,'N=500, noise=0%');
add('Online observation noise 0.1%',abs(cfg.online.observationNoiseLevel-0.001)<eps,'xdot noise=0.1%');
add('LLM-Prior official method enabled',isfield(cfg.online.methods,'llmPriorSINDy') && cfg.online.methods.llmPriorSINDy.frozen && cfg.online.methods.llmPriorSINDy.online,'LLM-Prior frozen+online');
add('Old PNC official method disabled',~cfg.online.methods.physicsNeuralCompositionalSINDy.frozen && ~cfg.online.methods.physicsNeuralCompositionalSINDy.online,'PNC disabled');
add('Held-out trajectory calibration enabled',isfield(cfg.online.update.detector,'trajectoryCalibrationEnabled') && cfg.online.update.detector.trajectoryCalibrationEnabled,'q0.995 x 1.10');
add('Single GFM1 nq mismatch',strcmpi(cfg.online.parameterMismatch.deviceType,'gfm') && isequal(cfg.online.parameterMismatch.device,1) && strcmpi(cfg.online.parameterMismatch.parameter,'nq'),'GFM1 nq');

f=fullfile(projectRoot,'utils','plot_online_manuscript_summary.m');
if exist(f,'file')==2
    txt=fileread(f);
    add('Manuscript plot uses 4 rows',contains(txt,'tiledlayout(4,1'), 'original 3 rows + RMSE row');
    add('Figure height is exactly 4/3',contains(txt,"pos(4)=round(pos(4)*4/3)"),'width unchanged');
    add('Fourth-row y label is RMSE',contains(txt,"ylabel(ax4,'RMSE')"),'compact manuscript label');
    add('A+S proposed red/bold',contains(txt,'A+S (proposed)') && contains(txt,'[0.8500 0.0500 0.0500]') && contains(txt,'lw=2.00'),'proposed emphasized');
else
    add('Manuscript plot exists',false,f);
end

runner=fullfile(projectRoot,'run_online_model_experiments.m');
if exist(runner,'file')==2
    txt=fileread(runner);
    add('Formal runner integrates trajectory calibration',contains(txt,'maybe_apply_online_detector_trajectory_calibration'),'not smoke-only');
else
    add('Formal runner exists',false,runner);
end

T=table(checks,pass,details,'VariableNames',{'Check','Pass','Details'});
disp(T);
if all(pass)
    fprintf('\nOFFICIAL 69-BUS LLM ONLINE SETUP PASSED.\n');
else
    error('OFFICIAL 69-BUS LLM ONLINE SETUP FAILED.');
end

    function add(name,tf,msg)
        checks(end+1,1)=string(name); %#ok<AGROW>
        pass(end+1,1)=logical(tf); %#ok<AGROW>
        details(end+1,1)=string(msg); %#ok<AGROW>
    end
end
