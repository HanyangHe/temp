function T = verify_pnc_phi_comp_only_patch(projectRoot)
%VERIFY_PNC_PHI_COMP_ONLY_PATCH Zero-cost structural verification.
if nargin < 1 || isempty(projectRoot), projectRoot = pwd; end
addpath(genpath(projectRoot));

requiredFiles = { ...
    'methods/build_pnc_phi_comp_only_library.m', ...
    'methods/fit_pnc_phi_comp_only_module.m', ...
    'methods/train_modular_pnc_phi_comp_only_sindy.m', ...
    'methods/train_pnc_phi_comp_only_sindy.m', ...
    'methods/predict_modular_pnc_phi_comp_only_sindy.m', ...
    'tests/run_pnc_phi_comp_only_diagnostic_10bus.m'};

name = strings(numel(requiredFiles)+3,1);
passed = false(size(name));
detail = strings(size(name));
row = 0;
for k = 1:numel(requiredFiles)
    row=row+1; name(row)=requiredFiles{k};
    f = fullfile(projectRoot,requiredFiles{k});
    passed(row)=exist(f,'file')==2;
    detail(row)=string(f);
end

cfg = config_offline_experiment_10bus();
cfg.sindy.physicsNeuralCompositionalCompOnly.enabled = true;
opt = get_sindy_options(cfg);
row=row+1; name(row)='comp-only option';
passed(row)=isfield(opt,'physicsNeuralCompositionalCompOnly') && ...
    opt.physicsNeuralCompositionalCompOnly.enabled;
detail(row)='physicsNeuralCompositionalCompOnly.enabled=true';

methods = get_offline_method_registry(cfg);
methodNames = string({methods.name});
row=row+1; name(row)='registry method';
passed(row)=any(methodNames=='pnc_phi_comp_only_sindy');
detail(row)=strjoin(methodNames,', ');

row=row+1; name(row)='production default';
baseOpt = get_sindy_options(config_offline_experiment_10bus());
passed(row)=~baseOpt.physicsNeuralCompositionalCompOnly.enabled;
detail(row)='diagnostic method must remain OFF in production config';

T = table(name,passed,detail);
disp(T);
if ~all(passed)
    error('verify_pnc_phi_comp_only_patch:Failed', ...
        'PNC Phi_comp-only patch verification failed.');
end
fprintf('PNC PHI_COMP-ONLY PATCH VERIFICATION: PASSED\n');
fprintf('Diagnostic contract: H=f_PE_hat(chi), then xdot=Phi_comp(chi,H)*Xi_2 only.\n');
end
