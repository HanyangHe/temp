function report = repair_stage4_clean_sections_from_cache(projectRoot,testCase,varargin)
%REPAIR_STAGE4_CLEAN_SECTIONS_FROM_CACHE Recover clean Sections 1.1/1.2.
%
% This repairs the Stage-4 incremental-save regression in which a run that
% evaluated only Weak PN-SINDy + NODE in Sections 1.1/1.2 overwrote the old
% M-KBF/V/PE/PN clean sections in their replay bundles.
%
% The function DOES NOT train or roll out any model. It scans each method's
% persistent evaluation_cache and restores clean exact-xdot evaluations for
% sampleCounts = [250 500 750 1000 2000].
%
% Usage:
%   repair_stage4_clean_sections_from_cache(pwd,'10bus');
%
% Optional:
%   'DryRun',true   -> inspect recoverability without writing bundles.
%
% After repair, rebuild the multi-seed summary with the existing aggregate-only
% path in run_offline_model_experiments_multiseed.

if nargin<1 || isempty(projectRoot), projectRoot=pwd; end
if nargin<2 || isempty(testCase), testCase='10bus'; end

p=inputParser;
addParameter(p,'DryRun',false,@(x)islogical(x)||(isnumeric(x)&&isscalar(x)));
parse(p,varargin{:});
dryRun=logical(p.Results.DryRun);

[testCase,cfgFcn] = normalize_case(testCase);
cfg = cfgFcn();
caseRoot = fullfile(projectRoot,'outputs',cfg.output.folderName);

seeds = cfg.randomSeeds(:).';
sampleCounts = cfg.sampleCounts(:).';
typicalN = cfg.typicalSampleCount;
methods = {'modular_koopman_kbf','vanilla_sindy', ...
    'physics_embedded_sindy','physics_neural_sindy'};

fprintf('\n============================================================\n');
fprintf('Stage-4 clean-section recovery from persistent evaluation caches\n');
fprintf('Case      : %s\n',testCase);
fprintf('Seeds     : [%s]\n',strtrim(sprintf('%d ',seeds)));
fprintf('Samples   : [%s]\n',strtrim(sprintf('%d ',sampleCounts)));
fprintf('Dry run   : %s\n',onoff(dryRun));
fprintf('No training or rollout will be executed.\n');
fprintf('============================================================\n');

rows = struct('Seed',{},'Method',{},'RecoveredCount',{}, ...
    'RequiredCount',{},'BundleUpdated',{},'MissingSamples',{});

for iseed=1:numel(seeds)
    seed=seeds(iseed);
    seedRoot=fullfile(caseRoot,'seed_runs',sprintf('seed_%d',seed));
    methodRoot=fullfile(seedRoot,get_method_results_folder(cfg));

    for im=1:numel(methods)
        methodName=methods{im};
        methodDir=fullfile(methodRoot,methodName);
        cacheDir=fullfile(methodDir,get_evaluation_cache_folder(cfg));
        bundlePath=fullfile(methodDir,get_bundle_file_name(cfg));

        recoveredE=cell(0,1);
        recoveredT=table();
        missingN=[];

        for iN=1:numel(sampleCounts)
            N=sampleCounts(iN);
            [ev,cond,src]=find_best_clean_cache(cacheDir,methodName,N);
            if isempty(ev)
                missingN(end+1)=N; %#ok<AGROW>
                fprintf('  [MISS] seed %d | %-26s | N=%d\n',seed,methodName,N);
                continue;
            end
            row=evaluation_summary_row_recovered(ev,N,0,cond,src);
            if isempty(recoveredT), recoveredT=row; else, recoveredT=[recoveredT;row]; end %#ok<AGROW>
            recoveredE{end+1,1}=ev; %#ok<AGROW>
            fprintf('  [FOUND] seed %d | %-26s | N=%d | %s\n', ...
                seed,methodName,N,short_name(src));
        end

        updated=false;
        if ~isempty(recoveredT) && exist(bundlePath,'file')==2
            S=load_method_bundle_safe(bundlePath);
            if isfield(S,'methodBundle') && isstruct(S.methodBundle)
                oldBundle=S.methodBundle;
                newBundle=oldBundle;
                newBundle.report=struct();

                % Recover Section 1.2 from all available clean sample sizes.
                newBundle.report.section1p2=struct( ...
                    'table',recoveredT,'evaluations',{recoveredE});

                % Recover Section 1.1 from the clean typical-N cache.
                hit=find(round(double(recoveredT.SampleCount))==round(typicalN),1,'first');
                if ~isempty(hit)
                    newBundle.report.section1p1=struct( ...
                        'table',recoveredT(hit,:), ...
                        'evaluations',{{recoveredE{hit}}});
                end

                repaired=merge_offline_method_bundle_sections(oldBundle,newBundle);
                repaired.recoveryInfo=struct( ...
                    'source','persistent evaluation_cache', ...
                    'recoveredAt',char(datetime('now','Format','yyyy-MM-dd HH:mm:ss')), ...
                    'sampleCountsRecovered',recoveredT.SampleCount(:).', ...
                    'missingSampleCounts',missingN);

                if ~dryRun
                    save_bundle_atomic(bundlePath,repaired);
                end
                updated=true;
            else
                warning('Invalid method bundle; not updated: %s',bundlePath);
            end
        elseif exist(bundlePath,'file')~=2
            warning('Method bundle missing; cannot restore into it: %s',bundlePath);
        end

        rows(end+1)=struct( ... %#ok<AGROW>
            'Seed',seed,'Method',string(methodName), ...
            'RecoveredCount',height(recoveredT), ...
            'RequiredCount',numel(sampleCounts), ...
            'BundleUpdated',updated && ~dryRun, ...
            'MissingSamples',string(strtrim(sprintf('%d ',missingN))));
    end
end

report=struct2table(rows);
disp(report);

fprintf('\nRecovery rule:\n');
fprintf('  * caches tagged common_state_measurement_to_derivative are NEVER used\n');
fprintf('    to reconstruct clean Sections 1.1/1.2.\n');
fprintf('  * exact/pointwise clean caches are preferred when protocol metadata exist.\n');
fprintf('  * if an ambiguous N=500 legacy cache cannot be distinguished safely,\n');
fprintf('    it is left missing rather than silently using the Stage-4 derivative cache.\n');
fprintf('============================================================\n');
end


function [testCase,cfgFcn]=normalize_case(testCase)
testCase=lower(char(string(testCase)));
switch testCase
    case {'10','10bus'}
        testCase='10bus'; cfgFcn=@config_offline_experiment_10bus;
    case {'69','69bus'}
        testCase='69bus'; cfgFcn=@config_offline_experiment_69bus;
    case {'123','123bus'}
        testCase='123bus'; cfgFcn=@config_offline_experiment_123bus;
    otherwise
        error('Unsupported testCase: %s',testCase);
end
end


function [bestEv,bestCond,bestFile]=find_best_clean_cache(cacheDir,methodName,N)
bestEv=[];
bestCond=struct();
bestFile='';
if exist(cacheDir,'dir')~=7, return; end
D=dir(fullfile(cacheDir,'*.mat'));
candidates=struct('score',{},'datenum',{},'ev',{},'cond',{},'file',{});

for i=1:numel(D)
    f=fullfile(D(i).folder,D(i).name);
    try
        S=load_cache_safe(f);
    catch
        continue;
    end
    if ~isfield(S,'savedEvaluation') || isempty(S.savedEvaluation), continue; end
    ev=S.savedEvaluation;
    if isfield(S,'condition'), cond=S.condition; else, cond=struct(); end

    if ~strcmp(char(evaluation_method_name(ev)),methodName), continue; end
    nThis=condition_sample_count(cond,ev);
    noiseThis=condition_noise_level(cond,ev);
    if ~(isfinite(nThis) && round(nThis)==round(N)), continue; end
    if ~(isfinite(noiseThis) && abs(noiseThis)<=1e-14), continue; end

    proto=lower(protocol_text(cond,ev,D(i).name));
    if contains(proto,'common_state_measurement_to_derivative')
        continue;
    end

    score=0;
    if contains(proto,'exact_xdot'), score=score+100; end
    if contains(proto,'pointwise'), score=score+60; end
    if contains(proto,'clean'), score=score+30; end
    if contains(proto,'grouped_state_trajectory')
        % This protocol is appropriate for NODE/Weak-PN, not the four
        % pointwise legacy methods recovered here.
        score=score-200;
    end
    if isempty(strtrim(proto)), score=score+10; end

    candidates(end+1)=struct( ... %#ok<AGROW>
        'score',score,'datenum',D(i).datenum,'ev',ev,'cond',cond,'file',f);
end

if isempty(candidates), return; end

scores=[candidates.score];
bestScore=max(scores);
idx=find(scores==bestScore);

% For ambiguous legacy candidates, prefer the older file: Stage-2 clean
% results predate the Stage-4 measurement-noise rerun.
if numel(idx)>1
    [~,j]=min([candidates(idx).datenum]);
    idx=idx(j);
else
    idx=idx(1);
end

% For N=500, an untagged single candidate is potentially ambiguous. If its
% protocol text is empty and no exact/pointwise marker is available, refuse to
% guess unless the filename itself is the legacy simple condition tag.
proto=lower(protocol_text(candidates(idx).cond,candidates(idx).ev, ...
    candidates(idx).file));
if N==500 && isempty(strtrim(proto))
    [~,base,~]=fileparts(candidates(idx).file);
    legacyTag=sprintf('%s_N500_noise0pct',methodName);
    if ~strcmp(base,legacyTag)
        return;
    end
end

bestEv=candidates(idx).ev;
bestCond=candidates(idx).cond;
bestFile=candidates(idx).file;
end


function T=evaluation_summary_row_recovered(ev,N,noise,cond,src)
method=evaluation_method_name(ev);
displayName=evaluation_display_name(ev);
training=field_numeric(ev,'trainingTimeSeconds',NaN);
if ~isfinite(training) && isfield(ev,'trainInfo')
    training=first_numeric_field(ev.trainInfo, ...
        {'trainingTimeSeconds','totalTrainingTimeSeconds','wallTimeSeconds'},NaN);
end
rolloutTime=NaN;
if isfield(ev,'prediction') && isstruct(ev.prediction) && ...
        isfield(ev.prediction,'metadata')
    rolloutTime=first_numeric_field(ev.prediction.metadata, ...
        {'solveTimeSeconds','trajectorySolveTimeSeconds'},NaN);
end

succ=field_logical(ev,'rolloutSucceeded',false);
status=field_string(ev,'rolloutStatus',"");
failureTime=field_numeric(ev,'failureTimeSeconds',NaN);
coverage=field_numeric(ev,'trajectoryCoveragePercent',NaN);
failureMsg=field_string(ev,'failureMessage',"");
if isfield(ev,'prediction') && isstruct(ev.prediction) && ...
        isfield(ev.prediction,'metadata')
    md=ev.prediction.metadata;
    if strlength(status)==0, status=field_string(md,'rolloutStatus',""); end
    if ~isfinite(failureTime), failureTime=field_numeric(md,'failureTimeSeconds',NaN); end
    if ~isfinite(coverage), coverage=field_numeric(md,'trajectoryCoveragePercent',NaN); end
    if strlength(failureMsg)==0, failureMsg=field_string(md,'failureMessage',""); end
end

M=struct();
if isfield(ev,'metrics') && isstruct(ev.metrics), M=ev.metrics; end
rmse=metric(M,{'RMSE','rmse'},NaN);
mae=metric(M,{'MAE','mae'},NaN);
maxae=metric(M,{'MaxAE','maxAE','maximumAbsoluteError'},NaN);
nmax=metric(M,{'NMaxAE_Range','nMaxAE_Range','normalizedMaxAEByRange'},NaN);
mape=metric(M,{'MAPE_percent','MAPEPercent','mapePercent'},NaN);
smape=metric(M,{'sMAPE_percent','SMAPEPercent','smapePercent'},NaN);
valid=metric(M,{'MAPE_valid_fraction','MAPEValidFraction'},NaN);
r2=metric(M,{'MeanR2','meanR2'},NaN);

cacheKey=protocol_text(cond,ev,src);
if isempty(cacheKey), cacheKey=src; end

T=table(string(method),string(displayName),double(N),double(noise),100*double(noise), ...
    training,rolloutTime,string(status),logical(succ),failureTime,coverage, ...
    string(failureMsg),rmse,mae,maxae,nmax,mape,smape,valid,r2,false, ...
    "recovered_from_persistent_evaluation_cache",string(cacheKey), ...
    'VariableNames',{'Method','DisplayName','SampleCount','NoiseLevel', ...
    'NoisePercent','TrainingTimeSec','TrajectorySolveTimeSec','RolloutStatus', ...
    'RolloutSucceeded','FailureTimeSec','TrajectoryCoveragePercent', ...
    'FailureMessage','RMSE','MAE','MaxAE','NMaxAE_Range','MAPE_percent', ...
    'sMAPE_percent','MAPE_valid_fraction','MeanR2','EvaluationReused', ...
    'EvaluationSource','EvaluationCacheKey'});
end


function txt=protocol_text(cond,ev,fileName)
parts=strings(0,1);
names={'protocol','dataProtocol','trainingProtocol','cacheKey','key','noiseProtocol'};
for i=1:numel(names)
    if isstruct(cond) && isfield(cond,names{i}) && ~isempty(cond.(names{i}))
        parts(end+1,1)=string(cond.(names{i})); %#ok<AGROW>
    end
end
if isstruct(ev) && isfield(ev,'trainInfo') && isstruct(ev.trainInfo)
    tr=ev.trainInfo;
    for i=1:numel(names)
        if isfield(tr,names{i}) && ~isempty(tr.(names{i}))
            parts(end+1,1)=string(tr.(names{i})); %#ok<AGROW>
        end
    end
end
[~,base,~]=fileparts(char(string(fileName)));
if contains(lower(base),'protocol')
    parts(end+1,1)=string(base); %#ok<AGROW>
end
txt=char(strjoin(parts,'|'));
end


function n=condition_sample_count(cond,ev)
n=first_numeric_field(cond,{'sampleCount','nSamples','N'},NaN);
if ~isfinite(n) && isfield(ev,'trainInfo')
    n=first_numeric_field(ev.trainInfo,{'nSamples','sampleCount','N'},NaN);
end
end


function x=condition_noise_level(cond,ev)
x=first_numeric_field(cond,{'noiseLevel','noise','eta'},NaN);
if ~isfinite(x) && isfield(cond,'noisePercent')
    x=double(cond.noisePercent)/100;
end
if ~isfinite(x) && isfield(ev,'trainInfo')
    x=first_numeric_field(ev.trainInfo,{'noiseLevel','noise','eta'},NaN);
end
% Legacy clean caches sometimes omit noise metadata entirely.
if ~isfinite(x), x=0; end
end


function s=evaluation_method_name(ev)
s="";
if isstruct(ev) && isfield(ev,'method') && isstruct(ev.method) && ...
        isfield(ev.method,'name') && ~isempty(ev.method.name)
    s=string(ev.method.name);
end
end


function s=evaluation_display_name(ev)
s=evaluation_method_name(ev);
if isstruct(ev) && isfield(ev,'method') && isstruct(ev.method) && ...
        isfield(ev.method,'displayName') && ~isempty(ev.method.displayName)
    s=string(ev.method.displayName);
end
end


function v=metric(M,names,defaultVal)
v=defaultVal;
for i=1:numel(names)
    if isstruct(M) && isfield(M,names{i}) && ~isempty(M.(names{i}))
        try
            q=double(M.(names{i}));
            if isscalar(q), v=q; return; end
        catch
        end
    end
end
end


function v=first_numeric_field(s,names,defaultVal)
v=defaultVal;
for i=1:numel(names)
    if isstruct(s) && isfield(s,names{i}) && ~isempty(s.(names{i}))
        try
            q=double(s.(names{i}));
            if isscalar(q), v=q; return; end
        catch
        end
    end
end
end


function v=field_numeric(s,name,defaultVal)
v=defaultVal;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    try
        q=double(s.(name));
        if isscalar(q), v=q; end
    catch
    end
end
end


function v=field_logical(s,name,defaultVal)
v=defaultVal;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    try, v=logical(s.(name)); catch, end
end
end


function v=field_string(s,name,defaultVal)
v=string(defaultVal);
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    try, v=string(s.(name)); catch, end
end
end


function folder=get_method_results_folder(cfg)
folder='method_results';
if isfield(cfg,'output') && isfield(cfg.output,'methodResultsFolder') && ...
        ~isempty(cfg.output.methodResultsFolder)
    folder=char(string(cfg.output.methodResultsFolder));
end
end


function folder=get_evaluation_cache_folder(cfg)
folder='evaluation_cache';
if isfield(cfg,'output') && isfield(cfg.output,'evaluationCacheFolder') && ...
        ~isempty(cfg.output.evaluationCacheFolder)
    folder=char(string(cfg.output.evaluationCacheFolder));
end
end


function f=get_bundle_file_name(cfg)
f='offline_part1_method_replay.mat';
if isfield(cfg,'output') && isfield(cfg.output,'methodReplayFileName') && ...
        ~isempty(cfg.output.methodReplayFileName)
    f=char(string(cfg.output.methodReplayFileName));
end
end


function S=load_cache_safe(filePath)
try
    S=load(filePath,'savedEvaluation','condition');
    return;
catch firstError
end
tmpDir=tempname; mkdir(tmpDir);
cleanupObj=onCleanup(@()cleanup_temp_dir(tmpDir));
tmpFile=fullfile(tmpDir,'cache.mat');
[ok,msg]=copyfile(filePath,tmpFile,'f');
if ~ok, error('Cache copy failed: %s',msg); end
try
    S=load(tmpFile,'savedEvaluation','condition');
catch
    rethrow(firstError);
end
clear cleanupObj; cleanup_temp_dir(tmpDir);
end


function S=load_method_bundle_safe(filePath)
try
    S=load(filePath,'methodBundle');
    return;
catch firstError
end
tmpDir=tempname; mkdir(tmpDir);
cleanupObj=onCleanup(@()cleanup_temp_dir(tmpDir));
tmpFile=fullfile(tmpDir,'bundle.mat');
[ok,msg]=copyfile(filePath,tmpFile,'f');
if ~ok, error('Bundle copy failed: %s',msg); end
try
    S=load(tmpFile,'methodBundle');
catch
    rethrow(firstError);
end
clear cleanupObj; cleanup_temp_dir(tmpDir);
end


function save_bundle_atomic(filePath,methodBundle)
d=fileparts(filePath);
if exist(d,'dir')~=7, mkdir(d); end
tmpDir=tempname; mkdir(tmpDir);
cleanupObj=onCleanup(@()cleanup_temp_dir(tmpDir));
tmpFile=fullfile(tmpDir,'bundle.mat');
save(tmpFile,'methodBundle','-v7.3');
whos('-file',tmpFile);

stage=fullfile(d,'_offline_part1_method_replay_repair.mat');
if exist(stage,'file')==2, delete(stage); end
[ok,msg]=copyfile(tmpFile,stage,'f');
if ~ok, error('Could not stage repaired bundle: %s',msg); end
whos('-file',stage);
if exist(filePath,'file')==2, delete(filePath); end
[ok,msg]=movefile(stage,filePath,'f');
if ~ok, error('Could not install repaired bundle: %s',msg); end
clear cleanupObj; cleanup_temp_dir(tmpDir);
end


function cleanup_temp_dir(d)
if exist(d,'dir')==7
    try, rmdir(d,'s'); catch, end
end
end


function s=short_name(p)
[~,n,e]=fileparts(p); s=[n e];
end


function s=onoff(tf)
if tf, s='ON'; else, s='OFF'; end
end
