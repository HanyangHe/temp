function report = verify_saved_offline_method_coverage(projectRoot,cfg)
%VERIFY_SAVED_OFFLINE_METHOD_COVERAGE Verify replay-only offline baselines.
%
% If cfg.run.savedOnlyMethods is present, every listed method must already have
% complete Section 1.1--1.3 method bundles for every manuscript seed.
% The verifier also confirms that saved-only methods are NOT present in any
% section execution list, preventing accidental retraining.

if nargin<1 || isempty(projectRoot)
    projectRoot=fileparts(fileparts(mfilename('fullpath')));
end
projectRoot=char(string(projectRoot));
addpath(genpath(projectRoot));

if nargin<2 || isempty(cfg)
    error('verify_saved_offline_method_coverage:Config','cfg is required.');
end

if ~isfield(cfg,'run') || ~isstruct(cfg.run) || ...
        ~isfield(cfg.run,'savedOnlyMethods') || isempty(cfg.run.savedOnlyMethods)
    report=struct('ready',true,'table',table(),'requiredMethods',strings(0,1));
    return;
end

requiredMethods=string(cfg.run.savedOnlyMethods(:));
campaignMethods=string(cfg.run.methodsToRun(:));
if ~all(ismember(requiredMethods,campaignMethods))
    error('verify_saved_offline_method_coverage:CampaignList', ...
        'Every saved-only method must also appear in cfg.run.methodsToRun.');
end

sectionFields={'section1p1MethodsToRun','section1p2MethodsToRun','section1p3MethodsToRun'};
for i=1:numel(sectionFields)
    f=sectionFields{i};
    if isfield(cfg.run,f) && ~isempty(cfg.run.(f))
        active=string(cfg.run.(f)(:));
        overlap=intersect(requiredMethods,active,'stable');
        if ~isempty(overlap)
            error('verify_saved_offline_method_coverage:RetrainingRisk', ...
                ['Saved-only method(s) [%s] appear in cfg.run.%s. ', ...
                 'Remove them before launching the campaign.'], ...
                strjoin(overlap,', '),f);
        end
    end
end

baseRoot=fullfile(projectRoot,'outputs',char(string(cfg.output.folderName)), ...
    char(string(cfg.multiseed.seedFolderName)));
seeds=round(double(cfg.randomSeeds(:).'));

rows=table();
allOK=true;

for is=1:numel(seeds)
    seed=seeds(is);
    seedRoot=fullfile(baseRoot,sprintf('seed_%d',seed));
    for im=1:numel(requiredMethods)
        methodName=requiredMethods(im);
        bundleFile=fullfile(seedRoot,char(string(cfg.output.methodResultsFolder)), ...
            char(methodName),char(string(cfg.output.methodReplayFileName)));

        existsFlag=exist(bundleFile,'file')==2;
        sec11=false; sec12=false; sec13=false;
        message="";

        if ~existsFlag
            message="bundle missing";
        else
            try
                S=load_mat_long_path_safe(bundleFile,'methodBundle');
                if ~isfield(S,'methodBundle') || ~isstruct(S.methodBundle)
                    message="methodBundle missing/invalid";
                else
                    B=S.methodBundle;
                    sec11=section_has_conditions_local(B,'section1p1', ...
                        cfg.typicalSampleCount,0);
                    sec12=all(arrayfun(@(N)section_has_conditions_local( ...
                        B,'section1p2',N,0),cfg.sampleCounts));
                    sec13=all(arrayfun(@(q)section_has_conditions_local( ...
                        B,'section1p3',cfg.typicalSampleCount,q),cfg.noiseLevels));
                    if ~(sec11&&sec12&&sec13)
                        message="one or more official conditions are missing";
                    end
                end
            catch ME
                message="bundle read failed: "+string(ME.message);
            end
        end

        ok=existsFlag&&sec11&&sec12&&sec13;
        allOK=allOK&&ok;

        row=table(seed,methodName,existsFlag,sec11,sec12,sec13,ok, ...
            string(bundleFile),message, ...
            'VariableNames',{ ...
            'Seed','Method','BundleExists','Section1p1Complete', ...
            'Section1p2Complete','Section1p3Complete','Ready', ...
            'BundlePath','Message'});
        if isempty(rows), rows=row; else, rows=[rows;row]; end %#ok<AGROW>
    end
end

report=struct();
report.ready=allOK;
report.table=rows;
report.requiredMethods=requiredMethods;
report.seeds=seeds;

disp(rows);

if ~allOK
    error('verify_saved_offline_method_coverage:SavedBaselineIncomplete', ...
        ['Saved-only baseline coverage is incomplete. The campaign is stopped ', ...
         'before any new training so historical baselines are never silently ', ...
         'recomputed or omitted. Resolve rows with Ready=false first.']);
end

fprintf(['Verified saved-only coverage for %d method(s) across %d seed(s). ', ...
    'These methods will be loaded for aggregation and will NOT be retrained.\n'], ...
    numel(requiredMethods),numel(seeds));
end


function tf=section_has_conditions_local(B,sectionName,N,noise)
tf=false;
if ~isstruct(B) || ~isfield(B,'report') || ~isstruct(B.report) || ...
        ~isfield(B.report,sectionName) || ~isstruct(B.report.(sectionName))
    return;
end
sec=B.report.(sectionName);
if ~isfield(sec,'table') || ~istable(sec.table) || isempty(sec.table)
    return;
end
T=sec.table;
if ~ismember('SampleCount',T.Properties.VariableNames), return; end

nMatch=abs(double(T.SampleCount)-double(N))<=1e-12;
if ismember('NoiseLevel',T.Properties.VariableNames)
    q=double(T.NoiseLevel);
elseif ismember('NoisePercent',T.Properties.VariableNames)
    q=double(T.NoisePercent)/100;
else
    q=zeros(height(T),1);
end
noiseMatch=abs(q-double(noise))<=max(1e-14,1e-10*max(1,abs(double(noise))));
tf=any(nMatch & noiseMatch);
end
