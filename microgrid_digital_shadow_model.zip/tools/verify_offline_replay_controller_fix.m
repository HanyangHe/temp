function T = verify_offline_replay_controller_fix(projectRoot)
%VERIFY_OFFLINE_REPLAY_CONTROLLER_FIX Check the offline replay controller patch.
if nargin < 1 || isempty(projectRoot), projectRoot = pwd; end
mlxFile = fullfile(projectRoot,'microgrid_dataDriven_offline_experiments.mlx');
runnerFile = fullfile(projectRoot,'run_offline_llm_prior_level_ablation.m');

checks = strings(0,1); pass = false(0,1); details = strings(0,1);
add = @(name,ok,detail) assignin('caller','__dummy__',0); %#ok<NASGU>

[checks,pass,details] = addrow(checks,pass,details,'MLX exists',exist(mlxFile,'file')==2,mlxFile);
[checks,pass,details] = addrow(checks,pass,details,'Ablation runner exists',exist(runnerFile,'file')==2,runnerFile);

runnerText = fileread(runnerFile);
runnerSig = contains(runnerText, ...
    'function report = run_offline_llm_prior_level_ablation(projectRoot,caseFcn,configFcn,varargin)');
[checks,pass,details] = addrow(checks,pass,details,'Full ablation runner signature',runnerSig, ...
    'projectRoot, caseFcn, configFcn, varargin');
[checks,pass,details] = addrow(checks,pass,details,'No merge-template abort', ...
    ~contains(runnerText,'This patch file is a merge template'), ...
    'formal runner restored');

T = table(checks,pass,details,'VariableNames',{'Check','Pass','Details'});
disp(T);
if ~all(pass)
    error('verify_offline_replay_controller_fix:Failed','Offline replay controller verification failed.');
end
fprintf('\nOFFLINE REPLAY CONTROLLER FIX: ALL CHECKS PASSED\n');
end

function [c,p,d] = addrow(c,p,d,name,ok,detail)
c(end+1,1)=string(name); %#ok<AGROW>
p(end+1,1)=logical(ok); %#ok<AGROW>
d(end+1,1)=string(detail); %#ok<AGROW>
end
