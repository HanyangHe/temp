function View = display_official_cross_scale_table(R,showFigure)
%DISPLAY_OFFICIAL_CROSS_SCALE_TABLE Show the verified manuscript table.
%   View = display_official_cross_scale_table(R,true)
%
% INPUT
%   R          : batch report from reload_official_cross_scale_table(root,cases)
%   showFigure : true (default) to open a 7-column MATLAB UI table
%
% OUTPUT
%   View.table   : 6 rows per selected system, in manuscript order
%   View.data    : paper-layout cell array displayed in the window
%   View.csvPath : human-readable paper-layout CSV (display strings only)
%   View.figure  : figure handle, or [] if UI is unavailable
%
% SCIENTIFIC DATA POLICY
%   Values are converted DIRECTLY from R.numerical.CellTeX. That field is
%   produced by the official aggregator and used in the LaTeX manuscript
%   exporter. No rounding, aggregation, or successful-rollout filtering is
%   recalculated here. Missing/incompatible cells remain PENDING.

if nargin < 2 || isempty(showFigure)
    showFigure = true;
end
if ~isstruct(R) || ~isfield(R,'numerical') || ...
        ~istable(R.numerical) || ~isfield(R,'cases') || ...
        ~isfield(R,'outputDir')
    error('CrossScaleDisplay:Report', ...
        'Expected a batch report from reload_official_cross_scale_table.');
end

Q = R.numerical;
if ~isfield(R,'cleanMiddleSampleCount') || ...
        double(R.cleanMiddleSampleCount)~=750 || ...
        ~isfield(R,'noiseSampleCount') || double(R.noiseSampleCount)~=500
    error('CrossScaleDisplay:SampleBudget', ...
        'Refusing to label N=500 values as N=750: expected N750 clean/N500 noise source.');
end
need = {'Case','Method','Condition','Status','CellTeX'};
if ~all(ismember(need,Q.Properties.VariableNames))
    error('CrossScaleDisplay:Columns', ...
        'The official numerical report lacks required manuscript columns.');
end

% Exact order, grouping, and headings from the manuscript table.
allCases = ["10bus","69bus","123bus"];
selected = allCases(ismember(allCases,string(R.cases)));
methods = ["M-KBF","V-SINDy","PE-SINDy","ED-SINDy", ...
           "NODE","LLM-Prior SINDy"];
conditions = ["N250","N750","N2000","noise0p5","noise5"];
headers = {'System','Method','N_s = 250','N_s = 750','N_s = 2000', ...
           'η = 0.5%','η = 5%'};

nRows = numel(selected)*numel(methods);
rows = cell(nRows,7);
for icase = 1:numel(selected)
    currentCase = selected(icase);
    for im = 1:numel(methods)
        ri = (icase-1)*numel(methods)+im;
        if im == 1
            rows{ri,1} = char(extractBefore(currentCase,"bus")+"-bus");
        else
            rows{ri,1} = '';
        end
        rows{ri,2} = char(methods(im));
        for j = 1:numel(conditions)
            matched = string(Q.Case)==currentCase & ...
                      string(Q.Method)==methods(im) & ...
                      string(Q.Condition)==conditions(j);
            if nnz(matched) ~= 1
                error('CrossScaleDisplay:MissingOrDuplicate', ...
                    'Expected one saved table cell for %s / %s / %s; found %d.', ...
                    char(currentCase),char(methods(im)), ...
                    char(conditions(j)),nnz(matched));
            end
            status = string(Q.Status(matched));
            if status == "PENDING"
                rows{ri,j+2} = 'PENDING';
            else
                rows{ri,j+2} = local_latex_to_plain(Q.CellTeX(matched));
            end
        end
    end
end

% The MATLAB table is also left in the runner workspace as PaperTable.
T = cell2table(rows,'VariableNames', ...
    {'System','Method','Ns250','Ns750','Ns2000','Noise0p5','Noise5'});
View = struct('table',T,'data',{rows},'headers',{headers}, ...
    'csvPath','','figure',[]);

% Always print the same seven aligned paper columns to the Command Window.
% This also works in MATLAB -batch (where a GUI cannot be opened).
consoleWidths = [8 18 25 25 25 25 25];
for col = 1:7
    consoleWidths(col) = max([consoleWidths(col), ...
        numel(headers{col})+1, max(cellfun(@numel,rows(:,col)))+1]);
end
rule = repmat('-',1,sum(consoleWidths)+3*6);
fprintf('\n================= OFFICIAL CROSS-SCALE MANUSCRIPT TABLE =================\n');
local_print_console_row(headers,consoleWidths);
fprintf('%s\n',rule);
for i = 1:size(rows,1)
    if i>1 && mod(i-1,6)==0
        fprintf('%s\n',rule);  % system-block divider
    end
    local_print_console_row(rows(i,:),consoleWidths);
end
fprintf('%s\n',rule);
fprintf('RMSE cells: mean ± sample std (successful rollouts / 3).\n');
fprintf('Noise columns use N_s=500. PENDING = missing or incompatible saved data.\n');

% Store a second CSV matching the VISUAL paper layout, not the long-format
% numerical CSV already written by the official extractor.
View.csvPath = fullfile(char(string(R.outputDir)), ...
    'cross_scale_selected_cases_paper_display.csv');
writecell([headers;rows],View.csvPath);

if ~logical(showFigure)
    return;
end

% Always fail gracefully for -batch/headless sessions or MATLAB releases
% without uifigure styling support: the Command Window and CSV still work.
try
    scr = get(groot,'ScreenSize');
    winW = min(1490,max(940,scr(3)-85));
    winH = min(730,max(380,108+29*nRows));
    posX = max(10,floor((scr(3)-winW)/2));
    posY = max(20,floor((scr(4)-winH)/2));
    fig = uifigure('Name','Official Cross-Scale Manuscript Table', ...
        'Color',[1 1 1],'Position',[posX posY winW winH]);
    numericWidth = max(120,floor((winW-315)/5));
    colWidths = [{85,170},num2cell(repmat(numericWidth,1,5))];
    grid = uitable(fig,'Data',rows,'ColumnName',headers, ...
        'RowName',{},'ColumnWidth',colWidths, ...
        'FontName','Times New Roman','FontSize',12, ...
        'Position',[16 53 winW-32 winH-70]);
    % Match the manuscript's bold final method and system group labels.
    try
        boldStyle = uistyle('FontWeight','bold');
        for ir = 1:nRows
            if mod(ir-1,6)==0
                addStyle(grid,boldStyle,'cell',[ir 1]);
            elseif mod(ir,6)==0
                addStyle(grid,boldStyle,'cell',[ir 2]);
            end
        end
    catch
        % uistyle support is release-dependent; content remains complete.
    end
    uilabel(fig,'Text', ...
        'RMSE: mean ± sample std (successes/3). Noise: N_s=500. PENDING: missing/incompatible saved data.', ...
        'Position',[18 9 winW-36 33], ...
        'FontName','Times New Roman','FontSize',11);
    View.figure = fig;
catch ME
    warning('CrossScaleDisplay:FigureUnavailable', ...
        'Paper table is printed and exported; MATLAB GUI display unavailable: %s', ...
        ME.message);
end
end

function plain = local_latex_to_plain(cellTeX)
% Convert TeX typography ONLY; never read or transform numeric input fields.
plain = char(string(cellTeX));
plain = strrep(plain,'$','');
plain = strrep(plain,'\text{--}','--');
plain = strrep(plain,'\pm','±');
plain = strrep(plain,'\!\times\!','×');
plain = strrep(plain,'\;',' ');
plain = regexprep(plain,'10\^\{(-?\d+)\}','10^$1');
plain = strtrim(plain);
end

function local_print_console_row(cells,widths)
for col = 1:numel(widths)
    if col>1, fprintf(' | '); end
    fprintf('%-*s',widths(col),cells{col});
end
fprintf('\n');
end
