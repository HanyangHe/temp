function T = verify_section_parallel_offline_patch(projectRoot)
%VERIFY_SECTION_PARALLEL_OFFLINE_PATCH Runtime-light verification for 10/69/123 bus.
%
% This check does NOT start a parallel pool and does NOT train any model.
% It verifies that all three offline cases use the same section-level parallel
% architecture and the shared cache-key protocol required for safe reuse.

if nargin < 1 || isempty(projectRoot)
    projectRoot = fileparts(fileparts(mfilename('fullpath')));
end
addpath(genpath(projectRoot));

caseNames = ["10bus","69bus","123bus"];
configFcns = {@config_offline_experiment_10bus, ...
              @config_offline_experiment_69bus, ...
              @config_offline_experiment_123bus};
checks = strings(0,1);
passed = false(0,1);
detail = strings(0,1);

for ic = 1:numel(configFcns)
    cfg = configFcns{ic}();
    prefix = caseNames(ic) + ": ";
    if ic==1
        expectedMethods = ["modular_koopman_kbf";"vanilla_sindy"; ...
            "physics_embedded_sindy";"physics_neural_sindy"; ...
            "physics_neural_compositional_sindy";"weak_sindy"];
        expectedWorkers = 6;
    else
        expectedMethods = ["vanilla_sindy";"physics_embedded_sindy"; ...
            "physics_neural_compositional_sindy"];
        expectedWorkers = 3;
    end

    [checks,passed,detail] = add_check_local(checks,passed,detail, ...
        prefix+"parallel.enabled",isfield(cfg,'parallel') && ...
        isfield(cfg.parallel,'enabled') && logical(cfg.parallel.enabled), ...
        "cfg.parallel.enabled must be true");
    [checks,passed,detail] = add_check_local(checks,passed,detail, ...
        prefix+"parallel.mode",isfield(cfg.parallel,'mode') && ...
        strcmpi(char(string(cfg.parallel.mode)),'within_section'), ...
        "expected cfg.parallel.mode='within_section'");
    [checks,passed,detail] = add_check_local(checks,passed,detail, ...
        prefix+"parallel.workers",isfield(cfg.parallel,'numWorkers') && ...
        cfg.parallel.numWorkers == expectedWorkers, ...
        sprintf('expected %d bounded workers',expectedWorkers));

    for s = ["section1p1","section1p2","section1p3"]
        ok = isfield(cfg.parallel,char(s)) && logical(cfg.parallel.(char(s)));
        [checks,passed,detail] = add_check_local(checks,passed,detail, ...
            prefix+"parallel."+s,ok,"section-level parfor should be enabled");
    end

    m1 = string(cfg.run.section1p1MethodsToRun(:));
    m2 = string(cfg.run.section1p2MethodsToRun(:));
    m3 = string(cfg.run.section1p3MethodsToRun(:));
    [checks,passed,detail] = add_check_local(checks,passed,detail, ...
        prefix+"section method sets", ...
        isequal(m1,expectedMethods) && isequal(m2,expectedMethods) && ...
        isequal(m3,expectedMethods), ...
        "section-specific method set should match the current case campaign");

    % Official noise sweep: 0%% is the clean N=500 anchor, while positive
    % noise levels use the measured-state -> reconstructed-derivative protocol.
    % The clean key must therefore match the ordinary clean N=500 key, and the
    % configured sweep must include the new 10%% stress point.
    method = struct('name','physics_neural_compositional_sindy');
    clean = struct('metadata',struct());
    keyCleanA = string(make_offline_evaluation_cache_key(method,500,0,cfg,clean));
    keyCleanB = string(make_offline_evaluation_cache_key(method,500,0,cfg,clean));
    hasTenPct = any(abs(double(cfg.noiseLevels(:))-0.10) < 1e-12);
    [checks,passed,detail] = add_check_local(checks,passed,detail, ...
        prefix+"clean/noise0 anchor reuse",keyCleanA == keyCleanB && hasTenPct, ...
        "eta=0 must reuse clean N=500; noise grid must include 10 percent");

    nMethods = numel(expectedMethods);
    n1p1 = nMethods;
    n1p2Req = numel(cfg.sampleCounts)*nMethods;
    n1p2New = n1p2Req-nMethods; % N=500 x methods reused from Section 1.1
    n1p3Req = numel(cfg.noiseLevels)*nMethods;
    n1p3New = n1p3Req-nMethods; % eta=0 x methods reused from clean N=500
    queueText = sprintf('%s per seed: 1.1=%d new; 1.2=%d requests/%d new; 1.3=%d requests/%d new after clean-anchor reuse', ...
        caseNames(ic),n1p1,n1p2Req,n1p2New,n1p3Req,n1p3New);
    [checks,passed,detail] = add_check_local(checks,passed,detail, ...
        prefix+"expected queue sizes",n1p1==nMethods && ...
        n1p2Req==numel(cfg.sampleCounts)*nMethods && ...
        n1p2New==(numel(cfg.sampleCounts)-1)*nMethods && ...
        n1p3Req==numel(cfg.noiseLevels)*nMethods && ...
        n1p3New==(numel(cfg.noiseLevels)-1)*nMethods,queueText);
end

runnerPath = fullfile(projectRoot,'run_offline_model_experiments.m');
executorPath = fullfile(projectRoot,'experiments','run_offline_section_jobs.m');
keyPath = fullfile(projectRoot,'experiments','make_offline_evaluation_cache_key.m');
protocolPath = fullfile(projectRoot,'experiments','offline_method_data_protocol.m');
[checks,passed,detail] = add_check_local(checks,passed,detail, ...
    "shared parallel executor file",exist(executorPath,'file') == 2,executorPath);
[checks,passed,detail] = add_check_local(checks,passed,detail, ...
    "shared cache-key helpers",exist(keyPath,'file') == 2 && exist(protocolPath,'file') == 2, ...
    "cache key and data-protocol helpers must both exist");

runnerText = fileread(runnerPath);
executorText = fileread(executorPath);
[checks,passed,detail] = add_check_local(checks,passed,detail, ...
    "runner uses section executor",contains(runnerText,'run_offline_section_jobs('), ...
    "main generic runner must delegate section jobs to the bounded executor");
[checks,passed,detail] = add_check_local(checks,passed,detail, ...
    "executor contains parfor",contains(executorText,'parfor ('), ...
    "shared parallel executor must contain bounded parfor syntax");
[checks,passed,detail] = add_check_local(checks,passed,detail, ...
    "noise prepared before parfor",contains(runnerText,'noiseDatasets{in} = base') && ...
    contains(runnerText,'noiseDatasets{in} = add_offline_training_noise'), ...
    "clean anchor and positive-noise realizations should be prepared serially before Section 1.3 parfor");

T = table(checks,passed,detail,'VariableNames',{'Check','Passed','Detail'});
disp(T);
if all(passed)
    fprintf('\nSECTION-PARALLEL PATCH VERIFICATION: PASSED FOR 10/69/123 BUS\n');
    fprintf('  All three cases use serial seeds -> serial sections -> bounded within-section PARFOR.\n');
    fprintf('  No pool was started and no training/rollout was executed by this verifier.\n');
else
    error('verify_section_parallel_offline_patch:Failed', ...
        'One or more section-parallel patch checks failed.');
end
end


function [checks,passed,detail] = add_check_local(checks,passed,detail,name,ok,msg)
checks(end+1,1) = string(name);
passed(end+1,1) = logical(ok);
detail(end+1,1) = string(msg);
end
