function T = verify_pnc_residual_comp_patch(projectRoot)
%VERIFY_PNC_RESIDUAL_COMP_PATCH Zero-cost structural verifier.
if nargin < 1 || isempty(projectRoot), projectRoot = pwd; end
addpath(genpath(projectRoot));

checks = strings(0,1);
passed = false(0,1);

req = { ...
    'methods/build_pnc_residual_comp_library.m', ...
    'methods/fit_pnc_residual_comp_module.m', ...
    'methods/train_modular_pnc_residual_comp_sindy.m', ...
    'methods/train_pnc_residual_comp_sindy.m', ...
    'methods/predict_modular_pnc_residual_comp_sindy.m', ...
    'tests/run_pnc_residual_comp_diagnostic_10bus.m'};
for k = 1:numel(req)
    checks(end+1,1) = "file: " + string(req{k}); %#ok<AGROW>
    passed(end+1,1) = isfile(fullfile(projectRoot,req{k})); %#ok<AGROW>
end

cfg = config_offline_experiment_10bus();
opt = get_sindy_options(cfg);
checks(end+1,1) = "production residual diagnostic disabled";
passed(end+1,1) = isfield(opt,'physicsNeuralCompositionalResidual') && ...
    ~logical(opt.physicsNeuralCompositionalResidual.enabled);

methods = get_offline_method_registry(cfg);
names = string({methods.name});
checks(end+1,1) = "production registry excludes residual diagnostic";
passed(end+1,1) = ~any(names=="pnc_residual_comp_sindy");

cfg.sindy.physicsNeuralCompositionalResidual.enabled = true;
methods2 = get_offline_method_registry(cfg);
names2 = string({methods2.name});
checks(end+1,1) = "diagnostic registry includes residual method";
passed(end+1,1) = any(names2=="pnc_residual_comp_sindy");

T = table(checks,passed,'VariableNames',{'Check','Passed'});
disp(T);
if ~all(passed)
    error('verify_pnc_residual_comp_patch:Failed', ...
        'PNC residual-composition patch verification failed.');
end
fprintf('\nPNC RESIDUAL-COMPOSITION PATCH VERIFICATION: PASSED\n');
fprintf('Contract: xdot_hat = f_PE_hat + Phi_comp(chi,f_PE_hat)*Xi_c; Xi_c=0 exactly recovers PE.\n');
end
