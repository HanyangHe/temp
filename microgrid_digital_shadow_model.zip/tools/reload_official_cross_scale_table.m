function report = reload_official_cross_scale_table(projectRoot,caseName)
%RELOAD_OFFICIAL_CROSS_SCALE_TABLE Build IEEE TSG Table V from SAVED offline runs.
%
% Single-case interface (backward-compatible):
%   R = reload_official_cross_scale_table(pwd,'69bus');
%
% Selected-case interface (NEW):
%   R = reload_official_cross_scale_table(pwd,["10bus","69bus"]);
%   R = reload_official_cross_scale_table(pwd,{'10bus','69bus','123bus'});
%   R = reload_official_cross_scale_table(pwd,{'69bus'}); % batch output, 1 case
% MATLAB IMPORTANT: ['10bus','69bus'] concatenates text into '10bus69bus'.
% Use ["10bus","69bus"] or {'10bus','69bus'} instead.
%
% READ-ONLY SCIENTIFIC INPUTS (never retrains, integrates, or changes them):
% outputs/offline_model_experiments_<case>/seed_runs/seed_<dataSeed>/ ...
%     method_results/<method>/offline_part1_method_replay.mat
%       methodBundle.report.section1p2.table  clean N=250,750,2000
%       methodBundle.report.section1p3.table  noise=0.5%,5%, N=500
%
% WRITES ONLY to per-case outputs/.../paper_cross_scale_table/ and (when
% selecting a case list) outputs/paper_cross_scale_table/.
% Missing, incompatible, duplicated, or invalid saved conditions are marked
% PENDING, never reported as zero, and never counted as failed rollouts.
% The mean and MATLAB sample std(v,0) include ONLY successful rollouts.
% Any completed failure counts toward the denominator, not the RMSE mean.
%
% LLM-PRIOR DISCOVERY-SEED POLICY (2026-10-08 repair):
%   DATA SEED and LLM discovery seed are independent experimental identifiers.
%   Valid three-seed cohorts can use (a) one prior bank per data seed or
%   (b) one identical, fixed discovery prior bank for all data seeds.
%   The 69-bus V4 refresh used option (b), discovery seed 20260814 for data
%   seeds 20260814--20260816. Neither option can silently mix with the other.
%   Each LLM condition is also verified against its own saved cache key;
%   preserved pre-V4 sections from an incremental bundle merge are rejected.
%
% Output files:
%   cross_scale_<case>_per_seed_audit.csv     one row per method/condition/seed
%   cross_scale_<case>_numerical.csv         30 paper cells with exact numbers
%   cross_scale_<case>_rows.tex              six rows for that case
%   cross_scale_all_systems.tex              complete table: other cases pending
% Batch mode also writes outputs/paper_cross_scale_table/ with a combined
%   18-row full table, selected-case rows, merged numerical and audit CSVs.
%   cross_scale_<case>_report.mat            report and source metadata
%   cross_scale_<case>_README.txt            audit summary
%
% Requires MATLAB and the existing project utils/load_mat_long_path_safe.m.

if nargin < 1 || isempty(projectRoot), projectRoot = pwd; end
if nargin < 2 || isempty(caseName), caseName = "69bus"; end
projectRoot = char(string(projectRoot));
batchRequested = iscell(caseName) || (isstring(caseName) && numel(caseName)>1);
cases = lower(strtrim(string(caseName)));
cases = reshape(cases,1,[]);
allowed = ["10bus","69bus","123bus"];
if isempty(cases) || any(ismissing(cases)) || any(~ismember(cases,allowed))
    error('reload_official_cross_scale_table:Case', ...
        ['Case must be 10bus, 69bus, or 123bus. For multiple cases, use ', ...
         '["10bus","69bus"] or {''10bus'',''69bus''}. ', ...
         'MATLAB [''10bus'',''69bus''] concatenates character arrays.']);
end
if numel(unique(cases)) ~= numel(cases)
    error('reload_official_cross_scale_table:DuplicateCase', ...
        'Each selected case must appear only once.');
end
if batchRequested
    report = local_reload_selected_cases(projectRoot,cases);
    return;
end
caseName = char(cases);
if ~exist(fullfile(projectRoot,'config_offline_experiment_69bus.m'),'file')
    error('reload_official_cross_scale_table:ProjectRoot', ...
        'projectRoot must be microgrid_digital_shadow_model, not outputs or tools.');
end
addpath(projectRoot,fullfile(projectRoot,'utils'));
configFcn = str2func(['config_offline_experiment_' caseName]);
cfg = configFcn();
seeds = round(double(cfg.randomSeeds(:).'));
if numel(seeds) ~= 3 || numel(unique(seeds)) ~= 3
    error('reload_official_cross_scale_table:Seeds', ...
        'This manuscript table expects precisely three distinct data seeds.');
end
if ~all(ismember([250 750 2000],double(cfg.sampleCounts(:).')))
    error('reload_official_cross_scale_table:SampleGrid','N=250,750,2000 not all in configuration.');
end
if ~all(ismembertol([0.005 0.05],double(cfg.noiseLevels(:).'),1e-10,'DataScale',1))
    error('reload_official_cross_scale_table:NoiseGrid','0.5%% and 5%% not both in configuration.');
end
if double(cfg.typicalSampleCount) ~= 500
    error('reload_official_cross_scale_table:TypicalN','Noise comparisons require N=500.');
end

methodKeys = ["modular_koopman_kbf","vanilla_sindy","physics_embedded_sindy", ...
    "edsi","neural_ode_modular","llm_prior_sindy"];
methodLabels = ["M-KBF","V-SINDy","PE-SINDy","ED-SINDy","NODE","LLM-Prior SINDy"];
methodPending = ["M","V","PE","ED","NODE","LLM"];
configuredMethods = string(cfg.run.methodsToRun(:)).';
if ~isequal(configuredMethods,methodKeys)
    error('reload_official_cross_scale_table:MethodSet', ...
        'Configured manuscript method list/order differs from the expected six methods.');
end

nM = numel(methodKeys);
nC = 5;
nS = numel(seeds);
conditionName = ["N250","N750","N2000","noise0p5","noise5"];
sampleN       = [250,750,2000,500,500];
noiseFraction = [0,0,0,0.005,0.05];
sectionName   = ["section1p2","section1p2","section1p2","section1p3","section1p3"];
baseRoot = fullfile(projectRoot,'outputs',char(string(cfg.output.folderName)));
if ~exist(baseRoot,'dir')
    error('reload_official_cross_scale_table:MissingOutputs', ...
        'Saved offline outputs were not found: %s',baseRoot);
end
seedFolder = 'seed_runs';
if isfield(cfg,'multiseed') && isfield(cfg.multiseed,'seedFolderName')
    seedFolder = char(string(cfg.multiseed.seedFolderName));
end
methodFolder = 'method_results';
if isfield(cfg.output,'methodResultsFolder')
    methodFolder = char(string(cfg.output.methodResultsFolder));
end
bundleFile = 'offline_part1_method_replay.mat';
if isfield(cfg.output,'methodReplayFileName')
    bundleFile = char(string(cfg.output.methodReplayFileName));
end

% The audit has exactly 6*5*3 records, including missing/incompatible data.
proto = struct('Case',"",'Method',"",'MethodKey',"",'Condition',"", ...
    'Section',"",'Seed',NaN,'SampleCount',NaN,'NoisePercent',NaN, ...
    'Status',"MISSING",'RolloutSucceeded',NaN,'RMSE',NaN,'Reason',"", ...
    'SourceFile',"",'BundleSavedAt',"", ...
    'LLMDiscoverySeed',NaN,'LLMPriorHash',"",'LLMDiscoveryProtocol',"");
rows = repmat(proto,nM*nC*nS,1);
for im=1:nM
    for is=1:nS
        seed = seeds(is);
        path = fullfile(baseRoot,seedFolder,sprintf('seed_%d',seed), ...
            methodFolder,char(methodKeys(im)),bundleFile);
        B = [];
        issue = "";
        if exist(path,'file') ~= 2
            issue = "Saved method replay MAT not found";
        else
            try
                loaded = load_mat_long_path_safe(path,'methodBundle');
                if isfield(loaded,'methodBundle') && isstruct(loaded.methodBundle)
                    B = loaded.methodBundle;
                    issue = local_bundle_compatibility(B,methodKeys(im),seed,cfg);
                else
                    issue = "MAT file lacks methodBundle structure";
                end
            catch ME
                issue = "Could not read saved MAT: " + string(ME.message);
            end
        end
        for ic=1:nC
            k = local_index(im,ic,is,nC,nS);
            a = proto;
            a.Case = string(caseName);
            a.Method = methodLabels(im);
            a.MethodKey = methodKeys(im);
            a.Condition = conditionName(ic);
            a.Section = sectionName(ic);
            a.Seed = seed;
            a.SampleCount = sampleN(ic);
            a.NoisePercent = 100*noiseFraction(ic);
            a.SourceFile = string(path);
            if ~isempty(B) && isfield(B,'savedAt')
                a.BundleSavedAt = string(B.savedAt);
            end
            if methodKeys(im)=="llm_prior_sindy"
                [a.LLMDiscoverySeed,a.LLMPriorHash, ...
                    a.LLMDiscoveryProtocol] = local_llm_saved_metadata(B);
            end
            if strlength(issue) > 0
                if exist(path,'file') == 2
                    a.Status = "INCOMPATIBLE";
                end
                a.Reason = issue;
                rows(k) = a;
                continue;
            end
            [a.Status,a.RolloutSucceeded,a.RMSE,a.Reason] = ...
                local_one_saved_condition(B,sectionName(ic),methodKeys(im), ...
                sampleN(ic),noiseFraction(ic));
            rows(k) = a;
        end
        clear B loaded;
    end
end
Audit = struct2table(rows);
% Guard against mixing per-seed LLM banks with a partially refreshed
% fixed-prior cohort even when each individual MAT passes version checks.
[Audit,llmPriorSeedPolicy] = local_verify_llm_seed_cohort(Audit,seeds);
if isfield(cfg,'multiseed') && isfield(cfg.multiseed,'llmPriorDiscoveryPolicy') && ...
        strcmpi(string(cfg.multiseed.llmPriorDiscoveryPolicy),'fixed_bank')
    expectedPolicy="FIXED_DISCOVERY_SEED_"+ ...
        string(round(double(cfg.multiseed.llmPriorFixedDiscoverySeed)))+ ...
        "_HASH_"+string(cfg.multiseed.llmPriorExpectedBankHash);
    if ~strcmpi(llmPriorSeedPolicy,expectedPolicy)
        bad=(string(Audit.MethodKey)=="llm_prior_sindy");
        ix=find(bad & ismember(string(Audit.Status),["SUCCESS","FAILED"]));
        for j=reshape(ix,1,[])
            Audit.Status(j)="INCOMPATIBLE";
            Audit.RolloutSucceeded(j)=NaN;
            Audit.RMSE(j)=NaN;
            Audit.Reason(j)="LLM seed cohort is not the verified fixed-bank protocol";
        end
        llmPriorSeedPolicy="INCOMPATIBLE_EXPECTED_"+expectedPolicy;
    end
end

% Numerical table: one row per METHOD x target CONDITION.
resultsProto = struct('Case',"",'Method',"",'MethodKey',"", ...
    'Condition',"",'SampleCount',NaN,'NoisePercent',NaN, ...
    'ExpectedSeedCount',nS,'PresentSeedCount',0,'SuccessCount',0, ...
    'MeanRMSE',NaN,'StdRMSE',NaN,'Status',"PENDING",'CellTeX',"");
resRows = repmat(resultsProto,nM*nC,1);
for im=1:nM
    for ic=1:nC
        p = (im-1)*nC+ic;
        indices = arrayfun(@(is)local_index(im,ic,is,nC,nS),1:nS);
        Q = Audit(indices,:);
        goodRecords = ismember(string(Q.Status),["SUCCESS","FAILED"]);
        complete = all(goodRecords);
        goodRollouts = string(Q.Status)=="SUCCESS";
        r = resultsProto;
        r.Case = string(caseName);
        r.Method = methodLabels(im);
        r.MethodKey = methodKeys(im);
        r.Condition = conditionName(ic);
        r.SampleCount = sampleN(ic);
        r.NoisePercent = 100*noiseFraction(ic);
        r.PresentSeedCount = nnz(goodRecords);
        r.SuccessCount = nnz(goodRollouts);
        if complete
            vals = double(Q.RMSE(goodRollouts));
            if ~isempty(vals)
                r.MeanRMSE = mean(vals);
                if numel(vals)==1
                    r.StdRMSE = 0;  % official aggregator's single-success convention
                else
                    r.StdRMSE = std(vals,0);  % sample standard deviation (N-1)
                end
                if r.SuccessCount == nS
                    r.Status = "COMPLETE";
                else
                    r.Status = "COMPLETE_WITH_FAILURES";
                end
            else
                r.Status = "ALL_FAILED";
            end
            r.CellTeX = local_format_latex(r.MeanRMSE,r.StdRMSE,r.SuccessCount,nS);
        else
            r.Status = "PENDING";
            r.CellTeX = "\pending{" + caseName(1:end-3) + " " + ...
                methodPending(im) + " " + local_pending_suffix(ic) + "}";
        end
        resRows(p) = r;
    end
end
Numerical = struct2table(resRows);

% Never modify original per-seed bundles or canonical figures/summaries.
outDir = fullfile(baseRoot,'paper_cross_scale_table');
if ~exist(outDir,'dir'), mkdir(outDir); end
prefix = ['cross_scale_' caseName];
auditCsv = fullfile(outDir,[prefix '_per_seed_audit.csv']);
numericCsv = fullfile(outDir,[prefix '_numerical.csv']);
rowsTex = fullfile(outDir,[prefix '_rows.tex']);
fullTex = fullfile(outDir,'cross_scale_all_systems.tex');
readme = fullfile(outDir,[prefix '_README.txt']);
reportMat = fullfile(outDir,[prefix '_report.mat']);
writetable(Audit,auditCsv);
writetable(Numerical,numericCsv);
local_write_case_rows(rowsTex,caseName,Numerical);
local_write_full_table(fullTex,string(caseName),{Numerical},methodLabels,methodPending);

report = struct();
report.caseName = caseName;
report.projectRoot = projectRoot;
report.officialConfig = ['config_offline_experiment_' caseName];
report.sourceMode = 'per_seed_independent_method_replay_bundles_only';
report.seeds = seeds;
report.cleanMiddleSampleCount = 750;
report.noiseSampleCount = 500;
report.llmPriorSeedPolicy = llmPriorSeedPolicy;
report.audit = Audit;
report.numerical = Numerical;
report.completeCells = nnz(Numerical.Status~="PENDING");
report.pendingCells = nnz(Numerical.Status=="PENDING");
report.outputDir = outDir;
report.rowsTex = rowsTex;
report.fullTex = fullTex;
report.auditCsv = auditCsv;
report.numericCsv = numericCsv;
save(reportMat,'report','-v7');

fid=local_open(readme);
c=onCleanup(@()fclose(fid));
fprintf(fid,'OFFICIAL CROSS-SCALE TABLE EXTRACTION -- %s\n',upper(caseName));
fprintf(fid,'Generated: %s\n',char(datetime('now','Format','yyyy-MM-dd HH:mm:ss')));
fprintf(fid,'Source mode: per-seed methodBundle.report.section1p2/section1p3.table\n');
fprintf(fid,'Input root: %s\n',baseRoot);
fprintf(fid,'Data seeds: %s\n',strtrim(sprintf('%d ',seeds)));
fprintf(fid,'Verified LLM prior seed policy: %s\n',char(llmPriorSeedPolicy));
fprintf(fid,'Case output folder: %s\n',outDir);
fprintf(fid,'Official convention: successful-only RMSE mean +/- sample std, success n/3.\n');
fprintf(fid,'MISSING/INCOMPATIBLE/INVALID/DUPLICATE => PENDING, not numerical failure.\n');
fprintf(fid,'Number of complete paper cells: %d/30\n',report.completeCells);
fprintf(fid,'Number of pending cells: %d/30\n\n',report.pendingCells);
for im=1:nM
    fprintf(fid,'%s\n',char(methodLabels(im)));
    for ic=1:nC
        r = Numerical((im-1)*nC+ic,:);
        fprintf(fid,'  %-8s : %-23s | present=%d/3, success=%d/3, mean=%.12g, std=%.12g\n', ...
            char(conditionName(ic)),char(r.Status),r.PresentSeedCount,r.SuccessCount,r.MeanRMSE,r.StdRMSE);
        if r.Status=="PENDING"
            z = Audit((im-1)*nC*nS+(ic-1)*nS+(1:nS),:);
            for j=1:height(z)
                if ~ismember(z.Status(j),["SUCCESS","FAILED"])
                    fprintf(fid,'      seed=%d %s: %s\n',z.Seed(j),char(z.Status(j)),char(z.Reason(j)));
                end
            end
        end
    end
end
clear c;

fprintf('\n===============================================\n');
fprintf('Paper cross-scale extraction: %s\n',caseName);
fprintf('Completed cells: %d/30 | Pending: %d/30\n',report.completeCells,report.pendingCells);
fprintf('LLM prior discovery-seed policy: %s\n',char(llmPriorSeedPolicy));
fprintf('Per-seed audit: %s\n',auditCsv);
fprintf('Numerical CSV : %s\n',numericCsv);
fprintf('Six LaTeX rows: %s\n',rowsTex);
fprintf('Full LaTeX table: %s\n',fullTex);
fprintf('No training, rollout, input-data generation or LLM calls.\n');
fprintf('===============================================\n');
if report.pendingCells>0
    badLLM = Audit(string(Audit.MethodKey)=="llm_prior_sindy" & ...
        ~ismember(string(Audit.Status),["SUCCESS","FAILED"]),:);
    if ~isempty(badLLM)
        fprintf('LLM-Prior saved-record diagnostics (no model work performed):\n');
        for j=1:height(badLLM)
            fprintf('  data seed %d | discovery %g | %-8s | %-12s : %s\n', ...
                badLLM.Seed(j),badLLM.LLMDiscoverySeed(j), ...
                char(badLLM.Condition(j)),char(badLLM.Status(j)), ...
                char(badLLM.Reason(j)));
        end
    end
    warning('reload_official_cross_scale_table:Pending', ...
        '%d/30 entries remain pending. Inspect the per-seed audit CSV and README.',report.pendingCells);
end
end

function k = local_index(im,ic,is,nC,nS)
k = (im-1)*nC*nS + (ic-1)*nS + is;
end

function textOut = local_pending_suffix(ic)
switch ic
    case 1, textOut="250";
    case 2, textOut="750";
    case 3, textOut="2000";
    case 4, textOut="n05";
    otherwise, textOut="n5";
end
end

function issue = local_bundle_compatibility(B,expectedMethod,seed,cfg)
issue="";
if ~isfield(B,'methodName') || ~strcmpi(string(B.methodName),expectedMethod)
    issue="Saved bundle method name does not match requested method"; return;
end
if ~isfield(B,'config') || ~isstruct(B.config) || ...
        ~isfield(B.config,'randomSeed') || double(B.config.randomSeed)~=seed
    issue="Saved bundle seed does not match requested data seed"; return;
end
b=B.config;
if ~isfield(B,'report') || ~isstruct(B.report)
    issue="Saved bundle has no report structure"; return;
end
if any(expectedMethod==["vanilla_sindy","physics_embedded_sindy","llm_prior_sindy"])
    if ~isfield(b,'sindy') || ~isstruct(b.sindy) || ...
            ~isfield(b.sindy,'polyOrderOption') || ...
            ~isequal(double(b.sindy.polyOrderOption),double(cfg.sindy.polyOrderOption))
        issue="SINDy polynomial dictionary protocol differs"; return;
    end
    if ~isfield(b.sindy,'formulationVersion') || ...
            ~strcmp(string(b.sindy.formulationVersion),string(cfg.sindy.formulationVersion))
        issue="Saved SINDy formulationVersion is not the current official version"; return;
    end
    if ~isfield(b.sindy,'stlsq') || ~isfield(b.sindy.stlsq,'finalSupportRidgeRho') || ...
            ~isequal(double(b.sindy.stlsq.finalSupportRidgeRho), ...
                     double(cfg.sindy.stlsq.finalSupportRidgeRho))
        issue="Saved final-support SINDy ridge rho differs from the official value"; return;
    end
end
if expectedMethod=="llm_prior_sindy"
    if ~isfield(b.sindy,'llmPrior') || ~isstruct(b.sindy.llmPrior)
        issue="Saved bundle has no LLM prior metadata"; return;
    end
    p=b.sindy.llmPrior;
    q=cfg.sindy.llmPrior;
    if ~isfield(p,'formulationVersion') || ...
            ~strcmp(string(p.formulationVersion),string(q.formulationVersion)) || ...
            ~isfield(p,'discoveryProtocolVersion') || ...
            ~strcmp(string(p.discoveryProtocolVersion),string(q.discoveryProtocolVersion)) || ...
            ~isfield(p,'discoverySeed') || ~isnumeric(p.discoverySeed) || ...
            ~isscalar(p.discoverySeed) || ~isfinite(double(p.discoverySeed)) || ...
            double(p.discoverySeed)<=0 || ...
            double(p.discoverySeed)~=round(double(p.discoverySeed)) || ...
            ~isfield(p,'priorBankHash') || strlength(string(p.priorBankHash))==0
        issue="Incompatible or unidentified LLM prior-bank protocol/discovery seed/hash"; return;
    end
    % The fixed prior-bank protocol is not the same as a data-seed-specific
    % LLM realization. All networks must use the SAME frozen physical bank.
    if isfield(cfg,'multiseed') && isstruct(cfg.multiseed) && ...
            isfield(cfg.multiseed,'llmPriorDiscoveryPolicy') && ...
            strcmpi(string(cfg.multiseed.llmPriorDiscoveryPolicy),'fixed_bank')
        if ~isfield(cfg.multiseed,'llmPriorFixedDiscoverySeed') || ...
                ~isfield(cfg.multiseed,'llmPriorExpectedBankHash') || ...
                double(p.discoverySeed) ~= ...
                    double(cfg.multiseed.llmPriorFixedDiscoverySeed) || ...
                ~strcmpi(string(p.priorBankHash), ...
                    string(cfg.multiseed.llmPriorExpectedBankHash))
            issue="LLM prior discovery seed/hash does not match the required fixed-bank manuscript protocol";
            return;
        end
    end
end
if expectedMethod=="edsi"
    if ~isfield(b,'edsi') || ~isstruct(b.edsi) || ...
            ~isfield(b.edsi,'formulationVersion') || ...
            ~strcmp(string(b.edsi.formulationVersion),string(cfg.edsi.formulationVersion)) || ...
            ~isfield(b.edsi,'evolutionSearchSeed') || ...
            ~isequal(double(b.edsi.evolutionSearchSeed),double(cfg.edsi.evolutionSearchSeed))
        issue="ED-SINDy formulation/search protocol mismatch"; return;
    end
end
if expectedMethod=="neural_ode_modular"
    if ~isfield(b,'node') || ~isstruct(b.node) || ...
            ~isfield(b.node,'trainingProtocolVersion') || ...
            ~strcmp(string(b.node.trainingProtocolVersion), ...
                    string(cfg.node.trainingProtocolVersion))
        issue="NODE trainingProtocolVersion mismatch"; return;
    end
end
if expectedMethod=="modular_koopman_kbf"
    if ~isfield(b,'koopman') || ~isfield(b.koopman,'formulationVersion') || ...
            ~strcmp(string(b.koopman.formulationVersion), ...
                    string(cfg.koopman.formulationVersion))
        issue="M-KBF formulationVersion mismatch"; return;
    end
end
end

function [status,success,rmse,reason] = local_one_saved_condition(B,section,method,N,noise)
status="MISSING"; success=NaN; rmse=NaN; reason="";
sec=char(section);
if ~isfield(B.report,sec) || ~isstruct(B.report.(sec)) || ...
        ~isfield(B.report.(sec),'table') || ...
        ~istable(B.report.(sec).table) || isempty(B.report.(sec).table)
    reason="No saved section report table"; return;
end
T=B.report.(sec).table;
need={'Method','SampleCount','RolloutSucceeded','RMSE'};
if ~all(ismember(need,T.Properties.VariableNames)) || ...
        ~any(ismember({'NoiseLevel','NoisePercent'},T.Properties.VariableNames))
    status="INVALID"; reason="Required scientific report columns missing"; return;
end
if ismember('NoiseLevel',T.Properties.VariableNames)
    qNoise=double(T.NoiseLevel);
else
    qNoise=double(T.NoisePercent)/100;
end
ix=strcmpi(string(T.Method),method) & ...
    abs(double(T.SampleCount)-N)<1e-9 & abs(qNoise-noise)<1e-10;
num=nnz(ix);
if num==0
    reason="Requested condition not present in saved section table"; return;
elseif num>1
    status="DUPLICATE";
    reason="More than one row found for this method/seed/condition"; return;
end
[provenanceOK,provenanceReason] = ...
    local_verify_saved_condition_key(T,find(ix,1),B,method,N,noise);
if ~provenanceOK
    status="INCOMPATIBLE"; reason=provenanceReason; return;
end
rawSuccess = T.RolloutSucceeded(ix);
if ~(islogical(rawSuccess) || isnumeric(rawSuccess)) || ...
        numel(rawSuccess)~=1 || ~isfinite(double(rawSuccess)) || ...
        ~ismember(double(rawSuccess),[0 1])
    status="INVALID"; reason="RolloutSucceeded is not a valid scalar 0/1"; return;
end
success=double(rawSuccess);
rmse=double(T.RMSE(ix));
if success==1 && isfinite(rmse) && rmse>=0
    status="SUCCESS";
elseif success==0 && isnan(rmse)
    status="FAILED";
    reason="Completed rollout failure (full-window RMSE is NaN)";
else
    status="INVALID";
    reason="RolloutSucceeded and full-window RMSE are inconsistent/invalid";
end
end

function [discoverySeed,bankHash,protocol] = local_llm_saved_metadata(B)
% The discovery seed is NOT the data seed. Read the stored value faithfully.
discoverySeed=NaN;
bankHash="";
protocol="";
if isempty(B) || ~isstruct(B) || ~isfield(B,'config') || ...
        ~isstruct(B.config) || ~isfield(B.config,'sindy') || ...
        ~isstruct(B.config.sindy) || ~isfield(B.config.sindy,'llmPrior') || ...
        ~isstruct(B.config.sindy.llmPrior)
    return;
end
p=B.config.sindy.llmPrior;
if isfield(p,'discoverySeed') && isnumeric(p.discoverySeed) && ...
        isscalar(p.discoverySeed) && isfinite(double(p.discoverySeed))
    discoverySeed=double(p.discoverySeed);
end
if isfield(p,'priorBankHash') && ~isempty(p.priorBankHash)
    bankHash=string(p.priorBankHash);
end
if isfield(p,'discoveryProtocolVersion') && ...
        ~isempty(p.discoveryProtocolVersion)
    protocol=string(p.discoveryProtocolVersion);
end
end

function [Audit,policy] = local_verify_llm_seed_cohort(Audit,seeds)
% Accept either:
%   A) discoverySeed_i = dataSeed_i, independently generated prior banks;
%   B) discoverySeed_i = one fixed seed AND all bank hashes identical.
% A mixture is unsafe even if a bundle's latest config looks compatible.
policy="INCOMPLETE_PRIOR_METADATA";
llmMask=string(Audit.MethodKey)=="llm_prior_sindy";
if ~any(llmMask), policy="NOT_SELECTED"; return; end
discoverySeeds=nan(1,numel(seeds));
hashes=strings(1,numel(seeds));
for i=1:numel(seeds)
    ix=find(llmMask & double(Audit.Seed)==seeds(i),1,'first');
    if isempty(ix), return; end
    discoverySeeds(i)=double(Audit.LLMDiscoverySeed(ix));
    hashes(i)=string(Audit.LLMPriorHash(ix));
end
if any(~isfinite(discoverySeeds)) || any(strlength(hashes)==0)
    return;
end
independent=all(discoverySeeds==double(seeds(:).'));
fixed=all(discoverySeeds==discoverySeeds(1)) && ...
    all(strcmpi(hashes,hashes(1)));
if independent
    policy="PER_DATA_SEED_DISCOVERY";
elseif fixed
    policy="FIXED_DISCOVERY_SEED_"+string(discoverySeeds(1)) + ...
        "_HASH_"+hashes(1);
else
    policy="INVALID_MIXED_LLM_PRIOR_BANKS";
    bad=find(llmMask & ismember(string(Audit.Status),["SUCCESS","FAILED"]));
    for j=reshape(bad,1,[])
        Audit.Status(j)="INCOMPATIBLE";
        Audit.RolloutSucceeded(j)=NaN;
        Audit.RMSE(j)=NaN;
        Audit.Reason(j)="Mixed fixed/per-data LLM discovery seeds or inconsistent shared-bank hashes across data seeds";
    end
end
end

function [ok,reason] = local_verify_saved_condition_key(T,idx,B,method,N,noise)
% Require evidence that THIS row belongs to THIS data seed/condition.
% This prevents stale per-condition results surviving an incremental merge.
ok=false;
reason="";
if ~ismember('EvaluationCacheKey',T.Properties.VariableNames)
    reason="Saved condition lacks EvaluationCacheKey; provenance is unverifiable";
    return;
end
key=strtrim(string(T.EvaluationCacheKey(idx)));
if strlength(key)==0 || ismissing(key)
    reason="Saved condition has an empty EvaluationCacheKey";
    return;
end
parts=split(key,"|");
seed=round(double(B.config.randomSeed));
required=[ ...
    "N="+string(N), ...
    "noise="+string(sprintf('%.17g',noise)), ...
    "seed="+string(seed)];
if ~startsWith(key,string(method)+"|") || ...
        ~all(ismember(lower(required),lower(parts))) || ...
        ~any(startsWith(parts,"protocol="))
    reason="Saved condition cache key has different method/N/noise/data seed or missing data protocol";
    return;
end
if any(string(method)==["vanilla_sindy","physics_embedded_sindy"])
    if ~ismember("sindy_arch="+string(B.config.sindy.formulationVersion),parts)
        reason="Saved SINDy row does not match the official regression architecture";
        return;
    end
elseif string(method)=="edsi"
    if ~ismember("edsi_arch="+string(B.config.edsi.formulationVersion),parts)
        reason="Saved ED-SINDy row does not match the official evolution architecture";
        return;
    end
end
if string(method)=="llm_prior_sindy"
    [ok,reason]=local_verify_llm_condition_key(T,idx,B,N,noise);
else
    ok=true;
end
end

function [ok,reason] = local_verify_llm_condition_key(T,idx,B,N,noise)
% A newer V4 config can be merged over older V3 condition rows. Therefore
% bundle-level version metadata alone cannot establish scientific validity.
% Verify the SAVED ROW's provenance rather than accepting the latest config.
ok=false;
reason="";
if ~ismember('EvaluationCacheKey',T.Properties.VariableNames)
    reason="LLM condition lacks EvaluationCacheKey; prior provenance cannot be verified";
    return;
end
key=strtrim(string(T.EvaluationCacheKey(idx)));
if numel(key)~=1 || ismissing(key) || strlength(key)==0
    reason="LLM condition has missing or empty EvaluationCacheKey";
    return;
end
p=B.config.sindy.llmPrior;
s=B.config.sindy;
seed=double(B.config.randomSeed);
required=[ ...
    "N="+string(N), ...
    "noise="+string(sprintf('%.17g',noise)), ...
    "seed="+string(round(seed)), ...
    "sindy_arch="+string(s.formulationVersion), ...
    "llm_prior_arch="+string(p.formulationVersion), ...
    "discovery_protocol="+string(p.discoveryProtocolVersion), ...
    "discovery_seed="+string(round(double(p.discoverySeed))), ...
    "prior_hash="+string(p.priorBankHash)];
parts=split(key,"|");
if ~startsWith(key,"llm_prior_sindy|") || ...
        ~all(ismember(lower(required),lower(parts)))
    reason="Saved LLM condition cache key differs from current bundle's data seed/N/noise/prior protocol/hash (possible preserved pre-V4 condition)";
    return;
end
ok=true;
end

function out = local_format_latex(meanValue,stdValue,success,nExpected)
if success==0
    out="$\text{--}\;(" + string(success) + "/" + string(nExpected) + ")$";
    return;
end
if meanValue==0
    out="$0\pm"+string(sprintf('%.2g',stdValue))+"\;("+ ...
        string(success)+"/"+string(nExpected)+")$";
    return;
end
power = floor(log10(meanValue));
scale = 10^power;
x = meanValue/scale;
y = stdValue/scale;
% Use the same exponent for the mean and sample std, so parentheses are exact.
if y==0
    decimals=2;
else
    % Two significant digits for the std, avoiding a misleading '+/- 0.00'.
    decimals=max(2,min(5,1-floor(log10(y))));
end
fmt=['$(%.' num2str(decimals) 'f\\pm%.' num2str(decimals) ...
    'f)\\!\\times\\!10^{%d}\\;(%d/%d)$'];
out=string(sprintf(fmt,x,y,power,success,nExpected));
end

function local_write_case_rows(path,caseName,Numerical)
fid=local_open(path); c=onCleanup(@()fclose(fid));
local_line(fid,"% Generated from saved official method bundles; never hand-edit numbers.");
local_line(fid,"% " + caseName + ": Section 1.2 (N250/750/2000) + Section 1.3 (0.5/5% noise at N500).");
rowBreak = string(char([92 92]));
for im=1:6
    q=Numerical((im-1)*5+(1:5),:);
    if im==1, prefix=[caseName(1:end-3) '-bus']; else, prefix=''; end
    if im==6, name="\textbf{LLM-Prior SINDy}"; else, name=q.Method(1); end
    fields=[string(prefix),name,string(q.CellTeX(:)).'];
    local_line(fid,strjoin(fields," & ")+" "+rowBreak);
end
clear c;
end

function local_write_full_table(path,selectedCases,selectedNumerical,methodLabels,methodPending)
% Only include cases verified in THIS invocation, never stale exported CSVs.
allCases = ["10bus","69bus","123bus"];
assert(numel(selectedCases)==numel(selectedNumerical), ...
    'selectedCases and selectedNumerical must match.');
selectedCases = string(selectedCases);
allRows = strings(18,7);
ri = 0;
for icase=1:numel(allCases)
    cname = allCases(icase);
    matchedCase = find(selectedCases==cname,1);
    Q=table();
    if ~isempty(matchedCase)
        Q=selectedNumerical{matchedCase};
        expectedMethods = ["M-KBF","V-SINDy","PE-SINDy","ED-SINDy","NODE","LLM-Prior SINDy"];
        expectedConditions = ["N250","N750","N2000","noise0p5","noise5"];
        if height(Q)~=30 || ~all(ismember({'Method','Condition','CellTeX'}, ...
                Q.Properties.VariableNames))
            error('reload_official_cross_scale_table:CombinedTable', ...
                'Invalid numerical table for %s.',char(cname));
        end
        for m=1:6
            for j=1:5
                if nnz(string(Q.Method)==expectedMethods(m) & ...
                        string(Q.Condition)==expectedConditions(j))~=1
                    error('reload_official_cross_scale_table:CombinedTable', ...
                        'Missing/duplicate %s row in %s.',char(expectedMethods(m)),char(cname));
                end
            end
        end
    end
    for im=1:6
        ri=ri+1;
        if im==1, allRows(ri,1)=extractBefore(cname,'bus')+'-bus'; else, allRows(ri,1)=""; end
        if im==6
            allRows(ri,2)="\textbf{LLM-Prior SINDy}";
        else
            allRows(ri,2)=methodLabels(im);
        end
        target=["N250","N750","N2000","noise0p5","noise5"];
        for j=1:5
            cellTex="\pending{"+extractBefore(cname,'bus')+" "+ ...
                methodPending(im)+" "+local_pending_suffix(j)+"}";
            if ~isempty(Q)
                ix = find(string(Q.Method)==methodLabels(im) & string(Q.Condition)==target(j));
                cellTex = string(Q.CellTeX(ix));
            end
            allRows(ri,j+2)=cellTex;
        end
    end
end
fid=local_open(path); c=onCleanup(@()fclose(fid));
rowBreak=string(char([92 92]));
local_line(fid,"% Official cross-scale table; selected cases only, other cases explicitly pending.");
local_line(fid,"% Requires the manuscript \pending macro for incomplete cases.");
local_line(fid,"% Sources: compatible saved per-seed method replay bundles, Section 1.2/1.3.");
local_line(fid,"\begin{table*}[!t]");
local_line(fid,"\centering");
local_line(fid,"\caption{Cross-Scale Trajectory RMSE and Rollout Success}");
local_line(fid,"\label{tab:cross_scale_summary}");
local_line(fid,"\scriptsize");
local_line(fid,"\setlength{\tabcolsep}{5pt}");
local_line(fid,"\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}llccccc@{}}");
local_line(fid,"\toprule");
local_line(fid,"System & Method & $N_s=250$ & $N_s=750$ & $N_s=2000$ & $\eta=0.5\%$ & $\eta=5\%$ "+rowBreak);
local_line(fid,"\midrule");
for k=1:18
    local_line(fid,strjoin(allRows(k,:)," & ")+" "+rowBreak);
    if ismember(k,[6 12]), local_line(fid,"\midrule"); end
end
local_line(fid,"\bottomrule");
local_line(fid,"\end{tabular*}");
local_line(fid,"\par\smallskip");
local_line(fid,"\parbox{\textwidth}{\scriptsize Entries report mean $\pm$ sample standard deviation over successful rollouts and success count $(s/3)$; noisy conditions use $N_s=500$. Pending entries indicate missing, incomplete, or incompatible saved records.}");
local_line(fid,"\end{table*}");
clear c;
end

function batch = local_reload_selected_cases(projectRoot,cases)
% Run each requested case once; combine only the newly verified reports.
projectRoot=char(string(projectRoot));
if ~exist(fullfile(projectRoot,'config_offline_experiment_69bus.m'),'file')
    error('reload_official_cross_scale_table:ProjectRoot', ...
        'Project root must contain config_offline_experiment_69bus.m.');
end
n=numel(cases);
perCase=cell(1,n);
for k=1:n
    fprintf('\nProcessing saved %s results (%d/%d)...\n',char(cases(k)),k,n);
    perCase{k}=reload_official_cross_scale_table(projectRoot,char(cases(k)));
end

% Combine in paper order, independent of the user's requested order.
allCases=["10bus","69bus","123bus"];
orderedCases=allCases(ismember(allCases,cases));
Q=cell(1,numel(orderedCases));
allNumeric=cell(1,numel(orderedCases));
allAudit=cell(1,numel(orderedCases));
for k=1:numel(orderedCases)
    id=find(cases==orderedCases(k),1);
    Q{k}=perCase{id};
    allNumeric{k}=Q{k}.numerical;
    allAudit{k}=Q{k}.audit;
end
Numeric=vertcat(allNumeric{:});
Audit=vertcat(allAudit{:});

outDir=fullfile(projectRoot,'outputs','paper_cross_scale_table');
if ~exist(outDir,'dir'),mkdir(outDir);end
fullTex=fullfile(outDir,'cross_scale_all_systems.tex');
rowsTex=fullfile(outDir,'cross_scale_selected_cases_rows.tex');
numericCsv=fullfile(outDir,'cross_scale_selected_cases_numerical.csv');
auditCsv=fullfile(outDir,'cross_scale_selected_cases_per_seed_audit.csv');
reportMat=fullfile(outDir,'cross_scale_selected_cases_report.mat');
readme=fullfile(outDir,'cross_scale_selected_cases_README.txt');
methodLabels=["M-KBF","V-SINDy","PE-SINDy","ED-SINDy","NODE","LLM-Prior SINDy"];
methodPending=["M","V","PE","ED","NODE","LLM"];
local_write_full_table(fullTex,orderedCases,allNumeric,methodLabels,methodPending);
writetable(Numeric,numericCsv);
writetable(Audit,auditCsv);

fid=local_open(rowsTex); c=onCleanup(@()fclose(fid));
local_line(fid,"% Selected cases only; paste into the existing table rows in system order.");
for k=1:numel(orderedCases)
    tmp=fullfile(Q{k}.outputDir,['cross_scale_' char(orderedCases(k)) '_rows.tex']);
    if exist(tmp,'file')~=2
        error('reload_official_cross_scale_table:MissingRows', ...
            'Generated rows unavailable: %s',tmp);
    end
    local_line(fid,"% ---- "+orderedCases(k)+" ----");
    raw=fileread(tmp);
    fprintf(fid,'%s',raw);
end
clear c;

batch=struct();
batch.cases=orderedCases;
batch.cleanMiddleSampleCount=750;
batch.noiseSampleCount=500;
batch.requestedCases=cases;
batch.projectRoot=projectRoot;
batch.perCase=perCase;
batch.numerical=Numeric;
batch.audit=Audit;
batch.completeCells=nnz(Numeric.Status~="PENDING");
batch.pendingCells=nnz(Numeric.Status=="PENDING");
batch.outputDir=outDir;
batch.rowsTex=rowsTex;
batch.fullTex=fullTex;
batch.numericCsv=numericCsv;
batch.auditCsv=auditCsv;
save(reportMat,'batch','-v7');

fid=local_open(readme); c=onCleanup(@()fclose(fid));
fprintf(fid,'OFFICIAL CROSS-SCALE TABLE -- SELECTED CASES\n');
fprintf(fid,'Cases: %s\n',strjoin(cellstr(orderedCases),', '));
fprintf(fid,'Use only saved compatible per-seed method replay bundles; no reruns.\n');
fprintf(fid,'Selected cases: %d, total cells: %d; complete: %d; pending: %d.\n', ...
    n,height(Numeric),batch.completeCells,batch.pendingCells);
fprintf(fid,'Unselected 10/69/123bus cases remain explicit placeholders in full LaTeX.\n');
fprintf(fid,'Saved CSV from unselected cases is NEVER merged automatically.\n\n');
for k=1:numel(orderedCases)
    fprintf(fid,'%s: completed %d/30; pending %d/30\n', ...
        char(orderedCases(k)),Q{k}.completeCells,Q{k}.pendingCells);
end
fprintf(fid,'\nFull LaTeX table: %s\nSelected rows: %s\n',fullTex,rowsTex);
clear c;

fprintf('\n===============================================\n');
fprintf('Selected-case saved-result extraction complete: %s\n',strjoin(cellstr(orderedCases),', '));
fprintf('Complete cells: %d/%d | Pending cells: %d\n', ...
    batch.completeCells,height(Numeric),batch.pendingCells);
fprintf('Combined LaTeX table: %s\n',fullTex);
fprintf('Selected rows: %s\n',rowsTex);
fprintf('Numerical CSV: %s\n',numericCsv);
fprintf('Per-seed audit: %s\n',auditCsv);
fprintf('No experiments were re-run.\n');
fprintf('===============================================\n');
end

function local_line(fid,s)
fprintf(fid,'%s\n',char(string(s)));
end

function fid=local_open(file)
[fid,msg]=fopen(file,'w','n','UTF-8');
if fid<0, error('reload_official_cross_scale_table:Write','Cannot write %s (%s)',file,msg); end
end
