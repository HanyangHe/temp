function T=verify_online_baseline_comparison_setup(projectRoot)
%VERIFY_ONLINE_BASELINE_COMPARISON_SETUP Static checks for controlled A+S comparison.
if nargin<1 || isempty(projectRoot), projectRoot=pwd; end
files={ ...
    'microgrid_digital_shadow_online_experiments.mlx', ...
    'run_online_baseline_comparison_69bus.m', ...
    'run_online_model_experiments.m', ...
    fullfile('experiments','run_iterative_online_model_correction.m'), ...
    fullfile('experiments','retrain_online_model_after_trigger.m'), ...
    'config_online_experiment_69bus_mlx.m'};
checks=strings(numel(files)+8,1); pass=false(numel(files)+8,1); details=strings(numel(files)+8,1);
for i=1:numel(files)
    checks(i)="File exists: "+string(files{i});
    pass(i)=exist(fullfile(projectRoot,files{i}),'file')==2;
    details(i)=string(fullfile(projectRoot,files{i}));
end
r=fileread(fullfile(projectRoot,'run_online_baseline_comparison_69bus.m'));
rr=fileread(fullfile(projectRoot,'experiments','run_iterative_online_model_correction.m'));
base=numel(files);
checks(base+1)="External table excludes PE-SINDy";
pass(base+1)=contains(r,'PE-SINDy is excluded') && ~contains(r,'"PE-SINDy","A+S"');
details(base+1)="M-KBF / V-SINDy / LLM-Prior only";
checks(base+2)="Every external row is A+S";
pass(base+2)=contains(r,'"A+S"');
details(base+2)="adaptation + state synchronization";
checks(base+3)="Automatic trigger disabled for comparison";
pass(base+3)=contains(r,"triggerMode='scheduled_parameter_changes'");
details(base+3)="controlled oracle update schedule";
checks(base+4)="Scheduled updates are exactly [0 6] s";
pass(base+4)=contains(r,'scheduledTriggerTimes=[0.0 6.0]');
details(base+4)="matches the two true GFM1 nq coefficient jumps";
checks(base+5)="Exactly two update attempts requested";
pass(base+5)=contains(r,'maximumUpdateAttempts=2') && contains(r,'maximumAcceptedUpdates=2');
details(base+5)="common update count across methods";
checks(base+6)="Candidate rejection disabled in controlled table";
pass(base+6)=contains(r,'validation.enabled=false');
details(base+6)="every successful fit is activated after real fit delay";
checks(base+7)="Scheduled-update engine implemented";
pass(base+7)=contains(rr,'force_scheduled_update_detector') && contains(rr,'scheduled_update_times');
details(base+7)="post-jump causal sample pool only";
checks(base+8)="Real training wall-clock remains active";
rt=fileread(fullfile(projectRoot,'experiments','retrain_online_model_after_trigger.m'));
pass(base+8)=contains(rt,'trainTimer = tic') && contains(rt,'trainTime = toc(trainTimer)');
details(base+8)="fit time contributes to activation delay";
T=table(checks,pass,details,'VariableNames',{'Check','Pass','Details'});
disp(T);
if ~all(pass), error('Online scheduled A+S baseline setup verification FAILED.'); end
fprintf('\nONLINE SCHEDULED A+S BASELINE COMPARISON SETUP PASSED.\n');
end
