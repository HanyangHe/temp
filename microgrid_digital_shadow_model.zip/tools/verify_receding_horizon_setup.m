function T = verify_receding_horizon_setup(projectRoot)
%VERIFY_RECEDING_HORIZON_SETUP Static protocol checks; performs no simulation.
if nargin<1 || isempty(projectRoot), projectRoot=pwd; end
addpath(genpath(projectRoot));

cfg=config_receding_horizon_experiment_69bus();
c=case_grid_connected_69bus_receding_horizon();
checks=strings(0,1); pass=false(0,1); details=strings(0,1);
add('Parent horizon 60 s',abs(c.sim.tf-60)<1e-12,string(c.sim.tf));
add('Prediction horizon 12 s',abs(cfg.receding.predictionHorizonSeconds-12)<1e-12,string(cfg.receding.predictionHorizonSeconds));
add('Sliding step 1 s',abs(cfg.receding.anchorStepSeconds-1)<1e-12,string(cfg.receding.anchorStepSeconds));
add('49 windows',numel(cfg.receding.anchorTimesSeconds)==49,string(numel(cfg.receding.anchorTimesSeconds)));
add('Anchor grid 0:1:48',isequal(double(cfg.receding.anchorTimesSeconds),0:1:48),mat2str(cfg.receding.anchorTimesSeconds));
add('No parameter drift',~c.drift.enabled,string(c.drift.enabled));
add('Clean N=500 saved models',cfg.receding.initialModelSampleCount==500 && abs(cfg.receding.initialModelNoiseLevel)<1e-14, ...
    sprintf('N=%d noise=%g',cfg.receding.initialModelSampleCount,cfg.receding.initialModelNoiseLevel));
add('Representative seed 20260814',cfg.receding.initialModelSeed==20260814,string(cfg.receding.initialModelSeed));
add('Six primary methods',numel(cfg.receding.methods)==6,strjoin(string(cfg.receding.methods),', '));
add('Violin-only paper plotter',exist(fullfile(projectRoot,'utils','plot_receding_horizon_rmse_violin.m'),'file')==2, ...
    fullfile(projectRoot,'utils','plot_receding_horizon_rmse_violin.m'));
T=table(checks,pass,details,'VariableNames',{'Check','Pass','Details'});
disp(T);
if ~all(pass), error('RECEDING-HORIZON SETUP CHECK FAILED.'); end
fprintf('\nRECEDING-HORIZON SETUP: ALL CHECKS PASSED\n');

    function add(name,tf,detail)
        checks(end+1,1)=string(name); %#ok<AGROW>
        pass(end+1,1)=logical(tf); %#ok<AGROW>
        details(end+1,1)=string(detail); %#ok<AGROW>
    end
end
