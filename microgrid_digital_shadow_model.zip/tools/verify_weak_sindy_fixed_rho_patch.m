function T = verify_weak_sindy_fixed_rho_patch(projectRoot)
%VERIFY_WEAK_SINDY_FIXED_RHO_PATCH Static checks for fixed-rho Weak SINDy.

if nargin < 1 || isempty(projectRoot)
    projectRoot = fileparts(fileparts(mfilename('fullpath')));
end
addpath(genpath(projectRoot));

checks = strings(0,1);
pass = false(0,1);

fitFile = fullfile(projectRoot,'methods','fit_weak_sindy_stlsq_module.m');
runner = fullfile(projectRoot,'tests','run_weak_sindy_fixed_rho_retest_10bus.m');
cacheFile = fullfile(projectRoot,'experiments','make_offline_evaluation_cache_key.m');

checks(end+1,1) = "fixed-rho diagnostic runner exists"; %#ok<AGROW>
pass(end+1,1) = exist(runner,'file') == 2; %#ok<AGROW>
checks(end+1,1) = "weak fit implementation exists"; %#ok<AGROW>
pass(end+1,1) = exist(fitFile,'file') == 2; %#ok<AGROW>

cfg = config_offline_experiment_10bus();
checks(end+1,1) = "production Weak SINDy remains disabled"; %#ok<AGROW>
pass(end+1,1) = isfield(cfg.sindy,'weakSindy') && ...
    ~logical(cfg.sindy.weakSindy.enabled); %#ok<AGROW>

fitText = fileread(fitFile);
checks(end+1,1) = "support is discovered by ordinary STLSQ first"; %#ok<AGROW>
pass(end+1,1) = contains(fitText,'XiSupport = sparsifyDynamics') && ...
    contains(fitText,'supportMask = abs(XiSupport)>0'); %#ok<AGROW>
checks(end+1,1) = "weak coefficients use support-preserving rho refit"; %#ok<AGROW>
pass(end+1,1) = contains(fitText,'refit_stlsq_support_ridge') && ...
    contains(fitText,'fixed_all_weak_constraints'); %#ok<AGROW>
checks(end+1,1) = "weak rho no longer depends on reconstructed derivative labels"; %#ok<AGROW>
pass(end+1,1) = ~contains(fitText,'supportRidgeConfigured && measuredStateProtocol'); %#ok<AGROW>

runnerText = fileread(runner);
checks(end+1,1) = "diagnostic fixes weak rho at 1e-10"; %#ok<AGROW>
pass(end+1,1) = contains(runnerText, ...
    'cfg.sindy.weakSindy.supportRidgeRelativeAlpha = 1e-10'); %#ok<AGROW>

cacheText = fileread(cacheFile);
checks(end+1,1) = "weak cache key tags fixed rho"; %#ok<AGROW>
pass(end+1,1) = contains(cacheText,'weak_rho=%.17g'); %#ok<AGROW>

T = table(checks,pass,'VariableNames',{'Check','Passed'});
disp(T);
if ~all(pass)
    error('verify_weak_sindy_fixed_rho_patch:Failed', ...
        'One or more fixed-rho Weak-SINDy checks failed.');
end

fprintf('\nWEAK-SINDY FIXED-RHO PATCH VERIFICATION: PASSED\n');
fprintf(['Contract: weak integral regression; ordinary STLSQ support; ', ...
    'fixed rho=1e-10 coefficient refit for every clean/noisy condition.\n']);
end
