function T = verify_weak_sindy_ridge_retest_patch(projectRoot)
%VERIFY_WEAK_SINDY_RIDGE_RETEST_PATCH Static contract checks for the diagnostic.

if nargin < 1 || isempty(projectRoot)
    projectRoot = fileparts(fileparts(mfilename('fullpath')));
end
addpath(genpath(projectRoot));

checks = strings(0,1);
pass = false(0,1);

runner = fullfile(projectRoot,'tests','run_weak_sindy_ridge_retest_10bus.m');
fitFile = fullfile(projectRoot,'methods','fit_weak_sindy_stlsq_module.m');

checks(end+1,1) = "diagnostic runner exists"; %#ok<AGROW>
pass(end+1,1) = exist(runner,'file') == 2; %#ok<AGROW>
checks(end+1,1) = "weak fit implementation exists"; %#ok<AGROW>
pass(end+1,1) = exist(fitFile,'file') == 2; %#ok<AGROW>

cfg = config_offline_experiment_10bus();
checks(end+1,1) = "production Weak SINDy remains disabled"; %#ok<AGROW>
pass(end+1,1) = isfield(cfg.sindy,'weakSindy') && ...
    ~logical(cfg.sindy.weakSindy.enabled); %#ok<AGROW>

checks(end+1,1) = "shared support-ridge grid enabled in production config"; %#ok<AGROW>
pass(end+1,1) = logical(cfg.sindy.stlsq.supportRidge.enabled) && ...
    any(cfg.sindy.stlsq.supportRidge.relativeAlphaGrid == 0) && ...
    any(cfg.sindy.stlsq.supportRidge.relativeAlphaGrid == 1); %#ok<AGROW>

fitText = fileread(fitFile);
checks(end+1,1) = "weak support remains STLSQ-discovered before rho refit"; %#ok<AGROW>
pass(end+1,1) = contains(fitText,'XiSupport = sparsifyDynamics') && ...
    contains(fitText,'supportMask = abs(XiSupport)>0') && ...
    contains(fitText,'refit_stlsq_support_ridge'); %#ok<AGROW>

checks(end+1,1) = "weak rho is limited to measured/noisy-state protocol"; %#ok<AGROW>
pass(end+1,1) = contains(fitText,'supportRidgeConfigured && measuredStateProtocol'); %#ok<AGROW>

T = table(checks,pass,'VariableNames',{'Check','Passed'});
disp(T);
if ~all(pass)
    error('verify_weak_sindy_ridge_retest_patch:Failed', ...
        'One or more Weak-SINDy rho diagnostic checks failed.');
end

fprintf('\nWEAK-SINDY + RHO RETEST PATCH VERIFICATION: PASSED\n');
fprintf(['Contract: same noisy state trajectories, no pointwise xdot labels; ', ...
    'STLSQ discovers support; rho only refits that support under the measured-state protocol.\n']);
end
