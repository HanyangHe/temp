function T = verify_pnc_residualized_v3_patch(projectRoot)
%VERIFY_PNC_RESIDUALIZED_V3_PATCH Zero-cost structural verifier for v3 test.
if nargin < 1 || isempty(projectRoot), projectRoot = pwd; end
addpath(genpath(projectRoot));

checks = strings(0,1);
passed = false(0,1);
req = { ...
    'methods/fit_pnc_residualized_v3_module.m', ...
    'methods/train_modular_pnc_residualized_v3_sindy.m', ...
    'methods/train_pnc_residualized_v3_sindy.m', ...
    'methods/predict_modular_pnc_residualized_v3_sindy.m', ...
    'tests/run_pnc_residualized_v3_diagnostic_10bus.m'};
for k = 1:numel(req)
    checks(end+1,1) = "file: " + string(req{k}); %#ok<AGROW>
    passed(end+1,1) = isfile(fullfile(projectRoot,req{k})); %#ok<AGROW>
end

cfg = config_offline_experiment_10bus();
opt = get_sindy_options(cfg);
checks(end+1,1) = "production v3 diagnostic disabled";
passed(end+1,1) = isfield(opt,'physicsNeuralCompositionalResidualizedV3') && ...
    ~logical(opt.physicsNeuralCompositionalResidualizedV3.enabled);

methods = get_offline_method_registry(cfg);
names = string({methods.name});
checks(end+1,1) = "production registry excludes v3 diagnostic";
passed(end+1,1) = ~any(names=="pnc_residualized_v3_sindy");

cfg.sindy.physicsNeuralCompositionalResidualizedV3.enabled = true;
methods2 = get_offline_method_registry(cfg);
names2 = string({methods2.name});
checks(end+1,1) = "diagnostic registry includes v3 method";
passed(end+1,1) = any(names2=="pnc_residualized_v3_sindy");

checks(end+1,1) = "production PNC-v2 remains enabled";
passed(end+1,1) = logical(opt.physicsNeuralCompositional.enabled);
checks(end+1,1) = "flat PN remains production-disabled";
passed(end+1,1) = ~logical(opt.physicsNeural.enabled);

T = table(checks,passed,'VariableNames',{'Check','Passed'});
disp(T);
if ~all(passed)
    error('verify_pnc_residualized_v3_patch:Failed', ...
        'PNC-v3 diagnostic patch verification failed.');
end
fprintf('\nPNC-v3 RESIDUALIZED PATCH VERIFICATION: PASSED\n');
fprintf('Contract: f_hat = H + [H,Theta_PN,Phi_comp]*DeltaXi_2.\n');
fprintf('Exact parents: DeltaXi=0 -> PE; [-I,Xi_PN,0] -> flat PN.\n');
end
