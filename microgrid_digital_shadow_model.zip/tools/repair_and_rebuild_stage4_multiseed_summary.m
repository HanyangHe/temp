function report = repair_and_rebuild_stage4_multiseed_summary(projectRoot,testCase,varargin)
%REPAIR_AND_REBUILD_STAGE4_MULTISEED_SUMMARY Recover old clean sections and
% regenerate the existing multi-seed summary without training/rollout.
%
% Example:
%   report = repair_and_rebuild_stage4_multiseed_summary(pwd,'10bus');

if nargin<1 || isempty(projectRoot), projectRoot=pwd; end
if nargin<2 || isempty(testCase), testCase='10bus'; end

p=inputParser;
addParameter(p,'DryRun',false,@(x)islogical(x)||(isnumeric(x)&&isscalar(x)));
parse(p,varargin{:});
dryRun=logical(p.Results.DryRun);

repairReport=repair_stage4_clean_sections_from_cache( ...
    projectRoot,testCase,'DryRun',dryRun);

if dryRun
    report=struct('repairReport',repairReport,'aggregateReport',[]);
    return;
end

switch lower(char(string(testCase)))
    case {'10','10bus'}
        caseFcn=@case_grid_connected_10bus_true_physics;
        configFcn=@config_offline_experiment_10bus;
    case {'69','69bus'}
        caseFcn=@case_grid_connected_69bus_true_physics;
        configFcn=@config_offline_experiment_69bus;
    case {'123','123bus'}
        caseFcn=@case_grid_connected_123bus_true_physics;
        configFcn=@config_offline_experiment_123bus;
    otherwise
        error('Unsupported testCase: %s',char(string(testCase)));
end

fprintf('\nRebuilding multi-seed summary from repaired independent bundles...\n');
aggregateReport=run_offline_model_experiments_multiseed( ...
    projectRoot,caseFcn,configFcn,true);

report=struct();
report.repairReport=repairReport;
report.aggregateReport=aggregateReport;
end
