function cfg = config_offline_experiment_10bus_replay_all_saved()
%CONFIG_OFFLINE_EXPERIMENT_10BUS_REPLAY_ALL_SAVED
% Replay/aggregate-only configuration that exposes every Stage-4 method.
%
% This wrapper is used ONLY for saved-result multi-seed aggregation. It does
% not define a new experiment protocol and should not be used for training.
%
% The normal Stage-4 run config can execute only a subset during an
% incremental rerun. Replay instead exposes the complete retained manuscript
% comparison set from independently saved method bundles.

cfg = config_offline_experiment_10bus();

allSavedMethods = { ...
    'modular_koopman_kbf', ...
    'vanilla_sindy', ...
    'physics_embedded_sindy', ...
    'physics_neural_compositional_sindy', ...
    'neural_ode_modular'};

cfg.run.methodsToRun = allSavedMethods;
cfg.run.section1p1MethodsToRun = allSavedMethods;
cfg.run.section1p2MethodsToRun = allSavedMethods;
cfg.run.section1p3MethodsToRun = allSavedMethods;

cfg.run.section1p1 = true;
cfg.run.section1p2 = true;
cfg.run.section1p3 = true;

if isfield(cfg,'node') && isstruct(cfg.node)
    cfg.node.enabled = true;
end
end
