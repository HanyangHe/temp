function T = verify_final_sindy_support_ridge_10bus(projectRoot)
%VERIFY_FINAL_SINDY_SUPPORT_RIDGE_10BUS Zero-cost final SINDy protocol check.
%
% No training, truth solve, or rollout is executed.
%
% Usage:
%   clear functions; rehash toolboxcache;
%   T = verify_final_sindy_support_ridge_10bus(pwd);

if nargin < 1 || isempty(projectRoot), projectRoot = pwd; end
addpath(genpath(projectRoot));

cfg = config_offline_experiment_10bus();
opt = get_sindy_options(cfg);
expectedMethods = ["vanilla_sindy","physics_embedded_sindy","physics_neural_compositional_sindy"];

sec1 = string(cfg.run.section1p1MethodsToRun(:)).';
sec2 = string(cfg.run.section1p2MethodsToRun(:)).';
sec3 = string(cfg.run.section1p3MethodsToRun(:)).';
if ~isequal(sec1,expectedMethods) || ~isequal(sec2,expectedMethods) || ...
        ~isequal(sec3,expectedMethods)
    error('verify_final_sindy_support_ridge_10bus:Methods', ...
        'Sections 1.1/1.2/1.3 must rerun exactly V-/PE-/PNC-SINDy.');
end

if ~opt.stlsq.supportRidge.enabled
    error('verify_final_sindy_support_ridge_10bus:RidgeDisabled', ...
        'Shared support-ridge conditioning must be enabled.');
end
if ~strcmpi(opt.stlsq.supportRidge.applicationPolicy, ...
        'reconstructed_derivative_labels_only')
    error('verify_final_sindy_support_ridge_10bus:Policy', ...
        'Expected reconstructed_derivative_labels_only support-ridge policy.');
end
requiredRho = [0 1e-10 1e-9];
if ~all(ismember(requiredRho,opt.stlsq.supportRidge.relativeAlphaGrid))
    error('verify_final_sindy_support_ridge_10bus:RhoGrid', ...
        'Ridge grid must include 0, 1e-10, and 1e-9.');
end
if opt.stlsq.trajectoryValidation.enabled
    error('verify_final_sindy_support_ridge_10bus:TrajectorySelector', ...
        'The rejected held-out short-trajectory selector must remain OFF.');
end

cleanData = struct('derivativeLabelsReconstructed',false);
noisyData = struct('derivativeLabelsReconstructed',true);
[cleanApply,~,~] = should_apply_sindy_support_ridge(opt,cleanData);
[noisyApply,~,~] = should_apply_sindy_support_ridge(opt,noisyData);
if cleanApply || ~noisyApply
    error('verify_final_sindy_support_ridge_10bus:Application', ...
        'Expected exact labels -> OLS and reconstructed labels -> ridge selection.');
end
if ~opt.physicsNeuralCompositional.enabled || opt.physicsNeural.enabled || ...
        ~opt.physicsNeuralCompositional.includeLayer1BypassCandidate
    error('verify_final_sindy_support_ridge_10bus:PNC', ...
        'Expected proposed PNC enabled, flat PN disabled, and explicit PE bypass enabled.');
end

T = table( ...
    string(opt.formulationVersion), ...
    opt.stlsq.supportRidge.enabled, ...
    string(opt.stlsq.supportRidge.applicationPolicy), ...
    cleanApply,noisyApply, ...
    numel(opt.stlsq.supportRidge.relativeAlphaGrid), ...
    opt.stlsq.supportRidge.tieRelativeValidationTolerance, ...
    'VariableNames',{'FormulationVersion','RidgeConfigured','Policy', ...
    'AppliesToExactXdot','AppliesToReconstructedXdot','RhoCount','TieTolerance'});

disp(T);
fprintf('10-bus final shared SINDy support-ridge configuration check PASSED.\n');
fprintf('Sections 1.1/1.2/1.3 rerun: Vanilla SINDy, Physics-embedded SINDy, PNC-SINDy.\n');
fprintf('This verification performed no training or rollout.\n');
end
