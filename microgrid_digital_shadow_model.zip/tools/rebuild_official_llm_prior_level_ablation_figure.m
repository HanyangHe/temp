function figPath = rebuild_official_llm_prior_level_ablation_figure(projectRoot,testCase)
%REBUILD_OFFICIAL_LLM_PRIOR_LEVEL_ABLATION_FIGURE Saved-only five-bar plot.
% Reads the original immutable official Lv.0-Lv.3 per-run CSV and, when
% available, the SEPARATE C+E control. No training, DAE, or LLM calls.
% The original CSV is NEVER rewritten. For 69bus C+E is plotted as a gray
% independent rightmost control after Lv.3 in both panels.
%
% Usage:
%   rebuild_official_llm_prior_level_ablation_figure(pwd,'69bus');

if nargin<1 || isempty(projectRoot), projectRoot=pwd; end
if nargin<2 || isempty(testCase), testCase='69bus'; end
caseName=char(string(testCase));
outRoot=fullfile(projectRoot,'outputs', ...
    sprintf('offline_model_experiments_%s',caseName), ...
    'ablation_llm_prior_levels_N1000');
if ~isfolder(outRoot)
    error('rebuild_prior_ablation:MissingFolder','Folder not found: %s',outRoot);
end
csvFiles={fullfile(outRoot,'llm_prior_level_ablation_all_runs.csv'), ...
    fullfile(outRoot,'llm_prior_level_ablation_runs.csv')};
inCsv='';
for i=1:numel(csvFiles)
    if isfile(csvFiles{i}), inCsv=csvFiles{i}; break; end
end
if isempty(inCsv)
    error('rebuild_prior_ablation:MissingCSV', ...
        'Official per-run CSV not found under %s.',outRoot);
end
addpath(fullfile(projectRoot,'utils'),'-begin');
[T, schema] = read_official_prior_ablation_runs(inCsv);
seed=[];
added=false;
if strcmpi(caseName,'69bus')
    baselineCSV=fullfile(outRoot,'coordexp_baseline','coordexp_run.csv');
    if isfile(baselineCSV)
        U=readtable(baselineCSV);
        needed={'Variant','DataSeed','RMSE','ActiveCoefficientCount','RolloutSucceeded'};
        if height(U)~=1 || ~all(ismember(needed,U.Properties.VariableNames)) || ...
                ~strcmpi(string(U.Variant(1)),'coordexp')
            error('rebuild_prior_ablation:BadControlCSV', ...
                'C+E CSV must contain exactly one labeled control row.');
        end
        % Reuse EXACTLY the same alias handling as the check/runner.
        % The original per-run file is never changed or appended to.
        T0 = T(:,{'Variant','DataSeed','RMSE','ActiveCoefficientCount'});
        U0=U(:,{'Variant','DataSeed','RMSE','ActiveCoefficientCount'});
        U0.Variant=string(U0.Variant);
        T=[T0;U0];
        seed=double(U.DataSeed(1));
        if ~ismember(seed,unique(T0.DataSeed))
            error('rebuild_prior_ablation:FixedSeedMismatch', ...
                'C+E seed does not occur in original official ablation.');
        end
        added=true;
    end
end

% Back up the old four-bar figure once before regenerating the canonical
% figure. Source per-run data are untouched.
if added
    for ext={'.pdf','_preview.png'}
        base=fullfile(outRoot,['llm_prior_level_ablation' ext{1}]);
        backup=fullfile(outRoot,['llm_prior_level_ablation_before_coordexp' ext{1}]);
        if isfile(base) && ~isfile(backup)
            copyfile(base,backup);
        end
    end
end

if isempty(seed)
    figPath=plot_llm_prior_level_ablation(T,outRoot,'CaseName',caseName);
else
    figPath=plot_llm_prior_level_ablation(T,outRoot, ...
        'CaseName',caseName,'FixedDataSeed',seed);
end
fprintf('Official prior-level plot rebuilt from saved rows (training=0, LLM=0).\n');
fprintf('Original ablation CSV unchanged: %s\n',inCsv);
fprintf('Original columns mapped: %s / %s / %s / %s\n', ...
    schema.variantColumn,schema.seedColumn,schema.rmseColumn,schema.activeCountColumn);
if added
    fprintf('Additional independent control: %s\n', ...
        fullfile(outRoot,'coordexp_baseline','coordexp_run.csv'));
end
fprintf('Figure: %s\n',figPath);
end
