function T = verify_online_manuscript_figure_patch(projectRoot)
%VERIFY_ONLINE_MANUSCRIPT_FIGURE_PATCH Quick check for the manuscript-figure update.
if nargin<1 || strlength(string(projectRoot))==0
    projectRoot = pwd;
end
f = fullfile(projectRoot,'utils','plot_online_manuscript_summary.m');
assert(exist(f,'file')==2,'Updated plot_online_manuscript_summary.m not found.');
text = fileread(f);
checks = strings(0,1);
pass   = false(0,1);
detail = strings(0,1);
add('Updated manuscript plot exists', exist(f,'file')==2, f);
add('Four-row layout', contains(text,'tiledlayout(4,1)'), 'rows: parameter / voltage / error / tracking RMSE');
add('Legend uses F/F+S/A/A+S', contains(text,'"A+S (proposed)"') && contains(text,'"F+S"'), 'abbreviated deployment legend');
add('A+S proposed is bold red', contains(text,'cAS  = [0.8500 0.0500 0.0500]') && contains(text,'lw=2.20'), 'red + thicker line');
add('Tracking RMSE row included', contains(text,'collect_tracking_rmse_for_summary'), 'Fig.2 merged as fourth row');
T = table(checks,pass,detail,'VariableNames',{'Check','Pass','Details'});
if ~all(pass)
    error('Online manuscript figure patch verification FAILED.');
end
fprintf('Online manuscript figure patch verification PASSED.\n');

    function add(name,tf,msg)
        checks(end+1,1) = string(name); %#ok<AGROW>
        pass(end+1,1)   = logical(tf); %#ok<AGROW>
        detail(end+1,1) = string(msg); %#ok<AGROW>
    end
end
