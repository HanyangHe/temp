function [T,source] = read_official_prior_ablation_runs(csvPath)
%READ_OFFICIAL_PRIOR_ABLATION_RUNS Read legacy/current per-run prior-level CSV.
%
% This is an in-memory, read-only schema adapter. Original CSV is never
% altered. The official plotter historically accepted Level/Variant,
% RolloutRMSE/RMSE, Seed/DataSeed, ActiveCount/ActiveCoefficientCount.
% A prior patch accidentally required only three exact column names.
%
% [T,source] = read_official_prior_ablation_runs(csvPath)
% T: canonical Variant, DataSeed, RMSE, ActiveCoefficientCount, and
%    optional DiscoverySeed. source lists exact headers used.
%
% If the on-disk table has an unrecognized schema, abort and print its
% actual headers. NEVER invent a seed, a trajectory error, or a level.

if nargin~=1 || ~(ischar(csvPath) || isstring(csvPath)) || ~isfile(csvPath)
    error('read_prior_runs:MissingCSV','Official per-run CSV not found: %s',string(csvPath));
end
raw = readtable(csvPath);
original = string(raw.Properties.VariableNames(:));
normalized = lower(regexprep(original,'[^A-Za-z0-9]',''));

[vCol,vName] = pick(original,normalized, ...
    {'Variant','Level','PriorLevel','AblationLevel','PriorVariant'});
[rCol,rName] = pick(original,normalized, ...
    {'RMSE','RolloutRMSE','TrajectoryRMSE','TestRMSE'});
[sCol,sName] = pick(original,normalized, ...
    {'DataSeed','Seed','FixedDataSeed','SamplingSeed'});
[aCol,aName] = pick(original,normalized, ...
    {'ActiveCoefficientCount','ActiveCount','Active','NonzeroCoefficientCount'});
[dCol,dName] = pick(original,normalized, ...
    {'DiscoverySeed','LLMDiscoverySeed','PriorDiscoverySeed'},true);

requiredIdx = [vCol rCol sCol aCol];
if any(~isfinite(requiredIdx))
    fprintf(2,'\n[PRIOR CSV SCHEMA] Unrecognized official CSV: %s\n',char(csvPath));
    fprintf(2,'Actual column names: %s\n',strjoin(cellstr(original.'),', '));
    error('read_prior_runs:UnknownSchema', ...
        ['Could not identify Level/Variant, RMSE/RolloutRMSE, ', ...
         'DataSeed/Seed and ActiveCount/ActiveCoefficientCount. ', ...
         'Please share the actual header line before running C+E.']);
end

levels = lower(strtrim(string(raw.(vName))));
seeds = numeric_column(raw.(sName),'data seed');
errors = numeric_column(raw.(rName),'rollout RMSE');
active = numeric_column(raw.(aName),'active coefficient count');
levels = levels(:); seeds = seeds(:); errors = errors(:); active = active(:);

if numel(levels)~=height(raw) || numel(seeds)~=height(raw) || ...
        numel(errors)~=height(raw) || numel(active)~=height(raw)
    error('read_prior_runs:Shape','CSV columns have inconsistent row counts.');
end
allowed = ["none","coordinate_only","llm_direct","llm_full"];
if any(~ismember(levels,allowed))
    bad = unique(levels(~ismember(levels,allowed)));
    error('read_prior_runs:UnknownLevel', ...
        'Unexpected prior-level labels: %s. Do not reinterpret silently.', ...
        strjoin(cellstr(bad),', '));
end
if any(~isfinite(seeds) | seeds~=round(seeds))
    error('read_prior_runs:BadDataSeed', ...
        'Official CSV contains missing/noninteger data seeds.');
end
if any(isfinite(errors) & errors < 0) || any(isfinite(active) & active < 0)
    error('read_prior_runs:NegativeMetric','Negative RMSE or active count found.');
end

T = table(levels,seeds,errors,active,'VariableNames', ...
    {'Variant','DataSeed','RMSE','ActiveCoefficientCount'});
source = struct('filename',char(csvPath),'rawHeaders',{cellstr(original)}, ...
    'variantColumn',vName,'seedColumn',sName,'rmseColumn',rName, ...
    'activeCountColumn',aName,'discoverySeedColumn','');
if isfinite(dCol)
    dd = numeric_column(raw.(dName),'discovery seed');
    T.DiscoverySeed = dd(:);
    source.discoverySeedColumn = dName;
end
fprintf('[PRIOR CSV] %d saved rows | %s / %s / %s / %s\n', ...
    height(T),vName,sName,rName,aName);
end

function [idx,col] = pick(original,normalized,aliases,optional)
if nargin<4, optional=false; end
idx=NaN; col='';
for j=1:numel(aliases)
    needle=lower(regexprep(string(aliases{j}),'[^A-Za-z0-9]',''));
    hit=find(normalized==needle,1,'first');
    if ~isempty(hit)
        idx=hit; col=char(original(hit)); return;
    end
end
if ~optional, return; end
end

function a = numeric_column(v,label)
if isnumeric(v) || islogical(v)
    a=double(v);
else
    rawText=strtrim(string(v));
    a=str2double(rawText);
    blank = strlength(rawText)==0 | ismissing(rawText);
    knownMissing = strcmpi(rawText,'NaN') | strcmpi(rawText,'NA') | ...
        strcmpi(rawText,'N/A') | strcmpi(rawText,'<missing>');
    if any(isnan(a) & ~(blank | knownMissing))
        error('read_prior_runs:NonNumericColumn', ...
            'Column %s contains nonnumeric values.',label);
    end
end
if ~isvector(a)
    error('read_prior_runs:NonVectorColumn','Column %s must be a vector.',label);
end
end
