function cfg = config_offline_experiment_10bus_restore_clean_baselines()
%CONFIG_OFFLINE_EXPERIMENT_10BUS_RESTORE_CLEAN_BASELINES
% Temporary recovery configuration.
%
% Purpose:
%   Recompute ONLY the original four clean-data baselines for Sections 1.1
%   and 1.2 after the Stage-4 incremental-save bug removed those clean
%   conditions from the replay bundles.
%
% It intentionally does NOT rerun:
%   - Section 1.3 measurement-noise experiments,
%   - Weak PN-SINDy,
%   - Neural ODE.
%
% The non-destructive saver merges these newly recomputed clean conditions
% into the existing method bundles, preserving the current Stage-4 Section
% 1.3 results.

cfg = config_offline_experiment_10bus();

cleanMethods = { ...
    'modular_koopman_kbf', ...
    'vanilla_sindy', ...
    'physics_embedded_sindy', ...
    'physics_neural_sindy'};

cfg.run.section1p1 = true;
cfg.run.section1p2 = true;
cfg.run.section1p3 = false;

cfg.run.methodsToRun = cleanMethods;
cfg.run.section1p1MethodsToRun = cleanMethods;
cfg.run.section1p2MethodsToRun = cleanMethods;
cfg.run.section1p3MethodsToRun = {};

% Prevent confusing NODE/Weak-PN status messages during this recovery run.
if isfield(cfg,'node') && isstruct(cfg.node)
    cfg.node.enabled = false;
end
if isfield(cfg,'sindy') && isstruct(cfg.sindy) && ...
        isfield(cfg.sindy,'weakPhysicsNeural') && ...
        isstruct(cfg.sindy.weakPhysicsNeural)
    cfg.sindy.weakPhysicsNeural.enabled = false;
end

% Keep the official clean-data protocol unchanged.
% sampleCounts/randomSeeds/etc. are inherited from the official config.
end
