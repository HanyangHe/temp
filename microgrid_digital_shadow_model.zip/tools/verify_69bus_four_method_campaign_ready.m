function report = verify_69bus_four_method_campaign_ready(projectRoot)
%VERIFY_69BUS_FOUR_METHOD_CAMPAIGN_READY Verify saved M-KBF/V-SINDy coverage.
%
% The final 69-bus campaign intentionally recomputes ONLY EDSI and LLM-EDSI.
% M-KBF and V-SINDy must already exist for every requested data seed and every
% Section 1.1--1.3 condition. This verifier fails before any new training is
% launched if those historical bundles are incomplete.

if nargin<1 || isempty(projectRoot)
    projectRoot=fileparts(fileparts(mfilename('fullpath')));
end
projectRoot=char(string(projectRoot));
addpath(genpath(projectRoot));

cfg=config_offline_experiment_69bus();
baseRoot=fullfile(projectRoot,'outputs',char(string(cfg.output.folderName)), ...
    char(string(cfg.multiseed.seedFolderName)));

requiredMethods=["modular_koopman_kbf","vanilla_sindy"];
seeds=round(double(cfg.randomSeeds(:).'));

rows=table();
allOK=true;

for is=1:numel(seeds)
    seed=seeds(is);
    seedRoot=fullfile(baseRoot,sprintf('seed_%d',seed));
    for im=1:numel(requiredMethods)
        methodName=requiredMethods(im);
        bundleFile=fullfile(seedRoot,char(string(cfg.output.methodResultsFolder)), ...
            char(methodName),char(string(cfg.output.methodReplayFileName)));

        existsFlag=exist(bundleFile,'file')==2;
        sec11=false; sec12=false; sec13=false;
        message="";

        if ~existsFlag
            message="bundle missing";
        else
            try
                S=load_mat_long_path_safe(bundleFile,'methodBundle');
                if ~isfield(S,'methodBundle') || ~isstruct(S.methodBundle)
                    message="methodBundle missing/invalid";
                else
                    B=S.methodBundle;
                    sec11=section_has_conditions_local(B,'section1p1', ...
                        cfg.typicalSampleCount,0);
                    sec12=all(arrayfun(@(N)section_has_conditions_local( ...
                        B,'section1p2',N,0),cfg.sampleCounts));
                    sec13=all(arrayfun(@(q)section_has_conditions_local( ...
                        B,'section1p3',cfg.typicalSampleCount,q),cfg.noiseLevels));
                    if ~(sec11&&sec12&&sec13)
                        message="one or more official conditions are missing";
                    end
                end
            catch ME
                message="bundle read failed: "+string(ME.message);
            end
        end

        ok=existsFlag&&sec11&&sec12&&sec13;
        allOK=allOK&&ok;

        row=table(seed,methodName,existsFlag,sec11,sec12,sec13,ok,string(bundleFile),message, ...
            'VariableNames',{ ...
            'Seed','Method','BundleExists','Section1p1Complete', ...
            'Section1p2Complete','Section1p3Complete','Ready', ...
            'BundlePath','Message'});
        if isempty(rows), rows=row; else, rows=[rows;row]; end %#ok<AGROW>
    end
end

report=struct();
report.ready=allOK;
report.table=rows;
report.requiredMethods=requiredMethods;
report.seeds=seeds;

disp(rows);

if ~allOK
    error('verify_69bus_four_method_campaign_ready:SavedBaselineIncomplete', ...
        ['The final 69-bus campaign will NOT retrain M-KBF/V-SINDy, but one ', ...
         'or more saved baseline bundles/conditions are incomplete. Resolve ', ...
         'the rows marked Ready=false before launching EDSI/LLM-EDSI.']);
end

fprintf(['Verified: all saved M-KBF and V-SINDy Section 1.1--1.3 results ', ...
    'exist for all %d data seeds. They will not be retrained.\n'],numel(seeds));
end


function tf=section_has_conditions_local(B,sectionName,N,noise)
tf=false;
if ~isstruct(B) || ~isfield(B,'report') || ~isstruct(B.report) || ...
        ~isfield(B.report,sectionName) || ~isstruct(B.report.(sectionName))
    return;
end
sec=B.report.(sectionName);
if ~isfield(sec,'table') || ~istable(sec.table) || isempty(sec.table)
    return;
end
T=sec.table;
if ~ismember('SampleCount',T.Properties.VariableNames)
    return;
end

nMatch=abs(double(T.SampleCount)-double(N))<=1e-12;
if ismember('NoiseLevel',T.Properties.VariableNames)
    q=double(T.NoiseLevel);
elseif ismember('NoisePercent',T.Properties.VariableNames)
    q=double(T.NoisePercent)/100;
else
    q=zeros(height(T),1);
end
noiseMatch=abs(q-double(noise))<=max(1e-14,1e-10*max(1,abs(double(noise))));

tf=any(nMatch & noiseMatch);
end
