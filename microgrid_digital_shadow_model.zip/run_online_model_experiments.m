function report = run_online_model_experiments(projectRoot,caseFcn,configFcn)
%RUN_ONLINE_MODEL_EXPERIMENTS Formal online digital-shadow experiment runner.
%
% Online protocol:
%   1) load the saved nominal/offline initial model;
%   2) solve one true system whose selected device parameter(s) follow the
%      configured hidden constant or piecewise-constant mismatch schedule;
%   3) record x/V/u/xdot with configured xdot observation noise;
%   4) evaluate each enabled frozen baseline;
%   5) localize mismatch at the DER-module level from causal vector-field
%      residuals;
%   6) apply the method-specific fast local updater. For LLM-Prior SINDy,
%      freeze the compiled dictionary and offline sparse support and update only
%      the localized module coefficients by causal fixed-support RLS. PNC-SINDy
%      retains its historical layer-2 updater for backward compatibility;
%   7) validate the candidate on new post-training observations;
%   8) reuse the accepted model/activation sequence in a 2x2 Stage-3 ablation:
%        frozen/no-sync, frozen/sync, adapted/no-sync, adapted/sync.
%      The full digital-shadow deployment is adapted/sync.

if nargin<1 || isempty(projectRoot), projectRoot=fileparts(mfilename('fullpath')); end
if nargin<2 || isempty(caseFcn), caseFcn=@case_grid_connected_10bus_true_physics; end
if nargin<3 || isempty(configFcn), configFcn=@config_online_experiment_10bus; end
if ischar(caseFcn)||isstring(caseFcn), caseFcn=str2func(char(caseFcn)); end
if ischar(configFcn)||isstring(configFcn), configFcn=str2func(char(configFcn)); end
addpath(genpath(projectRoot));

cNominal=caseFcn();
if isfield(cNominal,'drift'), cNominal.drift.enabled=false; end
layout=mg_build_state_layout(cNominal);
cfg=configFcn();

plan=get_online_method_plan(cfg);
cfg=activate_registry_for_online_plan(cfg,plan);
allMethods=get_offline_method_registry(cfg);
[methods,plan]=resolve_online_method_plan(allMethods,plan);
if isempty(methods)
    error('run_online_model_experiments:NoMethods', ...
        'No frozen or online learned method is enabled in cfg.online.methods.');
end

cTruth=cNominal;
cTruth.drift=make_truth_parameter_mismatch(cTruth,cfg);

fprintf('\n============================================================\n');
fprintf('Microgrid digital shadow -- Online model experiment\n');
fprintf('Case: %s\n',cNominal.name);
fprintf('Scenario: %s + hidden parameter mismatch schedule\n', ...
    char(string(cNominal.scenario.name)));
fprintf('Online model correction: %s\n',onoff(cfg.online.update.enabled));
fprintf('============================================================\n');
print_reference_case_summary(cNominal,projectRoot);
print_online_experiment_settings(cfg,cNominal,cTruth,plan);

outRoot=fullfile(projectRoot,'outputs',cfg.output.folderName);
figDir=fullfile(outRoot,'figures');
if ~exist(outRoot,'dir'), mkdir(outRoot); end
if ~exist(figDir,'dir'), mkdir(figDir); end

%% Preflight all required saved initial models.
initialModels=cell(numel(methods),1);
initialTrainInfo=cell(numel(methods),1);
initialSources=cell(numel(methods),1);
for k=1:numel(methods)
    method=methods(k);
    fprintf('\nPreflight offline initial model: %s ...\n',method.displayName);
    [initialModels{k},initialTrainInfo{k},initialSources{k}]= ...
        load_offline_initial_model_for_online( ...
        projectRoot,method,cfg,cfg.online.initialModelSampleCount, ...
        cfg.online.initialModelNoiseLevel);
    source=initialSources{k};
    fprintf('  source: %s\n',source.bundlePath);
    fprintf('  condition: N=%d | noise=%.4g%%\n',source.sampleCount,source.noisePercent);
    if isfield(source,'methodSpecificCompatibilityVerified') && ...
            source.methodSpecificCompatibilityVerified
        if isfield(source,'legacyVariantAliasApplied') && source.legacyVariantAliasApplied
            fprintf(['  compatibility: PASS by verified legacy metadata alias ', ...
                '(saved variant %s -> canonical %s); full physics feature set matched\n'], ...
                source.storedModelVariant,source.canonicalModelVariant);
        elseif ~strcmp(source.savedFormulationVersion,source.currentFormulationVersion)
            fprintf(['  compatibility: PASS by method-specific mathematical signature ', ...
                '(saved tag %s; current tag %s)\n'], ...
                source.savedFormulationVersion,source.currentFormulationVersion);
        else
            fprintf('  compatibility: PASS by method-specific mathematical signature\n');
        end
    end
end

%% One common true online trajectory and observation stream.
fprintf('\nSolving physical reference trajectory with parameter mismatch schedule...\n');
truth=simulate_reference_truth_scenario(cTruth,layout);
fprintf('Reference truth solved in %.3f s; max algebraic residual %.3e.\n', ...
    truth.metadata.solveTimeSeconds,max(truth.networkResidualInf));

observations=build_online_observation_stream( ...
    truth,cfg.online.observationNoiseLevel,cfg);
obsFile=fullfile(outRoot,'online_observation_stream.mat');
save(obsFile,'observations','-v7.3');
write_parameter_profile_csv(truth,outRoot);

% The original nominal training pool is loaded once and reused for every
% online method so baseline differences do not come from different data.
needOnline=any([plan.online]) && cfg.online.update.enabled;
baseDataset=[]; baseDatasetSource=struct();
if needOnline
    fprintf('\nLoading nominal offline training data for online correction...\n');
    [baseDataset,baseDatasetSource]=load_offline_training_dataset_for_online( ...
        projectRoot,cfg,cfg.online.initialModelSampleCount, ...
        cfg.online.initialModelNoiseLevel);
    fprintf('  source: %s\n',baseDatasetSource.cacheFile);
    fprintf('  nominal samples: %d | noise=%.4g%%\n', ...
        size(baseDataset.x,1),100*cfg.online.initialModelNoiseLevel);
    offlineScale=get_detector_scale(baseDataset,cfg);
else
    offlineScale=[];
end

%% Deployment evaluation: legacy two-mode or Stage-3 four-variant ablation.
evaluations={};
T=table();
updateRows=table();
ablationEnabled = online_ablation_enabled(cfg);
ablationVariants = get_online_ablation_variants(cfg);

for k=1:numel(methods)
    method=methods(k);
    flags=plan(k);
    initialModel=initialModels{k};
    trainInfo=initialTrainInfo{k};
    source=initialSources{k};

    if flags.online && cfg.online.update.enabled && trajectory_calibration_requested(cfg)
        [cfg,~]=maybe_apply_online_detector_trajectory_calibration( ...
            projectRoot,cfg,initialModel,method,baseDataset,cNominal,layout, ...
            truth,observations,offlineScale,outRoot);
    end

    if ablationEnabled && flags.online
        fprintf('\nStage-3 four-variant online ablation: %s ...\n',method.displayName);
        if ~cfg.online.update.enabled
            error('run_online_model_experiments:OnlineUpdateDisabled', ...
                '%s online=true but cfg.online.update.enabled=false.',method.displayName);
        end

        % Detection/adaptation is executed exactly ONCE. All four deployment
        % variants below reuse the same causal observations, accepted models,
        % and activation times. This isolates coefficient adaptation and state
        % synchronization without changing the trigger/update history.
        onlineResult=run_iterative_online_model_correction( ...
            initialModel,baseDataset,observations,truth,method,cNominal,layout,cfg,offlineScale);
        detector=onlineResult.detector;
        update=onlineResult.update;
        acceptedModels=getfield_default(onlineResult,'acceptedModels',cell(0,1)); %#ok<GFLD>
        activationTimes=getfield_default(onlineResult,'acceptedActivationTimes',zeros(0,1)); %#ok<GFLD>
        activationTimes=double(activationTimes(:));
        commonStart=NaN;
        if ~isempty(activationTimes), commonStart=activationTimes(1); end

        write_online_update_artifacts(method,detector,update,onlineResult,outRoot);

        frozenPrediction=simulate_online_frozen_model_scenario( ...
            initialModel,method,truth,cNominal,layout,cfg);

        variantEvals=cell(numel(ablationVariants),1);
        for iVar=1:numel(ablationVariants)
            variant=lower(string(ablationVariants{iVar}));
            [adapted,synchronized]=ablation_variant_factors(variant);
            detectorForMode=struct();
            updateForMode=make_ablation_update_view( ...
                update,activationTimes,commonStart,adapted,synchronized);
            updatedModel=[];

            switch variant
                case "frozen_no_sync"
                    prediction=frozenPrediction;

                case "frozen_sync"
                    detectorForMode=detector;
                    if isempty(activationTimes)
                        prediction=frozenPrediction;
                    else
                        frozenModels=repmat({initialModel},numel(activationTimes),1);
                        prediction=simulate_online_multi_update_scenario( ...
                            initialModel,frozenModels,activationTimes,method,truth, ...
                            cNominal,layout,cfg,'StateSynchronization',true);
                        prediction.metadata.onlineMode='frozen_coefficients_with_state_sync';
                    end

                case "adapted_no_sync"
                    detectorForMode=detector;
                    updatedModel=getfield_default(update,'updatedModel',[]); %#ok<GFLD>
                    if isempty(activationTimes) || isempty(acceptedModels)
                        prediction=frozenPrediction;
                    else
                        prediction=simulate_online_multi_update_scenario( ...
                            initialModel,acceptedModels,activationTimes,method,truth, ...
                            cNominal,layout,cfg,'StateSynchronization',false);
                    end

                case "adapted_sync"
                    detectorForMode=detector;
                    updatedModel=getfield_default(update,'updatedModel',[]); %#ok<GFLD>
                    % run_iterative_online_model_correction uses the configured
                    % full deployment (state synchronization ON by default).
                    % Recompute only if a nonstandard config disabled it.
                    if isfield(onlineResult,'prediction') && ...
                            isfield(onlineResult.prediction,'metadata') && ...
                            isfield(onlineResult.prediction.metadata,'stateResynchronizedAtActivation') && ...
                            logical(onlineResult.prediction.metadata.stateResynchronizedAtActivation)
                        prediction=onlineResult.prediction;
                    elseif isempty(activationTimes) || isempty(acceptedModels)
                        prediction=frozenPrediction;
                    else
                        prediction=simulate_online_multi_update_scenario( ...
                            initialModel,acceptedModels,activationTimes,method,truth, ...
                            cNominal,layout,cfg,'StateSynchronization',true);
                    end

                otherwise
                    error('run_online_model_experiments:UnknownAblationVariant', ...
                        'Unknown cfg.online.ablation variant: %s',variant);
            end

            ev=make_evaluation(method,char(variant),initialModel,updatedModel, ...
                trainInfo,source,prediction,detectorForMode,updateForMode, ...
                truth,cNominal,layout,cfg);
            ev.ablation=struct( ...
                'variant',char(variant), ...
                'coefficientsAdapted',logical(adapted), ...
                'stateSynchronized',logical(synchronized), ...
                'commonActivationTimes',activationTimes(:).', ...
                'comparisonStartTime',commonStart);
            if adapted && isfield(update,'updatedTrainInfo')
                ev.updatedTrainInfo=update.updatedTrainInfo;
            else
                ev.updatedTrainInfo=struct();
            end
            variantEvals{iVar}=ev;
        end

        % Use frozen/no-sync over the identical post-activation window as the
        % common reference for all four attribution variants.
        idxBase=find(strcmpi(string(ablationVariants),'frozen_no_sync'),1);
        if isempty(idxBase), idxBase=1; end
        basePost=variantEvals{idxBase}.postActivationMetrics;
        baseTracking=variantEvals{idxBase}.trackingMetrics;
        for iVar=1:numel(variantEvals)
            ev=variantEvals{iVar};
            ev.frozenPostActivationMetrics=basePost;
            ev.frozenTrackingMetrics=baseTracking;
            if isfinite(basePost.RMSE) && basePost.RMSE>0 && ...
                    isfinite(ev.postActivationMetrics.RMSE)
                ev.postActivationRMSEImprovementPercent = ...
                    100*(basePost.RMSE-ev.postActivationMetrics.RMSE)/basePost.RMSE;
            else
                ev.postActivationRMSEImprovementPercent=NaN;
            end
            if isfinite(baseTracking.RMSE) && baseTracking.RMSE>0 && ...
                    isfinite(ev.trackingMetrics.RMSE)
                ev.trackingRMSEImprovementPercent = ...
                    100*(baseTracking.RMSE-ev.trackingMetrics.RMSE)/baseTracking.RMSE;
            else
                ev.trackingRMSEImprovementPercent=NaN;
            end
            variantEvals{iVar}=ev;
            evaluations{end+1,1}=ev; %#ok<AGROW>
            [T,urow]=append_summary_row(T,ev,cfg,cTruth);
            if is_canonical_update_mode(ev.mode)
                if isempty(updateRows), updateRows=urow; else, updateRows=[updateRows;urow]; end %#ok<AGROW>
            end
            write_per_variable(ev,outRoot);
            print_rollout(ev);
        end

    else
        % Backward-compatible two-mode path for other experiments.
        frozenEv=[];
        if flags.frozen
            fprintf('\nEvaluating frozen model: %s ...\n',method.displayName);
            prediction=simulate_online_frozen_model_scenario( ...
                initialModel,method,truth,cNominal,layout,cfg);
            frozenEv=make_evaluation(method,'frozen',initialModel,[],trainInfo, ...
                source,prediction,struct(),struct(),truth,cNominal,layout,cfg);
            evaluations{end+1,1}=frozenEv; %#ok<AGROW>
            [T,~]=append_summary_row(T,frozenEv,cfg,cTruth);
            write_per_variable(frozenEv,outRoot);
            print_rollout(frozenEv);
        end

        if flags.online
            fprintf('\nEvaluating online-corrected model: %s ...\n',method.displayName);
            if ~cfg.online.update.enabled
                error('run_online_model_experiments:OnlineUpdateDisabled', ...
                    '%s online=true but cfg.online.update.enabled=false.',method.displayName);
            end
            onlineResult=run_iterative_online_model_correction( ...
                initialModel,baseDataset,observations,truth,method,cNominal,layout,cfg,offlineScale);
            detector=onlineResult.detector;
            update=onlineResult.update;
            prediction=onlineResult.prediction;
            write_online_update_artifacts(method,detector,update,onlineResult,outRoot);

            updatedModel=getfield_default(update,'updatedModel',[]); %#ok<GFLD>
            onlineEv=make_evaluation(method,'online',initialModel,updatedModel, ...
                trainInfo,source,prediction,detector,update,truth,cNominal,layout,cfg);
            if isfield(update,'updatedTrainInfo'), onlineEv.updatedTrainInfo=update.updatedTrainInfo; end
            if ~isempty(frozenEv) && isfield(update,'activationTime') && isfinite(update.activationTime)
                varNames=get_dae_variable_names(cNominal,layout);
                [frozenPost,~]=metrics_on_prediction_window( ...
                    frozenEv.prediction,truth,update.activationTime,varNames,cfg);
                onlineEv.frozenPostActivationMetrics=frozenPost;
                if isfinite(frozenPost.RMSE) && isfinite(onlineEv.postActivationMetrics.RMSE) && frozenPost.RMSE>0
                    onlineEv.postActivationRMSEImprovementPercent = ...
                        100*(frozenPost.RMSE-onlineEv.postActivationMetrics.RMSE)/frozenPost.RMSE;
                else
                    onlineEv.postActivationRMSEImprovementPercent=NaN;
                end
            else
                onlineEv.frozenPostActivationMetrics=failed_summary_only();
                onlineEv.postActivationRMSEImprovementPercent=NaN;
            end
            evaluations{end+1,1}=onlineEv; %#ok<AGROW>
            [T,urow]=append_summary_row(T,onlineEv,cfg,cTruth);
            if isempty(updateRows), updateRows=urow; else, updateRows=[updateRows;urow]; end %#ok<AGROW>
            write_per_variable(onlineEv,outRoot);
            print_rollout(onlineEv);
        end
    end
end

writetable(T,fullfile(outRoot,'online_whole_trajectory_metrics.csv'));
write_online_tracking_metrics(T,outRoot);
if ablationEnabled
    writetable(T,fullfile(outRoot,'online_ablation_metrics.csv'));
    A=write_stage3_ablation_attribution(T,outRoot);
else
    A=table();
end
if ~isempty(updateRows)
    writetable(updateRows,fullfile(outRoot,'online_update_events.csv'));
end
print_online_tracking_summary(T,A);
disp(T);
plot_online_trajectory_comparison(truth,evaluations,cNominal,cfg,figDir);
plot_online_update_detector(evaluations,cfg,figDir);
plot_online_manuscript_summary(truth,evaluations,cNominal,cfg,figDir);
if ablationEnabled
    plot_online_ablation_summary(evaluations,cfg,figDir);
end

report=struct();
report.schemaVersion='online_model_experiment_stage3_tracking_metrics_v7';
report.caseName=cNominal.name;
report.caseFunction=string(func2str(caseFcn));
report.configFunction=string(func2str(configFcn));
report.config=cfg;
report.methodPlan=plan;
report.nominalCase=cNominal;
report.truthCase=cTruth;
report.layout=layout;
report.truth=truth;
report.observations=observations;
report.baseDatasetSource=baseDatasetSource;
report.evaluations=evaluations;
report.table=T;
report.updateEvents=updateRows;
report.outputRoot=outRoot;

save(fullfile(outRoot,'online_model_experiment_results.mat'),'report','-v7.3');
fprintf('\nOnline model experiment finished.\n');
fprintf('Output root       : %s\n',outRoot);
fprintf('Observation stream: %s\n',obsFile);
end

function D=make_truth_parameter_mismatch(c,cfg)
P=cfg.online.parameterMismatch;
D=struct();
D.enabled=logical(P.enabled);
D.deviceType=P.deviceType;
D.device=P.device;
D.parameter=P.parameter;
D.component=P.component;
D.profile=P.profile;
D.time=c.sim.t0;
D.endTime=c.sim.tf;
D.transition=0;
D.mode=P.mode;

% Preserve schedule fields exactly. Earlier versions copied only P.value,
% which silently discarded P.times/P.values and made a piecewise profile
% impossible for mg_parameter_profile to evaluate.
if isfield(P,'times') && ~isempty(P.times)
    D.times=double(P.times(:).');
end
if isfield(P,'values') && ~isempty(P.values)
    D.values=P.values(:).';
end
if isfield(P,'value')
    D.value=P.value;
elseif isfield(D,'values')
    D.value=D.values;
else
    D.value=[];
end

if any(strcmpi(string(D.profile),["piecewise_constant","piecewise","schedule"]))
    if ~isfield(D,'times') || ~isfield(D,'values') || isempty(D.times) || isempty(D.values)
        error('run_online_model_experiments:PiecewiseMismatchSchedule', ...
            'Piecewise parameter mismatch requires cfg.online.parameterMismatch.times and values.');
    end
    if numel(D.times)~=numel(D.values)
        error('run_online_model_experiments:PiecewiseMismatchLength', ...
            'Piecewise parameter mismatch times and values must have equal length.');
    end
end
end

function plan=get_online_method_plan(cfg)
M=cfg.online.methods;
plan=struct('configName',{},'methodName',{},'frozen',{},'online',{});
plan(end+1)=entry('neuralODE','neural_ode_modular',M.neuralODE); %#ok<AGROW>
plan(end+1)=entry('modularKoopman','modular_koopman_kbf',M.modularKoopman); %#ok<AGROW>
plan(end+1)=entry('vanillaSINDy','vanilla_sindy',M.vanillaSINDy); %#ok<AGROW>
plan(end+1)=entry('physicsEmbeddedSINDy','physics_embedded_sindy',M.physicsEmbeddedSINDy); %#ok<AGROW>
plan(end+1)=entry('neuralSINDy','neural_sindy',M.neuralSINDy); %#ok<AGROW>
plan(end+1)=entry('physicsNeuralCompositionalSINDy','physics_neural_compositional_sindy',M.physicsNeuralCompositionalSINDy); %#ok<AGROW>
plan(end+1)=entry('physicsNeuralSINDy','physics_neural_sindy',M.physicsNeuralSINDy); %#ok<AGROW>
if isfield(M,'llmPriorSINDy') && isstruct(M.llmPriorSINDy)
    plan(end+1)=entry('llmPriorSINDy','llm_prior_sindy',M.llmPriorSINDy); %#ok<AGROW>
end
plan=plan([plan.frozen] | [plan.online]);

    function e=entry(configName,methodName,s)
        e=struct('configName',configName,'methodName',methodName, ...
            'frozen',logical(s.frozen),'online',logical(s.online));
    end
end

function cfg=activate_registry_for_online_plan(cfg,plan)
requested=string({plan.methodName});
if any(requested=="neural_ode_modular"), cfg.node.enabled=true; end
if any(requested=="modular_koopman_kbf"), cfg.koopman.enabled=true; end
sindyRequested=contains(requested,"sindy");
if any(sindyRequested)
    cfg.sindy.enabled=true;
    if any(requested=="vanilla_sindy"), cfg.sindy.vanilla.enabled=true; end
    if any(requested=="physics_embedded_sindy"), cfg.sindy.physicsEmbedded.enabled=true; end
    if any(requested=="neural_sindy"), cfg.sindy.neural.enabled=true; end
    if any(requested=="physics_neural_compositional_sindy"), cfg.sindy.physicsNeuralCompositional.enabled=true; end
    if any(requested=="physics_neural_sindy"), cfg.sindy.physicsNeural.enabled=true; end
    if any(requested=="llm_prior_sindy")
        if ~isfield(cfg.sindy,'llmPrior') || ~isstruct(cfg.sindy.llmPrior)
            error('run_online_model_experiments:LLMPriorConfig', ...
                'cfg.sindy.llmPrior is required for LLM-Prior SINDy online deployment.');
        end
        cfg.sindy.llmPrior.enabled=true;
    end
end
end

function [methods,planOut]=resolve_online_method_plan(allMethods,plan)
methods=struct([]); planOut=struct([]);
available=string({allMethods.name});
for i=1:numel(plan)
    idx=find(available==string(plan(i).methodName),1);
    if isempty(idx)
        error('run_online_model_experiments:MethodRegistry', ...
            'Requested method %s is not available in the active registry.',plan(i).methodName);
    end
    if isempty(methods)
        methods=allMethods(idx);
        planOut=plan(i);
    else
        methods(end+1)=allMethods(idx); %#ok<AGROW>
        planOut(end+1)=plan(i); %#ok<AGROW>
    end
end
end

function scale=get_detector_scale(base,cfg)
if isfield(base,'metadata') && isfield(base.metadata,'vectorFieldNoiseScale') && ...
        numel(base.metadata.vectorFieldNoiseScale)==size(base.x,2)
    scale=base.metadata.vectorFieldNoiseScale(:);
else
    Y=base.labelsClean;
    scale=std(Y,0,1).';
    rmsScale=sqrt(mean(Y.^2,1)).';
    scale=max(scale,0.05*rmsScale);
end
scale=max(scale,cfg.online.update.detector.scaleFloor);
end

function tf=online_ablation_enabled(cfg)
tf=isfield(cfg,'online') && isfield(cfg.online,'ablation') && ...
    isstruct(cfg.online.ablation) && isfield(cfg.online.ablation,'enabled') && ...
    logical(cfg.online.ablation.enabled);
end

function variants=get_online_ablation_variants(cfg)
variants={'frozen_no_sync','frozen_sync','adapted_no_sync','adapted_sync'};
if online_ablation_enabled(cfg) && isfield(cfg.online.ablation,'variants') && ...
        ~isempty(cfg.online.ablation.variants)
    variants=cellstr(string(cfg.online.ablation.variants));
end
required=["frozen_no_sync","frozen_sync","adapted_no_sync","adapted_sync"];
if ~all(ismember(required,lower(string(variants))))
    error('run_online_model_experiments:AblationVariants', ...
        ['Stage-3 ablation must include frozen_no_sync, frozen_sync, ', ...
         'adapted_no_sync, and adapted_sync.']);
end
end

function [adapted,synchronized]=ablation_variant_factors(mode)
mode=lower(string(mode));
switch mode
    case "frozen_no_sync"
        adapted=false; synchronized=false;
    case "frozen_sync"
        adapted=false; synchronized=true;
    case "adapted_no_sync"
        adapted=true; synchronized=false;
    case "adapted_sync"
        adapted=true; synchronized=true;
    case "online" % legacy full online deployment
        adapted=true; synchronized=true;
    case "frozen"
        adapted=false; synchronized=false;
    otherwise
        adapted=false; synchronized=false;
end
end

function tf=is_adaptive_mode(mode)
[tf,~]=ablation_variant_factors(mode);
end

function tf=is_canonical_update_mode(mode)
mode=lower(string(mode));
tf = mode=="adapted_sync" || mode=="online";
end

function U=make_ablation_update_view(update,activationTimes,commonStart,adapted,synchronized)
% Build deployment-specific metadata without altering the canonical causal
% update record used to generate the shared activation schedule.
U=update;
U.comparisonActivationTime=commonStart;
U.commonActivationTimes=activationTimes(:).';
U.coefficientsAdapted=logical(adapted);
U.stateSynchronizedAtActivation=logical(synchronized);

if adapted
    if synchronized
        U.strategy=string(getfield_default(update,'strategy',''))+" + state_sync"; %#ok<GFLD>
    else
        U.strategy=string(getfield_default(update,'strategy',''))+" + no_state_sync"; %#ok<GFLD>
    end
else
    U.updatedModel=[];
    U.updatedTrainInfo=struct();
    U.candidateAccepted=false;
    U.trainingTimeSeconds=NaN;
    U.candidateReadyTime=NaN;
    U.validation=struct();
    U.acceptedUpdateCount=0;
    U.rejectedUpdateCount=0;
    U.updateCount=0;
    U.attemptCount=0;
    if synchronized && ~isempty(activationTimes)
        U.strategy="state_sync_only_common_schedule";
        U.activationTimes=activationTimes(:).';
        U.activationTime=activationTimes(1);
        U.activatedWithinHorizon=true;
    else
        U.strategy="frozen_no_update";
        U.activationTimes=[];
        U.activationTime=NaN;
        U.activatedWithinHorizon=false;
    end
end
end

function write_online_update_artifacts(method,detector,update,onlineResult,outRoot)
if isfield(detector,'table') && istable(detector.table)
    writetable(detector.table,fullfile(outRoot,sprintf('%s_online_detector.csv',method.name)));
end
if isfield(detector,'historyTable') && istable(detector.historyTable)
    writetable(detector.historyTable,fullfile(outRoot,sprintf('%s_online_detector_history.csv',method.name)));
end
if isfield(update,'historyTable') && istable(update.historyTable)
    writetable(update.historyTable,fullfile(outRoot,sprintf('%s_online_update_history.csv',method.name)));
end
if isfield(onlineResult,'updateLog') && ~isempty(onlineResult.updateLog)
    for iLog=1:numel(onlineResult.updateLog)
        fprintf('%s\n',onlineResult.updateLog(iLog));
    end
end
end

function label=deployment_mode_label(mode)
mode=lower(string(mode));
switch mode
    case "frozen_no_sync", label="F";
    case "frozen_sync", label="F+S";
    case "adapted_no_sync", label="A";
    case "adapted_sync", label="A+S";
    case "frozen", label="F";
    case "online", label="O";
    otherwise, label=upper(mode);
end
end

function ev=make_evaluation(method,mode,initialModel,updatedModel,trainInfo, ...
    source,prediction,detector,update,truth,cNominal,layout,cfg)
varNames=get_dae_variable_names(cNominal,layout);
if prediction.metadata.rolloutSucceeded && isequal(size(truth.y),size(prediction.y)) && ...
        numel(prediction.t)==numel(truth.t)
    [metrics,perVariable]=compute_trajectory_error_metrics( ...
        truth.y,prediction.y,varNames,cfg);
else
    [metrics,perVariable]=failed_metrics(varNames);
end

postStart=NaN;
if isfield(update,'comparisonActivationTime') && isfinite(update.comparisonActivationTime)
    postStart=update.comparisonActivationTime;
elseif isfield(update,'activationTime') && isfinite(update.activationTime)
    postStart=update.activationTime;
end
[postMetrics,postPerVariable]=metrics_on_prediction_window( ...
    prediction,truth,postStart,varNames,cfg);
[trackingMetrics,trackingPerVariable,trackingInfo]=compute_online_tracking_metrics( ...
    prediction,truth,update,cNominal,layout,cfg);

ev=struct();
ev.method=method;
ev.mode=char(mode);
ev.initialModel=initialModel;
ev.updatedModel=updatedModel;
ev.model=initialModel;
if ~isempty(updatedModel), ev.model=updatedModel; end
ev.trainInfo=trainInfo;
ev.initialModelSource=source;
ev.detector=detector;
ev.update=update;
ev.prediction=prediction;
ev.metrics=metrics;
ev.perVariableMetrics=strip_nrmse_report_data(perVariable);
ev.postActivationMetrics=postMetrics;
ev.postActivationPerVariableMetrics=strip_nrmse_report_data(postPerVariable);
ev.trackingMetrics=trackingMetrics;
ev.trackingPerVariableMetrics=strip_nrmse_report_data(trackingPerVariable);
ev.trackingInfo=trackingInfo;
ev.rolloutSucceeded=prediction.metadata.rolloutSucceeded;
ev.rolloutStatus=prediction.metadata.rolloutStatus;
ev.failureTimeSeconds=prediction.metadata.failureTimeSeconds;
ev.trajectoryCoveragePercent=prediction.metadata.trajectoryCoveragePercent;
ev.failureMessage=prediction.metadata.failureMessage;
[ev.coefficientsAdapted,ev.stateSynchronizedAtActivation]=ablation_variant_factors(mode);
ev.comparisonStartTime=postStart;
if is_adaptive_mode(mode) && isfield(update,'trainingTimeSeconds') && isfinite(update.trainingTimeSeconds)
    ev.trainingTimeSeconds=update.trainingTimeSeconds;
else
    ev.trainingTimeSeconds=source.offlineTrainingTimeSeconds;
end
end

function [T,urow]=append_summary_row(T,ev,cfg,cTruth)
row=evaluation_summary_row(ev,cfg.online.initialModelSampleCount, ...
    cfg.online.initialModelNoiseLevel);
row.DeploymentMode=string(ev.mode);
row.DeploymentLabel=deployment_mode_label(ev.mode);
row.CoefficientsAdapted=logical(getfield_default(ev,'coefficientsAdapted',false)); %#ok<GFLD>
row.StateSynchronizedAtActivation=logical(getfield_default(ev,'stateSynchronizedAtActivation',false)); %#ok<GFLD>
row.CommonComparisonStartTimeSec=getfield_default(ev,'comparisonStartTime',NaN); %#ok<GFLD>
row.InitialOfflineTrainingTimeSec=ev.initialModelSource.offlineTrainingTimeSeconds;
row.OnlineObservationNoisePercent=100*cfg.online.observationNoiseLevel;
row.TriggerDetected=false;
row.TriggerTimeSec=NaN;
row.AffectedModule="";
row.LocalizationMatchesInjectedMismatch=false;
row.OnlineUpdateStrategy="";
row.OnlineRetrainingTimeSec=NaN;
row.CandidateReadyTimeSec=NaN;
row.CandidateAccepted=false;
row.CandidateValidationOldScore=NaN;
row.CandidateValidationNewScore=NaN;
row.CandidateValidationImprovementPercent=NaN;
row.ModelActivationTimeSec=NaN;
row.ModelActivationTimesSec="";
row.StateSynchronizationTimesSec="";
row.OnlineUpdateStageCount=0;
row.OnlineUpdateAttemptCount=0;
row.AcceptedOnlineUpdateCount=0;
row.RejectedOnlineUpdateCount=0;
row.ModelUpdated=false;
row.OnlineUniqueSampleCount=0;
row.OnlineReplicatedRowCount=0;
row.PostActivationRMSE=NaN;
row.PostActivationMAE=NaN;
row.PostActivationMaxAE=NaN;
row.FrozenPostActivationRMSE=NaN;
row.PostActivationRMSEImprovementPercent=NaN;
row.TrackingWindowCount=0;
row.TrackingWindowsSec="";
row.TrackingDurationSec=NaN;
row.TrackingCoveragePercent=NaN;
row.TrackingRMSE=NaN;
row.TrackingMAE=NaN;
row.KeyVoltageBus=NaN;
row.KeyVoltageTrackingRMSE=NaN;
row.KeyVoltageTrackingMAE=NaN;
row.KeyVoltageTrackingMeanError=NaN;
row.FrozenTrackingRMSE=NaN;
row.TrackingRMSEImprovementPercent=NaN;

% Detector information is shared by the controlled Stage-3 variants that
% use the causal activation schedule. The completely frozen/no-sync branch
% intentionally has no detector requirement.
if isfield(ev,'detector') && isstruct(ev.detector) && ...
        isfield(ev.detector,'triggered') && logical(ev.detector.triggered)
    row.TriggerDetected=true;
    row.TriggerTimeSec=ev.detector.triggerTime;
    if isfield(ev.detector,'affectedModuleLabel')
        row.AffectedModule=string(ev.detector.affectedModuleLabel);
    end
    if isfield(ev.detector,'affectedDeviceType') && isfield(ev.detector,'affectedDeviceIndex')
        row.LocalizationMatchesInjectedMismatch = ...
            strcmpi(string(ev.detector.affectedDeviceType),string(cTruth.drift.deviceType)) && ...
            ismember(ev.detector.affectedDeviceIndex,double(cTruth.drift.device(:).'));
    end
end

if isfield(ev,'ablation') && isstruct(ev.ablation) && ...
        isfield(ev.ablation,'commonActivationTimes') && ~isempty(ev.ablation.commonActivationTimes)
    acts=double(ev.ablation.commonActivationTimes(:).');
    if row.StateSynchronizedAtActivation
        row.StateSynchronizationTimesSec=string(mat2str(acts,6));
    end
    if row.CoefficientsAdapted
        row.ModelActivationTimesSec=string(mat2str(acts,6));
        row.ModelActivationTimeSec=acts(1);
    end
end

if row.CoefficientsAdapted
    if isfield(ev.update,'strategy'), row.OnlineUpdateStrategy=string(ev.update.strategy); end
    if isfield(ev.update,'trainingTimeSeconds'), row.OnlineRetrainingTimeSec=ev.update.trainingTimeSeconds; end
    if isfield(ev.update,'candidateReadyTime'), row.CandidateReadyTimeSec=ev.update.candidateReadyTime; end
    if isfield(ev.update,'candidateAccepted'), row.CandidateAccepted=logical(ev.update.candidateAccepted); end
    if isfield(ev.update,'activationTime') && isfinite(ev.update.activationTime)
        row.ModelActivationTimeSec=ev.update.activationTime;
    end
    if isfield(ev.update,'activationTimes') && ~isempty(ev.update.activationTimes)
        row.ModelActivationTimesSec=string(mat2str(ev.update.activationTimes,6));
    end
    if isfield(ev.update,'updateCount'), row.OnlineUpdateStageCount=ev.update.updateCount; end
    if isfield(ev.update,'attemptCount')
        row.OnlineUpdateAttemptCount=ev.update.attemptCount;
    else
        row.OnlineUpdateAttemptCount=row.OnlineUpdateStageCount;
    end
    if isfield(ev.update,'acceptedUpdateCount'), row.AcceptedOnlineUpdateCount=ev.update.acceptedUpdateCount; end
    if isfield(ev.update,'rejectedUpdateCount'), row.RejectedOnlineUpdateCount=ev.update.rejectedUpdateCount; end
    row.ModelUpdated = row.AcceptedOnlineUpdateCount>0 || logical(getfield_default(ev.update,'activatedWithinHorizon',false)); %#ok<GFLD>
    if isfield(ev.update,'validation') && isstruct(ev.update.validation)
        row.CandidateValidationOldScore=getfield_default(ev.update.validation,'currentModelScore',NaN); %#ok<GFLD>
        row.CandidateValidationNewScore=getfield_default(ev.update.validation,'candidateModelScore',NaN); %#ok<GFLD>
        rel=getfield_default(ev.update.validation,'relativeImprovement',NaN); %#ok<GFLD>
        row.CandidateValidationImprovementPercent=100*rel;
    end
    if isfield(ev.update,'dataInfo')
        row.OnlineUniqueSampleCount=getfield_default(ev.update.dataInfo,'onlineUniqueSampleCount',0); %#ok<GFLD>
        row.OnlineReplicatedRowCount=getfield_default(ev.update.dataInfo,'onlineReplicatedRowCount',0); %#ok<GFLD>
    end
elseif row.StateSynchronizedAtActivation
    row.OnlineUpdateStrategy="state_sync_only_common_schedule";
end

if isfield(ev,'postActivationMetrics')
    row.PostActivationRMSE=ev.postActivationMetrics.RMSE;
    row.PostActivationMAE=ev.postActivationMetrics.MAE;
    row.PostActivationMaxAE=ev.postActivationMetrics.MaxAE;
end
if isfield(ev,'frozenPostActivationMetrics')
    row.FrozenPostActivationRMSE=ev.frozenPostActivationMetrics.RMSE;
end
if isfield(ev,'postActivationRMSEImprovementPercent')
    row.PostActivationRMSEImprovementPercent=ev.postActivationRMSEImprovementPercent;
end
if isfield(ev,'trackingMetrics') && isstruct(ev.trackingMetrics)
    M=ev.trackingMetrics;
    row.TrackingWindowCount=getfield_default(M,'WindowCount',0); %#ok<GFLD>
    windows=getfield_default(M,'Windows',zeros(0,2)); %#ok<GFLD>
    if ~isempty(windows), row.TrackingWindowsSec=string(mat2str(windows,6)); end
    row.TrackingDurationSec=getfield_default(M,'DurationSec',NaN); %#ok<GFLD>
    row.TrackingCoveragePercent=getfield_default(M,'CoveragePercent',NaN); %#ok<GFLD>
    row.TrackingRMSE=getfield_default(M,'RMSE',NaN); %#ok<GFLD>
    row.TrackingMAE=getfield_default(M,'MAE',NaN); %#ok<GFLD>
    row.KeyVoltageBus=getfield_default(M,'KeyVoltageBus',NaN); %#ok<GFLD>
    row.KeyVoltageTrackingRMSE=getfield_default(M,'KeyVoltageRMSE',NaN); %#ok<GFLD>
    row.KeyVoltageTrackingMAE=getfield_default(M,'KeyVoltageMAE',NaN); %#ok<GFLD>
    row.KeyVoltageTrackingMeanError=getfield_default(M,'KeyVoltageMeanError',NaN); %#ok<GFLD>
end
if isfield(ev,'frozenTrackingMetrics') && isstruct(ev.frozenTrackingMetrics)
    row.FrozenTrackingRMSE=getfield_default(ev.frozenTrackingMetrics,'RMSE',NaN); %#ok<GFLD>
end
if isfield(ev,'trackingRMSEImprovementPercent')
    row.TrackingRMSEImprovementPercent=ev.trackingRMSEImprovementPercent;
end

row.ParameterMismatchDeviceType=string(cTruth.drift.deviceType);
row.ParameterMismatchDevice=double(cTruth.drift.device(1));
row.ParameterMismatchDevices=string(mat2str(double(cTruth.drift.device(:).')));
row.ParameterMismatchParameter=string(cTruth.drift.parameter);
row.ParameterMismatchMode=string(cTruth.drift.mode);
row.ParameterMismatchValue=cTruth.drift.value;
if isempty(T), T=row; else, T=[T;row]; end %#ok<AGROW>

urow=table(string(ev.method.name),string(ev.method.displayName),string(ev.mode), ...
    logical(row.TriggerDetected),row.TriggerTimeSec,row.AffectedModule, ...
    logical(row.LocalizationMatchesInjectedMismatch),row.OnlineUpdateStrategy, ...
    row.OnlineRetrainingTimeSec,row.CandidateReadyTimeSec, ...
    logical(row.CandidateAccepted),row.CandidateValidationOldScore, ...
    row.CandidateValidationNewScore,row.CandidateValidationImprovementPercent, ...
    row.ModelActivationTimeSec,row.ModelActivationTimesSec,row.OnlineUpdateStageCount, ...
    row.OnlineUpdateAttemptCount,row.AcceptedOnlineUpdateCount,row.RejectedOnlineUpdateCount, ...
    logical(row.ModelUpdated),row.OnlineUniqueSampleCount, ...
    row.PostActivationRMSE,row.FrozenPostActivationRMSE, ...
    row.PostActivationRMSEImprovementPercent,row.TrackingRMSE, ...
    row.FrozenTrackingRMSE,row.TrackingRMSEImprovementPercent, ...
    'VariableNames',{'Method','DisplayName','DeploymentMode','TriggerDetected','TriggerTimeSec', ...
    'AffectedModule','LocalizationMatchesInjectedMismatch','OnlineUpdateStrategy', ...
    'OnlineRetrainingTimeSec','CandidateReadyTimeSec','CandidateAccepted', ...
    'CandidateValidationOldScore','CandidateValidationNewScore', ...
    'CandidateValidationImprovementPercent','ModelActivationTimeSec', ...
    'ModelActivationTimesSec','OnlineUpdateStageCount','OnlineUpdateAttemptCount', ...
    'AcceptedOnlineUpdateCount','RejectedOnlineUpdateCount','ModelUpdated', ...
    'OnlineUniqueSampleCount','PostActivationRMSE','FrozenPostActivationRMSE', ...
    'PostActivationRMSEImprovementPercent','TrackingRMSE','FrozenTrackingRMSE', ...
    'TrackingRMSEImprovementPercent'});
end

function A=write_stage3_ablation_attribution(T,outRoot)
%WRITE_STAGE3_ABLATION_ATTRIBUTION Compact 2x2 factorial attribution table.
A=table();
if isempty(T) || ~istable(T) || ...
        ~all(ismember({'Method','DeploymentMode','TrackingRMSE'},T.Properties.VariableNames))
    return;
end
methods=unique(string(T.Method),'stable');
for i=1:numel(methods)
    m=methods(i);
    f = value_for_mode(T,m,'frozen_no_sync','TrackingRMSE');
    fs = value_for_mode(T,m,'frozen_sync','TrackingRMSE');
    a = value_for_mode(T,m,'adapted_no_sync','TrackingRMSE');
    as = value_for_mode(T,m,'adapted_sync','TrackingRMSE');
    vF = value_for_mode(T,m,'frozen_no_sync','KeyVoltageTrackingRMSE');
    vFS = value_for_mode(T,m,'frozen_sync','KeyVoltageTrackingRMSE');
    vA = value_for_mode(T,m,'adapted_no_sync','KeyVoltageTrackingRMSE');
    vAS = value_for_mode(T,m,'adapted_sync','KeyVoltageTrackingRMSE');
    wholeF = value_for_mode(T,m,'frozen_no_sync','RMSE');
    wholeFS = value_for_mode(T,m,'frozen_sync','RMSE');
    wholeA = value_for_mode(T,m,'adapted_no_sync','RMSE');
    wholeAS = value_for_mode(T,m,'adapted_sync','RMSE');

    syncOnly = improvement_percent(f,fs);
    adaptOnly = improvement_percent(f,a);
    fullGain = improvement_percent(f,as);
    syncAfterAdapt = improvement_percent(a,as);
    adaptAfterSync = improvement_percent(fs,as);

    row=table(m,f,fs,a,as,vF,vFS,vA,vAS,wholeF,wholeFS,wholeA,wholeAS, ...
        syncOnly,adaptOnly,fullGain,syncAfterAdapt,adaptAfterSync, ...
        'VariableNames',{'Method','TrackRMSE_F','TrackRMSE_FS','TrackRMSE_A','TrackRMSE_AS', ...
        'VTrackRMSE_F','VTrackRMSE_FS','VTrackRMSE_A','VTrackRMSE_AS', ...
        'WholeRMSE_F','WholeRMSE_FS','WholeRMSE_A','WholeRMSE_AS', ...
        'TrackSyncOnlyImprovementPercent','TrackAdaptOnlyImprovementPercent', ...
        'TrackFullImprovementPercent','TrackSyncAfterAdaptationImprovementPercent', ...
        'TrackAdaptationAfterSyncImprovementPercent'});
    if isempty(A), A=row; else, A=[A;row]; end %#ok<AGROW>
end
writetable(A,fullfile(outRoot,'online_ablation_attribution.csv'));
end

function write_online_tracking_metrics(T,outRoot)
if isempty(T) || ~istable(T) || ~ismember('TrackingRMSE',T.Properties.VariableNames)
    return;
end
want={'Method','DisplayName','DeploymentMode','DeploymentLabel','RMSE','MAE', ...
    'TrackingWindowCount','TrackingWindowsSec','TrackingDurationSec', ...
    'TrackingCoveragePercent','TrackingRMSE','TrackingMAE','KeyVoltageBus', ...
    'KeyVoltageTrackingRMSE','KeyVoltageTrackingMAE','KeyVoltageTrackingMeanError', ...
    'TrackingRMSEImprovementPercent'};
keep=want(ismember(want,T.Properties.VariableNames));
writetable(T(:,keep),fullfile(outRoot,'online_tracking_metrics.csv'));
end

function print_online_tracking_summary(T,A)
if isempty(T) || ~istable(T) || ~ismember('TrackingRMSE',T.Properties.VariableNames)
    return;
end
fprintf('\n---------------- NON-DELAY TRACKING METRICS ----------------\n');
fprintf(['Tracking windows exclude accepted mismatch/update delay intervals; ', ...
    'latency and active-model tracking are reported separately.\n']);
vars={'DeploymentLabel','RMSE','TrackingRMSE','TrackingMAE', ...
    'KeyVoltageBus','KeyVoltageTrackingRMSE','KeyVoltageTrackingMAE', ...
    'TrackingDurationSec','TrackingCoveragePercent'};
vars=vars(ismember(vars,T.Properties.VariableNames));
disp(T(:,vars));
if nargin>=2 && istable(A) && ~isempty(A)
    fprintf('\n---------------- TRACKING ATTRIBUTION ----------------\n');
    disp(A);
end
end

function v=value_for_mode(T,methodName,mode,varName)
mask=strcmpi(string(T.Method),methodName) & strcmpi(string(T.DeploymentMode),mode);
idx=find(mask,1,'first');
if isempty(idx)
    v=NaN;
else
    v=double(T.(varName)(idx));
end
end

function p=improvement_percent(reference,value)
if isfinite(reference) && reference>0 && isfinite(value)
    p=100*(reference-value)/reference;
else
    p=NaN;
end
end

function [summary,perVariable]=metrics_on_prediction_window(prediction,truth,startTime,varNames,cfg)
if ~isfinite(startTime) || ~isfield(prediction,'t') || isempty(prediction.t) || ...
        ~isfield(prediction,'y') || isempty(prediction.y)
    [summary,perVariable]=failed_metrics(varNames);
    return;
end
mask=prediction.t(:)>=startTime-1e-12;
if nnz(mask)<2 || size(prediction.y,2)~=size(truth.y,2)
    [summary,perVariable]=failed_metrics(varNames);
    return;
end
tPred=prediction.t(mask);
yPred=prediction.y(mask,:);
yTruth=interp1(truth.t,truth.y,tPred,'linear');
if any(~isfinite(yPred),'all') || any(~isfinite(yTruth),'all')
    [summary,perVariable]=failed_metrics(varNames);
    return;
end
[summary,perVariable]=compute_trajectory_error_metrics(yTruth,yPred,varNames,cfg);
end

function S=failed_summary_only()
S=struct('RMSE',NaN,'MAE',NaN,'MaxAE',NaN,'NMaxAE_Range',NaN, ...
    'MAPE_percent',NaN,'sMAPE_percent',NaN,'MAPE_valid_fraction',NaN,'MeanR2',NaN);
end

function write_per_variable(ev,outRoot)
name=sprintf('%s_%s_per_variable_metrics.csv', ...
    char(string(ev.method.name)),lower(char(string(ev.mode))));
writetable(ev.perVariableMetrics,fullfile(outRoot,name));
if isfield(ev,'postActivationPerVariableMetrics') && ...
        istable(ev.postActivationPerVariableMetrics)
    name2=sprintf('%s_%s_post_activation_per_variable_metrics.csv', ...
        char(string(ev.method.name)),lower(char(string(ev.mode))));
    writetable(ev.postActivationPerVariableMetrics,fullfile(outRoot,name2));
end
if isfield(ev,'trackingPerVariableMetrics') && istable(ev.trackingPerVariableMetrics)
    name3=sprintf('%s_%s_tracking_per_variable_metrics.csv', ...
        char(string(ev.method.name)),lower(char(string(ev.mode))));
    writetable(ev.trackingPerVariableMetrics,fullfile(outRoot,name3));
end
end

function print_rollout(ev)
p=ev.prediction.metadata;
if p.rolloutSucceeded
    if isfinite(ev.metrics.RMSE)
        if isfield(ev,'trackingMetrics') && isstruct(ev.trackingMetrics) && ...
                isfinite(getfield_default(ev.trackingMetrics,'RMSE',NaN)) %#ok<GFLD>
            fprintf(['  %s rollout: SUCCESS | whole-window RMSE=%.6g | ', ...
                'tracking RMSE=%.6g | tracking MAE=%.6g'], ...
                char(deployment_mode_label(ev.mode)),ev.metrics.RMSE, ...
                ev.trackingMetrics.RMSE,ev.trackingMetrics.MAE);
            if isfinite(getfield_default(ev.trackingMetrics,'KeyVoltageRMSE',NaN)) %#ok<GFLD>
                fprintf(' | V%d tracking RMSE=%.6g', ...
                    round(ev.trackingMetrics.KeyVoltageBus),ev.trackingMetrics.KeyVoltageRMSE);
            end
            fprintf('\n');
        else
            fprintf('  %s rollout: SUCCESS | whole-window RMSE=%.6g | MAE=%.6g\n', ...
                char(deployment_mode_label(ev.mode)),ev.metrics.RMSE,ev.metrics.MAE);
        end
    elseif isfield(ev,'postActivationMetrics') && isfinite(ev.postActivationMetrics.RMSE)
        fprintf(['  %s rollout: %s | post-activation RMSE=%.6g | ', ...
            'MAE=%.6g | MaxAE=%.6g\n'],char(deployment_mode_label(ev.mode)),char(string(p.rolloutStatus)), ...
            ev.postActivationMetrics.RMSE,ev.postActivationMetrics.MAE, ...
            ev.postActivationMetrics.MaxAE);
    else
        fprintf('  %s rollout: %s | no complete metric window available.\n', ...
            char(deployment_mode_label(ev.mode)),char(string(p.rolloutStatus)));
    end
else
    fprintf('  %s rollout: %s | reached t=%.6g s | coverage %.3f%%\n', ...
        char(deployment_mode_label(ev.mode)),char(string(p.rolloutStatus)),p.failureTimeSeconds,p.trajectoryCoveragePercent);
end
end

function [summary,perVariable]=failed_metrics(varNames)
n=numel(varNames); z=nan(n,1);
summary=struct('RMSE',NaN,'MAE',NaN,'MaxAE',NaN,'NMaxAE_Range',NaN, ...
    'MAPE_percent',NaN,'sMAPE_percent',NaN,'MAPE_valid_fraction',NaN,'MeanR2',NaN);
perVariable=table(string(varNames(:)),z,z,z,z,z,z,z,z, ...
    'VariableNames',{'Variable','RMSE','MAE','MaxAE','NMaxAE_Range', ...
    'MAPE_percent','sMAPE_percent','MAPE_valid_fraction','R2'});
end

function U=empty_update()
U=struct('triggered',false,'triggerTime',NaN,'trainingStarted',false, ...
    'trainingCompleted',false,'trainingTimeSeconds',NaN,'candidateReadyTime',inf, ...
    'candidateAccepted',false,'activationTime',inf,'activatedWithinHorizon',false, ...
    'candidateModel',[],'updatedModel',[],'updatedTrainInfo',struct(), ...
    'dataInfo',struct(),'localUpdateInfo',struct(),'validation',struct(), ...
    'affectedModuleLabel',"",'affectedDeviceType','', ...
    'affectedDeviceIndex',NaN,'strategy','', 'failureMessage',"");
end

function value=getfield_default(S,name,defaultValue)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), value=S.(name); else, value=defaultValue; end
end

function write_parameter_profile_csv(truth,outRoot)
if ~isfield(truth,'parameters')||~isfield(truth.parameters,'driftValue')||isempty(truth.parameters.driftValue), return; end
D=truth.metadata.caseData.drift;
c0=truth.metadata.caseData; c0.drift.enabled=false;
p0=mg_parameter_profile(truth.t(1),c0);
type=lower(char(D.deviceType)); field=char(D.parameter);

% Keep the historical representative columns first for compatibility.
v=truth.parameters.driftValue(:);
repDev=truth.parameters.driftDevice;
nominal=p0.(type)(repDev).(field);
if isreal(v)
    rel=nan(size(v)); if abs(nominal)>eps, rel=v/nominal-1; end
    T=table(truth.t(:),real(v),100*real(rel), ...
        'VariableNames',{'Time_s','ParameterValue','RelativeMismatch_percent'});
else
    T=table(truth.t(:),real(v),imag(v),'VariableNames',{'Time_s','ParameterReal','ParameterImag'});
end

% Multi-device online cases additionally export every perturbed device profile.
if isfield(truth.parameters,'driftValues') && ~isempty(truth.parameters.driftValues) && ...
        isfield(truth.parameters,'driftDevices') && ~isempty(truth.parameters.driftDevices)
    devices=double(truth.parameters.driftDevices(:).');
    V=truth.parameters.driftValues;
    for iDev=1:numel(devices)
        dev=devices(iDev);
        values=V(iDev,:).';
        baseName=matlab.lang.makeValidName(sprintf('%s%d_%s',upper(type),dev,field));
        T.(baseName)=real(values);
        nom=p0.(type)(dev).(field);
        if isreal(values) && isreal(nom) && abs(nom)>eps
            T.([baseName '_RelativeMismatch_percent'])=100*(real(values)/real(nom)-1);
        end
    end
end
writetable(T,fullfile(outRoot,'online_parameter_profile.csv'));
end

function s=onoff(v)
if v, s='enabled'; else, s='disabled'; end
end


function tf=trajectory_calibration_requested(cfg)
tf=false;
if ~isstruct(cfg) || ~isfield(cfg,'online') || ~isfield(cfg.online,'update') || ...
        ~isfield(cfg.online.update,'detector') || ~isstruct(cfg.online.update.detector)
    return;
end
D=cfg.online.update.detector;
if isfield(D,'trajectoryCalibrationEnabled')
    tf=logical(D.trajectoryCalibrationEnabled);
elseif isfield(D,'calibrationSource')
    tf=strcmpi(string(D.calibrationSource),'heldout_nominal_trajectory');
end
end

function [cfgOut,info]=maybe_apply_online_detector_trajectory_calibration(projectRoot,cfgIn,initialModel,method,baseDataset,cNominal,layout,truthMismatch,obsMismatch,offlineScale,outRoot)
% Apply held-out nominal-trajectory detector calibration for the official
% 69-bus LLM-Prior online run. The calibrated thresholds are then injected
% back into cfg.online.update.detector.fixedModuleThresholds so the actual
% deployment run uses the same official settings that were previously tested
% in the dedicated smoke script.

cfgOut=cfgIn;
info=struct();
if ~trajectory_calibration_requested(cfgIn)
    return;
end
if isempty(baseDataset)
    warning('run_online_model_experiments:TrajectoryCalibrationNoBaseDataset', ...
        'Trajectory calibration requested, but baseDataset is empty. Skipping calibration.');
    return;
end
figDir=fullfile(outRoot,'figures');
if ~exist(figDir,'dir'), mkdir(figDir); end
D=cfgIn.online.update.detector;
baseThreshold=double(D.threshold);
qLevel=getfield_default(D,'trajectoryCalibrationQuantile',0.995);
qMultiplier=getfield_default(D,'trajectoryCalibrationMultiplier',1.10);
maxSafetyMultiplier=getfield_default(D,'trajectoryCalibrationMaxSafetyMultiplier',1.02);
calSeed=getfield_default(D,'trajectoryCalibrationNoiseSeed',cfgIn.online.observationNoiseSeed);
minTime=double(D.minimumTriggerTime);
reqConsecutive=max(1,round(double(D.requiredConsecutiveWindows)));

cfgCal=cfgIn;
cfgCal.online.parameterMismatch.enabled=false;
cfgCal.online.observationNoiseSeed=calSeed;
cfgCal.online.update.detector.calibrateFromOffline=false;
if isfield(cfgCal.online.update.detector,'fixedModuleThresholds')
    cfgCal.online.update.detector=rmfield(cfgCal.online.update.detector,'fixedModuleThresholds');
end
truthCal=simulate_reference_truth_scenario(cNominal,layout);
obsCal=build_online_observation_stream(truthCal,cfgCal.online.observationNoiseLevel,cfgCal);
dCal=detect_online_model_mismatch(initialModel,method,obsCal,cNominal,layout,cfgCal,offlineScale,baseDataset);

nMod=numel(dCal.moduleLabels);
thresholds=nan(nMod,1);
qScore=nan(nMod,1);
maxScore=nan(nMod,1);
calFalseBefore=false(nMod,1);
calFalseAfter=false(nMod,1);
calFirstAfter=nan(nMod,1);
for m=1:nMod
    mask=dCal.time>=minTime & isfinite(dCal.moduleRollingScore(:,m));
    vals=dCal.moduleRollingScore(mask,m);
    qScore(m)=trajectory_calibration_empirical_quantile(vals,qLevel);
    maxScore(m)=max(vals,[],'omitnan');
    tau=max(baseThreshold,qMultiplier*qScore(m));
    ratio0=dCal.moduleRollingScore(:,m)/tau;
    [calFalseBefore(m),~]=trajectory_calibration_persistent_crossing( ...
        dCal.time,ratio0,minTime,reqConsecutive);
    if calFalseBefore(m)
        tau=max(tau,maxSafetyMultiplier*maxScore(m));
    end
    thresholds(m)=tau;
    ratio=dCal.moduleRollingScore(:,m)/tau;
    [calFalseAfter(m),calFirstAfter(m)]=trajectory_calibration_persistent_crossing( ...
        dCal.time,ratio,minTime,reqConsecutive);
end

cfgPreview=cfgIn;
cfgPreview.online.update.detector.calibrateFromOffline=false;
cfgPreview.online.update.detector.fixedModuleThresholds=thresholds;
dPreview=detect_online_model_mismatch(initialModel,method,obsMismatch,cNominal,layout,cfgPreview,offlineScale,baseDataset);

mismatchMax=max(dPreview.moduleRollingScore,[],1,'omitnan').';
mismatchRatio=mismatchMax./thresholds;
previewTrigger=false(nMod,1);
previewTriggerTime=nan(nMod,1);
for m=1:nMod
    [previewTrigger(m),previewTriggerTime(m)]=trajectory_calibration_persistent_crossing( ...
        dPreview.time,dPreview.moduleRollingScore(:,m)./thresholds(m), ...
        minTime,reqConsecutive);
end

C=table(string(dCal.moduleLabels),repmat(baseThreshold,nMod,1),qScore,maxScore, ...
    thresholds,calFalseBefore,calFalseAfter,calFirstAfter,mismatchMax,mismatchRatio, ...
    previewTrigger,previewTriggerTime, ...
    'VariableNames',{'Module','BaseThreshold','NominalRollingQ995', ...
    'NominalRollingMax','FixedTrajectoryCalibratedThreshold', ...
    'QCalibrationWouldFalseTrigger','FinalCalibrationFalseTrigger', ...
    'FinalCalibrationFirstFalseTriggerTime_s','MismatchRollingMax', ...
    'MismatchMaxTriggerRatio','MismatchWouldTrigger','MismatchFirstTriggerTime_s'});

writetable(C,fullfile(outRoot,'trajectory_calibrated_module_thresholds.csv'));
[pdfCal,pngCal]=plot_online_detector_trajectory_calibration( ...
    dCal,dPreview,thresholds,truthMismatch,figDir);

cfgOut.online.update.detector.calibrateFromOffline=false;
cfgOut.online.update.detector.fixedModuleThresholds=thresholds;
cfgOut.online.update.detector.calibrationSource='heldout_nominal_trajectory';
cfgOut.online.update.detector.trajectoryCalibrationApplied=true;
cfgOut.online.update.detector.trajectoryCalibrationQuantile=qLevel;
cfgOut.online.update.detector.trajectoryCalibrationMultiplier=qMultiplier;
cfgOut.online.update.detector.trajectoryCalibrationMaxSafetyMultiplier=maxSafetyMultiplier;
cfgOut.online.update.detector.trajectoryCalibrationNoiseSeed=calSeed;

info=struct();
info.table=C;
info.fixedModuleThresholds=thresholds;
info.figurePDF=pdfCal;
info.figurePNG=pngCal;

fprintf('\n---------------- TRAJECTORY CALIBRATION ----------------\n');
disp(C);
end

function q=trajectory_calibration_empirical_quantile(v,p)
v=v(isfinite(v));
if isempty(v), q=NaN; return; end
v=sort(v(:));
p=min(max(p,0),1);
pos=1+(numel(v)-1)*p;
lo=floor(pos); hi=ceil(pos);
if lo==hi
    q=v(lo);
else
    a=pos-lo;
    q=(1-a)*v(lo)+a*v(hi);
end
end

function [tf,tFirst]=trajectory_calibration_persistent_crossing(t,ratio,minTime,nRequired)
tf=false; tFirst=NaN; count=0;
for k=1:numel(t)
    if t(k)<minTime
        count=0; continue;
    end
    if isfinite(ratio(k)) && ratio(k)>1
        count=count+1;
    else
        count=0;
    end
    if count>=nRequired
        tf=true; tFirst=t(k); return;
    end
end
end

function [pdfPath,pngPath]=plot_online_detector_trajectory_calibration(dCal,dMis,thresholds,truth,figDir)
labels=string(dCal.moduleLabels);
nMod=numel(labels);
cols=lines(nMod);
fig=figure('Name','Held-out nominal-trajectory detector calibration', ...
    'Color','w','Visible','off','Units','pixels','Position',[80 60 1120 820]);
tl=tiledlayout(fig,3,1,'TileSpacing','compact','Padding','compact'); %#ok<NASGU>

ax1=nexttile; hold(ax1,'on');
for m=1:nMod
    plot(ax1,dCal.time,dCal.moduleRollingScore(:,m)/thresholds(m), ...
        'LineWidth',1.1,'Color',cols(m,:),'DisplayName',char(labels(m)));
end
yline(ax1,1,'--','LineWidth',1.5,'Color',[0.35 0.35 0.35], ...
    'DisplayName','Trigger ratio = 1');
ylabel(ax1,'Nominal score / threshold'); xlim(ax1,[truth.t(1) truth.t(end)]);
grid(ax1,'on'); legend(ax1,'Location','eastoutside','Box','on');
text(ax1,0.5,-0.18,'(a)','Units','normalized','HorizontalAlignment','center');

idxGfm=find(strcmpi(labels,'GFM1'),1);
if isempty(idxGfm), idxGfm=1; end
ax2=nexttile; hold(ax2,'on');
plot(ax2,dCal.time,dCal.moduleRollingScore(:,idxGfm),'LineWidth',1.6, ...
    'Color',[0.00 0.4470 0.7410],'DisplayName','Held-out nominal calibration');
plot(ax2,dMis.time,dMis.moduleRollingScore(:,idxGfm),'LineWidth',1.6, ...
    'Color',[0.8500 0.3250 0.0980],'DisplayName','Hidden mismatch preview');
yline(ax2,thresholds(idxGfm),'--','LineWidth',1.5,'Color',[0.25 0.25 0.25], ...
    'DisplayName','Fixed GFM1 threshold');
ylabel(ax2,'GFM1 rolling VF NRMSE'); xlim(ax2,[truth.t(1) truth.t(end)]);
grid(ax2,'on'); legend(ax2,'Location','best','Box','on');
text(ax2,0.5,-0.18,'(b)','Units','normalized','HorizontalAlignment','center');

ax3=nexttile; hold(ax3,'on');
plot(ax3,dCal.time,dCal.moduleRollingScore(:,idxGfm)/thresholds(idxGfm), ...
    'LineWidth',1.5,'Color',[0.00 0.4470 0.7410],'DisplayName','Nominal');
plot(ax3,dMis.time,dMis.moduleRollingScore(:,idxGfm)/thresholds(idxGfm), ...
    'LineWidth',1.5,'Color',[0.4940 0.1840 0.5560],'DisplayName','Mismatch');
yline(ax3,1,'--','LineWidth',1.5,'Color',[0.85 0.325 0.098], ...
    'DisplayName','Trigger ratio = 1');
ylabel(ax3,'GFM1 score / threshold'); xlabel(ax3,'Time (s)');
xlim(ax3,[truth.t(1) truth.t(end)]); grid(ax3,'on');
legend(ax3,'Location','best','Box','on');
text(ax3,0.5,-0.18,'(c)','Units','normalized','HorizontalAlignment','center');

pdfPath=fullfile(figDir,'online_detector_trajectory_calibration.pdf');
pngPath=fullfile(figDir,'online_detector_trajectory_calibration.png');
exportgraphics(fig,pdfPath,'ContentType','vector','BackgroundColor','white');
exportgraphics(fig,pngPath,'Resolution',220,'BackgroundColor','white');
end
