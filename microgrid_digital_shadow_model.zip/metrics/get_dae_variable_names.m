function names = get_dae_variable_names(c,layout)
%GET_DAE_VARIABLE_NAMES Names matching columns of the ODE15I y trajectory.

meta = build_offline_feature_metadata(c,layout);
ns = c.network.nonSlackBuses(:);
names = [meta.stateNames;"V"+string(ns)+"_Re";"V"+string(ns)+"_Im"];
end
