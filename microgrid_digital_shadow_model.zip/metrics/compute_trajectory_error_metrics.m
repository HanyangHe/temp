function [summary,perVariable] = compute_trajectory_error_metrics(yTrue,yPred,varNames,cfg)
%COMPUTE_TRAJECTORY_ERROR_METRICS Whole-scenario DAE trajectory metrics.
%
% Metrics deliberately use the ENTIRE trajectory. MAPE/sMAPE are included as
% requested, but near-zero truth values are masked because percentage errors
% are ill-conditioned for angles, deviations, or controller states crossing 0.

if ~isequal(size(yTrue),size(yPred))
    error('compute_trajectory_error_metrics:Size', ...
        'Truth and prediction trajectories must have the same size.');
end
if size(yTrue,2) ~= numel(varNames)
    error('compute_trajectory_error_metrics:Names', ...
        'Number of variable names must match trajectory columns.');
end

E = yPred-yTrue;
AE = abs(E);
rmseVar = sqrt(mean(E.^2,1));
maeVar = mean(AE,1);
maxaeVar = max(AE,[],1);

rangeTrue = max(yTrue,[],1)-min(yTrue,[],1);
rmsTrue = sqrt(mean(yTrue.^2,1));
stdTrue = std(yTrue,0,1);
maxAbsTrue = max(abs(yTrue),[],1);
baseFloor = max(cfg.metrics.scaleFloorAbsolute, ...
    cfg.metrics.scaleFloorRelative.*max(maxAbsTrue,ones(size(maxAbsTrue))));
rangeScale = max(rangeTrue,baseFloor);
rmsScale = max(rmsTrue,baseFloor);
stdScale = max(stdTrue,baseFloor);

nrmseRangeVar = rmseVar./rangeScale;
nrmseRMSVar = rmseVar./rmsScale;
nrmseStdVar = rmseVar./stdScale;
nmaxaeRangeVar = maxaeVar./rangeScale;

mapeVar = nan(1,size(yTrue,2));
smapeVar = nan(1,size(yTrue,2));
validFraction = zeros(1,size(yTrue,2));
r2Var = nan(1,size(yTrue,2));
for j = 1:size(yTrue,2)
    floorJ = max(cfg.metrics.mapeFloorAbsolute, ...
        cfg.metrics.mapeFloorRelative*max(1,maxAbsTrue(j)));
    mask = abs(yTrue(:,j)) > floorJ;
    validFraction(j) = mean(mask);
    if any(mask)
        mapeVar(j) = 100*mean(AE(mask,j)./abs(yTrue(mask,j)));
    end
    denom = abs(yTrue(:,j))+abs(yPred(:,j));
    maskS = denom > floorJ;
    if any(maskS)
        smapeVar(j) = 100*mean(2*AE(maskS,j)./denom(maskS));
    end
    yc = yTrue(:,j)-mean(yTrue(:,j));
    sst = sum(yc.^2);
    if sst > baseFloor(j)^2
        r2Var(j) = 1-sum(E(:,j).^2)/sst;
    end
end

summary.RMSE = sqrt(mean(E(:).^2));
summary.MAE = mean(AE(:));
summary.MaxAE = max(AE(:));
summary.NRMSE_Range = sqrt(mean((E./rangeScale).^2,'all'));
summary.NRMSE_RMS = sqrt(mean((E./rmsScale).^2,'all'));
summary.NRMSE_Std = sqrt(mean((E./stdScale).^2,'all'));
summary.NMaxAE_Range = max(max(AE./rangeScale));
summary.MAPE_percent = mean(mapeVar,'omitnan');
summary.sMAPE_percent = mean(smapeVar,'omitnan');
summary.MAPE_valid_fraction = mean(validFraction);
summary.MeanR2 = mean(r2Var,'omitnan');

perVariable = table(string(varNames(:)),rmseVar(:),maeVar(:),maxaeVar(:), ...
    nrmseRangeVar(:),nrmseRMSVar(:),nrmseStdVar(:),nmaxaeRangeVar(:), ...
    mapeVar(:),smapeVar(:),validFraction(:),r2Var(:), ...
    'VariableNames',{'Variable','RMSE','MAE','MaxAE','NRMSE_Range', ...
    'NRMSE_RMS','NRMSE_Std','NMaxAE_Range','MAPE_percent', ...
    'sMAPE_percent','MAPE_valid_fraction','R2'});
end
