function cfg = config_receding_horizon_experiment_69bus()
%CONFIG_RECEDING_HORIZON_EXPERIMENT_69BUS Application-III prediction study.
%
% This experiment reuses the already trained OFFLINE Part-1 models.  It does
% not generate training data and does not train/refit any model.  A 60-s
% parent truth trajectory is evaluated through repeated 12-s open-loop
% predictions reinitialized from the measured/true state every 1 s.
%
% The base offline configuration is inherited deliberately so that saved
% model compatibility is checked against exactly the same method settings.

cfg = config_offline_experiment_69bus();

offlineOutputFolder = cfg.output.folderName;

%% Receding-horizon task
cfg.name = 'receding_horizon_prediction_69bus';
cfg.receding.parentDurationSeconds = 60.0;
cfg.receding.predictionHorizonSeconds = 12.0;
cfg.receding.anchorStepSeconds = 1.0;
cfg.receding.anchorTimesSeconds = ...
    0:cfg.receding.anchorStepSeconds: ...
    (cfg.receding.parentDurationSeconds-cfg.receding.predictionHorizonSeconds);

% Reuse the representative clean N=500 models from Offline Part 1.
cfg.receding.initialModelSeed = 20260814;
cfg.receding.initialModelSampleCount = 500;
cfg.receding.initialModelNoiseLevel = 0.0;

% Primary manuscript comparison set. PE-SINDy is retained here as the
% ideal strong-physics reference used in Offline Part 1; no method is retrained.
cfg.receding.methods = { ...
    'modular_koopman_kbf', ...
    'vanilla_sindy', ...
    'physics_embedded_sindy', ...
    'edsi', ...
    'neural_ode_modular', ...
    'llm_prior_sindy'};

% Resume/replay policy. Parent truth and every completed method/window result
% are cached independently, so an interrupted rollout campaign can resume.
cfg.receding.reuseParentTruth = true;
cfg.receding.reuseWindowCache = true;
cfg.receding.forceRecomputeWindows = false;

%% Saved-offline-model source used by the existing strict loader
cfg.online.offlineOutputFolder = offlineOutputFolder;
cfg.online.initialModelSeed = cfg.receding.initialModelSeed;

%% Parallel rollout execution
cfg.receding.parallel.enabled = true;
cfg.receding.parallel.numWorkers = 6;
cfg.receding.parallel.autoStartPool = true;
cfg.receding.parallel.poolProfile = 'local';

%% Figures / outputs
cfg.figures.visible = 'off';
cfg.figures.exportPDF = true;
cfg.figures.exportPNG = true;
cfg.output.folderName = 'receding_horizon_experiments_69bus';
cfg.output.recedingResultFileName = 'receding_horizon_results.mat';
cfg.output.parentTruthFileName = 'parent_truth_60s.mat';
cfg.output.windowCacheFolder = 'window_cache';
cfg.output.figureFolder = 'figures';
end
