function yGuess = mg_initial_guess(c,layout)
%MG_INITIAL_GUESS Construct a physically informed equilibrium starting point.

V = complex(ones(c.network.N,1));
V(c.network.slackBus) = c.network.Vslack;
x = zeros(layout.nx,1);

for k = 1:numel(c.sg)
    idx = layout.sg{k};
    if numel(idx) == 5 && isfield(c.sg(k),'model') && ...
            strcmpi(string(c.sg(k).model),'salient_avr_5state')
        Eq0 = getfield_default(c.sg(k),'EqPrimeGuess',1.02);
        arg = c.input.nominal.sgPm(k)*c.sg(k).XdPrime/max(abs(Eq0),eps);
        arg = max(min(arg,0.8),-0.8);
        x(idx(1)) = asin(arg);
        x(idx(2)) = 0;
        x(idx(3)) = Eq0;
        x(idx(4)) = getfield_default(c.sg(k),'EdPrimeGuess',0.0);
        x(idx(5)) = getfield_default(c.sg(k),'EfdGuess',1.0);
    else
        arg = c.input.nominal.sgPm(k)*c.sg(k).XdPrime/max(c.sg(k).Eprime,eps);
        arg = max(min(arg,0.8),-0.8);
        x(idx(1)) = asin(arg);
        x(idx(2)) = 0;
    end
end

for k = 1:numel(c.gfm)
    idx = layout.gfm{k};
    Xeq = max(imag(c.gfm(k).Zout),0);
    arg = c.input.nominal.gfmPstar(k)*Xeq/max(c.input.nominal.gfmEref(k),eps);
    arg = max(min(arg,0.8),-0.8);
    x(idx(1)) = asin(arg);
    x(idx(2)) = c.input.nominal.gfmPstar(k);
    x(idx(3)) = c.input.nominal.gfmQstar(k);
    x(idx(4)) = c.input.nominal.gfmEref(k);
end

for k = 1:numel(c.gfl)
    idx = layout.gfl{k};
    x(idx(1)) = 0;
    x(idx(2)) = 0;
    x(idx(3)) = c.input.nominal.gflPstar(k);
    x(idx(4)) = -c.input.nominal.gflQstar(k);
end

yGuess = mg_pack_dae_state(x,V,c,layout);
end

function v = getfield_default(s,name,defaultValue)
if isfield(s,name) && ~isempty(s.(name))
    v = s.(name);
else
    v = defaultValue;
end
end
