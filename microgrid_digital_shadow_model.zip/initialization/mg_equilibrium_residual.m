function R = mg_equilibrium_residual(y,c,layout)
%MG_EQUILIBRIUM_RESIDUAL Steady-state equations f=0 and g=0 at t0.

[x,V] = mg_unpack_dae_state(y,c,layout);
[f,g] = mg_system_equations(c.sim.t0,x,V,c,layout);
R = [f; real(g); imag(g)];
end
