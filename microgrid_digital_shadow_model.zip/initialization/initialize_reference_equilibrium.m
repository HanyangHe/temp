function [y0,yp0,info] = initialize_reference_equilibrium(c,layout)
%INITIALIZE_REFERENCE_EQUILIBRIUM Solve the nominal steady-state DAE point.
%
% The initialization solves f(x,V,u0)=0 and the non-slack network current
% balance g(x,V,u0)=0. Because the nominal point is an equilibrium, xdot0=0.
% Algebraic voltage derivatives do not enter the DAE residual and are set to 0.

if exist('fsolve','file') ~= 2
    error('initialize_reference_equilibrium:MissingFsolve', ...
        ['This initialization uses FSOLVE (Optimization Toolbox). ', ...
         'The user''s prior EMS code also uses FSOLVE.']);
end

yGuess = mg_initial_guess(c,layout);
opts = optimoptions('fsolve', ...
    'Display','off', ...
    'FunctionTolerance',c.init.FunctionTolerance, ...
    'StepTolerance',c.init.StepTolerance, ...
    'OptimalityTolerance',c.init.OptimalityTolerance, ...
    'MaxIterations',c.init.MaxIterations, ...
    'MaxFunctionEvaluations',c.init.MaxFunctionEvaluations);

[y0,fval,exitflag,output] = fsolve(@(y)mg_equilibrium_residual(y,c,layout),yGuess,opts);
yp0 = zeros(size(y0));
F0 = mg_dae_residual(c.sim.t0,y0,yp0,c,layout);
resInf = norm(F0,inf);

info.exitflag = exitflag;
info.output = output;
info.fsolveResidualInf = norm(fval,inf);
info.daeResidualInf = resInf;
info.yGuess = yGuess;

if exitflag <= 0 || resInf > c.init.acceptResidual
    error('initialize_reference_equilibrium:NoConvergence', ...
        'Equilibrium initialization failed: exitflag=%d, ||F||_inf=%.3e.', ...
        exitflag,resInf);
end
end
