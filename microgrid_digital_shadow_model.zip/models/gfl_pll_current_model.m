function [dx,Iinj,aux] = gfl_pll_current_model(x,Vbus,u,p,base)
%GFL_PLL_CURRENT_MODEL SRF-PLL plus reduced first-order current loop.
%
% x = [thetaPLL; xiPLL; id; iq]
% All currents are defined positive for injection INTO the network.

if numel(x) ~= 4
    error('gfl_pll_current_model:StateSize','GFL state must have 4 elements.');
end

theta = x(1);
xi = x(2);
id = x(3);
iq = x(4);

Vdq = Vbus*exp(-1i*theta);
vd = real(Vdq);
vq = imag(Vdq);
den = vd^2 + vq^2 + p.voltageRegularization;

idRef = (vd*u.Pstar + vq*u.Qstar)/den;
iqRef = (vq*u.Pstar - vd*u.Qstar)/den;
nuPLL = p.KpPLL*vq + p.KiPLL*xi;

dx = zeros(4,1);
dx(1) = base.w*nuPLL;
dx(2) = vq;
dx(3) = (idRef - id)/p.tauI;
dx(4) = (iqRef - iq)/p.tauI;

Iinj = (id + 1i*iq)*exp(1i*theta);
Se = Vbus*conj(Iinj);

aux.vd = vd;
aux.vq = vq;
aux.idRef = idRef;
aux.iqRef = iqRef;
aux.Pe = real(Se);
aux.Qe = imag(Se);
aux.nuPLL = nuPLL;
aux.fHz = base.f*(1 + nuPLL);
end
