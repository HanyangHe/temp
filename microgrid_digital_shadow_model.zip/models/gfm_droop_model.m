function [dx,Iinj,aux] = gfm_droop_model(x,Vbus,u,p,base)
%GFM_DROOP_MODEL Reduced GFM droop dynamics with voltage-source port.
%
% x = [delta; pFilt; qFilt; E]
% Internal source: E*exp(j*delta), behind p.Zout.

if numel(x) ~= 4
    error('gfm_droop_model:StateSize','GFM state must have 4 elements.');
end

delta = x(1);
pFilt = x(2);
qFilt = x(3);
Emag = x(4);

Eint = Emag*exp(1i*delta);
Iinj = (Eint - Vbus)/p.Zout;
Se = Vbus*conj(Iinj);
Pe = real(Se);
Qe = imag(Se);

nu = p.mp*(u.Pstar - pFilt);
Edroop = u.Eref + p.nq*(u.Qstar - qFilt);

dx = zeros(4,1);
dx(1) = base.w*nu;
dx(2) = (Pe - pFilt)/p.tauP;
dx(3) = (Qe - qFilt)/p.tauQ;
dx(4) = (Edroop - Emag)/p.tauE;

aux.Eint = Eint;
aux.Pe = Pe;
aux.Qe = Qe;
aux.nu = nu;
aux.fHz = base.f*(1 + nu);
end
