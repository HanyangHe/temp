function [dx,Iinj,aux] = sg_classical_model(x,Vbus,u,p,base)
%SG_CLASSICAL_MODEL Second-order synchronous-generator classical model.
%
% x = [delta; nu], where nu=(omega-omega_b)/omega_b.
% Positive Iinj is current injected from the SG into the network.

if numel(x) ~= 2
    error('sg_classical_model:StateSize','SG state must have 2 elements.');
end

delta = x(1);
nu = x(2);
Eint = p.Eprime*exp(1i*delta);
Iinj = (Eint - Vbus)/(1i*p.XdPrime);
Pe = real(Vbus*conj(Iinj));

dx = zeros(2,1);
dx(1) = base.w*nu;
dx(2) = (u.Pm - Pe - p.D*nu)/(2*p.H);

aux.Eint = Eint;
aux.Pe = Pe;
aux.Qe = imag(Vbus*conj(Iinj));
aux.fHz = base.f*(1 + nu);
end
