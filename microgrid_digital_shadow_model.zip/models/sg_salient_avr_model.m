function [dx,Iinj,aux] = sg_salient_avr_model(x,Vbus,u,p,base)
%SG_SALIENT_AVR_MODEL Five-state salient-pole SG with first-order AVR.
%
% State ordering
%   x = [delta; nu; EqPrime; EdPrime; Efd]
%   nu = (omega-omega_b)/omega_b.
%
% Inputs
%   u.Pm   : mechanical power input (pu)
%   u.Vref : AVR terminal-voltage reference (pu)
%
% Positive Iinj denotes current injected FROM the generator INTO the network.
% Rotor-frame convention used here:
%   Vq = Re{V*exp(-j*delta)}
%   Vd = -Im{V*exp(-j*delta)}
%   I  = (Iq - j*Id)*exp(j*delta)
% so terminal active power is Vq*Iq + Vd*Id.

if numel(x) ~= 5
    error('sg_salient_avr_model:StateSize', ...
        'Salient-pole SG+AVR state must have 5 elements.');
end

requiredP = {'H','D','Ra','Xd','Xq','XdPrime','XqPrime', ...
    'TdoPrime','TqoPrime','KA','TA'};
for k = 1:numel(requiredP)
    if ~isfield(p,requiredP{k})
        error('sg_salient_avr_model:MissingParameter', ...
            'SG parameter structure is missing field "%s".',requiredP{k});
    end
end
if ~isfield(u,'Pm') || ~isfield(u,'Vref')
    error('sg_salient_avr_model:MissingInput', ...
        'SG input structure must contain Pm and Vref.');
end

delta = x(1);
nu = x(2);
EqPrime = x(3);
EdPrime = x(4);
Efd = x(5);

VR = real(Vbus);
VI = imag(Vbus);
c = cos(delta);
s = sin(delta);
Vq = VR*c + VI*s;
Vd = VR*s - VI*c;

% Salient transient stator algebraic relation:
%   Eq' - Vq = Ra*Iq + Xd'*Id
%   Ed' - Vd = -Xq'*Iq + Ra*Id
% The closed form below avoids an inner nonlinear solve.
den = p.Ra^2 + p.XdPrime*p.XqPrime;
if abs(den) <= eps
    error('sg_salient_avr_model:SingularStatorMap', ...
        'Ra^2 + XdPrime*XqPrime is zero/near-zero.');
end
Iq = ( p.Ra*(EqPrime - Vq) - p.XdPrime*(EdPrime - Vd) )/den;
Id = ( p.XqPrime*(EqPrime - Vq) + p.Ra*(EdPrime - Vd) )/den;

Iinj = (Iq - 1i*Id)*exp(1i*delta);
Sterminal = Vbus*conj(Iinj);
Pt = real(Sterminal);
Qt = imag(Sterminal);

% Air-gap/electromagnetic power used in the swing equation. With Ra~=0,
% Pt = Pairgap - Ra*(Iq^2+Id^2).
Pairgap = EqPrime*Iq + EdPrime*Id + ...
    (p.XqPrime-p.XdPrime)*Id*Iq;
Vt = abs(Vbus);

dx = zeros(5,1);
dx(1) = base.w*nu;
dx(2) = (u.Pm - Pairgap - p.D*nu)/(2*p.H);
dx(3) = (Efd - EqPrime - (p.Xd-p.XdPrime)*Id)/p.TdoPrime;
dx(4) = (-EdPrime + (p.Xq-p.XqPrime)*Iq)/p.TqoPrime;
dx(5) = (-Efd + p.KA*(u.Vref - Vt))/p.TA;

aux.Vq = Vq;
aux.Vd = Vd;
aux.Iq = Iq;
aux.Id = Id;
aux.Vt = Vt;
aux.Pairgap = Pairgap;
aux.Pe = Pt;     % keep project convention: reported P is terminal injection
aux.Qe = Qt;
aux.copperLoss = p.Ra*(Iq^2+Id^2);
aux.fHz = base.f*(1 + nu);
aux.EqPrime = EqPrime;
aux.EdPrime = EdPrime;
aux.Efd = Efd;
end
