function cfg = config_online_experiment_69bus_mlx()
%CONFIG_ONLINE_EXPERIMENT_69BUS_MLX Official 69-bus config for Live Script use.
% Same numerical protocol as config_online_experiment_69bus, but suppresses
% external figure windows and exports PNGs so the Live Script can display them.
cfg=config_online_experiment_69bus();
cfg.figures.visible='off';
cfg.figures.exportPDF=true;
cfg.figures.exportPNG=true;
cfg.figures.closeAfterExport=true;
end
