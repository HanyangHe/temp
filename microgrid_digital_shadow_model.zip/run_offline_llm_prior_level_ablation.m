function report = run_offline_llm_prior_level_ablation(projectRoot, cfg)
% Thin wrapper patch:
% Keep the existing official experiment outputs, then regenerate the paper
% figure using the new 1x3 layout.
%
% IMPORTANT: this patch is intentionally conservative. It assumes the core
% official ablation experiment logic already exists in the user's codebase.
% After the experiment body finishes and writes the per-run CSV, call the
% rebuild helper to generate the new figure style.
%
% If your repository already has a fuller implementation of this function,
% merge the final block below instead of fully overwriting.

error(['This patch file is a merge template, not a standalone full runner. ', ...
       'Please merge the final figure-regeneration block into your existing ', ...
       'run_offline_llm_prior_level_ablation.m, or keep your current runner ', ...
       'and use tools/rebuild_official_llm_prior_level_ablation_figure.m ', ...
       'to regenerate the figure without rerunning experiments.']);

% ---- MERGE THIS BLOCK AT THE END OF YOUR EXISTING RUNNER ----
% testCase = cfg.testCase;  % or the variable you already use
% try
%     rebuild_official_llm_prior_level_ablation_figure(projectRoot, testCase);
% catch MEfig
%     warning('Failed to rebuild paper figure: %s', MEfig.message);
% end
% -------------------------------------------------------------

% Dummy output for completeness.
report = struct();
end
