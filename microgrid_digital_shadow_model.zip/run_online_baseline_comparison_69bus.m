function report = run_online_baseline_comparison_69bus(projectRoot, replaySavedOnly)
%RUN_ONLINE_BASELINE_COMPARISON_69BUS External online baseline comparison.
%
% Every method is evaluated under the SAME controlled online architecture:
%   A = model adaptation at the known hidden-parameter jump times
%   S = measured-state synchronization at model activation
% Therefore every row below is the full A+S deployment. The compared learned
% models are intentionally limited to the representative non-oracle baselines:
%   M-KBF, V-SINDy, LLM-Prior SINDy.
%
% PE-SINDy is excluded here because it is retained only as an ideal strong-
% physics offline reference. Each method uses its native parameter-update rule:
%   M-KBF      : causal retraining of learned Koopman generator coefficients
%   V-SINDy    : localized fixed-support coefficient RLS
%   LLM-Prior  : localized fixed-support coefficient RLS, no online LLM call
% Automatic mismatch triggering is disabled ONLY for this external comparison.
% The two hidden coefficient jumps at t = 0 and 6 s define a common oracle
% update schedule for every method.  Each method collects its causal post-jump
% sample pool, executes its real numerical update, and activates the result
% after the measured wall-clock fit delay.  This controls update count/timing
% so the comparison focuses on model-update capability rather than detector
% sensitivity.
% All model-update wall-clock times are measured and enter deployment delay.

if nargin<1 || isempty(projectRoot), projectRoot=fileparts(mfilename('fullpath')); end
if nargin<2 || isempty(replaySavedOnly), replaySavedOnly=false; end
addpath(genpath(projectRoot));

outRoot=fullfile(projectRoot,'outputs','online_model_experiments_69bus');
if ~exist(outRoot,'dir'), mkdir(outRoot); end
csvFile=fullfile(outRoot,'online_baseline_comparison.csv');
matFile=fullfile(outRoot,'online_baseline_comparison_results.mat');

if replaySavedOnly && exist(csvFile,'file')==2
    T=readtable(csvFile,'TextType','string');
    fprintf('\n============================================================\n');
    fprintf('69-BUS ONLINE BASELINE COMPARISON -- SAVED TABLE REPLAY\n');
    fprintf('No truth solve, detector recomputation, retraining, or rollout is performed.\n');
    fprintf('============================================================\n');
    disp(T);
    report=struct('table',T,'outputRoot',outRoot,'replayed',true, ...
        'csvFile',csvFile,'matFile',matFile);
    return;
end

methods=["modular_koopman_kbf","vanilla_sindy","llm_prior_sindy"];
displayNames=["M-KBF","V-SINDy","LLM-Prior"];
rows=cell(numel(methods),1);
subreports=cell(numel(methods),1);

fprintf('\n============================================================\n');
fprintf('69-BUS ONLINE EXTERNAL BASELINE COMPARISON\n');
fprintf('Mode                : scheduled A+S for every method\n');
fprintf('Methods             : M-KBF | V-SINDy | LLM-Prior\n');
fprintf('PE-SINDy            : excluded (offline ideal-physics reference only)\n');
fprintf('Offline initial data: N=500 | clean labels\n');
fprintf('Online xdot noise   : 0.1%%\n');
fprintf('Hidden mismatch     : GFM1 nq +0.10 at 0 s, then -0.10 at 6 s\n');
fprintf('Update schedule     : automatic detector OFF | forced at [0 6] s\n');
fprintf('============================================================\n');

for i=1:numel(methods)
    methodName=methods(i);
    fprintf('\n############################################################\n');
    fprintf('ONLINE BASELINE %d/%d -- %s (A+S)\n',i,numel(methods),displayNames(i));
    fprintf('############################################################\n');
    safeName=char(strrep(methodName,'_','-'));
    methodFolder=fullfile('online_model_experiments_69bus','baseline_comparison',safeName);
    cfgFcn=@() baseline_config_local(methodName,methodFolder);
    try
        R=run_online_model_experiments( ...
            projectRoot,@case_grid_connected_69bus_true_physics,cfgFcn);
        subreports{i}=R;
        rows{i}=summary_row_local(R,displayNames(i));
    catch ME
        warning('run_online_baseline_comparison_69bus:MethodFailed', ...
            '%s baseline failed: %s',displayNames(i),ME.message);
        rows{i}=failed_row_local(displayNames(i),ME.message);
    end
end

T=vertcat(rows{:});
writetable(T,csvFile);
report=struct();
report.schemaVersion='online_baseline_comparison_69bus_scheduled_as_v2';
report.table=T;
report.methods=methods;
report.displayNames=displayNames;
report.subreports=subreports;
report.outputRoot=outRoot;
report.csvFile=csvFile;
report.replayed=false;
save(matFile,'report','-v7.3');

fprintf('\n================ ONLINE BASELINE COMPARISON TABLE ================\n');
disp(T);
fprintf('Saved CSV: %s\n',csvFile);
end

function cfg=baseline_config_local(methodName,methodFolder)
cfg=config_online_experiment_69bus();

% One A+S deployment per method; the internal F/F+S/A/A+S ablation is not
% repeated here.
cfg.online.ablation.enabled=false;
cfg.online.update.stateSynchronizationAtActivation=true;

% Controlled A+S comparison: bypass automatic mismatch-trigger timing and
% force exactly one adaptation attempt after each true coefficient jump.
% The update helper receives an observation stream trimmed to the jump time,
% so its minimum causal sample pool is collected strictly AFTER that jump.
cfg.online.update.triggerMode='scheduled_parameter_changes';
cfg.online.update.scheduledTriggerTimes=[0.0 6.0];
cfg.online.update.scheduledDeviceType='gfm';
cfg.online.update.scheduledDeviceIndex=1;
cfg.online.update.maximumUpdateAttempts=2;
cfg.online.update.maximumAcceptedUpdates=2;

% To control the update COUNT as requested, every successfully trained
% candidate is activated after its real fit delay; no method-specific
% validation rejection is allowed to remove one of the two scheduled updates.
cfg.online.update.validation.enabled=false;

% Detector calibration is irrelevant in scheduled mode and is disabled to
% avoid method-dependent threshold work in this controlled comparison.
cfg.online.update.detector.calibrateFromOffline=false;
cfg.online.update.detector.trajectoryCalibrationEnabled=false;
if isfield(cfg.online.update.detector,'fixedModuleThresholds')
    cfg.online.update.detector=rmfield(cfg.online.update.detector,'fixedModuleThresholds');
end

% Disable every online method, then activate exactly one.
fields=fieldnames(cfg.online.methods);
for k=1:numel(fields)
    f=fields{k};
    if isstruct(cfg.online.methods.(f))
        if isfield(cfg.online.methods.(f),'frozen'), cfg.online.methods.(f).frozen=false; end
        if isfield(cfg.online.methods.(f),'online'), cfg.online.methods.(f).online=false; end
    end
end

switch lower(string(methodName))
    case "modular_koopman_kbf"
        cfg.online.methods.modularKoopman.frozen=false;
        cfg.online.methods.modularKoopman.online=true;
        cfg.online.update.strategy='method_specific_fast_update';
    case "vanilla_sindy"
        cfg.online.methods.vanillaSINDy.frozen=false;
        cfg.online.methods.vanillaSINDy.online=true;
        cfg.online.update.strategy='module_local_fixed_support_rls';
    case "llm_prior_sindy"
        if ~isfield(cfg.online.methods,'llmPriorSINDy')
            cfg.online.methods.llmPriorSINDy=struct('frozen',false,'online',true);
        else
            cfg.online.methods.llmPriorSINDy.frozen=false;
            cfg.online.methods.llmPriorSINDy.online=true;
        end
        cfg.online.update.strategy='module_local_fixed_support_rls';
    otherwise
        error('Unknown baseline method: %s',methodName);
end

% All methods share exactly the same clean initial-data and online-observation
% protocol, detector calibration, mismatch schedule, validation and state sync.
cfg.online.initialModelSampleCount=500;
cfg.online.initialModelNoiseLevel=0.0;
cfg.online.initialModelSeed=20260814;
cfg.online.observationNoiseLevel=0.001;
cfg.online.observationNoiseSeed=20260815;
cfg.online.update.trainingDelayScale=1.0;
cfg.online.update.minimumTrainingDelaySeconds=0.0;

% Baseline comparison is table-only: suppress figure windows and heavy PDF
% generation. Per-method numeric artifacts are still saved for audit/replay.
cfg.output.folderName=methodFolder;
cfg.figures.visible='off';
cfg.figures.exportPDF=false;
cfg.figures.exportPNG=false;
cfg.figures.closeAfterExport=true;
end

function row=summary_row_local(R,displayName)
ev=find_online_eval_local(R.evaluations);
if isempty(ev)
    row=failed_row_local(displayName,'No online A+S evaluation found.');
    return;
end
whole=get_nested_local(ev,{'metrics','RMSE'},NaN);
track=get_nested_local(ev,{'trackingMetrics','RMSE'},NaN);
vtrack=get_nested_local(ev,{'trackingMetrics','KeyVoltageRMSE'},NaN);
scheduledTimes="[0 6]";
accepted=get_nested_local(ev,{'update','acceptedUpdateCount'},0);
fitTime=get_nested_local(ev,{'update','trainingTimeSecondsTotal'},NaN);
if ~isfinite(fitTime)
    fitTime=get_nested_local(ev,{'update','trainingTimeSeconds'},NaN);
end
activationTimes="";
act=[];
if isfield(ev,'update') && isstruct(ev.update) && ...
        isfield(ev.update,'activationTimes') && ~isempty(ev.update.activationTimes)
    act=ev.update.activationTimes;
end
if isnumeric(act) && ~isempty(act)
    activationTimes=string(mat2str(double(act(:).'),6));
end
row=table(string(displayName),"A+S",whole,track,vtrack,scheduledTimes, ...
    activationTimes,double(accepted),fitTime, ...
    'VariableNames',{'Method','Mode','WholeRMSE','TrackingRMSE','V35_RMSE', ...
    'ScheduledUpdateTimes_s','ActivationTimes_s','AcceptedUpdates','CoefficientFitTime_s'});
end

function row=failed_row_local(displayName,msg)
warning('run_online_baseline_comparison_69bus:FailedRow','%s: %s',displayName,msg);
row=table(string(displayName),"A+S",NaN,NaN,NaN,"[0 6]","",0,NaN, ...
    'VariableNames',{'Method','Mode','WholeRMSE','TrackingRMSE','V35_RMSE', ...
    'ScheduledUpdateTimes_s','ActivationTimes_s','AcceptedUpdates','CoefficientFitTime_s'});
end

function ev=find_online_eval_local(evaluations)
ev=[];
if ~iscell(evaluations), evaluations=num2cell(evaluations); end
for k=1:numel(evaluations)
    e=evaluations{k};
    if isstruct(e) && isfield(e,'mode') && any(strcmpi(string(e.mode),["online","adapted_sync"]))
        ev=e; return;
    end
end
end

function v=get_nested_local(S,path,defaultValue)
v=defaultValue;
cur=S;
for k=1:numel(path)
    if ~isstruct(cur) || ~isfield(cur,path{k}) || isempty(cur.(path{k}))
        return;
    end
    cur=cur.(path{k});
end
if isnumeric(cur) || islogical(cur)
    if isscalar(cur), v=cur; end
else
    v=cur;
end
end
