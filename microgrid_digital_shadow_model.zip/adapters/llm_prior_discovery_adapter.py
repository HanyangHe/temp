#!/usr/bin/env python3
"""Weak-domain LLM physics-prior discovery adapter.

This diagnostic adapter deliberately does NOT show the LLM a task-specific
hand-built feature block, an EDSI parent dictionary, exact governing ODEs, or
fitted coefficients. It supplies only device semantics, averaged-model context,
and the local d/q coordinate convention, then asks the model to compile a
compact coefficient-free basis bank that MATLAB will fit and validate.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from openai import OpenAI

VERSION = "weak_domain_prior_compiler_v8_complexity_safe_canonical_closure_20261005"


def read_json(p: Path) -> dict[str, Any]:
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_json(p: Path, obj: dict[str, Any]) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    t = p.with_suffix(p.suffix + ".tmp")
    with t.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
    t.replace(p)


def nattr(obj: Any, name: str, default: int = 0) -> int:
    try:
        return int(getattr(obj, name, default) or 0)
    except Exception:
        return default


def usage_dict(resp: Any) -> dict[str, int]:
    u = getattr(resp, "usage", None)
    inp = nattr(u, "input_tokens")
    out = nattr(u, "output_tokens")
    details = getattr(u, "input_tokens_details", None) if u else None
    return {
        "input_tokens": inp,
        "output_tokens": out,
        "total_tokens": nattr(u, "total_tokens", inp + out),
        "cached_input_tokens": nattr(details, "cached_tokens"),
        "cache_write_tokens": nattr(details, "cache_write_tokens"),
    }


def estimate_cost(u: dict[str, int], p: dict[str, Any]) -> float:
    inp = int(u.get("input_tokens", 0))
    cached = int(u.get("cached_input_tokens", 0))
    written = int(u.get("cache_write_tokens", 0))
    uncached = max(inp - cached - written, 0)
    out = int(u.get("output_tokens", 0))
    return (
        uncached * float(p.get("input", 0.10))
        + cached * float(p.get("cached_input", 0.01))
        + written * float(p.get("cache_write", 0.0))
        + out * float(p.get("output", 0.50))
    ) / 1_000_000.0


@dataclass(frozen=True)
class Expr:
    op: str
    args: tuple["Expr", ...] = ()
    var: int | None = None

    def depth(self) -> int:
        if self.op in {"const", "var"}:
            return 0
        return 1 + max(a.depth() for a in self.args)

    def complexity(self) -> int:
        if self.op in {"const", "var"}:
            return 0
        if self.op in {"sin", "cos", "square", "sqrt_pos", "sub", "div"}:
            return sum(a.complexity() for a in self.args) + 1
        return sum(a.complexity() for a in self.args) + len(self.args) - 1

    def canonical(self) -> str:
        if self.op == "const":
            return "1"
        if self.op == "var":
            return f"x{self.var}"
        if self.op in {"sin", "cos", "sqrt_pos"}:
            return f"{self.op}({self.args[0].canonical()})"
        if self.op == "square":
            # Keep square(a) as the compact canonical representation. A later
            # prod(a,a) normalization maps to this same form. This is not only
            # algebraically canonical; it also keeps the Python complexity
            # contract identical to MATLAB's DSL compiler after rewriting.
            a = self.args[0].canonical()
            return f"square({a})"
        if self.op == "prod":
            factors: list[Expr] = []
            def collect_factor(a: Expr) -> None:
                if a.op == "prod":
                    for q in a.args:
                        collect_factor(q)
                elif a.op == "square":
                    collect_factor(a.args[0])
                    collect_factor(a.args[0])
                elif a.op == "const":
                    # Multiplicative identity is removed.
                    return
                else:
                    factors.append(a)
            for a in self.args:
                collect_factor(a)
            vals = sorted(a.canonical() for a in factors)
            if not vals:
                return "1"
            if len(vals) == 1:
                return vals[0]
            # Canonical algebraic normalization: prod(a,a) == square(a).
            # Prefer the compact square form so an equivalent rewrite cannot
            # inflate expression complexity after validation.
            if len(vals) == 2 and vals[0] == vals[1]:
                return f"square({vals[0]})"
            return f"prod({','.join(vals)})"
        if self.op == "add":
            flat: list[Expr] = []
            for a in self.args:
                if a.op == "add":
                    flat.extend(a.args)
                else:
                    flat.append(a)
            vals = sorted(a.canonical() for a in flat)
            return f"add({','.join(vals)})"
        if self.op in {"sub", "div"}:
            return f"{self.op}({self.args[0].canonical()},{self.args[1].canonical()})"
        raise ValueError(self.op)


def split_args(body: str) -> list[str]:
    depth = 0
    start = 0
    out: list[str] = []
    for i, ch in enumerate(body):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth < 0:
                raise ValueError("unbalanced parentheses")
        elif ch == "," and depth == 0:
            out.append(body[start:i])
            start = i + 1
    if depth != 0:
        raise ValueError("unbalanced parentheses")
    out.append(body[start:])
    if any(not x for x in out):
        raise ValueError("empty argument")
    return out


def parse_expr(s: str, n_vars: int) -> Expr:
    s = re.sub(r"\s+", "", str(s))
    if s == "1":
        return Expr("const")
    m = re.fullmatch(r"x(\d+)", s)
    if m:
        idx = int(m.group(1))
        if idx < 1 or idx > n_vars:
            raise ValueError(f"invalid variable x{idx}")
        return Expr("var", var=idx)

    p = s.find("(")
    if p <= 0 or not s.endswith(")"):
        raise ValueError(f"invalid expression syntax: {s}")
    op = s[:p].lower()
    args = split_args(s[p + 1 : -1])

    if op in {"sin", "cos", "square", "sqrt_pos"}:
        if len(args) != 1:
            raise ValueError(f"{op} expects 1 arg")
        return Expr(op, (parse_expr(args[0], n_vars),))
    if op in {"prod", "add"}:
        if len(args) < 2:
            raise ValueError(f"{op} expects >=2 args")
        return Expr(op, tuple(parse_expr(a, n_vars) for a in args))
    if op in {"sub", "div"}:
        if len(args) != 2:
            raise ValueError(f"{op} expects 2 args")
        return Expr(op, tuple(parse_expr(a, n_vars) for a in args))
    raise ValueError(f"unsupported operator: {op}")


def canonical_if_valid(raw: str, n_vars: int, max_depth: int, max_complexity: int) -> str | None:
    try:
        e = parse_expr(raw, n_vars)
        canonical = e.canonical()
        # CRITICAL: validate the representation that is actually exported to
        # MATLAB, not only the pre-canonical LLM spelling. Canonical rewrites
        # must never increase depth/complexity beyond the shared DSL contract.
        e2 = parse_expr(canonical, n_vars)
    except Exception:
        return None
    if e2.depth() > max_depth or e2.complexity() > max_complexity:
        return None
    return e2.canonical()


def extract_coordinate_terms(sem: dict[str, Any], n_vars: int, max_depth: int, max_complexity: int) -> list[str]:
    out: list[str] = []
    raw_items = sem.get("coordinate_knowledge", {}).get("privileged_latents", [])
    for raw in raw_items:
        txt = str(raw)
        expr = txt.split("=", 1)[1].strip() if "=" in txt else txt.strip()
        c = canonical_if_valid(expr, n_vars, max_depth, max_complexity)
        if c and c not in out:
            out.append(c)
    return out


def cache_key(req: dict[str, Any]) -> str:
    q = dict(req)
    q.pop("cache_dir", None)
    q.pop("pricing_usd_per_million", None)
    q["adapter_version"] = VERSION
    raw = json.dumps(q, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def schema(n_outputs: int, max_basis_terms: int, max_latents: int) -> dict[str, Any]:
    latent = {
        "type": "object",
        "properties": {
            "name": {"type": "string", "maxLength": 80},
            "expression": {"type": "string", "maxLength": 320},
            "role": {"type": "string", "maxLength": 220},
            "confidence": {"type": "number", "minimum": 0, "maximum": 1},
        },
        "required": ["name", "expression", "role", "confidence"],
        "additionalProperties": False,
    }
    basis = {
        "type": "object",
        "properties": {
            "expression": {"type": "string", "maxLength": 340},
            "reason": {"type": "string", "maxLength": 220},
            "confidence": {"type": "number", "minimum": 0, "maximum": 1},
            "target_derivatives": {
                "type": "array",
                "items": {"type": "integer", "minimum": 1, "maximum": n_outputs},
                "minItems": 1,
                "maxItems": n_outputs,
            },
        },
        "required": ["expression", "reason", "confidence", "target_derivatives"],
        "additionalProperties": False,
    }
    closure = {
        "type": "object",
        "properties": {
            "latent_expressions": {
                "type": "array", "items": {"type": "string", "maxLength": 320},
                "minItems": 1, "maxItems": 2,
            },
            "partner_aliases": {
                "type": "array", "items": {"type": "string", "pattern": r"^x[1-9][0-9]*$"},
                "minItems": 0, "maxItems": 4,
            },
            "reason": {"type": "string", "maxLength": 220},
            "confidence": {"type": "number", "minimum": 0, "maximum": 1},
            "target_derivatives": {
                "type": "array",
                "items": {"type": "integer", "minimum": 1, "maximum": n_outputs},
                "minItems": 1,
                "maxItems": n_outputs,
            },
        },
        "required": ["latent_expressions", "partner_aliases", "reason", "confidence", "target_derivatives"],
        "additionalProperties": False,
    }
    return {
        "type": "object",
        "properties": {
            "latent_features": {
                "type": "array", "items": latent,
                "minItems": 0, "maxItems": max_latents,
            },
            "prior_ode": {
                "type": "array", "items": {"type": "string", "maxLength": 360},
                "minItems": n_outputs, "maxItems": n_outputs,
            },
            "compiled_basis": {
                "type": "array", "items": basis,
                "minItems": 1, "maxItems": max_basis_terms,
            },
            "interaction_closures": {
                "type": "array", "items": closure,
                "minItems": 0, "maxItems": 6,
            },
            "diagnosis": {"type": "string", "maxLength": 600},
            "confidence": {"type": "number", "minimum": 0, "maximum": 1},
        },
        "required": ["latent_features", "prior_ode", "compiled_basis", "interaction_closures", "diagnosis", "confidence"],
        "additionalProperties": False,
    }


SYSTEM_PROMPT = r"""
You are a physics-prior compiler for sparse dynamical-system identification.

Your task is NOT to edit an existing dictionary and NOT to fit coefficients.
Starting from weak domain knowledge only, reconstruct a compact but sufficiently
complete set of coefficient-free symbolic basis functions that would allow an
outer sparse linear regression to express the canonical averaged dynamics of
the stated device class.  Do not over-compress the physics bank: a complete
small physical span is more valuable than an artificially minimal list.

The user supplies only:
- device type and physical meanings of x1,x2,...;
- target derivative meanings;
- positive-sequence fundamental-frequency averaged-model context;
- the project's local d/q coordinate convention.
No task-specific hand-written feature bank or exact governing ODE is supplied.

Use general power-system / power-electronics knowledge to infer the missing
high-value interactions. Think first in reusable physical motifs and latent
quantities, then compile those motifs into basis functions. Unknown physical
parameters must remain OUTER regression coefficients. Do not invent numerical
constants and do not pad the answer with generic polynomial clutter.

Use the supplied d/q coordinates aggressively. In particular:
- SG: after forming the local d/q terminal-voltage coordinates, reason about
  the low-order bilinear interactions between those coordinates and the
  transient internal electromagnetic states, the useful low-order d/q voltage
  products, and the terminal-voltage magnitude/error naturally entering a
  first-order AVR. Infer the canonical motifs rather than copying a memorized
  feature list.
- GFM: reconstruct the power-transfer motifs of an averaged controllable
  voltage source behind impedance. Use internal source-voltage magnitude with
  local d/q terminal voltage to form the bilinear interactions needed by active
  and reactive power dynamics, then add compact droop/reference-error motifs.
- GFL: derive the standard P/Q-to-dq-current relationship, including the
  voltage normalization and cross-couplings required by that relationship.

Return enough high-confidence basis terms to span the canonical model when
justified (typically several terms beyond the supplied d/q coordinates). Prefer
physically canonical motifs over algebraically correlated surrogates. Assign a
confidence to each proposed latent/basis term. High confidence should mean the
term follows directly from the stated averaged device physics, not merely that
it is plausible. For identical semantic input, prefer the same canonical,
complete, nonredundant symbolic representation rather than alternative but
physically equivalent enumerations.

Also return compact interaction_closures when a physical motif is naturally a
small interaction family rather than one isolated term. For each family, report
only the one or two canonical latent expressions and the small set of raw state
aliases that physically participate. Do NOT decide which algebraic members of
that family are emitted. A deterministic generic compiler will always apply the
same low-order closure rule: all latent-state bilinear products, the product of
two latents when two are present, and the square of each latent. This separates
semantic physical inference from reproducible symbolic enumeration. Closure
terms are only candidate basis functions; final coefficient/support selection
remains entirely data-driven.

Machine-expression DSL:
  1, xN,
  prod(a,b,...), add(a,b,...), sub(a,b), div(a,b),
  sin(a), cos(a), square(a), sqrt_pos(a)

Inline latent quantities inside compiled_basis; the machine DSL has no named
intermediate variables. Do not include raw anchors 1,x1,...,xn in
compiled_basis. Keep equations and diagnosis concise, but do not omit a key
physical interaction merely to save tokens. No chain-of-thought.
""".strip()


def compact_semantics(sem: dict[str, Any]) -> dict[str, Any]:
    return {
        "device_type": sem["device_type"],
        "model_family": sem.get("model_family", ""),
        "system_description": sem.get("system_description", ""),
        "variables": [
            f"{v['alias']}={v['symbol']}|{v['meaning']}|{v['role']}|{v['unit']}"
            for v in sem["variable_glossary"]
        ],
        "derivatives": [
            f"{d['alias']}={d['physical_symbol']}|{d['meaning']}"
            for d in sem["target_derivatives"]
        ],
        "coordinate_knowledge": sem.get("coordinate_knowledge", {}),
        "prior_strength": sem.get("prior_strength_statement", ""),
    }


def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: llm_prior_discovery_adapter.py request.json response.json", file=sys.stderr)
        return 64

    req_path = Path(sys.argv[1]).resolve()
    resp_path = Path(sys.argv[2]).resolve()
    t0 = time.perf_counter()
    try:
        req = read_json(req_path)
        if not os.environ.get("OPENAI_API_KEY"):
            raise RuntimeError("OPENAI_API_KEY is not visible to Python.")

        sem = dict(req["semantic_system"])
        n_vars = len(sem["variable_glossary"])
        n_outputs = len(sem["target_derivatives"])
        max_depth = int(req.get("max_expression_depth", 8))
        max_complexity = int(req.get("max_expression_complexity", 32))
        max_basis_terms = int(req.get("max_basis_terms", 18))
        max_latents = int(req.get("max_latent_features", 8))

        cache_dir = Path(req["cache_dir"]).resolve()
        cache_dir.mkdir(parents=True, exist_ok=True)
        cfile = cache_dir / f"{cache_key(req)}.json"
        cache_mode = str(req.get("cache_mode", "record_or_replay")).lower()
        if cache_mode in {"replay", "record_or_replay"} and cfile.exists():
            result = read_json(cfile)
            result["cache_hit"] = True
            result["cloud_call_count"] = 0
            result["estimated_cost_usd"] = 0.0
            result["latency_seconds"] = time.perf_counter() - t0
            write_json(resp_path, result)
            print(f"LLM_PRIOR_DISCOVERY_CACHE_HIT device={sem['device_type']} seed={req.get('discovery_seed')}")
            return 0
        if cache_mode == "replay":
            raise RuntimeError(f"Replay requested but cache missing: {cfile}")

        payload = {
            "goal": (
                "Recover a compact and sufficiently complete physical basis span from weak device semantics only; "
                "prefer complete canonical motifs over an over-compressed surrogate bank."
            ),
            "representation_policy": (
                "Return the most canonical, complete, and nonredundant representation supported by the semantics. "
                "Do not deliberately vary notation or choose alternative equivalent forms across repeated calls."
            ),
            "system": compact_semantics(sem),
            "dsl": {
                "operators": ["prod", "add", "sub", "div", "sin", "cos", "square", "sqrt_pos"],
                "max_depth": max_depth,
                "max_complexity": max_complexity,
                "max_basis_terms": max_basis_terms,
            },
            "verification": (
                "MATLAB compiles every expression, fits coefficients with the shared STLSQ backend, "
                "records confidence only as prior metadata, canonicalizes symbolic expressions, and applies "
                "one deterministic generic low-order closure rule to every declared interaction family. "
                "Final support/coefficients and post-discovery "
                "performance are determined independently from data and are not imitation targets."
            ),
        }

        client = OpenAI()
        model = str(req.get("model", "gpt-6-luna"))
        effort = str(req.get("reasoning_effort", "medium"))
        start = time.perf_counter()
        resp = client.responses.create(
            model=model,
            reasoning={"effort": effort},
            input=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": json.dumps(payload, separators=(",", ":"), ensure_ascii=False)},
            ],
            text={
                "format": {
                    "type": "json_schema",
                    "name": "weak_domain_prior_compiler",
                    "strict": True,
                    "schema": schema(n_outputs, max_basis_terms, max_latents),
                }
            },
            max_output_tokens=int(req.get("max_output_tokens", 7000)),
            store=bool(req.get("store", False)),
        )
        latency = time.perf_counter() - start
        if getattr(resp, "status", None) == "incomplete":
            raise RuntimeError(f"GPT prior-discovery response incomplete: {getattr(resp, 'incomplete_details', None)!r}")
        if not resp.output_text:
            raise RuntimeError("GPT prior-discovery response contained no output_text.")

        parsed = json.loads(resp.output_text)
        supplied_coords = extract_coordinate_terms(sem, n_vars, max_depth, max_complexity)

        canonical_terms: list[str] = []
        rejected: list[str] = []
        item_by_expr: dict[str, dict[str, Any]] = {}
        anchors = {"1", *[f"x{i}" for i in range(1, n_vars + 1)]}

        # Supplied coordinate terms are weak metadata, not LLM discoveries.
        # They are nevertheless high-confidence physical latents and may later
        # be mutation-locked by MATLAB after fixed-width compression.
        for c in supplied_coords:
            item_by_expr[c] = {
                "expression": c,
                "source": "supplied_coordinate",
                "reason": "project d/q coordinate convention",
                "confidence": 1.0,
                "target_derivatives": list(range(1, n_outputs + 1)),
            }

        def register_item(raw: str, source: str, reason: str, confidence: float, targets: list[int]) -> None:
            c = canonical_if_valid(raw, n_vars, max_depth, max_complexity)
            if c is None:
                rejected.append(raw)
                return
            if c in anchors or c in supplied_coords:
                return
            conf = min(max(float(confidence), 0.0), 1.0)
            item = {
                "expression": c,
                "source": source,
                "reason": reason,
                "confidence": conf,
                "target_derivatives": targets,
            }
            old = item_by_expr.get(c)
            if old is None:
                canonical_terms.append(c)
                item_by_expr[c] = item
            elif conf > float(old.get("confidence", 0.0)):
                item_by_expr[c] = item

        for item in parsed.get("latent_features", []):
            register_item(
                str(item.get("expression", "")),
                "llm_latent",
                str(item.get("role", "")),
                float(item.get("confidence", parsed.get("confidence", 0.0))),
                list(range(1, n_outputs + 1)),
            )

        for item in parsed.get("compiled_basis", []):
            register_item(
                str(item.get("expression", "")),
                "llm_compiled",
                str(item.get("reason", "")),
                float(item.get("confidence", parsed.get("confidence", 0.0))),
                [int(x) for x in item.get("target_derivatives", [])],
            )

        # Snapshot the terms directly proposed by the LLM before the generic
        # closure compiler expands interaction families. This is diagnostic
        # metadata only; it does not alter the formal full prior bank.
        direct_terms = list(canonical_terms)
        direct_item_by_expr = {
            key: dict(value) for key, value in item_by_expr.items()
        }

        # Deterministic generic motif-closure compiler. The LLM identifies only
        # the semantic interaction family (canonical latents + participating raw
        # states). The adapter, not the LLM, enumerates the same complete
        # low-order family every time:
        #   1) every latent x partner bilinear product;
        #   2) latent1 x latent2 when two latents are present;
        #   3) the square of every latent.
        # Group ordering, duplicates, and expression ordering are canonicalized
        # before expansion so equivalent LLM descriptions compile identically.
        closure_generated: list[str] = []
        canonical_closures: list[dict[str, Any]] = []
        seen_group_keys: set[str] = set()
        for group in parsed.get("interaction_closures", []):
            raw_latents = [str(x) for x in group.get("latent_expressions", [])]
            latents = sorted({
                c for raw in raw_latents
                if (c := canonical_if_valid(raw, n_vars, max_depth, max_complexity)) is not None
            })
            partners = sorted({
                str(alias) for alias in group.get("partner_aliases", [])
                if re.fullmatch(r"x[1-9][0-9]*", str(alias))
                and 1 <= int(str(alias)[1:]) <= n_vars
            }, key=lambda x: int(x[1:]))
            targets = sorted({
                int(x) for x in group.get("target_derivatives", [])
                if 1 <= int(x) <= n_outputs
            })
            if not latents:
                continue
            key = json.dumps(
                {"latents": latents, "partners": partners, "targets": targets},
                sort_keys=True, separators=(",", ":")
            )
            if key in seen_group_keys:
                continue
            seen_group_keys.add(key)
            conf = min(max(float(group.get("confidence", parsed.get("confidence", 0.0))), 0.0), 1.0)
            reason = str(group.get("reason", "generic physical interaction family"))
            canonical_closures.append({
                "latent_expressions": latents,
                "partner_aliases": partners,
                "reason": reason,
                "confidence": conf,
                "target_derivatives": targets,
                "compiler_policy": "complete_low_order_family_v1",
            })

        canonical_closures.sort(key=lambda g: (
            tuple(g["latent_expressions"]), tuple(g["partner_aliases"]),
            tuple(g["target_derivatives"]), g["reason"]
        ))

        for group in canonical_closures:
            latents = group["latent_expressions"]
            partners = group["partner_aliases"]
            conf = float(group["confidence"])
            reason = str(group["reason"])
            targets = list(group["target_derivatives"])
            generated: list[str] = []
            for lat in latents:
                for partner in partners:
                    generated.append(f"prod({lat},{partner})")
            if len(latents) >= 2:
                generated.append(f"prod({latents[0]},{latents[1]})")
            for lat in latents:
                generated.append(f"square({lat})")

            # Canonicalize and sort candidates before registration. This makes
            # the resulting bank independent of LLM list ordering.
            canonical_generated = sorted({
                c for expr in generated
                if (c := canonical_if_valid(expr, n_vars, max_depth, max_complexity)) is not None
            })
            for expr in canonical_generated:
                before = len(canonical_terms)
                register_item(expr, "llm_closure", reason, conf, targets)
                if len(canonical_terms) > before:
                    closure_generated.append(canonical_terms[-1])

        # Deterministic bank assembly. Coordinates are always retained. Direct
        # LLM terms are ranked canonically and preserved before closure terms,
        # so deterministic completion can never evict an explicitly inferred
        # physical motif merely because it generated many algebraic members.
        max_total = max_basis_terms + len(supplied_coords)
        direct_source_priority = {"llm_compiled": 2, "llm_latent": 1}

        direct_ranked = sorted(
            direct_terms,
            key=lambda x: (
                -float(direct_item_by_expr[x].get("confidence", 0.0)),
                -int(direct_source_priority.get(str(direct_item_by_expr[x].get("source", "")), 0)),
                len(x),
                x,
            ),
        )
        direct_all_terms = (supplied_coords + direct_ranked)[:max_total]
        direct_compiled_items = [direct_item_by_expr[x] for x in direct_all_terms]

        closure_only = [
            x for x in canonical_terms
            if str(item_by_expr[x].get("source", "")) == "llm_closure"
        ]
        closure_ranked = sorted(
            closure_only,
            key=lambda x: (
                -float(item_by_expr[x].get("confidence", 0.0)),
                len(x),
                x,
            ),
        )
        full_candidates = supplied_coords + direct_ranked + closure_ranked
        # Stable de-duplication while preserving the direct-before-closure order.
        all_terms: list[str] = []
        for x in full_candidates:
            if x not in all_terms:
                all_terms.append(x)
            if len(all_terms) >= max_total:
                break
        compiled_items = [item_by_expr[x] for x in all_terms]

        if not canonical_terms:
            raise RuntimeError("LLM returned no valid non-coordinate prior terms after DSL validation.")

        usage = usage_dict(resp)
        cost = estimate_cost(usage, req.get("pricing_usd_per_million", {}))
        result = {
            "ok": True,
            "adapter_version": VERSION,
            "model": getattr(resp, "model", model),
            "response_id": getattr(resp, "id", ""),
            "device_type": sem["device_type"],
            "discovery_seed": int(req.get("discovery_seed", 0)),
            "supplied_coordinate_terms": supplied_coords,
            "llm_discovered_terms": canonical_terms,
            "llm_direct_terms": direct_terms,
            "llm_direct_prior_bank": direct_all_terms,
            "llm_direct_prior_items": direct_compiled_items,
            "compiled_prior_bank": all_terms,
            "source_items": [x for x in compiled_items if x["source"] != "supplied_coordinate"],
            "compiled_prior_items": compiled_items,
            "latent_features": parsed.get("latent_features", []),
            "interaction_closures": canonical_closures,
            "raw_interaction_closures": parsed.get("interaction_closures", []),
            "closure_compiler_policy": "complete_low_order_family_v1",
            "closure_generated_terms": closure_generated,
            "prior_ode": parsed.get("prior_ode", []),
            "diagnosis": parsed.get("diagnosis", ""),
            "confidence": float(parsed.get("confidence", 0.0)),
            "rejected_terms": rejected,
            "usage": usage,
            "estimated_cost_usd": cost,
            "latency_seconds": latency,
            "cloud_call_count": 1,
            "cache_hit": False,
        }
        if cache_mode in {"record", "record_or_replay"}:
            write_json(cfile, result)
        write_json(resp_path, result)
        print(
            f"LLM_PRIOR_DISCOVERY_OK device={sem['device_type']} seed={req.get('discovery_seed')} "
            f"coord={len(supplied_coords)} discovered={len(canonical_terms)} "
            f"tokens={usage['input_tokens']}+{usage['output_tokens']} "
            f"cost=${cost:.6f} latency={latency:.2f}s"
        )
        return 0

    except Exception as exc:
        result = {
            "ok": False,
            "adapter_version": VERSION,
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            "cloud_call_count": 0,
            "cache_hit": False,
            "latency_seconds": time.perf_counter() - t0,
        }
        try:
            write_json(resp_path, result)
        except Exception:
            pass
        print(f"LLM_PRIOR_DISCOVERY_ERROR {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
