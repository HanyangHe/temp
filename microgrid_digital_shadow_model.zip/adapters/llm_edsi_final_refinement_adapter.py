#!/usr/bin/env python3
"""Two-pass GPT-6 Luna adapter for post-EDSI dictionary refinement.

MATLAB calls:
    python llm_edsi_final_refinement_adapter.py request.json response.json

The adapter performs:
  1) evolutionary-search diagnosis;
  2) concrete one-slot mutation proposal generation.

awareness_mode="task":
  The model knows this is SINDy-like sparse vector-field identification and
  sees the complete generation-by-generation best-lineage digest, but variable
  meanings and device identity remain hidden.

awareness_mode="domain":
  The same task information is provided, plus physical SG/GFM/GFL semantics
  and permission to use pretrained domain knowledge as an external prior.

The adapter never decides the final model. MATLAB validates and scores every
proposal with the same numerical ridge fitness used by EDSI.
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

from openai import OpenAI


ADAPTER_VERSION = "post_edsi_refinement_v1"


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)
    tmp.replace(path)


def usage_value(obj: Any, name: str, default: int = 0) -> int:
    if obj is None:
        return default
    try:
        return int(getattr(obj, name, default) or 0)
    except Exception:
        return default


def usage_dict(response: Any) -> dict[str, int]:
    usage = getattr(response, "usage", None)
    inp = usage_value(usage, "input_tokens")
    out = usage_value(usage, "output_tokens")
    total = usage_value(usage, "total_tokens", inp + out)
    details = getattr(usage, "input_tokens_details", None) if usage else None
    cached = usage_value(details, "cached_tokens")
    cache_write = usage_value(details, "cache_write_tokens")
    return {
        "input_tokens": inp,
        "output_tokens": out,
        "total_tokens": total,
        "cached_input_tokens": cached,
        "cache_write_tokens": cache_write,
    }


def add_usage(a: dict[str, int], b: dict[str, int]) -> dict[str, int]:
    keys = {
        "input_tokens",
        "output_tokens",
        "total_tokens",
        "cached_input_tokens",
        "cache_write_tokens",
    }
    return {k: int(a.get(k, 0)) + int(b.get(k, 0)) for k in keys}


def estimated_cost(usage: dict[str, int], pricing: dict[str, Any]) -> float:
    inp = int(usage.get("input_tokens", 0))
    cached = int(usage.get("cached_input_tokens", 0))
    cache_write = int(usage.get("cache_write_tokens", 0))
    uncached = max(inp - cached - cache_write, 0)
    out = int(usage.get("output_tokens", 0))

    p_input = float(pricing.get("input", 0.10))
    p_cached = float(pricing.get("cached_input", 0.01))
    p_write = float(pricing.get("cache_write", 0.0))
    p_output = float(pricing.get("output", 0.50))

    return (
        uncached * p_input
        + cached * p_cached
        + cache_write * p_write
        + out * p_output
    ) / 1_000_000.0


def diagnosis_schema(width: int) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "summary": {"type": "string"},
            "search_patterns": {
                "type": "array",
                "items": {"type": "string"},
                "maxItems": 10,
            },
            "persistent_motifs": {
                "type": "array",
                "items": {"type": "string"},
                "maxItems": 10,
            },
            "weak_or_redundant_slots": {
                "type": "array",
                "items": {"type": "integer", "minimum": 1, "maximum": width},
                "maxItems": 16,
            },
            "promising_parent_slots": {
                "type": "array",
                "items": {"type": "integer", "minimum": 2, "maximum": width},
                "maxItems": 16,
            },
            "unexplored_directions": {
                "type": "array",
                "items": {"type": "string"},
                "maxItems": 10,
            },
            "refinement_plan": {
                "type": "array",
                "items": {"type": "string"},
                "maxItems": 10,
            },
        },
        "required": [
            "summary",
            "search_patterns",
            "persistent_motifs",
            "weak_or_redundant_slots",
            "promising_parent_slots",
            "unexplored_directions",
            "refinement_plan",
        ],
        "additionalProperties": False,
    }


def proposal_schema(width: int) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "proposals": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "replace_slot": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": width,
                        },
                        "operator": {
                            "type": "string",
                            "enum": ["product", "sin", "cos"],
                        },
                        "arg1": {
                            "type": "integer",
                            "minimum": 2,
                            "maximum": width,
                        },
                        "arg2": {
                            "type": "integer",
                            "minimum": 0,
                            "maximum": width,
                        },
                        "strategy": {
                            "type": "string",
                            "enum": [
                                "history_supported_composition",
                                "replace_persistent_weak_basis",
                                "reuse_successful_lineage",
                                "escape_search_plateau",
                                "increase_compositional_depth",
                                "domain_prior_transfer",
                                "diversify_final_dictionary",
                            ],
                        },
                    },
                    "required": [
                        "replace_slot",
                        "operator",
                        "arg1",
                        "arg2",
                        "strategy",
                    ],
                    "additionalProperties": False,
                },
            }
        },
        "required": ["proposals"],
        "additionalProperties": False,
    }


def system_prompt(mode: str) -> str:
    shared = (
        "You are a final symbolic-dictionary refinement adviser for a completed "
        "SINDy-like sparse nonlinear dynamical-system identification process. "
        "The numerical backbone has already completed a fixed-width evolutionary "
        "dictionary search. Coefficients are solved analytically by ridge regression. "
        "You are NOT allowed to choose the final model or coefficients. "
        "Your job is to study the completed evolutionary search history and suggest "
        "a small set of legal one-slot dictionary refinements. "
        "A separate numerical program will validate, score, and accept/reject every proposal. "
        "Dictionary width is fixed. Allowed operators are product, sin, and cos only. "
        "Do not replace protected slots. Do not use the constant slot as an expression parent. "
        "For product use arg1 and arg2; for sin/cos set arg2=0. "
        "A linear readout can combine separate basis functions, so an additive physical "
        "relationship can be represented by multiple separate dictionary terms. "
        "Do not invent unsupported operators or constants."
    )
    if mode == "task":
        return shared + (
            " This is the TASK-AWARE / DOMAIN-BLIND condition. "
            "You know the SINDy/system-identification objective and complete evolutionary "
            "history, but x1, x2, ... have deliberately undisclosed physical meanings. "
            "Do not infer a power-system, inverter, generator, or any other application domain. "
            "Base suggestions only on symbolic structure, search lineage, fitness, persistence, "
            "complexity, and basis importance."
        )
    if mode == "domain":
        return shared + (
            " This is the DOMAIN-AWARE condition. "
            "You are explicitly allowed to use pretrained power-system, synchronous-machine, "
            "rotating-frame, PLL, and inverter-control knowledge as an EXTERNAL structural prior. "
            "Use the supplied physical variable mapping and component description together with "
            "the observed EDSI history. Do not assume textbook equations are exact; domain knowledge "
            "should prioritize plausible legal structures, while numerical validation remains authoritative."
        )
    raise ValueError(f"Unknown awareness mode: {mode}")


def cache_key(req: dict[str, Any]) -> str:
    relevant = {
        "adapter_version": ADAPTER_VERSION,
        "model": req.get("model"),
        "reasoning_effort": req.get("reasoning_effort"),
        "awareness_mode": req.get("awareness_mode"),
        "requested_proposals": req.get("requested_proposals"),
        "dictionary_width": req.get("dictionary_width"),
        "protected_slots": req.get("protected_slots"),
        "max_depth": req.get("max_depth"),
        "max_complexity": req.get("max_complexity"),
        "current_validation_fitness": req.get("current_validation_fitness"),
        "dictionary": req.get("dictionary"),
        "evolution_digest": req.get("evolution_digest"),
        "domain_context": req.get("domain_context"),
    }
    raw = json.dumps(relevant, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def create_structured_response(
    client: OpenAI,
    *,
    model: str,
    reasoning_effort: str,
    system: str,
    user_payload: dict[str, Any],
    schema_name: str,
    schema: dict[str, Any],
    max_output_tokens: int,
    store: bool,
) -> Any:
    return client.responses.create(
        model=model,
        reasoning={"effort": reasoning_effort},
        input=[
            {"role": "system", "content": system},
            {
                "role": "user",
                "content": json.dumps(
                    user_payload, separators=(",", ":"), ensure_ascii=False
                ),
            },
        ],
        text={
            "format": {
                "type": "json_schema",
                "name": schema_name,
                "strict": True,
                "schema": schema,
            }
        },
        max_output_tokens=max_output_tokens,
        store=store,
    )


def main() -> int:
    if len(sys.argv) != 3:
        print(
            "Usage: llm_edsi_final_refinement_adapter.py request.json response.json",
            file=sys.stderr,
        )
        return 64

    request_path = Path(sys.argv[1]).resolve()
    response_path = Path(sys.argv[2]).resolve()
    t0 = time.perf_counter()

    try:
        req = read_json(request_path)
        mode = str(req["awareness_mode"]).lower()
        if mode not in {"task", "domain"}:
            raise ValueError("awareness_mode must be 'task' or 'domain'")

        model = str(req.get("model", "gpt-6-luna"))
        effort = str(req.get("reasoning_effort", "low"))
        width = int(req["dictionary_width"])
        requested = int(req["requested_proposals"])
        max_diag = int(req.get("max_diagnosis_output_tokens", 1600))
        max_prop = int(req.get("max_proposal_output_tokens", 1800))
        store = bool(req.get("store", False))
        cache_mode = str(req.get("cache_mode", "record_or_replay")).lower()
        cache_dir = Path(req.get("cache_dir", request_path.parent / "cache")).resolve()
        cache_dir.mkdir(parents=True, exist_ok=True)

        if not os.environ.get("OPENAI_API_KEY"):
            raise RuntimeError(
                "OPENAI_API_KEY is not visible to this Python process. "
                "Restart MATLAB after setting the Windows environment variable."
            )

        key = cache_key(req)
        cache_path = cache_dir / f"{key}.json"

        if cache_mode in {"replay", "record_or_replay"} and cache_path.exists():
            cached = read_json(cache_path)
            replay = dict(cached)
            replay["cache_hit"] = True
            replay["original_estimated_cost_usd"] = float(
                cached.get("estimated_cost_usd", 0.0)
            )
            replay["estimated_cost_usd"] = 0.0
            replay["latency_seconds"] = time.perf_counter() - t0
            replay["cloud_call_count"] = 0
            write_json(response_path, replay)
            print(
                f"LLM_EDSI_REFINEMENT_CACHE_HIT mode={mode} "
                f"proposals={len(replay.get('proposals', []))}"
            )
            return 0

        if cache_mode == "replay" and not cache_path.exists():
            raise RuntimeError(f"Replay requested but cache entry is missing: {cache_path}")

        client = OpenAI()
        sys_prompt = system_prompt(mode)

        diagnosis_payload = {
            "task": "diagnose_completed_edsi_evolution",
            "awareness_mode": mode,
            "dictionary_width": width,
            "protected_slots": req["protected_slots"],
            "allowed_operators": ["product", "sin", "cos"],
            "max_depth": int(req["max_depth"]),
            "max_complexity": int(req["max_complexity"]),
            "current_validation_fitness": float(req["current_validation_fitness"]),
            "current_dictionary": req["dictionary"],
            "complete_evolution_digest": req["evolution_digest"],
            "instructions": [
                "Interpret the complete generation-by-generation search trajectory before proposing changes.",
                "Identify structures that survived, repeatedly improved fitness, or remained weak/redundant.",
                "Look for plausible compositions not adequately explored by the completed evolution.",
                "Do not make final acceptance decisions; numerical validation is authoritative.",
            ],
        }
        if mode == "domain":
            diagnosis_payload["domain_context"] = req["domain_context"]

        diagnosis_response = create_structured_response(
            client,
            model=model,
            reasoning_effort=effort,
            system=sys_prompt,
            user_payload=diagnosis_payload,
            schema_name="edsi_final_refinement_diagnosis",
            schema=diagnosis_schema(width),
            max_output_tokens=max_diag,
            store=store,
        )
        if getattr(diagnosis_response, "status", None) == "incomplete":
            raise RuntimeError("Diagnosis response was incomplete.")
        if not diagnosis_response.output_text:
            raise RuntimeError("Diagnosis response contained no output_text.")
        diagnosis = json.loads(diagnosis_response.output_text)

        proposal_payload = {
            "task": "propose_final_edsi_dictionary_refinements",
            "awareness_mode": mode,
            "requested_proposals": requested,
            "dictionary_width": width,
            "protected_slots": req["protected_slots"],
            "allowed_operators": ["product", "sin", "cos"],
            "max_depth": int(req["max_depth"]),
            "max_complexity": int(req["max_complexity"]),
            "current_validation_fitness": float(req["current_validation_fitness"]),
            "current_dictionary": req["dictionary"],
            "complete_evolution_digest": req["evolution_digest"],
            "diagnosis": diagnosis,
            "rules": [
                "Each proposal changes exactly one replaceable dictionary slot.",
                "replace_slot must not be protected.",
                "arg1 and arg2 are current dictionary slot indices.",
                "for sin/cos arg2 must be 0.",
                "for product arg2 must be >= 2.",
                "avoid expressions already present in the current dictionary.",
                "diversify the proposal set rather than repeating the same motif.",
                "prefer proposals justified by the completed search history.",
            ],
        }
        if mode == "domain":
            proposal_payload["domain_context"] = req["domain_context"]

        proposal_response = create_structured_response(
            client,
            model=model,
            reasoning_effort=effort,
            system=sys_prompt,
            user_payload=proposal_payload,
            schema_name="edsi_final_refinement_proposals",
            schema=proposal_schema(width),
            max_output_tokens=max_prop,
            store=store,
        )
        if getattr(proposal_response, "status", None) == "incomplete":
            raise RuntimeError("Proposal response was incomplete.")
        if not proposal_response.output_text:
            raise RuntimeError("Proposal response contained no output_text.")

        parsed = json.loads(proposal_response.output_text)
        proposals = parsed.get("proposals", [])

        u1 = usage_dict(diagnosis_response)
        u2 = usage_dict(proposal_response)
        usage = add_usage(u1, u2)
        cost = estimated_cost(usage, req.get("pricing_usd_per_million", {}))

        result = {
            "ok": True,
            "adapter_version": ADAPTER_VERSION,
            "awareness_mode": mode,
            "model": getattr(proposal_response, "model", model),
            "cache_hit": False,
            "cloud_call_count": 2,
            "diagnosis_response_id": getattr(diagnosis_response, "id", ""),
            "proposal_response_id": getattr(proposal_response, "id", ""),
            "diagnosis": diagnosis,
            "requested_proposals": requested,
            "returned_proposals": len(proposals),
            "proposals": proposals,
            "usage": usage,
            "estimated_cost_usd": cost,
            "latency_seconds": time.perf_counter() - t0,
        }

        if cache_mode in {"record", "record_or_replay"}:
            write_json(cache_path, result)
        write_json(response_path, result)

        print(
            f"LLM_EDSI_FINAL_REFINE_OK mode={mode} model={result['model']} "
            f"proposals={len(proposals)} calls=2 "
            f"tokens={usage['input_tokens']}+{usage['output_tokens']} "
            f"cost=${cost:.6f} latency={result['latency_seconds']:.3f}s"
        )
        return 0

    except Exception as exc:
        result = {
            "ok": False,
            "adapter_version": ADAPTER_VERSION,
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            "cache_hit": False,
            "cloud_call_count": 0,
            "latency_seconds": time.perf_counter() - t0,
            "estimated_cost_usd": 0.0,
            "proposals": [],
        }
        try:
            write_json(response_path, result)
        except Exception:
            pass
        print(
            f"LLM_EDSI_FINAL_REFINE_ERROR {type(exc).__name__}: {exc}",
            file=sys.stderr,
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
