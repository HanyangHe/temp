#!/usr/bin/env python3
"""Semantic ODE-first LLM adapter for EDSI.

The model sees explicit variable semantics plus a compact sparse fitted ODE and
active-term summary. It forms a concise physical prior ODE and proposes only a
small set of structural dictionary edits. The adapter then reconstructs the full
fixed-width parent dictionary locally before MATLAB re-fits and validates it.

This adapter validates and canonicalizes every expression before MATLAB sees it.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from openai import OpenAI

# Version is intentionally bumped because the cloud prompt/schema changed from
# full-dictionary generation to compact sparse structural edits. Old cached
# responses must not be reused under the new formal method.
VERSION = "semantic_sparse_ode_edit_edsi_v3_dsl2_20261004"


def read_json(p: Path) -> dict[str, Any]:
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_json(p: Path, obj: dict[str, Any]) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
    tmp.replace(p)


def nattr(obj: Any, name: str, default: int = 0) -> int:
    try:
        return int(getattr(obj, name, default) or 0)
    except Exception:
        return default


def usage_dict(resp: Any) -> dict[str, int]:
    u = getattr(resp, "usage", None)
    inp = nattr(u, "input_tokens")
    out = nattr(u, "output_tokens")
    details = getattr(u, "input_tokens_details", None) if u else None
    return {
        "input_tokens": inp,
        "output_tokens": out,
        "total_tokens": nattr(u, "total_tokens", inp + out),
        "cached_input_tokens": nattr(details, "cached_tokens"),
        "cache_write_tokens": nattr(details, "cache_write_tokens"),
    }


def estimate_cost(u: dict[str, int], p: dict[str, Any]) -> float:
    inp = int(u.get("input_tokens", 0))
    cached = int(u.get("cached_input_tokens", 0))
    written = int(u.get("cache_write_tokens", 0))
    uncached = max(inp - cached - written, 0)
    out = int(u.get("output_tokens", 0))
    return (
        uncached * float(p.get("input", 0.10))
        + cached * float(p.get("cached_input", 0.01))
        + written * float(p.get("cache_write", 0.0))
        + out * float(p.get("output", 0.50))
    ) / 1_000_000.0


def cache_key(req: dict[str, Any]) -> str:
    q = dict(req)
    q.pop("cache_dir", None)
    q.pop("pricing_usd_per_million", None)
    q["adapter_version"] = VERSION
    raw = json.dumps(q, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


# ----------------------------------------------------------------------
# Symbolic DSL parser/canonicalizer
# ----------------------------------------------------------------------
@dataclass(frozen=True)
class Expr:
    op: str
    args: tuple["Expr", ...] = ()
    var: int | None = None

    def depth(self) -> int:
        if self.op in {"const", "var"}:
            return 0
        return 1 + max(a.depth() for a in self.args)

    def complexity(self) -> int:
        if self.op in {"const", "var"}:
            return 0
        if self.op in {"sin", "cos", "square", "sqrt_pos", "sub", "div"}:
            return sum(a.complexity() for a in self.args) + 1
        return sum(a.complexity() for a in self.args) + len(self.args) - 1

    def canonical(self) -> str:
        if self.op == "const":
            return "1"
        if self.op == "var":
            return f"x{self.var}"
        if self.op in {"sin", "cos", "square", "sqrt_pos"}:
            return f"{self.op}({self.args[0].canonical()})"
        if self.op in {"prod", "add"}:
            flat: list[Expr] = []
            for a in self.args:
                if a.op == self.op:
                    flat.extend(a.args)
                else:
                    flat.append(a)
            vals = sorted(a.canonical() for a in flat)
            return f"{self.op}({','.join(vals)})"
        if self.op in {"sub", "div"}:
            return f"{self.op}({self.args[0].canonical()},{self.args[1].canonical()})"
        raise ValueError(self.op)


def split_args(body: str) -> list[str]:
    depth = 0
    start = 0
    out: list[str] = []
    for i, ch in enumerate(body):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth < 0:
                raise ValueError("unbalanced parentheses")
        elif ch == "," and depth == 0:
            out.append(body[start:i])
            start = i + 1
    if depth != 0:
        raise ValueError("unbalanced parentheses")
    out.append(body[start:])
    if any(not x for x in out):
        raise ValueError("empty argument")
    return out


def parse_expr(s: str, n_vars: int) -> Expr:
    s = re.sub(r"\s+", "", s)
    if s == "1":
        return Expr("const")

    m = re.fullmatch(r"x(\d+)", s)
    if m:
        idx = int(m.group(1))
        if idx < 1 or idx > n_vars:
            raise ValueError(f"invalid variable x{idx}")
        return Expr("var", var=idx)

    p = s.find("(")
    if p <= 0 or not s.endswith(")"):
        raise ValueError(f"invalid expression syntax: {s}")
    op = s[:p].lower()
    args = split_args(s[p + 1 : -1])

    if op in {"sin", "cos", "square", "sqrt_pos"}:
        if len(args) != 1:
            raise ValueError(f"{op} expects 1 arg")
        return Expr(op, (parse_expr(args[0], n_vars),))

    if op in {"prod", "add"}:
        if len(args) < 2:
            raise ValueError(f"{op} expects >=2 args")
        return Expr(op, tuple(parse_expr(a, n_vars) for a in args))

    if op in {"sub", "div"}:
        if len(args) != 2:
            raise ValueError(f"{op} expects 2 args")
        return Expr(op, tuple(parse_expr(a, n_vars) for a in args))

    raise ValueError(f"unsupported operator: {op}")



def _canonical_if_valid(
    raw: str,
    n_vars: int,
    max_depth: int,
    max_complexity: int,
) -> str | None:
    try:
        e = parse_expr(str(raw), n_vars)
    except Exception:
        return None
    if e.depth() > max_depth or e.complexity() > max_complexity:
        return None
    return e.canonical()


def repair_dictionary(
    proposed_terms: list[str],
    parent_terms: list[str],
    width: int,
    n_vars: int,
    max_depth: int,
    max_complexity: int,
    preserve_terms: list[str] | None = None,
) -> tuple[list[str], dict[str, int]]:
    """Repair syntax-level dictionary issues without another cloud request."""
    required = ["1"] + [f"x{i}" for i in range(1, n_vars + 1)]
    out: list[str] = []
    seen: set[str] = set()
    stats = {
        "invalid_removed": 0,
        "duplicates_removed": 0,
        "parent_fill_count": 0,
        "llm_terms_kept": 0,
        "active_parent_replaced": 0,
        "proposal_dropped_no_slot": 0,
    }

    for term in required:
        out.append(term)
        seen.add(term)

    if len(out) > width:
        raise ValueError(
            f"required anchors ({len(out)}) exceed dictionary width={width}"
        )

    # Preserve the sparse active parent support first, ordered upstream by
    # descending importance.  If the preserved support already fills every
    # non-anchor slot, a genuinely new LLM proposal deterministically replaces
    # the weakest preserved non-anchor term instead of overflowing width.  This
    # is a local bookkeeping repair only: the parent elite itself remains in the
    # population and MATLAB STLSQ/validation still decides whether this child
    # survives.
    required_count = len(out)
    for raw in preserve_terms or []:
        if len(out) >= width:
            break
        canon = _canonical_if_valid(raw, n_vars, max_depth, max_complexity)
        if canon is None or canon in seen:
            continue
        out.append(canon)
        seen.add(canon)

    replace_cursor = len(out) - 1
    for raw in proposed_terms:
        canon = _canonical_if_valid(raw, n_vars, max_depth, max_complexity)
        if canon is None:
            stats["invalid_removed"] += 1
            continue
        if canon in seen:
            stats["duplicates_removed"] += 1
            continue

        if len(out) >= width:
            # All slots are occupied by anchors + importance-sorted preserved
            # parent terms at this point. Replace the weakest preserved term
            # (the last non-anchor slot) so the LLM edit is represented while
            # the fixed dictionary width is strictly maintained.
            if replace_cursor < required_count:
                stats["proposal_dropped_no_slot"] += 1
                continue
            removed = out.pop(replace_cursor)
            seen.remove(removed)
            replace_cursor -= 1
            stats["active_parent_replaced"] += 1

        out.append(canon)
        seen.add(canon)
        stats["llm_terms_kept"] += 1

    if len(out) < width:
        for raw in parent_terms:
            if len(out) >= width:
                break
            canon = _canonical_if_valid(raw, n_vars, max_depth, max_complexity)
            if canon is None or canon in seen:
                continue
            out.append(canon)
            seen.add(canon)
            stats["parent_fill_count"] += 1

    if len(out) != width:
        raise ValueError(
            f"repair produced {len(out)} unique terms; required width={width}"
        )
    return out, stats


def schema(n_candidates: int, n_outputs: int, max_proposed_terms: int) -> dict[str, Any]:
    item = {
        "type": "object",
        "properties": {
            "candidate_id": {
                "type": "integer",
                "minimum": 1,
                "maximum": n_candidates,
            },
            "prior_ode": {
                "type": "array",
                "items": {"type": "string", "maxLength": 280},
                "minItems": n_outputs,
                "maxItems": n_outputs,
            },
            "diagnosis": {"type": "string", "maxLength": 500},
            "proposed_terms": {
                "type": "array",
                "items": {"type": "string"},
                "minItems": 0,
                "maxItems": max_proposed_terms,
            },
            "confidence": {"type": "number", "minimum": 0, "maximum": 1},
        },
        "required": [
            "candidate_id", "prior_ode", "diagnosis",
            "proposed_terms", "confidence",
        ],
        "additionalProperties": False,
    }
    return {
        "type": "object",
        "properties": {
            "refinements": {
                "type": "array",
                "items": item,
                "minItems": n_candidates,
                "maxItems": n_candidates,
            }
        },
        "required": ["refinements"],
        "additionalProperties": False,
    }


SYSTEM_PROMPT = r"""
You are f_LLM, an ODE-prior reasoner for sparse system identification.

For each elite:
1) infer a compact physical prior ODE from the explicit variable glossary and
   device description;
2) compare it with the CURRENT SPARSE fitted ODE and active symbolic terms;
3) propose only a SMALL SET of non-anchor symbolic terms that could improve
   the physical structure.

Do NOT return a complete dictionary. MATLAB's local adapter preserves the
active parent structure, inserts your proposed terms, fills unused fixed-width
slots from the parent dictionary, then re-fits all coefficients with STLSQ and
uses held-out validation to decide whether the proposal survives.

Prefer physically meaningful missing couplings over cosmetic variants of terms
already present. Do not include anchors 1,x1,...,xn in proposed_terms.

Return EXACTLY one refinement for each elite, in the SAME array order as the
input elites. Preserve each elite candidate_id exactly. If the elites are
candidate_id 1 and 2, the output candidate_id sequence must be [1,2].

Dictionary DSL: xN, prod(...), add(...), sub(a,b), div(a,b), sin(...), cos(...), square(...), sqrt_pos(...).
Use xN aliases in machine expressions; the glossary supplies their meanings.
Return concise prior equations/diagnosis, not chain-of-thought.
""".strip()


def compact_semantics(sem: dict[str, Any]) -> dict[str, Any]:
    variables = [
        f"{v['alias']}={v['symbol']}|{v['meaning']}|{v['role']}|{v['unit']}"
        for v in sem["variable_glossary"]
    ]
    derivatives = [
        f"{d['alias']}={d['physical_symbol']}|{d['meaning']}"
        for d in sem["target_derivatives"]
    ]
    return {
        "device": sem["device_type"],
        "system": sem["system_description"],
        "variables": variables,
        "derivatives": derivatives,
    }


def compact_candidate(c: dict[str, Any], contract: dict[str, Any]) -> dict[str, Any]:
    ode = [str(eq["readable_equation"]) for eq in c["current_identified_ode"]]
    terms = list(c["complete_dictionary"])
    anchors = {"1", *[str(x) for x in contract.get("required_variable_aliases", [])]}
    active = [
        t for t in terms
        if bool(t.get("active", False)) and str(t.get("machine_expression")) not in anchors
    ]
    active.sort(
        key=lambda t: float(t.get("importance", 0.0) or 0.0),
        reverse=True,
    )
    max_active = int(contract.get("max_active_dictionary_terms", 24))
    active_view = [
        f"{t['machine_expression']}|imp={float(t.get('importance', 0.0) or 0.0):.3g}"
        for t in active[:max_active]
    ]

    inactive_n = int(contract.get("inactive_context_terms", 0))
    inactive_view: list[str] = []
    if inactive_n > 0:
        inactive = [t for t in terms if not bool(t.get("active", False))]
        inactive.sort(
            key=lambda t: float(t.get("importance", 0.0) or 0.0),
            reverse=True,
        )
        inactive_view = [
            str(t["machine_expression"]) for t in inactive[:inactive_n]
        ]

    return {
        "candidate_id": int(c["candidate_id"]),
        "validation_nmse": float(c["validation_nmse"]),
        "current_sparse_ode": ode,
        "active_dictionary_terms": active_view,
        "active_term_count": len(active),
        "dictionary_width": len(terms),
        "inactive_context_terms": inactive_view,
    }


def make_user_payload(req: dict[str, Any]) -> dict[str, Any]:
    c = req["dictionary_contract"]
    return {
        "goal": (
            "Infer the physical ODE prior from the sparse fitted model and "
            "propose a few missing physically meaningful symbolic terms."
        ),
        "generation": int(req["generation"]),
        "system": compact_semantics(req["semantic_system"]),
        "dictionary": {
            "width": int(c["fixed_width"]),
            "anchors": ["1"] + list(c["required_variable_aliases"]),
            "ops": list(c["allowed_functions"]),
            "max_depth": int(c["max_expression_depth"]),
            "max_complexity": int(c["max_expression_complexity"]),
            "max_proposed_terms": int(c["max_proposed_terms"]),
        },
        "elites": [compact_candidate(x, c) for x in req["candidates"]],
        "verification": (
            "The local adapter reconstructs a complete fixed-width dictionary; "
            "MATLAB re-fits it with sparse STLSQ and held-out pointwise "
            "validation. Parent elites remain preserved."
        ),
    }


def normalize_refinement_candidate_ids(
    refinements: list[dict[str, Any]], candidates: list[dict[str, Any]]
) -> tuple[list[dict[str, Any]], bool, list[int]]:
    """Make candidate IDs total/unique without spending another API call.

    Strict JSON schema constrains the numeric range but cannot enforce array-wide
    uniqueness.  GPT can therefore occasionally return e.g. [1,1] for two
    elites.  The prompt requires same-order output, so when the array length is
    correct we can safely restore the IDs positionally.  MATLAB still re-fits
    and validates every returned dictionary against its corresponding parent,
    so this repair cannot silently accept a bad model proposal.
    """
    expected = [int(c["candidate_id"]) for c in candidates]
    if len(refinements) != len(expected):
        raise RuntimeError(
            f"returned {len(refinements)} refinements; expected {len(expected)}"
        )

    model_ids = [int(x["candidate_id"]) for x in refinements]
    if len(set(model_ids)) == len(model_ids) and sorted(model_ids) == sorted(expected):
        by_id = {int(x["candidate_id"]): x for x in refinements}
        return [by_id[cid] for cid in expected], False, model_ids

    # Same-order output is part of SYSTEM_PROMPT.  Repair only the IDs; the
    # dictionaries themselves are left untouched and remain subject to the
    # existing MATLAB pointwise validation gate.
    repaired: list[dict[str, Any]] = []
    for cid, item in zip(expected, refinements):
        q = dict(item)
        q["candidate_id"] = cid
        repaired.append(q)
    return repaired, True, model_ids


def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: llm_edsi_ode_prior_adapter.py request.json response.json",
              file=sys.stderr)
        return 64

    request_path = Path(sys.argv[1]).resolve()
    response_path = Path(sys.argv[2]).resolve()
    t0 = time.perf_counter()

    try:
        req = read_json(request_path)
        if not os.environ.get("OPENAI_API_KEY"):
            raise RuntimeError("OPENAI_API_KEY is not visible to Python.")

        candidates = list(req["candidates"])
        contract = dict(req["dictionary_contract"])
        sem = dict(req["semantic_system"])
        width = int(contract["fixed_width"])
        n_vars = len(sem["variable_glossary"])
        n_outputs = len(sem["target_derivatives"])
        max_depth = int(contract["max_expression_depth"])
        max_complexity = int(contract["max_expression_complexity"])
        max_proposed_terms = int(contract.get("max_proposed_terms", 8))

        cache_dir = Path(req["cache_dir"]).resolve()
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_mode = str(req.get("cache_mode", "record_or_replay")).lower()
        cfile = cache_dir / f"{cache_key(req)}.json"

        if cache_mode in {"replay", "record_or_replay"} and cfile.exists():
            result = read_json(cfile)
            result["cache_hit"] = True
            result["cloud_call_count"] = 0
            result["estimated_cost_usd"] = 0.0
            result["latency_seconds"] = time.perf_counter() - t0
            write_json(response_path, result)
            print(
                f"LLM_ODE_PRIOR_CACHE_HIT g={req.get('generation')} "
                f"n={len(result.get('refinements', []))}"
            )
            return 0
        if cache_mode == "replay":
            raise RuntimeError(f"Replay requested but cache missing: {cfile}")

        client = OpenAI()
        model = str(req.get("model", "gpt-6-luna"))
        effort = str(req.get("reasoning_effort", "medium"))
        payload = make_user_payload(req)

        max_tokens = int(req.get("max_output_tokens", 10000))
        base_input = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": json.dumps(
                    payload, separators=(",", ":"), ensure_ascii=False
                ),
            },
        ]

        start_call = time.perf_counter()
        resp = client.responses.create(
            model=model,
            reasoning={"effort": effort},
            input=base_input,
            text={
                "format": {
                    "type": "json_schema",
                    "name": "semantic_sparse_ode_edit_fast",
                    "strict": True,
                    "schema": schema(len(candidates), n_outputs, max_proposed_terms),
                }
            },
            max_output_tokens=max_tokens,
            store=bool(req.get("store", False)),
        )
        latency = time.perf_counter() - start_call
        cloud_calls = 1

        # Medium reasoning consumes part of max_output_tokens.  If the model
        # exhausts the budget, make one targeted retry with a larger ceiling.
        # This is only for truncation/incomplete responses, never for duplicate
        # terms (duplicates are repaired locally below).
        if getattr(resp, "status", None) == "incomplete":
            retry_input = base_input + [{
                "role": "user",
                "content": (
                    "The previous response was truncated. Re-run the same task "
                    "more concisely. Keep prior_ode and diagnosis brief and "
                    "return only the requested small proposed_terms list."
                ),
            }]
            retry_start = time.perf_counter()
            resp = client.responses.create(
                model=model,
                reasoning={"effort": effort},
                input=retry_input,
                text={
                    "format": {
                        "type": "json_schema",
                        "name": "semantic_sparse_ode_edit_fast_retry",
                        "strict": True,
                        "schema": schema(len(candidates), n_outputs, max_proposed_terms),
                    }
                },
                max_output_tokens=max(max_tokens, 14000),
                store=bool(req.get("store", False)),
            )
            latency += time.perf_counter() - retry_start
            cloud_calls += 1

        if getattr(resp, "status", None) == "incomplete":
            details = getattr(resp, "incomplete_details", None)
            raise RuntimeError(
                "GPT response remained incomplete after one truncation retry; "
                f"details={details!r}"
            )
        if not resp.output_text:
            raise RuntimeError("GPT response contained no output_text.")

        parsed = json.loads(resp.output_text)
        refinements = list(parsed.get("refinements", []))
        refinements, candidate_id_repaired, model_candidate_ids = \
            normalize_refinement_candidate_ids(refinements, candidates)
        if candidate_id_repaired:
            expected_ids = [int(c["candidate_id"]) for c in candidates]
            print(
                "LLM_ODE_PRIOR_ID_REPAIR "
                f"model_ids={model_candidate_ids} -> expected={expected_ids}; "
                "repaired positionally; MATLAB validation remains authoritative."
            )

        by_id = {int(c["candidate_id"]): c for c in candidates}
        repair_totals = {
            "invalid_removed": 0,
            "duplicates_removed": 0,
            "parent_fill_count": 0,
            "llm_terms_kept": 0,
            "active_parent_replaced": 0,
            "proposal_dropped_no_slot": 0,
        }

        # Reconstruct the full fixed-width dictionary locally. Active sparse
        # parent terms are preserved before inactive filler terms, so the cloud
        # only needs to propose a few genuinely new structural candidates.
        for item in refinements:
            cid = int(item["candidate_id"])
            parent_dict = list(by_id[cid]["complete_dictionary"])
            active_parent = [t for t in parent_dict if bool(t.get("active", False))]
            inactive_parent = [t for t in parent_dict if not bool(t.get("active", False))]
            active_parent.sort(
                key=lambda t: float(t.get("importance", 0.0) or 0.0),
                reverse=True,
            )
            inactive_parent.sort(
                key=lambda t: float(t.get("importance", 0.0) or 0.0),
                reverse=True,
            )
            parent_terms = [
                str(t["machine_expression"])
                for t in active_parent + inactive_parent
            ]
            preserve_terms = [
                str(t["machine_expression"]) for t in active_parent
            ]
            repaired, stats = repair_dictionary(
                list(item.get("proposed_terms", [])),
                parent_terms,
                width,
                n_vars,
                max_depth,
                max_complexity,
                preserve_terms=preserve_terms,
            )
            item["refined_dictionary"] = repaired
            item["prior_ode_summary"] = " ; ".join(
                str(x) for x in item.get("prior_ode", [])
            )
            item["repair_stats"] = stats
            for k in repair_totals:
                repair_totals[k] += int(stats[k])

        usage = usage_dict(resp)
        cost = estimate_cost(usage, req.get("pricing_usd_per_million", {}))

        result = {
            "ok": True,
            "adapter_version": VERSION,
            "model": getattr(resp, "model", model),
            "response_id": getattr(resp, "id", ""),
            "generation": int(req["generation"]),
            "refinements": refinements,
            "usage": usage,
            "estimated_cost_usd": cost,
            "latency_seconds": latency,
            "cloud_call_count": cloud_calls,
            "cache_hit": False,
            "repair_totals": repair_totals,
            "candidate_id_repaired": bool(candidate_id_repaired),
            "model_candidate_ids": model_candidate_ids,
        }

        if cache_mode in {"record", "record_or_replay"}:
            write_json(cfile, result)
        write_json(response_path, result)

        print(
            f"LLM_ODE_PRIOR_OK g={req['generation']} "
            f"n={len(refinements)} calls={cloud_calls} "
            f"tokens={usage['input_tokens']}+{usage['output_tokens']} "
            f"cost=${cost:.6f} latency={latency:.2f}s "
            f"dupfix={repair_totals['duplicates_removed']} "
            f"parentfill={repair_totals['parent_fill_count']} "
            f"proposed_kept={repair_totals['llm_terms_kept']} "
            f"active_replaced={repair_totals['active_parent_replaced']} "
            f"proposal_dropped={repair_totals['proposal_dropped_no_slot']}"
        )
        return 0

    except Exception as exc:
        result = {
            "ok": False,
            "adapter_version": VERSION,
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            "refinements": [],
            "estimated_cost_usd": 0.0,
            "latency_seconds": time.perf_counter() - t0,
            "cloud_call_count": 0,
            "cache_hit": False,
        }
        try:
            write_json(response_path, result)
        except Exception:
            pass
        print(f"LLM_ODE_PRIOR_ERROR {type(exc).__name__}: {exc}",
              file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
