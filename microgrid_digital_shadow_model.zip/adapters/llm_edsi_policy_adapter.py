#!/usr/bin/env python3
"""GPT-6 Luna soft search-policy adviser for LLM-Constrained EDSI.

The model does NOT generate child dictionaries. It only returns bounded soft
mutation priors. MATLAB blends these priors with deterministic elite-consensus
rules and retains a large unguided exploration stream.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

from openai import OpenAI

VERSION = "llm_edsi_soft_policy_v1_20261003"


def load_json(p: Path) -> dict[str, Any]:
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def save_json(p: Path, obj: dict[str, Any]) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
    tmp.replace(p)


def nattr(obj: Any, name: str, default: int = 0) -> int:
    try:
        return int(getattr(obj, name, default) or 0)
    except Exception:
        return default


def usage_dict(resp: Any) -> dict[str, int]:
    u = getattr(resp, "usage", None)
    inp = nattr(u, "input_tokens")
    out = nattr(u, "output_tokens")
    det = getattr(u, "input_tokens_details", None) if u else None
    return {
        "input_tokens": inp,
        "output_tokens": out,
        "total_tokens": nattr(u, "total_tokens", inp + out),
        "cached_input_tokens": nattr(det, "cached_tokens"),
        "cache_write_tokens": nattr(det, "cache_write_tokens"),
    }


def cost_usd(usage: dict[str, int], price: dict[str, Any]) -> float:
    inp = int(usage.get("input_tokens", 0))
    cached = int(usage.get("cached_input_tokens", 0))
    written = int(usage.get("cache_write_tokens", 0))
    uncached = max(inp - cached - written, 0)
    out = int(usage.get("output_tokens", 0))
    return (
        uncached * float(price.get("input", 0.10))
        + cached * float(price.get("cached_input", 0.01))
        + written * float(price.get("cache_write", 0.0))
        + out * float(price.get("output", 0.50))
    ) / 1_000_000.0


def key_for(req: dict[str, Any]) -> str:
    q = dict(req)
    q.pop("cache_dir", None)
    q.pop("pricing_usd_per_million", None)
    q["adapter_version"] = VERSION
    raw = json.dumps(q, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def schema(n_modules: int, max_width: int) -> dict[str, Any]:
    policy = {
        "type": "object",
        "properties": {
            "module_id": {"type": "integer", "minimum": 1, "maximum": n_modules},
            "protect_slots": {
                "type": "array",
                "items": {"type": "integer", "minimum": 1, "maximum": max_width},
                "maxItems": 12,
            },
            "replace_slots": {
                "type": "array",
                "items": {"type": "integer", "minimum": 1, "maximum": max_width},
                "maxItems": 16,
            },
            "parent_slots": {
                "type": "array",
                "items": {"type": "integer", "minimum": 2, "maximum": max_width},
                "maxItems": 16,
            },
            "operator_weights": {
                "type": "object",
                "properties": {
                    "product": {"type": "number", "minimum": 0, "maximum": 1},
                    "sin": {"type": "number", "minimum": 0, "maximum": 1},
                    "cos": {"type": "number", "minimum": 0, "maximum": 1},
                },
                "required": ["product", "sin", "cos"],
                "additionalProperties": False,
            },
            "confidence": {"type": "number", "minimum": 0, "maximum": 1},
            "policy_intent": {
                "type": "string",
                "enum": [
                    "protect_stable_motifs",
                    "replace_weak_slots",
                    "reuse_strong_compositions",
                    "restore_diversity",
                    "domain_prior_regularization",
                    "balanced_stability_exploration",
                ],
            },
        },
        "required": [
            "module_id", "protect_slots", "replace_slots", "parent_slots",
            "operator_weights", "confidence", "policy_intent",
        ],
        "additionalProperties": False,
    }
    return {
        "type": "object",
        "properties": {
            "policies": {
                "type": "array",
                "items": policy,
                "minItems": n_modules,
                "maxItems": n_modules,
            }
        },
        "required": ["policies"],
        "additionalProperties": False,
    }


def system_prompt(mode: str) -> str:
    common = """
You are a SEARCH-POLICY adviser inside a fixed-width SINDy-like evolutionary
dictionary identification algorithm.

You are NOT a mutation generator. Do not output child dictionaries, equations,
coefficients, or final-model decisions.

For each module, the current 8 elites are ranked WORST to BEST by held-out
pointwise vector-field validation error. You also receive per-slot elite
consensus, coefficient importance, recent best-fitness history, and compact
strong/weak/evolved-term summaries.

Return only SOFT mutation priors:
- protect_slots: evolvable slots that should be changed less often;
- replace_slots: evolvable slots deserving more mutation pressure;
- parent_slots: expressions worth reusing as compositional parents;
- product/sin/cos operator weights;
- confidence.

Be conservative. Favor stability and repeatability while preserving search
diversity. These are probabilistic suggestions only: MATLAB keeps a nonzero
exploration probability for every evolvable slot and a large unguided
offspring stream. Never include protected [1,x] anchors in replace_slots.
""".strip()
    if mode == "task":
        return common + """
TASK-AWARE / DOMAIN-BLIND condition: x1,x2,... have deliberately undisclosed
physical meanings. Do not infer a microgrid, generator, inverter, or any other
application domain. Use only ranked symbolic evidence, consensus, importance,
complexity, diversity, and fitness trend.
"""
    if mode == "domain":
        return common + """
DOMAIN-AWARE condition: the context includes SG/GFM/GFL identity and physical
variable mapping. You may use pretrained synchronous-machine, inverter-control,
PLL, dq-frame, droop, voltage, and active/reactive-power knowledge only as an
EXTERNAL SOFT prior. Do not prescribe textbook equations and do not override
the observed elite evidence.
"""
    raise ValueError(f"Unsupported awareness mode: {mode}")


def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: llm_edsi_policy_adapter.py request.json response.json",
              file=sys.stderr)
        return 64

    request_path = Path(sys.argv[1]).resolve()
    response_path = Path(sys.argv[2]).resolve()
    start = time.perf_counter()

    try:
        req = load_json(request_path)
        mode = str(req["awareness_mode"]).lower()
        contexts = list(req["contexts"])
        if mode not in {"task", "domain"}:
            raise ValueError("awareness_mode must be task or domain")
        if not os.environ.get("OPENAI_API_KEY"):
            raise RuntimeError("OPENAI_API_KEY is not visible to Python.")

        cache_dir = Path(req["cache_dir"]).resolve()
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_mode = str(req.get("cache_mode", "record_or_replay")).lower()
        cache_file = cache_dir / f"{key_for(req)}.json"

        if cache_mode in {"replay", "record_or_replay"} and cache_file.exists():
            result = load_json(cache_file)
            result["cache_hit"] = True
            result["cloud_call_count"] = 0
            result["estimated_cost_usd"] = 0.0
            result["latency_seconds"] = time.perf_counter() - start
            save_json(response_path, result)
            print(
                f"LLM_EDSI_POLICY_CACHE_HIT g={req.get('generation')} "
                f"mode={mode} policies={len(result.get('policies', []))}"
            )
            return 0
        if cache_mode == "replay":
            raise RuntimeError(f"Replay requested but cache missing: {cache_file}")

        model = str(req.get("model", "gpt-6-luna"))
        effort = str(req.get("reasoning_effort", "low"))
        n_modules = max(int(c["module_id"]) for c in contexts)
        max_width = max(int(c["dictionary_width"]) for c in contexts)

        payload = {
            "task": "adaptive_soft_search_regularization",
            "generation": int(req["generation"]),
            "contexts": contexts,
            "rules": [
                "Use worst-to-best ranking as an in-context fitness signal.",
                "Prefer consistent high-value motifs for soft protection.",
                "Prefer weak/inconsistent slots for replacement.",
                "Prefer compact strong motifs as compositional parents.",
                "Do not output child structures or final equations.",
                "Return one policy for every module_id.",
            ],
        }

        client = OpenAI()
        resp = client.responses.create(
            model=model,
            reasoning={"effort": effort},
            input=[
                {"role": "system", "content": system_prompt(mode)},
                {"role": "user", "content": json.dumps(
                    payload, separators=(",", ":"), ensure_ascii=False)},
            ],
            text={
                "format": {
                    "type": "json_schema",
                    "name": "edsi_soft_search_policy",
                    "strict": True,
                    "schema": schema(n_modules, max_width),
                }
            },
            max_output_tokens=int(req.get("max_output_tokens", 2500)),
            store=bool(req.get("store", False)),
        )

        if getattr(resp, "status", None) == "incomplete":
            raise RuntimeError("GPT response was incomplete.")
        if not resp.output_text:
            raise RuntimeError("GPT response contained no output_text.")

        parsed = json.loads(resp.output_text)
        policies = parsed.get("policies", [])
        usage = usage_dict(resp)
        cost = cost_usd(usage, req.get("pricing_usd_per_million", {}))

        result = {
            "ok": True,
            "adapter_version": VERSION,
            "model": getattr(resp, "model", model),
            "response_id": getattr(resp, "id", ""),
            "generation": int(req["generation"]),
            "awareness_mode": mode,
            "policies": policies,
            "usage": usage,
            "estimated_cost_usd": cost,
            "latency_seconds": time.perf_counter() - start,
            "cloud_call_count": 1,
            "cache_hit": False,
        }

        if cache_mode in {"record", "record_or_replay"}:
            save_json(cache_file, result)
        save_json(response_path, result)

        print(
            f"LLM_EDSI_POLICY_OK g={req['generation']} mode={mode} "
            f"policies={len(policies)} tokens={usage['input_tokens']}+"
            f"{usage['output_tokens']} cost=${cost:.6f} "
            f"latency={result['latency_seconds']:.2f}s"
        )
        return 0

    except Exception as exc:
        result = {
            "ok": False,
            "adapter_version": VERSION,
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            "policies": [],
            "estimated_cost_usd": 0.0,
            "latency_seconds": time.perf_counter() - start,
            "cloud_call_count": 0,
            "cache_hit": False,
        }
        try:
            save_json(response_path, result)
        except Exception:
            pass
        print(f"LLM_EDSI_POLICY_ERROR {type(exc).__name__}: {exc}",
              file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
