#!/usr/bin/env python3
"""OpenAI cloud adapter for the LLM-EDSI smoke test.

The MATLAB caller writes a compact anonymized JSON request and invokes:
    python llm_edsi_openai_adapter.py request.json response.json

The adapter never receives raw trajectories or physical device labels.  It asks
GPT-6 Luna for legal *proposal descriptors* only; MATLAB independently validates
and numerically scores every proposal.
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any

from openai import OpenAI


def _read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)
    tmp.replace(path)


def _schema(width: int) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "proposals": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "replace_slot": {"type": "integer", "minimum": 1, "maximum": width},
                        "operator": {"type": "string", "enum": ["product", "sin", "cos"]},
                        "arg1": {"type": "integer", "minimum": 2, "maximum": width},
                        "arg2": {"type": "integer", "minimum": 0, "maximum": width},
                        "strategy": {
                            "type": "string",
                            "enum": [
                                "compose_high_utility",
                                "replace_low_utility",
                                "increase_compositional_depth",
                                "reuse_successful_pattern",
                                "diversify_search",
                            ],
                        },
                    },
                    "required": ["replace_slot", "operator", "arg1", "arg2", "strategy"],
                    "additionalProperties": False,
                },
            }
        },
        "required": ["proposals"],
        "additionalProperties": False,
    }


def _system_prompt() -> str:
    return (
        "You are a symbolic-search proposal component inside a numerical system-identification algorithm. "
        "You do NOT choose the final model and you do NOT estimate coefficients. "
        "Use only the anonymized symbolic expressions and numerical diagnostics supplied by the caller. "
        "Do not infer or introduce domain-specific physics. Variables x1, x2, ... have no disclosed physical meaning. "
        "Return one-slot dictionary mutation proposals only. Allowed operators are product, sin, and cos. "
        "For product use arg1 and arg2; for sin/cos set arg2=0. "
        "Never use slot 1 (constant) as an expression parent. Never replace a protected slot. "
        "Prefer proposals that combine structurally useful expressions while maintaining diversity. "
        "The caller will independently reject duplicates, excessive depth/complexity, nonfinite features, and poor fitness. "
        "Return exactly the requested number of proposals when possible, with no prose outside the schema."
    )


def _usage_value(obj: Any, name: str, default: int = 0) -> int:
    if obj is None:
        return default
    val = getattr(obj, name, default)
    try:
        return int(val or 0)
    except Exception:
        return default


def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: llm_edsi_openai_adapter.py request.json response.json", file=sys.stderr)
        return 64

    request_path = Path(sys.argv[1]).resolve()
    response_path = Path(sys.argv[2]).resolve()

    t0 = time.perf_counter()
    try:
        req = _read_json(request_path)
        model = str(req.get("model", "gpt-6-luna"))
        width = int(req["dictionary_width"])
        reasoning_effort = str(req.get("reasoning_effort", "none"))
        max_output_tokens = int(req.get("max_output_tokens", 1200))
        store = bool(req.get("store", False))

        if not os.environ.get("OPENAI_API_KEY"):
            raise RuntimeError(
                "OPENAI_API_KEY is not visible to this Python process. "
                "Restart MATLAB after setting the Windows environment variable."
            )

        client = OpenAI()
        user_payload = {
            "task": "propose_fixed_width_dictionary_mutations",
            "requested_proposals": int(req["requested_proposals"]),
            "generation": int(req["generation"]),
            "dictionary_width": width,
            "protected_slots": req["protected_slots"],
            "allowed_operators": ["product", "sin", "cos"],
            "max_depth": int(req["max_depth"]),
            "max_complexity": int(req["max_complexity"]),
            "current_validation_fitness": float(req["current_validation_fitness"]),
            "recent_global_fitness": req.get("recent_global_fitness", []),
            "dictionary": req["dictionary"],
            "previous_llm_feedback": req.get("previous_llm_feedback", []),
            "rules": [
                "replace_slot must not be protected",
                "arg1 and arg2 refer to current dictionary slot indices",
                "for sin/cos arg2 must be 0",
                "for product arg2 must be >= 2",
                "avoid producing an expression already present in the current dictionary",
                "use numerical importance only as evidence, not as a hard rule",
            ],
        }

        response = client.responses.create(
            model=model,
            reasoning={"effort": reasoning_effort},
            input=[
                {"role": "system", "content": _system_prompt()},
                {
                    "role": "user",
                    "content": json.dumps(user_payload, separators=(",", ":"), ensure_ascii=False),
                },
            ],
            text={
                "format": {
                    "type": "json_schema",
                    "name": "edsi_mutation_proposals",
                    "strict": True,
                    "schema": _schema(width),
                }
            },
            max_output_tokens=max_output_tokens,
            store=store,
        )

        if getattr(response, "status", None) == "incomplete":
            details = getattr(response, "incomplete_details", None)
            reason = getattr(details, "reason", "unknown") if details else "unknown"
            raise RuntimeError(f"OpenAI response incomplete: {reason}")

        output_text = response.output_text
        if not output_text:
            raise RuntimeError("OpenAI response contained no output_text.")

        parsed = json.loads(output_text)
        proposals = parsed.get("proposals", [])

        usage = getattr(response, "usage", None)
        input_tokens = _usage_value(usage, "input_tokens")
        output_tokens = _usage_value(usage, "output_tokens")
        total_tokens = _usage_value(usage, "total_tokens", input_tokens + output_tokens)
        input_details = getattr(usage, "input_tokens_details", None) if usage else None
        cached_tokens = _usage_value(input_details, "cached_tokens")
        cache_write_tokens = _usage_value(input_details, "cache_write_tokens")
        uncached_tokens = max(input_tokens - cached_tokens - cache_write_tokens, 0)

        pricing = req.get("pricing_usd_per_million", {})
        p_input = float(pricing.get("input", 0.10))
        p_cached = float(pricing.get("cached_input", 0.01))
        p_cache_write = float(pricing.get("cache_write", 0.125))
        p_output = float(pricing.get("output", 0.50))
        estimated_cost = (
            uncached_tokens * p_input
            + cached_tokens * p_cached
            + cache_write_tokens * p_cache_write
            + output_tokens * p_output
        ) / 1_000_000.0

        result = {
            "ok": True,
            "model": getattr(response, "model", model),
            "response_id": getattr(response, "id", ""),
            "status": getattr(response, "status", "completed"),
            "latency_seconds": time.perf_counter() - t0,
            "requested_proposals": int(req["requested_proposals"]),
            "returned_proposals": len(proposals),
            "proposals": proposals,
            "usage": {
                "input_tokens": input_tokens,
                "cached_input_tokens": cached_tokens,
                "cache_write_tokens": cache_write_tokens,
                "output_tokens": output_tokens,
                "total_tokens": total_tokens,
            },
            "estimated_cost_usd": estimated_cost,
        }
        _write_json(response_path, result)
        print(
            f"LLM_EDSI_OK model={result['model']} proposals={len(proposals)} "
            f"tokens={input_tokens}+{output_tokens} cost=${estimated_cost:.6f} "
            f"latency={result['latency_seconds']:.3f}s"
        )
        return 0

    except Exception as exc:  # the MATLAB caller decides whether to abort or fall back
        result = {
            "ok": False,
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            "latency_seconds": time.perf_counter() - t0,
            "proposals": [],
        }
        try:
            _write_json(response_path, result)
        except Exception:
            pass
        print(f"LLM_EDSI_ERROR {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
