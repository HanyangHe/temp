#!/usr/bin/env python3
"""Direct knowledge-informed elite-dictionary refinement for EDSI.

The LLM receives complete current elite dictionaries plus physical ODE/SINDy
context and returns exact 1--2 edit plans.  It does NOT return mutation
probabilities or a surrogate fitness. MATLAB applies the edits and numerical
pointwise ridge validation remains authoritative.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

from openai import OpenAI

VERSION = "llm_edsi_elite_refine_fllm_v1_20261004"


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def save_json(path: Path, obj: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
    tmp.replace(path)


def num_attr(obj: Any, name: str, default: int = 0) -> int:
    try:
        return int(getattr(obj, name, default) or 0)
    except Exception:
        return default


def usage_dict(resp: Any) -> dict[str, int]:
    u = getattr(resp, "usage", None)
    inp = num_attr(u, "input_tokens")
    out = num_attr(u, "output_tokens")
    det = getattr(u, "input_tokens_details", None) if u else None
    return {
        "input_tokens": inp,
        "output_tokens": out,
        "total_tokens": num_attr(u, "total_tokens", inp + out),
        "cached_input_tokens": num_attr(det, "cached_tokens"),
        "cache_write_tokens": num_attr(det, "cache_write_tokens"),
    }


def estimate_cost(usage: dict[str, int], pricing: dict[str, Any]) -> float:
    inp = int(usage.get("input_tokens", 0))
    cached = int(usage.get("cached_input_tokens", 0))
    written = int(usage.get("cache_write_tokens", 0))
    uncached = max(inp - cached - written, 0)
    out = int(usage.get("output_tokens", 0))
    return (
        uncached * float(pricing.get("input", 0.10))
        + cached * float(pricing.get("cached_input", 0.01))
        + written * float(pricing.get("cache_write", 0.0))
        + out * float(pricing.get("output", 0.50))
    ) / 1_000_000.0


def cache_key(req: dict[str, Any]) -> str:
    q = dict(req)
    q.pop("cache_dir", None)
    q.pop("pricing_usd_per_million", None)
    q["adapter_version"] = VERSION
    raw = json.dumps(q, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def output_schema(n_candidates: int, width: int) -> dict[str, Any]:
    edit = {
        "type": "object",
        "properties": {
            "slot": {"type": "integer", "minimum": 1, "maximum": width},
            "operator": {
                "type": "string",
                "enum": ["product", "sin", "cos"],
            },
            "parent_a": {"type": "integer", "minimum": 2, "maximum": width},
            "parent_b": {"type": "integer", "minimum": 0, "maximum": width},
        },
        "required": ["slot", "operator", "parent_a", "parent_b"],
        "additionalProperties": False,
    }

    refinement = {
        "type": "object",
        "properties": {
            "candidate_id": {
                "type": "integer",
                "minimum": 1,
                "maximum": n_candidates,
            },
            "edits": {
                "type": "array",
                "items": edit,
                "minItems": 1,
                "maxItems": 2,
            },
            "intent": {
                "type": "string",
                "maxLength": 220,
            },
        },
        "required": ["candidate_id", "edits", "intent"],
        "additionalProperties": False,
    }

    return {
        "type": "object",
        "properties": {
            "refinements": {
                "type": "array",
                "items": refinement,
                "minItems": n_candidates,
                "maxItems": n_candidates,
            }
        },
        "required": ["refinements"],
        "additionalProperties": False,
    }


SYSTEM_PROMPT = r"""
You are f_LLM, a pretrained knowledge-informed symbolic-dictionary refinement
operator embedded intermittently inside an evolutionary SINDy identifier.

FIRST-PRINCIPLES ROLE
---------------------
Your input is a set of already-selected high-quality candidate dictionaries.
They are initial structural hypotheses produced by numerical evolution, not
blank dictionaries.

Your objective is to use your pretrained knowledge of:
  1. the specified physical dynamical system and its likely ODE structure, and
  2. SINDy / sparse symbolic vector-field modeling,

to make a SMALL, KNOWLEDGE-INFORMED adjustment to EACH supplied candidate
dictionary so that the refined dictionary has a plausible chance to represent
the target ODE more accurately.

You are not asked to choose coefficients, predict the numerical fitness, or
replace the numerical evolutionary algorithm. MATLAB will re-fit all
coefficients by closed-form ridge regression and will accept/reject your child
only through the same held-out pointwise vector-field objective used by EDSI.

In short:

    you propose a structural refinement;
    the data-driven numerical fitness decides.

WHAT YOU SEE
------------
For the current SG/GFM/GFL ODE module you receive:
  * the physical system description;
  * x_i -> physical input-variable mapping;
  * target derivative names;
  * four current elite dictionaries ranked best to fourth-best;
  * each complete dictionary;
  * per-term coefficient importance;
  * current pointwise validation error.

OUTPUT
------
For each candidate, return exactly 1 or 2 local dictionary edits.

Each edit replaces ONE evolvable dictionary slot by exactly one legal
expression:
  product(parent_a, parent_b)
  sin(parent_a)
  cos(parent_a)

parent_a/parent_b are references to CURRENT dictionary slots. Edits are applied
sequentially, so the second edit may refer to the result of the first edit.

This output format is only a grammar-safe encoding of the refined dictionary.
It is NOT a mutation-probability policy.

CONSTRAINTS
-----------
Respect the provided protected slots, fixed dictionary width, maximum depth,
and maximum expression complexity. Preserve [1,x] anchors. Do not rewrite a
candidate from scratch. Prefer a minimal physically meaningful refinement over
arbitrary complexity.

Use your system knowledge actively. For example, reason about plausible
couplings among dynamic states, voltage/current variables, active/reactive
power quantities, dq-frame variables, droop/controller states, PLL states, or
generator states when those semantics are actually present in the supplied
variable map. Do not invent variables that are not supplied.

Do not output prose outside the requested structured result.
""".strip()


def main() -> int:
    if len(sys.argv) != 3:
        print(
            "Usage: llm_edsi_elite_refine_adapter.py request.json response.json",
            file=sys.stderr,
        )
        return 64

    request_path = Path(sys.argv[1]).resolve()
    response_path = Path(sys.argv[2]).resolve()
    t0 = time.perf_counter()

    try:
        req = load_json(request_path)

        if not os.environ.get("OPENAI_API_KEY"):
            raise RuntimeError("OPENAI_API_KEY is not visible to Python.")

        candidates = list(req["candidates"])
        constraints = dict(req["constraints"])
        n_candidates = len(candidates)
        width = int(constraints["fixed_dictionary_width"])

        cache_dir = Path(req["cache_dir"]).resolve()
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_mode = str(req.get("cache_mode", "record_or_replay")).lower()
        cfile = cache_dir / f"{cache_key(req)}.json"

        if cache_mode in {"replay", "record_or_replay"} and cfile.exists():
            result = load_json(cfile)
            result["cache_hit"] = True
            result["cloud_call_count"] = 0
            result["estimated_cost_usd"] = 0.0
            result["latency_seconds"] = time.perf_counter() - t0
            save_json(response_path, result)
            print(
                f"LLM_ELITE_REFINE_CACHE_HIT g={req.get('generation')} "
                f"n={len(result.get('refinements', []))}"
            )
            return 0

        if cache_mode == "replay":
            raise RuntimeError(f"Replay requested but cache is missing: {cfile}")

        user_payload = {
            "objective": (
                "Starting from each current elite dictionary, make a minimal "
                "knowledge-informed refinement that may better represent the "
                "specified physical-system ODE with SINDy."
            ),
            "generation": int(req["generation"]),
            "device": req["device"],
            "constraints": constraints,
            "candidate_elite_dictionaries": candidates,
            "selection_rule": (
                "Your proposal will be re-fit by ridge regression and judged "
                "only by held-out pointwise vector-field error. The parent "
                "elite remains preserved by elitism."
            ),
        }

        model = str(req.get("model", "gpt-6-luna"))
        effort = str(req.get("reasoning_effort", "low"))

        client = OpenAI()
        resp = client.responses.create(
            model=model,
            reasoning={"effort": effort},
            input=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": json.dumps(
                        user_payload,
                        separators=(",", ":"),
                        ensure_ascii=False,
                    ),
                },
            ],
            text={
                "format": {
                    "type": "json_schema",
                    "name": "edsi_elite_dictionary_refinement",
                    "strict": True,
                    "schema": output_schema(n_candidates, width),
                }
            },
            max_output_tokens=int(req.get("max_output_tokens", 2600)),
            store=bool(req.get("store", False)),
        )

        if getattr(resp, "status", None) == "incomplete":
            raise RuntimeError("GPT response was incomplete.")
        if not resp.output_text:
            raise RuntimeError("GPT response contained no output_text.")

        parsed = json.loads(resp.output_text)
        refinements = list(parsed.get("refinements", []))

        # Deterministic candidate-id audit before MATLAB sees the result.
        ids = sorted(int(x["candidate_id"]) for x in refinements)
        expected = list(range(1, n_candidates + 1))
        if ids != expected:
            raise RuntimeError(
                f"Returned candidate ids {ids} do not match expected {expected}."
            )

        usage = usage_dict(resp)
        cost = estimate_cost(
            usage, req.get("pricing_usd_per_million", {})
        )

        result = {
            "ok": True,
            "adapter_version": VERSION,
            "model": getattr(resp, "model", model),
            "response_id": getattr(resp, "id", ""),
            "generation": int(req["generation"]),
            "refinements": refinements,
            "usage": usage,
            "estimated_cost_usd": cost,
            "latency_seconds": time.perf_counter() - t0,
            "cloud_call_count": 1,
            "cache_hit": False,
        }

        if cache_mode in {"record", "record_or_replay"}:
            save_json(cfile, result)
        save_json(response_path, result)

        print(
            f"LLM_ELITE_REFINE_OK g={req['generation']} "
            f"n={len(refinements)} "
            f"tokens={usage['input_tokens']}+{usage['output_tokens']} "
            f"cost=${cost:.6f} "
            f"latency={result['latency_seconds']:.2f}s"
        )
        return 0

    except Exception as exc:
        result = {
            "ok": False,
            "adapter_version": VERSION,
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            "refinements": [],
            "estimated_cost_usd": 0.0,
            "latency_seconds": time.perf_counter() - t0,
            "cloud_call_count": 0,
            "cache_hit": False,
        }
        try:
            save_json(response_path, result)
        except Exception:
            pass
        print(
            f"LLM_ELITE_REFINE_ERROR {type(exc).__name__}: {exc}",
            file=sys.stderr,
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
