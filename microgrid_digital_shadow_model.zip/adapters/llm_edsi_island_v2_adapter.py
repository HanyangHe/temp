#!/usr/bin/env python3
"""Batched GPT-6 Luna variation operator for Island EDSI v2.

The request contains all module/island contexts for ONE evolutionary
generation.  Each island exposes its current candidate dictionaries ranked
from worst to best, following the core in-context variation idea used by
LLM-ODE.

GPT-6 Luna returns multi-slot edit plans. MATLAB remains authoritative:
it checks legality, computes the fixed-rho ridge fit, applies island
selection/mixing, and performs final full coupled DAE validation.
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

from openai import OpenAI

ADAPTER_VERSION = "llm_edsi_island_v2_20261003"


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: Path, obj: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
    tmp.replace(path)


def usage_value(obj: Any, name: str, default: int = 0) -> int:
    try:
        return int(getattr(obj, name, default) or 0)
    except Exception:
        return default


def usage_dict(response: Any) -> dict[str, int]:
    u = getattr(response, "usage", None)
    inp = usage_value(u, "input_tokens")
    out = usage_value(u, "output_tokens")
    total = usage_value(u, "total_tokens", inp + out)
    d = getattr(u, "input_tokens_details", None) if u else None
    return {
        "input_tokens": inp,
        "output_tokens": out,
        "total_tokens": total,
        "cached_input_tokens": usage_value(d, "cached_tokens"),
        "cache_write_tokens": usage_value(d, "cache_write_tokens"),
    }


def estimate_cost(usage: dict[str, int], pricing: dict[str, Any]) -> float:
    inp = int(usage.get("input_tokens", 0))
    cached = int(usage.get("cached_input_tokens", 0))
    write = int(usage.get("cache_write_tokens", 0))
    uncached = max(inp - cached - write, 0)
    out = int(usage.get("output_tokens", 0))
    return (
        uncached * float(pricing.get("input", 0.10))
        + cached * float(pricing.get("cached_input", 0.01))
        + write * float(pricing.get("cache_write", 0.0))
        + out * float(pricing.get("output", 0.50))
    ) / 1_000_000.0


def request_hash(req: dict[str, Any]) -> str:
    relevant = dict(req)
    relevant.pop("cache_dir", None)
    relevant.pop("pricing_usd_per_million", None)
    relevant["adapter_version"] = ADAPTER_VERSION
    raw = json.dumps(relevant, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def schema(max_module_id: int, n_islands: int, width_max: int,
           edit_min: int, edit_max: int) -> dict[str, Any]:
    edit = {
        "type": "object",
        "properties": {
            "replace_slot": {"type": "integer", "minimum": 1, "maximum": width_max},
            "operator": {"type": "string", "enum": ["product", "sin", "cos"]},
            "arg1": {"type": "integer", "minimum": 2, "maximum": width_max},
            "arg2": {"type": "integer", "minimum": 0, "maximum": width_max},
        },
        "required": ["replace_slot", "operator", "arg1", "arg2"],
        "additionalProperties": False,
    }
    child = {
        "type": "object",
        "properties": {
            "module_id": {"type": "integer", "minimum": 1, "maximum": max_module_id},
            "island_id": {"type": "integer", "minimum": 1, "maximum": n_islands},
            "parent_rank": {"type": "integer", "minimum": 1, "maximum": 8},
            "edits": {
                "type": "array",
                "items": edit,
                "minItems": edit_min,
                "maxItems": edit_max,
            },
            "strategy": {
                "type": "string",
                "enum": [
                    "imitate_better_ranked_patterns",
                    "combine_complementary_motifs",
                    "remove_weak_replace_with_composition",
                    "increase_compositional_depth",
                    "diversify_island",
                    "domain_prior_transfer",
                ],
            },
        },
        "required": ["module_id", "island_id", "parent_rank", "edits", "strategy"],
        "additionalProperties": False,
    }
    return {
        "type": "object",
        "properties": {
            "children": {"type": "array", "items": child}
        },
        "required": ["children"],
        "additionalProperties": False,
    }


def system_prompt(mode: str, children_per_island: int) -> str:
    shared = f"""
You are the structural variation operator inside a SINDy-like evolutionary
system-identification algorithm.

For each island you are given CURRENT candidate dictionaries ranked from
WORST to BEST by held-out pointwise vector-field validation error. Infer which
symbolic motifs distinguish the better-ranked candidates and propose exactly
{children_per_island} new child dictionaries per island.

A child is represented as 2-4 simultaneous slot replacements applied to one
ranked parent dictionary. parent_rank=1 means the WORST candidate and
parent_rank=8 means the BEST candidate. Prefer parents in the better half
unless a poorer candidate contains a complementary useful motif.

Dictionary width is fixed. Protected [1,x] slots cannot be replaced.
The only allowed new-expression operators are:
  product(arg1,arg2), sin(arg1), cos(arg1).
For sin/cos set arg2=0.
All arg indices refer to slots in the chosen PARENT dictionary before edits.
Do not repeat a replace_slot within one child.

The numerical program, not you, decides fitness. Coefficients are solved
externally by fixed-rho ridge regression. Generate structurally diverse
children of varying complexity; do not merely repeat the best candidate.
""".strip()

    if mode == "task":
        return shared + """
This is the TASK-AWARE / DOMAIN-BLIND condition. You know this is sparse
vector-field identification, but x1,x2,... deliberately have no disclosed
physical meaning. Do not infer a microgrid, generator, inverter, or other
application domain. Use only ranked symbolic patterns, fitness, importance,
depth, complexity, and island diversity.
"""
    if mode == "domain":
        return shared + """
This is the DOMAIN-AWARE condition. Each context includes physical variable
semantics and component identity. You may use pretrained power-system,
synchronous-machine, PLL, dq-frame, droop, voltage, and active/reactive-power
knowledge as an external structural prior. Do not assume textbook equations
are exact: the ranked observed search evidence and subsequent numerical
validation remain authoritative.
"""
    raise ValueError(f"Unknown awareness mode: {mode}")


def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: llm_edsi_island_v2_adapter.py request.json response.json",
              file=sys.stderr)
        return 64

    req_path = Path(sys.argv[1]).resolve()
    out_path = Path(sys.argv[2]).resolve()
    t0 = time.perf_counter()

    try:
        req = read_json(req_path)
        mode = str(req["awareness_mode"]).lower()
        contexts = list(req["contexts"])
        if mode not in {"task", "domain"}:
            raise ValueError("awareness_mode must be task or domain")
        if not os.environ.get("OPENAI_API_KEY"):
            raise RuntimeError("OPENAI_API_KEY is not visible to Python.")

        model = str(req.get("model", "gpt-6-luna"))
        effort = str(req.get("reasoning_effort", "none"))
        max_tokens = int(req.get("max_output_tokens", 8000))
        store = bool(req.get("store", False))
        children_per_island = int(req["children_per_island"])
        edit_min = int(req["multi_edit_min"])
        edit_max = int(req["multi_edit_max"])
        cache_mode = str(req.get("cache_mode", "record_or_replay")).lower()
        cache_dir = Path(req["cache_dir"]).resolve()
        cache_dir.mkdir(parents=True, exist_ok=True)

        key = request_hash(req)
        cache_file = cache_dir / f"{key}.json"
        if cache_mode in {"replay", "record_or_replay"} and cache_file.exists():
            cached = read_json(cache_file)
            result = dict(cached)
            result["cache_hit"] = True
            result["cloud_call_count"] = 0
            result["estimated_cost_usd"] = 0.0
            result["latency_seconds"] = time.perf_counter() - t0
            write_json(out_path, result)
            print(f"LLM_EDSI_ISLAND_CACHE_HIT gen={req.get('generation')} "
                  f"children={len(result.get('children', []))}")
            return 0
        if cache_mode == "replay":
            raise RuntimeError(f"Replay requested but no cache exists: {cache_file}")

        max_module = max(int(c["module_id"]) for c in contexts)
        n_islands = max(int(c["island_id"]) for c in contexts)
        width_max = max(int(c["dictionary_width"]) for c in contexts)

        payload = {
            "task": "ranked_in_context_dictionary_variation",
            "generation": int(req["generation"]),
            "children_per_island": children_per_island,
            "multi_edit_min": edit_min,
            "multi_edit_max": edit_max,
            "max_depth": int(req["max_depth"]),
            "max_complexity": int(req["max_complexity"]),
            "allowed_operators": req["allowed_operators"],
            "contexts": contexts,
            "instructions": [
                "Each context is one evolutionary island.",
                "Candidates are sorted worst-to-best; use this ordering as an in-context fitness signal.",
                "Return the requested number of diverse child edit plans for every island.",
                "Do not output coefficients or final model decisions.",
            ],
        }

        client = OpenAI()
        response = client.responses.create(
            model=model,
            reasoning={"effort": effort},
            input=[
                {"role": "system",
                 "content": system_prompt(mode, children_per_island)},
                {"role": "user",
                 "content": json.dumps(payload, separators=(",", ":"),
                                       ensure_ascii=False)},
            ],
            text={
                "format": {
                    "type": "json_schema",
                    "name": "llm_edsi_island_children",
                    "strict": True,
                    "schema": schema(max_module, n_islands, width_max,
                                     edit_min, edit_max),
                }
            },
            max_output_tokens=max_tokens,
            store=store,
        )

        if getattr(response, "status", None) == "incomplete":
            raise RuntimeError("GPT response was incomplete.")
        if not response.output_text:
            raise RuntimeError("GPT response had no output_text.")

        parsed = json.loads(response.output_text)
        children = parsed.get("children", [])
        usage = usage_dict(response)
        cost = estimate_cost(usage, req.get("pricing_usd_per_million", {}))

        result = {
            "ok": True,
            "adapter_version": ADAPTER_VERSION,
            "model": getattr(response, "model", model),
            "response_id": getattr(response, "id", ""),
            "generation": int(req["generation"]),
            "awareness_mode": mode,
            "children": children,
            "returned_children": len(children),
            "usage": usage,
            "estimated_cost_usd": cost,
            "latency_seconds": time.perf_counter() - t0,
            "cloud_call_count": 1,
            "cache_hit": False,
        }
        if cache_mode in {"record", "record_or_replay"}:
            write_json(cache_file, result)
        write_json(out_path, result)

        print(
            f"LLM_EDSI_ISLAND_OK gen={req['generation']} mode={mode} "
            f"children={len(children)} tokens={usage['input_tokens']}+"
            f"{usage['output_tokens']} cost=${cost:.6f} "
            f"latency={result['latency_seconds']:.2f}s"
        )
        return 0

    except Exception as exc:
        result = {
            "ok": False,
            "adapter_version": ADAPTER_VERSION,
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            "children": [],
            "estimated_cost_usd": 0.0,
            "latency_seconds": time.perf_counter() - t0,
            "cloud_call_count": 0,
            "cache_hit": False,
        }
        try:
            write_json(out_path, result)
        except Exception:
            pass
        print(f"LLM_EDSI_ISLAND_ERROR {type(exc).__name__}: {exc}",
              file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
