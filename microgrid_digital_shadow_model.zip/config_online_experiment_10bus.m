function cfg = config_online_experiment_10bus()
%CONFIG_ONLINE_EXPERIMENT_10BUS Formal online digital-shadow experiment settings.
%
% The online study starts from saved Offline Part-1 models. Every baseline
% has independent frozen/online deployment switches. The default comparison
% is PNC-SINDy under a four-variant online attribution study.
%
% Online correction uses a method-specific fast path. For PNC-SINDy:
%   module-wise vector-field mismatch localization
%     -> update only the affected DER module
%     -> freeze the offline PE-SINDy first layer Xi_1
%     -> freeze the flat-PN and compositional fixed feature generators
%     -> causally reselect/refit only the second-layer sparse readout Xi_2
%     -> causal post-training candidate validation
%     -> state synchronization and local-model replacement after validation.

cfg=config_offline_experiment_10bus();
cfg.name='online_model_experiment_10bus';

%% Saved offline initial-model condition
cfg.online.offlineOutputFolder='offline_model_experiments_10bus';
cfg.online.initialModelSampleCount=500;
cfg.online.initialModelSeed=20260814; % first prespecified official offline sampling seed
cfg.online.initialModelNoiseLevel=0.001; % 0.1% offline xdot-label noise
cfg.online.observationNoiseLevel=0.001;  % 0.1% online xdot observation noise
cfg.online.observationNoiseSeed=20260815;

%% Online baseline controls
% Every baseline retains both switches. The fast module-local online updater
% currently applies to the SINDy family. NODE and M-KBF can still be enabled
% in frozen mode; their online switches are kept OFF until a family-specific
% fast updater is explicitly implemented.
cfg.online.methods.neuralODE.frozen=false;
cfg.online.methods.neuralODE.online=false;

cfg.online.methods.modularKoopman.frozen=false;
cfg.online.methods.modularKoopman.online=false;

cfg.online.methods.vanillaSINDy.frozen=false;
cfg.online.methods.vanillaSINDy.online=false;

cfg.online.methods.physicsEmbeddedSINDy.frozen=false;
cfg.online.methods.physicsEmbeddedSINDy.online=false;


cfg.online.methods.neuralSINDy.frozen=false; % legacy N-SINDy disabled
cfg.online.methods.neuralSINDy.online=false;

cfg.online.methods.physicsNeuralCompositionalSINDy.frozen=true;
cfg.online.methods.physicsNeuralCompositionalSINDy.online=true;

% Former flat PN-SINDy is retained only as an offline structure ablation.
cfg.online.methods.physicsNeuralSINDy.frozen=false;
cfg.online.methods.physicsNeuralSINDy.online=false;

%% Stage-3 online attribution ablation
% Two factors are separated explicitly:
%   coefficient adaptation: OFF / ON
%   state synchronization:  OFF / ON
% This yields four controlled deployment variants evaluated on the SAME truth,
% observation stream, detector/update history, and accepted activation times:
%   frozen_no_sync  : frozen coefficients, continuous model state
%   frozen_sync     : frozen coefficients, measured-state synchronization only
%   adapted_no_sync : updated coefficients, continuous model state
%   adapted_sync    : updated coefficients + measured-state synchronization
% The full digital-shadow deployment is adapted_sync.  frozen_sync uses the
% accepted activation times from the adaptive run, so synchronization is not
% given an unrealistically earlier trigger.
cfg.online.ablation.enabled=true;
cfg.online.ablation.variants={ ...
    'frozen_no_sync', ...
    'frozen_sync', ...
    'adapted_no_sync', ...
    'adapted_sync'};
cfg.online.ablation.primaryVariant='adapted_sync';
cfg.online.ablation.commonActivationSchedule='accepted_adaptive_activation_times';


%% Hidden true-system parameter mismatch
% The test system follows a hidden piecewise-constant nq mismatch.
% The first bias is active from t=0 and a second bias is introduced at 6 s,
% allowing the re-armed online updater to demonstrate repeated adaptation.
cfg.online.parameterMismatch.enabled=true;
cfg.online.parameterMismatch.deviceType='gfm';
cfg.online.parameterMismatch.device=1;
cfg.online.parameterMismatch.parameter='nq';
cfg.online.parameterMismatch.component='all';
% Piecewise constant additive bias for manuscript-oriented online test:
%   t in [0,6):  nq = nq_nominal + 0.10
%   t in [6,12]: nq = nq_nominal - 0.10
cfg.online.parameterMismatch.profile='piecewise_constant';
cfg.online.parameterMismatch.mode='additive';
cfg.online.parameterMismatch.times=[0.0,6.0];
cfg.online.parameterMismatch.values=[0.10,-0.10];
cfg.online.parameterMismatch.value=cfg.online.parameterMismatch.values;

%% Online mismatch detector
cfg.online.update.enabled=true;
cfg.online.update.strategy='method_specific_fast_update';
% Monitoring attempts and successful deployments are counted separately.
% Rejected candidates do not stop monitoring; the detector is re-armed.
cfg.online.update.maximumUpdateAttempts=10;
cfg.online.update.maximumAcceptedUpdates=4;
cfg.online.update.refractorySeconds=0.05;

% One score is maintained for every SG/GFM/GFL module. The first module that
% persistently crosses its own threshold is localized as the affected module.
cfg.online.update.detector.metric='module_rolling_vector_field_nrmse';
cfg.online.update.detector.windowSeconds=0.10;
cfg.online.update.detector.threshold=0.05;
cfg.online.update.detector.minimumTriggerTime=0.10;
cfg.online.update.detector.requiredConsecutiveWindows=3;
cfg.online.update.detector.scaleFloor=1e-10;

% Calibrate each module threshold against the saved nominal model on its
% original offline validation trajectories. This prevents a baseline's known
% nominal residual from being mistaken for newly developed model mismatch.
cfg.online.update.detector.calibrateFromOffline=true;
cfg.online.update.detector.baselineQuantile=0.995;
cfg.online.update.detector.baselineMultiplier=1.50;

%% Fast local coefficient adaptation
% Online observations are sampled on the existing 5-ms saved grid. Only data
% available at/before the trigger are used in the coefficient update.
cfg.online.update.sampleStep=0.005;
cfg.online.update.minimumOnlineSamples=100;
cfg.online.update.waitForMinimumSamples=true;
cfg.online.update.historyWindowSeconds=inf;

% Legacy pointwise-SINDy fast updater retained for optional V-/PE-/flat-PN
% online tests. It keeps the offline support fixed and applies weighted RLS.
% The default PNC-SINDy path below does NOT use this fixed-support policy.
cfg.online.update.localRLS.supportTolerance=0;
cfg.online.update.localRLS.offlineDataWeight=0.05;
% Give each causal online innovation moderately higher information weight than
% the unit-weight RLS default. This increases coefficient responsiveness to a
% genuine changed regime while candidate validation still guards deployment.
cfg.online.update.localRLS.onlineSampleWeight=0.5;
cfg.online.update.localRLS.priorPrecision=1e-6;
cfg.online.update.localRLS.covarianceJitter=1e-10;
cfg.online.update.localRLS.forgettingHalfLifeSeconds=1.0;

% PNC-SINDy v2 online update: Xi_1 and BOTH fixed neural banks are frozen.
% Only the second-layer sparse readout Xi_2 is re-identified from causal
% observations. Unlike the legacy fixed-support RLS path, the Xi_2 support
% may change so neural features that were inactive offline can activate
% after a physical-model mismatch. Every candidate remains a fixed-feature
% sparse linear regression; there is no backpropagation or joint retraining.
cfg.online.update.pncLayer2.supportReselection=true;
cfg.online.update.pncLayer2.includeOfflineModelCandidate=true;
cfg.online.update.pncLayer2.validationFraction=0.20;
cfg.online.update.pncLayer2.minimumValidationSamples=20;
cfg.online.update.pncLayer2.thresholdGrid=cfg.sindy.stlsq.thresholdGrid;
cfg.online.update.pncLayer2.maxIterations=10;
cfg.online.update.pncLayer2.preferSparseWithinRelativeValidationTolerance=0.01;
cfg.online.update.pncLayer2.validationAbsoluteTolerance=1e-12;
cfg.online.update.pncLayer2.offlineInformationWeight=0.05;
cfg.online.update.pncLayer2.onlineSampleWeight=0.5;
cfg.online.update.pncLayer2.priorPrecision=1e-6;
cfg.online.update.pncLayer2.covarianceJitter=1e-10;
cfg.online.update.pncLayer2.forgettingHalfLifeSeconds=1.0;
cfg.online.update.pncLayer2.preferOfflineCandidateWhenNearBest=true;

% Measured computation time is retained as a real deployment delay.
cfg.online.update.trainingDelayScale=1.0;
cfg.online.update.minimumTrainingDelaySeconds=0.0;

%% Causal candidate validation and deployment
% Once the local coefficient update finishes, the candidate is checked on a
% short NEW observation interval that arrives after training. It is deployed
% only when its local vector-field residual improves by the required amount.
cfg.online.update.validation.enabled=true;
cfg.online.update.validation.windowSeconds=0.20;
cfg.online.update.validation.minimumSamples=20;
cfg.online.update.validation.requiredRelativeImprovement=0.10;
cfg.online.update.validation.requiredAbsoluteImprovement=0.0;

% A practical digital shadow is synchronized to measured state when a new
% local model is activated. The updated rollout therefore restarts from the
% measured/reference DAE state at the activation time rather than propagating
% accumulated pre-update state error through the model switch.
cfg.online.update.stateSynchronizationAtActivation=true;

%% Stage-3 non-delay tracking metrics
% Tracking quality is evaluated only when the deployed digital shadow is not
% inside an accepted trigger-to-activation delay interval. The first delay
% after each hidden parameter change is anchored to the physical mismatch
% onset; later refinement delays start at their actual detector trigger.
% This separates adaptation latency from active-model tracking accuracy.
cfg.online.tracking.enabled=true;
cfg.online.tracking.definition='non_delay_after_hidden_mismatch';
cfg.online.tracking.keyVoltageBus=[]; % [] -> terminal bus of first perturbed DER

%% Output / figures
cfg.output.folderName='online_model_experiments_10bus';
cfg.figures.exportPDF=true;
cfg.figures.visible='on';
cfg.figures.showOnlineUpdateMarkers=true;
end
