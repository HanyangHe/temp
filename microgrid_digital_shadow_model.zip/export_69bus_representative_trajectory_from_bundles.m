function figPath = export_69bus_representative_trajectory_from_bundles(projectRoot,varargin)
%EXPORT_69BUS_REPRESENTATIVE_TRAJECTORY_FROM_BUNDLES
% Re-export the manuscript representative 69-bus N=500 figure as a
% whole-state rollout RMSE-vs-time plot on a logarithmic y-axis.
%
% This replaces the old multi-panel trajectory-detail composite.
% It reads only saved Stage-2 replay bundles. It does NOT rerun model
% rollout, truth simulation, or training.
%
% Output files:
%   <projectRoot>/outputs/offline_model_experiments_69bus/
%       representative_composite_69bus_N500.pdf
%       representative_composite_69bus_N500.fig

if nargin < 1 || isempty(projectRoot)
    projectRoot = fileparts(mfilename('fullpath'));
    if isempty(projectRoot), projectRoot = pwd; end
end

p = inputParser;
p.FunctionName = mfilename;
addParameter(p,'Seed',20260814,@(x)isnumeric(x) && isscalar(x) && isfinite(x));
addParameter(p,'Visible','off',@(x)ischar(x) || (isstring(x) && isscalar(x)));
parse(p,varargin{:});
opt = p.Results;
seed = round(double(opt.Seed));

caseRoot = fullfile(projectRoot,'outputs','offline_model_experiments_69bus');
seedRoot = fullfile(caseRoot,'seed_runs',sprintf('seed_%d',seed));
methodRoot = fullfile(seedRoot,'method_results');
if exist(methodRoot,'dir') ~= 7
    error('Stage-2 69-bus method-results folder not found:\n  %s',methodRoot);
end

methodNames = { ...
    'modular_koopman_kbf', ...
    'vanilla_sindy', ...
    'physics_embedded_sindy', ...
    'edsi', ...
    'neural_ode_modular', ...
    'llm_prior_sindy'};

evaluations = cell(0,1);
truth = [];
typicalN = 500;

for k = 1:numel(methodNames)
    methodName = methodNames{k};
    bundleFile = fullfile(methodRoot,methodName,'offline_part1_method_replay.mat');
    if exist(bundleFile,'file') ~= 2
        warning('Skipping %s because its replay bundle was not found:\n  %s', methodName,bundleFile);
        continue;
    end
    S = load_method_bundle_safe(bundleFile);
    if ~isfield(S,'methodBundle')
        warning('Skipping invalid replay bundle for %s:\n  %s', methodName,bundleFile);
        continue;
    end
    B = S.methodBundle;
    if isempty(truth) && isfield(B,'report') && isfield(B.report,'truth') && ~isempty(B.report.truth)
        truth = B.report.truth;
    end
    if isfield(B,'config') && isfield(B.config,'typicalSampleCount') && ~isempty(B.config.typicalSampleCount)
        typicalN = B.config.typicalSampleCount;
    end
    ev = extract_typical_clean_evaluation(B,typicalN);
    if isempty(ev)
        warning('Skipping %s: no clean Section 1.1 evaluation at N=%d was found.', methodName,typicalN);
        continue;
    end
    evaluations{end+1,1} = ev; %#ok<AGROW>
end

if isempty(truth)
    error(['No common truth trajectory was found in the saved Stage-2 bundles. ', ...
        'The exporter does not regenerate the truth trajectory.']);
end
if isempty(evaluations)
    error('No 69-bus Section 1.1 evaluations were loaded.');
end
if ~isfield(truth,'x') || isempty(truth.x) || ~isfield(truth,'t') || isempty(truth.t)
    error('Saved truth trajectory does not contain truth.x and truth.t.');
end

plotOrder = get_plot_order(evaluations);
curves = cell(0,1);
for ii = 1:numel(plotOrder)
    ev = evaluations{plotOrder(ii)};
    c = build_rmse_curve(ev,truth);
    if isempty(c)
        warning('Skipping method with missing/invalid dynamic-state prediction: %s', char(method_legend_abbrev(ev)));
        continue;
    end
    curves{end+1,1} = c; %#ok<AGROW>
end
if isempty(curves)
    error('No valid whole-state RMSE curves could be constructed.');
end

fig = figure('Name','','Color','w','Visible',char(string(opt.Visible)));
fig.Units = 'pixels';
pos = fig.Position; pos(3)=560; pos(4)=285; fig.Position = pos;
ax = axes(fig); hold(ax,'on'); box(ax,'on'); grid(ax,'on');

h = gobjects(0); labels = strings(0);
allY = [];
tFinal = truth.t(end);
for i = 1:numel(curves)
    c = curves{i};
    hc = semilogy(ax,c.t,c.rmse, ...
        'LineWidth',method_line_width_from_label(c.label), ...
        'LineStyle','-', ...
        'Color',method_color_from_label(c.label));
    h(end+1) = hc; %#ok<AGROW>
    labels(end+1) = string(c.label); %#ok<AGROW>
    allY = [allY; c.rmse(:)]; %#ok<AGROW>
    if c.stopTime < tFinal - 1e-9
        xline(ax,c.stopTime,'--', ...
            'Color',method_color_from_label(c.label), ...
            'LineWidth',0.9, ...
            'HandleVisibility','off');
    end
end

% Robust y limits on log scale
allY = allY(isfinite(allY) & allY > 0);
if isempty(allY)
    yMin = 1e-8; yMax = 1;
else
    yMin = 10^floor(log10(min(allY))*1.0);
    yMax = 10^ceil(log10(max(allY))*1.0);
    if yMin == yMax
        yMin = yMin/10; yMax = yMax*10;
    end
end
set(ax,'YScale','log');
xlim(ax,[truth.t(1) truth.t(end)]);
ylim(ax,[yMin yMax]);
xlabel(ax,'Time (s)');
ylabel(ax,'Whole-state rollout RMSE');

lgd = legend(ax,h,cellstr(labels), ...
    'Orientation','horizontal', ...
    'NumColumns',3, ...
    'Interpreter','none', ...
    'Box','on');
lgd.Location = 'northoutside';
lgd.FontSize = 8;
lgd.FontName = 'Times New Roman';

set(ax,'FontName','Times New Roman','FontSize',9,'LineWidth',0.75);
apply_times_new_roman_all_local(fig);

if exist(caseRoot,'dir') ~= 7, mkdir(caseRoot); end
baseName = sprintf('representative_composite_69bus_N%d',round(typicalN));
figPath = fullfile(caseRoot,[baseName '.pdf']);
figFile = fullfile(caseRoot,[baseName '.fig']);
savefig(fig,figFile);
exportgraphics(fig,figPath,'ContentType','vector');

% Save underlying curve data for traceability
curveFile = fullfile(caseRoot,[baseName '_rmse_curves.mat']);
save(curveFile,'curves','seed','typicalN');

fprintf('\n============================================================\n');
fprintf('69-bus representative RMSE replay finished.\n');
fprintf('Official sampling seed : %d\n',seed);
fprintf('Figure type            : whole-state rollout RMSE (log y-axis)\n');
fprintf('PDF: %s\n',figPath);
fprintf('FIG: %s\n',figFile);
fprintf('MAT: %s\n',curveFile);
fprintf('============================================================\n');
end

function c = build_rmse_curve(ev,truth)
c = [];
if ~isfield(ev,'prediction') || ~isstruct(ev.prediction), return; end
p = ev.prediction;
if ~isfield(p,'x') || isempty(p.x) || ~isfield(p,'t') || isempty(p.t), return; end
if size(p.x,1) ~= size(truth.x,1)
    return;
end
tPred = p.t(:);
if any(~isfinite(tPred)) || numel(tPred) < 2
    return;
end
xPred = p.x;
% Align truth to prediction time grid.
xTruth = interp1(truth.t(:),truth.x.',tPred,'linear','extrap').';
err = xPred - xTruth;
rmse = sqrt(mean(err.^2,1));
rmse = max(rmse(:),1e-16);
label = char(method_legend_abbrev(ev));
stopTime = tPred(end);
status = '';
if isfield(ev,'result') && isstruct(ev.result)
    if isfield(ev.result,'status') && ~isempty(ev.result.status)
        status = string(ev.result.status);
    end
elseif isfield(ev,'status') && ~isempty(ev.status)
    status = string(ev.status);
end
c = struct('label',label,'t',tPred,'rmse',rmse,'stopTime',stopTime,'status',status);
end

function order = get_plot_order(evaluations)
labels = cell(numel(evaluations),1);
for k = 1:numel(evaluations)
    labels{k} = char(method_legend_abbrev(evaluations{k}));
end
canonical = {'M-KBF','NODE','V-SINDy','PE-SINDy','ED-SINDy','LLM-Prior SINDy'};
order = [];
for i = 1:numel(canonical)
    idx = find(strcmpi(labels,canonical{i}),1,'first');
    if ~isempty(idx)
        order(end+1) = idx; %#ok<AGROW>
    end
end
for k = 1:numel(evaluations)
    if ~ismember(k,order)
        order(end+1) = k; %#ok<AGROW>
    end
end
end

function lw = method_line_width_from_label(label)
switch lower(strtrim(char(label)))
    case 'v-sindy'
        lw = 1.8;
    case 'pe-sindy'
        lw = 1.6;
    case 'ed-sindy'
        lw = 1.45;
    case 'llm-prior sindy'
        lw = 1.45;
    case 'm-kbf'
        lw = 1.25;
    case 'node'
        lw = 1.25;
    otherwise
        lw = 1.35;
end
end

function color = method_color_from_label(label)
switch lower(strtrim(char(label)))
    case 'm-kbf'
        color=[0.6350 0.0780 0.1840];
    case 'v-sindy'
        color=[0.0000 0.4470 0.7410];
    case 'pe-sindy'
        color=[0.8500 0.3250 0.0980];
    case 'ed-sindy'
        color=[0.4940 0.1840 0.5560];
    case 'node'
        color=[0.25 0.25 0.25];
    case 'llm-prior sindy'
        color=[0.4660 0.6740 0.1880];
    otherwise
        color=[0.35 0.35 0.35];
end
end

function S = load_method_bundle_safe(bundleFile)
try
    S = load(bundleFile,'methodBundle');
    return;
catch ME
    firstError = ME;
end

tmpDir = tempname; mkdir(tmpDir);
cleanupDir = onCleanup(@()cleanup_temp_dir(tmpDir));
tmpFile = fullfile(tmpDir,'bundle.mat');
[ok,~] = copyfile(bundleFile,tmpFile,'f');
if ~ok, rethrow(firstError); end
try
    S = load(tmpFile,'methodBundle');
catch
    rethrow(firstError);
end
clear cleanupDir; cleanup_temp_dir(tmpDir);
end

function cleanup_temp_dir(tmpDir)
if exist(tmpDir,'dir') == 7
    try, rmdir(tmpDir,'s'); catch, end
end
end

function ev = extract_typical_clean_evaluation(B,typicalN)
ev = [];
if ~isfield(B,'report') || ~isfield(B.report,'section1p1'), return; end
sec = B.report.section1p1;
if ~isfield(sec,'evaluations') || isempty(sec.evaluations), return; end
E = sec.evaluations;
if isfield(sec,'table') && istable(sec.table) && height(sec.table)==numel(E)
    T = sec.table; keep = true(height(T),1);
    if any(strcmp(T.Properties.VariableNames,'SampleCount'))
        keep = keep & round(double(T.SampleCount))==round(double(typicalN));
    end
    if any(strcmp(T.Properties.VariableNames,'NoiseLevel'))
        keep = keep & abs(double(T.NoiseLevel)) <= 1e-14;
    elseif any(strcmp(T.Properties.VariableNames,'NoisePercent'))
        keep = keep & abs(double(T.NoisePercent)) <= 1e-12;
    end
    idx = find(keep,1,'first');
    if ~isempty(idx) && ~isempty(E{idx}), ev = E{idx}; return; end
end
for i = 1:numel(E)
    if ~isempty(E{i}), ev = E{i}; return; end
end
end

function label = method_legend_abbrev(ev)
name = "";
if isfield(ev,'method') && isstruct(ev.method)
    if isfield(ev.method,'name') && ~isempty(ev.method.name)
        name = lower(string(ev.method.name));
    elseif isfield(ev.method,'displayName') && ~isempty(ev.method.displayName)
        name = lower(string(ev.method.displayName));
    end
end
switch char(name)
    case {'modular_koopman_kbf','m-kbf'}
        label = "M-KBF";
    case {'vanilla_sindy','vanilla sindy'}
        label = "V-SINDy";
    case {'physics_embedded_sindy','physics-embedded sindy'}
        label = "PE-SINDy";
    case {'edsi','ed-sindy'}
        label = "ED-SINDy";
    case {'neural_ode_modular','neural ode','node'}
        label = "NODE";
    case {'llm_prior_sindy','llm-prior sindy'}
        label = "LLM-Prior SINDy";
    otherwise
        if isfield(ev,'method') && isfield(ev.method,'displayName')
            label = string(ev.method.displayName);
        else
            label = "Method";
        end
end
end

function apply_times_new_roman_all_local(fig)
axesList=findall(fig,'Type','axes');
for j=1:numel(axesList)
    ax=axesList(j);
    title(ax,'');
    set(ax,'FontName','Times New Roman');
    try, ax.XLabel.FontName='Times New Roman'; catch, end
    try, ax.YLabel.FontName='Times New Roman'; catch, end
end
objs=findall(fig);
for j=1:numel(objs)
    try
        if isprop(objs(j),'FontName')
            objs(j).FontName='Times New Roman';
        end
    catch
    end
end
end
