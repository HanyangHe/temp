function replayInfo = replay_offline_multiseed_summary(projectRoot,sourceRoot)
%REPLAY_OFFLINE_MULTISEED_SUMMARY Rebuild canonical multi-seed summary.
%
% This is the authoritative replay path for 10-, 69-, and 123-bus offline
% campaigns. It rebuilds the aggregate tables/figures directly from the
% independently saved per-seed/per-method bundles and overwrites the
% canonical files under:
%   outputs/offline_model_experiments_<case>/multiseed_summary/
%
% In the same replay, the first official sampling seed is used only as the
% representative realization for the 12-s trajectory figure. Its saved
% Section-1.1 predictions are replayed without training/rollout and overwrite
% the original representative_composite_<case>_N500.{fig,pdf} in the case
% output root plus the ordinary Section-1.1 trajectory figures.
%
% No model training, dataset generation, truth solve, or rollout is executed.

if nargin < 1 || isempty(projectRoot)
    projectRoot = fileparts(mfilename('fullpath'));
    if isempty(projectRoot), projectRoot = pwd; end
end
if nargin < 2 || isempty(sourceRoot)
    sourceRoot = fullfile(projectRoot,'outputs','offline_model_experiments_10bus');
end
addpath(genpath(projectRoot));

[caseFcn,configFcn,caseTag,expectedRoot] = resolve_case_local(projectRoot,sourceRoot);
if ~strcmpi(char(string(sourceRoot)),expectedRoot)
    warning('replay_offline_multiseed_summary:SourceRootNormalized', ...
        ['The supplied sourceRoot does not exactly match the configured case root.\n', ...
         'Supplied: %s\nUsing:    %s'],char(string(sourceRoot)),expectedRoot);
end

cfg = configFcn();
methods = string(cfg.run.methodsToRun(:)).';
fprintf('\n============================================================\n');
fprintf('%s MULTI-SEED REPLAY FROM INDEPENDENT METHOD BUNDLES\n',upper(caseTag));
fprintf('Configured methods: %s\n',strjoin(cellstr(methods),', '));
fprintf('Mode: aggregate-only; NO training or rollout.\n');
fprintf('Canonical summary figures will be overwritten in place.\n');
fprintf('============================================================\n');

% 1) Rebuild and overwrite the canonical multi-seed tables/figures.
replayInfo = run_offline_model_experiments_multiseed( ...
    projectRoot,caseFcn,configFcn,true);

% 2) Restore the canonical representative 12-s rollout figure from the first
% official seed. This is not a new experiment: it reads the saved Section-1.1
% predictions and overwrites the original paper figure files.
trajectoryReplay = struct();
try
    seed = representative_seed_local(cfg);
    seedFolderName = 'seed_runs';
    if isfield(cfg,'multiseed') && isstruct(cfg.multiseed) && ...
            isfield(cfg.multiseed,'seedFolderName') && ...
            ~isempty(cfg.multiseed.seedFolderName)
        seedFolderName = char(string(cfg.multiseed.seedFolderName));
    end
    seedRoot = fullfile(expectedRoot,seedFolderName,sprintf('seed_%d',seed));

    methodsForTrajectory = available_representative_methods_local(seedRoot,methods);
    if isempty(methodsForTrajectory)
        warning('replay_offline_multiseed_summary:NoRepresentativeMethods', ...
            'No saved Section-1.1 method bundles were found for representative seed %d.',seed);
    else
        fprintf('\nRestoring representative 12-s rollout from saved seed %d...\n',seed);
        trajectoryReplay = replay_offline_model_experiment_results( ...
            projectRoot,seedRoot, ...
            'MethodsToDisplay',cellstr(methodsForTrajectory), ...
            'DisplayDetailedReport',false, ...
            'TrajectoryOnly',true, ...
            'CanonicalOutputRoot',expectedRoot);
    end
catch ME
    warning('replay_offline_multiseed_summary:RepresentativeTrajectoryReplay', ...
        ['Multi-seed tables/figures were rebuilt, but the representative ', ...
         '12-s trajectory replay failed:\n%s'],ME.message);
    trajectoryReplay = struct('failed',true,'message',ME.message);
end
replayInfo.representativeTrajectoryReplay = trajectoryReplay;

fprintf('\n%s multi-seed replay complete.\n',caseTag);
fprintf('Canonical multiseed output: %s\n',replayInfo.outputRoot);
fprintf('Canonical case output     : %s\n',expectedRoot);
end


function seed = representative_seed_local(cfg)
seed = 20260814;
if isfield(cfg,'randomSeeds') && ~isempty(cfg.randomSeeds)
    seed = round(double(cfg.randomSeeds(1)));
elseif isfield(cfg,'randomSeed') && ~isempty(cfg.randomSeed)
    seed = round(double(cfg.randomSeed));
end
end


function selected = available_representative_methods_local(seedRoot,requested)
% Keep the current manuscript order, but do not fail if one optional saved
% method (typically NODE during an unfinished overnight campaign) is absent.
selected = strings(0,1);
methodRoot = fullfile(seedRoot,'method_results');
if exist(methodRoot,'dir') ~= 7, return; end
for k = 1:numel(requested)
    f = fullfile(methodRoot,char(requested(k)),'offline_part1_method_replay.mat');
    if exist(f,'file') == 2
        selected(end+1,1) = requested(k); %#ok<AGROW>
    end
end
end


function [caseFcn,configFcn,tag,root] = resolve_case_local(projectRoot,sourceRoot)
[~,leaf] = fileparts(char(string(sourceRoot)));
switch lower(leaf)
    case 'offline_model_experiments_10bus'
        caseFcn = @case_grid_connected_10bus_true_physics;
        configFcn = @config_offline_experiment_10bus;
        tag = '10-bus';
    case 'offline_model_experiments_69bus'
        caseFcn = @case_grid_connected_69bus_true_physics;
        configFcn = @config_offline_experiment_69bus;
        tag = '69-bus';
    case 'offline_model_experiments_123bus'
        caseFcn = @case_grid_connected_123bus_true_physics;
        configFcn = @config_offline_experiment_123bus;
        tag = '123-bus';
    otherwise
        error('replay_offline_multiseed_summary:UnknownCaseRoot', ...
            ['Cannot infer the offline case from sourceRoot:\n  %s\n', ...
             'Expected a folder ending in offline_model_experiments_10bus, ', ...
             'offline_model_experiments_69bus, or offline_model_experiments_123bus.'], ...
             char(string(sourceRoot)));
end
cfg = configFcn();
root = fullfile(projectRoot,'outputs',cfg.output.folderName);
end
