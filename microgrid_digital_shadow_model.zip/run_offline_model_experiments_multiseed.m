function report = run_offline_model_experiments_multiseed(projectRoot,caseFcn,configFcn,aggregateOnly)
%RUN_OFFLINE_MODEL_EXPERIMENTS_MULTISEED Three-seed manuscript statistics.
%
% This wrapper varies cfg.randomSeed for scrambled Sobol data. The LLM
% discovery-seed policy is independent: explicit frozen bank for the 69-bus
% V4 campaign, independent per-data-seed banks elsewhere. Validation,
% neural-basis and noise seeds remain fixed.
%
% Per-seed outputs:
%   outputs/<base>/seed_runs/seed_<seed>/...
%
% Aggregate outputs:
%   outputs/<base>/multiseed_summary/
%       section1p1_multiseed_raw.csv
%       section1p1_multiseed_summary.csv
%       section1p2_multiseed_raw.csv
%       section1p2_multiseed_summary.csv
%       section1p3_multiseed_raw.csv
%       section1p3_multiseed_summary.csv
%       section1p2_sample_sensitivity_multiseed.{fig,pdf}
%       section1p3_noise_robustness_multiseed.{fig,pdf}
%       offline_multiseed_summary.mat
%
% Recovery / post-processing only:
%   report = run_offline_model_experiments_multiseed(projectRoot,caseFcn,configFcn,true);
% The fourth argument skips ALL training/rollout and rebuilds the aggregate
% mean/std files directly from existing per-seed method bundles.
%
% Aggregate only the methods explicitly listed in cfg.run.methodsToRun.
% Historical bundles for retired methods may remain on disk, but they are
% ignored by the final manuscript aggregation.

if nargin < 1 || isempty(projectRoot)
    projectRoot = fileparts(mfilename('fullpath'));
end
if nargin < 2 || isempty(caseFcn)
    caseFcn = @case_grid_connected_10bus_true_physics;
elseif ischar(caseFcn) || isstring(caseFcn)
    caseFcn = str2func(char(caseFcn));
end
if nargin < 3 || isempty(configFcn)
    configFcn = @config_offline_experiment_10bus;
elseif ischar(configFcn) || isstring(configFcn)
    configFcn = str2func(char(configFcn));
end
addpath(genpath(projectRoot));

if nargin < 4 || isempty(aggregateOnly)
    aggregateOnly = false;
end
aggregateOnly = logical(aggregateOnly);

baseCfg = configFcn();
if ~isfield(baseCfg,'randomSeeds') || numel(baseCfg.randomSeeds) < 2
    error('run_offline_model_experiments_multiseed:Seeds', ...
        'cfg.randomSeeds must contain at least two data-sampling seeds.');
end
seeds = round(double(baseCfg.randomSeeds(:).'));
if numel(unique(seeds)) ~= numel(seeds)
    error('run_offline_model_experiments_multiseed:DuplicateSeeds', ...
        'cfg.randomSeeds must contain unique values.');
end

% Saved-only baselines are a formal campaign contract: verify complete
% historical coverage before launching any new method. This guarantees that
% an MLX run cannot accidentally retrain M-KBF/V-SINDy or produce a final
% summary with a silently missing historical baseline.
if ~aggregateOnly && isfield(baseCfg,'run') && isstruct(baseCfg.run) && ...
        isfield(baseCfg.run,'savedOnlyMethods') && ...
        ~isempty(baseCfg.run.savedOnlyMethods)
    verify_saved_offline_method_coverage(projectRoot,baseCfg);
end

baseFolder = char(string(baseCfg.output.folderName));
seedFolderName = 'seed_runs';
keepSeedFigures = false;
if isfield(baseCfg,'multiseed') && isstruct(baseCfg.multiseed)
    if isfield(baseCfg.multiseed,'seedFolderName') && ~isempty(baseCfg.multiseed.seedFolderName)
        seedFolderName = char(string(baseCfg.multiseed.seedFolderName));
    end
    if isfield(baseCfg.multiseed,'keepSeedFigures')
        keepSeedFigures = logical(baseCfg.multiseed.keepSeedFigures);
    end
end

fprintf('\n============================================================\n');
fprintf('Offline Experiment Part 1 -- MULTI-SEED MANUSCRIPT MODE\n');
fprintf('Data-sampling seeds: [%s]\n',strtrim(sprintf('%d ',seeds)));
fprintf('Only the Sobol sampling realization changes across seeds.\n');
fprintf('Validation seed     : %d (fixed)\n',baseCfg.sindy.validationSeed);
fprintf('Neural-basis seed   : %d (fixed)\n',baseCfg.sindy.neuralBasis.seed);
fprintf('Noise seed          : %d (fixed)\n',baseCfg.noise.seed);
fprintf('============================================================\n');

seedRunReports = cell(numel(seeds),1);
if aggregateOnly
    fprintf('\n============================================================\n');
    fprintf('MULTI-SEED AGGREGATE-ONLY MODE\n');
    fprintf('No training, dataset generation, or rollout will be executed.\n');
    fprintf('Existing per-seed method bundles will be loaded and summarized.\n');
    fprintf('============================================================\n');
else
    for iSeed = 1:numel(seeds)
        seed = seeds(iSeed);
        cfgSeed = baseCfg;
        cfgSeed.randomSeed = seed;
        cfgSeed.randomSeeds = seed; % single-seed internal call
        cfgSeed.multiseed.enabled = false;
        cfgSeed.multiseed.internalSingleSeed = true;
        cfgSeed.output.folderName = fullfile(baseFolder,seedFolderName,sprintf('seed_%d',seed));
        if ~keepSeedFigures
            cfgSeed.figures.visible = 'off';
            cfgSeed.figures.exportPDF = false;
        end

        % Follow the case's explicit frozen/per-data LLM-bank policy.
        % cfgSeed.randomSeed always identifies DATA only.
        [cfgSeed,seedPrior] = prepare_offline_llm_prior_config(projectRoot,cfgSeed);

        fprintf('\n************************************************************\n');
        fprintf('MULTI-SEED RUN %d/%d -- data-sampling seed %d\n',iSeed,numel(seeds),seed);
        fprintf('Seed output: outputs/%s\n',cfgSeed.output.folderName);
        fprintf('************************************************************\n');

        if seed_compute_campaign_complete_local(projectRoot,cfgSeed)
            fprintf(['RESUME: seed %d already has complete compatible bundles for ', ...
                'all current compute methods/conditions. Skipping ALL training ', ...
                'and rollout for this seed.\n'],seed);
            priorHash="";
            if isstruct(seedPrior) && isfield(seedPrior,'bankHash')
                priorHash=string(seedPrior.bankHash);
            end
            seedRunReports{iSeed} = struct( ...
                'resumeSkipped',true,'seed',seed, ...
                'llmPriorBankHash',priorHash, ...
                'reason',"complete_current_compute_method_bundles");
            continue;
        end

        seedConfigFcn = @() cfgSeed;
        seedRunReports{iSeed} = run_offline_model_experiments( ...
            projectRoot,caseFcn,seedConfigFcn);
    end
end

% Aggregate only the configured final manuscript method bundles.
[raw1,raw2,raw3,availableBySeed] = load_saved_seed_tables_local( ...
    projectRoot,baseFolder,seedFolderName,seeds,baseCfg);
% Saved legacy bundles may carry historical display labels (e.g. "Vanilla
% SINDy"). Canonicalize labels from the CURRENT registry without altering any
% saved numerical result.
raw1 = canonicalize_display_names_local(raw1,baseCfg);
raw2 = canonicalize_display_names_local(raw2,baseCfg);
raw3 = canonicalize_display_names_local(raw3,baseCfg);
raw1 = sort_campaign_table_local(raw1,baseCfg);
raw2 = sort_campaign_table_local(raw2,baseCfg);
raw3 = sort_campaign_table_local(raw3,baseCfg);
% Validate all expected method/condition/seed rows BEFORE any file writes.
% For the formal 69-bus paper plots, missing rows are an ERROR (not a
% successful 1/1 subset). A saved failed rollout is a valid present row.
verify_complete_plot_cohort_local(raw2,raw3,baseCfg,seeds);
S1 = sort_campaign_table_local(summarize_table_local(raw1,seeds),baseCfg);
S2 = sort_campaign_table_local(summarize_table_local(raw2,seeds),baseCfg);
S3 = sort_campaign_table_local(summarize_table_local(raw3,seeds),baseCfg);

summaryRoot = fullfile(projectRoot,'outputs',baseFolder,'multiseed_summary');
if ~exist(summaryRoot,'dir'), mkdir(summaryRoot); end
write_pair_local(raw1,S1,summaryRoot,'section1p1_multiseed');
write_pair_local(raw2,S2,summaryRoot,'section1p2_multiseed');
write_pair_local(raw3,S3,summaryRoot,'section1p3_multiseed');

plotCfg = baseCfg;
plotCfg.figures.exportPDF = true;
if ~isempty(S2)
    plot_offline_sample_sensitivity_multiseed(S2,plotCfg,summaryRoot);
end
if ~isempty(S3)
    plot_offline_noise_robustness_multiseed(S3,plotCfg,summaryRoot);
end

compact = struct();
compact.schemaVersion = 'offline_multiseed_summary_v1';
compact.seeds = seeds;
compact.seedPolicy = 'vary_data_sampling_only';
compact.fixedValidationSeed = baseCfg.sindy.validationSeed;
compact.fixedNeuralBasisSeed = baseCfg.sindy.neuralBasis.seed;
compact.fixedNoiseSeed = baseCfg.noise.seed;
compact.baseConfig = baseCfg;
compact.availableMethodsBySeed = availableBySeed;
compact.section1p1.raw = raw1;
compact.section1p1.summary = S1;
compact.section1p2.raw = raw2;
compact.section1p2.summary = S2;
compact.section1p3.raw = raw3;
compact.section1p3.summary = S3;
save(fullfile(summaryRoot,'offline_multiseed_summary.mat'),'compact','-v7.3');

report = struct();
report.isMultiSeed = true;
report.aggregateOnly = aggregateOnly;
report.seeds = seeds;
report.seedPolicy = compact.seedPolicy;
report.seedRunReports = seedRunReports;
report.availableMethodsBySeed = availableBySeed;
report.section1p1 = compact.section1p1;
report.section1p2 = compact.section1p2;
report.section1p3 = compact.section1p3;
report.outputRoot = summaryRoot;

fprintf('\n============================================================\n');
fprintf('MULTI-SEED SUMMARY FINISHED\n');
fprintf('Aggregate output: %s\n',summaryRoot);
fprintf('RMSE/MaxAE means and standard deviations use successful rollouts only.\n');
fprintf('SeedCount denotes EXPECTED seeds; Present/Failed/Missing counts are explicit.\n');
fprintf('============================================================\n');
end

function tf = seed_compute_campaign_complete_local(projectRoot,cfgSeed)
%SEED_COMPUTE_CAMPAIGN_COMPLETE_LOCAL True only for a fully finished seed.
%
% Fully completed seeds are skipped before dataset generation/truth rollout.
% Partially completed seeds fall through to the normal runner, where the
% section-level persistent checkpoint preflight resumes individual conditions.

tf = false;
if ~isfield(cfgSeed,'run') || ~isstruct(cfgSeed.run)
    return;
end

sections = {'section1p1','section1p2','section1p3'};
methodFields = {'section1p1MethodsToRun','section1p2MethodsToRun', ...
    'section1p3MethodsToRun'};

for isec = 1:numel(sections)
    if isfield(cfgSeed.run,sections{isec}) && ~logical(cfgSeed.run.(sections{isec}))
        continue;
    end
    if isfield(cfgSeed.run,methodFields{isec}) && ~isempty(cfgSeed.run.(methodFields{isec}))
        names = string(cfgSeed.run.(methodFields{isec})(:));
    elseif isfield(cfgSeed.run,'methodsToRun') && ~isempty(cfgSeed.run.methodsToRun)
        names = string(cfgSeed.run.methodsToRun(:));
    else
        return;
    end

    for im = 1:numel(names)
        methodName = names(im);
        bundleFile = fullfile(projectRoot,'outputs', ...
            char(string(cfgSeed.output.folderName)), ...
            get_method_results_folder_local(cfgSeed),char(methodName), ...
            get_method_replay_file_local(cfgSeed));
        if exist(bundleFile,'file')~=2
            return;
        end
        try
            Q = load_mat_long_path_safe(bundleFile,'methodBundle');
            if ~isfield(Q,'methodBundle') || ~isstruct(Q.methodBundle)
                return;
            end
            B = Q.methodBundle;
            if ~isfield(B,'methodName') || ...
                    ~strcmpi(char(string(B.methodName)),char(methodName))
                return;
            end
            if ~bundle_matches_seed_campaign_local(B,cfgSeed.randomSeed,cfgSeed)
                return;
            end
            if ~bundle_section_complete_local(B,sections{isec},cfgSeed)
                return;
            end
        catch
            return;
        end
    end
end

tf = true;
end


function tf = bundle_section_complete_local(B,sectionName,cfg)
tf = false;
if ~isstruct(B) || ~isfield(B,'report') || ~isstruct(B.report) || ...
        ~isfield(B.report,sectionName) || ~isstruct(B.report.(sectionName)) || ...
        ~isfield(B.report.(sectionName),'table') || ...
        ~istable(B.report.(sectionName).table)
    return;
end
T = B.report.(sectionName).table;
if isempty(T) || ~ismember('SampleCount',T.Properties.VariableNames)
    return;
end

switch lower(sectionName)
    case 'section1p1'
        tf = table_has_condition_local(T,cfg.typicalSampleCount,0);
    case 'section1p2'
        tf = all(arrayfun(@(N)table_has_condition_local(T,N,0),cfg.sampleCounts));
    case 'section1p3'
        tf = all(arrayfun(@(q)table_has_condition_local( ...
            T,cfg.typicalSampleCount,q),cfg.noiseLevels));
end
end


function tf = table_has_condition_local(T,N,noise)
nMatch = abs(double(T.SampleCount)-double(N)) <= 1e-12;
if ismember('NoiseLevel',T.Properties.VariableNames)
    q = double(T.NoiseLevel);
elseif ismember('NoisePercent',T.Properties.VariableNames)
    q = double(T.NoisePercent)/100;
else
    q = zeros(height(T),1);
end
noiseTol = max(1e-14,1e-10*max(1,abs(double(noise))));
tf = any(nMatch & abs(q-double(noise))<=noiseTol);
end


function [T1,T2,T3,availableBySeed] = load_saved_seed_tables_local( ...
    projectRoot,baseFolder,seedFolderName,seeds,baseCfg)
T1 = table(); T2 = table(); T3 = table();
availableBySeed = cell(numel(seeds),1);
for iSeed = 1:numel(seeds)
    seed = seeds(iSeed);
    seedRoot = fullfile(projectRoot,'outputs',baseFolder,seedFolderName, ...
        sprintf('seed_%d',seed));
    methodRoot = fullfile(seedRoot,get_method_results_folder_local(baseCfg));
    if exist(methodRoot,'dir') ~= 7
        warning('run_offline_model_experiments_multiseed:MissingSeedFolder', ...
            'No saved method-results folder for seed %d: %s',seed,methodRoot);
        availableBySeed{iSeed} = strings(0,1);
        continue;
    end
    D = dir(methodRoot);
    D = D([D.isdir]);
    savedNames = strings(0,1);
    for k = 1:numel(D)
        if any(strcmp(D(k).name,{'.','..'})), continue; end
        file = fullfile(methodRoot,D(k).name,get_method_replay_file_local(baseCfg));
        if exist(file,'file') ~= 2, continue; end
        Q = load_mat_long_path_safe(file,'methodBundle');
        if ~isfield(Q,'methodBundle'), continue; end
        B = Q.methodBundle;
        if ~method_is_active_for_campaign_local(B,baseCfg)
            continue;
        end
        [compatible,why] = bundle_matches_seed_campaign_local(B,seed,baseCfg);
        if ~compatible
            warning('run_offline_model_experiments_multiseed:SkipIncompatibleBundle', ...
                'Skipping incompatible bundle for data seed %d: %s\nReason: %s', ...
                seed,file,char(why));
            continue;
        end
        savedNames(end+1,1) = string(B.methodName); %#ok<AGROW>
        if isfield(B,'report') && isstruct(B.report)
            T1 = append_seed_table_local(T1,B.report,'section1p1',seed);
            T2 = append_seed_table_local(T2,B.report,'section1p2',seed);
            T3 = append_seed_table_local(T3,B.report,'section1p3',seed);
        end
    end
    availableBySeed{iSeed} = savedNames;
end
end


function tf = method_is_active_for_campaign_local(B,baseCfg)
% Ignore historical/retired method bundles when rebuilding final summaries.
if ~isstruct(B) || ~isfield(B,'methodName')
    tf = false;
    return;
end
active = ["modular_koopman_kbf","vanilla_sindy","edsi", ...
    "neural_ode_modular","llm_prior_sindy"];
if isfield(baseCfg,'run') && isstruct(baseCfg.run) && ...
        isfield(baseCfg.run,'methodsToRun') && ~isempty(baseCfg.run.methodsToRun) && ...
        ~(ischar(baseCfg.run.methodsToRun) && strcmpi(baseCfg.run.methodsToRun,'all'))
    active = string(baseCfg.run.methodsToRun(:));
end
tf = any(strcmpi(string(B.methodName),active));
end

function [tf,why] = bundle_matches_seed_campaign_local(B,seed,baseCfg)
why="";
tf = isstruct(B) && isfield(B,'config') && isstruct(B.config) && ...
    isfield(B.config,'randomSeed') && round(double(B.config.randomSeed)) == round(double(seed));
if ~tf, return; end
methodName = '';
if isfield(B,'methodName'), methodName = char(string(B.methodName)); end
if any(strcmp(methodName,{'vanilla_sindy','physics_embedded_sindy','weak_sindy'}))
    tf = isfield(B.config,'sindy') && isfield(B.config.sindy,'polyOrderOption') && ...
        double(B.config.sindy.polyOrderOption) == double(baseCfg.sindy.polyOrderOption);
end
if tf && strcmp(methodName,'weak_sindy')
    tf = isfield(B.config.sindy,'weakSindy') && isstruct(B.config.sindy.weakSindy) && ...
        isequal(double(B.config.sindy.weakSindy.windowPoints(:).'), ...
            double(baseCfg.sindy.weakSindy.windowPoints(:).')) && ...
        double(B.config.sindy.weakSindy.windowStride) == ...
            double(baseCfg.sindy.weakSindy.windowStride) && ...
        double(B.config.sindy.weakSindy.testFunctionPower) == ...
            double(baseCfg.sindy.weakSindy.testFunctionPower) && ...
        isequal(double(B.config.sindy.weakSindy.thresholdGrid(:).'), ...
            double(baseCfg.sindy.weakSindy.thresholdGrid(:).'));
end
if tf && strcmp(methodName,'llm_prior_sindy')
    tf = isfield(B.config,'sindy') && isstruct(B.config.sindy) && ...
        isfield(B.config.sindy,'llmPrior') && isstruct(B.config.sindy.llmPrior) && ...
        isfield(B.config.sindy.llmPrior,'formulationVersion') && ...
        strcmp(char(string(B.config.sindy.llmPrior.formulationVersion)), ...
            char(string(baseCfg.sindy.llmPrior.formulationVersion))) && ...
        isfield(B.config.sindy.llmPrior,'discoveryProtocolVersion') && ...
        strcmp(char(string(B.config.sindy.llmPrior.discoveryProtocolVersion)), ...
            char(string(baseCfg.sindy.llmPrior.discoveryProtocolVersion))) && ...
        isfield(B.config.sindy.llmPrior,'discoverySeed') && ...
        isnumeric(B.config.sindy.llmPrior.discoverySeed) && ...
        isscalar(B.config.sindy.llmPrior.discoverySeed) && ...
        isfinite(double(B.config.sindy.llmPrior.discoverySeed)) && ...
        isfield(B.config.sindy.llmPrior,'priorBankHash') && ...
        strlength(strtrim(string(B.config.sindy.llmPrior.priorBankHash)))>0;
    if ~tf
        why="LLM prior bundle metadata is missing/incompatible";
        return;
    end
    % The candidate library width and shared STLSQ backend must also match
    % the current official 69-bus/other-case configuration.
    sb=B.config.sindy;
    sc=baseCfg.sindy;
    tf=isfield(sb,'polyOrderOption') && ...
        double(sb.polyOrderOption)==double(sc.polyOrderOption) && ...
        isfield(sb,'formulationVersion') && ...
        strcmp(string(sb.formulationVersion),string(sc.formulationVersion)) && ...
        isfield(sb,'stlsq') && isstruct(sb.stlsq) && ...
        isfield(sb.stlsq,'ridge') && isfield(sb.stlsq,'finalSupportRidgeRho') && ...
        double(sb.stlsq.ridge)==double(sc.stlsq.ridge) && ...
        double(sb.stlsq.finalSupportRidgeRho)==double(sc.stlsq.finalSupportRidgeRho);
    if ~tf
        why="LLM polynomial dictionary or sparse-regression backend mismatch";
        return;
    end
    p=B.config.sindy.llmPrior;
    expectedDiscovery=round(double(seed));
    expectedHash="";
    if isfield(baseCfg,'multiseed') && isstruct(baseCfg.multiseed) && ...
            isfield(baseCfg.multiseed,'llmPriorDiscoveryPolicy')
        policy=lower(strtrim(string(baseCfg.multiseed.llmPriorDiscoveryPolicy)));
        switch policy
            case "fixed_bank"
                expectedDiscovery=round(double(baseCfg.multiseed.llmPriorFixedDiscoverySeed));
                if isfield(baseCfg.multiseed,'llmPriorExpectedBankHash')
                    expectedHash=string(baseCfg.multiseed.llmPriorExpectedBankHash);
                end
            case {"per_data_seed","independent",""}
                % The ordinary 10/123-bus campaign uses one bank per seed.
            otherwise
                tf=false; why="Unknown discovery policy: "+policy; return;
        end
    end
    tf = round(double(p.discoverySeed))==expectedDiscovery;
    if ~tf
        why="LLM discovery seed differs from the campaign policy"; return;
    end
    if strlength(expectedHash)>0
        tf=strcmpi(strtrim(string(p.priorBankHash)),strtrim(expectedHash));
        if ~tf
            why="LLM prior bank hash differs from the official frozen bank"; return;
        end
    end
    [tf,why]=verify_llm_saved_condition_keys_local(B,seed);
    if ~tf, return; end
end
if tf && any(strcmp(methodName,{'edsi','llm_edsi'}))
    tf = isfield(B.config,'edsi') && isstruct(B.config.edsi) && ...
        isfield(B.config.edsi,'formulationVersion') && ...
        strcmp(char(string(B.config.edsi.formulationVersion)), ...
            char(string(baseCfg.edsi.formulationVersion))) && ...
        isfield(B.config.edsi,'evolutionSearchSeed') && ...
        double(B.config.edsi.evolutionSearchSeed) == ...
            double(baseCfg.edsi.evolutionSearchSeed);
end
if tf && strcmp(methodName,'llm_edsi')
    tf = isfield(B.config,'llmEdsi') && isstruct(B.config.llmEdsi) && ...
        isfield(B.config.llmEdsi,'formulationVersion') && ...
        strcmp(char(string(B.config.llmEdsi.formulationVersion)), ...
            char(string(baseCfg.llmEdsi.formulationVersion))) && ...
        isfield(B.config.llmEdsi,'maxCalls') && ...
        double(B.config.llmEdsi.maxCalls)==1 && ...
        isfield(B.config.llmEdsi,'initialGeneration') && ...
        double(B.config.llmEdsi.initialGeneration)==1;
end
end


function [ok,why] = verify_llm_saved_condition_keys_local(B,dataSeed)
% Bundle-level V4 metadata may be NEWER than an incrementally merged row.
% Validate every saved LLM condition cache key against the actual metadata.
ok=false; why="";
if ~isfield(B,'report') || ~isstruct(B.report)
    why="No LLM report"; return;
end
p=B.config.sindy.llmPrior;
s=B.config.sindy;
if ~isfield(s,'formulationVersion') || ~isfield(s,'stlsq') || ...
        ~isstruct(s.stlsq) || ~isfield(s.stlsq,'ridge') || ...
        ~isfield(s.stlsq,'finalSupportRidgeRho')
    why="Missing recorded LLM regression backend metadata"; return;
end
sections={'section1p1','section1p2','section1p3'};
for j=1:numel(sections)
    sec=sections{j};
    if ~isfield(B.report,sec), continue; end
    if ~isstruct(B.report.(sec)) || ~isfield(B.report.(sec),'table') || ...
            ~istable(B.report.(sec).table)
        why="Malformed LLM report section "+string(sec); return;
    end
    T=B.report.(sec).table;
    if isempty(T), continue; end
    needed={'EvaluationCacheKey','Method','SampleCount','RolloutSucceeded','RMSE'};
    if ~all(ismember(needed,T.Properties.VariableNames)) || ...
            ~any(ismember({'NoiseLevel','NoisePercent'},T.Properties.VariableNames))
        why="Missing cache key or scientific columns in "+string(sec); return;
    end
    if ismember('NoiseLevel',T.Properties.VariableNames)
        noiseVec=double(T.NoiseLevel);
    else
        noiseVec=double(T.NoisePercent)/100;
    end
    for k=1:height(T)
        if ~strcmpi(string(T.Method(k)),"llm_prior_sindy")
            why="Unexpected method row inside LLM bundle"; return;
        end
        N=double(T.SampleCount(k)); noise=double(noiseVec(k));
        if ~isfinite(N) || N<=0 || N~=round(N) || ~isfinite(noise) || noise<0
            why="Invalid saved LLM condition N/noise"; return;
        end
        key=strtrim(string(T.EvaluationCacheKey(k)));
        if numel(key)~=1 || ismissing(key) || strlength(key)==0 || ...
                ~startsWith(key,"llm_prior_sindy|")
            why="Empty/malformed LLM condition cache key"; return;
        end
        parts=lower(split(key,"|"));
        neededParts=[ ...
            "n="+string(sprintf('%d',round(N))), ...
            "noise="+string(sprintf('%.17g',noise)), ...
            "seed="+string(sprintf('%d',round(double(dataSeed)))), ...
            "sindy_arch="+string(s.formulationVersion), ...
            "support_discovery_rho="+string(sprintf('%.17g',double(s.stlsq.ridge))), ...
            "clean_final_rho="+string(sprintf('%.17g',double(s.stlsq.finalSupportRidgeRho))), ...
            "llm_prior_arch="+string(p.formulationVersion), ...
            "discovery_protocol="+string(p.discoveryProtocolVersion), ...
            "discovery_seed="+string(sprintf('%d',round(double(p.discoverySeed)))), ...
            "prior_hash="+string(p.priorBankHash)];
        if ~all(ismember(lower(neededParts),parts))
            why="Stale LLM cache key (data seed/N/noise/regression/prior) in "+ ...
                string(sec)+" at row "+string(k);
            return;
        end
        if noise==0 && ~ismember("protocol=clean_exact_vector_field",parts)
            why="Clean LLM row has wrong derivative-label protocol"; return;
        end
        rowSuccess=double(T.RolloutSucceeded(k));
        rowRMSE=double(T.RMSE(k));
        if ~isscalar(rowSuccess) || ~ismember(rowSuccess,[0 1]) || ...
                ~(rowSuccess==1 && isfinite(rowRMSE) && rowRMSE>=0 || ...
                  rowSuccess==0 && isnan(rowRMSE))
            why="LLM row has inconsistent success/RMSE"; return;
        end
    end
end
ok=true;
end

function verify_complete_plot_cohort_local(T2,T3,cfg,seeds)
% For official paper figures ONLY, fail closed if one seed is absent.
strict=isfield(cfg,'multiseed') && isstruct(cfg.multiseed) && ...
    isfield(cfg.multiseed,'strictPlotSeedCoverage') && ...
    logical(cfg.multiseed.strictPlotSeedCoverage);
if ~strict, return; end
methods=string(cfg.run.methodsToRun(:));
% All five sample budgets are included in the paper panel.
% The noise figure displays 0--5%%; cfg may also request additional noise.
noiseGrid=double(cfg.noiseLevels(:));
noiseGrid=noiseGrid(noiseGrid<=0.05+1e-14);
for isec=1:2
    if isec==1
        T=T2;
        Ns=double(cfg.sampleCounts(:)); qs=zeros(size(Ns));
        secLabel="section1p2";
    else
        T=T3;
        Ns=repmat(double(cfg.typicalSampleCount),numel(noiseGrid),1);
        qs=noiseGrid;
        secLabel="section1p3";
    end
    needed={'Method','Seed','SampleCount','RolloutSucceeded','RMSE'};
    if isempty(T) || ~istable(T) || ...
            ~all(ismember(needed,T.Properties.VariableNames)) || ...
            ~any(ismember({'NoiseLevel','NoisePercent'},T.Properties.VariableNames))
        error('run_offline_model_experiments_multiseed:IncompletePlotCohort', ...
            'Missing %s manuscript raw data. Original summary is untouched.',secLabel);
    end
    if ismember('NoiseLevel',T.Properties.VariableNames)
        noiseVals=double(T.NoiseLevel);
    else
        noiseVals=double(T.NoisePercent)/100;
    end
    for im=1:numel(methods)
        for ic=1:numel(Ns)
            ix=strcmpi(string(T.Method),methods(im)) & ...
                abs(double(T.SampleCount)-Ns(ic))<1e-9 & ...
                abs(noiseVals-qs(ic))<1e-10;
            group=T(ix,:);
            present=double(group.Seed(:));
            if numel(present)~=numel(seeds) || ...
                    ~isequal(sort(present(:)),sort(double(seeds(:))))
                error('run_offline_model_experiments_multiseed:IncompletePlotCohort', ...
                    ['INCOMPLETE %s: method %s, N=%d, noise=%.4g ', ...
                     '(present seeds %s, expected %s). ', ...
                     'Refusing to overwrite manuscript summaries/figures.'], ...
                    secLabel,char(methods(im)),round(Ns(ic)),qs(ic), ...
                    mat2str(present.'),mat2str(seeds));
            end
            % Explicit failed rollouts are valid PRESENT observations.
        end
    end
end
fprintf('STRICT PLOT COHORT CHECK PASSED: all configured methods, all plotted conditions, %d data seeds.\n',numel(seeds));
end


function T = append_seed_table_local(T,report,sectionName,seed)
if ~isfield(report,sectionName) || ~isstruct(report.(sectionName)) || ...
        ~isfield(report.(sectionName),'table') || isempty(report.(sectionName).table)
    return;
end
Q = report.(sectionName).table;
if ~istable(Q) || height(Q)==0, return; end
Q.Seed = repmat(double(seed),height(Q),1);
if isempty(T), T=Q; else, T=[T;Q]; end %#ok<AGROW>
end

function S = summarize_table_local(T,expectedSeeds)
if isempty(T) || ~istable(T) || height(T)==0
    S = table();
    return;
end
required = {'Method','DisplayName','SampleCount','NoiseLevel','NoisePercent', ...
    'RolloutSucceeded','RMSE','MaxAE','TrainingTimeSec'};
for k=1:numel(required)
    if ~ismember(required{k},T.Properties.VariableNames)
        error('run_offline_model_experiments_multiseed:MissingColumn', ...
            'Multi-seed table is missing required column %s.',required{k});
    end
end

keys = unique(T(:,{'Method','DisplayName','SampleCount','NoiseLevel','NoisePercent'}),'rows','stable');
rows = cell(height(keys),1);
for i = 1:height(keys)
    idx = T.Method==keys.Method(i) & ...
        T.DisplayName==keys.DisplayName(i) & ...
        T.SampleCount==keys.SampleCount(i) & ...
        abs(T.NoiseLevel-keys.NoiseLevel(i)) <= 1e-15;
    Q = T(idx,:);
    success = logical(Q.RolloutSucceeded);
    rmse = Q.RMSE(success & isfinite(Q.RMSE));
    maxae = Q.MaxAE(success & isfinite(Q.MaxAE));
    trtime = Q.TrainingTimeSec(isfinite(Q.TrainingTimeSec));
    seedsHere = unique(double(Q.Seed));
    if numel(seedsHere)~=height(Q)
        error('run_offline_model_experiments_multiseed:DuplicateSeedRow', ...
            'A condition has duplicated seed records: %s / N=%d.', ...
            char(string(keys.Method(i))),double(keys.SampleCount(i)));
    end
    r = keys(i,:);
    r.SeedCount = numel(expectedSeeds);  % official campaign denominator
    r.PresentSeedCount = numel(seedsHere);
    r.MissingSeedCount = r.SeedCount-r.PresentSeedCount;
    r.SuccessCount = nnz(success);
    r.FailedSeedCount = r.PresentSeedCount-r.SuccessCount;
    r.SuccessRate = r.SuccessCount/max(r.SeedCount,1);
    [mVal,sVal] = finite_mean_std_local(rmse);
    r.RMSEMean = mVal; r.RMSEStd = sVal;
    [mVal,sVal] = finite_mean_std_local(maxae);
    r.MaxAEMean = mVal; r.MaxAEStd = sVal;
    [mVal,sVal] = finite_mean_std_local(trtime);
    r.TrainingTimeMean = mVal; r.TrainingTimeStd = sVal;
    rows{i}=r;
end
S = vertcat(rows{:});
end

function T = canonicalize_display_names_local(T,cfg)
%CANONICALIZE_DISPLAY_NAMES_LOCAL Apply current registry labels to saved rows.
if isempty(T) || ~istable(T) || ...
        ~ismember('Method',T.Properties.VariableNames) || ...
        ~ismember('DisplayName',T.Properties.VariableNames)
    return;
end
R = get_offline_method_registry(cfg);
for k = 1:numel(R)
    hit = strcmpi(string(T.Method),string(R(k).name));
    if any(hit)
        T.DisplayName(hit) = string(R(k).displayName);
    end
end
end


function T = sort_campaign_table_local(T,cfg)
%SORT_CAMPAIGN_TABLE_LOCAL Keep plots/tables in the configured manuscript order.
if isempty(T) || ~istable(T) || ~ismember('Method',T.Properties.VariableNames)
    return;
end
order = ["modular_koopman_kbf","vanilla_sindy","edsi", ...
    "neural_ode_modular","llm_prior_sindy"];
if isfield(cfg,'run') && isstruct(cfg.run) && ...
        isfield(cfg.run,'methodsToRun') && ~isempty(cfg.run.methodsToRun)
    order = string(cfg.run.methodsToRun(:)).';
end
rank = repmat(numel(order)+1,height(T),1);
for k = 1:numel(order)
    rank(strcmpi(string(T.Method),order(k))) = k;
end
T.MethodOrderTmp = rank;
sortVars = {'MethodOrderTmp'};
for q = {'SampleCount','NoiseLevel','Seed'}
    if ismember(q{1},T.Properties.VariableNames), sortVars{end+1}=q{1}; end %#ok<AGROW>
end
T = sortrows(T,sortVars);
T.MethodOrderTmp = [];
end

function [m,s] = finite_mean_std_local(v)
v = double(v(:));
v = v(isfinite(v));
if isempty(v)
    m=NaN; s=NaN;
elseif numel(v)==1
    m=v(1); s=0;
else
    m=mean(v); s=std(v,0);
end
end

function write_pair_local(raw,S,outDir,stem)
if ~isempty(raw), writetable(raw,fullfile(outDir,[stem '_raw.csv'])); end
if ~isempty(S), writetable(S,fullfile(outDir,[stem '_summary.csv'])); end
end

function folder = get_method_results_folder_local(cfg)
folder = 'method_results';
if isfield(cfg,'output') && isfield(cfg.output,'methodResultsFolder') && ...
        ~isempty(cfg.output.methodResultsFolder)
    folder = char(string(cfg.output.methodResultsFolder));
end
end

function file = get_method_replay_file_local(cfg)
file = 'offline_part1_method_replay.mat';
if isfield(cfg,'output') && isfield(cfg.output,'methodReplayFileName') && ...
        ~isempty(cfg.output.methodReplayFileName)
    file = char(string(cfg.output.methodReplayFileName));
end
end
