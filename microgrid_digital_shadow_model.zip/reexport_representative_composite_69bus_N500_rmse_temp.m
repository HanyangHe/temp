clear functions;
rehash toolboxcache;
addpath(genpath(pwd));

% Replace export_69bus_representative_trajectory_from_bundles.m with the
% updated RMSE version before running this script.

figPath = export_69bus_representative_trajectory_from_bundles(pwd, ...
    'Seed', 20260814, ...
    'Visible', 'on');

disp(figPath);
