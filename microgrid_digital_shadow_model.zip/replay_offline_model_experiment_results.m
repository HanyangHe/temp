function replayInfo = replay_offline_model_experiment_results(projectRoot,resultSource,varargin)
%REPLAY_OFFLINE_MODEL_EXPERIMENT_RESULTS Replay any selected saved methods.
%
% v1p17 storage/replay rule:
%   - every method is stored independently under
%       outputs/<case>/method_results/<method_name>/
%   - replay loads only the selected method bundles and merges them IN MEMORY
%     for comparison figures/tables;
%   - replay never rewrites a method bundle and performs NO training/rollout.
%
% Default 10-bus usage:
%   replay_offline_model_experiment_results(projectRoot)
%
% Final manuscript methods are selected by default:
%   M-KBF, V-SINDy, PE-SINDy, PNC-SINDy, Neural ODE.
% Historical PW/PWN bundles may remain on disk but are ignored.
%
% Options:
%   'MethodsToDisplay'          default final Stage-4 manuscript methods
%   'DisplayDetailedReport'     default true
%   'ReplayOutputFolder'        retained for API compatibility; canonical replay
%                               now overwrites the original case-output figures.
%   'TrajectoryOnly'            default false. When true, only Section 1.1
%                               trajectory figures are regenerated.
%   'CanonicalOutputRoot'       optional explicit case output root.
%   'AutoSplitLegacyAggregate'  default true. If only the old aggregate
%       offline_experiment_part1_replay.mat exists, split it once into the
%       new per-method structure WITHOUT deleting/overwriting the old file.

if nargin < 1 || isempty(projectRoot)
    projectRoot = fileparts(mfilename('fullpath'));
    if isempty(projectRoot), projectRoot = pwd; end
end

optionNames = {'MethodsToDisplay','DisplayDetailedReport', ...
    'ReplayOutputFolder','AutoSplitLegacyAggregate','TrajectoryOnly','CanonicalOutputRoot'};
if nargin >= 2 && is_name_value_name(resultSource,optionNames)
    varargin = [{resultSource},varargin];
    resultSource = [];
end

p = inputParser;
p.FunctionName = mfilename;
addParameter(p,'MethodsToDisplay',final_manuscript_methods_local(),@valid_method_selection);
addParameter(p,'DisplayDetailedReport',true, ...
    @(x)islogical(x) || (isnumeric(x) && isscalar(x)));
addParameter(p,'ReplayOutputFolder','replay_display', ...
    @(x)ischar(x) || (isstring(x) && isscalar(x)));
addParameter(p,'AutoSplitLegacyAggregate',true, ...
    @(x)islogical(x) || (isnumeric(x) && isscalar(x)));
addParameter(p,'TrajectoryOnly',false, ...
    @(x)islogical(x) || (isnumeric(x) && isscalar(x)));
addParameter(p,'CanonicalOutputRoot','', ...
    @(x)ischar(x) || (isstring(x) && isscalar(x)));
parse(p,varargin{:});
opt = p.Results;
opt.DisplayDetailedReport = logical(opt.DisplayDetailedReport);
opt.AutoSplitLegacyAggregate = logical(opt.AutoSplitLegacyAggregate);
opt.TrajectoryOnly = logical(opt.TrajectoryOnly);

addpath(genpath(projectRoot));
if nargin < 2 || isempty(resultSource)
    resultSource = fullfile(projectRoot,'outputs','offline_model_experiments_10bus');
end
resultSource = char(string(resultSource));

[sourceRoot,methodFiles,legacyFile] = resolve_method_storage_source(resultSource);
if isempty(methodFiles) && opt.AutoSplitLegacyAggregate && ~isempty(legacyFile)
    fprintf(['No independent method bundles found. Splitting legacy aggregate ', ...
        'replay into per-method storage (legacy file remains unchanged)...\n']);
    migrate_legacy_offline_replay_to_method_bundles(projectRoot,legacyFile);
    [sourceRoot,methodFiles,~] = resolve_method_storage_source(sourceRoot);
end
if isempty(methodFiles)
    error('replay_offline_model_experiment_results:NoMethodBundles', ...
        ['No independent method replay bundles were found under %s. ', ...
         'Run an experiment with the v1p17 storage logic, or migrate the ', ...
         'legacy aggregate replay first.'],sourceRoot);
end

meta = load_method_bundle_metadata(methodFiles);
[selectedIdx,selectedNames] = resolve_method_selection(meta,opt.MethodsToDisplay);
selectedMeta = meta(selectedIdx);

bundles = cell(numel(selectedMeta),1);
for k = 1:numel(selectedMeta)
    S = load_mat_long_path_safe(selectedMeta(k).path,'methodBundle');
    if ~isfield(S,'methodBundle')
        error('replay_offline_model_experiment_results:InvalidMethodBundle', ...
            'File does not contain methodBundle: %s',selectedMeta(k).path);
    end
    bundles{k} = S.methodBundle;
end
validate_bundle_compatibility(bundles);

[report,c,cfg,truth] = merge_selected_method_bundles(bundles,selectedNames);
[report,cfg] = harmonize_replay_campaign(report,cfg,selectedNames);
% Replay must always regenerate both MATLAB FIG and vector PDF outputs.
if ~isfield(cfg,'figures') || ~isstruct(cfg.figures)
    cfg.figures = struct();
end
% Replay is intended to restore both the exported files and the Live Editor
% report view. Seed runs may have saved cfg.figures.visible='off'; override
% that saved execution detail during replay only.
cfg.figures.visible = 'on';
cfg.figures.exportPDF = true;
% Replay is a restoration operation, not a second result campaign.
% Always regenerate/overwrite the canonical figure files in the original
% case-output tree; never create a new replay_display result hierarchy.
replayOutRoot = canonical_case_output_root_local(projectRoot,resultSource,sourceRoot,cfg,opt.CanonicalOutputRoot);
if ~exist(replayOutRoot,'dir'), mkdir(replayOutRoot); end

fprintf('\n============================================================\n');
fprintf('Offline Experiment Part 1 -- SELECTIVE METHOD REPLAY ONLY\n');
fprintf('Independent source root: %s\n',sourceRoot);
fprintf('Selected methods: %s\n',strjoin(cellstr(selectedNames),', '));
fprintf('No model training, dataset generation, or rollout will be executed.\n');
fprintf('Replay figure export: canonical FIG + vector PDF files are regenerated and overwritten in place.\n');
fprintf('Detailed saved report display: %s\n',onoff_local(opt.DisplayDetailedReport));
fprintf('============================================================\n');
for k = 1:numel(selectedMeta)
    fprintf('  source[%d] %s -> %s\n',k,selectedMeta(k).methodName,selectedMeta(k).path);
end

if opt.DisplayDetailedReport
    print_saved_replay_overview(report,c,cfg,projectRoot,truth,selectedNames);
end

replayInfo = struct();
replayInfo.sourceRoot = sourceRoot;
replayInfo.sourceFiles = string({selectedMeta.path}).';
replayInfo.availableMethods = string({meta.methodName}).';
replayInfo.selectedMethods = selectedNames(:);
replayInfo.outputRoot = replayOutRoot;
replayInfo.sections = strings(0,1);
replayInfo.displayDetailedReport = opt.DisplayDetailedReport;

%% Section 1.1
if has_section(report,'section1p1')
    secDir = fullfile(replayOutRoot,'section_1p1_typical_accuracy');
    if ~exist(secDir,'dir'), mkdir(secDir); end
    T = strip_nrmse_report_data(report.section1p1.table);
    evals = report.section1p1.evaluations;

    if opt.DisplayDetailedReport
        fprintf('\n---------------- Section 1.1: typical N=%d [SAVED REPLAY] ----------------\n', ...
            cfg.typicalSampleCount);
        print_saved_evaluation_list(evals,T);
    end
    if ~isempty(T)
        writetable(T,fullfile(secDir,'section1p1_whole_trajectory_metrics.csv'));
    end
    for k = 1:numel(evals)
        if isempty(evals{k}), continue; end
        methodName = char(string(evals{k}.method.name));
        methodDir = fullfile(secDir,methodName);
        if ~exist(methodDir,'dir'), mkdir(methodDir); end
        if isfield(evals{k},'perVariableMetrics') && istable(evals{k}.perVariableMetrics)
            writetable(strip_nrmse_report_data(evals{k}.perVariableMetrics), ...
                fullfile(methodDir,'per_variable_metrics.csv'));
        end
        write_node_diagnostic_tables(evals{k},methodDir,'diagnostic');
        write_koopman_model_tables(evals{k},methodDir,'koopman');
    end
    plot_offline_trajectory_comparison(truth,evals,c,cfg,secDir,replayOutRoot);
    if opt.DisplayDetailedReport && ~isempty(T), disp(T); end
    replayInfo.sections(end+1,1) = "section1p1";
end

%% Section 1.2
if ~opt.TrajectoryOnly && has_section(report,'section1p2')
    secDir = fullfile(replayOutRoot,'section_1p2_sample_sensitivity');
    if ~exist(secDir,'dir'), mkdir(secDir); end
    T = strip_nrmse_report_data(report.section1p2.table);
    E = report.section1p2.evaluations;
    if opt.DisplayDetailedReport
        fprintf('\n---------------- Section 1.2: sample sensitivity [SAVED REPLAY] ----------------\n');
        print_saved_evaluation_list(E,T);
    end
    if ~isempty(T)
        writetable(T,fullfile(secDir,'section1p2_sample_sensitivity.csv'));
        plot_offline_sample_sensitivity(T,cfg,secDir);
    end
    for k = 1:numel(E)
        if isempty(E{k}), continue; end
        methodName = char(string(E{k}.method.name));
        methodDir = fullfile(secDir,methodName);
        if ~exist(methodDir,'dir'), mkdir(methodDir); end
        N = saved_eval_n(E{k},k);
        write_node_diagnostic_tables(E{k},methodDir,sprintf('diagnostic_N%d',round(N)));
        write_koopman_model_tables(E{k},methodDir,sprintf('koopman_N%d',round(N)));
    end
    if opt.DisplayDetailedReport && ~isempty(T), disp(T); end
    replayInfo.sections(end+1,1) = "section1p2";
end

%% Section 1.3
if ~opt.TrajectoryOnly && has_section(report,'section1p3')
    secDir = fullfile(replayOutRoot,'section_1p3_noise_robustness');
    if ~exist(secDir,'dir'), mkdir(secDir); end
    T = strip_nrmse_report_data(report.section1p3.table);
    E = report.section1p3.evaluations;
    if opt.DisplayDetailedReport
        fprintf('\n---------------- Section 1.3: state-measurement noise robustness [SAVED REPLAY] ----------------\n');
        print_saved_evaluation_list(E,T);
    end
    if ~isempty(T)
        writetable(T,fullfile(secDir,'section1p3_noise_robustness.csv'));
        plot_offline_noise_robustness(T,cfg,secDir);
    end
    for k = 1:numel(E)
        if isempty(E{k}), continue; end
        methodName = char(string(E{k}.method.name));
        methodDir = fullfile(secDir,methodName);
        if ~exist(methodDir,'dir'), mkdir(methodDir); end
        write_node_diagnostic_tables(E{k},methodDir,sprintf('diagnostic_entry%d',k));
        write_koopman_model_tables(E{k},methodDir,sprintf('koopman_entry%d',k));
    end
    if opt.DisplayDetailedReport && ~isempty(T), disp(T); end
    replayInfo.sections(end+1,1) = "section1p3";
end

if opt.DisplayDetailedReport
    print_saved_reuse_summary(report);
end
fprintf('\nReplay finished. Regenerated sections: %s\n', ...
    strjoin(cellstr(replayInfo.sections),', '));
fprintf('Canonical replay output: %s\n',replayOutRoot);
fprintf('All source method bundles were read only and were NOT overwritten.\n');
end


function methods = final_manuscript_methods_local()
methods = {'modular_koopman_kbf', ...
    'vanilla_sindy', ...
    'physics_embedded_sindy', ...
    'edsi', ...
    'neural_ode_modular', ...
    'llm_prior_sindy'};
end

function tf = is_name_value_name(x,names)
tf = false;
if ~(ischar(x) || (isstring(x) && isscalar(x))), return; end
tf = any(strcmpi(char(string(x)),names));
end

function tf = valid_method_selection(x)
tf = ischar(x) || isstring(x) || iscellstr(x); %#ok<ISCLSTR>
end

function [sourceRoot,methodFiles,legacyFile] = resolve_method_storage_source(source)
methodFiles = strings(0,1);
legacyFile = '';
if exist(source,'file') == 2
    [d,~,ext] = fileparts(source);
    if ~strcmpi(ext,'.mat')
        error('replay_offline_model_experiment_results:InvalidSource', ...
            'Result source file must be a MAT-file: %s',source);
    end
    vars = whos('-file',source);
    names = string({vars.name});
    if any(names=="methodBundle")
        sourceRoot = d;
        methodFiles = string(source);
        return;
    elseif any(names=="replayBundle")
        sourceRoot = d;
        legacyFile = source;
        methodRoot = fullfile(sourceRoot,'method_results');
        methodFiles = discover_method_files(methodRoot);
        return;
    else
        error('replay_offline_model_experiment_results:UnknownMAT', ...
            'MAT-file contains neither methodBundle nor legacy replayBundle: %s',source);
    end
end
if exist(source,'dir') ~= 7
    error('replay_offline_model_experiment_results:MissingSource', ...
        'Replay source does not exist: %s',source);
end
sourceRoot = source;
methodRoot = fullfile(sourceRoot,'method_results');
if exist(methodRoot,'dir') ~= 7
    % Also accept passing method_results itself.
    if strcmpi(last_path_component(sourceRoot),'method_results')
        methodRoot = sourceRoot;
        sourceRoot = fileparts(sourceRoot);
    end
end
methodFiles = discover_method_files(methodRoot);
legacyCandidate = fullfile(sourceRoot,'offline_experiment_part1_replay.mat');
if exist(legacyCandidate,'file') == 2, legacyFile = legacyCandidate; end
end

function files = discover_method_files(methodRoot)
files = strings(0,1);
if exist(methodRoot,'dir') ~= 7, return; end
D = dir(methodRoot);
D = D([D.isdir]);
for k = 1:numel(D)
    if strcmp(D(k).name,'.') || strcmp(D(k).name,'..'), continue; end
    d = fullfile(methodRoot,D(k).name);
    candidate = fullfile(d,'offline_part1_method_replay.mat');
    if exist(candidate,'file') == 2
        files(end+1,1)=string(candidate); %#ok<AGROW>
        continue;
    end
    M = dir(fullfile(d,'*.mat'));
    for j = 1:numel(M)
        p = fullfile(d,M(j).name);
        try
            v = whos('-file',p);
            if any(string({v.name})=="methodBundle")
                files(end+1,1)=string(p); %#ok<AGROW>
                break;
            end
        catch
        end
    end
end
end

function s = last_path_component(p)
[~,s] = fileparts(p);
end

function meta = load_method_bundle_metadata(files)
meta = struct('path',{},'methodName',{},'displayName',{},'order',{});
for k = 1:numel(files)
    S = load_mat_long_path_safe(char(files(k)),'methodBundle');
    if ~isfield(S,'methodBundle') || ~isfield(S.methodBundle,'methodName'), continue; end
    m = struct();
    m.path = char(files(k));
    m.methodName = char(string(S.methodBundle.methodName));
    if ~is_known_replay_method(m.methodName)
        continue;
    end
    if isfield(S.methodBundle,'displayName')
        m.displayName = char(string(S.methodBundle.displayName));
    else
        m.displayName = m.methodName;
    end
    m.order = canonical_method_order(m.methodName);
    meta(end+1)=m; %#ok<AGROW>
end
if isempty(meta), return; end
[~,ix] = sort([meta.order]);
meta = meta(ix);
end

function n = canonical_method_order(name)
order = ["true_physics_oracle","modular_koopman_kbf", ...
    "vanilla_sindy","physics_embedded_sindy","edsi", ...
    "neural_ode_modular","llm_prior_sindy","weak_sindy", ...
    "physics_neural_compositional_sindy","physics_neural_sindy"];
idx = find(strcmpi(string(name),order),1,'first');
if isempty(idx), n = 1000; else, n = idx; end
end

function tf = is_known_replay_method(name)
known = ["true_physics_oracle","modular_koopman_kbf", ...
    "vanilla_sindy","physics_embedded_sindy","edsi", ...
    "neural_ode_modular","llm_prior_sindy","weak_sindy", ...
    "physics_neural_compositional_sindy","physics_neural_sindy"];
tf = any(strcmpi(string(name),known));
end

function [idx,names] = resolve_method_selection(meta,selection)
availNames = string({meta.methodName});
availDisplay = string({meta.displayName});
if ischar(selection) || (isstring(selection) && isscalar(selection))
    if strcmpi(strtrim(char(string(selection))),'all')
        idx = 1:numel(meta);
        names = availNames(:);
        return;
    end
end
req = string(selection);
req = req(:);
idx = zeros(numel(req),1);
names = strings(numel(req),1);
for i = 1:numel(req)
    q = canonical_method_alias(req(i));
    j = find(strcmpi(q,availNames) | strcmpi(req(i),availDisplay),1,'first');
    if isempty(j)
        error('replay_offline_model_experiment_results:MethodNotSaved', ...
            'Requested method "%s" is not saved. Available: %s', ...
            char(req(i)),strjoin(cellstr(availNames),', '));
    end
    idx(i)=j;
    names(i)=availNames(j);
end
% Avoid duplicate selections while preserving requested order.
[~,ia] = unique(idx,'stable');
idx = idx(sort(ia));
names = names(sort(ia));
end

function q = canonical_method_alias(q)
q = string(q);
if strcmpi(q,'neural_ode') || strcmpi(q,'node') || strcmpi(q,'Neural ODE')
    q = "neural_ode_modular";
elseif strcmpi(q,'koopman') || strcmpi(q,'mkbf') || strcmpi(q,'m-kbf') || ...
        strcmpi(q,'modular_koopman') || strcmpi(q,'M-KBF')
    q = "modular_koopman_kbf";
elseif strcmpi(q,'pnc_sindy') || strcmpi(q,'pnc-sindy') || ...
        strcmpi(q,'PNC-SINDy') || strcmpi(q,'Physics-Neural Compositional SINDy')
    q = "physics_neural_compositional_sindy";
elseif strcmpi(q,'pn_sindy') || strcmpi(q,'pn-sindy') || ...
        strcmpi(q,'Physics-Neural SINDy')
    q = "physics_neural_sindy";
elseif strcmpi(q,'weak_sindy') || strcmpi(q,'weak-sindy') || ...
        strcmpi(q,'w-sindy') || strcmpi(q,'wsindy') || strcmpi(q,'Weak SINDy')
    q = "weak_sindy";
elseif strcmpi(q,'v-sindy') || strcmpi(q,'vsindy') || ...
        strcmpi(q,'Vanilla SINDy') || strcmpi(q,'V-SINDy')
    q = "vanilla_sindy";
elseif strcmpi(q,'pe-sindy') || strcmpi(q,'Physics-embedded SINDy')
    q = "physics_embedded_sindy";
elseif strcmpi(q,'edsi') || strcmpi(q,'EDSI') || strcmpi(q,'ED-SINDy')
    q = "edsi";
elseif strcmpi(q,'llm-prior sindy') || strcmpi(q,'llm_prior_sindy') || ...
        strcmpi(q,'LLM-Prior SINDy')
    q = "llm_prior_sindy";
elseif strcmpi(q,'llm-edsi') || strcmpi(q,'llmedsi') || strcmpi(q,'LLM-EDSI')
    q = "llm_edsi";
end
end

function validate_bundle_compatibility(B)
%VALIDATE_BUNDLE_COMPATIBILITY Protect physical comparability without
% requiring identical sweep metadata across independently updated methods.
%
% Independent method bundles can legitimately be produced at different
% times after the user changes sample/noise sweep lists.  Exact equality of
% cfg.sampleCounts/cfg.noiseLevels is therefore too strict for read-only
% replay.  Replay now treats those grids as display metadata and merges the
% ACTUAL saved conditions in memory.  Physical case/scenario mismatches
% remain hard errors.
if numel(B)<=1, return; end
ref = B{1};
gridMismatch = false;
for k = 2:numel(B)
    q = B{k};
    if ~strcmp(char(string(q.caseSnapshot.name)),char(string(ref.caseSnapshot.name)))
        error('replay_offline_model_experiment_results:CaseMismatch', ...
            'Selected method bundles belong to different physical cases.');
    end

    refScenario = saved_scenario_name(ref);
    qScenario = saved_scenario_name(q);
    if strlength(refScenario)>0 && strlength(qScenario)>0 && ~strcmp(refScenario,qScenario)
        error('replay_offline_model_experiment_results:ScenarioMismatch', ...
            ['Selected method bundles belong to different saved test scenarios ', ...
             '(%s versus %s). They cannot be overlaid scientifically.'], ...
            char(refScenario),char(qScenario));
    end

    if q.config.typicalSampleCount ~= ref.config.typicalSampleCount || ...
            ~isequal(q.config.sampleCounts(:).',ref.config.sampleCounts(:).') || ...
            ~same_numeric_vector(q.config.noiseLevels,ref.config.noiseLevels)
        gridMismatch = true;
    end
end
if gridMismatch
    fprintf(['NOTE: Selected method bundles contain different saved typical-N/sample/noise ', ...
        'grid metadata. Replay will NOT reject them. Actual saved conditions are merged ', ...
        'read-only; Sections 1.2/1.3 use the union of available sample/noise points, and ', ...
        'Section 1.1 is rebuilt at one common clean sample count when possible.\n']);
    for kk = 1:numel(B)
        cfgk = B{kk}.config;
        fprintf('  saved grid [%s]: typical N=%g | samples=[%s] | noise%%=[%s]\n', ...
            char(saved_bundle_method_name(B{kk})),double(cfgk.typicalSampleCount), ...
            strtrim(sprintf('%g ',double(cfgk.sampleCounts(:).'))), ...
            strtrim(sprintf('%.4g ',100*double(cfgk.noiseLevels(:).'))));
    end
end
end

function name = saved_bundle_method_name(bundle)
name = "saved_method";
if isfield(bundle,'methodName') && ~isempty(bundle.methodName)
    name = string(bundle.methodName);
elseif isfield(bundle,'displayName') && ~isempty(bundle.displayName)
    name = string(bundle.displayName);
end
end

function name = saved_scenario_name(bundle)
name = "";
if isfield(bundle,'caseSnapshot') && isstruct(bundle.caseSnapshot) && ...
        isfield(bundle.caseSnapshot,'scenario') && isstruct(bundle.caseSnapshot.scenario) && ...
        isfield(bundle.caseSnapshot.scenario,'name') && ~isempty(bundle.caseSnapshot.scenario.name)
    name = string(bundle.caseSnapshot.scenario.name);
end
end

function tf = same_numeric_vector(a,b)
a = double(a(:)); b = double(b(:));
tf = numel(a)==numel(b) && all(abs(a-b)<=1e-14*max(1,max(abs([a;b]))));
end

function [report,c,cfg,truth] = merge_selected_method_bundles(B,selectedNames)
base = B{1};
c = base.caseSnapshot;
cfg = base.config;
report = base.report;
report.methods = selectedNames(:).';
if isfield(base.report,'truth'), truth = base.report.truth; else, truth = []; end
if isempty(truth)
    error('replay_offline_model_experiment_results:MissingTruth', ...
        'Selected method bundle does not contain its saved common truth trajectory.');
end
sections = {'section1p1','section1p2','section1p3'};
for s = 1:numel(sections)
    name = sections{s};
    T = table(); E = cell(0,1);
    for k = 1:numel(B)
        if ~isfield(B{k}.report,name), continue; end
        sec = B{k}.report.(name);
        if isfield(sec,'table') && istable(sec.table) && ~isempty(sec.table)
            % Saved method bundles may come from different reporting versions.
            % In particular, legacy bundles may still contain NRMSE columns,
            % while newer bundles intentionally omit them. Strip report-only
            % NRMSE data before concatenation, then harmonize any remaining
            % schema differences so mixed-version method bundles can replay.
            secTable = strip_nrmse_report_data(sec.table);
            if isempty(T)
                T = secTable;
            else
                T = vertcat_compatible_report_tables(T,secTable);
            end
        end
        if isfield(sec,'evaluations') && ~isempty(sec.evaluations)
            E = [E;sec.evaluations(:)]; %#ok<AGROW>
        end
    end
    [T,E] = sort_combined_section(T,E,name,cfg,selectedNames);
    report.(name).table = T;
    report.(name).evaluations = E;
end
report.reuseSummary = combine_reuse_summary(B,selectedNames);
end

function T = vertcat_compatible_report_tables(A,B)
%VERTCAT_COMPATIBLE_REPORT_TABLES Concatenate replay tables across versions.
%
% Independent method bundles can be created by different code revisions.
% Their report tables may therefore differ by report-only columns (for
% example, legacy NRMSE columns) or by newly added bookkeeping columns.
% Replay is read-only, so normalize the two table schemas in memory before
% vertical concatenation. No source MAT file is modified.

A = strip_nrmse_report_data(A);
B = strip_nrmse_report_data(B);

if isempty(A), T = B; return; end
if isempty(B), T = A; return; end

namesA = A.Properties.VariableNames;
namesB = B.Properties.VariableNames;
allNames = namesA;
for k = 1:numel(namesB)
    if ~ismember(namesB{k},allNames)
        allNames{end+1} = namesB{k}; %#ok<AGROW>
    end
end

% Add missing variables using the opposite table as the type prototype.
for k = 1:numel(allNames)
    name = allNames{k};
    hasA = ismember(name,A.Properties.VariableNames);
    hasB = ismember(name,B.Properties.VariableNames);
    if ~hasA && hasB
        A.(name) = missing_table_variable_like(B.(name),height(A));
    elseif hasA && ~hasB
        B.(name) = missing_table_variable_like(A.(name),height(B));
    end
end

% Normalize common variable types when an old and a new bundle store the
% same logical quantity using compatible but different MATLAB classes.
for k = 1:numel(allNames)
    name = allNames{k};
    [A.(name),B.(name)] = make_table_variables_compatible(A.(name),B.(name));
end

A = A(:,allNames);
B = B(:,allNames);
T = [A;B];
end

function x = missing_table_variable_like(proto,nRows)
% Create a missing-valued table variable with nRows and prototype width.
if isvector(proto)
    tailSize = [1 1];
else
    sz = size(proto);
    tailSize = [1 sz(2:end)];
end
outSize = tailSize;
outSize(1) = nRows;

if isstring(proto)
    x = strings(outSize);
    x(:) = missing;
elseif islogical(proto)
    % Missing logical bookkeeping is conservatively false.
    x = false(outSize);
elseif isnumeric(proto)
    % Report-table numerical quantities are normalized to double below.
    x = nan(outSize);
elseif isdatetime(proto)
    x = NaT(outSize);
elseif isduration(proto)
    x = seconds(nan(outSize));
elseif iscategorical(proto)
    x = categorical(repmat({''},outSize));
    x(:) = categorical(missing);
elseif iscell(proto)
    x = cell(outSize);
else
    % Rare/custom report variables are represented as missing strings for
    % replay only; source bundles remain untouched.
    x = strings(outSize);
    x(:) = missing;
end
end

function [a,b] = make_table_variables_compatible(a,b)
% Coerce compatible representations to a common class for table vertcat.
if strcmp(class(a),class(b))
    return;
end

if isnumeric(a) && isnumeric(b)
    a = double(a);
    b = double(b);
    return;
end

if (isstring(a) || iscellstr_like(a) || ischar(a) || iscategorical(a)) && ...
        (isstring(b) || iscellstr_like(b) || ischar(b) || iscategorical(b))
    a = string(a);
    b = string(b);
    return;
end

if (islogical(a) && isnumeric(b)) || (isnumeric(a) && islogical(b))
    a = double(a);
    b = double(b);
    return;
end

% Last-resort compatibility for report-only metadata. This path should not
% affect the core Method/SampleCount/NoiseLevel/metric columns.
try
    a = string(a);
    b = string(b);
catch
    error('replay_offline_model_experiment_results:IncompatibleReportTableVariable', ...
        'Cannot merge replay-table variables of classes %s and %s.', ...
        class(a),class(b));
end
end

function tf = iscellstr_like(x)
tf = iscell(x) && (isempty(x) || all(cellfun(@(q)ischar(q) || (isstring(q) && isscalar(q)),x(:))));
end

function [T,E] = sort_combined_section(T,E,sectionName,cfg,methodOrder) %#ok<INUSD>
%SORT_COMBINED_SECTION Sort by actual saved condition rather than cfg grid.
% This makes mixed-campaign replay robust when independently saved methods
% were generated with different sample/noise sweep metadata.
if isempty(T) || height(T)~=numel(E), return; end
ord = zeros(height(T),1);
if strcmp(sectionName,'section1p2')
    actualGrid = sort(unique(round(double(T.SampleCount(isfinite(double(T.SampleCount)))))));
elseif strcmp(sectionName,'section1p3')
    actualGrid = sort(unique(double(T.NoiseLevel(isfinite(double(T.NoiseLevel))))));
else
    actualGrid = [];
end
for i = 1:height(T)
    m = string(T.Method(i));
    mi = find(strcmpi(m,methodOrder),1,'first');
    if isempty(mi), mi=999; end
    N = double(T.SampleCount(i));
    noise = double(T.NoiseLevel(i));
    switch sectionName
        case 'section1p1'
            ci = 1;
        case 'section1p2'
            ci = find(actualGrid==round(N),1,'first');
            if isempty(ci), ci=999; end
        otherwise
            ci = find(abs(actualGrid-noise)<=1e-12,1,'first');
            if isempty(ci), ci=999; end
    end
    ord(i) = 1000*ci + mi;
end
[~,ix]=sort(ord);
T=T(ix,:); E=E(ix);
end

function [report,cfg] = harmonize_replay_campaign(report,cfg,selectedNames)
%HARMONIZE_REPLAY_CAMPAIGN Reconstruct display grids from saved results.
%
% Section 1.2 and 1.3 use the union of actual conditions present in the
% merged tables.  Section 1.1 must remain an apples-to-apples comparison, so
% it is rebuilt at a single common CLEAN sample count using either the
% original section1p1 evaluation or the corresponding section1p2 evaluation.

% Union sample grid from actual saved Section 1.2 rows.
if isfield(report,'section1p2') && isfield(report.section1p2,'table') && ...
        istable(report.section1p2.table) && ~isempty(report.section1p2.table) && ...
        ismember('SampleCount',report.section1p2.table.Properties.VariableNames)
    v = double(report.section1p2.table.SampleCount);
    v = v(isfinite(v));
    if ~isempty(v), cfg.sampleCounts = sort(unique(round(v))).'; end
end

% Union noise grid from actual saved Section 1.3 rows.
if isfield(report,'section1p3') && isfield(report.section1p3,'table') && ...
        istable(report.section1p3.table) && ~isempty(report.section1p3.table) && ...
        ismember('NoiseLevel',report.section1p3.table.Properties.VariableNames)
    v = double(report.section1p3.table.NoiseLevel);
    v = v(isfinite(v));
    if ~isempty(v), cfg.noiseLevels = sort(unique(v)).'; end
end

% Find sample counts for which every selected method has a clean saved
% evaluation in either Section 1.1 or Section 1.2.
commonN = [];
for im = 1:numel(selectedNames)
    name = string(selectedNames(im));
    nAvail = clean_saved_sample_counts(report,name);
    if im==1
        commonN = nAvail;
    else
        commonN = intersect(commonN,nAvail,'stable');
    end
end

if isempty(commonN)
    % Keep the already merged Section 1.1 data rather than mixing or
    % inventing conditions.  The user can still replay Sections 1.2/1.3.
    fprintf(['NOTE: No single clean sample count is available for every selected method. ', ...
        'Section 1.1 will use only its already-saved entries; Sections 1.2/1.3 remain fully replayable.\n']);
    return;
end

preferredN = double(cfg.typicalSampleCount);
if any(commonN==preferredN)
    chosenN = preferredN;
else
    [~,j] = min(abs(double(commonN)-preferredN));
    chosenN = double(commonN(j));
    fprintf(['NOTE: Saved bundles do not all contain the configured typical N=%d. ', ...
        'Section 1.1 will be rebuilt at the nearest common clean N=%d.\n'], ...
        round(preferredN),round(chosenN));
end
cfg.typicalSampleCount = chosenN;

[Tnew,Enew,ok] = rebuild_typical_section(report,selectedNames,chosenN);
if ok
    report.section1p1.table = Tnew;
    report.section1p1.evaluations = Enew;
end
end

function nAvail = clean_saved_sample_counts(report,methodName)
nAvail = [];
sections = {'section1p1','section1p2'};
for is = 1:numel(sections)
    s = sections{is};
    if ~isfield(report,s) || ~isfield(report.(s),'table') || ...
            ~istable(report.(s).table) || isempty(report.(s).table), continue; end
    T = report.(s).table;
    if ~all(ismember({'Method','SampleCount'},T.Properties.VariableNames)), continue; end
    idx = strcmpi(string(T.Method),methodName);
    if ismember('NoiseLevel',T.Properties.VariableNames)
        idx = idx & abs(double(T.NoiseLevel))<=1e-14;
    end
    n = double(T.SampleCount(idx));
    n = round(n(isfinite(n)));
    nAvail = union(nAvail,n(:).','stable');
end
nAvail = sort(unique(nAvail));
end

function [Tnew,Enew,ok] = rebuild_typical_section(report,selectedNames,chosenN)
Tnew = table();
Enew = cell(0,1);
ok = true;
for im = 1:numel(selectedNames)
    methodName = string(selectedNames(im));
    [row,ev,found] = find_saved_clean_evaluation(report,'section1p1',methodName,chosenN);
    if ~found
        [row,ev,found] = find_saved_clean_evaluation(report,'section1p2',methodName,chosenN);
    end
    if ~found
        fprintf('NOTE: No saved clean N=%d evaluation found for %s; omitting it from Section 1.1.\n', ...
            round(chosenN),char(methodName));
        ok = false;
        continue;
    end
    if isempty(Tnew)
        Tnew = row;
    else
        Tnew = vertcat_compatible_report_tables(Tnew,row);
    end
    Enew{end+1,1} = ev; %#ok<AGROW>
end
if isempty(Tnew)
    ok = false;
elseif height(Tnew) ~= numel(Enew)
    ok = false;
end
end

function [row,ev,found] = find_saved_clean_evaluation(report,sectionName,methodName,chosenN)
row = table(); ev = []; found = false;
if ~isfield(report,sectionName), return; end
sec = report.(sectionName);
if ~isfield(sec,'table') || ~istable(sec.table) || isempty(sec.table) || ...
        ~isfield(sec,'evaluations') || isempty(sec.evaluations), return; end
T = sec.table;
if ~all(ismember({'Method','SampleCount'},T.Properties.VariableNames)), return; end
idx = strcmpi(string(T.Method),methodName) & round(double(T.SampleCount))==round(chosenN);
if ismember('NoiseLevel',T.Properties.VariableNames)
    idx = idx & abs(double(T.NoiseLevel))<=1e-14;
end
j = find(idx,1,'first');
if isempty(j) || j>numel(sec.evaluations), return; end
row = T(j,:);
ev = sec.evaluations{j};
found = ~isempty(ev);
end

function R = combine_reuse_summary(B,selectedNames)
methodName = strings(0,1); sampleCount=[]; noisePercent=[]; requestCount=[]; firstRequest=strings(0,1);
uniqueEval=0; totalReq=0;
for k = 1:numel(B)
    cache = B{k}.evaluationCache;
    if ~isfield(cache,'entries'), continue; end
    for j = 1:numel(cache.entries)
        e=cache.entries(j);
        methodName(end+1,1)=string(e.displayName); %#ok<AGROW>
        sampleCount(end+1,1)=e.sampleCount; %#ok<AGROW>
        noisePercent(end+1,1)=100*e.noiseLevel; %#ok<AGROW>
        requestCount(end+1,1)=e.requestCount; %#ok<AGROW>
        firstRequest(end+1,1)=string(e.firstRequest); %#ok<AGROW>
        uniqueEval=uniqueEval+1; totalReq=totalReq+e.requestCount;
    end
end
if isempty(methodName)
    RT=table();
else
    RT=table(methodName,sampleCount,noisePercent,requestCount,firstRequest, ...
        'VariableNames',{'Method','SampleCount','NoisePercent','RequestCount','FirstRequest'});
end
R = struct('table',RT,'uniqueEvaluations',uniqueEval,'totalRequests',totalReq, ...
    'reusedRequests',totalReq-uniqueEval,'selectedMethods',selectedNames(:));
end

function tf = has_section(report,name)
tf = isfield(report,name) && isfield(report.(name),'table') && ...
    isfield(report.(name),'evaluations') && ...
    (~isempty(report.(name).table) || ~isempty(report.(name).evaluations));
end

function print_saved_replay_overview(report,c,cfg,projectRoot,truth,selectedNames)
fprintf('\n============================================================\n');
fprintf('Microgrid digital shadow -- Offline Experiment Part 1 [SAVED REPORT]\n');
fprintf('Case: %s\n',char(string(c.name)));
if isfield(c,'scenario') && isstruct(c.scenario) && ...
        isfield(c.scenario,'name') && ~isempty(c.scenario.name)
    scenarioName = char(string(c.scenario.name));
else
    scenarioName = 'saved operating sequence';
end
fprintf('Test scenario: %s\n',scenarioName);
fprintf('Typical N: %d | sample sweep: [%s] | noise sweep (%%): [%s]\n', ...
    cfg.typicalSampleCount,strtrim(sprintf('%d ',cfg.sampleCounts)), ...
    strtrim(sprintf('%.3g ',100*cfg.noiseLevels)));
fprintf('Selected replay methods: %s\n',strjoin(cellstr(selectedNames),', '));
fprintf('============================================================\n\n');
print_reference_case_summary(c,projectRoot);
print_offline_experiment_settings(cfg);
if isfield(truth,'metadata') && isfield(truth.metadata,'solveTimeSeconds')
    if isfield(truth,'networkResidualInf') && ~isempty(truth.networkResidualInf)
        maxRes=max(truth.networkResidualInf);
    else
        maxRes=NaN;
    end
    fprintf('\nSaved common truth trajectory: original solve time %.3f s; max algebraic residual %.3e.\n', ...
        truth.metadata.solveTimeSeconds,maxRes);
end
end

function print_saved_evaluation_list(E,T)
if isempty(E), fprintf('  [no saved evaluations]\n'); return; end
for i=1:numel(E)
    if isempty(E{i}), continue; end
    if istable(T) && height(T)>=i, row=T(i,:); else, row=table(); end
    print_saved_offline_evaluation_detail(E{i},row);
end
end

function N = saved_eval_n(ev,fallback)
N=fallback;
if isfield(ev,'trainInfo') && isstruct(ev.trainInfo) && ...
        isfield(ev.trainInfo,'nSamples') && ~isempty(ev.trainInfo.nSamples)
    N=ev.trainInfo.nSamples;
end
if ~isscalar(N) || ~isfinite(N), N=fallback; end
end

function print_saved_reuse_summary(report)
if ~isfield(report,'reuseSummary') || ~isstruct(report.reuseSummary), return; end
fprintf('\n---------------- SAVED REUSE SUMMARY ----------------\n');
if isfield(report.reuseSummary,'uniqueEvaluations')
    fprintf('Unique trained/evaluated conditions across selected methods: %d\n', ...
        report.reuseSummary.uniqueEvaluations);
end
if isfield(report.reuseSummary,'reusedRequests')
    fprintf('Reused duplicate requests: %d\n',report.reuseSummary.reusedRequests);
end
if isfield(report.reuseSummary,'table') && istable(report.reuseSummary.table) && ...
        ~isempty(report.reuseSummary.table)
    disp(report.reuseSummary.table);
end
end

function s=onoff_local(tf)
if tf, s='ON'; else, s='OFF'; end
end

function root = canonical_case_output_root_local(projectRoot,resultSource,sourceRoot,cfg,explicitRoot)
if nargin >= 5 && strlength(string(explicitRoot)) > 0
    root = char(string(explicitRoot));
    return;
end

% First preference: infer from the supplied replay source. A representative
% seed source has the form <caseRoot>/seed_runs/seed_<id>.
root = char(string(sourceRoot));
[par,leaf] = fileparts(root);
if startsWith(lower(string(leaf)),"seed_")
    [par2,leaf2] = fileparts(par);
    if strcmpi(leaf2,'seed_runs')
        root = par2;
        return;
    end
end

% If method_results itself was supplied, sourceRoot has already been moved to
% its parent by resolve_method_storage_source. Handle a direct method folder
% or MAT-file conservatively by walking up to the nearest known case root.
probe = char(string(resultSource));
if exist(probe,'file') == 2, probe = fileparts(probe); end
for k = 1:6
    [parent,leaf] = fileparts(probe);
    if startsWith(lower(string(leaf)),"offline_model_experiments_")
        root = probe;
        return;
    end
    if isempty(parent) || strcmp(parent,probe), break; end
    probe = parent;
end

% Last fallback uses the configured output folder, stripping any seed suffix.
root = fullfile(projectRoot,'outputs',char(string(cfg.output.folderName)));
[par,leaf] = fileparts(root);
if startsWith(lower(string(leaf)),"seed_")
    [par2,leaf2] = fileparts(par);
    if strcmpi(leaf2,'seed_runs'), root = par2; end
end
end

