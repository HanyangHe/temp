function [Ti,Ni,inds]=TNspace(x,dotx,k,d,n,degr,index,x0,TrainCurBox,coef_alpha,ModelType)

% x: the search pool of the knn
% k: number of knear points
% d: intrinsic dimension
% n: ambient dimension
% degr: highest polynomial degree in GMLS model
% x0: the interested analyzing point

P_norm = eye(size(index,2));% define norm matrix-add by hhy
coef_gamma=0;% norm coefficient-add by hhy

N = size(x,1); %N=1, this is single point input version

if d > n % d <= n
    disp('d must be <= n');
    return;
end
if d == n
    P0_tilde = zeros(n,n,N);  
    for i = 1:N
        P0_tilde(:,:,i) = eye(n);
    end
    return;
end
minterm = nchoosek(degr+d,d);

if k <= minterm % k > D = (d+1)*d/2
    disp(['k must be > ' num2str(minterm)]);
    return;
end

%%% k nearest neighbors
[distances,inds] = knnCPU(x,x0,k); % N*k
% weights = ones(size(distances)) - distances;
% weightsM =diag(weights);

term = size(index,2);

% all index used for function components of vector fields
denorm = sum(index,1); % remove norm effect
ind_alin = zeros(d,1);
for jj = 1:d
    ind_alin(jj) = find((sum(index,1)==1)&(index(jj,:)==1));
end

%% local SVD 

P0_tilde = zeros(n,n);    
tvec_tilde = zeros(d,n); % tvec is d*n*N
tvec = zeros(n,n); % tvec is d*n*N

for i = 1:1
    
    temp = x(inds(i,:),:)'; % n*k
    tempmean = mean(temp,2); % n*1
    temp_rough = temp - repmat(tempmean,1,k); % n*k

    % --weight matrix calculation based on estimated curvature--
    if strcmp(ModelType,'Wendland')
        dvec=distances;
        w=(1-dvec/max(distances)).^4.*(1+4*dvec/max(distances));
        W=diag(w);
    else
        [~,eigM,~] = svd(temp_rough*temp_rough');
        Cur=trace(eigM(d+1:end,d+1:end))/trace(eigM);
        CurNeighbor=TrainCurBox(1,inds(1,1:round(k/1)));
        w=KnnWeightBasedOnShapeIndex([Cur CurNeighbor],temp_rough,TrainCurBox,coef_alpha,ModelType);
        W=diag(w);
    end
    %--------------------------------------------------
    
    % [U,S,~] = svd(temp_rough*weightsM);% !!!weighted svd!!!!
    [U,S,~] = svd(temp_rough*1);
    [~,IX] = sort(diag(S),'descend');
    U = U(:,IX); % rotation matrix

    %%% rough tangent space for representation of geodesic normal
    %%% coordiante
    t_rough = U(:,1:d); % n*d
    n_rough = U(:,d+1:n); % n*(n-d)
    tvec_tilde(:,:,i) = t_rough'; % tvec is d*n*N
    
    %%% correction
    xx = temp'; % k*n, knn points
    %x0 = x2; % center point
    %xnorm = sqrt( sum(sum((xx-repmat(x0,k,1)).^2))/n/k ); % xx is k*n

    dx = xx - repmat(x0,k,1);
    %%yy = dx/xnorm; % k*n normalized data
    %inyy = yy*U; % k*n with leading d in tvec, latter n-d in nvec, intrinsic normalized polynomial
    inyy = dx*U;
    dXT=inyy(:,1:d)';
    dXN=inyy(:,d+1:n);

    %% Phi = [1 yy yy.^2 yy.^3 ...]
    % Phi = ones(k,term); % k*term
    % 
    % %%% contant has 1, deg 1 has d, deg 2 has (d+1)*d/2
    % %%% index =  generatemultiindex(degr,d); % index is d*term
    % for ss = 1:term
    %     for rr = 1:d
    %         Phi(:,ss) = Phi(:,ss).*inyy(:,rr).^index(rr,ss);
    %     end
    % end

    Phi1=ones(term,k);
    for ii=1:d
        indexMatrix=repmat(index(ii,:),k,1)';
        dXT_Matrix=repmat(dXT(ii,:),term,1);
        Phi1=Phi1.*(dXT_Matrix.^indexMatrix);
    end
    Phi=Phi1' ;

    %%% regress for manifolds using PHI inverse, for latter n-d components
    for jj = 1:n-d
        
        % bb = (Phi'*Phi) \ (Phi'*dXN(:,jj)); % regress for all deg
        bb = (P_norm*(Phi'*W*Phi)+coef_gamma*eye(size(index,2)))\(P_norm*Phi'*W*dXN(:,jj));% regularized least square 

        %%bb = bb./xnorm.^(denorm'-1); % term*1, remove normalization effect
             
        for mm = 1:d
            tvec_tilde(mm,:,i) = tvec_tilde(mm,:,i) + bb(ind_alin(mm))*n_rough(:,jj)'; % tvec is d*n*N
        end
    end
    
    %%% generate projection matrix by tangent vectors
    P0_tilde(:,:,i) = tvec_tilde(:,:,i)'*pinv(tvec_tilde(:,:,i)*tvec_tilde(:,:,i)')*tvec_tilde(:,:,i);
    %%% generate orthonormal tangent vectors by projection matrix
    [U2,S2,~] = svd(P0_tilde(:,:,i));
    [~,IX2] = sort(diag(S2),'descend');
    U2 = U2(:,IX2); % eigenvector

    % U direction correction based on the nearest sample point vector field
    nearVecField=dotx(inds(i,1),:)';
    for jj=1:d
        if dot(U2(:,jj),nearVecField)<0
            U2(:,jj)=-U2(:,jj);
        end
    end
    
    Ti=U2(:,1:d);
    Ni=U2(:,d+1:n);
end

P0_tilde = squeeze(permute(P0_tilde,[3,2,1])); % P0 is N*n*n

    
% this code can used to check the function of the algorithm (need to run main fail first)
% seeN=100;
% [T,N]=TNspace_Torus(Xsp_Together',knear,d,n,degr,Xsp_Together(:,seeN)')
% 
% figure
% plot3(Xsp_Together(1,:),Xsp_Together(2,:),Xsp_Together(3,:));
% hold on 
% quiver3([Xsp_Together(1,seeN);Xsp_Together(1,seeN)],[Xsp_Together(2,seeN);Xsp_Together(2,seeN)],[Xsp_Together(3,seeN);Xsp_Together(3,seeN)],[T(1,1);T(1,2)],[T(2,1);T(2,2)],[T(3,1);T(3,2)]);
% hold on
% quiver3([Xsp_Together(1,seeN)],[Xsp_Together(2,seeN)],[Xsp_Together(3,seeN)],[N(1,1)],[N(2,1)],[N(3,1)]);
% hold off