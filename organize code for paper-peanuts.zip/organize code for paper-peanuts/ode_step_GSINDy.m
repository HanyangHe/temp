function x_next = ode_step_GSINDy(t, x, h,n,polyorder,usesine,usePeanutSpecCandyFun,searchPool,f,knear,d,degr,index,Coef_GSINDy,odeOrder,TrainCurBox,coef_alpha,ModelType)
    % ode4_step Perform a single step of the 4th-order Runge-Kutta method.
    % y_next = ode4_step(odefun, t, y, h)
    % odefun: function handle representing the ODE (dy/dt = odefun(t,y))
    % t: current time
    % y: current state (vector)
    % h: time step size
    
    if odeOrder==2
    k1 = odefun(t,x,n,polyorder,usesine,usePeanutSpecCandyFun,Coef_GSINDy);
    [Ti,~,~]=TNspace(searchPool',f,knear,d,n,degr,index,x',TrainCurBox,coef_alpha,ModelType);
    Pi=Ti*pinv(Ti'*Ti)*Ti';
    k1=Pi*k1;

    k2 = odefun(t + h/2, x + h/2*k1,n,polyorder,usesine,usePeanutSpecCandyFun,Coef_GSINDy);
    [Ti,~,~]=TNspace(searchPool',f,knear,d,n,degr,index,(x+ h/2*k1)',TrainCurBox,coef_alpha,ModelType);
    Pi=Ti*pinv(Ti'*Ti)*Ti';
    k2=Pi*k2;

    x_next = x + (h)*(k2);

    elseif odeOrder==4
    k1 = odefun(t,x,n,polyorder,usesine,usePeanutSpecCandyFun,Coef_GSINDy);
    [Ti,~,~]=TNspace(searchPool',f,knear,d,n,degr,index,x',TrainCurBox,coef_alpha,ModelType);
    Pi=Ti*pinv(Ti'*Ti)*Ti';
    k1=Pi*k1;

    k2 = odefun(t + h/2, x + h/2*k1,n,polyorder,usesine,usePeanutSpecCandyFun,Coef_GSINDy);
    [Ti,~,~]=TNspace(searchPool',f,knear,d,n,degr,index,(x+ h/2*k1)',TrainCurBox,coef_alpha,ModelType);
    Pi=Ti*pinv(Ti'*Ti)*Ti';
    k2=Pi*k2;

    k3 = odefun(t + h/2, x + h/2*k2,n,polyorder,usesine,usePeanutSpecCandyFun,Coef_GSINDy);
    [Ti,~,~]=TNspace(searchPool',f,knear,d,n,degr,index,(x+ h/2*k2)',TrainCurBox,coef_alpha,ModelType);
    Pi=Ti*pinv(Ti'*Ti)*Ti';
    k3=Pi*k3;

    k4 = odefun(t + h, x + h*k3,n,polyorder,usesine,usePeanutSpecCandyFun,Coef_GSINDy);
    [Ti,~,~]=TNspace(searchPool',f,knear,d,n,degr,index,(x + h*k3)',TrainCurBox,coef_alpha,ModelType);
    Pi=Ti*pinv(Ti'*Ti)*Ti';
    k4=Pi*k4;

    x_next = x + (h/6)*(k1 + 2*k2 + 2*k3 + k4);
    end


    function dotX=odefun(~,xi,n,polyorder,usesine,usePeanutSpecCandyFun,Coef_SINDy)
        dotX=(poolData_peanut(xi',n,polyorder,usesine,usePeanutSpecCandyFun)*Coef_SINDy)';
    end
end