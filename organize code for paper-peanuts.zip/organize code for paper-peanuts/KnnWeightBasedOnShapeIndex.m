function w=KnnWeightBasedOnShapeIndex(ShapeIndex,Dist,TrainShapeIndexBox,b,ModelType)

% when set below two alpha to 0, this become traditional unweighted case
% alpha_for_ShpIndMean: alpha coefficient (weights decay rate) for the center points which have the average Shape index value
% alpha_for_ShpIndMax: alpha coefficient (weights decay rate) for the center points which have the maximum Shape index value

ShpInd_mean=mean(TrainShapeIndexBox);
x_mean=ShpInd_mean/max(TrainShapeIndexBox);% standarlized

ShpInd_max=max(TrainShapeIndexBox);
x_max=ShpInd_max/max(TrainShapeIndexBox);% standarlized

alphaBOX=zeros(size(ShapeIndex));

% define model
if strcmp(ModelType,'tanh12')
    model=@(b, x) b(1) * tanh(b(2) * x ) ; % Define tanh12 model
elseif strcmp(ModelType,'PWL')
    model=@(b, x) (x<=x_mean).*(b(1).*x/x_mean) + (x>x_mean).*(b(1)+(b(2)-b(1)).*(x-x_mean)./(x_max-x_mean));% Define adaptive piece wise linear model
elseif strcmp(ModelType,'log123')
    model=@(b, x) b(1) * log(max(x + b(2),0)) + b(3); % Define logarithmic model
elseif strcmp(ModelType,'tanh1234')
    model=@(b, x) b(1) * tanh(b(2) * x + b(3)) + b(4); % Define tanh1234 model
elseif strcmp(ModelType,'poly2')
    model=@(b, x) b(1)*x^2 + b(2)*x + b(3); % Define poly2 model
elseif strcmp(ModelType,'none')
    model=@(b, x) 0;
end

for ii=1:length(ShapeIndex)
    x=ShapeIndex(ii)/max(TrainShapeIndexBox);% relative curvature
    alphaBOX(ii)=max(model(b,x),0);
end

alpha=max(alphaBOX);

distNorm=vecnorm(Dist);

w=(1-distNorm/max(distNorm)).^alpha;