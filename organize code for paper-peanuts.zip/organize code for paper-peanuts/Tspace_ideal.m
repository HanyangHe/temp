function T = Tspace_ideal(theta_A, phi_A, R0, L)
    % Define the parameterized equations of the peanut manifold
    R = @(theta, phi) (R0 - L * cos(2 * theta + pi)) .* (R0 - L * cos(2 * phi + pi)) .* cos(phi);
    x1 = @(theta, phi) R(theta, phi) .* cos(theta);
    x2 = @(theta, phi) R(theta, phi) .* sin(theta);
    x3 = @(theta, phi) (R0 - L * cos(2 * phi + pi)) .* sin(phi);

    % Partial derivatives with respect to theta
    dR_dtheta = @(theta, phi) (2 * L * sin(2 * theta + pi)) .* (R0 - L * cos(2 * phi + pi)) .* cos(phi);
    dx1_dtheta = @(theta, phi) dR_dtheta(theta, phi) .* cos(theta) - R(theta, phi) .* sin(theta);
    dx2_dtheta = @(theta, phi) dR_dtheta(theta, phi) .* sin(theta) + R(theta, phi) .* cos(theta);
    dx3_dtheta = @(theta, phi) 0; % x3 is independent of theta

    % Partial derivatives with respect to phi
    dR_dphi = @(theta, phi) (R0 - L * cos(2 * theta + pi)) .* (2 * L * sin(2 * phi + pi)) .* cos(phi) - ...
                            (R0 - L * cos(2 * theta + pi)) .* (R0 - L * cos(2 * phi + pi)) .* sin(phi);
    dx1_dphi = @(theta, phi) dR_dphi(theta, phi) .* cos(theta);
    dx2_dphi = @(theta, phi) dR_dphi(theta, phi) .* sin(theta);
    dx3_dphi = @(theta, phi) 2 * L * sin(2 * phi + pi) .* sin(phi) + ...
                            (R0 - L * cos(2 * phi + pi)) .* cos(phi);

    % Tangent vectors with respect to theta and phi at (theta_A, phi_A)
    T_theta = [dx1_dtheta(theta_A, phi_A), dx2_dtheta(theta_A, phi_A), dx3_dtheta(theta_A, phi_A)];
    T_phi = [dx1_dphi(theta_A, phi_A), dx2_dphi(theta_A, phi_A), dx3_dphi(theta_A, phi_A)];
    
    % Normalize each tangent vector individually
    T_theta = T_theta / norm(T_theta);
    T_phi = T_phi / norm(T_phi);

    % Construct tangent space matrix
    T = [T_theta' T_phi'];
end


