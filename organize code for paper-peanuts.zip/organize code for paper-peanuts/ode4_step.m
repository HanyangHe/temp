function x_next = ode4_step(t, x, h,n,polyorder,usesine,usePeanutSpecCandyFun,Coef_SINDy)
    % ode4_step Perform a single step of the 4th-order Runge-Kutta method.
    % y_next = ode4_step(odefun, t, y, h)
    % odefun: function handle representing the ODE (dy/dt = odefun(t,y))
    % t: current time
    % y: current state (vector)
    % h: time step size

    k1 = odefun(t,x,n,polyorder,usesine,usePeanutSpecCandyFun,Coef_SINDy);
    k2 = odefun(t + h/2, x + h/2*k1,n,polyorder,usesine,usePeanutSpecCandyFun,Coef_SINDy);
    k3 = odefun(t + h/2, x + h/2*k2,n,polyorder,usesine,usePeanutSpecCandyFun,Coef_SINDy);
    k4 = odefun(t + h, x + h*k3,n,polyorder,usesine,usePeanutSpecCandyFun,Coef_SINDy);
    
    x_next = x + (h/6)*(k1 + 2*k2 + 2*k3 + k4);

    function dotX=odefun(~,xi,n,polyorder,usesine,usePeanutSpecCandyFun,Coef_SINDy)
        dotX=(poolData_peanut(xi',n,polyorder,usesine,usePeanutSpecCandyFun)*Coef_SINDy)';
    end
end
