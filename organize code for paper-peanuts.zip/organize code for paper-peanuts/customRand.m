function random_samples = customRand(pdf_func, range, sample_size)
% customRand generates random numbers following a custom distribution
%
% Inputs:
% pdf_func    - Custom probability density function (PDF)
% range       - A 2-element vector [min, max] specifying the range
% sample_size - Number of random samples to generate
%
% Output:
% random_samples - Random numbers generated based on the custom distribution

    % Parameter setup
    x = linspace(range(1), range(2), 1000);  % Generate sufficient points within the specified range
    pdf_values = pdf_func(x);  % Evaluate the custom PDF

    % Normalize the PDF
    pdf_normalized = pdf_values / sum(pdf_values);  % Normalize so that the total sum equals 1

    % Compute the cumulative distribution function (CDF)
    cdf = cumsum(pdf_normalized);
    cdf = cdf / max(cdf);  % Normalize the CDF to range [0, 1]

    % Generate uniformly distributed random numbers
    uniform_random_numbers = rand(1,sample_size);

    % Use interpolation to compute the inverse CDF
    random_samples = interp1(cdf, x, uniform_random_numbers, 'linear', 'extrap');
end