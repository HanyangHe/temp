function [eOffTorus]=OffPeanutError(X,theta_A,phi_A,R0,L)
% X is n-by-1 prediction point; n is ambient dimension
% Xture is n-by-1 the reference point; n is ambient dimension
% thetaPhi_true is r-by-1 reference point; r is ambient dimension in orginal Polar coordinate system

x1_B = X(1,:); 
x2_B = X(2,:); 
x3_B = X(3,:); 

R = @(theta, phi) (R0 - L * cos(2 * theta + pi)) .* (R0 - L * cos(2 * phi + pi)) .* cos(phi);
x1 = @(theta, phi) R(theta, phi) .* cos(theta);
x2 = @(theta, phi) R(theta, phi) .* sin(theta);
x3 = @(theta, phi) (R0 - L * cos(2 * phi + pi)) .* sin(phi);

x1_A = x1(theta_A, phi_A);
x2_A = x2(theta_A, phi_A);
x3_A = x3(theta_A, phi_A);

dR_dtheta = @(theta, phi) -2 * L * sin(2 * theta + pi) .* (R0 - L * cos(2 * phi + pi)) .* cos(phi);
dx1_dtheta = @(theta, phi) dR_dtheta(theta, phi) .* cos(theta) - R(theta, phi) .* sin(theta);
dx2_dtheta = @(theta, phi) dR_dtheta(theta, phi) .* sin(theta) + R(theta, phi) .* cos(theta);
dx3_dtheta = @(theta, phi) 0; 

dR_dphi = @(theta, phi) (R0 - L * cos(2 * theta + pi)) .* (-2 * L * sin(2 * phi + pi)) .* cos(phi) - ...
                        (R0 - L * cos(2 * theta + pi)) .* (R0 - L * cos(2 * phi + pi)) .* sin(phi);
dx1_dphi = @(theta, phi) dR_dphi(theta, phi) .* cos(theta);
dx2_dphi = @(theta, phi) dR_dphi(theta, phi) .* sin(theta);
dx3_dphi = @(theta, phi) 2 * L * sin(2 * phi + pi) .* sin(phi) + ...
                        (R0 - L * cos(2 * phi + pi)) .* cos(phi);

T_theta = [dx1_dtheta(theta_A, phi_A), dx2_dtheta(theta_A, phi_A), dx3_dtheta(theta_A, phi_A)];
T_phi = [dx1_dphi(theta_A, phi_A), dx2_dphi(theta_A, phi_A), dx3_dphi(theta_A, phi_A)];

n_A = cross(T_theta, T_phi);

n_A_magnitude = norm(n_A);

AB = [x1_B - x1_A, x2_B - x2_A, x3_B - x3_A];

eOffTorus = abs(dot(AB, n_A) / n_A_magnitude);
