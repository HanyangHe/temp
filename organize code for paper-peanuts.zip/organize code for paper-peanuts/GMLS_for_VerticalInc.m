function dXNamb=GMLS_for_VerticalInc(indices,Dist,Ti,Ni,dXTamb,index,knear,d,TrainCurBox,coef_alpha,ModelType)
    % P_norm = eye(size(index,2));% define norm matrix-add by hhy
    % coef_gamma=1e-6;% norm coefficient-add by hhy

    % --weight matrix calculation based on estimated curvature--
    if strcmp(ModelType,'Wendland')
        distances=vecnorm(Dist);
        dvec=distances;
        w=(1-dvec/max(distances)).^4.*(1+4*dvec/max(distances));
        W=diag(w);
    else
        [~,eigM,~] = svd(Dist*Dist');
        Cur=eigM(end,end)/trace(eigM);
        CurNeighbor=TrainCurBox(1,indices(1,1:round(knear/1)));
        w=KnnWeightBasedOnShapeIndex([Cur CurNeighbor],Dist,TrainCurBox,coef_alpha,ModelType);
        W=diag(w);
    end
    %--------------------------------------------------
    
    dXTint=Ti'*dXTamb;
    
    term = size(index,2);
    % ==========Calculate k_mls for prediction=============
    Pm = ones(term,knear); % term*knear
    dX_BOX=Dist;%n*k

    dX_TH_BOX=Ti'*dX_BOX;

    for i=1:d
        indexMatrix=repmat(index(i,:),knear,1)';
        dXT_Matrix=repmat(dX_TH_BOX(i,:),term,1);
        Pm=Pm.*(dXT_Matrix.^indexMatrix);
    end

    dX_NV_BOX=Ni'*dX_BOX;
    k_mls=dX_NV_BOX*W*Pm'/(Pm*W*Pm');% weighted gmls

    % ======================predict dX_NV=====================
    P=ones(term,1);

    for i=1:d
        indexMatrix=repmat(index(i,:),1,1)';
        dXT_Matrix=repmat(dXTint(i,:),term,1);
        P=P.*(dXT_Matrix.^indexMatrix);
    end

    dXNint=k_mls*P;
    dXNamb=Ni*dXNint;