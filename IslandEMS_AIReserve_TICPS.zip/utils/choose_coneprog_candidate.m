function useB = choose_coneprog_candidate(xA,flagA,outA,xB,flagB,outB)
%CHOOSE_CONEPROG_CANDIDATE Prefer converged/finite, then better dual quality.
useB=false;
validA=~isempty(xA) && all(isfinite(xA(:)));
validB=~isempty(xB) && all(isfinite(xB(:)));
if validB && ~validA, useB=true; return; end
if ~validB, return; end
if flagB>0 && flagA<=0, useB=true; return; end
if flagA>0 && flagB<=0, return; end
qa=quality(outA); qb=quality(outB);
if qb < qa, useB=true; end
end

function q=quality(out)
p=getfieldnum(out,'primalfeasibility',Inf);
d=getfieldnum(out,'dualfeasibility',Inf);
g=getfieldnum(out,'dualitygap',Inf);
q=max([p,d,g]);
end
function v=getfieldnum(s,n,default)
v=default;
if isstruct(s) && isfield(s,n)
    q=s.(n);
    if isnumeric(q) && ~isempty(q) && isfinite(q(1))
        v=double(q(1));
    end
end
end
