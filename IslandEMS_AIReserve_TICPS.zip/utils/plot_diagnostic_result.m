function plot_diagnostic_result(result,cfg)
%PLOT_DIAGNOSTIC_RESULT In-memory diagnostic plots; never saves files.
% Intended for smoke/debug runs only.
f0=cfg.frequency.nominal_Hz;
dfLim=cfg.frequency.securityDeviation_Hz;
rLim=cfg.frequency.securityRoCoF_Hz_s;
spH=cfg.simulation.samplePerHour;

% 1) Frequency and RoCoF.
tf=(0:numel(result.freq_Hz)-1)/spH;
figure('Name','Diagnostic - frequency');
tiledlayout(2,1);
nexttile; hold on;
plot(tf,result.freq_Hz,'LineWidth',1.2);
if isfield(result,'freqAll_Hz') && ~isempty(result.freqAll_Hz)
    plot(tf,result.freqAll_Hz.','LineWidth',0.6);
end
yline(f0+dfLim,'k--'); yline(f0-dfLim,'k--'); yline(f0,'k:');
xlim([0 24]); ylabel('Frequency (Hz)'); grid on; box on;
legend('CoI','Location','best');
nexttile;
rocof=diff(result.freq_Hz)*spH/3600; % dt = 3600/spH s
tr=(0:numel(rocof)-1)/spH;
plot(tr,rocof,'LineWidth',1.0); hold on;
yline(rLim,'k--'); yline(-rLim,'k--');
xlim([0 24]); xlabel('Time (h)'); ylabel('RoCoF (Hz/s)'); grid on; box on;

% 2) Aggregate powers and individual DG outputs.
t=(0:size(result.P_DG_MW,2)-1)/spH;
figure('Name','Diagnostic - powers');
tiledlayout(2,1);
nexttile; hold on;
plot(t,result.P_DG_MW.','LineWidth',1.0);
for g=1:numel(result.DG_rating_MW), yline(result.DG_rating_MW(g),'--'); end
xlim([0 24]); ylabel('DG power (MW)'); grid on; box on;
nexttile; hold on;
plot(t,-real(result.totalLoad_MW),'LineWidth',1.0);
plot(t,real(result.totalGeneration_MW),'LineWidth',1.0);
plot(t,real(result.totalPV_MW),'LineWidth',1.0);
plot(t,real(result.totalBattery_MW),'LineWidth',1.0);
xlim([0 24]); xlabel('Time (h)'); ylabel('Power (MW)'); grid on; box on;
legend('Demand','Generation','PV','Battery','Location','best');

% 3) Storage SoC.
figure('Name','Diagnostic - state of charge'); hold on;
ts=(0:size(result.soc,2)-1)/spH;
plot(ts,result.soc.','LineWidth',0.8);
yline(cfg.storage.SOCmin,'k--'); yline(cfg.storage.SOCmax,'k--');
xlim([0 24]); ylim([0 1]); xlabel('Time (h)'); ylabel('SoC'); grid on; box on;

% 4) Network security envelopes.
figure('Name','Diagnostic - network security');
tiledlayout(2,1);
nexttile;
v=abs(result.voltage_pu); plot(t,min(v,[],1),'LineWidth',1.0); hold on;
plot(t,max(v,[],1),'LineWidth',1.0); yline(cfg.network.Vmin_pu,'k--'); yline(cfg.network.Vmax_pu,'k--');
xlim([0 24]); ylabel('|V| (p.u.)'); grid on; box on; legend('Min bus','Max bus','Location','best');
nexttile;
ratio=abs(result.current_pu)./result.lineLimits_pu(:);
plot(t,max(ratio,[],1),'LineWidth',1.0); hold on; yline(1,'k--');
xlim([0 24]); xlabel('Time (h)'); ylabel('Max |I| / limit'); grid on; box on;

% 5) Solver diagnostics and timing.
if isfield(result,'solver') && isfield(result.solver,'coneprogDiagnostics') && ...
        ~isempty(result.solver.coneprogDiagnostics)
    C=result.solver.coneprogDiagnostics; C=C(~cellfun(@isempty,C));
    if ~isempty(C)
        D=[C{:}]; k=[D.step]; ef=[D.exitflag]; man=[D.maxManualConstraintViolation];
        pri=[D.primalFeasibility]; dual=[D.dualFeasibility]; rel=[D.relativeGap];
        figure('Name','Diagnostic - coneprog'); tiledlayout(3,1);
        nexttile; stairs(k,ef,'LineWidth',1.0); yline(-7,'k--'); ylabel('Exit flag'); grid on; box on;
        nexttile; hold on; h=[]; lab={};
        if any(isfinite(man)), h(end+1)=semilogy(k,max(man,eps),'LineWidth',1.0); lab{end+1}='Manual'; end %#ok<AGROW>
        if any(isfinite(pri)), h(end+1)=semilogy(k,max(pri,eps),'LineWidth',1.0); lab{end+1}='Primal'; end %#ok<AGROW>
        if any(isfinite(dual)), h(end+1)=semilogy(k,max(dual,eps),'LineWidth',1.0); lab{end+1}='Dual'; end %#ok<AGROW>
        if any(isfinite(rel)), h(end+1)=semilogy(k,max(rel,eps),'LineWidth',1.0); lab{end+1}='Gap'; end %#ok<AGROW>
        ylabel('Residual'); grid on; box on;
        if ~isempty(h), legend(h,lab,'Location','best'); end
        nexttile; plot(k,[D.solveTime_s],'LineWidth',1.0); xlabel('MPC decision step'); ylabel('Solve time (s)'); grid on; box on;
    end
end
end
