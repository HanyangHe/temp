function fcoi = compute_coi_frequency(freqMatrix,dgRatingsMW,H_s)
%COMPUTE_COI_FREQUENCY Inertia-weighted DG center-of-inertia frequency.
% freqMatrix: [nFrequencyStates x nSamples]. The first nDG rows correspond
% to synchronous DGs in the current simulator. Only those DG states are
% used because GFM virtual-inertia constants are not defined in this model.

nDG=numel(dgRatingsMW);
if nDG==0
    fcoi=mean(freqMatrix,1,'omitnan');
    return;
end
if size(freqMatrix,1)<nDG
    error('freqMatrix has fewer rows than the number of DG ratings.');
end
if isscalar(H_s)
    Hvec=H_s*ones(nDG,1);
else
    Hvec=H_s(:);
    if numel(Hvec)~=nDG
        error('H_s must be scalar or have one entry per DG.');
    end
end
w=Hvec.*dgRatingsMW(:);
if sum(w)<=0
    fcoi=mean(freqMatrix(1:nDG,:),1,'omitnan');
else
    fcoi=sum(freqMatrix(1:nDG,:).*w,1,'omitnan')/sum(w);
end
end
