function beq = update_radial_mpc_beq(cache,Sload)
%UPDATE_RADIAL_MPC_BEQ Update only the load-injection RHS of cached Aeq.
% Valid for the radial BFM structure used by 10bus/18bus/33bus.
Kday = size(Sload,2);
Nbus = cache.Nbus;
rowsPerStage = cache.rowsPerStage;
if rowsPerStage ~= 3*Nbus
    error('Unexpected radial equality-row layout: rows/stage=%d, expected %d.', ...
        rowsPerStage,3*Nbus);
end
if size(Sload,1) < Nbus
    error('Sload has %d buses; cache expects %d.',size(Sload,1),Nbus);
end
beq = cache.beqTemplate;
outBus = cache.outBusOrder(:);
pLocal = (1:3:3*Nbus).';
qLocal = pLocal + 1;
for k=1:Kday
    off = (k-1)*rowsPerStage;
    beq(off+pLocal) = -real(Sload(outBus,k));
    beq(off+qLocal) = -imag(Sload(outBus,k));
end
end
