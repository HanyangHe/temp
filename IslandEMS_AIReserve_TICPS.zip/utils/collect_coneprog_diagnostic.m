function d = collect_coneprog_diagnostic(output,exitflag,step,solveTime_s, ...
    x,A,b,Aeq,beq,lb,ub,Asc,bsc,dsc,gamma,computeManual)
%COLLECT_CONEPROG_DIAGNOSTIC Capture solver quality and independent residuals.
% This helper is deliberately tolerant of MATLAB-version differences in
% coneprog's output structure. Missing fields are reported as NaN.

d = struct();
d.step = step;
d.exitflag = exitflag;
d.solveTime_s = solveTime_s;
d.message = string(get_field_ci(output,{'message'},''));
d.iterations = get_scalar_ci(output,{'iterations','iteration'},NaN);
d.primalFeasibility = get_scalar_ci(output, ...
    {'primalfeasibility','primal_feasibility','constrviolation','constraintviolation'},NaN);
d.dualFeasibility = get_scalar_ci(output,{'dualfeasibility','dual_feasibility'},NaN);
d.dualityGap = get_scalar_ci(output,{'dualitygap','duality_gap','gap'},NaN);
d.relativeGap = get_scalar_ci(output,{'relativegap','relative_gap','relgap'},NaN);
% coneprog exposes `dualitygap` rather than a separate relative-gap field in
% many MATLAB releases. Use that native stopping metric when relativeGap is
% unavailable so diagnostics are not silently NaN.
if ~isfinite(d.relativeGap) && isfinite(d.dualityGap)
    d.relativeGap = abs(d.dualityGap);
end
d.linearSolver = string(get_field_ci(output,{'linearsolver'},''));
if nargin < 16 || isempty(computeManual), computeManual = true; end
d.manualResidualComputed = logical(computeManual);
d.diagnosticTime_s = NaN; % filled by the caller, which owns the timer

% Independent residual reconstruction is relatively expensive for a 96-stage
% SOCP.  Evaluate it only for non-converged/warning exits, which is exactly
% where it is needed to diagnose exitflag -7.  Successful solves rely on
% coneprog's own feasibility fields.
if exitflag>0 || ~computeManual
    d.maxIneqViolation=NaN; d.maxEqViolation=NaN;
    d.maxLowerBoundViolation=NaN; d.maxUpperBoundViolation=NaN;
    d.maxSOCViolation=NaN; d.maxManualConstraintViolation=NaN;
    d.isConverged=exitflag>0; d.isMinus7=exitflag==-7;
    d.isHardFailure=~(exitflag>0 || exitflag==-7);
    return;
end

% Hard failures can return an empty x; keep the diagnostic record valid and
% let check_solver_solution raise the project-specific error.
if isempty(x) || any(~isfinite(x(:)))
    d.maxIneqViolation=NaN; d.maxEqViolation=NaN;
    d.maxLowerBoundViolation=NaN; d.maxUpperBoundViolation=NaN;
    d.maxSOCViolation=NaN; d.maxManualConstraintViolation=NaN;
    d.isConverged = exitflag>0; d.isMinus7=exitflag==-7;
    d.isHardFailure=~(exitflag>0 || exitflag==-7);
    return;
end
d.maxIneqViolation = max_violation(A*x-b);
d.maxEqViolation = max_abs(Aeq*x-beq);
d.maxLowerBoundViolation = max_violation(lb-x);
d.maxUpperBoundViolation = max_violation(x-ub);

% Independent second-order-cone residual: ||A*x-b|| <= d'*x-gamma.
d.maxSOCViolation = 0;
if nargin>=12 && ~isempty(Asc)
    vals=zeros(numel(Asc),1);
    for k=1:numel(Asc)
        lhs=norm(Asc{k}*x-bsc{k});
        rhs=dsc{k}'*x-gamma{k};
        vals(k)=max(lhs-rhs,0);
    end
    d.maxSOCViolation=max(vals,[],'omitnan');
end

d.maxManualConstraintViolation=max([d.maxIneqViolation,d.maxEqViolation, ...
    d.maxLowerBoundViolation,d.maxUpperBoundViolation,d.maxSOCViolation],[],'omitnan');
d.isConverged = exitflag>0;
d.isMinus7 = exitflag==-7;
d.isHardFailure = ~(exitflag>0 || exitflag==-7);
end

function v=max_violation(z)
if isempty(z), v=0; return; end
z=z(isfinite(z));
if isempty(z), v=NaN; else, v=max([0;z(:)]); end
end

function v=max_abs(z)
if isempty(z), v=0; return; end
z=z(isfinite(z));
if isempty(z), v=NaN; else, v=max(abs(z(:))); end
end

function v=get_scalar_ci(s,names,defaultValue)
v=defaultValue;
if ~isstruct(s), return; end
f=fieldnames(s);
for i=1:numel(names)
    j=find(strcmpi(f,names{i}),1);
    if ~isempty(j)
        q=s.(f{j});
        if isnumeric(q) && ~isempty(q)
            q=q(1);
            if isfinite(q), v=double(q); end
        end
        return;
    end
end
end

function v=get_field_ci(s,names,defaultValue)
v=defaultValue;
if ~isstruct(s), return; end
f=fieldnames(s);
for i=1:numel(names)
    j=find(strcmpi(f,names{i}),1);
    if ~isempty(j), v=s.(f{j}); return; end
end
end
