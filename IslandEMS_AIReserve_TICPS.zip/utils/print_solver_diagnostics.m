function T = print_solver_diagnostics(result,cfg)
%PRINT_SOLVER_DIAGNOSTICS Print a compact quality audit for coneprog solves.
T=table();
if ~isfield(result,'solver') || ~isfield(result.solver,'coneprogDiagnostics') || ...
        isempty(result.solver.coneprogDiagnostics)
    fprintf('\nNo coneprog diagnostic history is available.\n');
    return;
end
C=result.solver.coneprogDiagnostics;
C=C(~cellfun(@isempty,C));
if isempty(C), fprintf('\nNo coneprog diagnostics were recorded.\n'); return; end
D=[C{:}];

step=[D.step].'; exitflag=[D.exitflag].'; solveTime_s=[D.solveTime_s].';
iterations=[D.iterations].'; primal=[D.primalFeasibility].'; dual=[D.dualFeasibility].';
gap=[D.dualityGap].'; relGap=[D.relativeGap].'; manual=[D.maxManualConstraintViolation].';
ineq=[D.maxIneqViolation].'; eq=[D.maxEqViolation].'; soc=[D.maxSOCViolation].';
T=table(step,exitflag,solveTime_s,iterations,primal,dual,gap,relGap,manual,ineq,eq,soc);

n=numel(D); nConv=sum(exitflag>0); n7=sum(exitflag==-7); nHard=sum(~(exitflag>0 | exitflag==-7));

% Conditioning-retry summary (fields are present in revised runs).
retryCount=0; retryImproved=0;
if isfield(D,'retryUsed')
    retryUsed=[D.retryUsed].'; retryCount=sum(retryUsed);
    if retryCount>0 && isfield(D,'primaryDualFeasibility') && isfield(D,'retryDualFeasibility')
        pd=[D.primaryDualFeasibility].'; rd=[D.retryDualFeasibility].';
        retryImproved=sum(retryUsed & isfinite(pd) & isfinite(rd) & rd<pd);
    end
end
rt=cfg.diagnostics.solver.residualTolerance;
dt=cfg.diagnostics.solver.dualTolerance;
gt=cfg.diagnostics.solver.relativeGapTolerance;
% Manual residuals are intentionally reconstructed for only a small
% subset of -7 exits to keep 96-stage diagnostics inexpensive.  When absent,
% assess numerical tightness from coneprog's native feasibility/gap fields.
manualTight = isnan(manual) | manual<=rt;
primalTight = isnan(primal) | primal<=rt;
dualTight = isnan(dual) | dual<=dt;
gapTight = isnan(relGap) | relGap<=gt;
numTight = manualTight & primalTight & dualTight & gapTight;

fprintf('\n=== coneprog numerical diagnostic ===\n');
fprintf('  solves                 : %d\n',n);
fprintf('  converged exitflag > 0 : %d (%.1f%%)\n',nConv,100*nConv/n);
fprintf('  exitflag -7 warnings   : %d (%.1f%%)\n',n7,100*n7/n);
fprintf('  hard failures          : %d (%.1f%%)\n',nHard,100*nHard/n);
if retryCount>0
    fprintf('  conditioning retries   : %d (dual improved in %d)\n',retryCount,retryImproved);
end
fprintf('  max manual residual    : %.3e\n',max(manual,[],'omitnan'));
fprintf('  max primal feasibility : %.3e\n',max(primal,[],'omitnan'));
fprintf('  max dual feasibility   : %.3e\n',max(dual,[],'omitnan'));
fprintf('  max relative gap       : %.3e\n',max(relGap,[],'omitnan'));
if n7>0
    idx=exitflag==-7;
    fprintf('  -7 numerically tight*  : %d/%d\n',sum(numTight(idx)),sum(idx));
    fprintf('  * thresholds: manual/primal %.1e, dual %.1e, relative gap %.1e\n',rt,dt,gt);
    if cfg.diagnostics.solver.printMinus7Table
        fprintf('\n  Steps with exitflag -7:\n');
        disp(T(idx,{'step','solveTime_s','primal','dual','relGap','manual','ineq','eq','soc'}));
    end
end
fprintf('=====================================\n');
end
