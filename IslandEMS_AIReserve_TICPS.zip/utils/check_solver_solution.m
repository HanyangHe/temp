function check_solver_solution(x,exitflag,solverName,context)
%CHECK_SOLVER_SOLUTION Fail on unusable optimizer output; warn on non-success.
% The inherited experiments historically accepted exitflag -7 when a
% finite cone-program iterate was returned. Preserve that convention as a
% warning-level accepted state while preventing empty/NaN vectors from
% propagating into the physical simulation.
if nargin<4, context=''; end
if isempty(x) || any(~isfinite(x(:)))
    error('%s returned an empty/nonfinite decision vector (%s), exitflag=%g.', ...
        solverName,context,exitflag);
end
if ~(exitflag>0 || exitflag==-7)
    warning('%s did not report a successful exit (%s), exitflag=%g.', ...
        solverName,context,exitflag);
end
end
