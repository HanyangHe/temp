function validate_config(cfg)
%VALIDATE_CONFIG Fail early on unsupported or internally inconsistent settings.

mustBePositiveScalar(cfg.base.S_VA,'cfg.base.S_VA');
mustBePositiveScalar(cfg.base.V_V,'cfg.base.V_V');
if abs(cfg.base.S_VA-1e6)>1e-6
    error(['The inherited network/dynamic equations rely on the numerical ', ...
        'equivalence of per-unit power and MW at Sbase=1 MVA. Keep cfg.base.S_VA=1e6 ', ...
        'unless the entire mixed-unit formulation is generalized.']);
end
mustBePositiveScalar(cfg.simulation.samplePerHour,'cfg.simulation.samplePerHour');

% Output persistence is explicit so test launchers cannot accidentally fill
% the formal outputs/ directory. Older configurations without this field are
% still accepted and default to saving in run_experiments.m.
if isfield(cfg,'output') && isfield(cfg.output,'saveResults')
    if ~isscalar(cfg.output.saveResults) || ...
            ~(islogical(cfg.output.saveResults) || isnumeric(cfg.output.saveResults))
        error('cfg.output.saveResults must be a logical scalar.');
    end
end

% Revised time-base contract. The current study uses a 24-h horizon with
% equal MPC decision and prediction steps. The load/PV KRR predictors remain
% hourly and their hourly anchors are resampled onto the finer MPC grid
% outside the optimizer.
requiredFields = {'decisionInterval_h','predictionStep_h','horizon_h', ...
    'decisionLevelSteps','predictionHorizon'};
for k=1:numel(requiredFields)
    if ~isfield(cfg.mpc,requiredFields{k})
        error('Missing cfg.mpc.%s.',requiredFields{k});
    end
end
mustBePositiveScalar(cfg.mpc.decisionInterval_h,'cfg.mpc.decisionInterval_h');
mustBePositiveScalar(cfg.mpc.predictionStep_h,'cfg.mpc.predictionStep_h');
mustBePositiveScalar(cfg.mpc.horizon_h,'cfg.mpc.horizon_h');
if abs(cfg.mpc.decisionInterval_h-cfg.mpc.predictionStep_h) > 1e-12
    error(['Current study requires MPC decisionInterval_h == predictionStep_h ', ...
        'so every predicted stage corresponds to one possible receding-horizon decision step.']);
end
if abs(cfg.mpc.horizon_h-24) > 1e-12
    error('Current engine supports a 24-h MPC horizon.');
end
nDecisionExpected = round(24/cfg.mpc.decisionInterval_h);
nPredExpected = round(cfg.mpc.horizon_h/cfg.mpc.predictionStep_h);
if abs(nDecisionExpected*cfg.mpc.decisionInterval_h-24) > 1e-10
    error('24 h must be an integer multiple of cfg.mpc.decisionInterval_h.');
end
if abs(nPredExpected*cfg.mpc.predictionStep_h-cfg.mpc.horizon_h) > 1e-10
    error('cfg.mpc.horizon_h must be an integer multiple of cfg.mpc.predictionStep_h.');
end
if cfg.mpc.decisionLevelSteps ~= nDecisionExpected
    error('cfg.mpc.decisionLevelSteps must equal 24/decisionInterval_h (= %d).',nDecisionExpected);
end
if cfg.mpc.predictionHorizon ~= nPredExpected
    error('cfg.mpc.predictionHorizon must equal horizon_h/predictionStep_h (= %d).',nPredExpected);
end
if ~isfield(cfg.forecast,'nativeStep_h')
    error('Missing cfg.forecast.nativeStep_h.');
end
mustBePositiveScalar(cfg.forecast.nativeStep_h,'cfg.forecast.nativeStep_h');
stride = cfg.forecast.nativeStep_h/cfg.mpc.decisionInterval_h;
if abs(stride-round(stride)) > 1e-12
    error(['cfg.forecast.nativeStep_h must be an integer multiple of the MPC ', ...
        'decision interval for the inherited hourly-lag forecasting model.']);
end
if abs(cfg.forecast.nativeStep_h-1.0) > 1e-12
    error('The inherited load/PV KRR models are hourly; keep cfg.forecast.nativeStep_h = 1 h.');
end
if ~isfield(cfg.forecast,'interpolationMethod') || ...
        ~any(strcmpi(cfg.forecast.interpolationMethod,{'linear','pchip'}))
    error('cfg.forecast.interpolationMethod must be ''linear'' or ''pchip''.');
end

if ~strcmpi(cfg.ai.modelType,'krr')
    error('Current implementation supports cfg.ai.modelType=''krr'' only.');
end
if ~isfield(cfg.ai,'learningTarget') || ~strcmpi(cfg.ai.learningTarget,'frequency-stress-response')
    error('cfg.ai.learningTarget must be ''frequency-stress-response''.');
end
if ~isfield(cfg.ai,'modelRoot') || ~isfield(cfg.ai,'modelFileName') || ...
        isempty(cfg.ai.modelRoot) || isempty(cfg.ai.modelFileName)
    error('Per-grid AI modelRoot/modelFileName configuration is missing.');
end
if ~isfield(cfg.ai,'datasetRoot') || ~isfield(cfg.ai,'datasetFileName') || ...
        isempty(cfg.ai.datasetRoot) || isempty(cfg.ai.datasetFileName)
    error('Per-grid AI datasetRoot/datasetFileName configuration is missing.');
end
if ~isfield(cfg.ai,'response') || ~strcmpi(cfg.ai.response.securityTarget,'coi')
    error('Formal AI response target must use CoI/system frequency.');
end
if ~strcmpi(cfg.ai.response.scheduleMode,'balanced-random')
    error('cfg.ai.response.scheduleMode must be ''balanced-random''.');
end
if ~isscalar(cfg.frequency.dgRa_pu) || ~isfinite(cfg.frequency.dgRa_pu) || cfg.frequency.dgRa_pu<0 || ...
        ~isscalar(cfg.frequency.dgXdPrime_pu) || ~isfinite(cfg.frequency.dgXdPrime_pu) || cfg.frequency.dgXdPrime_pu<=0
    error('DG Ra/XdPrime parameters must be finite with Ra>=0 and XdPrime>0.');
end
if ~any(strcmpi(cfg.frequency.dgImpedanceBase,{'system','machine'}))
    error('cfg.frequency.dgImpedanceBase must be ''system'' or ''machine''.');
end

if cfg.frequency.dgPmin_pu < 0 || cfg.frequency.dgPmax_pu > 1 || ...
        cfg.frequency.dgPmin_pu >= cfg.frequency.dgPmax_pu
    error('DG active-power bounds must satisfy 0 <= Pmin < Pmax <= 1.');
end
if cfg.frequency.reserveDeviation_Hz < 0 || cfg.frequency.reserveRoCoF_Hz_s < 0
    error('Reserve-design frequency thresholds must be nonnegative.');
end
if cfg.frequency.securityDeviation_Hz <= 0 || cfg.frequency.securityRoCoF_Hz_s <= 0
    error('Security-evaluation frequency limits must be positive.');
end
if cfg.ai.alphaMin < 0 || cfg.ai.alphaMax <= cfg.ai.alphaMin
    error('AI reserve-ratio bounds must satisfy 0 <= alphaMin < alphaMax.');
end
if cfg.ai.fallbackAlpha < cfg.ai.alphaMin || cfg.ai.fallbackAlpha > cfg.ai.alphaMax
    error('cfg.ai.fallbackAlpha must lie inside [alphaMin, alphaMax].');
end
if cfg.ai.fallbackAlpha < 1
    warning('OOD fallback alpha < 1 does not restore the conventional physics reserve.');
end
if cfg.ai.calibrationRisk <= 0 || cfg.ai.calibrationRisk >= 1
    error('cfg.ai.calibrationRisk must lie strictly between 0 and 1.');
end
if cfg.ai.oodMarginStd < 0
    error('cfg.ai.oodMarginStd must be nonnegative.');
end
if cfg.ai.kernelSigma <= 0 || cfg.ai.lambda <= 0 || ...
        any(cfg.ai.kernelSigmaGrid<=0) || any(cfg.ai.lambdaGrid<=0)
    error('KRR kernel widths and regularization parameters must be positive.');
end
if abs(cfg.ai.alphaMax-1.0)>1e-12 || abs(cfg.ai.fallbackAlpha-1.0)>1e-12
    error('Formal response-learning policy requires alphaMax=fallbackAlpha=1.0.');
end
if any(cfg.ai.candidateAlphaGrid < cfg.ai.alphaMin-1e-12) || ...
        any(cfg.ai.candidateAlphaGrid > cfg.ai.alphaMax+1e-12)
    error('Online candidateAlphaGrid must lie inside [alphaMin,alphaMax].');
end
% Offline exploration range is intentionally allowed to be wider than the
% online deployed reserve-ratio range. This permits low-alpha boundary data
% (e.g., alpha=0.30) without ever allowing the online controller below 0.60.
if ~isfield(cfg.ai.response,'trainingAlphaMin') || ~isfield(cfg.ai.response,'trainingAlphaMax') || ...
        cfg.ai.response.trainingAlphaMin < 0 || ...
        cfg.ai.response.trainingAlphaMax < cfg.ai.response.trainingAlphaMin
    error('Invalid offline response-training alpha range.');
end
if any(cfg.ai.response.alphaLevels < cfg.ai.response.trainingAlphaMin-1e-12) || ...
        any(cfg.ai.response.alphaLevels > cfg.ai.response.trainingAlphaMax+1e-12)
    error('Exploration alphaLevels must lie inside the offline training range.');
end
if ~any(abs(cfg.ai.response.alphaLevels-1)<1e-12)
    error('Full response-training alphaLevels must contain alpha=1.');
end
if numel(unique(cfg.ai.response.alphaLevels))<3
    error('Use at least three alpha levels in a fresh response-learning dataset.');
end
if cfg.ai.response.trainingAlphaMax < cfg.ai.alphaMax-1e-12 || ...
        cfg.ai.response.trainingAlphaMin > cfg.ai.alphaMin+1e-12
    error('Offline training alpha range must cover the full online policy range.');
end
if ~isfield(cfg.ai.response,'incrementalReuseExistingDataset')
    error('cfg.ai.response.incrementalReuseExistingDataset is required.');
end
if ~isfield(cfg.ai.response,'minSamplesPerExistingAlpha') || ...
        cfg.ai.response.minSamplesPerExistingAlpha < 1
    error('cfg.ai.response.minSamplesPerExistingAlpha must be positive.');
end

% A symmetric reserve cannot exceed half of the usable DG range.
r0=max(cfg.frequency.reserveDeviation_Hz/(cfg.frequency.droop_pu*cfg.frequency.nominal_Hz), ...
       2*cfg.frequency.H_s*cfg.frequency.reserveRoCoF_Hz_s/cfg.frequency.nominal_Hz);
rmax=(cfg.frequency.dgPmax_pu-cfg.frequency.dgPmin_pu)/2;
if r0 > rmax
    error(['The physics reserve itself is infeasible: %.4f pu > symmetric limit %.4f pu. ', ...
        'Check droop/inertia bases and reserve thresholds.'],r0,rmax);
end
if cfg.ai.alphaMax*r0 > rmax
    warning(['cfg.ai.alphaMax reaches the DG feasibility ceiling. Predictions above %.3f ', ...
        'will be clipped by the reserve box.'],rmax/r0);
end

prices=[cfg.cost.diesel_per_kWh,cfg.cost.loadShed_per_kWh, ...
    cfg.cost.evTerminalDeficit_per_kWh,cfg.cost.bessTerminalDeficit_per_kWh, ...
    cfg.cost.batteryUnit_per_kWh,cfg.cost.pvCurtailment_per_kWh];
if any(prices<0)
    error('Economic coefficients in cfg.cost must be nonnegative.');
end

validDayTypes={'Usual day','Unusual day'};
if ~any(strcmpi(cfg.scenario.dayType,validDayTypes))
    error('cfg.scenario.dayType must be ''Usual day'' or ''Unusual day''.');
end
if any(~isfinite(cfg.scenario.decayRatios)) || any(cfg.scenario.decayRatios<=0)
    error('cfg.scenario.decayRatios must contain positive finite scaling factors.');
end
if any(~isfinite(cfg.experiment.randomSeeds)) || any(cfg.experiment.randomSeeds<0) || ...
        any(mod(cfg.experiment.randomSeeds,1)~=0)
    error('cfg.experiment.randomSeeds must be nonnegative integers.');
end

validCases=["10bus","10bus_loop","18bus","18bus_loop","33bus","33bus_loop"];
radialCases=["10bus","18bus","33bus"];
experimentCases=lower(string(cfg.experiment.systemCases));
responseCases=lower(string(cfg.ai.response.systemCases));
if isempty(experimentCases) || any(~ismember(experimentCases,validCases))
    error(['cfg.experiment.systemCases contains an unsupported case name. Valid catalog names: ', ...
        '10bus, 10bus_loop, 18bus, 18bus_loop, 33bus, 33bus_loop.']);
end
if isempty(responseCases) || any(~ismember(responseCases,validCases))
    error(['cfg.ai.response.systemCases contains an unsupported case name. Valid catalog names: ', ...
        '10bus, 10bus_loop, 18bus, 18bus_loop, 33bus, 33bus_loop.']);
end
if ~isfield(cfg.network,'allowMeshedCases'), cfg.network.allowMeshedCases=false; end
if ~cfg.network.allowMeshedCases
    if any(~ismember(experimentCases,radialCases))
        error(['Formal TICPS experiments are radial-only because meshed SOCP exactness is unresolved. ', ...
            'Use cfg.experiment.systemCases from {10bus,18bus,33bus}.']);
    end
    if any(~ismember(responseCases,radialCases))
        error(['AI response-data generation is radial-only. Use cfg.ai.response.systemCases from ', ...
            '{10bus,18bus,33bus}.']);
    end
end

catalog=paper_method_catalog();
methodIDs=string({catalog.id});
selected=string(cfg.experiment.enabledMethods);
if any(~ismember(selected,methodIDs))
    error('cfg.experiment.enabledMethods contains an unknown method ID.');
end
if ~ismember(string(cfg.ai.response.baselineID),methodIDs)
    error('cfg.ai.response.baselineID is not present in baseline_catalog.');
end
if any(~isfinite(cfg.ai.response.decayRatios)) || any(cfg.ai.response.decayRatios<=0)
    error('cfg.ai.response.decayRatios must contain positive finite values.');
end
if any(~isfinite(cfg.ai.response.randomSeeds)) || any(cfg.ai.response.randomSeeds<0) || ...
        any(mod(cfg.ai.response.randomSeeds,1)~=0)
    error('cfg.ai.response.randomSeeds must be nonnegative integers.');
end
end

function mustBePositiveScalar(x,name)
if ~isscalar(x) || ~isfinite(x) || x<=0
    error('%s must be a positive finite scalar.',name);
end
end
