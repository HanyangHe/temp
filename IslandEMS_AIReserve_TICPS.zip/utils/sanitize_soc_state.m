function [socOut,meta] = sanitize_soc_state(socIn,socMin,socMax,tol,label)
%SANITIZE_SOC_STATE Project tiny numerical SoC overshoots to exact hard bounds.
% This is numerical state hygiene, NOT an operating-limit relaxation.
% Values outside [socMin-tol,socMax+tol] trigger an error so a genuine
% physical violation is never silently hidden.

if nargin < 5 || isempty(label), label='SoC state'; end
if nargin < 4 || isempty(tol), tol=1e-4; end

socOut = socIn;
finiteMask = isfinite(socOut);
if any(~finiteMask(:))
    error('IslandEMS:NonfiniteSOC','%s contains nonfinite SoC values.',label);
end

hardLow  = socOut < socMin-tol;
hardHigh = socOut > socMax+tol;
if any(hardLow(:)) || any(hardHigh(:))
    lo = min(socOut(:)); hi = max(socOut(:));
    error('IslandEMS:PhysicalSOCViolation', ...
        ['%s exceeds hard SoC limits by more than numerical tolerance %.3g. ', ...
         'Observed range [%.8f, %.8f], allowed [%.8f, %.8f].'], ...
         label,tol,lo,hi,socMin,socMax);
end

nearLow  = socOut < socMin;
nearHigh = socOut > socMax;
correction = zeros(size(socOut));
correction(nearLow) = socMin-socOut(nearLow);
correction(nearHigh)= socMax-socOut(nearHigh);
socOut(nearLow)=socMin;
socOut(nearHigh)=socMax;

meta = struct();
meta.clipCount = nnz(nearLow)+nnz(nearHigh);
meta.lowClipCount = nnz(nearLow);
meta.highClipCount = nnz(nearHigh);
meta.maxCorrection = max(abs(correction(:)),[],'omitnan');
if isempty(meta.maxCorrection), meta.maxCorrection=0; end
end
