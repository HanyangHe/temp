function figProcess(w, h, filename, format)
    if nargin < 3 || isempty(filename), filename = 'figure'; end
    if nargin < 4 || isempty(format),   format   = 'pdf';    end

    fig = gcf;
    set(fig, 'Units','centimeters');
    pos = get(fig,'Position');                       % [left bottom width height]
    set(fig, 'Position', [pos(1) pos(2) w h]);       % size setting (cm)

    ax = gca;
    set(ax, 'Units','centimeters');


    set(fig, 'PaperUnits','centimeters', 'PaperPositionMode','auto', 'Color', 'none');

    % option
    % text(ax, 0.02, 0.95, sprintf('%.1f cm × %.1f cm', w, h), ...
    %     'Units','normalized','HorizontalAlignment','left', ...
    %     'VerticalAlignment','top','FontName','Times New Roman');

    if strcmpi(format,'pdf')
        set(fig, 'PaperSize', [w h], 'Renderer','painters');
        exportgraphics(fig, sprintf('%s.pdf', filename), 'ContentType','vector');
    elseif strcmpi(format,'png')
        exportgraphics(fig, sprintf('%s.png', filename), 'Resolution', 600);
    else
        error('format must be ''pdf'' or ''png''.');
    end
end
