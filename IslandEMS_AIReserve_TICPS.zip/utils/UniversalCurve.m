function ygrid = UniversalCurve(tAnchors,yAnchors,tgrid,method)
%UNIVERSALCURVE Interpolate an anchored profile onto a requested time grid.
% Used for exogenous profile construction and zero-order-hold schedule
% execution. It is not an intra-interval command-refinement mechanism.

if nargin<4 || isempty(method), method='spline'; end
if numel(tAnchors)~=numel(yAnchors)
    error('UniversalCurve:DimensionMismatch','Anchor dimensions do not match.');
end
if any(diff(tAnchors)<=0)
    error('UniversalCurve:NonMonotoneTime','tAnchors must be strictly increasing.');
end

ygrid = interp1(tAnchors,yAnchors,tgrid,method);
end
