function plot_saved_results(outputRoot)
%PLOT_SAVED_RESULTS Replay the most recent completed experiment run.
if ~exist(outputRoot,'dir'), error('Output directory not found: %s',outputRoot); end
D=dir(outputRoot); D=D([D.isdir]);
D=D(~ismember({D.name},{'.','..'}));
D=D(~startsWith({D.name},'training_'));
if isempty(D), error('No experiment run directories found.'); end
[~,ix]=max([D.datenum]); runDir=fullfile(outputRoot,D(ix).name);
summaryFile=fullfile(runDir,'summary.csv');
if ~exist(summaryFile,'file'), error('summary.csv not found in %s',runDir); end
T=readtable(summaryFile);
disp(T);

methods=unique(string(T.methodID),'stable');
cost=nan(size(methods)); freq=nan(size(methods)); viol=nan(size(methods)); reserve=nan(size(methods));
loadShed=nan(size(methods)); evUnmet=nan(size(methods));
for i=1:numel(methods)
    m=string(T.methodID)==methods(i);
    cost(i)=mean(T.totalCost(m),'omitnan');
    freq(i)=mean(T.maxAbsFreqDev_Hz(m),'omitnan');
    if ismember('frequencyViolationRate',T.Properties.VariableNames)
        viol(i)=mean(T.frequencyViolationRate(m),'omitnan');
    else
        viol(i)=mean(T.securityViolationRate(m),'omitnan');
    end
    if ismember('meanTotalDGReserve_kW',T.Properties.VariableNames)
        reserve(i)=mean(T.meanTotalDGReserve_kW(m),'omitnan');
    end
    if ismember('loadShedEnergy_kWh',T.Properties.VariableNames)
        loadShed(i)=mean(T.loadShedEnergy_kWh(m),'omitnan');
    end
    if ismember('EVUnmetEnergy_kWh',T.Properties.VariableNames)
        evUnmet(i)=mean(T.EVUnmetEnergy_kWh(m),'omitnan');
    end
end

figure; bar(categorical(methods),cost); ylabel('Mean operating cost ($)'); grid on;
figure; bar(categorical(methods),freq); ylabel('Mean max |\Delta f| (Hz)'); grid on;
figure; bar(categorical(methods),viol); ylabel('Frequency-violation rate'); grid on;
if any(isfinite(reserve))
    figure; bar(categorical(methods),reserve); ylabel('Mean total DG reserve (kW)'); grid on;
end
if any(isfinite(loadShed))
    figure; bar(categorical(methods),loadShed); ylabel('Load-shed energy (kWh)'); grid on;
end
if any(isfinite(evUnmet))
    figure; bar(categorical(methods),evUnmet); ylabel('EV unmet energy (kWh)'); grid on;
end

fprintf('Replayed run: %s\n',runDir);
end
