function Yfine = resample_horizon_anchors(Yanchor,nativeStep_h,targetStep_h,horizon_h,method)
%RESAMPLE_HORIZON_ANCHORS Resample forecast anchors onto the MPC grid.
%
% Yanchor must contain horizon_h/nativeStep_h + 1 columns, including the
% terminal anchor at exactly horizon_h. The returned Yfine contains
% horizon_h/targetStep_h stage values at [0,targetStep_h,...,horizon_h-targetStep_h].
% This utility operates OUTSIDE the optimizer; it does not introduce extra
% optimization variables or change the native resolution of the KRR models.

if nargin < 5 || isempty(method), method='pchip'; end
if nativeStep_h <= 0 || targetStep_h <= 0 || horizon_h <= 0
    error('Time steps and horizon must be positive.');
end
nAnchor = round(horizon_h/nativeStep_h);
nFine = round(horizon_h/targetStep_h);
if abs(nAnchor*nativeStep_h-horizon_h)>1e-10 || ...
        abs(nFine*targetStep_h-horizon_h)>1e-10
    error('Horizon must be an integer multiple of both native and target steps.');
end
if size(Yanchor,2) ~= nAnchor+1
    error('Expected %d anchor columns (including terminal anchor), got %d.', ...
        nAnchor+1,size(Yanchor,2));
end

tAnchor = 0:nativeStep_h:horizon_h;
tFine = 0:targetStep_h:horizon_h-targetStep_h;

% interp1 accepts matrix data by columns only after transposing. Treat real
% and imaginary parts separately to make complex load forecasts explicit.
Yr = interp1(tAnchor,real(Yanchor).',tFine,method).';
if ~isreal(Yanchor)
    Yi = interp1(tAnchor,imag(Yanchor).',tFine,method).';
    Yfine = complex(Yr,Yi);
else
    Yfine = Yr;
end

if any(~isfinite(Yfine(:)))
    error('Forecast-anchor resampling generated nonfinite values.');
end
end
