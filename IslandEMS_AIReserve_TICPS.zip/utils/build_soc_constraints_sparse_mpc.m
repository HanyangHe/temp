function [A_SOC,b_SOC] = build_soc_constraints_sparse_mpc(Kday,SOCmax,SOCmin,SOC0, ...
    EbattMaxGFM,EbattMax,EbattMaxEV,eta_ch,eta_dis,DG_GFM_num, ...
    BatteryGFM_Num,BatteryNum,EVBatteryNum,SolarNum,Nload,Nbranch,Nbus, ...
    dt_sys,step,SOCorigin)
%BUILD_SOC_CONSTRAINTS_SPARSE_MPC Sparse/vectorized equivalent of the legacy
% SOC_InequalityConstraints_withEVenShedding_MPC formulation.
%
% The original routine repeatedly formed a very large dense mostly-zero
% matrix with nested Kday loops. At Kday=96 this was expensive. This version
% preserves the same rows/columns and terminal constraints but constructs
% only the nonzero cumulative-energy blocks.

EbattMaxGFM=EbattMaxGFM(:); EbattMax=EbattMax(:); EbattMaxEV=EbattMaxEV(:);
SOC0=SOC0(:); SOCorigin=SOCorigin(:);
nDev=BatteryGFM_Num+BatteryNum+EVBatteryNum;
nRows=2*Kday*nDev;
nSocCols=BatteryGFM_Num*3*Kday + BatteryNum*(3*Kday+1) + EVBatteryNum*(2*Kday+2);
nPre=2*Kday*DG_GFM_num;
nPost=SolarNum*2*Kday+Nload*Kday+(3*Nbranch+Nbus)*Kday;
nTotal=nPre+nSocCols+nPost;

A0=spalloc(nRows,nSocCols,max(1,nDev*4*Kday*Kday/2));
b_SOC=zeros(nRows,1);
L=sparse(tril(ones(Kday)));
idxRow=0; idxCol=0;
index=Kday-step+1;

% GFM-BESS devices.
for ii=1:BatteryGFM_Num
    E=EbattMaxGFM(ii);
    rU=idxRow+(1:Kday); rL=idxRow+Kday+(1:Kday);
    cDis=idxCol+(1:Kday); cCh=idxCol+Kday+(1:Kday);
    A0(rU,cDis)=-(dt_sys/(E*eta_dis))*L;
    A0(rU,cCh)=(eta_ch*dt_sys/E)*L;
    A0(rL,cDis)=(dt_sys/(E*eta_dis))*L;
    A0(rL,cCh)=-(eta_ch*dt_sys/E)*L;
    s0=SOC0(ii); so=SOCorigin(ii);
    b_SOC(rU)=SOCmax-s0; b_SOC(rL)=s0-SOCmin;
    b_SOC(rL(index))=s0-so; b_SOC(rL(end))=0;
    idxRow=idxRow+2*Kday; idxCol=idxCol+3*Kday;
end

% Grid-following BESS devices.
for jj=1:BatteryNum
    ii=BatteryGFM_Num+jj; E=EbattMax(jj);
    rU=idxRow+(1:Kday); rL=idxRow+Kday+(1:Kday);
    cDis=idxCol+(1:Kday); cCh=idxCol+Kday+(1:Kday);
    A0(rU,cDis)=-(dt_sys/(E*eta_dis))*L;
    A0(rU,cCh)=(eta_ch*dt_sys/E)*L;
    A0(rL,cDis)=(dt_sys/(E*eta_dis))*L;
    A0(rL,cCh)=-(eta_ch*dt_sys/E)*L;
    shedCol=idxCol+3*Kday+1;
    A0(rU(index),shedCol)=1; A0(rL(index),shedCol)=-1;
    s0=SOC0(ii); so=SOCorigin(ii);
    b_SOC(rU)=SOCmax-s0; b_SOC(rL)=s0-SOCmin;
    b_SOC(rL(index))=s0-so; b_SOC(rL(end))=0;
    idxRow=idxRow+2*Kday; idxCol=idxCol+3*Kday+1;
end

% EV batteries: cumulative energy resets at the daily boundary inside the
% sliding horizon, exactly matching the legacy step-dependent matrix.
base=Kday-step+1;
if base==Kday
    Lwrap=L;
elseif base==0
    Lwrap=L;
else
    Lwrap=blkdiag(sparse(tril(ones(base))),sparse(tril(ones(Kday-base))));
end
for jj=1:EVBatteryNum
    ii=BatteryGFM_Num+BatteryNum+jj; E=EbattMaxEV(jj);
    rU=idxRow+(1:Kday); rL=idxRow+Kday+(1:Kday);
    cDis=idxCol+(1:Kday); cCh=idxCol+Kday+(1:Kday);
    A0(rU,cDis)=-(dt_sys/(E*eta_dis))*Lwrap;
    A0(rU,cCh)=(eta_ch*dt_sys/E)*Lwrap;
    A0(rL,cDis)=(dt_sys/(E*eta_dis))*Lwrap;
    A0(rL,cCh)=-(eta_ch*dt_sys/E)*Lwrap;
    relaxCol=idxCol+2*Kday+1; shedCol=idxCol+2*Kday+2;
    A0(rU(index),relaxCol)=-1; A0(rL(index),relaxCol)=-1;
    A0(rU(index),shedCol)=1; A0(rL(index),shedCol)=-1;
    s0=SOC0(ii);
    b_SOC(rU)=SOCmax-s0; b_SOC(rL)=s0-SOCmin;
    % delta is zero in the legacy implementation.
    b_SOC(rU(index))=SOCmax-s0;
    b_SOC(rL(index))=s0-SOCmax;
    if step>1
        b_SOC(rU(end))=0;
        b_SOC(rL(end))=0;
    end
    idxRow=idxRow+2*Kday; idxCol=idxCol+2*Kday+2;
end

A_SOC=[sparse(nRows,nPre),A0,sparse(nRows,nPost)];
if size(A_SOC,2)~=nTotal
    error('Sparse SOC constraint width mismatch: %d vs expected %d.',size(A_SOC,2),nTotal);
end
end
