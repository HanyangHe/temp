function [gridLB,gridUB] = build_mpc_grid_bounds_static(Kday,Nbranch,Nbus,Vmin,Vmax,k_brch,LineLimitsBFM)
%BUILD_MPC_GRID_BOUNDS_STATIC Constant network-variable box bounds.
oneLB=[0;-10*ones(Nbranch-1,1);0;-10*ones(Nbranch-1,1);zeros(Nbranch,1);Vmin^2*ones(Nbus,1)];
oneUB=[0; 10*ones(Nbranch-1,1);0; 10*ones(Nbranch-1,1);(k_brch*LineLimitsBFM).^2;Vmax^2*ones(Nbus,1)];
gridLB=repmat(oneLB,Kday,1);
gridUB=repmat(oneUB,Kday,1);
end
