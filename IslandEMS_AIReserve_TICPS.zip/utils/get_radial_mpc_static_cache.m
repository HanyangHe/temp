function cache = get_radial_mpc_static_cache(cacheKey,LineBFM,Vslack,Kday, ...
    BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,BusOfload, ...
    DieselG_Pgfm_rateVec,BatteryGFM_P_rate,BatteryGFL_P_rate,PVInv_P_rate,PF)
%GET_RADIAL_MPC_STATIC_CACHE Cache time-invariant 15-min MPC SOCP structure.
% The revised TICPS study uses radial networks only. For a fixed topology
% and 24-h/96-stage horizon, the network equality matrix and all SOC cone
% objects are constant across the 96 receding-horizon updates. Building
% these dense objects at every update was a major runtime bottleneck.
%
% Dynamic quantities (forecast RHS, current SoC, reserve bounds, EV
% availability, PV/load box limits) are intentionally NOT cached here.

persistent CACHE
if isempty(CACHE)
    CACHE = containers.Map('KeyType','char','ValueType','any');
end
key = char(string(cacheKey));
if isKey(CACHE,key)
    cache = CACHE(key);
    cache.reused = true;
    return;
end

buildTimer = tic;
Nbus = max(LineBFM(:,2));
Nbranch = size(LineBFM,1);
if Nbranch ~= Nbus
    error(['Static radial SOCP cache requires Nbranch == Nbus in the BFM ', ...
        '(dummy root branch plus one incoming branch per bus). ', ...
        'Received Nbranch=%d, Nbus=%d.'],Nbranch,Nbus);
end

% Equality structure. Zero injections preserve all topology/device columns;
% only the power-balance RHS changes online.
Szero = complex(zeros(Nbus,Kday));
[Aeq,beqTemplate] = LinearEqualityConstBFS_SOCP_powerbalance_island_withES_MPC( ...
    LineBFM,Vslack,Kday,Szero,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery, ...
    BusOfEVBattery,BusOfPV,BusOfload);
Aeq = sparse(Aeq);

% Static branch-flow and device apparent-power cones.
[A1,b1,d1,g1] = ConeConstraintsForBFS_SOCP_island_withEVenShedding_MPC( ...
    LineBFM,Vslack,Kday,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery, ...
    BusOfEVBattery,BusOfPV,numel(BusOfload));
[A2,b2,d2,g2] = ConeConstraintsForDGcapacity_island_withEVenShedding_MPC( ...
    DieselG_Pgfm_rateVec/PF,BatteryGFM_P_rate/PF,BatteryGFL_P_rate/PF, ...
    PVInv_P_rate/PF,LineBFM,Kday,BusOfDieselG_GFM,BusOfBatteryGFM, ...
    BusOfBattery,BusOfEVBattery,BusOfPV,numel(BusOfload));

Asc = [A1;A2]; bsc = [b1;b2]; dsc = [d1;d2]; gamma = [g1;g2];
socConstraints = optim.coneprog.SecondOrderConeConstraint.empty;
for k = 1:numel(Asc)
    % Sparse cone matrices materially reduce memory and cause coneprog's
    % automatic linear solver to use a sparse-oriented algorithm.
    Asc{k} = sparse(Asc{k});
    dsc{k} = sparse(dsc{k});
    socConstraints(end+1) = secondordercone(Asc{k},bsc{k},dsc{k},gamma{k}); %#ok<AGROW>
end

cache = struct();
cache.Aeq = Aeq;
cache.beqTemplate = beqTemplate;
cache.socConstraints = socConstraints;
cache.Asc = Asc;
cache.bsc = bsc;
cache.dsc = dsc;
cache.gamma = gamma;
cache.Nbus = Nbus;
cache.Nbranch = Nbranch;
cache.rowsPerStage = size(beqTemplate,1)/Kday;
cache.outBusOrder = LineBFM(1:Nbus,2);
cache.buildTime_s = toc(buildTimer);
cache.reused = false;
CACHE(key) = cache;
end
