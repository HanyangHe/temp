function [loopNodes, loopBranches] = findFundamentalLoopsFromBranches(branchMat)
% FINDFUNDAMENTALLOOPSFROMBRANCHES
% Find fundamental loops (cycle basis) of an undirected network.
% branchMat: m x 2 (or more), first two columns are [from, to] node IDs
% loopNodes:    1 x L cell, each cell is node sequence [n1 n2 ... nk]
% loopBranches: 1 x L cell, each cell is branch index sequence [e1 ... ek]
%
% NOTE: graph is treated as undirected; branch direction only affects sign

	edgesID = branchMat(:,1:2);          % [fromID, toID]
	allNodeIDs = unique(edgesID(:));     
	nNodes = numel(allNodeIDs);

	[~,~,idx] = unique(edgesID(:));      % idx size = 2*m
	u = idx(1:end/2);
	v = idx(end/2+1:end);
	m = numel(u);

	edges_uv = [u, v];                 
	branchIndex = (1:m).';         

	G = graph(u, v);                     
	T = minspantree(G);                

	tree_uv = sort(T.Edges.EndNodes, 2);  

	all_uv_sorted = sort(edges_uv, 2);

	isTreeEdge = ismember(all_uv_sorted, tree_uv, 'rows');
	chordIdx = find(~isTreeEdge);          % branchIndex

	loopNodes = {};
	loopBranches = {};

	for kk = 1:numel(chordIdx)
		eIdx = chordIdx(kk);              
		u_ch = u(eIdx);
		v_ch = v(eIdx);

		path_nodes = shortestpath(T, u_ch, v_ch);  % e.g. [u_ch ... v_ch]

		cycle_nodes_compact = path_nodes;          

		cycle_nodes = allNodeIDs(cycle_nodes_compact).';
		loopNodes{end+1} = cycle_nodes;

		nc = numel(cycle_nodes);
		edgeIdx_in_loop = zeros(1, nc);   

		for k = 1:nc
			uID = cycle_nodes(k);
			vID = cycle_nodes(mod(k, nc) + 1);  

			row = find( (branchMat(:,1)==uID & branchMat(:,2)==vID) | ...
			            (branchMat(:,1)==vID & branchMat(:,2)==uID), 1, 'first');
			if isempty(row)
				error('Cannot find branch between nodes %g and %g in branchMat.', uID, vID);
			end
			edgeIdx_in_loop(k) = row;
		end

		loopBranches{end+1} = edgeIdx_in_loop;
	end
end
