function f = build_mpc_objective_static(Kday,DG_GFM_num,BatteryGFM_Num,BatteryNum, ...
    EVBatteryNum,SolarNum,Nload,Nbranch,Nbus,C_dieselG,C_deg,C_BESSSoCshed, ...
    C_EVSoCshed,CsocRelax,C_PVCurt,C_LdShd,EbattMax,EbattMaxEV,dt_mpc)
%BUILD_MPC_OBJECTIVE_STATIC Time-invariant objective vector for MPC-SOCP.
parts=cell(1,DG_GFM_num+BatteryGFM_Num+BatteryNum+EVBatteryNum+SolarNum+Nload+1);
j=0;
for ii=1:DG_GFM_num
    j=j+1; parts{j}=[C_dieselG*ones(1,Kday),zeros(1,Kday)];
end
for ii=1:BatteryGFM_Num
    j=j+1; parts{j}=[C_deg*ones(1,Kday),C_deg*ones(1,Kday),zeros(1,Kday)];
end
for ii=1:BatteryNum
    j=j+1; parts{j}=[C_deg*ones(1,Kday),C_deg*ones(1,Kday),zeros(1,Kday),C_BESSSoCshed*EbattMax(ii)/dt_mpc];
end
for ii=1:EVBatteryNum
    j=j+1; parts{j}=[C_deg*ones(1,Kday),C_deg*ones(1,Kday),CsocRelax*EbattMaxEV(ii)/dt_mpc,C_EVSoCshed*EbattMaxEV(ii)/dt_mpc];
end
for ii=1:SolarNum
    j=j+1; parts{j}=[-C_PVCurt*ones(1,Kday),zeros(1,Kday)];
end
for ii=1:Nload
    j=j+1; parts{j}=C_LdShd*ones(1,Kday);
end
j=j+1; parts{j}=zeros(1,Kday*(3*Nbranch+Nbus));
f=1000*[parts{1:j}]*dt_mpc;
f=f(:);
end
