function snapshot = build_feature_screening_snapshot(result)
%BUILD_FEATURE_SCREENING_SNAPSHOT Compress one completed IslandEMS run into
%a small 96-row feature-screening snapshot.
%
% This helper performs NO optimization and NO physical simulation. It only
% reduces an already completed full-day result to decision-interval data.
%
% The returned snapshot is intentionally small so an informal smoke test may
% cache it in the operating-system temporary directory without polluting the
% formal project outputs/ tree.

if ~is_valid_result(result)
    error('build_feature_screening_snapshot:InvalidResult', ...
        'Input must be a completed IslandEMS result structure.');
end

cfg = result.cfgSnapshot;
f0 = cfg.frequency.nominal_Hz;
dfLim = cfg.frequency.securityDeviation_Hz;
rLim = cfg.frequency.securityRoCoF_Hz_s;
spH = cfg.simulation.samplePerHour;
dt_s = 3600/spH;
decision_h = cfg.mpc.decisionInterval_h;
samplesPerDecision = round(decision_h*spH);
Nphys = size(result.P_DG_MW,2);
K = min(cfg.mpc.decisionLevelSteps, floor(Nphys/samplesPerDecision));
if K < 8
    error('Too few decision intervals (%d) for feature screening.',K);
end

idx0 = 1 + (0:K-1)*samplesPerDecision;
time_h = (0:K-1)'*decision_h;

% ---- Frequency-stress target -------------------------------------------
peakDf = nan(K,1); peakRoCoF = nan(K,1); stress = nan(K,1);
violation = false(K,1);
for k = 1:K
    i0 = idx0(k);
    i1 = min(i0 + samplesPerDecision, Nphys+1); % freq has Nphys+1 samples
    fs = result.freq_Hz(i0:i1);
    peakDf(k) = max(abs(fs-f0),[],'omitnan');
    if numel(fs)>=2
        rr = diff(fs)/dt_s;
        peakRoCoF(k) = max(abs(rr),[],'omitnan');
    else
        peakRoCoF(k)=0;
    end
    stress(k) = max(peakDf(k)/max(dfLim,eps),peakRoCoF(k)/max(rLim,eps));
    violation(k) = stress(k)>1;
end

% ---- Aggregate active-power states -------------------------------------
PdgBase = max(sum(result.DG_rating_MW(:)),eps);
PdgTotal = sum(real(result.P_DG_MW),1);
Pload = max(-real(result.totalLoad_MW),0); % load stored as negative injection
Ppv = orient_generation_nonnegative(real(result.totalPV_MW));
Pbatt = real(result.totalBattery_MW);      % positive = net discharge
PnetMeasured = Pload - Ppv - Pbatt;       % approximate demand seen by SGs
balanceMismatch = rms_finite((PnetMeasured-PdgTotal)/PdgBase);

idxState = min(idx0,Nphys);
loadNow = Pload(idxState)'/PdgBase;
pvNow = Ppv(idxState)'/PdgBase;
battNow = Pbatt(idxState)'/PdgBase;
netNow = PnetMeasured(idxState)'/PdgBase;
dgNow = PdgTotal(idxState)'/PdgBase;
dgUpHeadroom = (PdgBase-PdgTotal(idxState))'/PdgBase;
pminTotal = cfg.frequency.dgPmin_pu*PdgBase;
dgDownHeadroom = (PdgTotal(idxState)-pminTotal)'/PdgBase;
netRampBack = [0; abs(diff(netNow))];

% ---- Candidate features -------------------------------------------------
featureData = [];
featureNames = {};
featureGroup = {};
featureEligible = [];

% Existing pre-MPC forecast/exogenous features.
if isfield(result,'reserve') && isfield(result.reserve,'features') && ~isempty(result.reserve.features)
    F = result.reserve.features;
    if size(F,1) ~= K && size(F,2) == K, F=F.'; end
    F = F(1:min(K,size(F,1)),:);
    if size(F,1)<K, F(end+1:K,:)=NaN; end
    names = string(result.reserve.featureNames);
    keepNames = [ ...
        "netLoadNow_pu","netLoadNext_pu","absNetLoadRamp_pu", ...
        "loadLevelNow_pu","pvFractionNow","absPVRamp_pu", ...
        "netLoadStdHorizon_pu","maxNetLoadRampHorizon_pu", ...
        "evAvailability","timeSin","timeCos"];
    for n = keepNames
        j=find(names==n,1);
        if ~isempty(j)
            isProxy = any(n==["timeSin","timeCos"]);
            [featureData,featureNames,featureGroup,featureEligible] = add_feature( ...
                featureData,featureNames,featureGroup,featureEligible,F(:,j), ...
                char(n), ternary(isProxy,'proxy-time','forecast-physics'), ~isProxy);
        end
    end
end

% Causal measured states at the decision instant.
[featureData,featureNames,featureGroup,featureEligible] = add_feature(featureData,featureNames,featureGroup,featureEligible,netNow,'measNetDemand_pu','measured-physics',true);
[featureData,featureNames,featureGroup,featureEligible] = add_feature(featureData,featureNames,featureGroup,featureEligible,netRampBack,'measAbsNetRampBack_pu','measured-physics',true);
[featureData,featureNames,featureGroup,featureEligible] = add_feature(featureData,featureNames,featureGroup,featureEligible,loadNow,'measLoadLevel_pu','measured-physics',true);
[featureData,featureNames,featureGroup,featureEligible] = add_feature(featureData,featureNames,featureGroup,featureEligible,pvNow,'measPVLevel_pu','measured-physics',true);
[featureData,featureNames,featureGroup,featureEligible] = add_feature(featureData,featureNames,featureGroup,featureEligible,battNow,'measBatteryNetPower_pu','measured-physics',true);
[featureData,featureNames,featureGroup,featureEligible] = add_feature(featureData,featureNames,featureGroup,featureEligible,dgNow,'dgLoading_pu','measured-physics',true);
[featureData,featureNames,featureGroup,featureEligible] = add_feature(featureData,featureNames,featureGroup,featureEligible,dgUpHeadroom,'dgUpHeadroom_pu','measured-physics',true);
[featureData,featureNames,featureGroup,featureEligible] = add_feature(featureData,featureNames,featureGroup,featureEligible,dgDownHeadroom,'dgDownHeadroom_pu','measured-physics',true);

[nGFM,nBESS,nEV] = storage_counts(result);
bessMeanSOC = nan(K,1); bessMinSOC = nan(K,1); evMeanSOC = nan(K,1);
if nBESS>0 && ~isempty(result.soc)
    bRows = nGFM+(1:nBESS);
    socIdx = min(idx0,size(result.soc,2));
    bSoc = result.soc(bRows,socIdx);
    bessMeanSOC = mean(bSoc,1,'omitnan')';
    bessMinSOC = min(bSoc,[],1,'omitnan')';
    [featureData,featureNames,featureGroup,featureEligible] = add_feature(featureData,featureNames,featureGroup,featureEligible,bessMeanSOC,'bessMeanSOC','measured-physics',true);
    [featureData,featureNames,featureGroup,featureEligible] = add_feature(featureData,featureNames,featureGroup,featureEligible,bessMinSOC,'bessMinSOC','measured-physics',true);
end
if nEV>0 && ~isempty(result.soc)
    eRows = nGFM+nBESS+(1:nEV);
    socIdx = min(idx0,size(result.soc,2));
    evSoc = result.soc(eRows,socIdx);
    evMeanSOC = mean(evSoc,1,'omitnan')';
    [featureData,featureNames,featureGroup,featureEligible] = add_feature(featureData,featureNames,featureGroup,featureEligible,evMeanSOC,'evMeanSOC','measured-physics',true);
end

% ---- Mechanism-only future-realized diagnostics (NEVER AI inputs) -------
futureNetRange = nan(K,1);
futureNetMaxRamp1s = nan(K,1);
futureImbalanceToDG = nan(K,1);
for k=1:K
    i0=idx0(k); i1=min(i0+samplesPerDecision-1,Nphys);
    z=PnetMeasured(i0:i1)/PdgBase;
    futureNetRange(k)=max(z,[],'omitnan')-min(z,[],'omitnan');
    if numel(z)>=2
        futureNetMaxRamp1s(k)=max(abs(diff(z)),[],'omitnan');
    else
        futureNetMaxRamp1s(k)=0;
    end
    dd=(PnetMeasured(i0:i1)-PdgTotal(i0:i1))/PdgBase;
    futureImbalanceToDG(k)=max(abs(dd),[],'omitnan');
end

snapshot = struct();
snapshot.kind = 'IslandEMSFeatureScreenSnapshotV1';
snapshot.created = datetime('now');
snapshot.meta = result.meta;
snapshot.cfg = cfg;
snapshot.K = K;
snapshot.time_h = time_h;
snapshot.target = struct('peakDf_Hz',peakDf,'peakRoCoF_Hz_s',peakRoCoF, ...
    'stress',stress,'violation',violation,'dfLimit_Hz',dfLim,'rocofLimit_Hz_s',rLim);
snapshot.features = struct('data',featureData,'names',{featureNames}, ...
    'group',{featureGroup},'eligible',logical(featureEligible));
snapshot.states = struct('netNow_pu',netNow,'loadNow_pu',loadNow,'pvNow_pu',pvNow, ...
    'batteryNow_pu',battNow,'dgLoading_pu',dgNow,'dgUpHeadroom_pu',dgUpHeadroom, ...
    'dgDownHeadroom_pu',dgDownHeadroom,'netRampBack_pu',netRampBack, ...
    'bessMeanSOC',bessMeanSOC,'bessMinSOC',bessMinSOC,'evMeanSOC',evMeanSOC);
snapshot.mechanism = struct('futureNetRange_pu',futureNetRange, ...
    'futureNetMaxRamp1s_pu',futureNetMaxRamp1s, ...
    'futureNetVsDGImbalance_pu',futureImbalanceToDG);
snapshot.balanceMismatch_pu = balanceMismatch;
end

function tf=is_valid_result(r)
tf=isstruct(r) && isfield(r,'meta') && isfield(r,'cfgSnapshot') && ...
    isfield(r,'freq_Hz') && isfield(r,'P_DG_MW') && isfield(r,'totalLoad_MW') && ...
    isfield(r,'DG_rating_MW') && isfield(r,'totalPV_MW') && isfield(r,'totalBattery_MW');
end

function y=orient_generation_nonnegative(x)
x=real(x(:).');
pos=sum(max(x,0),'omitnan'); neg=sum(max(-x,0),'omitnan');
if neg>pos, x=-x; end
y=max(x,0);
end

function [D,N,G,E]=add_feature(D,N,G,E,x,name,group,eligible)
x=x(:);
if isempty(D), D=x; else, D(:,end+1)=x; end %#ok<AGROW>
N{end+1}=name; G{end+1}=group; E(end+1)=eligible; %#ok<AGROW>
end

function v=rms_finite(x)
x=x(isfinite(x)); if isempty(x), v=NaN; else, v=sqrt(mean(x.^2)); end
end

function [nG,nB,nE]=storage_counts(result)
nG=0; nB=0; nE=0;
if isfield(result,'energyCapacity')
    if isfield(result.energyCapacity,'GFMBESS_MWh'), nG=numel(result.energyCapacity.GFMBESS_MWh); end
    if isfield(result.energyCapacity,'BESS_MWh'), nB=numel(result.energyCapacity.BESS_MWh); end
    if isfield(result.energyCapacity,'EV_MWh'), nE=numel(result.energyCapacity.EV_MWh); end
end
end

function out=ternary(c,a,b)
if c, out=a; else, out=b; end
end
