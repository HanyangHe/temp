ENERGY-NEUTRAL BOUNDARY CROSSFADE TEST V1
==========================================

Recommended interpretation
--------------------------
This is NOT a shorter MPC decision interval.

The MPC optimization remains 15 min / 96 stages.  The only change is the
low-level realization of continuous active-power setpoints.

Around each 15-min boundary, use a 5-min linear crossfade:
  2.5 min before + 2.5 min after.

The next-stage setpoint is already available from the current MPC horizon,
so there is no additional optimization and no future-information leak.

Why this is attractive
----------------------
For a boundary u_old -> u_new, the symmetric linear ramp has the same
integral over the transition window as the original ZOH pair.  Therefore it
suppresses the instantaneous command jump without a first-order energy bias.

The same layer is applied to continuous active-power channels and can be
shared by every comparison method.

Files
-----
tests/
  test_F1_33bus_energy_neutral_boundary_crossfade_v1.m
tools/
  common_boundary_crossfade_value_v1.m
  restore_boundary_crossfade_engine_v1.m

Preflight
---------
clear functions
rehash
addpath(genpath(pwd))
Rpre = test_F1_33bus_energy_neutral_boundary_crossfade_v1(pwd,false);

If PASS
-------
Rxf = test_F1_33bus_energy_neutral_boundary_crossfade_v1(pwd,true);

Expected runtime
----------------
About one normal 33-bus simulation: ~50-55 minutes.

Do not tune the 5-min window after seeing F1.  It is fixed a priori as
one-third of the 15-min MPC stage.
