function profile = replay_saved_operating_profiles(runRoot,caseName,methodID,decayRatio,varargin)
%REPLAY_SAVED_OPERATING_PROFILES Display/export full saved operating profiles.
% NO simulation is launched. One saved MAT result is loaded at a time.
%
% Figures:
%  1 aggregate powers
%  2 individual DG/storage powers
%  3 all saved SoC trajectories
%  4 CoI/individual frequency + CoI RoCoF
%  5 voltage/current security
%  6 baseline/executed load + reduction
%  7 reserve profiles (when saved)
%  8 instantaneous/cumulative cost
%
% Grid-independent: reusable for 10bus/18bus/33bus.

p = inputParser;
addParameter(p,'Seed',0);
addParameter(p,'DayType','Unusual day');
addParameter(p,'PaperLabel',methodID);
addParameter(p,'Visible',true);
addParameter(p,'Export',true);
addParameter(p,'OutputDir','');
parse(p,varargin{:});
opt = p.Results;

cfg = config_island_ems();
methodID = string(methodID);
paperLabel = string(opt.PaperLabel);
caseName = string(caseName);
dayTag = lower(strrep(string(opt.DayType),' ','_'));
decayCode = round(100*decayRatio);

methodDir = fullfile(runRoot,char(methodID));
pattern = sprintf('%s_%s_decay%03d_seed%03d_*.mat', ...
    caseName,dayTag,decayCode,opt.Seed);
hits = dir(fullfile(methodDir,pattern));
assert(numel(hits)==1, ...
    'Expected exactly one saved result for %s | %s | decay %.2f.', ...
    methodID,caseName,decayRatio);

filePath = fullfile(hits(1).folder,hits(1).name);
result = load_result_local(filePath);

if strlength(string(opt.OutputDir))==0
    outputDir = fullfile(runRoot,'manuscript_replay','profiles', ...
        char(caseName),sprintf('decay_%03d',decayCode),char(paperLabel));
else
    outputDir = char(opt.OutputDir);
end
if opt.Export && ~exist(outputDir,'dir'), mkdir(outputDir); end
vis = 'off'; if opt.Visible, vis = 'on'; end
prefix = sprintf('%s | %s | decay %.2f',upper(caseName),paperLabel,decayRatio);

profile = struct('caseName',caseName,'methodID',methodID, ...
    'paperLabel',paperLabel,'decayRatio',decayRatio, ...
    'filePath',filePath,'outputDir',outputDir,'figures',struct());

%% Aggregate power profiles
if all(isfield(result,{'totalLoad_MW','totalGeneration_MW','totalPV_MW','totalBattery_MW'}))
    n = min([numel(result.totalLoad_MW),numel(result.totalGeneration_MW), ...
        numel(result.totalPV_MW),numel(result.totalBattery_MW)]);
    t = time_axis_local(result,n);
    demand = positive_consumption_local(result.totalLoad_MW(1:n));
    dg = positive_generation_local(result.totalGeneration_MW(1:n));
    pv = positive_generation_local(result.totalPV_MW(1:n));
    batt = double(result.totalBattery_MW(1:n));

    fig = figure('Visible',vis,'Name',[char(prefix) ' - aggregate powers']);
    plot(t,demand,'LineWidth',1.1); hold on;
    plot(t,dg,'LineWidth',1.1);
    plot(t,pv,'LineWidth',1.1);
    plot(t,batt,'LineWidth',1.1);
    yline(0,'--','HandleVisibility','off');
    xlabel('Time (h)'); ylabel('Power (MW)');
    title([char(prefix) ' - aggregate power profiles']);
    legend({'Demand','DG generation','PV generation', ...
        'Battery net power (saved sign)'},'Location','best');
    grid on; hold off;
    profile.figures.aggregatePower = fig;
    export_local(fig,outputDir,'01_aggregate_power_profiles.png',opt.Export);
end

%% Individual DG / storage powers
hasDG = isfield(result,'P_DG_MW') && ~isempty(result.P_DG_MW);
hasBatt = isfield(result,'P_batt_MW') && ~isempty(result.P_batt_MW);
if hasDG || hasBatt
    fig = figure('Visible',vis,'Name',[char(prefix) ' - device powers']);
    tl = tiledlayout(2,1,'TileSpacing','compact','Padding','compact');
    nexttile;
    if hasDG
        X = double(result.P_DG_MW); t = time_axis_local(result,size(X,2));
        plot(t,X.','LineWidth',1.0);
        legend(compose('DG %d',1:size(X,1)),'Location','best');
    end
    xlabel('Time (h)'); ylabel('DG power (MW)');
    title('Individual DG active-power profiles'); grid on;

    nexttile;
    if hasBatt
        X = double(result.P_batt_MW); t = time_axis_local(result,size(X,2));
        plot(t,X.','LineWidth',0.9); yline(0,'--','HandleVisibility','off');
        if size(X,1)<=16
            legend(compose('Storage/EV %d',1:size(X,1)),'Location','eastoutside');
        end
    end
    xlabel('Time (h)'); ylabel('Power (MW)');
    title('Individual storage / EV power profiles (saved sign)'); grid on;
    title(tl,[char(prefix) ' - individual resource powers']);
    profile.figures.devicePower = fig;
    export_local(fig,outputDir,'02_individual_resource_power_profiles.png',opt.Export);
end

%% SoC trajectories
if isfield(result,'soc') && ~isempty(result.soc)
    X = double(result.soc); t = time_axis_local(result,size(X,2));
    fig = figure('Visible',vis,'Name',[char(prefix) ' - SoC']);
    plot(t,X.','LineWidth',0.9); hold on;
    yline(cfg.storage.SOCmin,'--','DisplayName','SoC min');
    yline(cfg.storage.SOCmax,'--','DisplayName','SoC max');
    xlabel('Time (h)'); ylabel('SoC');
    title([char(prefix) ' - all saved SoC trajectories']);
    ylim([0 1]); grid on; hold off;
    profile.figures.soc = fig;
    export_local(fig,outputDir,'03_soc_trajectories.png',opt.Export);
end

%% Frequency and RoCoF
if isfield(result,'freq_Hz') && ~isempty(result.freq_Hz)
    f = double(result.freq_Hz(:));
    tf = time_axis_local(result,numel(f));
    rocof = gradient(f,tf*3600);

    fig = figure('Visible',vis,'Name',[char(prefix) ' - frequency']);
    tl = tiledlayout(3,1,'TileSpacing','compact','Padding','compact');

    nexttile;
    plot(tf,f,'LineWidth',1.1); hold on;
    yline(cfg.frequency.nominal_Hz,'--','HandleVisibility','off');
    yline(cfg.frequency.nominal_Hz+cfg.frequency.securityDeviation_Hz,'--');
    yline(cfg.frequency.nominal_Hz-cfg.frequency.securityDeviation_Hz,'--');
    xlabel('Time (h)'); ylabel('CoI f (Hz)');
    title('Center-of-inertia frequency'); grid on; hold off;

    nexttile;
    if isfield(result,'freqAll_Hz') && ~isempty(result.freqAll_Hz)
        F = double(result.freqAll_Hz);
        ta = time_axis_local(result,size(F,2));
        plot(ta,F.','LineWidth',0.8); hold on;
        yline(cfg.frequency.nominal_Hz+cfg.frequency.securityDeviation_Hz,'--');
        yline(cfg.frequency.nominal_Hz-cfg.frequency.securityDeviation_Hz,'--');
        hold off;
    else
        plot(tf,f,'LineWidth',1.0);
    end
    xlabel('Time (h)'); ylabel('Frequency (Hz)');
    title('Individual frequency profiles'); grid on;

    nexttile;
    plot(tf,rocof,'LineWidth',1.0); hold on;
    yline(cfg.frequency.securityRoCoF_Hz_s,'--');
    yline(-cfg.frequency.securityRoCoF_Hz_s,'--');
    xlabel('Time (h)'); ylabel('RoCoF (Hz/s)');
    title('CoI RoCoF'); grid on; hold off;

    title(tl,[char(prefix) ' - frequency security']);
    profile.figures.frequency = fig;
    export_local(fig,outputDir,'04_frequency_and_rocof_profiles.png',opt.Export);
end

%% Network security
% voltage_pu and current_pu may be stored as complex phasors.  The physical
% quantities needed for the manuscript are magnitudes, so ALWAYS plot abs(.).
% This also prevents MATLAB warnings:
%   "Imaginary parts of complex X and/or Y arguments ignored."

hasV = isfield(result,'voltage_pu') && ~isempty(result.voltage_pu);
hasI = isfield(result,'current_pu') && ~isempty(result.current_pu);

if hasV || hasI
    fig = figure('Visible',vis,'Name',[char(prefix) ' - network']);
    tl = tiledlayout(2,1,'TileSpacing','compact','Padding','compact');

    nexttile;
    if hasV
        V = abs(double(result.voltage_pu));
        t = time_axis_local(result,size(V,2));

        vMin = min(V,[],1);
        vMax = max(V,[],1);

        plot(t,vMin,'LineWidth',1.1); hold on;
        plot(t,vMax,'LineWidth',1.1);
        yline(cfg.network.Vmin_pu,'--');
        yline(cfg.network.Vmax_pu,'--');

        legend({'Min bus |V|','Max bus |V|','Vmin','Vmax'}, ...
            'Location','best');
        hold off;
    end

    xlabel('Time (h)');
    ylabel('|V| (p.u.)');
    title('Voltage envelope');
    grid on;

    nexttile;
    if hasI
        I = abs(double(result.current_pu));
        t = time_axis_local(result,size(I,2));

        if isfield(result,'lineLimits_pu') && ...
                numel(result.lineLimits_pu)==size(I,1)

            lineLimit = abs(double(result.lineLimits_pu(:)));
            lineLimit(lineLimit<=0) = NaN;

            ratio = I ./ lineLimit;
            maxRatio = max(ratio,[],1,'omitnan');

            plot(t,maxRatio,'LineWidth',1.1); hold on;
            yline(1,'--');
            ylabel('Max |I| / limit');
            hold off;
        else
            plot(t,max(I,[],1),'LineWidth',1.1);
            ylabel('Max |I| (p.u.)');
        end
    end

    xlabel('Time (h)');
    title('Network-current loading');
    grid on;

    title(tl,[char(prefix) ' - network security']);

    profile.figures.network = fig;
    export_local(fig,outputDir,'05_network_security_profiles.png',opt.Export);
end

%% Baseline/executed load and reduction
if isfield(result,'loadBaseline_MW') && isfield(result,'loadExecuted_MW') && ...
        ~isempty(result.loadBaseline_MW) && ~isempty(result.loadExecuted_MW)
    B = double(result.loadBaseline_MW);
    E = double(result.loadExecuted_MW);
    n = min(size(B,2),size(E,2)); B=B(:,1:n); E=E(:,1:n);
    base = positive_consumption_local(sum(B,1));
    exec = positive_consumption_local(sum(E,1));
    reduction = max(base-exec,0);
    t = time_axis_local(result,n);

    fig = figure('Visible',vis,'Name',[char(prefix) ' - flexibility']);
    tl = tiledlayout(2,1,'TileSpacing','compact','Padding','compact');
    nexttile;
    plot(t,base,'LineWidth',1.1); hold on; plot(t,exec,'LineWidth',1.1);
    legend({'Baseline load','Executed load'},'Location','best');
    xlabel('Time (h)'); ylabel('Load (MW)');
    title('Baseline versus executed load'); grid on; hold off;
    nexttile;
    area(t,reduction);
    xlabel('Time (h)'); ylabel('Load reduction (MW)');
    title('Aggregate load reduction / shedding profile'); grid on;
    title(tl,[char(prefix) ' - flexibility allocation']);
    profile.figures.flexibility = fig;
    export_local(fig,outputDir,'06_load_flexibility_profiles.png',opt.Export);
end

%% Reserve profiles
alpha = extract_vector_local(result,'reserve', ...
    {'ratio','reserveRatio','alpha','alphaSelected','selectedAlpha', ...
     'ratioRecord','reserveRatioRecord'});
reservePower = extract_vector_local(result,'reserve', ...
    {'totalReserve_kW','totalDGReserve_kW','reserveTotal_kW', ...
     'totalReserve','reservePower_kW'});

if ~isempty(alpha) || ~isempty(reservePower)
    fig = figure('Visible',vis,'Name',[char(prefix) ' - reserve']);
    nTiles = 1 + (~isempty(alpha) && ~isempty(reservePower));
    tl = tiledlayout(nTiles,1,'TileSpacing','compact','Padding','compact');
    if ~isempty(alpha)
        nexttile; a=double(alpha(:)); t=linspace(0,24,numel(a));
        stairs(t,a,'LineWidth',1.1); xlabel('Time (h)'); ylabel('\alpha');
        title('Reserve-ratio profile'); ylim([0 1.05]); grid on;
    end
    if ~isempty(reservePower)
        nexttile; r=double(reservePower(:)); t=linspace(0,24,numel(r));
        stairs(t,r,'LineWidth',1.1); xlabel('Time (h)'); ylabel('Reserve (kW)');
        title('Total DG reserve profile'); grid on;
    end
    title(tl,[char(prefix) ' - reserve policy']);
    profile.figures.reserve = fig;
    export_local(fig,outputDir,'07_reserve_profiles.png',opt.Export);
end

%% Cost profiles
if isfield(result,'costRecord') && ~isempty(result.costRecord)
    c = double(result.costRecord(:)); t = time_axis_local(result,numel(c));
    fig = figure('Visible',vis,'Name',[char(prefix) ' - cost']);
    tl = tiledlayout(2,1,'TileSpacing','compact','Padding','compact');
    nexttile; plot(t,c,'LineWidth',1.0);
    xlabel('Time (h)'); ylabel('Cost increment ($)');
    title('Instantaneous saved cost record'); grid on;
    nexttile; plot(t,cumsum(c),'LineWidth',1.1);
    xlabel('Time (h)'); ylabel('Cumulative cost ($)');
    title('Cumulative operating cost'); grid on;
    title(tl,[char(prefix) ' - operating cost']);
    profile.figures.cost = fig;
    export_local(fig,outputDir,'08_operating_cost_profiles.png',opt.Export);
end

fprintf('Profile replay complete: %s | %s | decay %.2f\n', ...
    caseName,paperLabel,decayRatio);
if opt.Export, fprintf('  figures: %s\n',outputDir); end
end

function result = load_result_local(filePath)
S = load(filePath);
if isfield(S,'result') && isstruct(S.result), result=S.result; return; end
names=fieldnames(S);
for k=1:numel(names)
    x=S.(names{k});
    if isstruct(x) && (isfield(x,'freq_Hz')||isfield(x,'summary')||isfield(x,'totalCost'))
        result=x; return;
    end
end
error('Could not identify result struct in %s.',filePath);
end

function t = time_axis_local(result,n)
if isfield(result,'time_h') && ~isempty(result.time_h)
    x=double(result.time_h(:));
    if numel(x)==n, t=x; return; end
    if numel(x)==n-1 && n>1
        dt=median(diff(x)); t=[x; x(end)+dt]; return;
    end
    if numel(x)>n, t=x(1:n); return; end
end
t=linspace(0,24,n).';
end

function y = positive_consumption_local(x)
y=double(x(:)); f=y(isfinite(y));
if ~isempty(f)&&median(f)<0, y=-y; end
y=y(:).';
end

function y = positive_generation_local(x)
y=double(x(:)); f=y(isfinite(y));
if ~isempty(f)&&mean(f)<0, y=-y; end
y=y(:).';
end

function x = extract_vector_local(result,parentName,candidates)
x=[];
if ~isfield(result,parentName)||~isstruct(result.(parentName)), return; end
s=result.(parentName);
for k=1:numel(candidates)
    name=candidates{k};
    if isfield(s,name)
        v=s.(name);
        if isnumeric(v)&&isvector(v)&&~isempty(v), x=v; return; end
    end
end
end

function export_local(fig,outputDir,fileName,doExport)
if doExport, exportgraphics(fig,fullfile(outputDir,fileName),'Resolution',220); end
end
