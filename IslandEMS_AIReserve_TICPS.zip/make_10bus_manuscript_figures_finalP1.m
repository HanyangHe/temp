%% make_10bus_manuscript_figures_finalP1.m
% Updated manuscript figure generator for the FINAL 10-bus run.
%
% This version fixes the issues you reported:
%   1) outputs ALL THREE manuscript figures;
%   2) moves legends away from curve/bar overlap regions;
%   3) makes the first plotted curve visually stronger;
%   4) keeps replay-only behavior (NO optimization / NO simulation);
%   5) marks unsafe G1/P1U intervals so overlapping stress traces remain visible.
%
% Generated files:
%   figs/AI_sample_and_prediction_10bus.pdf
%   figs/adaptive_reserve_10bus.pdf
%   figs/curtailment_10bus.pdf
%
% Recommended use from project root:
%   make_10bus_manuscript_figures_finalP1

clear;
clc;
close all force;

%% User settings
RUN_TAG   = '20260910_finalP1_10bus';
CASE_NAME = '10bus';
SEED      = 0;
DECAY_P1_NORMAL = 1.00;
PART2_DECAYS = [0.20 0.40 0.60 0.80 1.00];

DF_LIM_HZ      = 0.50;
ROCOF_LIM_HZ_S = 0.50;

projectRoot = pwd;
runRoot = fullfile(projectRoot,'outputs',RUN_TAG);
figDir  = fullfile(projectRoot,'figs');

assert(exist(runRoot,'dir')==7, ...
    'Final run folder not found: %s',runRoot);

if ~exist(figDir,'dir')
    mkdir(figDir);
end

fprintf('Project root : %s\n',projectRoot);
fprintf('Run root     : %s\n',runRoot);
fprintf('Figure dir   : %s\n\n',figDir);

%% Resolve AI files for Fig. AI_model
cfg = try_config_local();
[datasetFile, modelFile] = resolve_ai_assets_local(cfg,projectRoot,CASE_NAME);

%% ========================================================================
% FIGURE 1: 10-bus offline response data / KRR motivation
% =========================================================================
fprintf('Generating AI_sample_and_prediction_10bus.pdf ...\n');

try
    [aiData, aiNote] = load_ai_dataset_local(datasetFile);
catch ME
    warning('AI dataset decoder skipped after unexpected schema error: %s',ME.message);
    aiData = empty_ai_data_local();
    aiNote = "decoder error: " + string(ME.message);
end

if isempty(aiData.alpha) || isempty(aiData.y) || size(aiData.X,1)==0
    fprintf(2,['WARNING: the AI dataset was not decoded automatically.\n', ...
        'The script will NOT stop; Part-I and Part-II figures will still be generated.\n']);
    print_mat_inventory_local(datasetFile);

    oldAI = fullfile(figDir,'AI_sample_and_prediction_10bus.pdf');
    if exist(oldAI,'file')==2
        fprintf(['Keeping the existing AI figure unchanged:\n  %s\n\n'],oldAI);
    else
        fprintf(2,['No existing AI_sample_and_prediction_10bus.pdf was found.\n', ...
            'Please send the printed MAT inventory so the dataset adapter can be finalized.\n\n']);
    end
else
    X = double(aiData.X);
    alphaAll = double(aiData.alpha(:));
    yAll = double(aiData.y(:));

    good = all(isfinite(X),2) & isfinite(alphaAll) & isfinite(yAll);
    X = X(good,:);
    alphaAll = alphaAll(good);
    yAll = yAll(good);

    assert(~isempty(alphaAll), ...
        'Decoded AI dataset contains no finite alpha/stress rows.');

    fprintf('AI dataset decoded: %d finite rows (%s)\n', ...
        numel(yAll),char(aiNote));

    f0 = figure('Color','w','Position',[50 40 820 900]);
    tl0 = tiledlayout(f0,3,1,'TileSpacing','compact','Padding','compact');

    % (a) sampled operating states
    ax0a = nexttile(tl0,1);
    scatter3(ax0a,X(:,1),X(:,2),X(:,3),16,yAll,'filled');
    grid(ax0a,'on');
    % Use the same mathematical feature symbols as in the manuscript.
    xlabel(ax0a,'$P_{\mathrm{net}}(\mathrm{pu})$', ...
        'Interpreter','latex');
    ylabel(ax0a,'$|\Delta P_{\mathrm{net}}|(\mathrm{pu})$', ...
        'Interpreter','latex');
    zlabel(ax0a,'$H_{\mathrm{DG}}(\mathrm{pu})$', ...
        'Interpreter','latex');
    title(ax0a,'(a) Sampled operating states');
    view(ax0a,38,24);
    cb = colorbar(ax0a);
    % Point color represents the normalized frequency-stress label y_k.
    % Keep the numeric color scale but omit the vertical colorbar label
    % to reduce clutter in the single-column manuscript figure.
    cb.Label.String = '';

    % (b) frequency stress versus reserve ratio
    ax0b = nexttile(tl0,2);
    hold(ax0b,'on');
    hSamples = scatter(ax0b,alphaAll,yAll,15,'filled', ...
        'MarkerFaceAlpha',0.20,'MarkerEdgeAlpha',0.20);
    [binX,binY] = alpha_level_mean_local(alphaAll,yAll);
    hMean = plot(ax0b,binX,binY,'-o','LineWidth',2.3,'MarkerSize',5);
    yline(ax0b,1,'--','Security limit','LineWidth',1.0, ...
        'HandleVisibility','off');
    xlabel(ax0b,'Reserve ratio \alpha');
    ylabel(ax0b,'$y_k$','Interpreter','latex');
    title(ax0b,'(b) Stress versus reserve ratio');
    grid(ax0b,'on');

    xmin = min(alphaAll);
    xmax = max(alphaAll);
    if isfinite(xmin) && isfinite(xmax) && xmax > xmin
        pad = max(0.02,0.04*(xmax-xmin));
        xlim(ax0b,[max(0,xmin-pad) min(1.05,xmax+pad)]);
    end

    legend(ax0b,[hSamples hMean],{'Samples','Mean by \alpha level'}, ...
        'Location','southoutside','Orientation','horizontal','Box','off');

    % (c) state-conditioned reserve-response trends.
    % Use three net-load regimes. This is more useful for the manuscript
    % story than forcing a held-out scatter here: the quantitative RMSE/MAE
    % remains reported in Table III, while this panel shows why a
    % state-dependent response model is required.
    ax0c = nexttile(tl0,3);
    hold(ax0c,'on');

    q1 = quantile(X(:,1),1/3);
    q2 = quantile(X(:,1),2/3);
    stateMasks = {X(:,1)<=q1, X(:,1)>q1 & X(:,1)<=q2, X(:,1)>q2};
    stateNames = {'Low net load','Medium net load','High net load'};
    lineWidths = [2.4 1.35 1.35];
    hh = gobjects(3,1);

    for g = 1:3
        [gx,gy] = alpha_level_mean_local(alphaAll(stateMasks{g}), ...
                                         yAll(stateMasks{g}));
        hh(g) = plot(ax0c,gx,gy,'-o', ...
            'LineWidth',lineWidths(g),'MarkerSize',4);
    end

    yline(ax0c,1,'--','Security limit','LineWidth',1.0, ...
        'HandleVisibility','off');
    xlabel(ax0c,'Reserve ratio \alpha');
    ylabel(ax0c,'Mean $y_k$','Interpreter','latex');
    title(ax0c,'(c) State-conditioned reserve-response trends');
    grid(ax0c,'on');

    if isfinite(xmin) && isfinite(xmax) && xmax > xmin
        pad = max(0.02,0.04*(xmax-xmin));
        xlim(ax0c,[max(0,xmin-pad) min(1.05,xmax+pad)]);
    end

    legend(ax0c,hh,stateNames, ...
        'Location','southoutside','Orientation','horizontal','Box','off');

    style_all_axes_local(f0);

    out0 = fullfile(figDir,'AI_sample_and_prediction_10bus.pdf');
    exportgraphics(f0,out0,'ContentType','vector');
    fprintf('Exported: %s\n\n',out0);
end

%% ========================================================================
% FIGURE 2: adaptive reserve (Part I)
% =========================================================================
fprintf('Generating adaptive_reserve_10bus.pdf ...\n');

part1IDs    = ["A0","T7","G1","P1U","P1"];
part1Labels = ["A0","F1","G1","P1U","P1"];
R1 = struct();

for i = 1:numel(part1IDs)
    id = part1IDs(i);
    file = find_result_local(runRoot,char(id),CASE_NAME,DECAY_P1_NORMAL,SEED);
    R1.(char(id)) = load_result_local(file);
end

P1  = R1.P1;
P1U = R1.P1U;
G1  = R1.G1;
F1  = R1.T7;

n = numel(P1.reserve.ratio);
t_h = (0:n-1)' * 0.25;

alphaFinal       = double(P1.reserve.ratio(:));
alphaKRRProposal = nan(n,1);
guardTriggered   = false(n,1);
moderateBranch   = false(n,1);
severeBranch     = false(n,1);

if isfield(P1.reserve,'metaHistory')
    H = P1.reserve.metaHistory;
    for k = 1:min(n,numel(H))
        m = H{k};
        if ~isstruct(m) || ~isfield(m,'prediction') || ~isstruct(m.prediction)
            continue;
        end
        q = m.prediction;
        alphaKRRProposal(k) = scalar_field_local(q,'preShieldAlpha',NaN);
        guardTriggered(k)   = logical_field_local(q,'forecastSafetyShieldTriggered',false);
        moderateBranch(k)   = logical_field_local(q,'forecastSafetyShieldModerateBranch',false);
        severeBranch(k)     = logical_field_local(q,'forecastSafetyShieldSevereBranch',false);
    end
end

alphaKRRProposal(~isfinite(alphaKRRProposal)) = alphaFinal(~isfinite(alphaKRRProposal));

stressF1  = interval_stress_local(F1, DF_LIM_HZ, ROCOF_LIM_HZ_S);
stressG1  = interval_stress_local(G1, DF_LIM_HZ, ROCOF_LIM_HZ_S);
stressP1U = interval_stress_local(P1U,DF_LIM_HZ, ROCOF_LIM_HZ_S);
stressP1  = interval_stress_local(P1, DF_LIM_HZ, ROCOF_LIM_HZ_S);

meanAlpha1 = zeros(numel(part1IDs),1);
cost1      = zeros(numel(part1IDs),1);
for i = 1:numel(part1IDs)
    rr = R1.(char(part1IDs(i)));
    meanAlpha1(i) = mean(double(rr.reserve.ratio(:)),'omitnan');
    cost1(i)      = scalar_total_cost_local(rr);
end

f1 = figure('Color','w','Position',[100 70 820 920]);
tl1 = tiledlayout(f1,3,1,'TileSpacing','compact','Padding','compact');

% (a) reserve policy
ax1 = nexttile(tl1,1);
hold(ax1,'on');

% Plot final reserve first, then thick KRR proposal on top, then full reserve
hFinal = stairs(ax1,t_h,alphaFinal,'LineWidth',1.35);
hKrr   = stairs(ax1,t_h,alphaKRRProposal,'LineWidth',2.25,'LineStyle','--');
hF1    = yline(ax1,1,'-.','F1','LineWidth',1.0);

idxGuard = find(guardTriggered);
hGuard = gobjects(1,1);
if ~isempty(idxGuard)
    hGuard = scatter(ax1,t_h(idxGuard),alphaFinal(idxGuard),26,'filled');
end

% Optional branch-specific markers (not placed in legend to keep it clean)
idxSev = find(severeBranch);
if ~isempty(idxSev)
    scatter(ax1,t_h(idxSev),alphaFinal(idxSev),28,'d','filled', ...
        'HandleVisibility','off');
end

xlim(ax1,[0 24]);
ylim(ax1,[0.55 1.04]);
ylabel(ax1,'Reserve ratio \alpha');
title(ax1,'(a) KRR proposal and final guarded reserve');
grid(ax1,'on');

if isempty(idxGuard)
    legend(ax1,[hKrr hFinal hF1], ...
        {'KRR proposal','Final P1','Full reserve'}, ...
        'Location','southoutside','Orientation','horizontal','Box','off');
else
    legend(ax1,[hKrr hFinal hF1 hGuard], ...
        {'KRR proposal','Final P1','Full reserve','Guard intervention'}, ...
        'Location','southoutside','Orientation','horizontal','Box','off');
end

% (b) security stress
ax2 = nexttile(tl1,2);
hold(ax2,'on');

% Include G1 so panel (b) directly explains why its apparently attractive
% reserve/cost point in panel (c) may be unacceptable from the security view.
% Draw P1U before G1 and explicitly mark unsafe G1/P1U intervals so nearly
% coincident trajectories cannot visually hide one another.
hStressF1  = stairs(ax2,t_h,stressF1, 'LineWidth',2.50,'LineStyle','-');
hStressP1U = stairs(ax2,t_h,stressP1U,'LineWidth',1.25,'LineStyle','-.');
hStressG1  = stairs(ax2,t_h,stressG1, 'LineWidth',2.00,'LineStyle','--');
hStressP1  = stairs(ax2,t_h,stressP1, 'LineWidth',1.50,'LineStyle','-');

idxG1Unsafe = find(stressG1>1);
if ~isempty(idxG1Unsafe)
    scatter(ax2,t_h(idxG1Unsafe),stressG1(idxG1Unsafe),34,'o', ...
        'LineWidth',1.2,'HandleVisibility','off');
end

idxP1UUnsafe = find(stressP1U>1);
if ~isempty(idxP1UUnsafe)
    scatter(ax2,t_h(idxP1UUnsafe),stressP1U(idxP1UUnsafe),34,'x', ...
        'LineWidth',1.2,'HandleVisibility','off');
end

yline(ax2,1,'--','Security limit','LineWidth',1.0,'HandleVisibility','off');

xlim(ax2,[0 24]);
ylabel(ax2,'Normalized CoI stress');
title(ax2,'(b) Interval frequency-security stress');
grid(ax2,'on');
legend(ax2,[hStressF1 hStressG1 hStressP1U hStressP1], ...
    {'F1','G1','P1U','P1'}, ...
    'Location','southoutside','Orientation','horizontal', ...
    'NumColumns',4,'Box','off');

fprintf(['Part-I panel (b) security check: max stress ', ...
    'F1=%.4f G1=%.4f P1U=%.4f P1=%.4f | ', ...
    'unsafe intervals G1=%d P1U=%d\n'], ...
    max(stressF1),max(stressG1),max(stressP1U),max(stressP1), ...
    nnz(stressG1>1),nnz(stressP1U>1));

% (c) reserve--economic tradeoff
ax3 = nexttile(tl1,3);
x = 1:numel(part1Labels);

yyaxis(ax3,'left');
hb = bar(ax3,x,meanAlpha1,0.62);
ylabel(ax3,'Mean reserve ratio');
ylim(ax3,[0 1.08]);

yyaxis(ax3,'right');
hp = plot(ax3,x,cost1,'-o','LineWidth',2.15,'MarkerSize',5);
ylabel(ax3,'Daily cost ($)');

xticks(ax3,x);
xticklabels(ax3,cellstr(part1Labels));
xlim(ax3,[0.4 numel(x)+0.6]);
xlabel(ax3,'Method');
title(ax3,'(c) Reserve--economic tradeoff');
grid(ax3,'on');
legend(ax3,[hb hp],{'Mean reserve ratio','Daily cost'}, ...
    'Location','southoutside','Orientation','horizontal','Box','off');

style_all_axes_local(f1);

out1 = fullfile(figDir,'adaptive_reserve_10bus.pdf');
exportgraphics(f1,out1,'ContentType','vector');
fprintf('Exported: %s\n\n',out1);

%% ========================================================================
% FIGURE 3: curtailment allocation and operating cost (Part II)
% =========================================================================
fprintf('Generating curtailment_10bus.pdf ...\n');

part2IDs = ["C0","C1","P1"];
cost2 = nan(numel(PART2_DECAYS),numel(part2IDs));
loadShed = nan(size(cost2));
evUnmet  = nan(size(cost2));
bessDef  = nan(size(cost2));
meanAlpha2 = nan(size(cost2));

for j = 1:numel(part2IDs)
    for i = 1:numel(PART2_DECAYS)
        rr = load_result_local( ...
            find_result_local(runRoot,char(part2IDs(j)),CASE_NAME,PART2_DECAYS(i),SEED));

        cost2(i,j)      = scalar_total_cost_local(rr);
        meanAlpha2(i,j) = mean(double(rr.reserve.ratio(:)),'omitnan');
        loadShed(i,j)   = summary_metric_local(rr,'loadShedEnergy_kWh');
        evUnmet(i,j)    = summary_metric_local(rr,'EVUnmetEnergy_kWh');
        bessDef(i,j)    = summary_metric_local(rr,'BESSTerminalDeficit_kWh');
    end
end

% basic parity check
alphaSpread = max(max(meanAlpha2,[],2)-min(meanAlpha2,[],2));
if alphaSpread > 1e-8
    warning('Part-II methods do not have identical reserve ratios. Spread = %.3g',alphaSpread);
end

f2 = figure('Color','w','Position',[130 70 820 920]);
tl2 = tiledlayout(f2,3,1,'TileSpacing','compact','Padding','compact');

% (a) operating cost
bx1 = nexttile(tl2,1);
hold(bx1,'on');
hC0 = plot(bx1,PART2_DECAYS,cost2(:,1),'-o','LineWidth',2.20,'MarkerSize',5);
hC1 = plot(bx1,PART2_DECAYS,cost2(:,2),'-s','LineWidth',1.20,'MarkerSize',5);
hP1 = plot(bx1,PART2_DECAYS,cost2(:,3),'-^','LineWidth',1.45,'MarkerSize',5);
xlim(bx1,[0.18 1.02]);
xticks(bx1,PART2_DECAYS);
ylabel(bx1,'Daily cost ($)');
title(bx1,'(a) Operating cost');
grid(bx1,'on');
legend(bx1,[hC0 hC1 hP1],{'C0','C1','P1'}, ...
    'Location','southoutside','Orientation','horizontal','Box','off');

% (b) load shedding
bx2 = nexttile(tl2,2);
hold(bx2,'on');
hLS0 = plot(bx2,PART2_DECAYS,loadShed(:,1),'-o','LineWidth',2.20,'MarkerSize',5);
hLS1 = plot(bx2,PART2_DECAYS,loadShed(:,2),'-s','LineWidth',1.20,'MarkerSize',5);
hLSP = plot(bx2,PART2_DECAYS,loadShed(:,3),'-^','LineWidth',1.45,'MarkerSize',5);
xlim(bx2,[0.18 1.02]);
xticks(bx2,PART2_DECAYS);
ylabel(bx2,'Load shedding (kWh)');
title(bx2,'(b) Direct load interruption');
grid(bx2,'on');
legend(bx2,[hLS0 hLS1 hLSP],{'C0','C1','P1'}, ...
    'Location','southoutside','Orientation','horizontal','Box','off');

% (c) service-deferment allocation at gamma = 0.20
bx3 = nexttile(tl2,3);
alloc = [loadShed(1,:)' evUnmet(1,:)' bessDef(1,:)'];
bh = bar(bx3,alloc,'stacked');
xticks(bx3,1:3);
xticklabels(bx3,cellstr(part2IDs));
ylabel(bx3,'Energy (kWh)');
xlabel(bx3,'Method');
title(bx3,'(c) Service-deferment allocation at \gamma_{PV}=0.20');
grid(bx3,'on');
legend(bx3,bh,{'Load shedding','EV unmet charging','BESS terminal deficit'}, ...
    'Location','southoutside','Orientation','horizontal','Box','off');

style_all_axes_local(f2);

out2 = fullfile(figDir,'curtailment_10bus.pdf');
exportgraphics(f2,out2,'ContentType','vector');
fprintf('Exported: %s\n\n',out2);

fprintf('Done.\n');
fprintf('Three manuscript figures are in:\n  %s\n',figDir);


%% =========================================================================
% Local helpers
% =========================================================================
function cfg = try_config_local()
cfg = struct();
if exist('config_island_ems','file')==2
    try
        cfg = config_island_ems();
    catch
        cfg = struct();
    end
end
end


function [datasetFile, modelFile] = resolve_ai_assets_local(cfg,projectRoot,caseName)

datasetFile = "";
modelFile   = "";

% dataset
if isfield(cfg,'ai')
    if isfield(cfg.ai,'datasetRoot') && isfield(cfg.ai,'datasetFileName')
        cand = { ...
            fullfile(projectRoot,cfg.ai.datasetRoot,caseName,cfg.ai.datasetFileName), ...
            fullfile(projectRoot,cfg.ai.datasetRoot,cfg.ai.datasetFileName)};
        for i = 1:numel(cand)
            if exist(cand{i},'file')==2
                datasetFile = string(cand{i});
                break;
            end
        end
    end

    if strlength(datasetFile)==0 && isfield(cfg.ai,'modelRoot') && isfield(cfg.ai,'modelFileName')
        cand = { ...
            fullfile(projectRoot,cfg.ai.modelRoot,caseName,cfg.ai.modelFileName), ...
            fullfile(projectRoot,cfg.ai.modelRoot,cfg.ai.modelFileName)};
        for i = 1:numel(cand)
            if exist(cand{i},'file')==2
                modelFile = string(cand{i});
                break;
            end
        end
    end
end

if strlength(datasetFile)==0
    hits = dir(fullfile(projectRoot,'**','reserve_response_dataset*.mat'));
    if ~isempty(hits)
        chosen = choose_path_with_case_local(hits,caseName);
        datasetFile = string(fullfile(chosen.folder,chosen.name));
    end
end

if strlength(modelFile)==0
    hits = dir(fullfile(projectRoot,'**','reserve_krr_model.mat'));
    if ~isempty(hits)
        chosen = choose_path_with_case_local(hits,caseName);
        modelFile = string(fullfile(chosen.folder,chosen.name));
    end
end
end


function chosen = choose_path_with_case_local(hits,caseName)
chosen = hits(1);
for k = 1:numel(hits)
    p = lower(fullfile(hits(k).folder,hits(k).name));
    if contains(p,lower(caseName))
        chosen = hits(k);
        return;
    end
end
end


function S = load_model_local(modelFile)
S = [];
if strlength(modelFile)==0 || exist(modelFile,'file')~=2
    return;
end
T = load(modelFile);
if isfield(T,'model') && isstruct(T.model)
    S = T.model;
    return;
end
names = fieldnames(T);
for i = 1:numel(names)
    x = T.(names{i});
    if isstruct(x) && isfield(x,'stateFeatureNames')
        S = x;
        return;
    end
end
end


function [aiData,note] = load_ai_dataset_local(datasetFile)
% Robust adapter for the paper response dataset.
%
% Supports, among others:
%   X [N x 4], Y [N x 1], where X(:,4) is alpha;
%   X [N x 3] + separate alpha + Y;
%   top-level or nested tables;
%   nested structs with common field-name variants.

aiData = empty_ai_data_local();
note = "dataset not found";

if strlength(datasetFile)==0 || exist(datasetFile,'file')~=2
    warning('AI dataset file not found.');
    return;
end

S = load(datasetFile);
note = "MAT loaded";

% IMPORTANT FIX relative to v2:
% First parse the TOP-LEVEL loaded MAT struct itself.  The paper dataset may
% store X/Y directly at top level rather than inside a "dataset" struct.
[ok,out,why] = infer_ai_dataset_from_struct_local(S,0);
if ok
    aiData = out;
    note = why;
    return;
end

warning('Could not infer AI dataset schema from %s',datasetFile);
end


function out = empty_ai_data_local()
out = struct( ...
    'X',nan(0,3), ...
    'alpha',nan(0,1), ...
    'y',nan(0,1), ...
    'featureNames',string(["netLoadNow_pu","absNetLoadRamp_pu","dgUpHeadroom_pu"]));
end


function [ok,out,why] = infer_ai_dataset_from_struct_local(ds,depth)
ok = false;
out = empty_ai_data_local();
why = "not inferred";

if depth > 6 || ~isstruct(ds)
    return;
end

% Struct arrays of scalar records -> table when possible.
if numel(ds)>1
    try
        T = struct2table(ds);
        [ok,out,why] = infer_ai_dataset_from_table_local(T);
        if ok
            why = "struct-array table";
            return;
        end
    catch
    end
    return;
end

fn = fieldnames(ds);

% 1) Any table at this level.
for i = 1:numel(fn)
    v = ds.(fn{i});
    if istable(v)
        [ok,out,why] = infer_ai_dataset_from_table_local(v);
        if ok
            why = "table field " + string(fn{i});
            return;
        end
    end
end

% 2) Matrix-style datasets.
% Common final-training format is X=[state(3), alpha] and Y=stress.
Xraw = [];
xField = "";

xNames = ["X","inputs","input","features","featureMatrix", ...
          "predictors","responseX","trainingX","dataX","samplesX"];

for i = 1:numel(fn)
    name = string(fn{i});
    v = ds.(fn{i});
    if isnumeric(v) && ismatrix(v) && size(v,1)>=20 && size(v,2)>=3
        if any(strcmpi(name,xNames)) || contains(lower(name),"feature") ...
                || contains(lower(name),"input") || strcmpi(name,"x")
            Xraw = double(v);
            xField = name;
            break;
        end
    end
end

% If no semantically named X was found, accept an unambiguous N x 4 matrix.
if isempty(Xraw)
    cand = {};
    candName = strings(0);
    for i = 1:numel(fn)
        v = ds.(fn{i});
        if isnumeric(v) && ismatrix(v) && size(v,1)>=20 && size(v,2)==4
            cand{end+1} = double(v); %#ok<AGROW>
            candName(end+1) = string(fn{i}); %#ok<AGROW>
        end
    end
    if numel(cand)==1
        Xraw = cand{1};
        xField = candName(1);
    end
end

y = [];
yField = "";
yNames = ["Y","y","target","targets","label","labels","stress", ...
          "targetStress","frequencyStress","normalizedStress", ...
          "response","responseY","trainingY","dataY"];

if ~isempty(Xraw)
    N = size(Xraw,1);

    for i = 1:numel(fn)
        name = string(fn{i});
        v = ds.(fn{i});
        if isnumeric(v) && isvector(v) && numel(v)==N
            if any(strcmpi(name,yNames)) || contains(lower(name),"stress") ...
                    || contains(lower(name),"target") || strcmpi(name,"y")
                y = double(v(:));
                yField = name;
                break;
            end
        end
    end

    alpha = [];
    alphaField = "";

    % Most likely paper format: X(:,4) is candidate alpha.
    if size(Xraw,2)>=4
        alphaCandidate = Xraw(:,4);
        if alpha_plausible_local(alphaCandidate)
            alpha = alphaCandidate;
            alphaField = xField + "(:,4)";
        end
    end

    % Otherwise seek a separate alpha/reserve-ratio vector.
    if isempty(alpha)
        for i = 1:numel(fn)
            name = string(fn{i});
            v = ds.(fn{i});
            if isnumeric(v) && isvector(v) && numel(v)==N
                lname = lower(name);
                if contains(lname,"alpha") || ...
                        (contains(lname,"reserve") && contains(lname,"ratio"))
                    a = double(v(:));
                    if alpha_plausible_local(a)
                        alpha = a;
                        alphaField = name;
                        break;
                    end
                end
            end
        end
    end

    if ~isempty(y) && ~isempty(alpha)
        out.X = Xraw(:,1:3);
        out.alpha = alpha(:);
        out.y = y(:);
        out.featureNames = get_feature_names_local(ds);
        ok = true;
        why = "matrix fields " + xField + ", " + alphaField + ", " + yField;
        return;
    end
end

% 3) Separate named feature vectors + alpha + stress.
% Keep this optional adapter non-fatal: an unfamiliar nested metadata struct
% should never prevent the other manuscript figures from being generated.
try
    [okVec,outVec,whyVec] = infer_separate_vectors_local(ds);
catch ME
    okVec = false;
    outVec = empty_ai_data_local();
    whyVec = "separate-vector adapter skipped: " + string(ME.message);
end
if okVec
    ok = true;
    out = outVec;
    why = whyVec;
    return;
end

% 4) Recurse through nested structs/cells.
for i = 1:numel(fn)
    v = ds.(fn{i});

    if isstruct(v)
        [ok2,out2,why2] = infer_ai_dataset_from_struct_local(v,depth+1);
        if ok2
            ok = true;
            out = out2;
            why = string(fn{i}) + "." + why2;
            return;
        end

    elseif iscell(v) && ~isempty(v)
        % Handle cells containing tables or structs, common in trajectory data.
        for j = 1:min(numel(v),50)
            x = v{j};
            if istable(x)
                [ok2,out2,why2] = infer_ai_dataset_from_table_local(x);
                if ok2
                    ok = true;
                    out = out2;
                    why = string(fn{i}) + "{cell table}";
                    return;
                end
            elseif isstruct(x)
                [ok2,out2,why2] = infer_ai_dataset_from_struct_local(x,depth+1);
                if ok2
                    ok = true;
                    out = out2;
                    why = string(fn{i}) + "{cell}." + why2;
                    return;
                end
            end
        end
    end
end
end


function [ok,out,why] = infer_ai_dataset_from_table_local(T)
ok = false;
out = empty_ai_data_local();
why = "table not inferred";

if height(T)<20
    return;
end

names = string(T.Properties.VariableNames);
normNames = normalize_names_local(names);

iNet  = best_col_local(normNames, ...
    ["netloadnowpu","netloadpu","netloadnow"], ...
    ["netload"],["ramp","delta","change","drop"]);
iRamp = best_col_local(normNames, ...
    ["absnetloadramppu","netloadramppu","absnetloadramp"], ...
    ["netload","ramp"],[]);
iHead = best_col_local(normNames, ...
    ["dgupheadroompu","upheadroompu","dgheadroompu"], ...
    ["headroom"],[]);
iAlpha = best_col_local(normNames, ...
    ["alpha","reservealpha","reserveratio","candidatealpha","alpharatio"], ...
    ["alpha"],[]);
if isempty(iAlpha)
    iAlpha = best_col_local(normNames,[],["reserve","ratio"],[]);
end
iY = best_col_local(normNames, ...
    ["stress","targetstress","frequencystress","normalizedstress","y"], ...
    ["stress"],[]);

% MATLAB concatenation drops empty [] entries.  Therefore do NOT
% concatenate the indices before testing them; otherwise one missing field
% can silently shorten the vector and later cause "index exceeds array".
if isempty(iNet) || isempty(iRamp) || isempty(iHead) || ...
        isempty(iAlpha) || isempty(iY)
    return;
end

idx = [iNet iRamp iHead iAlpha iY];

try
    X = [double(T{:,iNet}) double(T{:,iRamp}) double(T{:,iHead})];
    a = double(T{:,iAlpha});
    y = double(T{:,iY});
catch
    return;
end

a = a(:);
y = y(:);

if size(X,1)~=numel(a) || numel(a)~=numel(y) || ~alpha_plausible_local(a)
    return;
end

out.X = X;
out.alpha = a;
out.y = y;
out.featureNames = ["netLoadNow_pu","absNetLoadRamp_pu","dgUpHeadroom_pu"];
ok = true;
why = "table columns";
end


function [ok,out,why] = infer_separate_vectors_local(ds)
ok = false;
out = empty_ai_data_local();
why = "separate vectors not inferred";

fn = fieldnames(ds);
names = string(fn);
normNames = normalize_names_local(names);

iNet  = best_col_local(normNames, ...
    ["netloadnowpu","netloadpu","netloadnow"],["netload"],["ramp","delta","change","drop"]);
iRamp = best_col_local(normNames, ...
    ["absnetloadramppu","netloadramppu","absnetloadramp"],["netload","ramp"],[]);
iHead = best_col_local(normNames, ...
    ["dgupheadroompu","upheadroompu","dgheadroompu"],["headroom"],[]);
iAlpha = best_col_local(normNames, ...
    ["alpha","reservealpha","reserveratio","candidatealpha","alpharatio"],["alpha"],[]);
iY = best_col_local(normNames, ...
    ["stress","targetstress","frequencystress","normalizedstress","y"],["stress"],[]);

% MATLAB concatenation drops empty [] entries.  Therefore do NOT
% concatenate the indices before testing them; otherwise one missing field
% can silently shorten the vector and later cause "index exceeds array".
if isempty(iNet) || isempty(iRamp) || isempty(iHead) || ...
        isempty(iAlpha) || isempty(iY)
    return;
end

idx = [iNet iRamp iHead iAlpha iY];

vals = cell(1,5);
for k=1:5
    v = ds.(fn{idx(k)});
    if ~isnumeric(v) || ~isvector(v)
        return;
    end
    vals{k} = double(v(:));
end

N = numel(vals{1});
if N<20 || any(cellfun(@numel,vals)~=N) || ~alpha_plausible_local(vals{4})
    return;
end

out.X = [vals{1} vals{2} vals{3}];
out.alpha = vals{4};
out.y = vals{5};
out.featureNames = ["netLoadNow_pu","absNetLoadRamp_pu","dgUpHeadroom_pu"];
ok = true;
why = "separate vectors";
end


function names = get_feature_names_local(ds)
names = string(["netLoadNow_pu","absNetLoadRamp_pu","dgUpHeadroom_pu"]);
if isfield(ds,'stateFeatureNames') && numel(ds.stateFeatureNames)>=3
    names = string(ds.stateFeatureNames(1:3));
elseif isfield(ds,'featureNames') && numel(ds.featureNames)>=3
    tmp = string(ds.featureNames);
    names = tmp(1:3);
end
end


function tf = alpha_plausible_local(a)
a = double(a(:));
a = a(isfinite(a));
if isempty(a)
    tf = false;
    return;
end
tf = prctile(a,1)>=-1e-6 && prctile(a,99)<=1.05 && ...
     numel(unique(round(a,6)))>=2;
end


function nn = normalize_names_local(names)
nn = lower(regexprep(string(names),'[^a-zA-Z0-9]',''));
end


function idx = best_col_local(normNames,exactCandidates,mustContain,mustNotContain)
idx = [];

for q = 1:numel(exactCandidates)
    j = find(strcmpi(normNames,exactCandidates(q)),1,'first');
    if ~isempty(j)
        idx = j;
        return;
    end
end

if isempty(mustContain)
    return;
end

for j = 1:numel(normNames)
    s = normNames(j);
    ok = true;
    for q = 1:numel(mustContain)
        ok = ok && contains(s,mustContain(q));
    end
    for q = 1:numel(mustNotContain)
        ok = ok && ~contains(s,mustNotContain(q));
    end
    if ok
        idx = j;
        return;
    end
end
end


function [xa,ya] = alpha_level_mean_local(alpha,y)
alpha = double(alpha(:));
y = double(y(:));
good = isfinite(alpha) & isfinite(y);
alpha = alpha(good);
y = y(good);

if isempty(alpha)
    xa = [];
    ya = [];
    return;
end

% Round only for grouping against floating-point storage noise.
aKey = round(alpha,6);
levels = unique(aKey);
xa = nan(numel(levels),1);
ya = nan(numel(levels),1);

for i = 1:numel(levels)
    idx = aKey==levels(i);
    xa(i) = mean(alpha(idx),'omitnan');
    ya(i) = mean(y(idx),'omitnan');
end

[xa,ord] = sort(xa);
ya = ya(ord);
end


function print_mat_inventory_local(filePath)
if strlength(filePath)==0 || exist(filePath,'file')~=2
    fprintf(2,'Dataset file is missing.\n');
    return;
end

fprintf('\n=============================================================\n');
fprintf(' AI DATASET MAT INVENTORY\n');
fprintf('=============================================================\n');
fprintf('File: %s\n',filePath);

try
    W = whos('-file',char(filePath));
    for k=1:numel(W)
        fprintf('  %-30s %-12s %s\n',W(k).name,W(k).class,mat2str(W(k).size));
    end
catch ME
    fprintf(2,'Could not inspect MAT file: %s\n',ME.message);
end

fprintf('=============================================================\n\n');
end


function lbl = feature_label_local(k,featureNames)
if nargin<2 || isempty(featureNames) || numel(featureNames)<k
    featureNames = string(["netLoadNow_pu","absNetLoadRamp_pu","dgUpHeadroom_pu"]);
end
switch char(featureNames(k))
    case 'netLoadNow_pu'
        lbl = 'netLoadNow\_pu';
    case 'absNetLoadRamp_pu'
        lbl = 'absNetLoadRamp\_pu';
    case 'dgUpHeadroom_pu'
        lbl = 'dgUpHeadroom\_pu';
    otherwise
        lbl = char(featureNames(k));
end
end


function [xb,yb] = binned_curve_local(x,y,nBins)
x = x(:); y = y(:);
good = isfinite(x) & isfinite(y);
x = x(good); y = y(good);
if isempty(x)
    xb = NaN; yb = NaN;
    return;
end
edges = linspace(min(x),max(x),nBins+1);
xb = nan(nBins,1);
yb = nan(nBins,1);
for i = 1:nBins
    if i < nBins
        idx = x>=edges(i) & x<edges(i+1);
    else
        idx = x>=edges(i) & x<=edges(i+1);
    end
    if any(idx)
        xb(i) = mean(x(idx),'omitnan');
        yb(i) = mean(y(idx),'omitnan');
    end
end
good = isfinite(xb) & isfinite(yb);
xb = xb(good);
yb = yb(good);
end


function file = find_result_local(runRoot,id,caseName,decay,seed)
methodDir = fullfile(runRoot,id);
assert(exist(methodDir,'dir')==7,'Missing method folder: %s',methodDir);
pattern = sprintf('%s_*_decay%03d_seed%03d_*.mat', ...
    caseName,round(100*decay),seed);
hits = dir(fullfile(methodDir,pattern));
assert(numel(hits)==1, ...
    'Expected one %s result at decay %.2f; found %d.', id,decay,numel(hits));
file = fullfile(hits(1).folder,hits(1).name);
end


function result = load_result_local(file)
S = load(file);
if isfield(S,'result') && isstruct(S.result)
    result = S.result;
    return;
end
names = fieldnames(S);
for k = 1:numel(names)
    x = S.(names{k});
    if isstruct(x) && (isfield(x,'summary') || isfield(x,'reserve') || isfield(x,'interval'))
        result = x;
        return;
    end
end
error('Could not identify result struct in %s',file);
end


function y = interval_stress_local(result,dfLim,rLim)
df = double(result.interval.maxAbsFreqDev_Hz(:));
rr = double(result.interval.maxAbsRoCoF_Hz_s(:));
y = max(df/dfLim,rr/rLim);
end


function v = scalar_total_cost_local(result)
v = NaN;
costFields = {'totalCost','objectiveValue','dailyCost'};
for i = 1:numel(costFields)
    f = costFields{i};
    if isfield(result,f) && isnumeric(result.(f)) && isscalar(result.(f))
        v = double(result.(f));
        return;
    end
end
if isfield(result,'summary')
        for i = 1:numel(costFields)
            f = costFields{i};
            if isfield(result.summary,f) && isnumeric(result.summary.(f)) && isscalar(result.summary.(f))
                v = double(result.summary.(f));
                return;
            end
        end
end
end


function v = summary_metric_local(result,name)
v = NaN;
if isfield(result,'summary') && isfield(result.summary,name)
    x = result.summary.(name);
    if isnumeric(x) && isscalar(x)
        v = double(x);
        return;
    end
end
if isfield(result,name)
    x = result.(name);
    if isnumeric(x) && isscalar(x)
        v = double(x);
    end
end
end


function v = scalar_field_local(s,name,defaultValue)
v = defaultValue;
if isstruct(s) && isfield(s,name)
    x = s.(name);
    if isnumeric(x) && isscalar(x)
        v = double(x);
    end
end
end


function v = logical_field_local(s,name,defaultValue)
v = logical(defaultValue);
if isstruct(s) && isfield(s,name)
    x = s.(name);
    if (islogical(x) || isnumeric(x)) && isscalar(x)
        v = logical(x);
    end
end
end


function style_all_axes_local(figHandle)
set(findall(figHandle,'Type','axes'), ...
    'FontName','Times New Roman','FontSize',12, ...
    'LineWidth',0.8);
set(findall(figHandle,'Type','text'),'FontName','Times New Roman');
end
