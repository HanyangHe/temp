function catalog = paper_method_catalog()
%PAPER_METHOD_CATALOG Final paper-facing method catalog.
%
% FINAL PROPOSED RESERVE POLICY
% -----------------------------
% P1 is the proposed method:
%
%   KRR adaptive reserve proposal
%      -> forecast-aware two-branch safety guard
%      -> final reserve ratio
%
% The frozen KRR state-feature contract remains unchanged:
%   [netLoadNow_pu, absNetLoadRamp_pu, dgUpHeadroom_pu].
%
% The forecast guard is outside the KRR model and uses decision-time
% forecast quantities already available before the current MPC solve.
%
% P1U is the reserve ablation:
%   same uncalibrated KRR proposal, but WITHOUT the forecast guard.
%
% The previous global additive one-sided calibration is NOT part of either
% final P1U or final P1.
%
% Part-II methods C0/C1/P1 use exactly the SAME guarded reserve policy and
% differ only in flexibility/curtailment allocation:
%   C0 : no special flexibility
%   C1 : BESS-only flexibility
%   P1 : hierarchical BESS/EV/load flexibility
%
% T7 remains internally unchanged and is paper-labeled F1.

catalog = baseline_catalog();

ids = string({catalog.id});
required = ["A0","T7","G1","P1U","P1"];
assert(all(ismember(required,ids)), ...
    'Legacy baseline catalog is missing one or more required paper methods.');

% Add final guard-policy fields to the complete struct array so all elements
% remain structurally compatible.
[catalog.aiForecastSafetyShield] = deal(false);
[catalog.aiForecastSafetyShieldDropThreshold_pu] = deal(NaN);
[catalog.aiForecastSafetyShieldNetLoadMin_pu] = deal(NaN);
[catalog.aiForecastSafetyShieldSevereDropEnabled] = deal(false);
[catalog.aiForecastSafetyShieldSevereDropThreshold_pu] = deal(NaN);
[catalog.aiForecastSafetyShieldAlpha] = deal(NaN);

% Frozen final normalized guard parameters.
dropThr   = 0.02;
netMin    = 0.60;
severeThr = 0.11;
shieldA   = 1.00;

% ----- P1U: unguarded KRR reserve ablation -------------------------------
i = find(ids=="P1U",1);
catalog(i).description = [ ...
    'Adaptive KRR reserve without forecast-aware safety guard + ', ...
    'hierarchical MPC-SOCP'];
catalog(i).reserveMode = 'ai';
catalog(i).reserveFixedRatio = NaN;
catalog(i).curtailmentMode = 'hierarchical';
catalog(i).aiSafetyCalibration = false;
catalog(i).aiForecastSafetyShield = false;

% ----- P1: final proposed method -----------------------------------------
i = find(ids=="P1",1);
catalog(i).description = [ ...
    'Proposed: adaptive KRR reserve + forecast-aware two-branch guard + ', ...
    'hierarchical MPC-SOCP'];
catalog(i).reserveMode = 'ai';
catalog(i).reserveFixedRatio = NaN;
catalog(i).curtailmentMode = 'hierarchical';
catalog(i).aiSafetyCalibration = false;
catalog(i).aiForecastSafetyShield = true;
catalog(i).aiForecastSafetyShieldDropThreshold_pu = dropThr;
catalog(i).aiForecastSafetyShieldNetLoadMin_pu = netMin;
catalog(i).aiForecastSafetyShieldSevereDropEnabled = true;
catalog(i).aiForecastSafetyShieldSevereDropThreshold_pu = severeThr;
catalog(i).aiForecastSafetyShieldAlpha = shieldA;

P1 = catalog(i);

% ----- C0/C1: Part-II flexibility ablations ------------------------------
C0 = P1;
C0.id = 'C0';
C0.description = [ ...
    'Curtailment ablation: proposed guarded adaptive reserve + MPC-SOCP + ', ...
    'no special flexibility'];
C0.legacyCase = 9;
C0.curtailmentMode = 'none';

C1 = P1;
C1.id = 'C1';
C1.description = [ ...
    'Curtailment ablation: proposed guarded adaptive reserve + MPC-SOCP + ', ...
    'BESS-only flexibility'];
C1.legacyCase = 9;
C1.curtailmentMode = 'bess';

ids = string({catalog.id});
if any(ids=="C0")
    catalog(ids=="C0") = C0;
else
    catalog(end+1) = C0;
end

ids = string({catalog.id});
if any(ids=="C1")
    catalog(ids=="C1") = C1;
else
    catalog(end+1) = C1;
end
end
