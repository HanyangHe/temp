function plan = paper_study_catalog()
%PAPER_STUDY_CATALOG Final TICPS two-part paper experiment organization.
%
% PART I -- Adaptive reserve ablation, NORMAL CASE ONLY
%   Internal IDs : A0, T7, G1, P1U, P1
%   Paper labels : A0, F1, G1, P1U, P1
%   decayRatio   : 1.00 only
%
%   P1U : uncalibrated adaptive KRR reserve WITHOUT forecast guard
%   P1  : uncalibrated adaptive KRR reserve WITH final two-branch guard
%
% PART II -- Curtailment Allocation and Operating Cost
%   Methods      : C0, C1, P1
%   decayRatio   : 0.20, 0.40, 0.60, 0.80, 1.00
%
% C0/C1/P1 use the same final guarded adaptive reserve policy. Only the
% flexibility/curtailment allocation differs.
%
% P1@decay=1.00 is shared by Part I and Part II.

plan = struct();
plan.version = 'ticps-two-stage-v4-final-P1-forecast-guard';

plan.proposedReservePolicy = struct();
plan.proposedReservePolicy.methodID = 'P1';
plan.proposedReservePolicy.krrSafetyCalibration = false;
plan.proposedReservePolicy.forecastGuardEnabled = true;
plan.proposedReservePolicy.moderateDropThreshold_pu = 0.02;
plan.proposedReservePolicy.netLoadMin_pu = 0.60;
plan.proposedReservePolicy.severeDropThreshold_pu = 0.11;
plan.proposedReservePolicy.shieldAlpha = 1.00;
plan.proposedReservePolicy.note = [ ...
    'Normalized guard parameters are frozen for subsequent seed/grid ', ...
    'validation and are not retuned case by case.'];

plan.aiReserveAblation = struct();
plan.aiReserveAblation.label = ...
    'Adaptive reserve ablation under the normal-generation case';
plan.aiReserveAblation.methods = {'A0','T7','G1','P1U','P1'};
plan.aiReserveAblation.paperLabels = {'A0','F1','G1','P1U','P1'};
plan.aiReserveAblation.decayRatios = 1.00;
plan.aiReserveAblation.purpose = [ ...
    'A0: no explicit reserve; F1/T7: full fixed alpha=1 reserve; ', ...
    'G1: one global fixed alpha; P1U: adaptive KRR reserve without the ', ...
    'forecast-aware guard; P1: proposed adaptive KRR reserve with the ', ...
    'two-branch forecast-aware guard. Part I is evaluated only at ', ...
    'decayRatio=1.00.'];

plan.curtailmentAllocationCost = struct();
plan.curtailmentAllocationCost.label = ...
    'Curtailment Allocation and Operating Cost';
plan.curtailmentAllocationCost.methods = {'C0','C1','P1'};
plan.curtailmentAllocationCost.paperLabels = {'C0','C1','P1'};
plan.curtailmentAllocationCost.decayRatios = [0.20 0.40 0.60 0.80 1.00];
plan.curtailmentAllocationCost.purpose = [ ...
    'Hold the proposed guarded adaptive reserve policy and MPC-SOCP fixed ', ...
    'while varying only the flexibility/curtailment allocation: no special ', ...
    'flexibility, BESS-only flexibility, and hierarchical BESS/EV/load ', ...
    'allocation.'];

% Compatibility alias for older runner/replay code.
plan.severeGenerationShortage = plan.curtailmentAllocationCost;

plan.sharedMethods = {'P1'};
plan.sharedDecayRatios = 1.00;

% Full fresh-paper formal run order. The runner must obey study-specific
% decay scheduling rather than taking a Cartesian product.
plan.formalRunOrder = {'A0','T7','G1','P1U','P1','C0','C1'};
plan.allPaperMethods = plan.formalRunOrder;
plan.useStudySpecificDecayScheduling = true;

plan.paperLabelMap = struct( ...
    'A0','A0','T7','F1','G1','G1','P1U','P1U', ...
    'P1','P1','C0','C0','C1','C1');

% 18-bus transition to the final P1:
% unaffected Part-I baselines can be reused; all Part-II rows and P1U@1
% should be regenerated under the frozen final code.
plan.rerun18bus = struct();
plan.rerun18bus.reusePartI = {'A0','T7','G1'};
plan.rerun18bus.recommendedPartI = {'P1U'};
plan.rerun18bus.requiredPartI = {'P1'};
plan.rerun18bus.requiredPartII = {'C0','C1','P1'};
plan.rerun18bus.partIDecayRatios = 1.00;
plan.rerun18bus.partIIDecayRatios = [0.20 0.40 0.60 0.80 1.00];
plan.rerun18bus.expectedRerunCount = 16; % P1U@1 + 15 Part-II rows
plan.rerun18bus.expectedFinalUniquePairCount = 19;
end
