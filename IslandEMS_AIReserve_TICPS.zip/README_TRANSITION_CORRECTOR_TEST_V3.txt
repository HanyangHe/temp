TRANSITION CORRECTOR TEST V3
============================

Why V2 stopped
--------------
The physical patch preflight was correct, but the current
paper_method_catalog() does not expose the full-reserve benchmark under the
literal ID "F1". In this project the manuscript name F1 may still map to the
legacy/internal catalog ID "T7".

V3 fixes this without changing the experiment:
- resolves F1 first, then T7;
- prints all catalog IDs and the selected method's reserve/alpha-related
  fields during preflight;
- resolves the method BEFORE any temporary engine modification;
- uses silent path cleanup (no rmpath warning flood);
- keeps the same fixed 4.5-s DG smoothstep corrector;
- still performs no BESS compensation;
- still changes no model/training/alpha logic.

Before V3
---------
V2 used onCleanup, so its failed run should already have restored the engine.
For an extra safety check you may run the V2 restore utility once; it is
safe when no V2 marker remains.

V3 preflight
------------
clear functions
rehash
addpath(genpath(pwd))
Rpre = test_F1_33bus_DG_transition_corrector_v3(pwd,false);

Only continue if:
- handoff count = 2
- resolved internal ID is F1 or T7
- PRE-FLIGHT STATUS: PASS
- Simulation launched: NO
- Source modified: NO

Run one case
------------
Rtc = test_F1_33bus_DG_transition_corrector_v3(pwd,true);

Emergency restore
-----------------
Only if MATLAB/Windows is force-killed while V3 is patched:

Rrestore = restore_transition_corrector_test_engine_v3(pwd);
