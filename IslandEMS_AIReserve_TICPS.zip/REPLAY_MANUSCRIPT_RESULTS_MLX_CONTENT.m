%% MANUSCRIPT RESULT REPLAY DASHBOARD
% Central Live Script for 10-bus / 18-bus / 33-bus saved-result replay.
%
% NO optimization or physical simulation is launched.
%
% IMPORTANT:
% All figure-display/export switches are controlled HERE.
%
% Grid-specific replay engines:
%   replay_10bus_manuscript_results.m
%   replay_18bus_manuscript_results.m
%   replay_33bus_manuscript_results.m
%
% Detailed physical-profile helper:
%   replay_saved_operating_profiles.m

clear;
clc;

projectRoot = pwd;
addpath(genpath(projectRoot));

%% ============================================================
% USER OPTIONS
% =============================================================

% Select one or more grids.
replayCases = "18bus";
% replayCases = ["10bus","18bus","33bus"];

% Explicit reproducible formal-run tags.
runTags = struct();
runTags.bus10 = '';
runTags.bus18 = '20260907_115951';
runTags.bus33 = '';

% ---------------- Figure options ----------------
plotOpt = struct();

% Master switches
plotOpt.showFigures = true;          % display MATLAB/Live Editor figures
plotOpt.exportFigures = true;        % save PNG files
plotOpt.closeExistingFigures = true; % close old windows before replay

% Summary/manuscript-comparison figures
plotOpt.generateSummaryFigures = true;

% Detailed physical operating profiles
plotOpt.generateDetailedProfiles = true;

% Which saved operating conditions should display full profiles?
% Recommended manuscript inspection:
plotOpt.profileDecays = [0.20 1.00];

% To inspect/export ALL saved conditions:
% plotOpt.profileDecays = [0.20 0.40 0.60 0.80 1.00];

% Internal IDs. T7 is displayed as F1.
plotOpt.profileMethods = ["A0","T7","G1","P1U","P1","C0","C1"];

% If you want PNG export without opening dozens of figures:
% plotOpt.showFigures = false;
% plotOpt.exportFigures = true;

if plotOpt.closeExistingFigures
    close all force;
end

fprintf('Project root : %s\n',projectRoot);
fprintf('Replay cases : %s\n',strjoin(replayCases,', '));
fprintf('Show figures : %d\n',plotOpt.showFigures);
fprintf('Export figs  : %d\n\n',plotOpt.exportFigures);


%% ============================================================
% REPLAY SAVED SUMMARY RESULTS
% =============================================================

reports = struct();

for caseName = replayCases

    runTag = get_run_tag_local(caseName,runTags);

    fprintf('\n=============================================================\n');
    fprintf(' REPLAY %s -- SAVED RESULTS ONLY\n',upper(caseName));
    fprintf(' runTag: %s\n',runTag);
    fprintf('=============================================================\n');

    switch string(caseName)

        case "10bus"
            assert(exist('replay_10bus_manuscript_results','file')==2, ...
                'replay_10bus_manuscript_results.m is not available.');
            reports.bus10 = replay_10bus_manuscript_results( ...
                runTag,projectRoot, ...
                'ShowFigures',plotOpt.showFigures, ...
                'ExportFigures',plotOpt.exportFigures, ...
                'GenerateSummaryFigures',plotOpt.generateSummaryFigures);

        case "18bus"
            assert(exist('replay_18bus_manuscript_results','file')==2, ...
                'replay_18bus_manuscript_results.m is missing.');
            reports.bus18 = replay_18bus_manuscript_results( ...
                runTag,projectRoot, ...
                'ShowFigures',plotOpt.showFigures, ...
                'ExportFigures',plotOpt.exportFigures, ...
                'GenerateSummaryFigures',plotOpt.generateSummaryFigures);

        case "33bus"
            assert(exist('replay_33bus_manuscript_results','file')==2, ...
                'replay_33bus_manuscript_results.m is not available.');
            reports.bus33 = replay_33bus_manuscript_results( ...
                runTag,projectRoot, ...
                'ShowFigures',plotOpt.showFigures, ...
                'ExportFigures',plotOpt.exportFigures, ...
                'GenerateSummaryFigures',plotOpt.generateSummaryFigures);

        otherwise
            error('Unsupported case: %s',caseName);
    end
end


%% ============================================================
% REPLAY STATUS
% =============================================================

for caseName = replayCases
    report = get_report_local(reports,caseName);

    if isempty(report.missing)
        fprintf('%-5s : COMPLETE\n',caseName);
    else
        fprintf('%-5s : WARNING -- missing results\n',caseName);
        disp(report.missing);
    end
end


%% ============================================================
% PART I -- ADAPTIVE RESERVE ABLATION TABLES
% =============================================================
% Paper labels:
%   A0, F1(T7), G1, P1U, P1

for caseName = replayCases
    report = get_report_local(reports,caseName);

    fprintf('\nPART I -- %s\n',upper(caseName));
    disp(report.part1Table);

    fprintf('\nP1 vs F1 -- %s\n',upper(caseName));
    disp(report.part1Comparison);
end


%% ============================================================
% PART II -- CURTAILMENT ALLOCATION AND OPERATING COST TABLES
% =============================================================
% C0, C1, P1 use the same calibrated adaptive reserve.
% Their intended difference is flexibility allocation.

for caseName = replayCases
    report = get_report_local(reports,caseName);

    fprintf('\nPART II -- %s\n',upper(caseName));
    disp(report.part2Table);

    fprintf('\nC0 / C1 / P1 comparison -- %s\n',upper(caseName));
    disp(report.part2Comparison);
end


%% ============================================================
% KEY MANUSCRIPT FINDINGS
% =============================================================

for caseName = replayCases
    report = get_report_local(reports,caseName);

    fprintf('\nKey findings -- %s\n',upper(caseName));
    disp(report.keyFindings);
end


%% ============================================================
% FULL PHYSICAL OPERATING-PROFILE FIGURES
% =============================================================
%
% For every selected grid/method/decay this can display/export:
%
%   01 aggregate power profiles
%      demand / DG / PV / battery
%
%   02 individual resource powers
%      all DG power + all storage/EV power
%
%   03 SoC trajectories
%      all saved SoC curves + limits
%
%   04 frequency security
%      CoI frequency + individual frequencies + CoI RoCoF
%
%   05 network security
%      min/max bus voltage + current loading
%
%   06 flexibility / curtailment
%      baseline load + executed load + reduction/shedding profile
%
%   07 reserve policy
%      alpha trajectory + reserve power when saved
%
%   08 operating cost
%      instantaneous + cumulative cost
%
% NO simulation is launched.

if plotOpt.generateDetailedProfiles

    assert(exist('replay_saved_operating_profiles','file')==2, ...
        'replay_saved_operating_profiles.m is missing.');

    for caseName = replayCases

        report = get_report_local(reports,caseName);

        for decay = plotOpt.profileDecays

            for methodID = plotOpt.profileMethods

                paperLabel = methodID;
                if methodID=="T7"
                    paperLabel = "F1";
                end

                fprintf('\n-------------------------------------------------------------\n');
                fprintf(' Detailed profile: %s | %s | decay %.2f\n', ...
                    upper(caseName),paperLabel,decay);
                fprintf('-------------------------------------------------------------\n');

                replay_saved_operating_profiles( ...
                    report.runRoot, ...
                    caseName, ...
                    methodID, ...
                    decay, ...
                    'PaperLabel',paperLabel, ...
                    'Visible',plotOpt.showFigures, ...
                    'Export',plotOpt.exportFigures);

                drawnow;
            end
        end
    end
end


%% ============================================================
% CROSS-GRID PART I SUMMARY
% =============================================================

combinedPart1 = table();

for caseName = replayCases
    report = get_report_local(reports,caseName);
    T = report.part1Table;
    T.CaseName = repmat(string(caseName),height(T),1);
    combinedPart1 = append_table_local(combinedPart1,T);
end

if ~isempty(combinedPart1)
    fprintf('\nCross-grid Part-I summary\n');

    wanted = ["CaseName","PaperLabel","DecayRatio","TotalCost", ...
        "MeanReserveRatio","MaxAbsFreqDev_Hz","MaxAbsRoCoF_Hz_s", ...
        "SecurityViolationRate"];

    wanted = wanted(ismember(wanted,string(combinedPart1.Properties.VariableNames)));
    disp(combinedPart1(:,cellstr(wanted)));
end


%% ============================================================
% CROSS-GRID PART II SUMMARY
% =============================================================

combinedPart2 = table();

for caseName = replayCases
    report = get_report_local(reports,caseName);
    T = report.part2Table;
    T.CaseName = repmat(string(caseName),height(T),1);
    combinedPart2 = append_table_local(combinedPart2,T);
end

if ~isempty(combinedPart2)
    fprintf('\nCross-grid Part-II summary\n');

    wanted = ["CaseName","PaperLabel","DecayRatio","TotalCost", ...
        "LoadShedEnergy_kWh","EVUnmetEnergy_kWh", ...
        "EVCommutingViolation_kWh","BESSTerminalDeficit_kWh", ...
        "SecurityViolationRate"];

    wanted = wanted(ismember(wanted,string(combinedPart2.Properties.VariableNames)));
    disp(combinedPart2(:,cellstr(wanted)));
end


%% ============================================================
% OUTPUT LOCATIONS
% =============================================================

fprintf('\nManuscript replay output folders:\n');

for caseName = replayCases
    report = get_report_local(reports,caseName);
    fprintf('  %-5s : %s\n',caseName,report.outputDir);
end


%% ============================================================
% LOCAL FUNCTIONS
% =============================================================

function runTag = get_run_tag_local(caseName,runTags)
switch string(caseName)
    case "10bus"
        runTag = string(runTags.bus10);
    case "18bus"
        runTag = string(runTags.bus18);
    case "33bus"
        runTag = string(runTags.bus33);
    otherwise
        error('Unsupported case: %s',caseName);
end

assert(strlength(runTag)>0, ...
    'No formal runTag has been assigned for %s.',caseName);
end


function report = get_report_local(reports,caseName)
switch string(caseName)
    case "10bus"
        assert(isfield(reports,'bus10'),'10-bus report has not been replayed.');
        report = reports.bus10;
    case "18bus"
        assert(isfield(reports,'bus18'),'18-bus report has not been replayed.');
        report = reports.bus18;
    case "33bus"
        assert(isfield(reports,'bus33'),'33-bus report has not been replayed.');
        report = reports.bus33;
    otherwise
        error('Unsupported case: %s',caseName);
end
end


function Tout = append_table_local(Tout,Tnew)
if isempty(Tout)
    Tout = Tnew;
    return;
end

commonVars = intersect( ...
    Tout.Properties.VariableNames, ...
    Tnew.Properties.VariableNames, ...
    'stable');

Tout = Tout(:,commonVars);
Tnew = Tnew(:,commonVars);

Tout = [Tout; Tnew];
end
