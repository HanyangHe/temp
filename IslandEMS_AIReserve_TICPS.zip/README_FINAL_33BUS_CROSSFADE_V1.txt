FINAL 33-BUS OFFICIAL PAPER CROSSFADE PATCH V1
===============================================

Frozen strategy
---------------
MPC optimization interval remains 15 min.

The official common command-realization layer applies a symmetric linear
5-min TOTAL crossfade around each MPC boundary:

  2.5 min before boundary
  2.5 min after boundary

Outside the boundary transition, the original stage command is held.

Applied active-power channels
-----------------------------
- DG
- stationary GFM BESS
- stationary GFL BESS
- EV BESS

Not changed
-----------
- Q commands
- MPC optimization model/horizon/number of solves
- KRR model/training/features
- reserve alpha selection
- forecast guard logic
- predictive input averaging
- true 1-s load/PV
- nonlinear physical models

Run order
---------
1) Dry run patch:
   clear functions
   rehash
   addpath(genpath(pwd))
   Rpatch = apply_final_33bus_boundary_crossfade_patch_v1(pwd,false);

2) Apply:
   Rpatch = apply_final_33bus_boundary_crossfade_patch_v1(pwd,true);

3) Final production preflight:
   clear functions
   rehash
   addpath(genpath(pwd))
   Rpre = preflight_final_33bus_boundary_crossfade_v1(pwd);

4) Formal suite preflight:
   Rrun = run_final_33bus_paper_suite_crossfade_v1(pwd,false);

5) Start/resume official 19-case suite:
   R33 = run_final_33bus_paper_suite_crossfade_v1(pwd,true);

Formal output
-------------
outputs/YYYYMMDD_finalP1_33bus/

  README.md
  formal_contract.mat
  formal_case_manifest.csv
  formal_33bus_summary.csv
  formal_33bus_partI_normal.csv
  formal_33bus_partII_hierarchical.csv
  formal_33bus_run_state.mat
  formal_33bus_complete.mat

  A0/
  F1/
  G1/
  P1U/
  P1/
  C0/
  C1/

Each completed case is written immediately. The runner resumes only
compatible completed cases.

Expected runtime
----------------
About 19 x ~50 min, roughly 15-17 hours depending on solver variation.
