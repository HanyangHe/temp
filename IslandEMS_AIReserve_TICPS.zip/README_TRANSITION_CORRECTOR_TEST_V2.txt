TRANSITION CORRECTOR TEST V2
============================

What changed from V1
--------------------
The source inspection showed the actual receding-horizon DG active-power
handoff is:

  Ref(idx_ref+1,RealStep)=P_DG_opt_Dec(execIdx,1,ii);idx_ref=idx_ref+1;

and this exact execIdx handoff occurs twice in engine_island_ems.m:
one receding branch with Q=0 and one receding PQ/SOCP branch.

V2 therefore patches BOTH actual receding-horizon handoffs temporarily.

Corrector
---------
Tc = 3*Tg = 4.5 s
beta = 3*x^2 - 2*x^3
Pref_exec = Pref_previous + beta*(Pref_target-Pref_previous)

The correction lasts only at the start of each 15-min interval. After 4.5 s
the original target is applied exactly.

This first test remains intentionally minimal:
- DG Pref smoothing only
- no BESS compensation
- no KRR/model/training changes
- no alpha changes
- no load/PV changes
- no permanent production change

Files
-----
tests/
  test_F1_33bus_DG_transition_corrector_v2.m
tools/
  restore_transition_corrector_test_engine_v2.m

Run
---
1) Preflight only:
   clear functions
   rehash
   addpath(genpath(pwd))
   Rpre = test_F1_33bus_DG_transition_corrector_v2(pwd,false);

2) Only if PRE-FLIGHT STATUS: PASS:
   Rtc = test_F1_33bus_DG_transition_corrector_v2(pwd,true);

Output
------
outputs/cache/transition_corrector_test_v2/33bus_F1_decay100_seed000/

Emergency restore
-----------------
Only if MATLAB is force-killed while the temporary patch is active:

   Rrestore = restore_transition_corrector_test_engine_v2(pwd);

Do NOT tune Tc based on the result. If fixed Tc=4.5 s does not sufficiently
help, the next test should retain the same Tc and add a common BESS
compensation layer rather than sweeping the transition time.
