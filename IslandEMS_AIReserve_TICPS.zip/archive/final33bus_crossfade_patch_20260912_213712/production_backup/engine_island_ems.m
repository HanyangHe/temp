% ENGINE_ISLAND_EMS_NOREFINE  Internal simulation/optimization engine.
% This script is executed inside run_single_experiment.m.  It intentionally
% contains no post-optimization sub-interval command refinement.  All EMS
% commands are applied with zero-order hold at the configured decision rate.
%
% Required workspace variables: cfg, runCfg, projectRoot, aiModel.

fontsize = cfg.output.fontSize;
frontsize = cfg.output.fontSize;
ExportFigForPaper = cfg.output.exportFigures;
rng(runCfg.randomSeed,'twister');
activateCase = runCfg.legacyCase;
samplePerHour = cfg.simulation.samplePerHour;
DecisionLevelSteps = cfg.mpc.decisionLevelSteps;
dayPoints = 24;                     % native hourly forecasting data points/day
DayHours = 24;
dt = 1/samplePerHour;               % h; 1-s physical simulation by default

% IMPORTANT TIME-BASE SEPARATION
% dt_pre is retained as the NATIVE hourly load/PV forecasting (and legacy
% day-ahead scheduling) step. The receding-horizon MPC uses dt_mpc=dt_deci.
% Thus the 24-h KRR predictors are not retrained merely because the EMS is
% updated every 15 min.
dt_pre = cfg.forecast.nativeStep_h;  % h; native forecasting/legacy DA grid (1 h)
dt_mpc = cfg.mpc.predictionStep_h;   % h; MPC optimization grid (0.25 h default)
dt_deci = cfg.mpc.decisionInterval_h;% h; receding-horizon update interval
dt_exec = dt_deci;                   % zero-order-hold execution; no hidden refinement
if abs(dt_mpc-dt_deci)>1e-12
    error('MPC prediction step and decision interval must be equal in this study.');
end
predictionHorizonMPC = cfg.mpc.predictionHorizon;
forecastHorizon = round(cfg.mpc.horizon_h/dt_pre); % 24 hourly forecast transitions
forecastStride = round(dt_pre/dt_deci);            % 4 decision steps per hourly forecast step

t_pre = 0:dt_pre:DayHours-dt_pre;    % 0:1:23, hourly forecast/legacy DA anchors
t_mpc = 0:dt_mpc:cfg.mpc.horizon_h-dt_mpc; % 0:0.25:23.75, 96 MPC stages
t_deci = 0:dt_deci:DayHours-dt_deci;
t_exec = t_deci;
t_sim = 0:dt:DayHours-dt;
samplesPerDecision=round(dt_deci/dt);
if abs(samplesPerDecision*dt-dt_deci)>1e-12
    error('MPC decision interval must be an integer multiple of the physical simulation step.');
end
Integrator = cfg.simulation.integrator;
w_pre = cfg.forecast.upstreamTrustWeight;
CaseName = runCfg.caseName;
dayType = char(runCfg.dayType);
decayRatio = runCfg.decayRatio;
k_LdShd = cfg.flexibility.maxLoadShedFraction;
rocof_limit_Hz_s = cfg.frequency.reserveRoCoF_Hz_s;
df_reserve_Hz = cfg.frequency.reserveDeviation_Hz;
EVnumberPerResi = cfg.ev.numberPerResidentialBus;

dataFile = @(name) fullfile(projectRoot,'data',name);

% Per-run result holders
TotalLoadBox={}; TotalGFMBox={}; TotalBattBox={}; TotalPVBox={};
SoC_BOX={}; Iline_magBox={}; Vs_magBox={}; freqBox={}; EcoCostBox={};
DeciTimeCostBox={}; P_DG_opt_DecBox={}; P_DGBox={};
freq=[]; S_PV_busBox=[]; Sload_busBox=[]; Xbasic=[]; VsBoxBasic=[];
Pload_BoxBasic=[]; Qload_BoxBasic=[]; P_DG=[]; P_res=[]; Pbatt=[];
Pbatt_dis=[]; Pbatt_ch=[]; V_from=[]; V_to=[]; I_line=[]; Ploss=[];
P_DG_GFM=[]; P_Batt_GFM=[]; P_br=[]; Q_br=[]; l_br=[]; v_bus=[];
relaxationGapBox=[]; relaxationGap=[]; relaxationRelGapBox=[];
relaxationRelGap=[]; AngleErrorBox=[]; MagErrorBox=[];
solverExitflagHistory=[]; pfExitflagHistory=[];
solverDiagnosticHistory=cell(1,DecisionLevelSteps);
decisionBlockTimeHistory=nan(1,DecisionLevelSteps);
forecastBuildTimeHistory=nan(1,DecisionLevelSteps);
dynamicAssemblyTimeHistory=nan(1,DecisionLevelSteps);
postprocessTimeHistory=nan(1,DecisionLevelSteps);
manualResidualWarningCount=0;
% Keep the numerical algorithm/tolerances unchanged; only suppress the
% repetitive termination text.  A different LinearSolver can be selected
% explicitly later for a controlled diagnostic comparison.
coneOptions=optimoptions('coneprog','Display',cfg.solver.coneprogDisplay);
if isfield(cfg.solver,'coneprogLinearSolver') && ...
        ~strcmpi(cfg.solver.coneprogLinearSolver,'default')
    coneOptions.LinearSolver=cfg.solver.coneprogLinearSolver;
end
% Optional conditioning retry.  The primary solve uses sparse matrices with
% LinearSolver='auto' (MATLAB then selects a sparse-oriented solver).  Only
% materially poor exitflag=-7 cases are retried with the configured
% alternative linear solver; physical/model tolerances are unchanged.
coneOptionsRetry=[];
if isfield(cfg.solver,'enableConditioningRetry') && cfg.solver.enableConditioningRetry
    coneOptionsRetry=optimoptions('coneprog','Display','none', ...
        'LinearSolver',cfg.solver.retryLinearSolver);
end

PF=0.9;
PF_DieselG=0.85;

BusOfSlack=1;

S_base=cfg.base.S_VA; % VA
V_base=cfg.base.V_V; % V
I_base=S_base/(V_base*sqrt(3));%A
Z_base=V_base^2/S_base;%ohm

f_rate=cfg.frequency.nominal_Hz;
w_rate=2*pi*f_rate;

Vmin=cfg.network.Vmin_pu;
Vmax=cfg.network.Vmax_pu;


% Test-system parameters are centralized in config/system_case_catalog.m.
sys=system_case_catalog(CaseName,cfg);
Topology=sys.Topology;
BusNum=sys.BusNum;
k_brch=sys.k_branch;
BusOfDieselG_GFM=sys.BusOfDieselG_GFM;
BusOfBatteryGFM=sys.BusOfBatteryGFM;
MainGFM=sys.MainGFM;
BusOfBattery=sys.BusOfBattery;
BusOfPV=sys.BusOfPV;
residential_node=sys.residential_node;
business_node=sys.business_node;
BusOfEVBattery=sys.BusOfEVBattery;
DieselG_Pgfm_rate=sys.DieselG_Pgfm_rate;
BatteryGFL_P_rate=sys.BatteryGFL_P_rate;
BatteryGFM_Pgfm_rate=sys.BatteryGFM_P_rate;
PVInv_P_rateIn=sys.PVInv_P_rateIn;
residentialPower=sys.residentialPower;
businessPower=sys.businessPower;
BatteryEV_P_rate=sys.BatteryEV_P_rate;
brhID=sys.brhID;
busID=sys.busID;

% Shared converter interface inductances.
Xm_g=[sys.Xm_g_battGFM*ones(numel(BusOfBatteryGFM),1); ...
      sys.Xm_g_batt*ones(numel(BusOfBattery),1); ...
      sys.Xm_g_EVbatt*ones(numel(BusOfEVBattery),1); ...
      sys.Xm_g_solar*ones(numel(BusOfPV),1)];

% No inverter GFM-BESS is active in the current benchmark grids.
K_Pdp=[];
K_Qdp=[];

% DG active-power/frequency droop is defined on each local DG P-rated base.
Rdroop=cfg.frequency.droop_pu*ones(1,numel(DieselG_Pgfm_rate));
deltaVmax=0.01;
deltaQmax=DieselG_Pgfm_rate;
kQ_DG=deltaVmax./deltaQmax;

ResiUserNum=length(residential_node);
BusiUserNum=length(business_node);
DG_GFM_num=length(BusOfDieselG_GFM);
BatteryGFM_Num=length(BusOfBatteryGFM);
BatteryNum=length(BusOfBattery);
SolarNum=length(BusOfPV);
EVBatteryNum=length(BusOfEVBattery);

[Bus_Prate,idx_P_DG_GFM,idx_PbattGFM,idx_Pbatt,idx_P_PV,idx_Pbusi,idx_Presi,idx_P_EV] = busdata(residential_node,business_node,BusOfPV,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusNum,PF,residentialPower,businessPower,PVInv_P_rateIn,DieselG_Pgfm_rate,BatteryGFM_Pgfm_rate,BatteryGFL_P_rate,BatteryEV_P_rate);

Load_P_rate=zeros(BusNum,1);
Load_Q_rate=zeros(BusNum,1);
PVInv_P_rate=zeros(BusNum,1);
BatteryGFM_P_rate=zeros(BusNum,1);
BatteryGFL_P_rate=zeros(BusNum,1);
BatteryEV_P_rate=zeros(BusNum,1);
DieselG_Pgfm_rateVec=zeros(BusNum,1);

Load_P_rate=Bus_Prate(:,idx_Pbusi)+Bus_Prate(:,idx_Presi);%MW; note: if one node contains different loads, we cannot combine them together.
Load_Q_rate=Bus_Prate(:,idx_Pbusi+1)+Bus_Prate(:,idx_Presi+1);%MW;
PVInv_P_rate(BusOfPV,1)=Bus_Prate(BusOfPV,idx_P_PV);%MW; rated power of PV inverter
BatteryGFM_P_rate(BusOfBatteryGFM,1)=Bus_Prate(BusOfBatteryGFM,idx_PbattGFM);%MW; 
BatteryGFL_P_rate(BusOfBattery,1)=Bus_Prate(BusOfBattery,idx_Pbatt);%MW; rated power of Battery inverter
BatteryEV_P_rate(BusOfEVBattery,1)=Bus_Prate(BusOfEVBattery,idx_P_EV);%MW; 
DieselG_Pgfm_rateVec(BusOfDieselG_GFM,1)=Bus_Prate(BusOfDieselG_GFM,idx_P_DG_GFM);%MW; 

[Line, LineLimits, LineBFM, LineLimitsBFM]= linedata(Topology,Z_base,I_base);
Impedance = Line(:,3) + 1j.*Line(:,4);
Admittance = 1./Impedance;

% Admittance Matrix
Y_Bus = admittance_matrix(BusNum,length(Line(:,1)),Admittance,Line);
% Keep the original matrix for optimization/initialization compatibility,
% but prepare one sparse copy for the 1-s physical kernel so sparse(Y_Bus)
% is not rebuilt 86,400 times per simulated day.
Y_Bus_dyn = sparse(Y_Bus);
G = real(Y_Bus);
B = imag(Y_Bus);

% Loop search
[loopNodes, loopBranches] = findFundamentalLoopsFromBranches(LineBFM);
Loops=size(loopNodes,2);
if Loops==0
    loopBrhNum=[];
else
    for ii=1:Loops
        loopBrhNum(1,ii)=length(loopBranches{ii});
    end
end
NumOfCrossTerm=sum(loopBrhNum.*(loopBrhNum-1)/2);

P_gfmIBRmax=1;%pu

Zmv_g=ones(length(Xm_g),1)*(0.05+1j*0.0);%pu virtual impedance of inverter controller

V_DC=2;

PFmin_inv=0.9;%minimum power factor for inverter at the maximum active power
Q_BattInvMax=BatteryGFL_P_rate*sqrt(1/PFmin_inv^2-1);

P_DGmax=cfg.frequency.dgPmax_pu;% pu on each DG active-power rating
P_DGmin=cfg.frequency.dgPmin_pu;% pu on each DG active-power rating

phys.omega_b=w_rate;
% pu value of with the local DG base:
phys.H   = cfg.frequency.H_s;% Inertia constant, s, 1–5 for dissel generator (s)-level
phys.D   = cfg.frequency.D_pu;% Damping, pu, 
phys.PminPu = cfg.frequency.dgPmin_pu;
phys.PmaxPu = cfg.frequency.dgPmax_pu;
phys.Xd  = 2;% d-axis synchronous reactance, pu, 1.2-2 (sensitive parameter)
% phys.Tdo = 1;% Open circuit d-axis transient time constant, s, 0.3-0.8 (affect the ripple in the output, need to be large) (s)-level


%Excitation (AVR) (highly sensitive parameter)
% KA = 40/2;  %50-200; 40
% TA = 0.08/ samplePerHour;%0.02-0.1 (s)-level

%Governor + Turbine (primary frequency regulator)
% Tg_sim = 0.3/ samplePerHour;  % s  (typical 0.2~0.5 for DG governor/actuator)
% Tt_sim = 2.7/ samplePerHour;  % s  (turbine/engine power response channel)
Tm = cfg.frequency.governorTime_s;% s  (use this in your 1st-order Pm model)
KIsec=cfg.frequency.secondaryIntegralGain;% 0.3~1.0 tuned for 10~30s recovery


Xd_prime = cfg.frequency.dgXdPrime_pu; % d-axis transient reactance, pu on cfg.frequency.dgImpedanceBase
Ra       = cfg.frequency.dgRa_pu;      % stator resistance, pu on cfg.frequency.dgImpedanceBase
Zs_DG=(Ra+1j*Xd_prime)*ones(1,DG_GFM_num);

% ----- Consistent DG bases -------------------------------------------------
% H, D, and Rdroop are defined on each DG's local ACTIVE-POWER rating.
% The dynamic model explicitly normalizes (Pm-Pe) by Prate and multiplies
% the droop gain by Prate, so these parameters must NOT be silently moved to
% the 1-MVA network base.
%
% The legacy code did not document whether Ra/Xd_prime were specified on a
% machine or system MVA base. Do not silently change their numerical value.
% The convention is now explicit and selectable in config_island_ems.m.
Zs_DG_native = (Ra+1j*Xd_prime)*ones(1,DG_GFM_num);
switch lower(cfg.frequency.dgImpedanceBase)
    case 'system'
        Zs_DG = Zs_DG_native;
    case 'machine'
        S_sys_MVA = S_base/1e6;
        S_machine_MVA = DieselG_Pgfm_rate(:)./PF_DieselG;
        kX_vec = S_sys_MVA ./ S_machine_MVA;
        Zs_DG = Zs_DG_native .* reshape(kX_vec,1,[]);
    otherwise
        error('Unknown cfg.frequency.dgImpedanceBase: %s', ...
            cfg.frequency.dgImpedanceBase);
end

DGcontrolParams(1)=Tm;
DGcontrolParams(2)=KIsec;

C_dieselG=cfg.cost.diesel_per_kWh;%$/kWh
% K_DG_plty=1.1;% K_DG_plty*C_dieselG larger than EV and BESS cost but smaller than EV energy shedding cost


C_LdShd=cfg.cost.loadShed_per_kWh;%$/kWh load shedding price
C_PVCurt=cfg.cost.pvCurtailment_per_kWh;%$/kWh optional renewable-curtailment penalty
% Economic convention: DG generation cost is charged once at the source.
% Network and battery-conversion losses increase required DG energy through
% the physical/SoC balances and are therefore NOT charged a second time.

% K_BESSrwd=0.5;% decay rate for the BESS power cost to encourage using BESS for power balance first to avoid using DG, which may cause frequency fluctuation

C_buy_residential=ones(size(t_sim))*C_dieselG;

C_buy_business=ones(size(t_sim))*C_dieselG;

C_sell=ones(size(t_sim))*0;

% system level price vector for decision
C_buy_residential_declevel=C_buy_residential(1:dt_pre/dt:end);
C_buy_residential_declevel0=C_buy_residential_declevel(1,1:24);
C_buy_residential_declevel=[C_buy_residential_declevel0 C_buy_residential_declevel0];
C_buy_business_declevel=C_buy_business(1:dt_pre/dt:end);
C_buy_business_declevel0=C_buy_business_declevel(1,1:24);
C_buy_business_declevel=[C_buy_business_declevel0 C_buy_business_declevel0];
C_sell_declevel=C_sell(1:dt_pre/dt:end);
C_sell_declevel0=C_sell_declevel(1,1:24);
C_sell_declevel=[C_sell_declevel0 C_sell_declevel];

% Separate 15-min MPC price vectors. Prices are constant in the present
% islanded study, but keeping a correctly sampled MPC vector avoids hidden
% hourly assumptions if time-varying prices are introduced later.
C_buy_residential_mpc_day=C_buy_residential(1:dt_mpc/dt:end);
C_buy_residential_mpc=[C_buy_residential_mpc_day C_buy_residential_mpc_day];
C_buy_business_mpc_day=C_buy_business(1:dt_mpc/dt:end);
C_buy_business_mpc=[C_buy_business_mpc_day C_buy_business_mpc_day];
C_sell_mpc_day=C_sell(1:dt_mpc/dt:end);
C_sell_mpc=[C_sell_mpc_day C_sell_mpc_day];

% Setup-price plotting removed; saved results are replayed separately.



CsocRelax=cfg.ev.terminalNumericalSlackPenalty_per_kWh;% $/kWh; numerical slack is disabled by default
C_EVSoCshed=cfg.cost.evTerminalDeficit_per_kWh;%$/kWh cost for EV terminal-energy deficit

SOCmax=cfg.storage.SOCmax;
SOCmin=cfg.storage.SOCmin;
SOC_GFL(1:BatteryNum,1)=0.50;% initial charging state of energy storage, for SOC, each row is a battery
SOC_GFM0(1:BatteryGFM_Num,1)=0.50;
SOC_EV0=zeros(EVBatteryNum,1);
SOC_EV0(1:EVBatteryNum,1)=0.50;
SOC=[SOC_GFM0;SOC_GFL;SOC_EV0];

% Numerical SoC guard at the physical-to-EMS interface. The physical
% integrator runs at 1 s and can produce tiny floating-point / finite-step
% overshoots (e.g. 0.9000086 for a 0.90 upper limit). Such values must not
% make a rolling-horizon terminal constraint mathematically infeasible.
% IMPORTANT: this is NOT a relaxation of the operating bounds. Values only
% within socNumericalTol are projected back to the exact hard bound; larger
% violations raise an error so genuine physical violations are never hidden.
socNumericalTol = 1e-4;
socNumericalClipCount = 0;
socNumericalClipMax = 0;

dSOC_EVcsp=SOCmax-SOC_EV0;

SOCrelaxGap=cfg.ev.terminalNumericalSlackMax;% legacy numerical EV terminal slack; default 0

% battery cost
Batt_Duration=cfg.storage.bessDuration_h;% h
Ncyc=cfg.cost.batteryCycles;% battery life cycle
if BatteryNum>0
    EbattMax=BatteryGFL_P_rate(BusOfBattery,1)*Batt_Duration;% per-device BESS capacities, MWh
else
    EbattMax=zeros(0,1);
end

Batt_DurationGFM=cfg.storage.gfmBessDuration_h;% h
if BatteryGFM_Num>0
    EbattMaxGFM=BatteryGFM_P_rate(BusOfBatteryGFM,1)*Batt_DurationGFM;% per-device GFM-BESS capacities, MWh
else
    EbattMaxGFM=zeros(0,1);
end

EVBatt_Duration=cfg.ev.energyDuration_h;% h
if EVBatteryNum>0
    EbattMaxEV=BatteryEV_P_rate(BusOfEVBattery,1)*EVBatt_Duration;% per-bus aggregate fleet capacity, MWh; P already includes EV count
else
    EbattMaxEV=zeros(0,1);
end
T_EVch1=11;% 0~T_EVch1 h is the first charging period
T_EVch2=16;% T_EVch2~24h is the second charging period

C_battUnitPrice=cfg.cost.batteryUnit_per_kWh;%dollar/kWh
% C_batt_total=EbattMax*1000*C_battUnitPrice;%dollar
inta_batt_ch=0.95;% charging efficiency
inta_batt_dis=0.95;% discharging efficiency

if BatteryNum+BatteryGFM_Num>0
C_deg=C_battUnitPrice/(Ncyc*2);% degradation cost
else
C_deg=0;
end
C_BESSSoCshed=cfg.cost.bessTerminalDeficit_per_kWh;%$/kWh cost for BESS terminal-energy deficit

SoCParams=struct();
SoCParams.eta_ch=inta_batt_ch;
SoCParams.eta_dis=inta_batt_dis;
SoCParams.E_GFM_MWh=EbattMaxGFM;
SoCParams.E_BESS_MWh=EbattMax;
SoCParams.E_EV_MWh=EbattMaxEV;


%===activation distribution function for EV grid-connecting===
% Please run the design code in the EV datasets file to prepare the EVactiDisFun
load(dataFile('EVactiDisFun.mat'))
% The EV availability data are hourly. Resample one periodic day onto the
% MPC grid, then duplicate it so every receding 24-h horizon can index
% across midnight without special cases.
evAvailabilityAnchors=[EVactiDisFun EVactiDisFun(1)];
EVactiDisFun_mpc_day=resample_horizon_anchors(evAvailabilityAnchors, ...
    cfg.forecast.nativeStep_h,dt_mpc,DayHours,cfg.forecast.interpolationMethod);
EVactiDisFun_mpc_day=min(max(EVactiDisFun_mpc_day,0),1);
EVactiDisFun_mpc=[EVactiDisFun_mpc_day EVactiDisFun_mpc_day];

% EV-availability plotting removed from batch engine.


Nload=numel(residential_node)+numel(business_node);
% k_LdShd=0.1;
% Treat the provided load power as the rated power, whose per unit value is 1.
PF_box=abs(Load_P_rate./sqrt(Load_P_rate.^2+Load_Q_rate.^2));% Assume constant PF

lag = 6;  % In the autoregressive model, use the previous 'lag' time points as input

regularPeriod=0; % 1: period 1; 0: period 0

% ---------load residential load data-----------
Pmat_source0=[];
Pmat_target0=[];
load(dataFile('USA_PAState_Residential.mat'));
temp=USA_PAState_Residential.ElectricityFacilitykWHourly;
P_PAresidential_TMY3=temp(2:end);
PmatYear_PA=reshape(P_PAresidential_TMY3,24,length(P_PAresidential_TMY3)/24);

if regularPeriod==1
    Pmat_source0=[PmatYear_PA(:,2:6)];
else
    Pmat_source0=[PmatYear_PA(:,2:6)]+0.05*randn(size(PmatYear_PA(:,2:6)));
end

Pmat_target0=[Pmat_target0 PmatYear_PA(:,7)];

Pmax=max(max(Pmat_source0));
Pmat_source=Pmat_source0/Pmax;
Pmat_target=Pmat_target0/Pmax;

Pmat_residential=[Pmat_source Pmat_target];


% ----------load large office load data--------------
Pmat_source0=[];
Pmat_target0=[];
load(dataFile('USA_PAState_RefBldgLargeOfficeNew2004v1.mat'));
temp=USA_PAState_RefBldgLargeOfficeNew2004v1.ElectricityFacilitykWHourly;
P_PAlargeOffice_TMY3=temp(2:end);
PmatYear_PA=reshape(P_PAlargeOffice_TMY3,24,length(P_PAlargeOffice_TMY3)/24);

if regularPeriod==1
    Pmat_source0=[Pmat_source0 PmatYear_PA(:,2:6)];
else
    Pmat_source0=[Pmat_source0 PmatYear_PA(:,198:201)+40*randn(size(PmatYear_PA(:,198:201)))];
end

if regularPeriod==1
    Pmat_target0=[Pmat_target0 PmatYear_PA(:,9)];
    Ptarget_sp=PmatYear_PA(:,5:6);
else
    Pmat_target0=[Pmat_target0 PmatYear_PA(:,202)];
end
Pmat_target0(23)=0.90*Pmat_target0(22);Pmat_target0(24)=Pmat_target0(22);

Pmax=max(max(Pmat_source0));
Pmat_source=Pmat_source0/Pmax;
Pmat_target=Pmat_target0/Pmax;

Pmat_largeOffice=[Pmat_source Pmat_target];

% prepare training data
[X_train_largeOffice, dy_train_largeOffice] = build_dataset(Pmat_largeOffice, 1:size(Pmat_largeOffice,2)-2, lag, dayPoints,1);
[X_train_residential, dy_train_residential] = build_dataset(Pmat_residential, 1:size(Pmat_residential,2)-2, lag, dayPoints,1);
curve_business=Pmat_largeOffice(:,end)';
curve_residential=Pmat_residential(:,end)';

% forecasting curve for scheduling
PF_box(isnan(PF_box))=0;
PowAngle=acos(PF_box);

P_st=Load_P_rate;

Pload_box_1day1h=zeros(BusNum,length(t_pre));
for ii=1:BusNum
    if ismember(ii,business_node)
        Pload_box_1day1h(ii,:)=curve_business*P_st(ii);
    elseif ismember(ii,residential_node)
        Pload_box_1day1h(ii,:)=curve_residential*P_st(ii);
    end
end
Qload_box_1day1h=Pload_box_1day1h.*tan(PowAngle);%Qload_box_syslevel(isnan(Qload_box_syslevel))=0;

Pload_box_syslevel_true2day_idealPredfordebug=[Pload_box_1day1h Pload_box_1day1h];

if lag>1
    Pload_box_lag1day1h=[Pload_box_1day1h(:,end-lag+2:end) Pload_box_1day1h];
    Qload_box_lag1day1h=[Qload_box_1day1h(:,end-lag+2:end) Qload_box_1day1h];
    Pload_box_lag1day1hMPC=[Pload_box_1day1h(:,end-lag+2:end) Pload_box_1day1h Pload_box_1day1h];
    Qload_box_lag1day1hMPC=[Qload_box_1day1h(:,end-lag+2:end) Qload_box_1day1h Qload_box_1day1h];
end

% numerically rebuild the true load curve at real time step size for simulation
Nvari=length(t_sim);

curve_business_true = (UniversalCurve(t_pre, curve_business,t_sim, 'pchip'));
curve_business_true = curve_business_true+0.002*randn(size(curve_business_true));
curve_residential_true = (UniversalCurve(t_pre, curve_residential,t_sim, 'pchip'));
curve_residential_true=curve_residential_true+0.002*randn(size(curve_residential_true));

Pload_true_box=zeros(BusNum,length(t_sim));
for ii=1:BusNum
    if ismember(ii,business_node)
        Pload_true_box(ii,:)=curve_business_true*P_st(ii);
    elseif ismember(ii,residential_node)
        Pload_true_box(ii,:)=curve_residential_true*P_st(ii);
    end
end
Qload_true_box=Pload_true_box.*tan(PowAngle);%Qload_box(isnan(Qload_box))=0;

Pload_true_box_1daySimstep=Pload_true_box(:,1:dt_deci/dt:end);
if lag>1
    Pload_true_box_lag1daySimstep=[Pload_true_box_1daySimstep(:,end-(lag-1)*dt_pre/dt_deci+1:end) Pload_true_box_1daySimstep];
end
Qload_true_box_lag1daySimstep=Pload_true_box_lag1daySimstep.*tan(PowAngle);

Pload_true_box_lag2daySimstepMPC=[Pload_true_box_lag1daySimstep Pload_true_box_1daySimstep];
Qload_true_box_lag2daySimstepMPC=Pload_true_box_lag2daySimstepMPC.*tan(PowAngle);

Pload_true_box_2daySimstepMPC=[Pload_true_box_1daySimstep Pload_true_box_1daySimstep];
Qload_true_box_2daySimstepMPC=Pload_true_box_2daySimstepMPC.*tan(PowAngle);

% Load setup plotting removed from batch engine.


% Representative-load plotting removed from batch engine.


% Load lag/debug plotting removed from batch engine.


% =========set up load prediction model=============
load(dataFile('lambda_busi.mat'))
load(dataFile('sigma_busi.mat'))
load(dataFile('sigmaT_busi.mat'))

N_train=size(X_train_largeOffice,1);
for i = 1:N_train
    for j = 1:N_train
        K_train_business(i,j) =AnisotropicGaussianKernel(X_train_largeOffice(i,:),X_train_largeOffice(j,:),sigma_busi,sigmaT_busi,lag); 
    end
end
alpha_best_largeOffice = (K_train_business + lambda_busi * eye(N_train)) \ dy_train_largeOffice;

load(dataFile('lambda_resid.mat'))
load(dataFile('sigma_resid.mat'))
load(dataFile('sigmaT_resid.mat'))

N_train=size(X_train_residential,1);
for i = 1:N_train
    for j = 1:N_train
        K_train_residential(i,j) =AnisotropicGaussianKernel(X_train_residential(i,:),X_train_residential(j,:),sigma_resid,sigmaT_resid,lag); 
    end
end
alpha_best_residential = (K_train_residential + lambda_resid * eye(N_train)) \ dy_train_residential;

% =============load PV data==============
Pmat_train0=[];
Pmat_test0=[];

data = readtable(dataFile('2017_pv_raw.csv'));
temp=data.Huang_E4102_kW;
PmatYears1min=reshape(temp,24*60,length(temp)/(24*60));
P_solarData=temp(1:60:end);
PmatYears=reshape(P_solarData,24,length(P_solarData)/24);

TypicalDay=max(PmatYears(:,286),0);
Pmat_curveDic=[TypicalDay 0.9*TypicalDay 0.8*TypicalDay 0.7*TypicalDay 0.6*TypicalDay 0.5*TypicalDay 0.4*TypicalDay 0.3*TypicalDay 0.2*TypicalDay 0.1*TypicalDay];
Nm=size(Pmat_curveDic,2);
Pmat_trainDisp=[];
for ii=1:Nm
    Pmat_train0{ii}=[0.96*Pmat_curveDic(:,ii) Pmat_curveDic(:,ii) 1.04*Pmat_curveDic(:,ii)];
    Pmat_trainDisp=[Pmat_trainDisp Pmat_train0{ii}];
end
TrueUnusualDay=PmatYears(:,286);
TrueUnusualDay1min=PmatYears1min(:,286);
TrueUsualDay1min=PmatYears1min(:,286);

Pmat_test0=[Pmat_test0 decayRatio*TrueUnusualDay];

% PV-dictionary plotting removed from batch engine.


%=======Model set up============
TypicalIdx=1;
beta=0.01;
for Round=1:Nm
% ------data preparation------
Pmat0=[Pmat_train0{Round} Pmat_test0];
% normalize
Pmax0=max(TypicalDay);
Pmat=Pmat0/Pmax0;
Pmat(Pmat < 0) = 0;
Pmat_train=Pmat(:,1:end-1);

train_idx = 1:size(Pmat_train,2);

usedx=1;
[X_train_PV{Round}, nextX_train_PV] = build_dataset(Pmat_train,train_idx, lag, dayPoints, usedx);

% --------------set up PV prediction model---------------
load(dataFile('best_lambdaBox_PV.mat'));
load(dataFile('best_sigmaBox_PV.mat'));
load(dataFile('sigmaTBox_PV.mat'));

N_train=size(X_train_PV{Round},1);
for i = 1:N_train
    for j = 1:N_train
        K_train_PV(i,j) =AnisotropicGaussianKernel(X_train_PV{Round}(i,:),X_train_PV{Round}(j,:),best_sigmaBox_PV(1,Round),sigmaTBox_PV(1,Round),lag); 
    end
end
alpha_best_PV{Round} = (K_train_PV + best_lambdaBox_PV(1,Round) * eye(N_train)) \ nextX_train_PV;
end

% =========prepare true curve for this application scenario==============
TypicalDay_st=TypicalDay'/max(TypicalDay);
P_PV1_curve_1day1h_fore=zeros(BusNum,length(t_pre));
for ii=1:BusNum
    if ismember(ii,BusOfPV)
        P_PV1_curve_1day1h_fore(ii,:)=TypicalDay_st*PVInv_P_rate(ii,1);% The forecasting curve used for making decision has a normal bell shape
    end
end

P_PV1_curve_lag1day1h_fore=[P_PV1_curve_1day1h_fore(:,end-lag+2:end) P_PV1_curve_1day1h_fore];

Pmat_test=Pmat_test0/max(TypicalDay);
TypicalDay_st_true=Pmat_test(:,end)';
TypicalDay_st_true(TypicalDay_st_true<0)=0;
P_PV1_curve_1day1h_true=zeros(BusNum,length(t_pre));
for ii=1:BusNum
    if ismember(ii,BusOfPV)
        P_PV1_curve_1day1h_true(ii,:)=TypicalDay_st_true*PVInv_P_rate(ii,1);% The forecasting curve used for making decision has a normal bell shape
    end
end

P_PV1_curve_lag1day1h_true=[P_PV1_curve_1day1h_true(:,end-lag+2:end) P_PV1_curve_1day1h_true];
% P_PV1_curve_lag2day1h_trueMPC=[P_PV1_curve_1day1h_true(:,end-lag+2:end) P_PV1_curve_1day1h_true P_PV1_curve_1day1h_true];
P_PV1_curve_2day1h_true=[P_PV1_curve_1day1h_true P_PV1_curve_1day1h_true];


% -----------simulation-time resolution PV curve----------------
t_pv=0:1/60:24-1/60;
if strcmp(dayType,'Usual day')
    TrueUsualDay1min=1*TrueUsualDay1min;
    TrueUsualDay1min_st=TrueUsualDay1min/Pmax0;
    TrueUsualDay1min_st(TrueUsualDay1min_st<0)=0;
    PV1_curve_st = UniversalCurve(t_pv, TrueUsualDay1min_st',t_sim, 'pchip');
elseif strcmp(dayType,'Unusual day')
    TrueUnusualDay1min=decayRatio*TrueUnusualDay1min;
    TrueUnusualDay1min_st=TrueUnusualDay1min/Pmax0;
    TrueUnusualDay1min_st(TrueUnusualDay1min_st<0)=0;
    PV1_curve_st = UniversalCurve(t_pv, TrueUnusualDay1min_st',t_sim, 'pchip');
end
% PV1_curve = PV1_curve_st*PVInv_S_rate(BusOfPV(1),1);
PV1_curve=zeros(BusNum,length(t_sim));
for ii=1:BusNum
    if ismember(ii,BusOfPV)
        PV1_curve(ii,:)=PV1_curve_st*PVInv_P_rate(ii,1);% The forecasting curve used for making decision has a normal bell shape
    end
end

% --------measured true curve for MPC forecasting------
PV1_curve_1dayDecStep=PV1_curve(:,1:dt_deci/dt:end);
w = 9;                          % window size (odd is better)
% PV1_curve_1dayDecStep = movmean(PV1_curve_1dayDecStep, w, 2, 'omitnan');   % row-wise smoothing
if lag>1
    PV1_curve_lag1dayDecStep=[PV1_curve_1dayDecStep(:,end-(lag-1)*dt_pre/dt_deci+1:end) PV1_curve_1dayDecStep];%The measured solar data for MPC at each decision step
end

P_PV1_curve_lag2day1h_trueMPC=[PV1_curve_lag1dayDecStep PV1_curve_1dayDecStep];
P_PV1_curve_2day1h_trueMPC=[PV1_curve_1dayDecStep PV1_curve_1dayDecStep];

% PV setup plotting removed from batch engine.


% % Typical curve for EMS scheduling
% t_h=0:1:23;
% wind_base = 0.3 + 0.2*sin(2*pi*(t_h-5)/18) + 0.2*sin(2*pi*t_h/8) + 0.1*randn(size(t_h)); % gentle diurnal effect
% wind_noise = 0.02*randn(size(t_h));  
% wind_curve=wind_base + wind_noise;
% P_WT1_curve_sys0=wind_curve;
% figure
% plot(t_h, wind_curve);
% xlabel('Hour'); ylabel('Normalized Wind Power');
% title('Forecasting Wind Power Curve');
% 
% % True wind power curve (normalized 0~1, 24 hours, hourly resolution)
% wind_base = 0.3 + 0.2*sin(2*pi*(t_sys)/18) + 0.2*sin(2*pi*t_sys/8) + 0.01*randn(size(t_sys)); % gentle diurnal effect
% wind_noise = 0.001*randn(size(t_sys));           % strong random fluctuations
% wind_curve = wind_base + wind_noise;
% P_WT1_curve_sys0_true=wind_curve;
% figure
% plot(t_sys, wind_curve);
% xlabel('Hour'); ylabel('Normalized Wind Power');
% title('True Daily Wind Power Curve');


if ismember(1,activateCase)

[dP_RESVdown,dP_RESVup,reserveMetaStatic] = compute_frequency_reserve_pu( ...
    runCfg.reserveMode, runCfg.reserveFixedRatio, Rdroop, phys.H, ...
    df_reserve_Hz, rocof_limit_Hz_s, f_rate, aiModel, [], ...
    P_DGmin, P_DGmax, aiCfgRun);

% x=[(...,Pdg[1->24],...),(...,Pdis[1->24],Pch[1->24],...) ,(...,PEVdis[1->24],PEVch[1->24],...), (...,PresMax[1->24],...),(...,Pload(residential,business)[1->24],...)]' decision variable format;

Kday=24;

% ==============power forecasting for scheduling===================
% if strcmp(dayType,'Unusual')
% ------day-ahead forcast load and Res information--------
decisionStep=1;
predictionStep=1;
S_PV_busBox(:,1:lag)=P_PV1_curve_lag1day1h_fore(:,decisionStep:dt_pre:decisionStep+(lag-1)*dt_pre);% active power optimization for economic dispatch
% S_PV_busBox(:,1:lag)=PV1_curve_lag1dayDecStep(:,decisionStep:dt_pre/dt_deci:decisionStep+(lag-1)*dt_pre/dt_deci);% active power optimization for economic dispatch
P_PV=zeros(BusNum,1);

Sload_busBox(:,1:lag)=Pload_true_box_lag1daySimstep(:,decisionStep:dt_pre/dt_deci:decisionStep+(lag-1)*dt_pre/dt_deci)+1j*Qload_true_box_lag1daySimstep(:,decisionStep:dt_pre/dt_deci:decisionStep+(lag-1)*dt_pre/dt_deci);% active power optimization for economic dispatch
Sload=zeros(BusNum,1);

predictionHorizon=24;
useUpStream=1;
lookAheadStep=1;

iniPV_Seq=(real(S_PV_busBox(BusOfPV(1),1:lag))./PVInv_P_rate(BusOfPV(1),1))';
Xi = WeightDetermine(iniPV_Seq,Pmat_curveDic/max(TypicalDay),lag,beta,TypicalIdx);
for ii=1:predictionHorizon % forecasting before optimization
    StdTime=mod((ii-1+predictionStep-1)*dt_pre,24)/24;
    % % ========== update the next step load and GFL power==========
    % PV prediction (assume local MPPT control)------------
    P_PV_busBoxST(BusOfPV,ii:ii+lag-1)=real(S_PV_busBox(BusOfPV,ii:ii+lag-1))./PVInv_P_rate(BusOfPV,1);
    P_PV_busBoxST(BusOfPV,ii+lag)=max(SolarPredModel(P_PV_busBoxST(BusOfPV(1),ii:ii+lag-1),X_train_PV,Xi,best_sigmaBox_PV,sigmaTBox_PV,alpha_best_PV,P_PV1_curve_2day1h_true(BusOfPV(1),predictionStep-1+ii+1)./PVInv_P_rate(BusOfPV(1),1),ii,useUpStream,lookAheadStep,StdTime,TypicalIdx),0);
    S_PV_busBox(BusOfPV,ii+lag)=(P_PV_busBoxST(BusOfPV,ii+lag)+1j*0).*PVInv_P_rate(BusOfPV,1);
    
    P_PV(:,ii)=S_PV_busBox(:,ii+lag-1);
    
    % load prediction----------
    Pload_busBoxST(residential_node,ii:ii+lag-1)=real(Sload_busBox(residential_node,ii:ii+lag-1))./P_st(residential_node,1);
    Pload_busBoxST(residential_node,ii+lag)=LoadPredModel(Pload_busBoxST(residential_node(1),ii:ii+lag-1),X_train_residential,sigma_resid,sigmaT_resid,alpha_best_residential,StdTime);
    Sload_busBox(residential_node,ii+lag)=(Pload_busBoxST(residential_node,ii+lag)).*P_st(residential_node,1);
    
    Pload_busBoxST(business_node,ii:ii+lag-1)=real(Sload_busBox(business_node,ii:ii+lag-1))./P_st(business_node,1);
    Pload_busBoxST(business_node,ii+lag)=LoadPredModel(Pload_busBoxST(business_node(1),ii:ii+lag-1),X_train_largeOffice,sigma_busi,sigmaT_busi,alpha_best_largeOffice,StdTime);
    Sload_busBox(business_node,ii+lag)=(Pload_busBoxST(business_node,ii+lag)).*P_st(business_node,1);
    
    Sload(:,ii)=Sload_busBox(:,ii+lag-1);
end
S_PV=P_PV;


% else
% % ------ideal perfect prediction case------
% Sload=zeros(BusNum,Kday);
% Sload([residential_node business_node],:)=Pload_box_lag1day1h([residential_node business_node],lag:end)+1j*Qload_box_lag1day1h([residential_node business_node],lag:end);
% 
% P_PV=zeros(BusNum,Kday);
% P_PV(BusOfPV,:)=P_PV1_curve_1day1h_true(BusOfPV,:);
% end
% ====================================

% coefficient vector of objective function
Pload_resid=sum(real(Sload(residential_node,:)));
Pload_busi=sum(real(Sload(business_node,:)));
w_c_resid=Pload_resid./(Pload_resid+Pload_busi);
w_c_busi=Pload_busi./(Pload_resid+Pload_busi);
C_buy=C_buy_residential_declevel0.*w_c_resid+C_buy_business_declevel0.*w_c_busi;

DG_GFM_coefBox=[];
for ii=1:DG_GFM_num
    DG_GFM_coefBox=[DG_GFM_coefBox C_dieselG*ones(1,Kday)];
end

GFM_coefBox=[];
for ii=1:BatteryGFM_Num
    GFM_coefBox=[GFM_coefBox C_deg*ones(1,Kday) C_deg*ones(1,Kday)];
end

batt_coefBox=[];
for ii=1:BatteryNum
    batt_coefBox=[batt_coefBox C_deg*ones(1,Kday) C_deg*ones(1,Kday)];
end

EVbatt_coefBox=[];
for ii=1:EVBatteryNum
    EVbatt_coefBox=[EVbatt_coefBox C_deg*ones(1,Kday) C_deg*ones(1,Kday)];% shuffle the sequence of the price vector
end

resMax_coefBox=[];
for ii=1:SolarNum
    resMax_coefBox=[resMax_coefBox -C_PVCurt*ones(1,Kday)];
end

loadShed_coefBox=[];
for ii=1:Nload
    loadShed_coefBox=[loadShed_coefBox C_LdShd*ones(1,Kday)];
end

f_linprog=1000*[DG_GFM_coefBox GFM_coefBox batt_coefBox EVbatt_coefBox resMax_coefBox loadShed_coefBox]*dt_pre;
f_linprog=f_linprog';

% ==========ineq================
% ---box constraints----


DG_GFM_lbBox=[];
for ii=1:DG_GFM_num
    DG_GFM_lbBox=[DG_GFM_lbBox (P_DGmin+dP_RESVdown(ii))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(ii),1)*ones(1,Kday) ];
end

battGFM_lbBox=[];
for ii=1:BatteryGFM_Num
    battGFM_lbBox=[battGFM_lbBox 0*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday) 0*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)];
end

batt_lbBox=[];
for ii=1:BatteryNum
    batt_lbBox=[batt_lbBox 0*BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday) 0*BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)];
end

EVbatt_lbBox=[];
for ii=1:EVBatteryNum
    EVbatt_lbBox=[EVbatt_lbBox 0*BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday) 0*BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday)];
end

resMax_lbBox=[];
for ii=1:SolarNum
    resMax_lbBox=[resMax_lbBox 0*ones(1,Kday)];
end

loadShed_lbBox=[];
for ii=[residential_node business_node]
    loadShed_lbBox=[loadShed_lbBox 0*real(Sload(ii,1))*ones(1,Kday)];
end

lb=[DG_GFM_lbBox...
    battGFM_lbBox...
    batt_lbBox...
    EVbatt_lbBox...
    resMax_lbBox...
    loadShed_lbBox...
    ]';


DG_GFM_ubBox=[];
for ii=1:DG_GFM_num
    DG_GFM_ubBox=[DG_GFM_ubBox (P_DGmax-dP_RESVup(ii))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(ii),1)*ones(1,Kday) ];
end

battGFM_ubBox=[];
for ii=1:BatteryGFM_Num
    battGFM_ubBox=[battGFM_ubBox (P_gfmIBRmax-dP_RESVup(ii))*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday) (P_gfmIBRmax-dP_RESVup(ii))*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)];
end

batt_ubBox=[];
for ii=1:BatteryNum
    batt_ubBox=[batt_ubBox BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday) BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)];
end

EVbatt_ubBox=[];
for ii=1:EVBatteryNum
    EVbatt_ubBox=[EVbatt_ubBox 0*BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday) BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday).*EVactiDisFun];
end

resMax_ubBox=[];
for ii=1:SolarNum
    resMax_ubBox=[resMax_ubBox P_PV(BusOfPV(ii),:)];
end

loadShed_ubBox=[];
for ii=[residential_node business_node]
    loadShed_ubBox=[loadShed_ubBox k_LdShd*abs(real(Sload(ii,:)))];
end

ub=[DG_GFM_ubBox...
    battGFM_ubBox...
    batt_ubBox...
    EVbatt_ubBox...
    resMax_ubBox...
    loadShed_ubBox...
    ]';

% =======linear inequality constraints====
A=[];
b=[];

[Aineq_SOC,bineq_SOC]=SOC_InequalityConstraintsForBFS_LP(Kday,SOCmax,SOCmin,SOC(:,1),EbattMaxGFM,EbattMax,EbattMaxEV,inta_batt_ch,inta_batt_dis,DG_GFM_num,BatteryGFM_Num,BatteryNum,EVBatteryNum,SolarNum,Nload,dt_pre,SOC(:,1));
A=[A;Aineq_SOC];
b=[b;bineq_SOC];

% Frequency awareness is enforced only through the explicit DG reserve box
% constraints above; disabled legacy Pref-step/nadir surrogates were removed.

% ================equality constraints============
% ---power balance----
b_powbal=(sum(real(Sload),1))';% uncontrollable power, positive value means injection into the grid
Atmp=[];
for ii=1:DG_GFM_num
    Atmp=[Atmp -eye(Kday)];
end
for ii=1:BatteryNum+BatteryGFM_Num
    Atmp=[Atmp -eye(Kday) eye(Kday)];
end
for ii=1:EVBatteryNum
    tmp1=-eye(Kday);tmp2=eye(Kday);
    tmp=[tmp1 tmp2];
    Atmp=[Atmp tmp];
end
for ii=1:SolarNum
    Atmp=[Atmp -eye(Kday)];% output power is negative value on the left side of the equal
end
for ii=1:Nload
    Atmp=[Atmp -eye(Kday)];% output power is negative value on the left side of the equal
end

Aeq=[Atmp];
beq=[b_powbal];

opts=optimoptions('linprog','Display','none');

tic
[x,fval,exitflag,output]=linprog(f_linprog,A,b,Aeq,beq,lb,ub,opts);
check_solver_solution(x,exitflag,'linprog','day-ahead LP');
solverExitflagHistory=exitflag;
dayahead_linprog_timecost=toc

x0_LP_NP=x;

idx=0;



PbattGFM_dis=[];PbattGFM_ch=[];Pbatt_dis=[];Pbatt_ch=[];PbattEV_dis=[];PbattEV_ch=[];Pbatt_opt=[];P_DG_opt=[];Pres_opt=[];
for ii=1:DG_GFM_num
    P_DG_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
end
for ii=1:BatteryGFM_Num
    PbattGFM_dis(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
    PbattGFM_ch(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
    PbattGFM_opt(:,:,ii) = PbattGFM_dis(:,:,ii) - PbattGFM_ch(:,:,ii); 
end
for ii=1:BatteryNum
    Pbatt_dis(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
    Pbatt_ch(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
    Pbatt_opt(:,:,ii) = Pbatt_dis(:,:,ii) - Pbatt_ch(:,:,ii); 
end
for ii=1:EVBatteryNum
    PbattEV_dis(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
    PbattEV_ch(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
    PbattEV_opt(:,:,ii) = PbattEV_dis(:,:,ii) - PbattEV_ch(:,:,ii); 
end
for ii=1:SolarNum
    Pres_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday; 
end
for ii=1:Nload
    dPload_opt(ii,:) = x(idx+1:idx+Kday);idx=idx+Kday; 
end

% DA-LP schedule plotting removed; use saved-result replay.


%-------------------------------%
fprintf('MPC EMS daily scheduling time cost: %fs\n', dayahead_linprog_timecost);
mean(dayahead_linprog_timecost)

P_DG_opt_Dec=[];
for ii=1:DG_GFM_num
    P_DG_opt_Dec(:,:,ii)=UniversalCurve(t_pre, P_DG_opt(:,:,ii)',t_pre, 'previous')';
end
PbattGFM_opt_Dec=[];
for ii=1:BatteryGFM_Num
    PbattGFM_opt_Dec(:,:,ii)=UniversalCurve(t_pre, PbattGFM_opt(:,:,ii)',t_pre, 'previous')';
end
Pbatt_opt_Dec=[];
for ii=1:BatteryNum
    Pbatt_opt_Dec(:,:,ii)=UniversalCurve(t_pre, Pbatt_opt(:,:,ii)',t_pre, 'previous')';
end
PbattEV_opt_Dec=[];
for ii=1:EVBatteryNum
    PbattEV_opt_Dec(:,:,ii)=UniversalCurve(t_pre, PbattEV_opt(:,:,ii)',t_pre, 'previous')';
end
Pres_opt_Dec=[];
for ii=1:SolarNum
    Pres_opt_Dec(:,:,ii)=UniversalCurve(t_pre, Pres_opt(:,:,ii)',t_pre, 'previous')';
end
dPload_opt_Dec=[];
for ii=1:Nload
    dPload_opt_Dec(ii,:)=UniversalCurve(t_pre, dPload_opt(ii,:),t_pre, 'previous')';
end
nr = numel(residential_node);
nb = numel(business_node);

dPload = zeros(BusNum,size(dPload_opt_Dec,2));
dPload(residential_node,:) = dPload_opt_Dec(1:nr,:);
dPload(business_node,:)    = dPload_opt_Dec(nr+1:nr+nb,:);
dQload=dPload.*tan(PowAngle);
% ===================simulation====================
tic
Pbatt=[];
for RealStep = 1:DayHours*samplePerHour
    decisionStep=ceil(RealStep*dt*1);

    if RealStep==1
        S_load_vec=Pload_true_box(:,RealStep)+1j*Qload_true_box(:,RealStep);
        [Vs, Vinv, Xbasic(:,RealStep),freq(:,RealStep),~]=InitializationProgram(P_DG_opt_Dec,PbattGFM_opt_Dec,Pbatt_opt_Dec,PbattEV_opt_Dec,DieselG_Pgfm_rate,Pload_true_box,Qload_true_box,PV1_curve,V_DC,Zs_DG,Xd_prime,Xm_g,Zmv_g,Y_Bus_dyn,SOC(:,RealStep),SOCmin,SOCmax,DGcontrolParams,SoCParams,phys,K_Pdp,K_Qdp,Rdroop,kQ_DG,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,BusNum,DG_GFM_num,BatteryGFM_Num,BatteryNum,EVBatteryNum,SolarNum,MainGFM,dt,Integrator);
        S_slack_ini=-sum(S_load_vec);
        meanfreq(:,RealStep)=compute_coi_frequency(freq(:,RealStep),DieselG_Pgfm_rate,phys.H);
        
        Niter=5;% suggest value >=
    else
        S_load_vec=Pload_true_box(:,RealStep)+1j*Qload_true_box(:,RealStep)+(dPload(:,decisionStep)+1j*dQload(:,decisionStep));
        S_slack_ini=S_busInjVec(1);

        Niter=3;% suggest value >=
    end
    
    idx_ref=0;
    for ii=1:DG_GFM_num
        Ref(idx_ref+1,RealStep)=1;idx_ref=idx_ref+1;%Vset GFM
        Ref(idx_ref+1,RealStep)=P_DG_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%Qg1_bat set
    end

    for ii=1:BatteryGFM_Num
        Ref(idx_ref+1,RealStep)=1;idx_ref=idx_ref+1;%Vset GFM
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%dw_set GFM
        Ref(idx_ref+1,RealStep)=PbattGFM_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%Qg1_bat set
    end

    for ii=1:BatteryNum
        Ref(idx_ref+1,RealStep)=Pbatt_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%Qg1_bat set
    end

    for ii=1:EVBatteryNum
        Ref(idx_ref+1,RealStep)=PbattEV_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%Qg1_bat set
    end

    for ii=1:SolarNum
        Ref(idx_ref+1,RealStep)=min(Pres_opt_Dec(decisionStep,1,ii),PV1_curve(BusOfPV(ii),RealStep));idx_ref=idx_ref+1;%Pg2_bat set
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%Qg2_bat set
    end
    
    
    [Xbasic(:,RealStep+1),Vs,Vinv,S_busInjVec,S_DG,S_inv_Batt,S_inv_PV,freq(:,RealStep+1),SOC(:,RealStep+1),fvalpf, exitflagpf,obserP{RealStep}]=MicrogridSys_ODEAE_expIterSolver(Xbasic(:,RealStep),Vs,Vinv,Ref(:,RealStep),S_load_vec,V_DC,Zs_DG,Xm_g,Zmv_g,Y_Bus_dyn,SOC(:,RealStep),SOCmin,SOCmax,DieselG_Pgfm_rate,DGcontrolParams,SoCParams,phys,K_Pdp,K_Qdp,Rdroop,kQ_DG,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,MainGFM,dt,Niter,Integrator);                                                                                                                                    
    [SOC(:,RealStep+1),socGuardMeta] = sanitize_soc_state( ...
        SOC(:,RealStep+1),SOCmin,SOCmax,socNumericalTol, ...
        sprintf('physical state after second %d',RealStep));
    socNumericalClipCount = socNumericalClipCount + socGuardMeta.clipCount;
    socNumericalClipMax = max(socNumericalClipMax,socGuardMeta.maxCorrection);
    pfExitflagHistory(RealStep)=exitflagpf;

    % record results and calculate costs
    VsBoxBasic(:,RealStep)=Vs;
    meanfreq(:,RealStep)=compute_coi_frequency(freq(:,RealStep+1),DieselG_Pgfm_rate,phys.H);
    dmeanfreq(:,RealStep)=compute_coi_frequency(freq(:,RealStep+1),DieselG_Pgfm_rate,phys.H)-f_rate;
    Pload_BoxBasic(:,RealStep)=real(S_load_vec([residential_node business_node],:));
    Qload_BoxBasic(:,RealStep)=imag(S_load_vec([residential_node business_node],:));

    Pload_resid=real(sum(S_load_vec(residential_node,1)));
    Pload_busi=real(sum(S_load_vec(business_node,1)));
    w_c_resid=Pload_resid/(Pload_resid+Pload_busi);
    w_c_busi=Pload_busi/(Pload_resid+Pload_busi);
    C_buy(1,RealStep)=C_buy_residential(1,RealStep)*w_c_resid+C_buy_business(1,RealStep)*w_c_busi;

    P_DG(:,RealStep)=real(S_DG(BusOfDieselG_GFM,1));
    P_res(:,RealStep)=real(S_inv_PV(BusOfPV,1));

    idx_ref=0;
    Pbatt(:,RealStep)=real(S_inv_Batt([BusOfBatteryGFM BusOfBattery BusOfEVBattery],1));
    Pbatt_dis=max(Pbatt(:,RealStep),0);% active power injected from the storage system
    Pbatt_ch=max(-Pbatt(:,RealStep),0);% active power consumed by the storage system
    
    V_from = Vs(Line(:,1));
    V_to   = Vs(Line(:,2));
    I_line(:,RealStep) = (V_from - V_to) ./ Impedance;
    Ploss(1,RealStep) = sum(abs(I_line(:,RealStep)).^2 .* real(Impedance));
    
    P_DG_GFM=sum(real(S_DG(BusOfDieselG_GFM,:)));
    P_Batt_GFM=sum(real(S_inv_Batt(BusOfBatteryGFM,:)));
    
    % Pbuy=max(real(S_busInjVec(BusOfSlack,:)),0);% total active power injected from the large system
    % Pbuy_forPowBalan=max(Pbuy-Ploss(1,RealStep),0);% additional power for load power balance
    % Psell=max(-real(S_busInjVec(BusOfSlack,:)),0);%active power consumed by the large system
    
    CostRecord(1,RealStep)=(C_dieselG*sum(P_DG(:,RealStep)) + C_deg*sum(Pbatt_ch+Pbatt_dis) + C_LdShd*sum(dPload_opt_Dec(:,decisionStep)))*dt*1000;% $; losses are already internalized by DG dispatch/SoC dynamics
    
    P_battVec_chr=min(Pbatt(:,RealStep),0);
    TotalLoad(1,RealStep)=real(sum(S_load_vec));
    % TotalConsume(1,RealStep)=real(sum(S_load_vec))+sum(P_battVec_chr)-Ploss(1,RealStep);
    TotalConsume(1,RealStep)=real(sum(S_load_vec))+sum(P_battVec_chr);% diagnostic consumption; network losses are represented by the physical power flow
    P_battVec_gen=max(Pbatt(:,RealStep),0);
    TotalGen(1,RealStep)=sum(P_battVec_gen)+real(sum(S_inv_PV))+P_DG_GFM;
    TotalGFM(1,RealStep)=P_DG_GFM+P_Batt_GFM;
    TotalBatt(1,RealStep)=sum(Pbatt(:,RealStep));
    TotalPV(1,RealStep)=real(sum(S_inv_PV(BusOfPV,1)));
end
timeCostsimulationDayAhead=toc;
fprintf('MPC EMS daily simulation time cost: %fs\n', timeCostsimulationDayAhead);

Pload_true_boxPlt=Pload_true_box([residential_node business_node],:);
[totalCost]=EMS_results_display(Pload_BoxBasic,Qload_BoxBasic,Pload_true_boxPlt,P_DG,Pbatt,P_res,TotalLoad,TotalConsume,Ploss,TotalGen,TotalBatt,TotalPV,TotalGFM,CostRecord,VsBoxBasic,SOC,T_EVch1,T_EVch2,Xbasic,I_line,LineLimits,Vmin,Vmax,ResiUserNum+BusiUserNum,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,meanfreq,t_sim,ExportFigForPaper,brhID,cfg.output.showFigures);
disp(['Average frequency deviation:',num2str(sum(dmeanfreq)/length(dmeanfreq)),'Hz'])
disp(['Total cost for day-ahead LP: $',num2str(totalCost)])
disp(['Average value of one step decision time cost for day-ahead LP: ',num2str(dayahead_linprog_timecost/Kday),'s'])

fig_idx=1;
TotalLoadBox{fig_idx}=TotalLoad;
TotalGFMBox{fig_idx}=TotalGFM;
TotalBattBox{fig_idx}=TotalBatt;
TotalPVBox{fig_idx}=TotalPV;
SoC_BOX{fig_idx}=SOC;
Iline_magBox{fig_idx}=abs(I_line(brhID,:));
Vs_magBox{fig_idx}=abs(VsBoxBasic(busID,:));
freqBox{fig_idx}=meanfreq;
EcoCostBox{fig_idx}=totalCost;
DeciTimeCostBox{fig_idx}=dayahead_linprog_timecost;

P_DG_opt_DecBox{fig_idx}=P_DG_opt_Dec;
P_DGBox{fig_idx}=P_DG;
end


if ismember(4,activateCase)

[dP_RESVdown,dP_RESVup,reserveMetaStatic] = compute_frequency_reserve_pu( ...
    runCfg.reserveMode, runCfg.reserveFixedRatio, Rdroop, phys.H, ...
    df_reserve_Hz, rocof_limit_Hz_s, f_rate, aiModel, [], ...
    P_DGmin, P_DGmax, aiCfgRun);

% x=[(...,Pdg[1->24],...|...,Qdg[1->24],...),(...,Pdis_i[k=1->24],Pch_i[1->24],...|...,Q_i[k=1->24],...),(...,PEVdis[1->24],PEVch[1->24],...),(...,PresMax[1->24],...|...,QresMax[1->24],...),(...,Pload(residential,business)[1->24],...),(...,P_br[k]\in Gird,Q_br[k]\in Gird,~l_br[k]\in Gird,~v_bus[k]\in Gird,...)k=1~24]' decision variable format
Kday=24;
Nbranch=size(LineBFM,1);

% ==============power forecasting for scheduling===================
% if strcmp(dayType,'Unusual')
% ------day-ahead forcast load and Res information--------
decisionStep=1;
predictionStep=1;
S_PV_busBox(:,1:lag)=P_PV1_curve_lag1day1h_fore(:,decisionStep:dt_pre:decisionStep+(lag-1)*dt_pre);% active power optimization for economic dispatch
P_PV=zeros(BusNum,1);

Sload_busBox(:,1:lag)=Pload_true_box_lag1daySimstep(:,decisionStep:dt_pre/dt_deci:decisionStep+(lag-1)*dt_pre/dt_deci)+1j*Qload_true_box_lag1daySimstep(:,decisionStep:dt_pre/dt_deci:decisionStep+(lag-1)*dt_pre/dt_deci);% active power optimization for economic dispatch
Sload=zeros(BusNum,1);

predictionHorizon=24;
useUpStream=1;
lookAheadStep=1;

iniPV_Seq=(real(S_PV_busBox(BusOfPV(1),1:lag))./PVInv_P_rate(BusOfPV(1),1))';
Xi = WeightDetermine(iniPV_Seq,Pmat_curveDic/max(TypicalDay),lag,beta,TypicalIdx);
for ii=1:predictionHorizon % forecasting before optimization
    StdTime=mod((ii-1+predictionStep-1)*dt_pre,24)/24;
    % % ========== update the next step load and GFL power==========
    % PV prediction (assume local MPPT control)------------
    P_PV_busBoxST(BusOfPV,ii:ii+lag-1)=real(S_PV_busBox(BusOfPV,ii:ii+lag-1))./PVInv_P_rate(BusOfPV,1);
    P_PV_busBoxST(BusOfPV,ii+lag)=max(SolarPredModel(P_PV_busBoxST(BusOfPV(1),ii:ii+lag-1),X_train_PV,Xi,best_sigmaBox_PV,sigmaTBox_PV,alpha_best_PV,P_PV1_curve_2day1h_true(BusOfPV(1),predictionStep-1+ii+1)./PVInv_P_rate(BusOfPV(1),1),ii,useUpStream,lookAheadStep,StdTime,TypicalIdx),0);
    S_PV_busBox(BusOfPV,ii+lag)=(P_PV_busBoxST(BusOfPV,ii+lag)+1j*0).*PVInv_P_rate(BusOfPV,1);
    
    P_PV(:,ii)=S_PV_busBox(:,ii+lag-1);
    
    % load prediction----------
    Pload_busBoxST(residential_node,ii:ii+lag-1)=real(Sload_busBox(residential_node,ii:ii+lag-1))./P_st(residential_node,1);
    Pload_busBoxST(residential_node,ii+lag)=LoadPredModel(Pload_busBoxST(residential_node(1),ii:ii+lag-1),X_train_residential,sigma_resid,sigmaT_resid,alpha_best_residential,StdTime);
    Sload_busBox(residential_node,ii+lag)=(Pload_busBoxST(residential_node,ii+lag)).*P_st(residential_node,1);
    
    Pload_busBoxST(business_node,ii:ii+lag-1)=real(Sload_busBox(business_node,ii:ii+lag-1))./P_st(business_node,1);
    Pload_busBoxST(business_node,ii+lag)=LoadPredModel(Pload_busBoxST(business_node(1),ii:ii+lag-1),X_train_largeOffice,sigma_busi,sigmaT_busi,alpha_best_largeOffice,StdTime);
    Sload_busBox(business_node,ii+lag)=(Pload_busBoxST(business_node,ii+lag)).*P_st(business_node,1);
    
    Sload(:,ii)=Sload_busBox(:,ii+lag-1);
end
S_PV=P_PV;

% else
% % ------ideal perfect prediction case------
% Sload=zeros(BusNum,Kday);
% Sload([residential_node business_node],:)=Pload_box_lag1day1h([residential_node business_node],lag:end)+1j*Qload_box_lag1day1h([residential_node business_node],lag:end);
% 
% P_PV=zeros(BusNum,Kday);
% P_PV(BusOfPV,:)=P_PV1_curve_1day1h_true(BusOfPV,:);
% 
% % Sload=Pload_box_lag1day1h(:,lag:end)+1j*Qload_box_lag1day1h(:,lag:end);
% % P_PV=P_PV1_curve_lag1day1h_true(:,lag:end);
% end
% ====================================

% coefficient vector of objective function
Pload_resid=sum(real(Sload(residential_node,:)));
Pload_busi=sum(real(Sload(business_node,:)));
w_c_resid=Pload_resid./(Pload_resid+Pload_busi);
w_c_busi=Pload_busi./(Pload_resid+Pload_busi);
C_buy=C_buy_residential_declevel0.*w_c_resid+C_buy_business_declevel0.*w_c_busi;

DG_GFM_coefBox=[];
for ii=1:DG_GFM_num
    DG_GFM_coefBox=[DG_GFM_coefBox C_dieselG*ones(1,Kday) zeros(1,Kday)];
end

GFM_coefBox=[];
for ii=1:BatteryGFM_Num
    GFM_coefBox=[GFM_coefBox C_deg*ones(1,Kday) C_deg*ones(1,Kday) zeros(1,Kday)];
end

batt_coefBox=[];
for ii=1:BatteryNum
    batt_coefBox=[batt_coefBox C_deg*ones(1,Kday) C_deg*ones(1,Kday) zeros(1,Kday)];
end

EVbatt_coefBox=[];
for ii=1:EVBatteryNum
    EVbatt_coefBox=[EVbatt_coefBox C_deg*ones(1,Kday) C_deg*ones(1,Kday)];% shuffle the sequence of the price vector
end

resMax_coefBox=[];
for ii=1:SolarNum
    resMax_coefBox=[resMax_coefBox -C_PVCurt*ones(1,Kday) zeros(1,Kday)];
end

loadShed_coefBox=[];
for ii=1:Nload
    loadShed_coefBox=[loadShed_coefBox C_LdShd*ones(1,Kday)];
end

f_coneprog=1000*[DG_GFM_coefBox GFM_coefBox batt_coefBox EVbatt_coefBox resMax_coefBox loadShed_coefBox]*dt_pre;

for ii=1:Kday
    f_coneprog=[f_coneprog zeros(1,Nbranch) zeros(1,Nbranch) zeros(1,Nbranch) zeros(1,BusNum)];
end
% C_zeta
f_coneprog=f_coneprog';

% ==========ineq================
% ---box constraints----
lb=[];
ub=[];

% l
DG_GFM_lbBox=[];
for ii=1:DG_GFM_num
    DG_GFM_lbBox=[DG_GFM_lbBox (P_DGmin+dP_RESVdown(ii))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(ii),1)*ones(1,Kday) -(P_DGmin+dP_RESVdown(ii))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(ii),1)*ones(1,Kday)];
end

battGFM_lbBox=[];
for ii=1:BatteryGFM_Num
    battGFM_lbBox=[battGFM_lbBox 0*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)/PF 0*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)/PF -(P_gfmIBRmax-dP_RESVup(ii))*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)/PF];
end

batt_lbBox=[];
for ii=1:BatteryNum
    batt_lbBox=[batt_lbBox 0*BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)/PF 0*BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)/PF -BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)/PF];
end

EVbatt_lbBox=[];
for ii=1:EVBatteryNum
    EVbatt_lbBox=[EVbatt_lbBox 0*BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday)/PF 0*BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday)/PF];
end

resMax_lbBox=[];
for ii=1:SolarNum
    resMax_lbBox=[resMax_lbBox 0*ones(1,Kday)/PF -PVInv_P_rate(BusOfPV(ii),:)*ones(1,Kday)/PF];
end

loadShed_lbBox=[];
for ii=[residential_node business_node]
    loadShed_lbBox=[loadShed_lbBox 0*real(Sload(ii,1))*ones(1,Kday)];
end

lb=[DG_GFM_lbBox...
    battGFM_lbBox...
    batt_lbBox...
    EVbatt_lbBox...
    resMax_lbBox...
    loadShed_lbBox...
    ]';

for ii=1:Kday
    lb=[lb;[0;-10*ones(Nbranch-1,1)];[0;-10*ones(Nbranch-1,1)];zeros(Nbranch,1);Vmin^2*ones(BusNum,1)];
end

% u
DG_GFM_ubBox=[];
for ii=1:DG_GFM_num
    DG_GFM_ubBox=[DG_GFM_ubBox (P_DGmax-dP_RESVup(ii))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(ii),1)*ones(1,Kday) (P_DGmax-dP_RESVup(ii))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(ii),1)*ones(1,Kday)];
end

battGFM_ubBox=[];
for ii=1:BatteryGFM_Num
    battGFM_ubBox=[battGFM_ubBox (P_gfmIBRmax-dP_RESVup(ii))*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)/PF (P_gfmIBRmax-dP_RESVup(ii))*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)/PF (P_gfmIBRmax-dP_RESVup(ii))*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)/PF];
end

batt_ubBox=[];
for ii=1:BatteryNum
    batt_ubBox=[batt_ubBox BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)/PF BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)/PF BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)/PF];
end

EVbatt_ubBox=[];
for ii=1:EVBatteryNum
    EVbatt_ubBox=[EVbatt_ubBox 0*BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday)/PF BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday).*EVactiDisFun/PF];
end

resMax_ubBox=[];
for ii=1:SolarNum
    resMax_ubBox=[resMax_ubBox P_PV(BusOfPV(ii),:)/PF PVInv_P_rate(BusOfPV(ii),:)*ones(1,Kday)/PF];
end

loadShed_ubBox=[];
for ii=[residential_node business_node]
    loadShed_ubBox=[loadShed_ubBox k_LdShd*abs(real(Sload(ii,:)))];
end

ub=[DG_GFM_ubBox...
    battGFM_ubBox...
    batt_ubBox...
    EVbatt_ubBox...
    resMax_ubBox...
    0*loadShed_ubBox...
    ]';

for ii=1:Kday
    ub=[ub;[0;10*ones(Nbranch-1,1)];[0;10*ones(Nbranch-1,1)];(k_brch*LineLimitsBFM).^2;Vmax^2*ones(BusNum,1)];
end

% -----other inequality linear constraints-----
A=[];
b=[];

% ---SOC----
[Aineq_SOC,bineq_SOC]=SOC_InequalityConstraintsForBFS_withLoadShed(Kday,SOCmax,SOCmin,SOC(:,1),EbattMaxGFM,EbattMax,EbattMaxEV,inta_batt_ch,inta_batt_dis,DG_GFM_num,BatteryGFM_Num,BatteryNum,EVBatteryNum,SolarNum,Nload,Nbranch,BusNum,dt_pre);
A=[A;Aineq_SOC];
b=[b;bineq_SOC];

% Frequency awareness is enforced only through the explicit DG reserve box
% constraints above; disabled legacy Pref-step/nadir surrogates were removed.

% eq
Aeq=[];
beq=[];

% power flow 
V_slack=1;
[Aeq_grid,beq_grid]=LinearEqualityConstraintsForBFS_SOCP_powerbalance_island_withLS(LineBFM,V_slack,Kday,Sload,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,[residential_node business_node]);

Aeq=[Aeq;Aeq_grid];
beq=[beq;beq_grid];

% cone
[Asc_ass_cell1,bsc_ass_cell1,dsc_ass_cell1,gamma_ass_cell1]=ConeConstraintsForBFS_SOCP_island_withLoadShed(LineBFM,V_slack,Kday,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,Nload);

% P^2+Q^2<=S^2 cone constraints for DG
[Asc_ass_cell2,bsc_ass_cell2,dsc_ass_cell2,gamma_ass_cell2]=ConeConstraintsForDGcapacity_island_withLoadShed(DieselG_Pgfm_rateVec/PF,BatteryGFM_P_rate/PF,BatteryGFL_P_rate/PF,PVInv_P_rate/PF,LineBFM,Kday,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,Nload);

Asc_ass_cell=[Asc_ass_cell1;Asc_ass_cell2];
bsc_ass_cell=[bsc_ass_cell1;bsc_ass_cell2];
dsc_ass_cell=[dsc_ass_cell1;dsc_ass_cell2];
gamma_ass_cell=[gamma_ass_cell1;gamma_ass_cell2];


socConstraints = optim.coneprog.SecondOrderConeConstraint.empty;

for k = 1:length(Asc_ass_cell)
    socConstraints(end+1) = secondordercone(Asc_ass_cell{k}, bsc_ass_cell{k}, dsc_ass_cell{k}, gamma_ass_cell{k});
end


tic
[x, fval, exitflag, output] = coneprog(f_coneprog, socConstraints,A,b,Aeq,beq,lb,ub,coneOptions);
check_solver_solution(x,exitflag,'coneprog','day-ahead SOCP');
solverExitflagHistory=exitflag;
dayahead_coneprog_timecost=toc;

x0_LP_NP=x(1:(DG_GFM_num+SolarNum)*Kday+(BatteryNum+BatteryGFM_Num+EVBatteryNum)*Kday*2);

idx=0;
PbattGFM_dis=[];PbattGFM_ch=[];Pbatt_dis=[];Pbatt_ch=[];PbattEV_dis=[];PbattEV_ch=[];Pbatt_opt=[];P_DG_opt=[];Q_DG_opt=[];Pres_opt=[];
for ii=1:DG_GFM_num
    P_DG_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
    Q_DG_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
end
for ii=1:BatteryGFM_Num
    PbattGFM_dis(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
    PbattGFM_ch(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
    PbattGFM_opt(:,:,ii) = PbattGFM_dis(:,:,ii) - PbattGFM_ch(:,:,ii); 
    QbattGFM_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday; 
end
for ii=1:BatteryNum
    Pbatt_dis(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
    Pbatt_ch(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
    Pbatt_opt(:,:,ii) = Pbatt_dis(:,:,ii) - Pbatt_ch(:,:,ii); 
    Qbatt_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday; 
end
for ii=1:EVBatteryNum
    PbattEV_dis(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
    PbattEV_ch(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
    PbattEV_opt(:,:,ii) = PbattEV_dis(:,:,ii) - PbattEV_ch(:,:,ii); 
end
for ii=1:SolarNum
    Pres_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday; 
    Qres_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday; 
end
for ii=1:Nload
    dPload_opt(ii,:) = x(idx+1:idx+Kday);idx=idx+Kday; 
end

for ii=1:Kday
    P_br(:,ii)=x(idx+1:idx+Nbranch);idx=idx+Nbranch;
    Q_br(:,ii)=x(idx+1:idx+Nbranch);idx=idx+Nbranch;
    l_br(:,ii)=x(idx+1:idx+Nbranch);idx=idx+Nbranch;
    v_bus(:,ii)=x(idx+1:idx+BusNum);idx=idx+BusNum;

    num = abs(P_br(2:end,ii).^2+Q_br(2:end,ii).^2 - l_br(2:end,ii).*v_bus(Line(:,1),ii));
    % Here, for the den of the relative gap, may be the results without the
    % constraint will be more reasonable
    % den = max([1e-6*ones(Nbranch-1,1), abs(P_br(2:end,ii).^2), abs(l_br(2:end,ii).*v_br(Line(:,1),ii))], [], 2);
    den = max(max(abs(P_br(2:end,ii).^2)));

    relaxationGapBox(:,ii)    = num;          % absolute gap
    relaxationGap(1,ii)       = max(num);     % max absolute gap
    relaxationRelGapBox(:,ii) = num ./ den;   % relative gap
    relaxationRelGap(1,ii)    = max(relaxationRelGapBox(:,ii)); % max relative gap
end
disp('Relaxation gap of power constraints in a day:');
disp(relaxationGap);

disp('Relative relaxation gap of power constraints in a day:');
disp(relaxationRelGap);


% ----angle recovery analysis (meshed networks only)----
% Formal TICPS cases are radial. When Loops==0 there is no loop-angle
% consistency condition to evaluate, so the meshed-grid helper is skipped.
if Loops > 0
    BranchIndexAndSign=LoopBranchDirectSign(LineBFM,loopNodes,Loops);
    AngleErrorBox=zeros(Loops,Kday);
    MagErrorBox=zeros(Loops,Kday);
    for ii=1:Kday
        for e=1:Loops
            br_n=loopBranches{e};
            node_fr=LineBFM(br_n,1);
            node_to=LineBFM(br_n,2);
            Angle=zeros(1,length(br_n)+1);
            MagError=zeros(1,length(br_n)+1);
            for jj=1:length(br_n)
                V_from_mag=sqrt(v_bus(node_fr(jj),ii));
                P=P_br(br_n(jj),ii);
                Q=Q_br(br_n(jj),ii);
                z=LineBFM(br_n(jj),3)+1j*LineBFM(br_n(jj),4);
                Isign=BranchIndexAndSign{e}(jj,2);
                Angle(jj+1)=Angle(jj)+Isign*angle( ...
                    V_from_mag-z*(P-1j*Q)/V_from_mag);
                MagError(jj+1)=abs(abs( ...
                    V_from_mag-z*(P-1j*Q)/V_from_mag) ...
                    -sqrt(v_bus(node_to(jj),ii)));
            end
            AngleErrorBox(e,ii)=Angle(end);
            MagErrorBox(e,ii)=MagError(end);
        end
    end
    MaxAngleErrorAllLoopInDay=max(max(abs(AngleErrorBox)));
    MaxMagErrorAllLoopInDay=max(max(abs(MagErrorBox)));
    disp('max angle error for all loops in a day:');
    disp(MaxAngleErrorAllLoopInDay);
    disp('max magnitude error for all loops in a day:');
    disp(MaxMagErrorAllLoopInDay);
else
    BranchIndexAndSign=cell(0,1);
    AngleErrorBox=zeros(0,Kday);
    MagErrorBox=zeros(0,Kday);
    MaxAngleErrorAllLoopInDay=NaN;
    MaxMagErrorAllLoopInDay=NaN;
    fprintf('Angle-recovery loop audit skipped: radial topology has no fundamental loops.\n');
end

% DA-SOCP schedule plotting removed; use saved-result replay.


%-------------------------------%
fprintf('MPC EMS daily scheduling time cost: %fs\n', dayahead_coneprog_timecost);
mean(dayahead_coneprog_timecost)

P_DG_opt_Dec=[];Q_DG_opt_Dec=[];
for ii=1:DG_GFM_num
    P_DG_opt_Dec(:,:,ii)=UniversalCurve(t_pre, P_DG_opt(:,:,ii)',t_pre, 'previous')';
    Q_DG_opt_Dec(:,:,ii)=UniversalCurve(t_pre, Q_DG_opt(:,:,ii)',t_pre, 'previous')';
end
PbattGFM_opt_Dec=[];QbattGFM_opt_Dec=[];
for ii=1:BatteryGFM_Num
    PbattGFM_opt_Dec(:,:,ii)=UniversalCurve(t_pre, PbattGFM_opt(:,:,ii)',t_pre, 'previous')';
    QbattGFM_opt_Dec(:,:,ii)=UniversalCurve(t_pre, QbattGFM_opt(:,:,ii)',t_pre, 'previous')';
end
Pbatt_opt_Dec=[];Qbatt_opt_Dec=[];
for ii=1:BatteryNum
    Pbatt_opt_Dec(:,:,ii)=UniversalCurve(t_pre, Pbatt_opt(:,:,ii)',t_pre, 'previous')';
    Qbatt_opt_Dec(:,:,ii)=UniversalCurve(t_pre, Qbatt_opt(:,:,ii)',t_pre,'previous')';
end
PbattEV_opt_Dec=[];
for ii=1:EVBatteryNum
    PbattEV_opt_Dec(:,:,ii)=UniversalCurve(t_pre, PbattEV_opt(:,:,ii)',t_pre, 'previous')';
end
Pres_opt_Dec=[];Qres_opt_Dec=[];
for ii=1:SolarNum
    Pres_opt_Dec(:,:,ii)=UniversalCurve(t_pre, Pres_opt(:,:,ii)',t_pre, 'previous')';
    Qres_opt_Dec(:,:,ii)=UniversalCurve(t_pre, Qres_opt(:,:,ii)',t_pre, 'previous')';
end
dPload_opt_Dec=[];
for ii=1:Nload
    dPload_opt_Dec(ii,:)=UniversalCurve(t_pre, dPload_opt(ii,:),t_pre, 'previous')';
end
nr = numel(residential_node);
nb = numel(business_node);

dPload = zeros(BusNum,size(dPload_opt_Dec,2));
dPload(residential_node,:) = dPload_opt_Dec(1:nr,:);
dPload(business_node,:)    = dPload_opt_Dec(nr+1:nr+nb,:);
dQload=dPload.*tan(PowAngle);
% ===================simulation====================
tic
Pbatt=[];

for RealStep = 1:DayHours*samplePerHour
    decisionStep=ceil(RealStep*dt*1);
    
    if RealStep==1
        S_load_vec=Pload_true_box(:,RealStep)+1j*Qload_true_box(:,RealStep);
        [Vs, Vinv, Xbasic(:,RealStep),freq(:,RealStep),~]=InitializationProgramPQ(P_DG_opt_Dec,Q_DG_opt_Dec,PbattGFM_opt_Dec,QbattGFM_opt_Dec,Pbatt_opt_Dec,Qbatt_opt_Dec,PbattEV_opt_Dec,Pres_opt_Dec,Qres_opt_Dec,DieselG_Pgfm_rate,Pload_true_box,Qload_true_box,PV1_curve,Q_BattInvMax,V_DC,Zs_DG,Xd_prime,Xm_g,Zmv_g,Y_Bus_dyn,SOC(:,RealStep),SOCmin,SOCmax,DGcontrolParams,SoCParams,phys,K_Pdp,K_Qdp,Rdroop,kQ_DG,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,BusNum,DG_GFM_num,BatteryGFM_Num,BatteryNum,EVBatteryNum,SolarNum,MainGFM,dt,Integrator);
        S_slack_ini=-sum(S_load_vec);
        meanfreq(:,RealStep)=compute_coi_frequency(freq(:,RealStep),DieselG_Pgfm_rate,phys.H);
        
        Niter=5;% suggest value >=
    else
        S_load_vec=Pload_true_box(:,RealStep)+1j*Qload_true_box(:,RealStep)+(dPload(:,decisionStep)+1j*dQload(:,decisionStep));
        S_slack_ini=S_busInjVec(1);

        Niter=3;% suggest value >=
    end
    
    idx_ref=0;
    for ii=1:DG_GFM_num
        Ref(idx_ref+1,RealStep)=1;idx_ref=idx_ref+1;%Vset GFM
        Ref(idx_ref+1,RealStep)=P_DG_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=Q_DG_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Qg1_bat set
    end

    for ii=1:BatteryGFM_Num
        Ref(idx_ref+1,RealStep)=1;idx_ref=idx_ref+1;%Vset GFM
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%dw_set GFM
        Ref(idx_ref+1,RealStep)=PbattGFM_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=QbattGFM_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Qg1_bat set
    end

    for ii=1:BatteryNum
        Ref(idx_ref+1,RealStep)=Pbatt_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=Qbatt_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Qg1_bat set
        % Ref(idx+1,RealStep)=Q_V_control(Vs(BusOfBattery(ii)),Q_BattInvMax(BusOfBattery(ii)));idx=idx+1;%Qg1_bat set
    end

    for ii=1:EVBatteryNum
        Ref(idx_ref+1,RealStep)=PbattEV_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%Qg1_bat set
        % Ref(idx+1,RealStep)=Q_V_control(Vs(BusOfBattery(ii)),Q_BattInvMax(BusOfBattery(ii)));idx=idx+1;%Qg1_bat set
    end

    for ii=1:SolarNum
        % Ref(idx_ref+1,RealStep)=min(Pres_opt_Dec(decisionStep,1,ii),PV1_curve(BusOfPV(ii),RealStep));idx_ref=idx_ref+1;%Pg2_bat set
        Ref(idx_ref+1,RealStep)=min(Pres_opt_Dec(decisionStep,1,ii),PV1_curve(BusOfPV(ii),RealStep));idx_ref=idx_ref+1;%Pg2_bat set
        Ref(idx_ref+1,RealStep)=Qres_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Qg2_bat set
    end
    
    
    [Xbasic(:,RealStep+1),Vs,Vinv,S_busInjVec,S_DG,S_inv_Batt,S_inv_PV,freq(:,RealStep+1),SOC(:,RealStep+1),fvalpf, exitflagpf,~]=MicrogridSys_ODEAE_expIterSolver(Xbasic(:,RealStep),Vs,Vinv,Ref(:,RealStep),S_load_vec,V_DC,Zs_DG,Xm_g,Zmv_g,Y_Bus_dyn,SOC(:,RealStep),SOCmin,SOCmax,DieselG_Pgfm_rate,DGcontrolParams,SoCParams,phys,K_Pdp,K_Qdp,Rdroop,kQ_DG,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,MainGFM,dt,Niter,Integrator);                                                                                                                                    
    [SOC(:,RealStep+1),socGuardMeta] = sanitize_soc_state( ...
        SOC(:,RealStep+1),SOCmin,SOCmax,socNumericalTol, ...
        sprintf('physical state after second %d',RealStep));
    socNumericalClipCount = socNumericalClipCount + socGuardMeta.clipCount;
    socNumericalClipMax = max(socNumericalClipMax,socGuardMeta.maxCorrection);
    pfExitflagHistory(RealStep)=exitflagpf;

    % record results and calculate costs
    VsBoxBasic(:,RealStep)=Vs;
    meanfreq(:,RealStep)=compute_coi_frequency(freq(:,RealStep+1),DieselG_Pgfm_rate,phys.H);
    dmeanfreq(:,RealStep)=compute_coi_frequency(freq(:,RealStep+1),DieselG_Pgfm_rate,phys.H)-f_rate;
    Pload_BoxBasic(:,RealStep)=real(S_load_vec([residential_node business_node],:));
    Qload_BoxBasic(:,RealStep)=imag(S_load_vec([residential_node business_node],:));

    Pload_resid=real(sum(S_load_vec(residential_node,1)));
    Pload_busi=real(sum(S_load_vec(business_node,1)));
    w_c_resid=Pload_resid/(Pload_resid+Pload_busi);
    w_c_busi=Pload_busi/(Pload_resid+Pload_busi);
    C_buy(1,RealStep)=C_buy_residential(1,RealStep)*w_c_resid+C_buy_business(1,RealStep)*w_c_busi;

    P_DG(:,RealStep)=real(S_DG(BusOfDieselG_GFM,1));
    P_res(:,RealStep)=real(S_inv_PV(BusOfPV,1));

    idx_ref=0;
    Pbatt(:,RealStep)=real(S_inv_Batt([BusOfBatteryGFM BusOfBattery BusOfEVBattery],1));
    Pbatt_dis=max(Pbatt(:,RealStep),0);% active power injected from the storage system
    Pbatt_ch=max(-Pbatt(:,RealStep),0);% active power consumed by the storage system
    
    V_from = Vs(Line(:,1));
    V_to   = Vs(Line(:,2));
    I_line(:,RealStep) = (V_from - V_to) ./ Impedance;
    Ploss(1,RealStep) = sum(abs(I_line(:,RealStep)).^2 .* real(Impedance));
    
    P_DG_GFM=sum(real(S_DG(BusOfDieselG_GFM,:)));
    P_Batt_GFM=sum(real(S_inv_Batt(BusOfBatteryGFM,:)));
    
    % Pbuy=max(real(S_busInjVec(BusOfSlack,:)),0);% total active power injected from the large system
    % Pbuy_forPowBalan=max(Pbuy-Ploss(1,RealStep),0);% additional power for load power balance
    % Psell=max(-real(S_busInjVec(BusOfSlack,:)),0);%active power consumed by the large system
    
    CostRecord(1,RealStep)=(C_dieselG*sum(P_DG(:,RealStep)) + C_deg*sum(Pbatt_ch+Pbatt_dis) + C_LdShd*sum(dPload_opt_Dec(:,decisionStep)))*dt*1000;% $; losses are already internalized by DG dispatch/SoC dynamics
    
    P_battVec_chr=min(Pbatt(:,RealStep),0);
    TotalLoad(1,RealStep)=real(sum(S_load_vec));
    % TotalConsume(1,RealStep)=real(sum(S_load_vec))+sum(P_battVec_chr)-Ploss(1,RealStep);
    TotalConsume(1,RealStep)=real(sum(S_load_vec))+sum(P_battVec_chr);% diagnostic consumption; network losses are represented by the physical power flow
    P_battVec_gen=max(Pbatt(:,RealStep),0);
    TotalGen(1,RealStep)=sum(P_battVec_gen)+real(sum(S_inv_PV))+P_DG_GFM;
    TotalGFM(1,RealStep)=P_DG_GFM+P_Batt_GFM;
    TotalBatt(1,RealStep)=sum(Pbatt(:,RealStep));
    TotalPV(1,RealStep)=real(sum(S_inv_PV(BusOfPV,1)));
end
timeCostsimulationDayAhead=toc;
fprintf('MPC EMS daily simulation time cost: %fs\n', timeCostsimulationDayAhead);
Pload_true_boxPlt=Pload_true_box([residential_node business_node],:);

[totalCost]=EMS_results_display(Pload_BoxBasic,Qload_BoxBasic,Pload_true_boxPlt,P_DG,Pbatt,P_res,TotalLoad,TotalConsume,Ploss,TotalGen,TotalBatt,TotalPV,TotalGFM,CostRecord,VsBoxBasic,SOC,T_EVch1,T_EVch2,Xbasic,I_line,LineLimits,Vmin,Vmax,ResiUserNum+BusiUserNum,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,meanfreq,t_sim,ExportFigForPaper,brhID,cfg.output.showFigures);
disp(['Average frequency deviation:',num2str(sum(dmeanfreq)/length(dmeanfreq)),'Hz'])
disp(['Total cost for day-ahead SOCP: $',num2str(totalCost)])
disp(['Average value of one step decision time cost for day-ahead SOCP: ',num2str(timeCostsimulationDayAhead/Kday),'s'])

fig_idx=4;
TotalLoadBox{fig_idx}=TotalLoad;
TotalGFMBox{fig_idx}=TotalGFM;
TotalBattBox{fig_idx}=TotalBatt;
TotalPVBox{fig_idx}=TotalPV;
SoC_BOX{fig_idx}=SOC;
Iline_magBox{fig_idx}=abs(I_line(brhID,:));
Vs_magBox{fig_idx}=abs(VsBoxBasic(busID,:));
freqBox{fig_idx}=meanfreq;
EcoCostBox{fig_idx}=totalCost;
DeciTimeCostBox{fig_idx}=dayahead_coneprog_timecost;

P_DG_opt_DecBox{fig_idx}=P_DG_opt_Dec;
P_DGBox{fig_idx}=P_DG;
end


if ismember(6,activateCase)

[dP_RESVdown,dP_RESVup,reserveMetaStatic] = compute_frequency_reserve_pu( ...
    runCfg.reserveMode, runCfg.reserveFixedRatio, Rdroop, phys.H, ...
    df_reserve_Hz, rocof_limit_Hz_s, f_rate, aiModel, [], ...
    P_DGmin, P_DGmax, aiCfgRun);


predictionHorizon = predictionHorizonMPC;
controlHorizon=predictionHorizon;
useUpStream = 1;
lookAheadStep = 1;

Kday=predictionHorizon;
Nbranch=size(Line,1);
offset = 2*Kday*BatteryNum + 2*Kday;

SOC_EV_base=zeros(numel(BusOfEVBattery),1);
infeFlag=1;

decisionStep=1;
predictionStep=1;

outter=tic;
for RealStep = 1:DayHours*samplePerHour

    if mod(RealStep-1,samplesPerDecision)==0 && predictionStep<=predictionHorizon

        decisionBlockTimer=tic;

        % Build the native HOURLY forecast anchors from the existing KRR
        % models, then resample those anchors onto the 15-min MPC grid. The
        % optimizer therefore sees 96 stages over 24 h, while the trained
        % forecasters remain unchanged.
        historyIdx=decisionStep:forecastStride:decisionStep+(lag-1)*forecastStride;
        S_PV_busBox=zeros(BusNum,forecastHorizon+lag);
        Sload_busBox=zeros(BusNum,forecastHorizon+lag);
        S_PV_busBox(:,1:lag)=P_PV1_curve_lag2day1h_trueMPC(:,historyIdx);
        Sload_busBox(:,1:lag)=Pload_true_box_lag2daySimstepMPC(:,historyIdx) + ...
            1j*Qload_true_box_lag2daySimstepMPC(:,historyIdx);

        iniPV_Seq=(real(S_PV_busBox(BusOfPV(1),1:lag))./PVInv_P_rate(BusOfPV(1),1))';
        if strcmp(dayType,'Usual day')
            Xi = zeros(size(iniPV_Seq,2),size(Pmat_curveDic,2));
            Xi(:,1)=1;
        else
            Xi = WeightDetermine(iniPV_Seq,Pmat_curveDic/max(TypicalDay),lag,beta,TypicalIdx);
        end

        P_PV_busBoxST=zeros(BusNum,forecastHorizon+lag);
        Pload_busBoxST=zeros(BusNum,forecastHorizon+lag);
        P_PV_anchor=zeros(BusNum,forecastHorizon+1);
        Sload_anchor=zeros(BusNum,forecastHorizon+1);
        for ii=1:forecastHorizon
            currentClock_h=(decisionStep-1)*dt_deci+(ii-1)*dt_pre;
            StdTime=mod(currentClock_h,24)/24;
            futureIdx=decisionStep+ii*forecastStride;

            % PV prediction on the native 1-h grid.
            P_PV_busBoxST(BusOfPV,ii:ii+lag-1)= ...
                real(S_PV_busBox(BusOfPV,ii:ii+lag-1))./PVInv_P_rate(BusOfPV,1);
            P_PV_busBoxST(BusOfPV,ii+lag)=max(SolarPredModel( ...
                P_PV_busBoxST(BusOfPV(1),ii:ii+lag-1),X_train_PV,Xi, ...
                best_sigmaBox_PV,sigmaTBox_PV,alpha_best_PV, ...
                P_PV1_curve_2day1h_trueMPC(BusOfPV(1),futureIdx)./PVInv_P_rate(BusOfPV(1),1), ...
                ii,useUpStream,lookAheadStep,StdTime,TypicalIdx),0);
            S_PV_busBox(BusOfPV,ii+lag)= ...
                (P_PV_busBoxST(BusOfPV,ii+lag)+1j*0).*PVInv_P_rate(BusOfPV,1);
            P_PV_anchor(:,ii)=S_PV_busBox(:,ii+lag-1);

            % Load prediction on the native 1-h grid.
            Pload_busBoxST(residential_node,ii:ii+lag-1)= ...
                real(Sload_busBox(residential_node,ii:ii+lag-1))./P_st(residential_node,1);
            Pload_busBoxST(residential_node,ii+lag)=LoadPredModel( ...
                Pload_busBoxST(residential_node(1),ii:ii+lag-1), ...
                X_train_residential,sigma_resid,sigmaT_resid,alpha_best_residential,StdTime);
            Sload_busBox(residential_node,ii+lag)= ...
                Pload_busBoxST(residential_node,ii+lag).*P_st(residential_node,1);

            Pload_busBoxST(business_node,ii:ii+lag-1)= ...
                real(Sload_busBox(business_node,ii:ii+lag-1))./P_st(business_node,1);
            Pload_busBoxST(business_node,ii+lag)=LoadPredModel( ...
                Pload_busBoxST(business_node(1),ii:ii+lag-1), ...
                X_train_largeOffice,sigma_busi,sigmaT_busi,alpha_best_largeOffice,StdTime);
            Sload_busBox(business_node,ii+lag)= ...
                Pload_busBoxST(business_node,ii+lag).*P_st(business_node,1);
            Sload_anchor(:,ii)=Sload_busBox(:,ii+lag-1);
        end

        % Include the terminal +24-h anchor so interpolation to 23.75 h does
        % not require extrapolation.
        P_PV_anchor(:,forecastHorizon+1)=S_PV_busBox(:,forecastHorizon+lag);
        Sload_anchor(:,forecastHorizon+1)=Sload_busBox(:,forecastHorizon+lag);
        P_PV=resample_horizon_anchors(P_PV_anchor,dt_pre,dt_mpc, ...
            cfg.mpc.horizon_h,cfg.forecast.interpolationMethod);
        P_PV=max(P_PV,0);
        Sload=resample_horizon_anchors(Sload_anchor,dt_pre,dt_mpc, ...
            cfg.mpc.horizon_h,cfg.forecast.interpolationMethod);
        % FINAL_MPC_INPUT_INTERVAL_AVERAGE_BEGIN
        % Represent each 15-min MPC stage by the adjacent-point average
        % of its PREDICTIVE load/PV samples. Physical 1-s true curves
        % Pload_true_box and PV1_curve are intentionally unchanged.
        if isfield(cfg.forecast,'useMPCIntervalAverage') && ...
                cfg.forecast.useMPCIntervalAverage
            if size(Sload,2)>=2
                Sload=[0.5*(Sload(:,1:end-1)+Sload(:,2:end)) Sload(:,end)];
            end
            if size(P_PV,2)>=2
                P_PV=[0.5*(P_PV(:,1:end-1)+P_PV(:,2:end)) P_PV(:,end)];
            end
        end
        % FINAL_MPC_INPUT_INTERVAL_AVERAGE_END
        S_PV=P_PV;


        % else strcmp(dayType,'Usual day')
        % % ------ perfect prediction case------
        % Sload=Pload_true_box_2daySimstepMPC(:,decisionStep:dt_pre/dt_deci:decisionStep+dt_pre/dt_deci*(predictionHorizon-1))+1j*Qload_true_box_lag2daySimstepMPC(:,decisionStep:dt_pre/dt_deci:decisionStep+dt_pre/dt_deci*(predictionHorizon-1));
        % 
        % P_PV=P_PV1_curve_2day1h_trueMPC(:,decisionStep:dt_pre/dt_deci:decisionStep+dt_pre/dt_deci*(predictionHorizon-1));
        % end
        % ====================================

        %% --- Energy Management System  ---
        % x=[(...,Pdg[1->24],...),(...,Pdis[1->24],Pch[1->24],...) ,(...,PEVdis[1->24],PEVch[1->24],dSOCrelax,...), (...,PresMax[1->24],...)]' decision variable format;

        % T_EVch1mpc=mod(T_EVch1+predictionStep-2,Kday)+1;
        % T_EVch2mpc=mod(T_EVch2+predictionStep-2,Kday)+1;

        % coefficient vector of objective function
        Pload_resid=sum(real(Sload(residential_node,:)));
        Pload_busi=sum(real(Sload(business_node,:)));
        w_c_resid=Pload_resid./(Pload_resid+Pload_busi);
        w_c_busi=Pload_busi./(Pload_resid+Pload_busi);
        C_buy=C_buy_residential_mpc(1,predictionStep:predictionStep+predictionHorizon-1).*w_c_resid+C_buy_business_mpc(1,predictionStep:predictionStep+predictionHorizon-1).*w_c_busi;


        DG_GFM_coefBox=[];
        for ii=1:DG_GFM_num
            DG_GFM_coefBox=[DG_GFM_coefBox C_dieselG*ones(1,Kday)];
        end
        
        GFM_coefBox=[];
        for ii=1:BatteryGFM_Num
            GFM_coefBox=[GFM_coefBox C_deg*ones(1,Kday) C_deg*ones(1,Kday)];
        end
        
        batt_coefBox=[];
        for ii=1:BatteryNum
            batt_coefBox=[batt_coefBox C_deg*ones(1,Kday) C_deg*ones(1,Kday)];
        end
        
        EVbatt_coefBox=[];
        for ii=1:EVBatteryNum
            EVbatt_coefBox=[EVbatt_coefBox ...
                C_deg*ones(1,Kday) ...
                C_deg*ones(1,Kday) ...
                CsocRelax*EbattMaxEV(ii)/dt_mpc];% shuffle the sequence of the price vector
        end
        
        resMax_coefBox=[];
        for ii=1:SolarNum
            resMax_coefBox=[resMax_coefBox -C_PVCurt*ones(1,Kday)];
        end

        loadShed_coefBox=[];
        for ii=1:Nload
            loadShed_coefBox=[loadShed_coefBox C_LdShd*ones(1,Kday)];
        end
        
        f_linprog=1000*[DG_GFM_coefBox GFM_coefBox batt_coefBox EVbatt_coefBox resMax_coefBox loadShed_coefBox]*dt_mpc;
        f_linprog=f_linprog';

        % ==============inequality constraints=================
        % -------box constraints------------
        % lb
        DG_GFM_lbBox=[];
        for ii=1:DG_GFM_num
            DG_GFM_lbBox=[DG_GFM_lbBox (P_DGmin+dP_RESVdown(ii))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(ii),1)*ones(1,Kday) ];
        end
        
        battGFM_lbBox=[];
        for ii=1:BatteryGFM_Num
            battGFM_lbBox=[battGFM_lbBox 0*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday) 0*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)];
        end
        
        batt_lbBox=[];
        for ii=1:BatteryNum
            batt_lbBox=[batt_lbBox 0*BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday) 0*BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)];
        end
        
        EVbatt_lbBox=[];
        for ii=1:EVBatteryNum
            EVbatt_lbBox=[EVbatt_lbBox 0*BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday) 0*BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday) 0];
        end
        
        resMax_lbBox=[];
        for ii=1:SolarNum
            resMax_lbBox=[resMax_lbBox 0*ones(1,Kday)];
        end
        
        loadShed_lbBox=[];
        for ii=[residential_node business_node]
            loadShed_lbBox=[loadShed_lbBox 0*real(Sload(ii,1))*ones(1,Kday)];
        end
        
        lb=[DG_GFM_lbBox...
            battGFM_lbBox...
            batt_lbBox...
            EVbatt_lbBox...
            resMax_lbBox...
            loadShed_lbBox...
            ]';

        % ub
        DG_GFM_ubBox=[];
        for ii=1:DG_GFM_num
            DG_GFM_ubBox=[DG_GFM_ubBox (P_DGmax-dP_RESVup(ii))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(ii),1)*ones(1,Kday) ];
        end
        
        battGFM_ubBox=[];
        for ii=1:BatteryGFM_Num
            battGFM_ubBox=[battGFM_ubBox (P_gfmIBRmax-dP_RESVup(ii))*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday) (P_gfmIBRmax-dP_RESVup(ii))*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)];
        end
        
        batt_ubBox=[];
        for ii=1:BatteryNum
            batt_ubBox=[batt_ubBox BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday) BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)];
        end
        
        EVbatt_ubBox=[];
        for ii=1:EVBatteryNum
            EVbatt_ubBox=[EVbatt_ubBox 0*BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday) BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday).*EVactiDisFun_mpc(predictionStep:predictionStep+predictionHorizon-1) SOCrelaxGap];
        end
        
        resMax_ubBox=[];
        for ii=1:SolarNum
            resMax_ubBox=[resMax_ubBox P_PV(BusOfPV(ii),:)];
        end

        loadShed_ubBox=[];
        for ii=[residential_node business_node]
            loadShed_ubBox=[loadShed_ubBox k_LdShd*abs(real(Sload(ii,:)))];
        end
        
        ub=[DG_GFM_ubBox...
            battGFM_ubBox...
            batt_ubBox...
            EVbatt_ubBox...
            resMax_ubBox...
            loadShed_ubBox...
            ]';

        % ------linear inequality constraints-------
        A=[];
        b=[];

        % ---------SOC constraints-------
        [Aineq_SOC,bineq_SOC]=SOC_InequalityConstraintsForBFS_LP_MPC(Kday,SOCmax,SOCmin,SOC(:,RealStep),EbattMaxGFM,EbattMax,EbattMaxEV,inta_batt_ch,inta_batt_dis,DG_GFM_num,BatteryGFM_Num,BatteryNum,EVBatteryNum,SolarNum,Nload,dt_mpc,predictionStep,SOC(:,1));
        A=[A;Aineq_SOC];
        b=[b;bineq_SOC];

        % Frequency awareness is enforced only through the explicit DG reserve box
% constraints above; disabled legacy Pref-step/nadir surrogates were removed.

% ================equality constraints============
        % ---power balance----
        b_powbal=(sum(real(Sload),1))';% uncontrollable power, positive value means injection into the grid
        Atmp=[];
        for ii=1:DG_GFM_num
            Atmp=[Atmp -eye(Kday)];
        end
        for ii=1:BatteryNum+BatteryGFM_Num
            Atmp=[Atmp -eye(Kday) eye(Kday)];
        end
        for ii=1:EVBatteryNum
            tmp1=-eye(Kday);tmp2=eye(Kday);
            tmp=[tmp1 tmp2 zeros(Kday,1)];
            Atmp=[Atmp tmp];
        end
        for ii=1:SolarNum
            Atmp=[Atmp -eye(Kday)];% output power is negative value on the left side of the equal
        end
        for ii=1:Nload
            Atmp=[Atmp -eye(Kday)];% output power is negative value on the left side of the equal
        end
        
        Aeq=[Atmp];
        beq=[b_powbal];

        opts=optimoptions('linprog','Display','off');
        inner=tic;
        [x,fval,exitflag,output]=linprog(f_linprog,A,b,Aeq,beq,lb,ub,opts);
        check_solver_solution(x,exitflag,'linprog',sprintf('MPC-LP step %d',predictionStep));
        solverExitflagHistory(decisionStep)=exitflag;
        decisionTimeMPC_LPwithoutgridBox(decisionStep)=toc(inner);


        if decisionStep>1
            idx=0;
            PbattGFM_disPre=[];PbattGFM_chPre=[];Pbatt_disPre=[];Pbatt_chPre=[];PbattEV_disPre=[];PbattEV_chPre=[];Pbatt_optPre=[];P_DG_optPre=[];Pres_optPre=[];PbattGFM_optPre=[];PbattEV_optPre=[];
            for ii=1:DG_GFM_num
                P_DG_optPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday;
            end
            for ii=1:BatteryGFM_Num
                PbattGFM_disPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday;
                PbattGFM_chPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday;
                PbattGFM_optPre(:,:,ii) = PbattGFM_disPre(:,:,ii) - PbattGFM_chPre(:,:,ii); 
            end
            for ii=1:BatteryNum
                Pbatt_disPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday;
                Pbatt_chPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday;
                Pbatt_optPre(:,:,ii) = Pbatt_disPre(:,:,ii) - Pbatt_chPre(:,:,ii); 
            end
            for ii=1:EVBatteryNum
                PbattEV_disPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday;
                PbattEV_chPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday;
                PbattEV_optPre(:,:,ii) = PbattEV_disPre(:,:,ii) - PbattEV_chPre(:,:,ii); 
                SOCrelaxPre(ii) = xpre(idx+1:idx+1);idx=idx+1;
            end
            for ii=1:SolarNum
                Pres_optPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday; 
            end
            for ii=1:Nload
                dPload_optPre(ii,:) = x(idx+1:idx+Kday);idx=idx+Kday; 
            end
        end

        if exitflag>0 || exitflag==-7
            idx=0;
            PbattGFM_dis=[];PbattGFM_ch=[];Pbatt_dis=[];Pbatt_ch=[];PbattEV_dis=[];PbattEV_ch=[];Pbatt_opt=[];P_DG_opt=[];Pres_opt=[];PbattGFM_opt=[];PbattEV_opt=[];
            for ii=1:DG_GFM_num
                P_DG_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
            end
            for ii=1:BatteryGFM_Num
                PbattGFM_dis(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
                PbattGFM_ch(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
                PbattGFM_opt(:,:,ii) = PbattGFM_dis(:,:,ii) - PbattGFM_ch(:,:,ii); 
            end
            for ii=1:BatteryNum
                Pbatt_dis(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
                Pbatt_ch(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
                Pbatt_opt(:,:,ii) = Pbatt_dis(:,:,ii) - Pbatt_ch(:,:,ii); 
            end
            for ii=1:EVBatteryNum
                PbattEV_dis(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
                PbattEV_ch(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
                PbattEV_opt(:,:,ii) = PbattEV_dis(:,:,ii) - PbattEV_ch(:,:,ii); 
                SOCrelax(ii,decisionStep) = x(idx+1:idx+1);idx=idx+1;
            end
            for ii=1:SolarNum
                Pres_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday; 
            end
            for ii=1:Nload
                dPload_opt(ii,:) = x(idx+1:idx+Kday);idx=idx+Kday; 
            end
            nr = numel(residential_node);
            nb = numel(business_node);
            
            dPload = zeros(BusNum,size(dPload_opt,2));
            dPload(residential_node,:) = dPload_opt(1:nr,:);
            dPload(business_node,:)    = dPload_opt(nr+1:nr+nb,:);
            dQload=dPload.*tan(PowAngle);
            xpre=x;
            infeFlag=1;
        else
            if isempty(P_DG_optPre)==0
            P_DG_opt=P_DG_optPre;P_DG_opt(1,:,:)=P_DG_optPre(infeFlag+1,:,:);
            end
            if isempty(PbattGFM_optPre)==0
            PbattGFM_opt=PbattGFM_optPre;PbattGFM_opt(1,:,:)=PbattGFM_optPre(infeFlag+1,:,:);
            end
            if isempty(Pbatt_optPre)==0
            Pbatt_opt=Pbatt_optPre;Pbatt_opt(1,:,:)=Pbatt_optPre(infeFlag+1,:,:);
            end
            if isempty(PbattEV_optPre)==0
            PbattEV_opt=PbattEV_optPre;PbattEV_opt(1,:,:)=PbattEV_optPre(infeFlag+1,:,:);
            end
            if isempty(Pres_optPre)==0
            Pres_opt=Pres_optPre;Pres_opt(1,:,:)=Pres_optPre(infeFlag+1,:,:);
            end
            if isempty(Pres_optPre)==0
            dPload_opt=dPload_optPre;dPload_opt(:,1)=dPload_optPre(:,infeFlag+1);
            end
            nr = numel(residential_node);
            nb = numel(business_node);
            
            dPload = zeros(BusNum,size(dPload_opt,2));
            dPload(residential_node,:) = dPload_opt(1:nr,:);
            dPload(business_node,:)    = dPload_opt(nr+1:nr+nb,:);
            infeFlag=infeFlag+1;
        end
        seeinfeFlag(decisionStep)=infeFlag;

        % The study enforces dt_mpc == dt_exec.  Therefore the execution
        % grid is identical to the MPC grid and UniversalCurve(...,'previous')
        % is an exact no-op.  Direct assignment removes repeated interpolation
        % overhead without changing any command value.
        P_DG_opt_Dec=P_DG_opt; Q_DG_opt_Dec=Q_DG_opt;
        PbattGFM_opt_Dec=[]; QbattGFM_opt_Dec=[];
        if BatteryGFM_Num>0
            PbattGFM_opt_Dec=PbattGFM_opt; QbattGFM_opt_Dec=QbattGFM_opt;
        end
        Pbatt_opt_Dec=[]; Qbatt_opt_Dec=[];
        if BatteryNum>0
            Pbatt_opt_Dec=Pbatt_opt; Qbatt_opt_Dec=Qbatt_opt;
        end
        PbattEV_opt_Dec=[];
        if EVBatteryNum>0, PbattEV_opt_Dec=PbattEV_opt; end
        Pres_opt_Dec=[]; Qres_opt_Dec=[];
        if SolarNum>0, Pres_opt_Dec=Pres_opt; Qres_opt_Dec=Qres_opt; end
        dPload_opt_Dec=dPload_opt;
        nr = numel(residential_node);
        nb = numel(business_node);
        dPload = zeros(BusNum,size(dPload_opt_Dec,2));
        dPload(residential_node,:) = dPload_opt_Dec(1:nr,:);
        dPload(business_node,:)    = dPload_opt_Dec(nr+1:nr+nb,:);
        dQload=dPload.*tan(PowAngle);
        execIdx=1;
 
        if false% output for debug
            figure
            legend_entries = cell(DG_GFM_num+BatteryNum+BatteryGFM_Num+EVBatteryNum+SolarNum, 1);
            hold on
            for ii=1:DG_GFM_num
                stairs(0:1:23, P_DG_opt(:,:,ii)','LineWidth',2);
                legend_entries{ii} = sprintf('$P_{DG%d}$', ii);
            end
            for ii=1:BatteryGFM_Num
                stairs(0:1:23, PbattGFM_opt(:,:,ii)','LineWidth',2);
                legend_entries{DG_GFM_num+ii} = sprintf('$P_{GFMbatt%d}$', ii);
            end
            for ii=1:BatteryNum
                stairs(0:1:23, Pbatt_opt(:,:,ii)','LineWidth',2);
                legend_entries{DG_GFM_num+BatteryGFM_Num+ii} = sprintf('$P_{batt%d}$', ii);
            end
            for ii=1:EVBatteryNum
                stairs(0:1:23, PbattEV_opt(:,:,ii)','LineWidth',2);
                legend_entries{DG_GFM_num+BatteryNum+BatteryGFM_Num+ii} = sprintf('$P_{EV%d}$', ii);
            end
            for ii=1:SolarNum
                stairs(0:1:23, Pres_opt(:,:,ii)','Color','m','LineWidth',2);
                legend_entries{DG_GFM_num+BatteryNum+BatteryGFM_Num+EVBatteryNum+ii} = sprintf('$P_{res%d}$', ii);
            end
            for ii=1:Nload
                stairs(0:1:23, dPload_opt(ii,:),'Color','m','LineWidth',2);
                legend_entries{DG_GFM_num+BatteryNum+BatteryGFM_Num+EVBatteryNum+SolarNum+ii} = sprintf('$P_{LdShed%d}$', ii);
            end
            hold off
            xlabel('t(h)','Interpreter','latex');
            ylabel('$MW$','Interpreter','latex');
            xlim([0,23])
            legend(legend_entries, 'Interpreter', 'latex','NumColumns',2)
            set(gca, 'FontName', 'Times New Roman', 'FontSize', fontsize);
            title(predictionStep)
            grid on
            box on
        end

        %-------------------------------
        if exist('decisionBlockTimer','var')
            decisionBlockTimeHistory(decisionStep)=toc(decisionBlockTimer);
        end
        predictionStep=predictionStep+1;
        decisionStep=decisionStep+1;
    elseif mod(RealStep-1,samplesPerDecision)==0 && predictionStep<=predictionHorizon
        execIdx=execIdx+1;
    end

    idx_ref=0;
    for ii=1:DG_GFM_num
        Ref(idx_ref+1,RealStep)=1;idx_ref=idx_ref+1;%Vset GFM
        Ref(idx_ref+1,RealStep)=P_DG_opt_Dec(execIdx,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%Qg1_bat set
    end

    for ii=1:BatteryGFM_Num
        Ref(idx_ref+1,RealStep)=1;idx_ref=idx_ref+1;%Vset GFM
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%dw_set GFM
        Ref(idx_ref+1,RealStep)=PbattGFM_opt_Dec(execIdx,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%Qg1_bat set
    end

    for ii=1:BatteryNum
        Ref(idx_ref+1,RealStep)=Pbatt_opt_Dec(execIdx,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%Qg1_bat set
        % Ref(idx+1,RealStep)=Q_V_control(Vs(BusOfBattery(ii)),Q_BattInvMax(BusOfBattery(ii)));idx=idx+1;%Qg1_bat set
    end

    for ii=1:EVBatteryNum
        Ref(idx_ref+1,RealStep)=PbattEV_opt_Dec(execIdx,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%Qg1_bat set
        % Ref(idx+1,RealStep)=Q_V_control(Vs(BusOfBattery(ii)),Q_BattInvMax(BusOfBattery(ii)));idx=idx+1;%Qg1_bat set
    end

    for ii=1:SolarNum
        % Ref(idx_ref+1,RealStep)=min(Pres_opt_Dec(decisionStep,1,ii),PV1_curve(BusOfPV(ii),RealStep));idx_ref=idx_ref+1;%Pg2_bat set
        Ref(idx_ref+1,RealStep)=min(Pres_opt_Dec(execIdx,1,ii),PV1_curve(BusOfPV(ii),RealStep));idx_ref=idx_ref+1;%Pg2_bat set
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%Qg2_bat set
    end


    if RealStep==1
        S_load_vec=Pload_true_box(:,RealStep)+1j*Qload_true_box(:,RealStep);
        [Vs, Vinv, Xbasic(:,RealStep),freq(:,RealStep),~]=InitializationProgram(P_DG_opt,PbattGFM_opt,Pbatt_opt,PbattEV_opt,DieselG_Pgfm_rate,Pload_true_box,Qload_true_box,PV1_curve,V_DC,Zs_DG,Xd_prime,Xm_g,Zmv_g,Y_Bus_dyn,SOC(:,RealStep),SOCmin,SOCmax,DGcontrolParams,SoCParams,phys,K_Pdp,K_Qdp,Rdroop,kQ_DG,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,BusNum,DG_GFM_num,BatteryGFM_Num,BatteryNum,EVBatteryNum,SolarNum,MainGFM,dt,Integrator);
        S_slack_ini=-sum(S_load_vec);
        meanfreq(:,RealStep)=compute_coi_frequency(freq(:,RealStep),DieselG_Pgfm_rate,phys.H);
        
        Niter=5;% suggest value >=
    else
        S_load_vec=Pload_true_box(:,RealStep)+1j*Qload_true_box(:,RealStep)+(dPload(:,execIdx)+1j*dQload(:,execIdx));
        S_slack_ini=S_busInjVec(1);
        
        Niter=3;% suggest value >=
    end

   

    [Xbasic(:,RealStep+1),Vs,Vinv,S_busInjVec,S_DG,S_inv_Batt,S_inv_PV,freq(:,RealStep+1),SOC(:,RealStep+1),fvalpf, exitflagpf,~]=MicrogridSys_ODEAE_expIterSolver(Xbasic(:,RealStep),Vs,Vinv,Ref(:,RealStep),S_load_vec,V_DC,Zs_DG,Xm_g,Zmv_g,Y_Bus_dyn,SOC(:,RealStep),SOCmin,SOCmax,DieselG_Pgfm_rate,DGcontrolParams,SoCParams,phys,K_Pdp,K_Qdp,Rdroop,kQ_DG,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,MainGFM,dt,Niter,Integrator);                                                                                                                                    
    [SOC(:,RealStep+1),socGuardMeta] = sanitize_soc_state( ...
        SOC(:,RealStep+1),SOCmin,SOCmax,socNumericalTol, ...
        sprintf('physical state after second %d',RealStep));
    socNumericalClipCount = socNumericalClipCount + socGuardMeta.clipCount;
    socNumericalClipMax = max(socNumericalClipMax,socGuardMeta.maxCorrection);
    pfExitflagHistory(RealStep)=exitflagpf;

    % record results and calculate costs
    VsBoxBasic(:,RealStep)=Vs;
    meanfreq(:,RealStep)=compute_coi_frequency(freq(:,RealStep+1),DieselG_Pgfm_rate,phys.H);
    dmeanfreq(:,RealStep)=compute_coi_frequency(freq(:,RealStep+1),DieselG_Pgfm_rate,phys.H)-f_rate;
    Pload_BoxBasic(:,RealStep)=real(S_load_vec([residential_node business_node],:));
    Qload_BoxBasic(:,RealStep)=imag(S_load_vec([residential_node business_node],:));

    Pload_resid=real(sum(S_load_vec(residential_node,1)));
    Pload_busi=real(sum(S_load_vec(business_node,1)));
    w_c_resid=Pload_resid/(Pload_resid+Pload_busi);
    w_c_busi=Pload_busi/(Pload_resid+Pload_busi);
    C_buy(1,RealStep)=C_buy_residential(1,RealStep)*w_c_resid+C_buy_business(1,RealStep)*w_c_busi;

    P_DG(:,RealStep)=real(S_DG(BusOfDieselG_GFM,1));
    P_res(:,RealStep)=real(S_inv_PV(BusOfPV,1));

    idx_ref=0;
    Pbatt(:,RealStep)=real(S_inv_Batt([BusOfBatteryGFM BusOfBattery BusOfEVBattery],1));
    Pbatt_dis=max(Pbatt(:,RealStep),0);% active power injected from the storage system
    Pbatt_ch=max(-Pbatt(:,RealStep),0);% active power consumed by the storage system
    
    V_from = Vs(Line(:,1));
    V_to   = Vs(Line(:,2));
    I_line(:,RealStep) = (V_from - V_to) ./ Impedance;
    Ploss(1,RealStep) = sum(abs(I_line(:,RealStep)).^2 .* real(Impedance));
    
    P_DG_GFM=sum(real(S_DG(BusOfDieselG_GFM,:)));
    P_Batt_GFM=sum(real(S_inv_Batt(BusOfBatteryGFM,:)));
    
    % Pbuy=max(real(S_busInjVec(BusOfSlack,:)),0);% total active power injected from the large system
    % Pbuy_forPowBalan=max(Pbuy-Ploss(1,RealStep),0);% additional power for load power balance
    % Psell=max(-real(S_busInjVec(BusOfSlack,:)),0);%active power consumed by the large system
    
    CostRecord(1,RealStep)=(C_dieselG*sum(P_DG(:,RealStep)) + C_deg*sum(Pbatt_ch+Pbatt_dis) + C_LdShd*sum(dPload(:,execIdx)))*dt*1000;% $; losses are already internalized by DG dispatch/SoC dynamics
    
    P_battVec_chr=min(Pbatt(:,RealStep),0);
    TotalLoad(1,RealStep)=real(sum(S_load_vec));
    % TotalConsume(1,RealStep)=real(sum(S_load_vec))+sum(P_battVec_chr)-Ploss(1,RealStep);
    TotalConsume(1,RealStep)=real(sum(S_load_vec))+sum(P_battVec_chr);% diagnostic consumption; network losses are represented by the physical power flow
    P_battVec_gen=max(Pbatt(:,RealStep),0);
    TotalGen(1,RealStep)=sum(P_battVec_gen)+real(sum(S_inv_PV))+P_DG_GFM;
    TotalGFM(1,RealStep)=P_DG_GFM+P_Batt_GFM;
    TotalBatt(1,RealStep)=sum(Pbatt(:,RealStep));
    TotalPV(1,RealStep)=real(sum(S_inv_PV(BusOfPV,1)));
end
timeCostMPC=toc(outter);
fprintf('MPC EMS daily decision time cost without grid model: %fs\n', sum(decisionTimeMPC_LPwithoutgridBox));
fprintf('MPC EMS daily simulation time cost without grid model: %fs\n', timeCostMPC);

Pload_true_boxPlt=Pload_true_box([residential_node business_node],:);
[totalCost]=EMS_results_display(Pload_BoxBasic,Qload_BoxBasic,Pload_true_boxPlt,P_DG,Pbatt,P_res,TotalLoad,TotalConsume,Ploss,TotalGen,TotalBatt,TotalPV,TotalGFM,CostRecord,VsBoxBasic,SOC,T_EVch1,T_EVch2,Xbasic,I_line,LineLimits,Vmin,Vmax,ResiUserNum+BusiUserNum,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,meanfreq,t_sim,ExportFigForPaper,brhID,cfg.output.showFigures);
disp(['Average frequency deviation:',num2str(sum(dmeanfreq)/length(dmeanfreq)),'Hz'])
disp(['Total cost for MPC LP: $',num2str(totalCost)])
disp(['Average value of one step decision time cost for MPC LP: ',num2str(mean(decisionTimeMPC_LPwithoutgridBox)),'s'])

fig_idx=6;
TotalLoadBox{fig_idx}=TotalLoad;
TotalGFMBox{fig_idx}=TotalGFM;
TotalBattBox{fig_idx}=TotalBatt;
TotalPVBox{fig_idx}=TotalPV;
SoC_BOX{fig_idx}=SOC;
Iline_magBox{fig_idx}=abs(I_line(brhID,:));
Vs_magBox{fig_idx}=abs(VsBoxBasic(busID,:));
freqBox{fig_idx}=meanfreq;
EcoCostBox{fig_idx}=totalCost;
DeciTimeCostBox{fig_idx}=mean(decisionTimeMPC_LPwithoutgridBox);

P_DG_opt_DecBox{fig_idx}=P_DG_opt_Dec;
P_DGBox{fig_idx}=P_DG;
end


if ismember(9,activateCase)


k_SoC=cfg.flexibility.evCurtailmentFactor; % commuting-aware EV curtailment bound
switch lower(runCfg.curtailmentMode)
    case 'none'
        bessRelaxFactor = 0;
        evRelaxFactor = 0;
    case 'bess'
        bessRelaxFactor = 1;
        evRelaxFactor = 0;
    case 'hierarchical'
        bessRelaxFactor = 1;
        evRelaxFactor = k_SoC;
    otherwise
        error('Unknown curtailmentMode: %s',runCfg.curtailmentMode);
end
meanfreq(:,1)=60;%Hz





predictionHorizon = predictionHorizonMPC;
controlHorizon=predictionHorizon;
useUpStream = 1;
lookAheadStep = 1;

Kday=predictionHorizon;
Nbranch=size(LineBFM,1);
offset = 2*Kday*BatteryNum + 2*Kday;

SOC_EV_base=zeros(numel(BusOfEVBattery),1);
infeFlag=1;

% ----- One-time/static MPC-SOCP preparation ------------------------------
% For radial cases, Aeq and every second-order cone are invariant across the
% 96 receding-horizon updates.  Cache/reuse them instead of rebuilding large
% dense matrices every 15 min.  This optimization applies to all MPC-SOCP
% methods using legacyCase=9, including T4/T6/T7/A0/G1/P1U/P1.
staticStructureTimer=tic;
loadBusList=[residential_node business_node];
staticCacheKey=sprintf('%s_K%d_DG%d_BG%d_B%d_EV%d_PV%d_L%d_PF%.6g', ...
    Topology,Kday,DG_GFM_num,BatteryGFM_Num,BatteryNum,EVBatteryNum,SolarNum,Nload,PF);
staticCacheKey=[staticCacheKey,sprintf('_DGR%.6g',DieselG_Pgfm_rate(:)), ...
    sprintf('_BGR%.6g',BatteryGFM_P_rate(:)),sprintf('_BR%.6g',BatteryGFL_P_rate(:)), ...
    sprintf('_PVR%.6g',PVInv_P_rate(:))];
staticCacheReused=false;
if cfg.performance.cacheStaticMPCSOCP
    mpcStatic=get_radial_mpc_static_cache(staticCacheKey,LineBFM,1,Kday, ...
        BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,loadBusList, ...
        DieselG_Pgfm_rateVec,BatteryGFM_P_rate,BatteryGFL_P_rate,PVInv_P_rate,PF);
    staticCacheReused=mpcStatic.reused;
else
    mpcStatic=[];
end
f_coneprog_static=build_mpc_objective_static(Kday,DG_GFM_num,BatteryGFM_Num,BatteryNum, ...
    EVBatteryNum,SolarNum,Nload,Nbranch,BusNum,C_dieselG,C_deg,C_BESSSoCshed, ...
    C_EVSoCshed,CsocRelax,C_PVCurt,C_LdShd,EbattMax,EbattMaxEV,dt_mpc);
[gridLB_static,gridUB_static]=build_mpc_grid_bounds_static(Kday,Nbranch,BusNum,Vmin,Vmax,k_brch,LineLimitsBFM);
staticStructureBuildTime=toc(staticStructureTimer);

reserveRatioHistory = nan(1,predictionHorizon);
reserveEvalTimeHistory = nan(1,predictionHorizon);
reserveFeatureHistory = nan(predictionHorizon,numel(reserve_feature_names()));
reserveMetaHistory = cell(1,predictionHorizon);

decisionStep=1;
predictionStep=1;

outter=tic;
for RealStep = 1:DayHours*samplePerHour
    
    if mod(RealStep-1,samplesPerDecision)==0 && predictionStep<=predictionHorizon
        
        decisionBlockTimer=tic;
        forecastTimer=tic;
        % Build the native HOURLY forecast anchors from the existing KRR
        % models, then resample those anchors onto the 15-min MPC grid. The
        % optimizer therefore sees 96 stages over 24 h, while the trained
        % forecasters remain unchanged.
        historyIdx=decisionStep:forecastStride:decisionStep+(lag-1)*forecastStride;
        S_PV_busBox=zeros(BusNum,forecastHorizon+lag);
        Sload_busBox=zeros(BusNum,forecastHorizon+lag);
        S_PV_busBox(:,1:lag)=P_PV1_curve_lag2day1h_trueMPC(:,historyIdx);
        Sload_busBox(:,1:lag)=Pload_true_box_lag2daySimstepMPC(:,historyIdx) + ...
            1j*Qload_true_box_lag2daySimstepMPC(:,historyIdx);

        iniPV_Seq=(real(S_PV_busBox(BusOfPV(1),1:lag))./PVInv_P_rate(BusOfPV(1),1))';
        if strcmp(dayType,'Usual day')
            Xi = zeros(size(iniPV_Seq,2),size(Pmat_curveDic,2));
            Xi(:,1)=1;
        else
            Xi = WeightDetermine(iniPV_Seq,Pmat_curveDic/max(TypicalDay),lag,beta,TypicalIdx);
        end

        P_PV_busBoxST=zeros(BusNum,forecastHorizon+lag);
        Pload_busBoxST=zeros(BusNum,forecastHorizon+lag);
        P_PV_anchor=zeros(BusNum,forecastHorizon+1);
        Sload_anchor=zeros(BusNum,forecastHorizon+1);
        for ii=1:forecastHorizon
            currentClock_h=(decisionStep-1)*dt_deci+(ii-1)*dt_pre;
            StdTime=mod(currentClock_h,24)/24;
            futureIdx=decisionStep+ii*forecastStride;

            % PV prediction on the native 1-h grid.
            P_PV_busBoxST(BusOfPV,ii:ii+lag-1)= ...
                real(S_PV_busBox(BusOfPV,ii:ii+lag-1))./PVInv_P_rate(BusOfPV,1);
            P_PV_busBoxST(BusOfPV,ii+lag)=max(SolarPredModel( ...
                P_PV_busBoxST(BusOfPV(1),ii:ii+lag-1),X_train_PV,Xi, ...
                best_sigmaBox_PV,sigmaTBox_PV,alpha_best_PV, ...
                P_PV1_curve_2day1h_trueMPC(BusOfPV(1),futureIdx)./PVInv_P_rate(BusOfPV(1),1), ...
                ii,useUpStream,lookAheadStep,StdTime,TypicalIdx),0);
            S_PV_busBox(BusOfPV,ii+lag)= ...
                (P_PV_busBoxST(BusOfPV,ii+lag)+1j*0).*PVInv_P_rate(BusOfPV,1);
            P_PV_anchor(:,ii)=S_PV_busBox(:,ii+lag-1);

            % Load prediction on the native 1-h grid.
            Pload_busBoxST(residential_node,ii:ii+lag-1)= ...
                real(Sload_busBox(residential_node,ii:ii+lag-1))./P_st(residential_node,1);
            Pload_busBoxST(residential_node,ii+lag)=LoadPredModel( ...
                Pload_busBoxST(residential_node(1),ii:ii+lag-1), ...
                X_train_residential,sigma_resid,sigmaT_resid,alpha_best_residential,StdTime);
            Sload_busBox(residential_node,ii+lag)= ...
                Pload_busBoxST(residential_node,ii+lag).*P_st(residential_node,1);

            Pload_busBoxST(business_node,ii:ii+lag-1)= ...
                real(Sload_busBox(business_node,ii:ii+lag-1))./P_st(business_node,1);
            Pload_busBoxST(business_node,ii+lag)=LoadPredModel( ...
                Pload_busBoxST(business_node(1),ii:ii+lag-1), ...
                X_train_largeOffice,sigma_busi,sigmaT_busi,alpha_best_largeOffice,StdTime);
            Sload_busBox(business_node,ii+lag)= ...
                Pload_busBoxST(business_node,ii+lag).*P_st(business_node,1);
            Sload_anchor(:,ii)=Sload_busBox(:,ii+lag-1);
        end

        % Include the terminal +24-h anchor so interpolation to 23.75 h does
        % not require extrapolation.
        P_PV_anchor(:,forecastHorizon+1)=S_PV_busBox(:,forecastHorizon+lag);
        Sload_anchor(:,forecastHorizon+1)=Sload_busBox(:,forecastHorizon+lag);
        P_PV=resample_horizon_anchors(P_PV_anchor,dt_pre,dt_mpc, ...
            cfg.mpc.horizon_h,cfg.forecast.interpolationMethod);
        P_PV=max(P_PV,0);
        Sload=resample_horizon_anchors(Sload_anchor,dt_pre,dt_mpc, ...
            cfg.mpc.horizon_h,cfg.forecast.interpolationMethod);
        % FINAL_MPC_INPUT_INTERVAL_AVERAGE_BEGIN
        % Represent each 15-min MPC stage by the adjacent-point average
        % of its PREDICTIVE load/PV samples. Physical 1-s true curves
        % Pload_true_box and PV1_curve are intentionally unchanged.
        if isfield(cfg.forecast,'useMPCIntervalAverage') && ...
                cfg.forecast.useMPCIntervalAverage
            if size(Sload,2)>=2
                Sload=[0.5*(Sload(:,1:end-1)+Sload(:,2:end)) Sload(:,end)];
            end
            if size(P_PV,2)>=2
                P_PV=[0.5*(P_PV(:,1:end-1)+P_PV(:,2:end)) P_PV(:,end)];
            end
        end
        % FINAL_MPC_INPUT_INTERVAL_AVERAGE_END
        S_PV=P_PV;
        forecastBuildTimeHistory(predictionStep)=toc(forecastTimer);

        % ----- Operating-state-dependent reserve policy -------------------------
        % Formal AI input contract (three causal first-principles features):
        %   [Pnet_now, |Delta Pnet|, measured SG upward headroom].
        % The SG headroom must be known BEFORE solving the current MPC.  Use
        % the last realized physical SG output, never the newly optimized
        % dispatch.  At the first decision there is no prior physical sample;
        % headroom is left NaN so AI mode transparently falls back to alpha=1.
        totalDGPrate_MW = max(sum(DieselG_Pgfm_rate(:)),eps);
        if RealStep>1 && ~isempty(P_DG) && size(P_DG,2)>=RealStep-1 && ...
                all(isfinite(P_DG(:,RealStep-1)))
            measuredDG_MW = sum(real(P_DG(:,RealStep-1)));
            dgUpHeadroom_pu = (totalDGPrate_MW-measuredDG_MW)/totalDGPrate_MW;
            dgUpHeadroom_pu = min(max(dgUpHeadroom_pu,0),1);
        else
            dgUpHeadroom_pu = NaN;
        end
        [reserveFeature,reserveFeatureMeta] = build_reserve_features(Sload,P_PV, ...
            DieselG_Pgfm_rate,dgUpHeadroom_pu);
        reserveFeatureHistory(predictionStep,:) = reserveFeature;
        % Offline response-data generation may prescribe a different reserve
        % ratio at every 15-min closed-loop update. The selected ratio still
        % applies to the full prediction horizon of THIS MPC solve, exactly
        % like the online AI policy; only the next implemented action is used.
        reserveRatioRequest = runCfg.reserveFixedRatio;
        if strcmpi(runCfg.reserveMode,'scheduled')
            if ~isfield(runCfg,'reserveAlphaSchedule') || ...
                    numel(runCfg.reserveAlphaSchedule)<predictionStep
                error('Scheduled reserve mode requires one alpha per MPC update.');
            end
            reserveRatioRequest = runCfg.reserveAlphaSchedule(predictionStep);
        end
        % P1_FORECAST_SAFETY_GUARD_FINAL
        % Forecast-only directional quantities are passed through aiCfgStep.
        % They are available before the current MPC solve and are NOT added
        % to the frozen three-feature KRR input vector.
        aiCfgStep = aiCfgRun;
        aiCfgStep.forecastNetLoadNow_pu = reserveFeatureMeta.netLoadNow_pu;
        aiCfgStep.forecastSignedNetRamp_pu = reserveFeatureMeta.signedNetRampForecast_pu;
        aiCfgStep.forecastNetDrop_pu = reserveFeatureMeta.netDropForecast_pu;
        reserveTimer=tic;
        [dP_RESVdown,dP_RESVup,reserveMeta] = compute_frequency_reserve_pu( ...
            runCfg.reserveMode, reserveRatioRequest, Rdroop, phys.H, ...
            df_reserve_Hz, rocof_limit_Hz_s, f_rate, aiModel, reserveFeature, ...
            P_DGmin, P_DGmax, aiCfgStep);
        reserveEvalTimeHistory(predictionStep)=toc(reserveTimer);
        reserveRatioHistory(predictionStep) = reserveMeta.alpha;
        reserveMetaHistory{predictionStep} = reserveMeta;

        assemblyTimer=tic;
        %% --- Energy Management System  ---
        % Decision variables: 

        % x=[(...,Pdg[1->24],...|...,Qdg[1->24],...),(...,Pdis_i[k=1->24],Pch_i[1->24],...|...,Q_i[k=1->24],...,dSoC),(...,PEVdis[1->24],PEVch[1->24],dSOC_relax,dSoC,...),(...,PresMax[1->24],...|...,QresMax[1->24],...),(...,Pload(residential,business)[1->24],...),(...,P_br[k]\in Gird,Q_br[k]\in Gird,~l_br[k]\in Gird,~v_bus[k]\in Gird,...)k=1~24]' decision variable format


        % Objective coefficients are time-invariant for the revised model and
        % were assembled once before the receding-horizon loop.
        f_coneprog=f_coneprog_static;

        % =====inequality constraints======
        lb=[];
        ub=[];

        % ----box constraints-----
        % l
        DG_GFM_lbBox=[];
        for ii=1:DG_GFM_num
            DG_GFM_lbBox=[DG_GFM_lbBox (P_DGmin+dP_RESVdown(ii))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(ii),1)*ones(1,Kday) -(P_DGmin+dP_RESVdown(ii))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(ii),1)*ones(1,Kday)];
        end
        
        battGFM_lbBox=[];
        for ii=1:BatteryGFM_Num
            battGFM_lbBox=[battGFM_lbBox 0*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)/PF 0*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)/PF -(P_gfmIBRmax-dP_RESVup(ii))*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)/PF];
        end
        
        batt_lbBox=[];
        for ii=1:BatteryNum
            batt_lbBox=[batt_lbBox 0*BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)/PF 0*BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)/PF -BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)/PF 0];
        end
        
        EVbatt_lbBox=[];
        for ii=1:EVBatteryNum
            EVbatt_lbBox=[EVbatt_lbBox 0*BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday)/PF 0*BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday)/PF 0 0];
        end
        
        resMax_lbBox=[];
        for ii=1:SolarNum
            resMax_lbBox=[resMax_lbBox 0*ones(1,Kday)/PF -PVInv_P_rate(BusOfPV(ii),:)*ones(1,Kday)/PF];
        end
        
        loadShed_lbBox=[];
        for ii=[residential_node business_node]
            loadShed_lbBox=[loadShed_lbBox 0*real(Sload(ii,:))];
        end
        
        lb=[DG_GFM_lbBox...
            battGFM_lbBox...
            batt_lbBox...
            EVbatt_lbBox...
            resMax_lbBox...
            loadShed_lbBox...
            ]';
        
        lb=[lb;gridLB_static];
        
        % u
        DG_GFM_ubBox=[];
        for ii=1:DG_GFM_num
            DG_GFM_ubBox=[DG_GFM_ubBox (P_DGmax-dP_RESVup(ii))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(ii),1)*ones(1,Kday) (P_DGmax-dP_RESVup(ii))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(ii),1)*ones(1,Kday)];
        end
        
        battGFM_ubBox=[];
        for ii=1:BatteryGFM_Num
            battGFM_ubBox=[battGFM_ubBox (P_gfmIBRmax-dP_RESVup(ii))*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)/PF (P_gfmIBRmax-dP_RESVup(ii))*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)/PF (P_gfmIBRmax-dP_RESVup(ii))*BatteryGFM_P_rate(BusOfBatteryGFM(ii),1)*ones(1,Kday)/PF];
        end
        
        batt_ubBox=[];
        for ii=1:BatteryNum
            batt_ubBox=[batt_ubBox BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)/PF BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)/PF BatteryGFL_P_rate(BusOfBattery(ii),1)*ones(1,Kday)/PF bessRelaxFactor*(SOC_GFL(ii,1)-SOCmin)];
        end
        
        EVbatt_ubBox=[];
        for ii=1:EVBatteryNum
            EVbatt_ubBox=[EVbatt_ubBox 0*BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday)/PF BatteryEV_P_rate(BusOfEVBattery(ii),1)*ones(1,Kday).*EVactiDisFun_mpc(predictionStep:predictionStep+predictionHorizon-1)/PF SOCrelaxGap evRelaxFactor*(SOCmax-dSOC_EVcsp(ii,1)-SOCmin)];
        end
        
        resMax_ubBox=[];
        for ii=1:SolarNum
            resMax_ubBox=[resMax_ubBox P_PV(BusOfPV(ii),:)/PF PVInv_P_rate(BusOfPV(ii),:)*ones(1,Kday)/PF];
        end
        
        loadShed_ubBox=[];
        for ii=[residential_node business_node]
            loadShed_ubBox=[loadShed_ubBox k_LdShd*abs(real(Sload(ii,:)))];
        end
        
        ub=[DG_GFM_ubBox...
            battGFM_ubBox...
            batt_ubBox...
            EVbatt_ubBox...
            resMax_ubBox...
            loadShed_ubBox...
            ]';
        
        ub=[ub;gridUB_static];

        % ----linear inequality constraints----
        A=[];
        b=[];

        % SOC
        % Sanitize the realized state before it becomes the initial state of
        % the next MPC. Only numerical boundary overshoots <=1e-4 are clipped.
        [SOC(:,RealStep),socGuardMeta] = sanitize_soc_state( ...
            SOC(:,RealStep),SOCmin,SOCmax,socNumericalTol, ...
            sprintf('MPC initial state at step %d',predictionStep));
        socNumericalClipCount = socNumericalClipCount + socGuardMeta.clipCount;
        socNumericalClipMax = max(socNumericalClipMax,socGuardMeta.maxCorrection);

        if cfg.performance.useSparseSOCConstraints
            [Aineq_SOC,bineq_SOC]=build_soc_constraints_sparse_mpc( ...
                Kday,SOCmax,SOCmin,SOC(:,RealStep),EbattMaxGFM,EbattMax,EbattMaxEV, ...
                inta_batt_ch,inta_batt_dis,DG_GFM_num,BatteryGFM_Num,BatteryNum, ...
                EVBatteryNum,SolarNum,Nload,Nbranch,BusNum,dt_mpc,predictionStep,SOC(:,1));
        else
            [Aineq_SOC,bineq_SOC]=SOC_InequalityConstraints_withEVenShedding_MPC( ...
                Kday,SOCmax,SOCmin,SOC(:,RealStep),EbattMaxGFM,EbattMax,EbattMaxEV, ...
                inta_batt_ch,inta_batt_dis,DG_GFM_num,BatteryGFM_Num,BatteryNum,EVBatteryNum, ...
                SolarNum,Nload,Nbranch,BusNum,dt_mpc,predictionStep,SOC(:,1));
            Aineq_SOC=sparse(Aineq_SOC);
        end
        A=Aineq_SOC;
        b=bineq_SOC;

        % Frequency awareness is enforced only through the explicit DG reserve box
% constraints above; disabled legacy Pref-step/nadir surrogates were removed.

% eq / cone structure
        V_slack=1;
        if cfg.performance.cacheStaticMPCSOCP
            Aeq=mpcStatic.Aeq;
            beq=update_radial_mpc_beq(mpcStatic,Sload);
            socConstraints=mpcStatic.socConstraints;
            Asc_ass_cell=mpcStatic.Asc;
            bsc_ass_cell=mpcStatic.bsc;
            dsc_ass_cell=mpcStatic.dsc;
            gamma_ass_cell=mpcStatic.gamma;
        else
            [Aeq,beq]=LinearEqualityConstBFS_SOCP_powerbalance_island_withES_MPC( ...
                LineBFM,V_slack,Kday,Sload,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery, ...
                BusOfEVBattery,BusOfPV,[residential_node business_node]);
            Aeq=sparse(Aeq);
            [Asc_ass_cell1,bsc_ass_cell1,dsc_ass_cell1,gamma_ass_cell1]= ...
                ConeConstraintsForBFS_SOCP_island_withEVenShedding_MPC( ...
                LineBFM,V_slack,Kday,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery, ...
                BusOfEVBattery,BusOfPV,Nload);
            [Asc_ass_cell2,bsc_ass_cell2,dsc_ass_cell2,gamma_ass_cell2]= ...
                ConeConstraintsForDGcapacity_island_withEVenShedding_MPC( ...
                DieselG_Pgfm_rateVec/PF,BatteryGFM_P_rate/PF,BatteryGFL_P_rate/PF,PVInv_P_rate/PF, ...
                LineBFM,Kday,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,Nload);
            Asc_ass_cell=[Asc_ass_cell1;Asc_ass_cell2];
            bsc_ass_cell=[bsc_ass_cell1;bsc_ass_cell2];
            dsc_ass_cell=[dsc_ass_cell1;dsc_ass_cell2];
            gamma_ass_cell=[gamma_ass_cell1;gamma_ass_cell2];
            socConstraints=optim.coneprog.SecondOrderConeConstraint.empty;
            for kk=1:numel(Asc_ass_cell)
                Asc_ass_cell{kk}=sparse(Asc_ass_cell{kk});
                dsc_ass_cell{kk}=sparse(dsc_ass_cell{kk});
                socConstraints(end+1)=secondordercone(Asc_ass_cell{kk},bsc_ass_cell{kk},dsc_ass_cell{kk},gamma_ass_cell{kk}); %#ok<AGROW>
            end
        end

        dynamicAssemblyTimeHistory(predictionStep)=toc(assemblyTimer);

        % Primary sparse SOCP solve.  If an exitflag=-7 solution has a
        % materially poor dual residual, retry only that step with a second
        % linear-system formulation.  No feasibility/optimality tolerance is
        % relaxed and the numerically better candidate is retained.
        primaryTimer=tic;
        [xPrimary,fPrimary,flagPrimary,outPrimary]=coneprog( ...
            f_coneprog,socConstraints,A,b,Aeq,beq,lb,ub,coneOptions);
        primaryTime=toc(primaryTimer);
        x=xPrimary; fval=fPrimary; exitflag=flagPrimary; output=outPrimary;
        retryUsed=false; retryTime=0; retryFlag=NaN; retryDual=NaN;
        primaryDual=NaN;
        if isstruct(outPrimary) && isfield(outPrimary,'dualfeasibility') && ...
                ~isempty(outPrimary.dualfeasibility)
            primaryDual=outPrimary.dualfeasibility(1);
        end
        if ~isempty(coneOptionsRetry) && flagPrimary==-7 && isfinite(primaryDual) && ...
                primaryDual>cfg.solver.retryDualThreshold
            retryUsed=true;
            retryTimer=tic;
            [xRetry,fRetry,flagRetry,outRetry]=coneprog( ...
                f_coneprog,socConstraints,A,b,Aeq,beq,lb,ub,coneOptionsRetry);
            retryTime=toc(retryTimer);
            retryFlag=flagRetry;
            if isstruct(outRetry) && isfield(outRetry,'dualfeasibility') && ~isempty(outRetry.dualfeasibility)
                retryDual=outRetry.dualfeasibility(1);
            end
            if choose_coneprog_candidate(xPrimary,flagPrimary,outPrimary,xRetry,flagRetry,outRetry)
                x=xRetry; fval=fRetry; exitflag=flagRetry; output=outRetry;
            end
        end
        decisionTimeMPC_withgridBox(decisionStep)=primaryTime+retryTime;

        progressOn = isfield(cfg.diagnostics,'progress') && cfg.diagnostics.progress.enabled;
        progressEvery = max(1,cfg.diagnostics.progress.everyN);
        if progressOn && (mod(decisionStep-1,progressEvery)==0 || decisionStep==DecisionLevelSteps)
            fprintf('[MPC %02d/%02d] exitflag=%d | solve %.2f s', ...
                decisionStep,DecisionLevelSteps,exitflag,decisionTimeMPC_withgridBox(decisionStep));
            if retryUsed
                fprintf(' | retry %s: flag %d, dual %.3e -> %.3e', ...
                    cfg.solver.retryLinearSolver,retryFlag,primaryDual,retryDual);
            end
        end

        % Manual reconstruction of all cone residuals can itself be costly.
        % Record coneprog's native diagnostics for every step, but perform the
        % expensive independent residual audit only for the first few -7 exits.
        maxManual = cfg.diagnostics.solver.manualResidualMaxWarningSteps;
        computeManual = (exitflag==-7) && (manualResidualWarningCount < maxManual);
        if computeManual, manualResidualWarningCount=manualResidualWarningCount+1; end
        diagTimer=tic;
        diagRec=collect_coneprog_diagnostic( ...
            output,exitflag,predictionStep,decisionTimeMPC_withgridBox(decisionStep), ...
            x,A,b,Aeq,beq,lb,ub,Asc_ass_cell,bsc_ass_cell,dsc_ass_cell,gamma_ass_cell,computeManual);
        diagRec.diagnosticTime_s=toc(diagTimer);
        diagRec.retryUsed=retryUsed;
        diagRec.primaryExitflag=flagPrimary;
        diagRec.primaryDualFeasibility=primaryDual;
        diagRec.retryExitflag=retryFlag;
        diagRec.retryDualFeasibility=retryDual;
        if isstruct(output) && isfield(output,'linearsolver')
            diagRec.selectedLinearSolver=string(output.linearsolver);
        else
            diagRec.selectedLinearSolver="";
        end
        solverDiagnosticHistory{predictionStep}=diagRec;
        if progressOn && (mod(decisionStep-1,progressEvery)==0 || decisionStep==DecisionLevelSteps)
            if computeManual
                fprintf(' | manual diag %.2f s | residual %.3e', ...
                    diagRec.diagnosticTime_s,diagRec.maxManualConstraintViolation);
            end
            fprintf('\n');
        end

        % ---------------------------------------------------------------
        % Optional exact-state reserve-feasibility probe for diagnostic tests.
        % Disabled in normal simulations.  When enabled, the current MPC
        % problem is re-solved at the SAME physical/MPC state with several
        % fixed reserve ratios.  Only reserve-dependent DG/GFM box bounds are
        % changed; forecasts, SoC state, network constraints, objective, and
        % all other constraints remain identical.  This identifies whether a
        % hard failure can be removed by backing off the AI-requested reserve,
        % or whether the state is infeasible even at the online lower bound.
        probeEnabled=false;
        if isfield(cfg,'diagnostics') && isfield(cfg.diagnostics,'feasibilityProbe') && ...
                isfield(cfg.diagnostics.feasibilityProbe,'enabled')
            probeEnabled=logical(cfg.diagnostics.feasibilityProbe.enabled);
        end
        if probeEnabled
            pCfg=cfg.diagnostics.feasibilityProbe;
            targetProbeStep=65;
            if isfield(pCfg,'targetStep') && ~isempty(pCfg.targetStep)
                targetProbeStep=round(pCfg.targetStep);
            end
            if predictionStep==targetProbeStep
                probeAlphaGrid=[1.0 0.9 0.8 0.7 0.6];
                if isfield(pCfg,'alphaGrid') && ~isempty(pCfg.alphaGrid)
                    probeAlphaGrid=double(pCfg.alphaGrid(:).');
                end
                probeAlphaGrid=unique(probeAlphaGrid,'stable');
                probeAlphaGrid=probeAlphaGrid(isfinite(probeAlphaGrid) & probeAlphaGrid>=0);
                nProbe=numel(probeAlphaGrid);
                probeAlpha=nan(nProbe,1); probeUsable=false(nProbe,1);
                probeFlag=nan(nProbe,1); probeTime=nan(nProbe,1); probeObj=nan(nProbe,1);
                probePrimal=nan(nProbe,1); probeDual=nan(nProbe,1); probeGap=nan(nProbe,1);
                probeManual=nan(nProbe,1); probeRetry=false(nProbe,1);
                probeLB=cell(nProbe,1); probeUB=cell(nProbe,1);

                fprintf('\n[feasibility probe] exact MPC state at step %d (t=%.2f h), AI-selected alpha %.3f\n', ...
                    predictionStep,(predictionStep-1)*dt_mpc,reserveMeta.alpha);
                fprintf('[feasibility probe] re-solving identical state for alpha = %s\n', ...
                    mat2str(probeAlphaGrid,3));

                for ip=1:nProbe
                    aProbe=probeAlphaGrid(ip);
                    probeAlpha(ip)=aProbe;
                    [dDownProbe,dUpProbe,~]=compute_frequency_reserve_pu( ...
                        'fixed',aProbe,Rdroop,phys.H,df_reserve_Hz,rocof_limit_Hz_s, ...
                        f_rate,[],[],P_DGmin,P_DGmax,aiCfgRun);

                    % Rebuild ONLY alpha-dependent DG/GFM bounds.  All other
                    % current-state bounds and constraints are reused exactly.
                    DG_lb_probe=[];
                    for jj=1:DG_GFM_num
                        DG_lb_probe=[DG_lb_probe ...
                            (P_DGmin+dDownProbe(jj))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(jj),1)*ones(1,Kday) ...
                            -(P_DGmin+dDownProbe(jj))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(jj),1)*ones(1,Kday)]; %#ok<AGROW>
                    end
                    battGFM_lb_probe=[];
                    for jj=1:BatteryGFM_Num
                        battGFM_lb_probe=[battGFM_lb_probe ...
                            0*BatteryGFM_P_rate(BusOfBatteryGFM(jj),1)*ones(1,Kday)/PF ...
                            0*BatteryGFM_P_rate(BusOfBatteryGFM(jj),1)*ones(1,Kday)/PF ...
                            -(P_gfmIBRmax-dUpProbe(jj))*BatteryGFM_P_rate(BusOfBatteryGFM(jj),1)*ones(1,Kday)/PF]; %#ok<AGROW>
                    end
                    lbProbe=[DG_lb_probe battGFM_lb_probe batt_lbBox EVbatt_lbBox ...
                        resMax_lbBox loadShed_lbBox]';
                    lbProbe=[lbProbe;gridLB_static];

                    DG_ub_probe=[];
                    for jj=1:DG_GFM_num
                        DG_ub_probe=[DG_ub_probe ...
                            (P_DGmax-dUpProbe(jj))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(jj),1)*ones(1,Kday) ...
                            (P_DGmax-dUpProbe(jj))*DieselG_Pgfm_rateVec(BusOfDieselG_GFM(jj),1)*ones(1,Kday)]; %#ok<AGROW>
                    end
                    battGFM_ub_probe=[];
                    for jj=1:BatteryGFM_Num
                        battGFM_ub_probe=[battGFM_ub_probe ...
                            (P_gfmIBRmax-dUpProbe(jj))*BatteryGFM_P_rate(BusOfBatteryGFM(jj),1)*ones(1,Kday)/PF ...
                            (P_gfmIBRmax-dUpProbe(jj))*BatteryGFM_P_rate(BusOfBatteryGFM(jj),1)*ones(1,Kday)/PF ...
                            (P_gfmIBRmax-dUpProbe(jj))*BatteryGFM_P_rate(BusOfBatteryGFM(jj),1)*ones(1,Kday)/PF]; %#ok<AGROW>
                    end
                    ubProbe=[DG_ub_probe battGFM_ub_probe batt_ubBox EVbatt_ubBox ...
                        resMax_ubBox loadShed_ubBox]';
                    ubProbe=[ubProbe;gridUB_static];
                    probeLB{ip}=lbProbe; probeUB{ip}=ubProbe;

                    tProbe=tic;
                    [xP,fP,flagP,outP]=coneprog(f_coneprog,socConstraints,A,b,Aeq,beq,lbProbe,ubProbe,coneOptions);
                    tP=toc(tProbe);
                    retriedP=false;
                    dualP=NaN;
                    if isstruct(outP) && isfield(outP,'dualfeasibility') && ~isempty(outP.dualfeasibility)
                        dualP=outP.dualfeasibility(1);
                    end
                    if ~isempty(coneOptionsRetry) && flagP==-7 && isfinite(dualP) && ...
                            dualP>cfg.solver.retryDualThreshold
                        retriedP=true;
                        tRetryP=tic;
                        [xPR,fPR,flagPR,outPR]=coneprog(f_coneprog,socConstraints,A,b,Aeq,beq,lbProbe,ubProbe,coneOptionsRetry);
                        tP=tP+toc(tRetryP);
                        if choose_coneprog_candidate(xP,flagP,outP,xPR,flagPR,outPR)
                            xP=xPR; fP=fPR; flagP=flagPR; outP=outPR;
                        end
                    end
                    dP=collect_coneprog_diagnostic(outP,flagP,predictionStep,tP, ...
                        xP,A,b,Aeq,beq,lbProbe,ubProbe,Asc_ass_cell,bsc_ass_cell,dsc_ass_cell,gamma_ass_cell,true);
                    usableP=~isempty(xP) && all(isfinite(xP(:))) && ...
                        (flagP>0 || flagP==-7) && ...
                        (isnan(dP.maxManualConstraintViolation) || dP.maxManualConstraintViolation<=1e-6);
                    probeUsable(ip)=usableP;
                    % coneprog returns an empty objective value when the probe
                    % problem is infeasible (e.g., exitflag=-2).  Keep the
                    % feasibility spectrum table well-defined by recording NaN
                    % rather than assigning [] into a scalar table slot.
                    flagScalar=NaN;
                    if ~isempty(flagP) && isnumeric(flagP), flagScalar=double(flagP(1)); end
                    objScalar=NaN;
                    if ~isempty(fP) && isnumeric(fP) && isfinite(fP(1)), objScalar=double(fP(1)); end
                    timeScalar=NaN;
                    if ~isempty(tP) && isnumeric(tP) && isfinite(tP(1)), timeScalar=double(tP(1)); end
                    probeFlag(ip)=flagScalar; probeTime(ip)=timeScalar; probeObj(ip)=objScalar;
                    probePrimal(ip)=dP.primalFeasibility; probeDual(ip)=dP.dualFeasibility;
                    probeGap(ip)=dP.relativeGap; probeManual(ip)=dP.maxManualConstraintViolation;
                    probeRetry(ip)=retriedP;
                    fprintf('  alpha %.2f -> usable=%d | flag=%d | %.2f s | primal %.2e | dual %.2e | residual %.2e\n', ...
                        aProbe,usableP,flagP,tP,dP.primalFeasibility,dP.dualFeasibility,dP.maxManualConstraintViolation);
                end

                probeTable=table(probeAlpha,probeUsable,probeFlag,probeTime,probeObj, ...
                    probePrimal,probeDual,probeGap,probeManual,probeRetry, ...
                    'VariableNames',{'Alpha','Usable','Exitflag','SolveTime_s','Objective', ...
                    'PrimalFeasibility','DualFeasibility','RelativeGap','ManualResidual','RetryUsed'});

                % -----------------------------------------------------------
                % Optional terminal-constraint family ablation at the exact
                % frozen state.  Diagnostic only; disabled in normal runs.
                % It removes selected SoC rows WITHOUT changing the current
                % physical state, forecasts, objective, network constraints,
                % or cone constraints.  This identifies whether recursive
                % infeasibility is caused by hidden rolling-horizon terminal
                % rows rather than the reserve ratio itself.
                terminalAblationTable=table();
                termEnabled=false;
                if isfield(pCfg,'terminalConstraintAblation') && ...
                        ~isempty(pCfg.terminalConstraintAblation)
                    termEnabled=logical(pCfg.terminalConstraintAblation);
                end
                if termEnabled
                    termAlphaGrid=[1.0 0.6];
                    if isfield(pCfg,'terminalAlphaGrid') && ~isempty(pCfg.terminalAlphaGrid)
                        termAlphaGrid=double(pCfg.terminalAlphaGrid(:).');
                    end
                    termAlphaGrid=unique(termAlphaGrid,'stable');
                    termAlphaGrid=termAlphaGrid(isfinite(termAlphaGrid));

                    termVariants=[ ...
                        "BASELINE"; ...
                        "RELAX_FIRST_BESS_SOCMAX_1E4"; ...
                        "DROP_BESS1_HORIZON_END"; ...
                        "DROP_ALL_BESS_HORIZON_END"; ...
                        "DROP_ALL_EV_HORIZON_END"; ...
                        "DROP_ALL_STORAGE_HORIZON_END"; ...
                        "DROP_BESS_DAILY_TARGET"; ...
                        "DROP_EV_DAILY_TARGET" ...
                        ];

                    nBessAll=BatteryGFM_Num+BatteryNum;
                    nStorageRows=2*Kday*(nBessAll+EVBatteryNum);
                    if size(A,1)<nStorageRows
                        error('IslandEMS:TerminalProbeRows', ...
                            'Linear inequality matrix has %d rows but at least %d SoC rows are expected.', ...
                            size(A,1),nStorageRows);
                    end
                    % Daily-boundary row inside the rolling 24-h horizon.
                    % This must use the same definition as
                    % build_soc_constraints_sparse_mpc(): index = Kday-step+1.
                    % The probe runs inside engine_island_ems, where the current
                    % MPC step is predictionStep; the builder-local variable
                    % `index` is therefore not visible here.
                    terminalIndex=Kday-predictionStep+1;
                    if terminalIndex<1 || terminalIndex>Kday
                        error('IslandEMS:TerminalProbeIndex', ...
                            'Computed terminal daily-boundary index %d is outside [1,%d] at MPC step %d.', ...
                            terminalIndex,Kday,predictionStep);
                    end
                    bessEndRows=2*Kday*(1:nBessAll);
                    bessDailyRows=(0:nBessAll-1)*2*Kday + Kday + terminalIndex;
                    evEndRows=[]; evDailyRows=[];
                    for jj=1:EVBatteryNum
                        r0=2*Kday*(nBessAll+jj-1);
                        evEndRows=[evEndRows r0+Kday r0+2*Kday]; %#ok<AGROW>
                        evDailyRows=[evDailyRows r0+terminalIndex r0+Kday+terminalIndex]; %#ok<AGROW>
                    end
                    firstBessUpperRows=[];
                    if nBessAll>0, firstBessUpperRows=1:Kday; end
                    firstBessEndRow=[];
                    if nBessAll>0, firstBessEndRow=2*Kday; end

                    nRowsTerm=numel(termVariants)*numel(termAlphaGrid);
                    tv=repmat("",nRowsTerm,1); ta=nan(nRowsTerm,1);
                    tu=false(nRowsTerm,1); tf=nan(nRowsTerm,1); tt=nan(nRowsTerm,1);
                    tp=nan(nRowsTerm,1); td=nan(nRowsTerm,1); tg=nan(nRowsTerm,1); tm=nan(nRowsTerm,1);
                    tr=false(nRowsTerm,1); removedCount=zeros(nRowsTerm,1);
                    rr=0;
                    fprintf('\n[terminal-constraint probe] exact step-%d state; selective SoC-row ablation\n',predictionStep);
                    for ia=1:numel(termAlphaGrid)
                        aTerm=termAlphaGrid(ia);
                        [~,ipUse]=min(abs(probeAlphaGrid-aTerm));
                        if isempty(ipUse) || abs(probeAlphaGrid(ipUse)-aTerm)>1e-9
                            error('IslandEMS:TerminalProbeAlpha', ...
                                'terminalAlphaGrid value %.3f must also be included in feasibilityProbe.alphaGrid.',aTerm);
                        end
                        lbTerm=probeLB{ipUse}; ubTerm=probeUB{ipUse};
                        for iv=1:numel(termVariants)
                            rr=rr+1;
                            variant=termVariants(iv);
                            keep=true(size(A,1),1); bVar=b;
                            switch variant
                                case "BASELINE"
                                    % no change
                                case "RELAX_FIRST_BESS_SOCMAX_1E4"
                                    if ~isempty(firstBessUpperRows)
                                        bVar(firstBessUpperRows)=bVar(firstBessUpperRows)+1e-4;
                                    end
                                case "DROP_BESS1_HORIZON_END"
                                    if ~isempty(firstBessEndRow), keep(firstBessEndRow)=false; end
                                case "DROP_ALL_BESS_HORIZON_END"
                                    keep(bessEndRows)=false;
                                case "DROP_ALL_EV_HORIZON_END"
                                    keep(evEndRows)=false;
                                case "DROP_ALL_STORAGE_HORIZON_END"
                                    keep(unique([bessEndRows evEndRows]))=false;
                                case "DROP_BESS_DAILY_TARGET"
                                    keep(bessDailyRows)=false;
                                case "DROP_EV_DAILY_TARGET"
                                    keep(evDailyRows)=false;
                            end
                            AVar=A(keep,:); bTerm=bVar(keep);
                            removedCount(rr)=sum(~keep);
                            tTerm=tic;
                            [xT,fT,flagT,outT]=coneprog(f_coneprog,socConstraints,AVar,bTerm,Aeq,beq,lbTerm,ubTerm,coneOptions);
                            tElapsed=toc(tTerm); retriedT=false;
                            dualT=NaN;
                            if isstruct(outT) && isfield(outT,'dualfeasibility') && ~isempty(outT.dualfeasibility)
                                dualT=outT.dualfeasibility(1);
                            end
                            if ~isempty(coneOptionsRetry) && flagT==-7 && isfinite(dualT) && ...
                                    dualT>cfg.solver.retryDualThreshold
                                retriedT=true;
                                tRetry=tic;
                                [xTR,fTR,flagTR,outTR]=coneprog(f_coneprog,socConstraints,AVar,bTerm,Aeq,beq,lbTerm,ubTerm,coneOptionsRetry);
                                tElapsed=tElapsed+toc(tRetry);
                                if choose_coneprog_candidate(xT,flagT,outT,xTR,flagTR,outTR)
                                    xT=xTR; fT=fTR; flagT=flagTR; outT=outTR;
                                end
                            end
                            dT=collect_coneprog_diagnostic(outT,flagT,predictionStep,tElapsed, ...
                                xT,AVar,bTerm,Aeq,beq,lbTerm,ubTerm,Asc_ass_cell,bsc_ass_cell,dsc_ass_cell,gamma_ass_cell,true);
                            usableT=~isempty(xT) && all(isfinite(xT(:))) && ...
                                (flagT>0 || flagT==-7) && ...
                                (isnan(dT.maxManualConstraintViolation) || dT.maxManualConstraintViolation<=1e-6);
                            tv(rr)=variant; ta(rr)=aTerm; tu(rr)=usableT;
                            if ~isempty(flagT), tf(rr)=double(flagT(1)); end
                            tt(rr)=tElapsed; tp(rr)=dT.primalFeasibility; td(rr)=dT.dualFeasibility;
                            tg(rr)=dT.relativeGap; tm(rr)=dT.maxManualConstraintViolation; tr(rr)=retriedT;
                            fprintf('  alpha %.2f | %-32s -> usable=%d flag=%d removed=%d time=%.2fs\n', ...
                                aTerm,char(variant),usableT,flagT,removedCount(rr),tElapsed);
                        end
                    end
                    terminalAblationTable=table(tv,ta,tu,tf,tt,removedCount,tp,td,tg,tm,tr, ...
                        'VariableNames',{'Variant','Alpha','Usable','Exitflag','SolveTime_s','RowsRemoved', ...
                        'PrimalFeasibility','DualFeasibility','RelativeGap','ManualResidual','RetryUsed'});
                end

                probeReport=struct();
                probeReport.kind='IslandEMSStepReserveFeasibilityProbeV1';
                probeReport.methodID=string(runCfg.id);
                probeReport.caseName=string(runCfg.caseName);
                probeReport.targetStep=predictionStep;
                probeReport.targetTime_h=(predictionStep-1)*dt_mpc;
                probeReport.realStep=RealStep;
                probeReport.selectedAlpha=reserveMeta.alpha;
                probeReport.selectedReserveMeta=reserveMeta;
                probeReport.alphaHistory=reserveRatioHistory(1:predictionStep);
                probeReport.featureHistory=reserveFeatureHistory(1:predictionStep,:);
                probeReport.reserveMetaHistory={reserveMetaHistory{1:predictionStep}};
                probeReport.targetFeature=reserveFeature;
                if RealStep>1 && size(P_DG,2)>=RealStep-1
                    probeReport.currentDG_MW=real(P_DG(:,RealStep-1));
                else
                    probeReport.currentDG_MW=[];
                end
                probeReport.currentSOC=SOC(:,RealStep);
                probeReport.primaryAtTarget=struct('exitflag',exitflag,'objective',fval, ...
                    'dualFeasibility',diagRec.dualFeasibility,'primalFeasibility',diagRec.primalFeasibility, ...
                    'manualResidual',diagRec.maxManualConstraintViolation);
                probeReport.probeTable=probeTable;
                probeReport.terminalAblationTable=terminalAblationTable;
                probeReport.createdAt=datestr(now,30);

                probeFile=fullfile(tempdir,sprintf('IslandEMS_%s_step%d_feasibility_probe.mat', ...
                    char(string(runCfg.id)),predictionStep));
                if isfield(pCfg,'file') && ~isempty(pCfg.file)
                    probeFile=char(pCfg.file);
                end
                save(probeFile,'probeReport','-v7.3');
                fprintf('[feasibility probe] saved compact diagnostic to:\n  %s\n',probeFile);

                stopAfterProbe=true;
                if isfield(pCfg,'stopAfterProbe'), stopAfterProbe=logical(pCfg.stopAfterProbe); end
                if stopAfterProbe
                    error('IslandEMS:DiagnosticStop', ...
                        'Diagnostic feasibility probe completed at MPC step %d.',predictionStep);
                end
            end
        end

        check_solver_solution(x,exitflag,'coneprog',sprintf('MPC-SOCP step %d',predictionStep));
        solverExitflagHistory(predictionStep)=exitflag;
        postTimer=tic;

        if decisionStep>1
            idx=0;
            PbattGFM_disPre=[];PbattGFM_chPre=[];Pbatt_disPre=[];Pbatt_chPre=[];PbattEV_disPre=[];PbattEV_chPre=[];Pbatt_optPre=[];P_DG_optPre=[];Pres_optPre=[];PbattGFM_optPre=[];PbattEV_optPre=[];
            for ii=1:DG_GFM_num
                P_DG_optPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday;
                Q_DG_optPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday;
            end
            for ii=1:BatteryGFM_Num
                PbattGFM_disPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday;
                PbattGFM_chPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday;
                PbattGFM_optPre(:,:,ii) = PbattGFM_disPre(:,:,ii) - PbattGFM_chPre(:,:,ii); 
                QbattGFM_optPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday; 
            end
            for ii=1:BatteryNum
                Pbatt_disPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday;
                Pbatt_chPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday;
                Pbatt_optPre(:,:,ii) = Pbatt_disPre(:,:,ii) - Pbatt_chPre(:,:,ii); 
                Qbatt_optPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday; 
                dSOC_BESSPre(ii) = xpre(idx+1); idx=idx+1;
            end
            for ii=1:EVBatteryNum
                PbattEV_disPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday;
                PbattEV_chPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday;
                PbattEV_optPre(:,:,ii) = PbattEV_disPre(:,:,ii) - PbattEV_chPre(:,:,ii); 
                SOCrelaxPre(ii) = xpre(idx+1:idx+1);idx=idx+1;
                dSOCPre(ii) = xpre(idx+1:idx+1);idx=idx+1;
            end
            for ii=1:SolarNum
                Pres_optPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday; 
                Qres_optPre(:,:,ii) = xpre(idx+1:idx+Kday);idx=idx+Kday; 
            end
            for ii=1:Nload
                dPload_optPre(ii,:) = xpre(idx+1:idx+Kday);idx=idx+Kday; 
            end
        end

        

        if exitflag>0 || exitflag==-7
            idx=0;
            PbattGFM_dis=[];PbattGFM_ch=[];Pbatt_dis=[];Pbatt_ch=[];PbattEV_dis=[];PbattEV_ch=[];Pbatt_opt=[];P_DG_opt=[];Q_DG_opt=[];Pres_opt=[];PbattGFM_opt=[];QbattGFM_opt=[];
            for ii=1:DG_GFM_num
                P_DG_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
                Q_DG_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
            end
            for ii=1:BatteryGFM_Num
                PbattGFM_dis(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
                PbattGFM_ch(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
                PbattGFM_opt(:,:,ii) = PbattGFM_dis(:,:,ii) - PbattGFM_ch(:,:,ii); 
                QbattGFM_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday; 
            end
            for ii=1:BatteryNum
                Pbatt_dis(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
                Pbatt_ch(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
                Pbatt_opt(:,:,ii) = Pbatt_dis(:,:,ii) - Pbatt_ch(:,:,ii); 
                Qbatt_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday; 
                dSOC_BESS(ii,decisionStep) = x(idx+1); idx=idx+1;
            end
            for ii=1:EVBatteryNum
                PbattEV_dis(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
                PbattEV_ch(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday;
                PbattEV_opt(:,:,ii) = PbattEV_dis(:,:,ii) - PbattEV_ch(:,:,ii); 
                SOCrelax(ii,decisionStep) = x(idx+1:idx+1);idx=idx+1;
                dSOC(ii,decisionStep) = x(idx+1:idx+1);idx=idx+1;
            end
            for ii=1:SolarNum
                Pres_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday; 
                Qres_opt(:,:,ii) = x(idx+1:idx+Kday);idx=idx+Kday; 
            end
            for ii=1:Nload
                dPload_opt(ii,:) = x(idx+1:idx+Kday);idx=idx+Kday; 
            end
            nr = numel(residential_node);
            nb = numel(business_node);
            
            dPload = zeros(BusNum,size(dPload_opt,2));
            dPload(residential_node,:) = dPload_opt(1:nr,:);
            dPload(business_node,:)    = dPload_opt(nr+1:nr+nb,:);
            dQload=dPload.*tan(PowAngle);

            xpre=x;
            infeFlag=1;
        else
            if isempty(P_DG_optPre)==0
            P_DG_opt=P_DG_optPre;P_DG_opt(1,:,:)=P_DG_optPre(infeFlag+1,:,:);
            Q_DG_opt=Q_DG_optPre;Q_DG_opt(1,:,:)=Q_DG_optPre(infeFlag+1,:,:);
            end
            if isempty(PbattGFM_optPre)==0
            PbattGFM_opt=PbattGFM_optPre;PbattGFM_opt(1,:,:)=PbattGFM_optPre(infeFlag+1,:,:);
            QbattGFM_opt=QbattGFM_optPre;QbattGFM_opt(1,:,:)=QbattGFM_optPre(infeFlag+1,:,:);
            end
            if isempty(Pbatt_optPre)==0
            Pbatt_opt=Pbatt_optPre;Pbatt_opt(1,:,:)=Pbatt_optPre(infeFlag+1,:,:);
            Qbatt_opt=Qbatt_optPre;Qbatt_opt(1,:,:)=Qbatt_optPre(infeFlag+1,:,:);
            end
            if isempty(PbattEV_optPre)==0
            PbattEV_opt=PbattEV_optPre;PbattEV_opt(1,:,:)=PbattEV_optPre(infeFlag+1,:,:);
            end
            if isempty(Pres_optPre)==0
            Pres_opt=Pres_optPre;Pres_opt(1,:,:)=Pres_optPre(infeFlag+1,:,:);
            Qres_opt=Qres_optPre;Qres_opt(1,:,:)=Qres_optPre(infeFlag+1,:,:);
            end
            if isempty(dPload_optPre)==0
            dPload_opt=dPload_optPre;dPload_opt(:,1)=dPload_optPre(:,infeFlag+1);
            end
            nr = numel(residential_node);
            nb = numel(business_node);
            
            dPload = zeros(BusNum,size(dPload_opt,2));
            dPload(residential_node,:) = dPload_opt(1:nr,:);
            dPload(business_node,:)    = dPload_opt(nr+1:nr+nb,:);
            dQload=dPload.*tan(PowAngle);
            x=xpre;

            infeFlag=infeFlag+1;
        end

        % The study enforces dt_mpc == dt_exec.  Therefore the execution
        % grid is identical to the MPC grid and UniversalCurve(...,'previous')
        % is an exact no-op.  Direct assignment removes repeated interpolation
        % overhead without changing any command value.
        P_DG_opt_Dec=P_DG_opt; Q_DG_opt_Dec=Q_DG_opt;
        PbattGFM_opt_Dec=[]; QbattGFM_opt_Dec=[];
        if BatteryGFM_Num>0
            PbattGFM_opt_Dec=PbattGFM_opt; QbattGFM_opt_Dec=QbattGFM_opt;
        end
        Pbatt_opt_Dec=[]; Qbatt_opt_Dec=[];
        if BatteryNum>0
            Pbatt_opt_Dec=Pbatt_opt; Qbatt_opt_Dec=Qbatt_opt;
        end
        PbattEV_opt_Dec=[];
        if EVBatteryNum>0, PbattEV_opt_Dec=PbattEV_opt; end
        Pres_opt_Dec=[]; Qres_opt_Dec=[];
        if SolarNum>0, Pres_opt_Dec=Pres_opt; Qres_opt_Dec=Qres_opt; end
        dPload_opt_Dec=dPload_opt;
        nr = numel(residential_node);
        nb = numel(business_node);
        dPload = zeros(BusNum,size(dPload_opt_Dec,2));
        dPload(residential_node,:) = dPload_opt_Dec(1:nr,:);
        dPload(business_node,:)    = dPload_opt_Dec(nr+1:nr+nb,:);
        dQload=dPload.*tan(PowAngle);
        execIdx=1;
        
        if cfg.diagnostics.computeRelaxationGap
            [relaxationGap(decisionStep),relaxationRelGap(decisionStep), ...
                MaxAngleErrorAllLoopInDay(decisionStep),MaxMagErrorAllLoopInDay(decisionStep)] = ...
                relaxationGapAnalysis(x,idx,Nbranch,BusNum,Line,LineBFM,loopNodes,Loops,loopBranches,Kday);
        else
            relaxationGap(decisionStep)=NaN; relaxationRelGap(decisionStep)=NaN;
            MaxAngleErrorAllLoopInDay(decisionStep)=NaN; MaxMagErrorAllLoopInDay(decisionStep)=NaN;
        end

        if false% output for debug
            figure
            legend_entries = cell(2*DG_GFM_num+2*BatteryNum+2*BatteryGFM_Num+EVBatteryNum+2*SolarNum+Nload, 1);
            hold on
            for ii=1:DG_GFM_num
                stairs(0:1:23, P_DG_opt(:,:,ii)','LineWidth',2);
                legend_entries{ii} = sprintf('$P_{DG%d}$', ii);
            end
            for ii=1:DG_GFM_num
                stairs(0:1:23, Q_DG_opt(:,:,ii)','LineStyle',':','LineWidth',2);
                legend_entries{DG_GFM_num+ii} = sprintf('$Q_{DG%d}$', ii);
            end
            
            for ii=1:BatteryGFM_Num
                stairs(0:1:23, PbattGFM_opt(:,:,ii)','LineWidth',2);
                legend_entries{2*DG_GFM_num+ii} = sprintf('$P_{batt%d}$', ii);
            end
            for ii=1:BatteryGFM_Num
                stairs(0:1:23, QbattGFM_opt(:,:,ii)','LineStyle',':','LineWidth',2);
                legend_entries{2*DG_GFM_num+BatteryGFM_Num+ii} = sprintf('$Q_{batt%d}$', ii);
            end
            
            for ii=1:BatteryNum
                stairs(0:1:23, Pbatt_opt(:,:,ii)','LineWidth',2);
                legend_entries{2*DG_GFM_num+2*BatteryGFM_Num+ii} = sprintf('$P_{batt%d}$', ii);
            end
            for ii=1:BatteryNum
                stairs(0:1:23, Qbatt_opt(:,:,ii)','LineStyle',':','LineWidth',2);
                legend_entries{2*DG_GFM_num+2*BatteryGFM_Num+BatteryNum+ii} = sprintf('$Q_{batt%d}$', ii);
            end
            
            for ii=1:EVBatteryNum
                stairs(0:1:23, PbattEV_opt(:,:,ii)','LineWidth',2);
                legend_entries{2*DG_GFM_num+2*BatteryNum+2*BatteryGFM_Num+ii} = sprintf('$P_{EV%d}$', ii);
            end
            
            for ii=1:SolarNum
                stairs(0:1:23, Pres_opt(:,:,ii)','Color','m','LineWidth',2);
                legend_entries{2*DG_GFM_num+2*BatteryNum+2*BatteryGFM_Num+EVBatteryNum+ii} = sprintf('$P_{res%d}$', ii);
            end
            for ii=1:SolarNum
                stairs(0:1:23, Qres_opt(:,:,ii)','LineStyle',':','Color','m','LineWidth',2);
                legend_entries{2*DG_GFM_num+2*BatteryNum+2*BatteryGFM_Num+EVBatteryNum+SolarNum+ii} = sprintf('$Q_{res%d}$', ii);
            end
            
            for ii=1:Nload
                stairs(0:1:23, dPload_opt(ii,:),'Color','m','LineWidth',2);
                legend_entries{2*DG_GFM_num+2*BatteryNum+2*BatteryGFM_Num+EVBatteryNum+2*SolarNum+ii} = sprintf('$P_{LdShed%d}$', ii);
            end
            hold off
            xlabel('t(h)','Interpreter','latex');
            ylabel('$MW$','Interpreter','latex');
            xlim([0,23])
            legend(legend_entries, 'Interpreter', 'latex','NumColumns',2)
            set(gca, 'FontName', 'Times New Roman', 'FontSize', fontsize);
            title(predictionStep)
            grid on
            box on
        end

        %-------------------------------
        postprocessTimeHistory(decisionStep)=toc(postTimer);
        if exist('decisionBlockTimer','var')
            decisionBlockTimeHistory(decisionStep)=toc(decisionBlockTimer);
        end
        predictionStep=predictionStep+1;
        decisionStep=decisionStep+1;
    elseif mod(RealStep-1,samplesPerDecision)==0 && predictionStep<=predictionHorizon
        % execIdx=execIdx+1; 
        execIdx=1; 
    end

    idx_ref=0;
    for ii=1:DG_GFM_num
        Ref(idx_ref+1,RealStep)=1;idx_ref=idx_ref+1;%Vset GFM
        Ref(idx_ref+1,RealStep)=P_DG_opt_Dec(execIdx,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=Q_DG_opt_Dec(execIdx,1,ii);idx_ref=idx_ref+1;%Qg1_bat set
    end
    
    for ii=1:BatteryGFM_Num
        Ref(idx_ref+1,RealStep)=1;idx_ref=idx_ref+1;%Vset GFM
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%dw_set GFM
        Ref(idx_ref+1,RealStep)=PbattGFM_opt_Dec(execIdx,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=QbattGFM_opt_Dec(execIdx,1,ii);idx_ref=idx_ref+1;%Qg1_bat set
    end

    for ii=1:BatteryNum
        Pbatt_cmd=Pbatt_opt_Dec(execIdx,1,ii);
        Ref(idx_ref+1,RealStep)=Pbatt_cmd;idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=Qbatt_opt_Dec(execIdx,1,ii);idx_ref=idx_ref+1;%Qg1_bat set
    end
    
    for ii=1:EVBatteryNum
        Ref(idx_ref+1,RealStep)=PbattEV_opt_Dec(execIdx,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
        Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%Qg1_bat set
    end
    
    for ii=1:SolarNum
        Ref(idx_ref+1,RealStep)=min(Pres_opt_Dec(execIdx,1,ii),PV1_curve(BusOfPV(ii),RealStep));idx_ref=idx_ref+1;%Pg2_bat set
        Ref(idx_ref+1,RealStep)=Qres_opt_Dec(execIdx,1,ii);idx_ref=idx_ref+1;%Qg2_bat set
    end
    

    if RealStep==1
        S_load_vec=Pload_true_box(:,RealStep)+1j*Qload_true_box(:,RealStep);
        [Vs, Vinv, Xbasic(:,RealStep),freq(:,RealStep),~]=InitializationProgram(P_DG_opt,PbattGFM_opt,Pbatt_opt,PbattEV_opt,DieselG_Pgfm_rate,Pload_true_box,Qload_true_box,PV1_curve,V_DC,Zs_DG,Xd_prime,Xm_g,Zmv_g,Y_Bus_dyn,SOC(:,RealStep),SOCmin,SOCmax,DGcontrolParams,SoCParams,phys,K_Pdp,K_Qdp,Rdroop,kQ_DG,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,BusNum,DG_GFM_num,BatteryGFM_Num,BatteryNum,EVBatteryNum,SolarNum,MainGFM,dt,Integrator);
        S_slack_ini=-sum(S_load_vec);
        meanfreq(:,RealStep)=compute_coi_frequency(freq(:,RealStep),DieselG_Pgfm_rate,phys.H);
        
        Niter=5;% suggest value >=
    else
        S_load_vec=Pload_true_box(:,RealStep)+1j*Qload_true_box(:,RealStep)+(dPload(:,execIdx)+1j*dQload(:,execIdx));
        S_slack_ini=S_busInjVec(1);

        Niter=3;% suggest value >=
    end

    [Xbasic(:,RealStep+1),Vs,Vinv,S_busInjVec,S_DG,S_inv_Batt,S_inv_PV,freq(:,RealStep+1),SOC(:,RealStep+1),fvalpf, exitflagpf,obserP{RealStep}]=MicrogridSys_ODEAE_expIterSolver(Xbasic(:,RealStep),Vs,Vinv,Ref(:,RealStep),S_load_vec,V_DC,Zs_DG,Xm_g,Zmv_g,Y_Bus_dyn,SOC(:,RealStep),SOCmin,SOCmax,DieselG_Pgfm_rate,DGcontrolParams,SoCParams,phys,K_Pdp,K_Qdp,Rdroop,kQ_DG,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,MainGFM,dt,Niter,Integrator);                                                                                                                                    
    [SOC(:,RealStep+1),socGuardMeta] = sanitize_soc_state( ...
        SOC(:,RealStep+1),SOCmin,SOCmax,socNumericalTol, ...
        sprintf('physical state after second %d',RealStep));
    socNumericalClipCount = socNumericalClipCount + socGuardMeta.clipCount;
    socNumericalClipMax = max(socNumericalClipMax,socGuardMeta.maxCorrection);
    pfExitflagHistory(RealStep)=exitflagpf;

    % record results and calculate costs
    VsBoxBasic(:,RealStep)=Vs;
    meanfreq(:,RealStep+1)=compute_coi_frequency(freq(:,RealStep+1),DieselG_Pgfm_rate,phys.H);
    dmeanfreq(:,RealStep+1)=compute_coi_frequency(freq(:,RealStep+1),DieselG_Pgfm_rate,phys.H)-f_rate;
    Pload_BoxBasic(:,RealStep)=real(S_load_vec([residential_node business_node],:));
    Qload_BoxBasic(:,RealStep)=imag(S_load_vec([residential_node business_node],:));

    Pload_resid=real(sum(S_load_vec(residential_node,1)));
    Pload_busi=real(sum(S_load_vec(business_node,1)));
    w_c_resid=Pload_resid/(Pload_resid+Pload_busi);
    w_c_busi=Pload_busi/(Pload_resid+Pload_busi);
    C_buy(1,RealStep)=C_buy_residential(1,RealStep)*w_c_resid+C_buy_business(1,RealStep)*w_c_busi;

    P_DG(:,RealStep)=real(S_DG(BusOfDieselG_GFM,1));
    P_res(:,RealStep)=real(S_inv_PV(BusOfPV,1));

    idx_ref=0;
    Pbatt(:,RealStep)=real(S_inv_Batt([BusOfBatteryGFM BusOfBattery BusOfEVBattery],1));
    Pbatt_dis=max(Pbatt(:,RealStep),0);% active power injected from the storage system
    Pbatt_ch=max(-Pbatt(:,RealStep),0);% active power consumed by the storage system
    
    V_from = Vs(Line(:,1));
    V_to   = Vs(Line(:,2));
    I_line(:,RealStep) = (V_from - V_to) ./ Impedance;
    Ploss(1,RealStep) = sum(abs(I_line(:,RealStep)).^2 .* real(Impedance));
    
    P_DG_GFM=sum(real(S_DG(BusOfDieselG_GFM,:)));
    P_Batt_GFM=sum(real(S_inv_Batt(BusOfBatteryGFM,:)));
    
    % Pbuy=max(real(S_busInjVec(BusOfSlack,:)),0);% total active power injected from the large system
    % Pbuy_forPowBalan=max(Pbuy-Ploss(1,RealStep),0);% additional power for load power balance
    % Psell=max(-real(S_busInjVec(BusOfSlack,:)),0);%active power consumed by the large system
    
    CostRecord(1,RealStep)=(C_dieselG*sum(P_DG(:,RealStep)) + C_deg*sum(Pbatt_ch+Pbatt_dis) + C_LdShd*sum(dPload(:,execIdx)))*dt*1000;% $; losses are already internalized by DG dispatch/SoC dynamics
    
    P_battVec_chr=min(Pbatt(:,RealStep),0);
    TotalLoad(1,RealStep)=real(sum(S_load_vec));
    % TotalConsume(1,RealStep)=real(sum(S_load_vec))+sum(P_battVec_chr)-Ploss(1,RealStep);
    TotalConsume(1,RealStep)=real(sum(S_load_vec))+sum(P_battVec_chr);% diagnostic consumption; network losses are represented by the physical power flow
    P_battVec_gen=max(Pbatt(:,RealStep),0);
    TotalGen(1,RealStep)=sum(P_battVec_gen)+real(sum(S_inv_PV))+P_DG_GFM;
    TotalGFM(1,RealStep)=P_DG_GFM+P_Batt_GFM;
    TotalBatt(1,RealStep)=sum(Pbatt(:,RealStep));
    TotalPV(1,RealStep)=real(sum(S_inv_PV(BusOfPV,1)));
end
timeCostMPC=toc(outter);
decisionBlockTotalTime=sum(decisionBlockTimeHistory,'omitnan');
forecastBuildTotalTime=sum(forecastBuildTimeHistory,'omitnan');
dynamicAssemblyTotalTime=sum(dynamicAssemblyTimeHistory,'omitnan');
postprocessTotalTime=sum(postprocessTimeHistory,'omitnan');
coneSolveTotalTime=sum(decisionTimeMPC_withgridBox,'omitnan');
decisionAssemblyAndPostTime=max(decisionBlockTotalTime-coneSolveTotalTime,0);
physicalLoopAndRecordTime=max(timeCostMPC-decisionBlockTotalTime,0);
fprintf('MPC static SOCP preparation time: %fs (cache reused=%d)\n',staticStructureBuildTime,staticCacheReused);
fprintf('MPC EMS coneprog solve time (daily total): %fs\n',coneSolveTotalTime);
fprintf('MPC EMS decision setup/postprocess time: %fs\n',decisionAssemblyAndPostTime);
fprintf('  forecast construction total: %fs\n',forecastBuildTotalTime);
fprintf('  dynamic constraint assembly: %fs\n',dynamicAssemblyTotalTime);
fprintf('  postprocess/unpack total    : %fs\n',postprocessTotalTime);
fprintf('MPC EMS physical-loop/recording time: %fs\n',physicalLoopAndRecordTime);
fprintf('MPC EMS total coupled runtime: %fs\n',timeCostMPC);

Pload_true_boxPlt=Pload_true_box([residential_node business_node],:);
[totalCost]=EMS_results_display(Pload_BoxBasic,Qload_BoxBasic,Pload_true_boxPlt,P_DG,Pbatt,P_res,TotalLoad,TotalConsume,Ploss,TotalGen,TotalBatt,TotalPV,TotalGFM,CostRecord,VsBoxBasic,SOC,T_EVch1,T_EVch2,Xbasic,I_line,LineLimits,Vmin,Vmax,ResiUserNum+BusiUserNum,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,meanfreq,t_sim,ExportFigForPaper,brhID,cfg.output.showFigures);
disp(['Average frequency deviation:',num2str(sum(dmeanfreq)/length(dmeanfreq)),'Hz'])
evDeficitSOC=max(SOCmax-SOC(BatteryGFM_Num+BatteryNum+1:end,end),0);
bessDeficitSOC=max(SOC(BatteryGFM_Num+1:BatteryGFM_Num+BatteryNum,1)- ...
    SOC(BatteryGFM_Num+1:BatteryGFM_Num+BatteryNum,end),0);
TotC=totalCost + 1000*C_EVSoCshed*sum(EbattMaxEV(:).*evDeficitSOC(:)) ...
    + 1000*C_BESSSoCshed*sum(EbattMax(:).*bessDeficitSOC(:));
disp(['Total cost for MPC SOCP: $',num2str(TotC)])
disp(['Average value of one step decision time cost for MPC LP: ',num2str(mean(decisionTimeMPC_withgridBox)),'s'])

fig_idx=9;
TotalLoadBox{fig_idx}=TotalLoad;
TotalGFMBox{fig_idx}=TotalGFM;
TotalBattBox{fig_idx}=TotalBatt;
TotalPVBox{fig_idx}=TotalPV;
SoC_BOX{fig_idx}=SOC;
Iline_magBox{fig_idx}=abs(I_line(brhID,:));
Vs_magBox{fig_idx}=abs(VsBoxBasic(busID,:));
freqBox{fig_idx}=meanfreq;
EcoCostBox{fig_idx}=TotC;
DeciTimeCostBox{fig_idx}=mean(decisionTimeMPC_withgridBox);

P_DG_opt_DecBox{fig_idx}=P_DG_opt_Dec;
P_DGBox{fig_idx}=P_DG;

relaxationGap;
relaxationRelGap;
MaxAngleErrorAllLoopInDay;
MaxMagErrorAllLoopInDay;
end
