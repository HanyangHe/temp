%% Offline training for GRID-SPECIFIC randomized-alpha frequency-stress models
% One reusable model is stored under ai/models/<caseName>/reserve_krr_model.mat.
% Existing compatible response data are reused.  Missing alpha levels are
% added with matched final-paper scenario parity when possible; already
% observed alpha=0.60:1.00 rows are not duplicated.
clear; clc;
projectRoot=fileparts(mfilename('fullpath'));
addpath(genpath(projectRoot));
% TRAIN_AIRESERVE_PATH_HYGIENE_BEGIN
% Archived/output copies must never shadow live production functions.
nonRuntimeTrees={'archive','outputs','patch_files'};
for iPath=1:numel(nonRuntimeTrees)
    pDrop=fullfile(projectRoot,nonRuntimeTrees{iPath});
    if exist(pDrop,'dir')==7
        try, rmpath(genpath(pDrop)); catch, end
    end
end
clear config_island_ems system_case_catalog engine_island_ems
rehash
% TRAIN_AIRESERVE_PATH_HYGIENE_END

cfg=config_island_ems();
validate_config(cfg);
% TRAIN_AIRESERVE_INPUTAVG_BANNER
if isfield(cfg.forecast,'useMPCIntervalAverage')
    avgModeOn=logical(cfg.forecast.useMPCIntervalAverage);
else
    avgModeOn=false;
end
if isfield(cfg.forecast,'mpcIntervalAverageMode')
    avgModeName=string(cfg.forecast.mpcIntervalAverageMode);
else
    avgModeName="not-configured";
end
fprintf(' average input   : %d (%s)\n',avgModeOn,avgModeName);
caseNames=string(cfg.ai.response.systemCases);
if isempty(caseNames), error('cfg.ai.response.systemCases is empty.'); end

fprintf('\n=============================================================\n');
fprintf(' GRID-SPECIFIC AI RESERVE RESPONSE-MODEL TRAINING\n');
fprintf(' state features : %s\n',strjoin(reserve_feature_names(),', '));
fprintf(' queried input  : reserveRatio alpha\n');
fprintf(' target         : normalized CoI frequency stress\n');
fprintf(' ONLINE alpha   : [%.2f, %.2f], fallback %.2f\n', ...
    cfg.ai.alphaMin,cfg.ai.alphaMax,cfg.ai.fallbackAlpha);
fprintf(' OFFLINE alpha  : [%.2f, %.2f], target levels %s\n', ...
    cfg.ai.response.trainingAlphaMin,cfg.ai.response.trainingAlphaMax, ...
    mat2str(cfg.ai.response.alphaLevels));
fprintf(' profile        : %s\n',cfg.ai.response.profile);
fprintf(' grids          : %s\n',strjoin(cellstr(caseNames),', '));
fprintf(' incremental    : %d\n',logical(cfg.ai.response.incrementalReuseExistingDataset));
fprintf('=============================================================\n\n');

for ic=1:numel(caseNames)
    caseName=char(caseNames(ic));
    modelFile=get_ai_reserve_model_file(projectRoot,cfg,caseName);
    if exist(modelFile,'file') && cfg.ai.trainingSkipValidExisting
        S=load(modelFile,'model');
        [ok,msg]=validate_ai_reserve_model(S.model,cfg,caseName);
        if ok
            fprintf('[%s] Valid existing response model found -> reuse/skip training:\n  %s\n', ...
                caseName,modelFile);
            continue
        else
            fprintf('[%s] Existing model is stale/incompatible (%s) -> checking reusable data.\n',caseName,msg);
        end
    end

    cfgCase=cfg;
    cfgCase.ai.response.systemCases={caseName};
    dataset=[]; datasetFile='';
    baseDataset=[]; baseFile='';
    if cfg.ai.response.incrementalReuseExistingDataset
        [baseDataset,baseFile,findMsg]=find_latest_compatible_response_dataset( ...
            projectRoot,cfgCase,caseName);
        fprintf('[%s] Existing-data check: %s\n',caseName,findMsg);
    end

    targetLevels=sort(unique(cfgCase.ai.response.alphaLevels(:).'));
    missingLevels=targetLevels;
    if ~isempty(baseDataset)
        counts=zeros(size(targetLevels));
        for i=1:numel(targetLevels)
            counts(i)=sum(abs(baseDataset.alpha-targetLevels(i))<1e-12);
        end
        missingLevels=targetLevels(counts<cfg.ai.response.minSamplesPerExistingAlpha);
        fprintf('[%s] Existing dataset: %d rows, %d groups\n',caseName, ...
            size(baseDataset.X,1),numel(unique(baseDataset.groupID)));
        disp(table(targetLevels(:),counts(:),'VariableNames',{'Alpha','ExistingCount'}));
    end

    if isempty(baseDataset)
        fprintf('[%s] No reusable dataset -> generating full randomized training set.\n',caseName);
        [dataset,datasetFile]=generate_reserve_response_dataset(cfgCase,projectRoot);
    elseif isempty(missingLevels)
        fprintf('[%s] All target alpha levels already sufficiently represented -> no simulation.\n',caseName);
        dataset=baseDataset; datasetFile=baseFile;
    else
        fprintf('[%s] Missing/underrepresented alpha levels: %s\n',caseName,mat2str(missingLevels));
        cfgAdd=cfgCase;
        if cfg.ai.response.parity.enabled && strcmpi(cfg.ai.response.profile,'paper')
            fprintf(['[%s] Generating MATCHED final-paper parity enrichment: ', ...
                'same 5 decay levels x 2 seeds; only missing-alpha rows retained.\n'],caseName);
            cfgAdd.ai.response.scheduleMode='matched-paper-parity';
            cfgAdd.ai.response.parityTargetAlphaLevels=missingLevels;
            cfgAdd.ai.response.parityFillerAlphaLevels= ...
                cfg.ai.response.parity.referenceExistingAlphaLevels;
            cfgAdd.ai.response.parityTargetCountPerTrajectory= ...
                cfg.ai.response.parity.targetCountPerTrajectory;
            cfgAdd.ai.response.retainAlphaLevels=missingLevels;
            cfgAdd.ai.response.alphaLevels=targetLevels;
            cfgAdd.ai.response.decayRatios=cfg.ai.response.parity.decayRatios;
            cfgAdd.ai.response.randomSeeds=cfg.ai.response.parity.randomSeeds;
            cfgAdd.ai.response.saveIntermediate=cfg.ai.response.parity.saveIntermediate;
        else
            fprintf('[%s] Generating generic incremental enrichment trajectories.\n',caseName);
            cfgAdd.ai.response.alphaLevels=missingLevels;
            cfgAdd.ai.response.decayRatios=cfg.ai.response.decayRatios;
            cfgAdd.ai.response.randomSeeds=cfg.ai.response.randomSeeds;
        end
        [extra,extraFile]=generate_reserve_response_dataset(cfgAdd,projectRoot); %#ok<NASGU>
        dataset=merge_reserve_response_datasets(baseDataset,extra,cfgCase,caseName);

        stamp=datestr(now,'yyyymmdd_HHMMSS');
        mergedRoot=fullfile(projectRoot,cfg.output.root, ...
            sprintf('training_%s_response_merged_%s',lower(caseName),stamp));
        if ~exist(mergedRoot,'dir'), mkdir(mergedRoot); end
        datasetFile=fullfile(mergedRoot,'reserve_response_dataset.mat');
        sourceFiles=struct('base',baseFile,'incremental',extraFile); %#ok<NASGU>
        save(datasetFile,'dataset','sourceFiles','-v7.3');
        fprintf('[%s] Saved merged response dataset:\n  %s\n',caseName,datasetFile);
        fprintf('  base %d + added %d = %d samples; groups %d\n', ...
            dataset.mergeInfo.baseSamples,dataset.mergeInfo.addedSamples, ...
            dataset.mergeInfo.finalSamples,dataset.mergeInfo.finalGroups);
        fprintf('  matched scenario groups reused: %d\n',dataset.mergeInfo.matchedGroups);
    end

    % Publish ONE canonical reusable final-paper dataset per grid.  The
    % outputs/training_* file remains a provenance/generation artifact only.
    sourceDatasetFile=datasetFile;
    datasetFile=publish_ai_reserve_dataset(projectRoot,cfgCase,caseName, ...
        dataset,sourceDatasetFile);

    finalCounts=zeros(size(targetLevels));
    for ia=1:numel(targetLevels)
        finalCounts(ia)=sum(abs(dataset.alpha-targetLevels(ia))<1e-12);
    end
    fprintf('[%s] Final paper alpha-bin counts:\n',caseName);
    disp(table(targetLevels(:),finalCounts(:),'VariableNames',{'Alpha','FinalCount'}));
    if min(finalCounts)<cfg.ai.response.minSamplesPerExistingAlpha
        warning('[%s] At least one final alpha bin has fewer than %d samples.', ...
            caseName,cfg.ai.response.minSamplesPerExistingAlpha);
    end

    fprintf('[%s] Training KRR frequency-stress response model...\n',caseName);
    model=train_reserve_krr(dataset,cfgCase.ai);
    model.caseName=caseName;
    model.trainingSignature=ai_reserve_model_signature(cfgCase,caseName);
    model.datasetFile=datasetFile;

    modelDir=fileparts(modelFile);
    if ~exist(modelDir,'dir'), mkdir(modelDir); end
    save(modelFile,'model','datasetFile','-v7.3');
    fprintf('[%s] Saved reusable AI reserve response model:\n  %s\n',caseName,modelFile);
end

fprintf('\nTraining command finished. Existing compatible response data were reused.\n');
