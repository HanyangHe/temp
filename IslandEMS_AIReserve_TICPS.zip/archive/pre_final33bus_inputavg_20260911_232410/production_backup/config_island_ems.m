function cfg = config_island_ems()
%CONFIG_ISLAND_EMS Central configuration for the islanded-microgrid study.
% Keep experiment switches here; method-specific logic belongs in
% baseline_catalog.m and the core engine.

cfg.projectName = 'IslandEMS_AIReserve_TICPS';

% ----- Base quantities ----------------------------------------------------
cfg.base.S_VA = 1e6;
cfg.base.V_V  = 480;

% ----- Simulation ---------------------------------------------------------
cfg.simulation.samplePerHour = 3600;   % 1-s physical simulation step
cfg.simulation.integrator = 'ode4';
cfg.simulation.randomSeed = 0;

% ----- MPC / forecasting --------------------------------------------------
% Default revised study: 15-min receding-horizon MPC. The MPC decision
% interval and the prediction-grid step are intentionally equal, while the
% total prediction horizon remains 24 h.
cfg.mpc.decisionInterval_h = 0.25;      % 15 min between MPC updates
cfg.mpc.predictionStep_h   = 0.25;      % 15 min per MPC prediction stage
cfg.mpc.horizon_h          = 24.0;      % 24-h look-ahead horizon
cfg.mpc.decisionLevelSteps = round(24/cfg.mpc.decisionInterval_h); % 96/day
cfg.mpc.predictionHorizon  = round(cfg.mpc.horizon_h/cfg.mpc.predictionStep_h); % 96 stages

% The existing load/PV KRR predictors were trained on hourly data. They
% therefore remain hourly "native" forecasters. At every 15-min MPC update,
% the code generates hourly forecast anchors and interpolates those anchors
% onto the 15-min optimization grid OUTSIDE the optimizer. This preserves
% the original forecasting models while removing the 1-h dispatch hold.
cfg.forecast.nativeStep_h = 1.0;
cfg.forecast.interpolationMethod = 'pchip';
cfg.forecast.upstreamTrustWeight = 0.1;

% ----- Frequency model and reserve design --------------------------------
cfg.frequency.nominal_Hz = 60;
cfg.frequency.droop_pu = 0.03;         % 3% droop on each DG local P-rated base
cfg.frequency.H_s = 1.0;               % local DG active-power base
cfg.frequency.D_pu = 0.8;              % local DG active-power base
cfg.frequency.governorTime_s = 1.5;
cfg.frequency.secondaryIntegralGain = 0.5; % inactive for MainGFM=0 cases
cfg.frequency.dgPmin_pu = 0.20;
cfg.frequency.dgPmax_pu = 1.00;
cfg.frequency.dgImpedanceBase = 'system'; % 'system' preserves legacy Ra/Xd'' convention; use 'machine' only if source parameters are machine-base pu
cfg.frequency.dgRa_pu = 0.02;          % source-base convention selected by dgImpedanceBase
cfg.frequency.dgXdPrime_pu = 0.25;     % source-base convention selected by dgImpedanceBase

% IMPORTANT: reserve-design bandwidth and security-evaluation limit are
% intentionally distinct.  After correcting the DG rating-base convention
% and moving to a 15-min MPC grid, the nominal physics reserve is set to
% 0.30 Hz; the nonlinear physical response is still judged against the
% separate 0.50-Hz security criterion.  alpha=1 therefore means the fixed
% 0.30-Hz physics baseline used by T7/F1.
cfg.frequency.reserveDeviation_Hz = 0.30;      % nominal EMS reserve-design bandwidth
cfg.frequency.reserveRoCoF_Hz_s = 0.50;        % EMS inertial/RoCoF reserve design
cfg.frequency.securityDeviation_Hz = 0.50;     % physical security criterion
cfg.frequency.securityRoCoF_Hz_s = 0.50;       % physical security criterion

% ----- Network ------------------------------------------------------------
cfg.network.Vmin_pu = 0.90;
cfg.network.Vmax_pu = 1.10;
% The revised TICPS paper uses radial cases only. Meshed SOCP exactness is
% not a contribution and is intentionally excluded from formal experiments.
cfg.network.allowMeshedCases = false;
cfg.network.paperCases = {'10bus','18bus','33bus'};

% ----- Storage / EV / flexibility ----------------------------------------
cfg.storage.bessDuration_h = 8.0;      % manuscript-consistent E/P duration
cfg.storage.gfmBessDuration_h = 8.0;   % inactive in current test grids
cfg.storage.SOCmin = 0.20;
cfg.storage.SOCmax = 0.90;
cfg.ev.numberPerResidentialBus = 3;
cfg.ev.energyDuration_h = 6.0;         % aggregate fleet E/P duration
% A legacy, unreported EV terminal-SoC feasibility slack existed in the
% original code. Keep the variable structurally for compatibility but fix
% it to zero by default so the manuscript's explicit dSOC_EV variable is
% the only terminal-energy relaxation mechanism.
cfg.ev.terminalNumericalSlackMax = 0.0;
cfg.ev.terminalNumericalSlackPenalty_per_kWh = 10.0;
cfg.flexibility.maxLoadShedFraction = 0.20;
cfg.flexibility.evCurtailmentFactor = 0.90;

% ----- Economic coefficients --------------------------------------------
% All prices are in $/kWh. Optimization powers are in MW, so objective
% assembly explicitly converts MWh to kWh by a factor of 1000.
cfg.cost.diesel_per_kWh = 0.30;
cfg.cost.loadShed_per_kWh = 3.00;
cfg.cost.evTerminalDeficit_per_kWh = 0.60;
cfg.cost.bessTerminalDeficit_per_kWh = 0.45;
cfg.cost.batteryUnit_per_kWh = 300;
cfg.cost.batteryCycles = 5000;
cfg.cost.pvCurtailment_per_kWh = 0.0; % no hidden PV reward in the manuscript model

% ----- Experiment selection ----------------------------------------------
% Formal paper cases are radial only: 10bus, 18bus, 33bus.
% Meshed legacy cases remain in system_case_catalog.m for archival/debug use
% but validate_config rejects them while allowMeshedCases=false.
cfg.experiment.systemCases = {'33bus'}; % representative development case
cfg.scenario.dayType = 'Unusual day';
cfg.scenario.decayRatios = [0.20 0.40 0.60 0.80 1.00];
cfg.experiment.randomSeeds = 0;

% All original manuscript baselines are available. P1 is enabled after
% train_AIReserve.m creates a model.
% ----- Final TICPS paper experiment groups ----------------------------
% Severe shortage:
%   T3, T4, T6, T7, P1
%
% AI reserve ablation:
%   A0, T7, G1, P1U, P1
%
% T7 and P1 are shared and should be simulated only once.

cfg.experiment.paperStudies = paper_study_catalog();

% Unique formal run order, AI ablation first
cfg.experiment.enabledMethods = ...
    cfg.experiment.paperStudies.formalRunOrder;

% ----- AI reserve model ---------------------------------------------------
% The formal AI rule no longer learns alpha* from an expensive multi-alpha
% full-day oracle sweep.  Instead, a small number of CLOSED-LOOP trajectories
% are generated with a balanced randomized reserve ratio at each 15-min MPC
% update.  KRR learns the physical frequency-stress response
%
%   [Pnet, |Delta Pnet|, DG upward headroom, candidate alpha] -> stress,
%
% where stress=max(max|df_CoI|/df_lim,max|RoCoF_CoI|/RoCoF_lim).  Online,
% the smallest candidate alpha whose CALIBRATED predicted stress is <=1 is
% selected before solving the MPC.  alpha=1 is the conventional full physics
% reserve and is also the transparent OOD/no-safe-candidate fallback.
cfg.ai.modelType = 'krr';
cfg.ai.learningTarget = 'frequency-stress-response';
% One offline model is stored per physical grid.  Formal results belong in
% outputs/, whereas reusable trained models live under ai/models/<case>/.
cfg.ai.modelRoot = fullfile('ai','models');
cfg.ai.modelFileName = 'reserve_krr_model.mat';
% Canonical reusable FINAL-PAPER response datasets live separately from
% temporary/output training artifacts.  One dataset is retained per grid.
cfg.ai.datasetRoot = fullfile('ai','datasets');
cfg.ai.datasetFileName = 'reserve_response_dataset_paper.mat';
cfg.ai.trainingSkipValidExisting = true;

% Formal reserve-policy range.  After increasing the nominal physics reserve
% to the 0.30-Hz design bandwidth, alpha=1 is secure in the representative
% radial 18-bus smoke test.  The AI is therefore only allowed to REMOVE
% unnecessary conservatism; it never requests more than the full physics
% reserve in the formal study.
cfg.ai.alphaMin = 0.60;      % ONLINE permitted reserve ratio
cfg.ai.alphaMax = 1.00;
cfg.ai.candidateAlphaGrid = 0.60:0.02:1.00; % online policy search grid
cfg.ai.kernelSigma = 1.0;             % fallback if grouped tuning unavailable
cfg.ai.lambda = 1e-3;
cfg.ai.tuneHyperparameters = true;
cfg.ai.kernelSigmaGrid = [0.35 0.60 1.00 1.70 3.00];
cfg.ai.lambdaGrid = [1e-5 1e-4 1e-3 1e-2 1e-1];
cfg.ai.calibrationRisk = 0.05;        % one-sided stress-underprediction risk target
cfg.ai.useSafetyCalibration = false;
% FINAL_P1_FORECAST_GUARD_DEFAULTS
% Method-specific enable/disable is applied in run_single_experiment.
% Keep the global default OFF so training/legacy runs are unaffected.
cfg.ai.enableForecastSafetyShield = false;
cfg.ai.forecastSafetyShieldDropThreshold_pu = 0.02;
cfg.ai.forecastSafetyShieldNetLoadMin_pu = 0.60;
cfg.ai.forecastSafetyShieldSevereDropEnabled = true;
cfg.ai.forecastSafetyShieldSevereDropThreshold_pu = 0.11;
cfg.ai.forecastSafetyShieldAlpha = 1.00;
cfg.ai.useOODFallback = true;
cfg.ai.oodMarginStd = 0.50;
cfg.ai.fallbackAlpha = 1.0;           % conventional full physics reserve
cfg.ai.requireModelForAI = true;

% Efficient randomized-alpha response-data generation.  Each trajectory
% contributes approximately 95 causal interval samples rather than requiring
% one full-day simulation per alpha value.  The exploration alpha levels are
% balanced and shuffled independently of time of day.
%
% FINAL-PAPER POLICY:
%   * Offline exploration includes alpha=0.30 to expose the security boundary.
%   * Online deployment remains restricted to alpha in [0.60,1.00].
%   * Fresh 10bus/33bus paper datasets treat ALL six offline alpha levels
%     identically in every trajectory.
%   * For the existing 18bus paper dataset (which already contains
%     alpha=0.60:0.10:1.00), missing alpha=0.30 rows are generated with the
%     SAME five irradiance levels and SAME two paper seeds.  A matched-parity
%     schedule places alpha=0.30 about as often per trajectory as each legacy
%     alpha appeared previously, and only the new alpha=0.30 rows are merged.
%     Thus the final 18bus alpha bins remain approximately balanced without
%     rerunning/recounting the already available 0.60:1.00 samples.
cfg.ai.response.profile = 'paper';
cfg.ai.response.systemCases = {'33bus'}; % train current grid; set all three radial cases later
cfg.ai.response.baselineID = 'T7';
cfg.ai.response.securityTarget = 'coi';
cfg.ai.response.saveIntermediate = false;

% Offline exploration can be wider than the deployed controller.
cfg.ai.response.trainingAlphaMin = 0.30;
cfg.ai.response.trainingAlphaMax = 1.00;
cfg.ai.response.alphaLevels = [0.30 0.60 0.70 0.80 0.90 1.00];
cfg.ai.response.scheduleMode = 'balanced-random';

% Reuse previously generated response datasets whenever their physics/model
% contract matches. Missing alpha levels are appended instead of rerunning
% already available trajectories.
cfg.ai.response.incrementalReuseExistingDataset = true;
% Fresh six-level paper trajectories provide about 155-160 rows/alpha.  Use
% 140 as a conservative minimum after finite-row filtering.
cfg.ai.response.minSamplesPerExistingAlpha = 140;

% Matched final-paper enrichment for a missing alpha level (currently 0.30
% in the existing 18bus dataset).  Use exactly the same paper scenario box as
% the old alpha levels: five irradiance levels x two seeds.
cfg.ai.response.parity.enabled = true;
cfg.ai.response.parity.decayRatios = [0.20 0.40 0.60 0.80 1.00];
cfg.ai.response.parity.randomSeeds = 0:1;
cfg.ai.response.parity.referenceExistingAlphaLevels = [0.60 0.70 0.80 0.90 1.00];
% In the original five-level dataset each alpha appeared about 1/5 of the 96
% intervals in every trajectory.  Preserve that exposure for alpha=0.30.
cfg.ai.response.parity.targetCountPerTrajectory = ...
    round(cfg.mpc.decisionLevelSteps/numel(cfg.ai.response.parity.referenceExistingAlphaLevels));
cfg.ai.response.parity.saveIntermediate = false;

% Robust long-running training-data generation.  Keep only compact retained
% response rows in a resumable checkpoint after every completed trajectory;
% do not save the huge 86,400-point per-trajectory result unless explicitly
% requested.  If a randomized alpha schedule causes a closed-loop MPC
% infeasibility, retry the SAME decay/physical-seed scenario with a different
% alpha permutation rather than discarding all previously completed work.
cfg.ai.response.resumePartialGeneration = true;
cfg.ai.response.checkpointEveryTrajectory = true;
cfg.ai.response.maxTrajectoryRetries = 3;
cfg.ai.response.retryScheduleSeedStride = 104729; % prime stride -> new permutation
cfg.ai.response.deleteCheckpointOnSuccess = true;

switch lower(cfg.ai.response.profile)
    case 'quick'
        % Pipeline/proof-of-concept profile only.
        cfg.ai.response.decayRatios = [0.20 0.60 1.00];
        cfg.ai.response.randomSeeds = 0;
    case 'paper'
        % FINAL profile: 5 irradiance levels x 2 randomized/noise seeds =
        % 10 trajectories/grid.  Fresh grids balance all six alpha levels.
        cfg.ai.response.decayRatios = [0.20 0.40 0.60 0.80 1.00];
        cfg.ai.response.randomSeeds = 0:1;
    otherwise
        error('Unknown cfg.ai.response.profile: %s',cfg.ai.response.profile);
end

% ----- Solver diagnostics / performance -----------------------------------
% Do not relax optimization tolerances by default.  The diagnostic layer
% records coneprog exit flags and numerical residuals so exitflag -7 can be
% assessed explicitly instead of being silently treated as a success.
cfg.solver.coneprogDisplay = 'none';       % suppress repetitive solver text
cfg.solver.coneprogLinearSolver = 'auto'; % sparse data -> MATLAB sparse-oriented solver
cfg.solver.enableConditioningRetry = true;
cfg.solver.retryLinearSolver = 'normal';
cfg.solver.retryDualThreshold = 1e-3; % retry only materially poor -7 dual residuals

cfg.diagnostics.solver.residualTolerance = 1e-6;
cfg.diagnostics.solver.dualTolerance = 1e-5;
cfg.diagnostics.solver.relativeGapTolerance = 1e-6;
cfg.diagnostics.solver.printMinus7Table = true;
% Full manual cone residual reconstruction is expensive for a 96-stage SOCP.
% By default it is limited to the first few -7 warnings; coneprog's own
% primal/dual/gap fields are still recorded for every solve.
cfg.diagnostics.solver.manualResidualMaxWarningSteps = 3;
% Progress logging is off for formal runs and enabled explicitly by smoke tests.
cfg.diagnostics.progress.enabled = false;
cfg.diagnostics.progress.everyN = 1;
cfg.diagnostics.showSmokePlots = true;
cfg.diagnostics.computeRelaxationGap = false; % legacy SOCP-gap audit; expensive and not needed for new smoke/AI study

% Safe implementation optimizations that do not alter the physical model:
% avoid rebuilding unused solver options and avoid no-op interpolation when
% the MPC prediction and execution grids are identical.
cfg.performance.fastPhysicalKernel = true;
% Cache all time-invariant radial SOCP matrices/cones and use sparse dynamic
% constraints. This applies to every MPC-SOCP case, not only smoke tests.
cfg.performance.cacheStaticMPCSOCP = true;
cfg.performance.useSparseSOCConstraints = true;

% ----- Output -------------------------------------------------------------
cfg.output.root = 'outputs';
% Formal experiment runs persist results by default. Informal/smoke tests
% must explicitly set this false so they do not create files under outputs/.
cfg.output.saveResults = true;
% cfg.output.runTag = datestr(now,'yyyymmdd_HHMMSS');
cfg.output.runTag = '20260910_finalP1_33bus';
cfg.output.showFigures = false;
cfg.output.exportFigures = false;
cfg.output.fontSize = 10;
cfg.output.writeSummaryCSV = true;
end
