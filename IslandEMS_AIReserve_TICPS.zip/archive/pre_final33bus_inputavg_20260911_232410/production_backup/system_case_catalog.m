function sys = system_case_catalog(caseName,cfg)
%SYSTEM_CASE_CATALOG Physical test-system definitions used by the EMS study.
% External case identifiers are descriptive names only:
%   10bus, 10bus_loop, 18bus, 18bus_loop, 33bus, 33bus_loop.
% The former numeric case codes (1, 1.5, ..., 3.5) are intentionally removed.
%
% All power ratings are in MW. Loads are passed to busdata.m as positive
% magnitudes; busdata converts them to negative network injections.
%
% IMPORTANT: sys.Topology is an internal network-data key retained for
% linedata.m compatibility. sys.CaseName is the user-facing case name.

caseName = char(lower(strtrim(string(caseName))));
nEV = cfg.ev.numberPerResidentialBus;
sys = struct();
sys.CaseName = caseName;

switch caseName
    case '10bus'
        sys.Topology = '10bus';
        sys.BusNum = 10;
        sys.k_branch = 0.93;

        sys.BusOfDieselG_GFM = 1;
        sys.BusOfBatteryGFM = [];
        sys.MainGFM = 0;
        sys.BusOfBattery = 10;
        sys.BusOfPV = 10;
        sys.residential_node = [2 4 6 8 9];
        sys.business_node = [5 7];
        sys.BusOfEVBattery = [2 4 6 8 9];

        sys.DieselG_Pgfm_rate = 0.14;
        sys.BatteryGFL_P_rate = 0.10;
        sys.PVInv_P_rateIn = 0.20;
        sys.residentialPower = [0.010;0.0145;0.0165;0.0185;0.025];
        sys.businessPower = [0.045;0.055];
        sys.BatteryEV_P_rate = nEV*0.007*ones(numel(sys.BusOfEVBattery),1);

        sys.brhID = 8;
        sys.busID = 9;

    case '10bus_loop'
        sys = system_case_catalog('10bus',cfg);
        sys.CaseName = caseName;
        sys.Topology = '10bus_loop';

    case '18bus'
        sys.Topology = '18bus-CIRED';
        sys.BusNum = 18;
        sys.k_branch = 0.80;

        sys.BusOfDieselG_GFM = [1 10];
        sys.BusOfBatteryGFM = [];
        sys.MainGFM = [0 0];
        sys.BusOfBattery = [15 16 18];
        sys.BusOfPV = [15 16];
        sys.residential_node = [3:5 6 7:9 11 12:14];
        sys.business_node = [2 17];
        sys.BusOfEVBattery = sys.residential_node;

        sys.DieselG_Pgfm_rate = [0.14 0.14];
        sys.BatteryGFL_P_rate = [0.10 0.10 0.10];
        sys.PVInv_P_rateIn = [0.20 0.15];
        % Randomized rated residential loads are retained from the uploaded
        % experiment. runCfg.randomSeed makes this reproducible per run.
        sys.residentialPower = (0.010 + 0.015*rand(numel(sys.residential_node),1));
        sys.businessPower = [0.060;0.100];
        sys.BatteryEV_P_rate = nEV*0.007*ones(numel(sys.BusOfEVBattery),1);

        sys.brhID = 9;
        sys.busID = 18;

    case '18bus_loop'
        sys = system_case_catalog('18bus',cfg);
        sys.CaseName = caseName;
        sys.Topology = '18bus-CIRED_loop';

    case '33bus'
        sys.Topology = '33bus-IEEE';
        sys.BusNum = 33;
        sys.k_branch = 0.80;

        sys.BusOfDieselG_GFM = [1 18 33];
        sys.BusOfBatteryGFM = [];
        sys.MainGFM = [0 0 0];
        sys.BusOfBattery = [10 22 25 33];
        sys.BusOfPV = [10 22 25 33];
        sys.residential_node = [1:9 11:17 19:21 23:24 26:32];
        sys.business_node = [18 22 25 33];
        sys.BusOfEVBattery = sys.residential_node;

        sys.DieselG_Pgfm_rate = [0.15;0.15;0.15];
        sys.BatteryGFL_P_rate = [0.20;0.15;0.15;0.15];
        sys.PVInv_P_rateIn = [0.25;0.20;0.20;0.25];
        sys.residentialPower = (0.005 + 0.015*rand(numel(sys.residential_node),1));
        sys.businessPower = [0.050;0.045;0.045;0.050];
        sys.BatteryEV_P_rate = nEV*0.007*ones(numel(sys.BusOfEVBattery),1);

        sys.brhID = 16;
        sys.busID = 22;

    case '33bus_loop'
        sys = system_case_catalog('33bus',cfg);
        sys.CaseName = caseName;
        sys.Topology = '33bus-IEEE_loop';

    otherwise
        error(['Unsupported system case ''%s''. Valid names are: ', ...
            '10bus, 10bus_loop, 18bus, 18bus_loop, 33bus, 33bus_loop.'],caseName);
end

% No GFM-BESS units are used in the current three benchmark families.
sys.BatteryGFM_P_rate=[];

% Shared DER-interface parameters.
sys.Xm_g_battGFM = 0.15;
sys.Xm_g_batt = 0.15;
sys.Xm_g_solar = 0.15;
sys.Xm_g_EVbatt = 0.15;
end
