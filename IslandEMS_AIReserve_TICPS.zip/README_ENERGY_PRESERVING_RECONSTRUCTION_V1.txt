ENERGY-PRESERVING CONTINUOUS RECONSTRUCTION TEST V1
===================================================

Core formula
------------
For current interval k:

b_k     = (u_{k-1}+u_k)/2
b_{k+1} = (u_k+u_{k+1})/2
xi      = (t-t_k)/DeltaT

u_exe(xi)
 = (1-xi)b_k + xi b_{k+1}
   + 6 xi(1-xi)[u_k-(b_k+b_{k+1})/2]

Properties
----------
1) continuous across interval boundaries;
2) interval average exactly equals u_k in continuous time;
3) no arbitrary smoothing window parameter;
4) zero extra MPC solves;
5) no KRR/model/training/alpha changes.

Files
-----
tests/
  test_F1_33bus_energy_preserving_reconstruction_v1.m

tools/
  common_energy_preserving_reconstruction_v1.m
  restore_energy_preserving_reconstruction_engine_v1.m

Preflight
---------
clear functions
rehash
addpath(genpath(pwd))
Rpre = test_F1_33bus_energy_preserving_reconstruction_v1(pwd,false);

Run one F1 screen only if PASS
------------------------------
Rrec = test_F1_33bus_energy_preserving_reconstruction_v1(pwd,true);

Expected runtime
----------------
Approximately one normal 33-bus case: ~50-55 minutes.

Safety
------
The production engine is backed up before patching. An onCleanup restoration
guard is installed before source modification. After simulation, production
is restored BEFORE result persistence.

Emergency restore
-----------------
If MATLAB/Windows is force-killed while the temporary patch is active:

Rrestore = restore_energy_preserving_reconstruction_engine_v1(pwd);
