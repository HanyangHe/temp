function [feature,meta] = build_reserve_features(Sload,P_PV,DGPrate,dgUpHeadroom_pu)
%BUILD_RESERVE_FEATURES Frozen KRR state features + forecast guard metadata.
%
% Frozen KRR feature vector:
%   [Pnet_now, |Delta Pnet|, SG upward headroom]
%
% All terms are normalized by aggregate SG active-power rating.
%
% The optional META output exposes decision-time forecast quantities for the
% final P1 forecast-aware guard. These quantities are NOT added to the KRR
% feature vector and therefore do not require retraining the existing model.
%
%   meta.netLoadNow_pu
%   meta.signedNetRampForecast_pu = (Pnet_next-Pnet_now)/PdgRated
%   meta.netDropForecast_pu       = max(Pnet_now-Pnet_next,0)/PdgRated
%   meta.absNetRampForecast_pu
%
% Sload and P_PV are forecast trajectories available BEFORE the current MPC
% solve. dgUpHeadroom_pu is computed from the last realized SG output.

Pload = max(-sum(real(Sload),1,'omitnan'),0);
Ppv   = max( sum(real(P_PV),1,'omitnan'),0);
PdgTot = max(sum(DGPrate(:)),eps);
net = Pload-Ppv;

if isempty(net)
    error('build_reserve_features:EmptyForecast', ...
        'Empty load/PV forecast trajectory.');
end

netNow_pu = net(1)/PdgTot;

if numel(net)>=2
    signedNetRampForecast_pu = (net(2)-net(1))/PdgTot;
    absNetRamp_pu = abs(signedNetRampForecast_pu);
else
    signedNetRampForecast_pu = 0;
    absNetRamp_pu = 0;
end

netDropForecast_pu = max(-signedNetRampForecast_pu,0);

if isempty(dgUpHeadroom_pu)
    dgUpHeadroom_pu = NaN;
end

if ~isscalar(dgUpHeadroom_pu)
    error('build_reserve_features:HeadroomShape', ...
        'dgUpHeadroom_pu must be scalar.');
end

feature = [netNow_pu,absNetRamp_pu,dgUpHeadroom_pu];

if any(~isfinite(feature(1:2)))
    error('build_reserve_features:NonfiniteForecastFeature', ...
        'Net-load operating/ramp features must be finite.');
end

if nargout>=2
    meta = struct();
    meta.netLoadNow_pu = netNow_pu;
    meta.signedNetRampForecast_pu = signedNetRampForecast_pu;
    meta.netDropForecast_pu = netDropForecast_pu;
    meta.absNetRampForecast_pu = absNetRamp_pu;
end
end
