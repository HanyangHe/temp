function alphaSchedule = make_matched_parity_alpha_schedule(nSteps,targetLevels,fillerLevels,targetCountPerLevel,seed)
%MAKE_MATCHED_PARITY_ALPHA_SCHEDULE Final-paper enrichment schedule.
% Places each missing/target alpha level a prescribed number of times in a
% trajectory, then fills the remaining intervals with already-observed alpha
% levels. The full schedule is shuffled so alpha is not tied to time of day.
%
% Typical current 18bus use:
%   targetLevels = 0.30
%   fillerLevels = [0.60 0.70 0.80 0.90 1.00]
%   targetCountPerLevel = round(96/5) = 19
% so alpha=0.30 receives the same ~1/5 per-trajectory exposure that each
% legacy alpha level received in the previous five-level paper dataset.

if nargin<5 || isempty(seed), seed=0; end
targetLevels=targetLevels(:).';
fillerLevels=fillerLevels(:).';
if isempty(targetLevels) || any(~isfinite(targetLevels))
    error('targetLevels must be nonempty and finite.');
end
if isempty(fillerLevels) || any(~isfinite(fillerLevels))
    error('fillerLevels must be nonempty and finite.');
end
if ~isscalar(nSteps) || nSteps<1 || mod(nSteps,1)~=0
    error('nSteps must be a positive integer.');
end
if ~isscalar(targetCountPerLevel) || targetCountPerLevel<1 || mod(targetCountPerLevel,1)~=0
    error('targetCountPerLevel must be a positive integer.');
end
nTarget=targetCountPerLevel*numel(targetLevels);
if nTarget>=nSteps
    error('Requested target-alpha quota leaves no room for filler levels.');
end

baseTarget=repelem(targetLevels,targetCountPerLevel);
nFill=nSteps-numel(baseTarget);
baseFill=repmat(fillerLevels,1,ceil(nFill/numel(fillerLevels)));
baseFill=baseFill(1:nFill);
base=[baseTarget baseFill];

state=rng;
cleanup=onCleanup(@()rng(state)); %#ok<NASGU>
rng(double(seed),'twister');
alphaSchedule=base(randperm(nSteps));
alphaSchedule=reshape(alphaSchedule,1,[]);
end
