function names = reserve_feature_names()
%RESERVE_FEATURE_NAMES Formal AI-reserve input contract.
% The revised TICPS model intentionally uses only three first-principles,
% decision-time features:
%   1) current forecast net-load operating point;
%   2) magnitude of the near-term forecast net-load ramp;
%   3) measured SG upward headroom immediately BEFORE the new MPC solve.
%
% EV availability, time proxies, PV-specific ramp, and BESS SoC are not
% part of the formal learner after the feature-screening/ablation tests.
names = { ...
    'netLoadNow_pu', ...
    'absNetLoadRamp_pu', ...
    'dgUpHeadroom_pu'};
end
