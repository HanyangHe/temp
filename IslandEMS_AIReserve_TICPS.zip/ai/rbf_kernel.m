function K = rbf_kernel(X1,X2,sigma)
%RBF_KERNEL Squared-exponential kernel without toolbox dependencies.
if sigma<=0, error('sigma must be positive.'); end
n1=sum(X1.^2,2); n2=sum(X2.^2,2).';
D2=max(n1+n2-2*(X1*X2.'),0);
K=exp(-D2/(2*sigma^2));
end
