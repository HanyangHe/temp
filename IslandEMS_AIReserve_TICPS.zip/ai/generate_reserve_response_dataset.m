function [dataset,datasetFile] = generate_reserve_response_dataset(cfg,projectRoot)
%GENERATE_RESERVE_RESPONSE_DATASET Closed-loop randomized-alpha response data.
%
% Efficient learning scheme:
%   [Pnet_k, |Delta Pnet_k|, DG upward headroom_k, alpha_k] -> stress_k
%
% Robustness for long paper-data runs:
%   * compact checkpoint after every completed trajectory;
%   * restart skips completed (decay, physical-seed) scenarios;
%   * an infeasible randomized schedule is retried with a new alpha
%     permutation for the SAME physical scenario;
%   * only retained training rows are checkpointed (not 86,400-point traces).

caseNames=string(cfg.ai.response.systemCases);
if numel(caseNames)~=1
    error('generate_reserve_response_dataset:PerGridOnly', ...
        'Generate/train one response dataset/model per grid case.');
end
caseName=char(caseNames(1));
if ~strcmpi(cfg.ai.response.securityTarget,'coi')
    error('Formal response target must be CoI/system frequency.');
end

catalog=baseline_catalog(); ids=string({catalog.id});
base=catalog(ids==string(cfg.ai.response.baselineID));
if isempty(base), error('Response baseline %s not found.',cfg.ai.response.baselineID); end
base=base(1);

alphaLevels=sort(unique(cfg.ai.response.alphaLevels(:).'));
if alphaLevels(1)<cfg.ai.response.trainingAlphaMin-1e-12 || ...
        alphaLevels(end)>cfg.ai.response.trainingAlphaMax+1e-12
    error('Exploration alpha levels must lie inside offline training range [%.2f, %.2f].', ...
        cfg.ai.response.trainingAlphaMin,cfg.ai.response.trainingAlphaMax);
end
scheduleMode=lower(string(cfg.ai.response.scheduleMode));
retainAlphaLevels=[];
if isfield(cfg.ai.response,'retainAlphaLevels') && ~isempty(cfg.ai.response.retainAlphaLevels)
    retainAlphaLevels=sort(unique(cfg.ai.response.retainAlphaLevels(:).'));
end
if scheduleMode=="matched-paper-parity"
    req={'parityTargetAlphaLevels','parityFillerAlphaLevels','parityTargetCountPerTrajectory'};
    for ir=1:numel(req)
        if ~isfield(cfg.ai.response,req{ir})
            error('Matched-paper-parity generation missing cfg.ai.response.%s.',req{ir});
        end
    end
    targetLevels=sort(unique(cfg.ai.response.parityTargetAlphaLevels(:).'));
    fillerLevels=sort(unique(cfg.ai.response.parityFillerAlphaLevels(:).'));
    if isempty(retainAlphaLevels), retainAlphaLevels=targetLevels; end
else
    targetLevels=[]; fillerLevels=[];
end

stamp=datestr(now,'yyyymmdd_HHMMSS');
trainRoot=fullfile(projectRoot,cfg.output.root, ...
    sprintf('training_%s_response_%s',lower(caseName),stamp));
if ~exist(trainRoot,'dir'), mkdir(trainRoot); end

nSteps=cfg.mpc.decisionLevelSteps;
resumeEnabled=get_bool(cfg.ai.response,'resumePartialGeneration',true);
checkpointEvery=get_bool(cfg.ai.response,'checkpointEveryTrajectory',true);
maxRetries=max(1,round(get_num(cfg.ai.response,'maxTrajectoryRetries',3)));
retryStride=round(get_num(cfg.ai.response,'retryScheduleSeedStride',104729));
deleteOnSuccess=get_bool(cfg.ai.response,'deleteCheckpointOnSuccess',true);

checkpointRoot=fullfile(projectRoot,cfg.output.root,'training_checkpoints');
if ~exist(checkpointRoot,'dir'), mkdir(checkpointRoot); end
checkpointFile=fullfile(checkpointRoot,sprintf('%s_%s_%s_response_checkpoint.mat', ...
    lower(caseName),lower(char(cfg.ai.response.profile)),lower(char(scheduleMode))));
checkpointSignature=make_generation_signature(cfg,caseName,scheduleMode,alphaLevels, ...
    targetLevels,fillerLevels,retainAlphaLevels,nSteps);

state=empty_generation_state();
if resumeEnabled && exist(checkpointFile,'file')
    C=load(checkpointFile,'checkpoint');
    if isfield(C,'checkpoint') && isfield(C.checkpoint,'signature') && ...
            isequaln(C.checkpoint.signature,checkpointSignature)
        state=C.checkpoint.state;
        fprintf('[%s] Resuming compact response-generation checkpoint:\n  %s\n',caseName,checkpointFile);
        fprintf('  recovered retained rows %d | completed trajectories %d\n', ...
            size(state.Xstate,1),numel(state.completedScenarioKeys));
    else
        warning('[%s] Ignoring stale/incompatible response-generation checkpoint.',caseName);
        try delete(checkpointFile); catch, end %#ok<CTCH>
    end
end

fprintf('\n=============================================================\n');
fprintf(' RANDOMIZED-ALPHA FREQUENCY-RESPONSE DATA GENERATION\n');
fprintf(' grid            : %s\n',caseName);
fprintf(' profile         : %s\n',cfg.ai.response.profile);
fprintf(' schedule mode   : %s\n',char(scheduleMode));
fprintf(' alpha contract  : %s\n',mat2str(alphaLevels));
if scheduleMode=="matched-paper-parity"
    fprintf(' parity target   : %s (%d slots/trajectory)\n', ...
        mat2str(targetLevels),cfg.ai.response.parityTargetCountPerTrajectory);
    fprintf(' parity filler   : %s\n',mat2str(fillerLevels));
    fprintf(' retained rows   : %s only\n',mat2str(retainAlphaLevels));
end
fprintf(' state features  : %s\n',strjoin(reserve_feature_names(),', '));
fprintf(' target          : normalized CoI frequency stress\n');
fprintf(' trajectories    : %d\n',numel(cfg.ai.response.decayRatios)*numel(cfg.ai.response.randomSeeds));
fprintf(' per-alpha sweep : NONE\n');
fprintf(' checkpoint      : %s\n',ternary(resumeEnabled,'ON (resume supported)','OFF'));
fprintf(' schedule retries: %d max / trajectory\n',maxRetries);
fprintf('=============================================================\n\n');

scenarioIndex=0;
unresolved={};
for decay=cfg.ai.response.decayRatios(:).'
    for seed=cfg.ai.response.randomSeeds(:).'
        scenarioIndex=scenarioIndex+1;
        scenarioKey=sprintf('decay%.6f_seed%d',decay,seed);
        if any(strcmp(state.completedScenarioKeys,scenarioKey))
            fprintf('[%s] response trajectory %d: decay %.2f seed %d -> checkpointed, SKIP\n', ...
                caseName,scenarioIndex,decay,seed);
            continue
        end

        baseScheduleSeed=round(100000*decay)+1009*double(seed)+7919*scenarioIndex;
        success=false;
        lastME=[];
        for attempt=1:maxRetries
            scheduleSeed=baseScheduleSeed+(attempt-1)*retryStride;
            alphaSchedule=build_schedule(scheduleMode,nSteps,alphaLevels,targetLevels, ...
                fillerLevels,cfg.ai.response,scheduleSeed);

            runCfg=base;
            runCfg.reserveMode='scheduled';
            runCfg.reserveFixedRatio=NaN;
            runCfg.reserveAlphaSchedule=alphaSchedule;
            runCfg.caseName=caseName;
            runCfg.dayType='Unusual day';
            runCfg.decayRatio=decay;
            runCfg.randomSeed=seed;

            if attempt==1
                fprintf('[%s] response trajectory %d: decay %.2f seed %d\n', ...
                    caseName,scenarioIndex,decay,seed);
            else
                fprintf('  retry %d/%d with new alpha permutation (scheduleSeed=%d)\n', ...
                    attempt,maxRetries,scheduleSeed);
            end
            tRun=tic;
            try
                r=run_single_experiment(cfg,runCfg,projectRoot,trainRoot, ...
                    logical(cfg.ai.response.saveIntermediate));
                close all force;
                elapsed=toc(tRun);
                success=true;
            catch ME
                close all force;
                elapsed=toc(tRun);
                lastME=ME;
                if is_retryable_trajectory_failure(ME)
                    failStep=parse_failed_mpc_step(ME.message);
                    if isfinite(failStep) && failStep>=1 && failStep<=numel(alphaSchedule)
                        failAlpha=alphaSchedule(failStep);
                        fprintf(2,['  trajectory attempt failed after %.2f min: %s\n', ...
                            '  failed MPC step %d used alpha %.3f; compact prior checkpoint remains intact.\n'], ...
                            elapsed/60,first_line(ME.message),failStep,failAlpha);
                    else
                        fprintf(2,'  trajectory attempt failed after %.2f min: %s\n', ...
                            elapsed/60,first_line(ME.message));
                    end
                    if attempt<maxRetries
                        continue
                    end
                else
                    rethrow(ME)
                end
            end

            if success
                [state,gm]=append_completed_run(state,r,cfg,alphaSchedule,alphaLevels, ...
                    retainAlphaLevels,scenarioIndex,decay,seed,scheduleSeed,elapsed,nSteps);
                state.completedScenarioKeys{end+1}=scenarioKey;
                state.failedScenarioKeys(strcmp(state.failedScenarioKeys,scenarioKey))=[];
                fprintf('  finished %.2f min | usable rows %d | max stress %.3f | attempt %d\n', ...
                    elapsed/60,gm.usableSamples,gm.maxStress,attempt);
                if checkpointEvery
                    save_checkpoint(checkpointFile,checkpointSignature,state);
                    fprintf('  checkpointed retained data: %d rows | %d/%d trajectories complete\n', ...
                        size(state.Xstate,1),numel(state.completedScenarioKeys), ...
                        numel(cfg.ai.response.decayRatios)*numel(cfg.ai.response.randomSeeds));
                end
                break
            end
        end

        if ~success
            state.failedScenarioKeys{end+1}=scenarioKey;
            unresolved{end+1}=scenarioKey; %#ok<AGROW>
            if checkpointEvery, save_checkpoint(checkpointFile,checkpointSignature,state); end
            fprintf(2,['[%s] UNRESOLVED trajectory decay %.2f seed %d after %d schedule attempts.\n', ...
                'Completed trajectories are preserved. Re-run train_AIReserve after diagnosing this scenario.\n'], ...
                caseName,decay,seed,maxRetries);
            if ~isempty(lastME)
                fprintf(2,'  last error: %s\n',first_line(lastME.message));
            end
        end
    end
end

if ~isempty(unresolved)
    error('generate_reserve_response_dataset:UnresolvedTrajectories', ...
        ['Paper response generation is incomplete for: %s. Compact progress is saved at:\n%s\n', ...
         'Re-running train_AIReserve will skip completed trajectories and retry only the unresolved scenarios.'], ...
        strjoin(unresolved,', '),checkpointFile);
end

if isempty(state.Xstate)
    error('generate_reserve_response_dataset:NoSamples', ...
        'No finite causal response samples were generated.');
end

dataset=state_to_dataset(state,cfg,caseName,scheduleMode,retainAlphaLevels,scenarioIndex);
datasetFile=fullfile(trainRoot,'reserve_response_dataset.mat');
save(datasetFile,'dataset','-v7.3');
fprintf('\nSaved randomized-alpha response dataset:\n  %s\n',datasetFile);
fprintf('Samples %d | groups %d | safe %.1f%% | stress range [%.3f, %.3f]\n', ...
    size(dataset.X,1),numel(unique(dataset.groupID)),100*mean(dataset.secure), ...
    min(dataset.yStress),max(dataset.yStress));

if deleteOnSuccess && exist(checkpointFile,'file')
    delete(checkpointFile);
    fprintf('Completed checkpoint removed: %s\n',checkpointFile);
end
end

% -------------------------------------------------------------------------
function alphaSchedule=build_schedule(scheduleMode,nSteps,alphaLevels,targetLevels,fillerLevels,responseCfg,scheduleSeed)
switch char(scheduleMode)
    case 'balanced-random'
        alphaSchedule=make_balanced_alpha_schedule(nSteps,alphaLevels,scheduleSeed);
    case 'matched-paper-parity'
        alphaSchedule=make_matched_parity_alpha_schedule(nSteps,targetLevels, ...
            fillerLevels,responseCfg.parityTargetCountPerTrajectory,scheduleSeed);
    otherwise
        error('Unsupported response schedule mode: %s',char(scheduleMode));
end
end

function [state,gm]=append_completed_run(state,r,cfg,alphaSchedule,alphaLevels,retainAlphaLevels,groupID,decay,seed,scheduleSeed,elapsed,nSteps)
F=r.reserve.features;
a=r.reserve.ratio(:);
df=r.interval.maxAbsFreqDev_Hz(:);
rc=r.interval.maxAbsRoCoF_Hz_s(:);
n=min([size(F,1),numel(a),numel(df),numel(rc),nSteps]);
F=F(1:n,:); a=a(1:n); df=df(1:n); rc=rc(1:n);
stress=max(df/cfg.frequency.securityDeviation_Hz, ...
           rc/cfg.frequency.securityRoCoF_Hz_s);
valid=all(isfinite(F),2) & isfinite(a) & isfinite(stress) & ...
    a>=cfg.ai.response.trainingAlphaMin-1e-12 & ...
    a<=cfg.ai.response.trainingAlphaMax+1e-12;
if ~isempty(retainAlphaLevels)
    keep=false(size(a));
    for ik=1:numel(retainAlphaLevels)
        keep=keep | abs(a-retainAlphaLevels(ik))<1e-12;
    end
    valid=valid & keep;
end
idx=find(valid);
state.Xstate=[state.Xstate;F(idx,:)];
state.alphaAll=[state.alphaAll;a(idx)];
state.stressAll=[state.stressAll;stress(idx)];
state.dfAll=[state.dfAll;df(idx)];
state.rocofAll=[state.rocofAll;rc(idx)];
state.groupID=[state.groupID;groupID*ones(numel(idx),1)];
state.decayAll=[state.decayAll;decay*ones(numel(idx),1)];
state.seedAll=[state.seedAll;seed*ones(numel(idx),1)];
state.intervalAll=[state.intervalAll;idx(:)];
state.timeAll=[state.timeAll;(idx(:)-1)*cfg.mpc.decisionInterval_h];
counts=arrayfun(@(x)sum(abs(alphaSchedule-x)<1e-12),alphaLevels);
gm=struct('groupID',groupID,'decayRatio',decay,'randomSeed',seed, ...
    'scheduleSeed',scheduleSeed,'alphaSchedule',alphaSchedule, ...
    'alphaLevels',alphaLevels,'alphaCounts',counts, ...
    'usableSamples',numel(idx),'elapsed_s',elapsed,'totalCost',r.totalCost, ...
    'maxStress',max(stress,[],'omitnan'));
if isempty(state.groupMeta), state.groupMeta=gm; else, state.groupMeta(end+1)=gm; end
end

function dataset=state_to_dataset(state,cfg,caseName,scheduleMode,retainAlphaLevels,nScenarioBox)
X=[state.Xstate state.alphaAll];
stateNames=reserve_feature_names();
inputNames=[stateNames {'reserveRatio'}];
dataset=struct();
dataset.kind='IslandEMSFrequencyStressResponseDatasetV1';
dataset.caseName=caseName;
dataset.stateFeatureNames=stateNames;
dataset.inputNames=inputNames;
dataset.Xstate=state.Xstate;
dataset.alpha=state.alphaAll;
dataset.X=X;
dataset.yStress=state.stressAll;
dataset.maxAbsFreqDev_Hz=state.dfAll;
dataset.maxAbsRoCoF_Hz_s=state.rocofAll;
dataset.secure=state.stressAll<=1;
dataset.groupID=state.groupID;
dataset.decayRatio=state.decayAll;
dataset.randomSeed=state.seedAll;
dataset.intervalIndex=state.intervalAll;
dataset.time_h=state.timeAll;
dataset.groupMeta=state.groupMeta;
dataset.alphaLevels=sort(unique(state.alphaAll(:))).';
dataset.scheduleMode=char(scheduleMode);
dataset.retainedAlphaLevels=retainAlphaLevels;
dataset.securityLimits=struct('df_Hz',cfg.frequency.securityDeviation_Hz, ...
    'rocof_Hz_s',cfg.frequency.securityRoCoF_Hz_s);
dataset.created=datestr(now,30);
dataset.trainingSignature=ai_reserve_model_signature(cfg,caseName);
levels=dataset.alphaLevels;
counts=zeros(numel(levels),1);
for i=1:numel(levels), counts(i)=sum(abs(state.alphaAll-levels(i))<1e-12); end
dataset.summary=struct('nSamples',size(X,1),'nGroups',numel(unique(state.groupID)), ...
    'scenarioBoxSize',nScenarioBox,'safeFraction',mean(dataset.secure), ...
    'stressMean',mean(state.stressAll),'stressMax',max(state.stressAll), ...
    'alphaCounts',counts);
end

function state=empty_generation_state()
state=struct('Xstate',[],'alphaAll',[],'stressAll',[],'dfAll',[],'rocofAll',[], ...
    'groupID',[],'decayAll',[],'seedAll',[],'intervalAll',[],'timeAll',[], ...
    'groupMeta',struct([]),'completedScenarioKeys',{{}},'failedScenarioKeys',{{}});
end

function sig=make_generation_signature(cfg,caseName,scheduleMode,alphaLevels,targetLevels,fillerLevels,retainAlphaLevels,nSteps)
sig=struct();
sig.version='ResponseGenerationCheckpointV2';
sig.caseName=caseName;
sig.profile=char(cfg.ai.response.profile);
sig.scheduleMode=char(scheduleMode);
sig.alphaLevels=alphaLevels;
sig.targetLevels=targetLevels;
sig.fillerLevels=fillerLevels;
sig.retainAlphaLevels=retainAlphaLevels;
sig.decayRatios=cfg.ai.response.decayRatios(:).';
sig.randomSeeds=cfg.ai.response.randomSeeds(:).';
sig.nSteps=nSteps;
sig.decisionInterval_h=cfg.mpc.decisionInterval_h;
sig.reserveDeviation_Hz=cfg.frequency.reserveDeviation_Hz;
sig.securityDeviation_Hz=cfg.frequency.securityDeviation_Hz;
sig.securityRoCoF_Hz_s=cfg.frequency.securityRoCoF_Hz_s;
sig.featureNames=reserve_feature_names();
if scheduleMode=="matched-paper-parity"
    sig.parityTargetCountPerTrajectory=cfg.ai.response.parityTargetCountPerTrajectory;
else
    sig.parityTargetCountPerTrajectory=[];
end
end

function save_checkpoint(fileName,signature,state)
checkpoint=struct('signature',signature,'state',state,'updated',datestr(now,30)); %#ok<NASGU>
tmp=[fileName '.tmp.mat'];
save(tmp,'checkpoint','-v7.3');
if exist(fileName,'file'), delete(fileName); end
movefile(tmp,fileName,'f');
end

function tf=is_retryable_trajectory_failure(ME)
msg=lower(ME.message);
tf=contains(msg,'exitflag=-2') || contains(msg,'problem is infeasible') || ...
   contains(msg,'problem infeasible') || contains(msg,'问题不可行') || ...
   contains(msg,'empty/nonfinite decision vector');
end

function k=parse_failed_mpc_step(msg)
tok=regexp(msg,'MPC-SOCP step\s+(\d+)','tokens','once');
if isempty(tok), k=NaN; else, k=str2double(tok{1}); end
end

function s=first_line(msg)
parts=regexp(msg,'\r?\n','split'); s=parts{1};
end

function v=get_bool(s,f,default)
if isfield(s,f), v=logical(s.(f)); else, v=default; end
end
function v=get_num(s,f,default)
if isfield(s,f), v=double(s.(f)); else, v=default; end
end
function out=ternary(cond,a,b)
if cond, out=a; else, out=b; end
end
