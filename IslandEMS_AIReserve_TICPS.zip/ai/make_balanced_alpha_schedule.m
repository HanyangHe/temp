function alphaSchedule = make_balanced_alpha_schedule(nSteps,alphaLevels,seed)
%MAKE_BALANCED_ALPHA_SCHEDULE Balanced randomized reserve-ratio exploration.
% Each alpha level appears as evenly as possible over the full day.  The
% permutation is independent of time-of-day so alpha is not a clock proxy.
% This schedule is used ONLY for offline response-data generation.

alphaLevels=alphaLevels(:).';
if isempty(alphaLevels) || any(~isfinite(alphaLevels))
    error('alphaLevels must be a nonempty finite vector.');
end
if ~isscalar(nSteps) || nSteps<1 || mod(nSteps,1)~=0
    error('nSteps must be a positive integer.');
end
if nargin<3 || isempty(seed), seed=0; end

nA=numel(alphaLevels);
base=repmat(alphaLevels,1,ceil(nSteps/nA));
base=base(1:nSteps);
state=rng;
cleanup=onCleanup(@()rng(state)); %#ok<NASGU>
rng(double(seed),'twister');
alphaSchedule=base(randperm(nSteps));
alphaSchedule=reshape(alphaSchedule,1,[]);
end
