function [dataset,datasetFile,msg] = find_latest_compatible_response_dataset(projectRoot,cfg,caseName)
%FIND_LATEST_COMPATIBLE_RESPONSE_DATASET Find best reusable dataset for a grid.
% Prefer the compatible file with the MOST samples (then newest on ties), so
% a small recently generated enrichment file never hides a larger prior paper
% dataset if a previous merge/training attempt was interrupted.
dataset=[]; datasetFile=''; msg='no prior response dataset found';

% 1) Prefer the canonical per-grid dataset published under ai/datasets/.
if isfield(cfg.ai,'datasetRoot') && isfield(cfg.ai,'datasetFileName')
    canonicalFile=get_ai_reserve_dataset_file(projectRoot,cfg,caseName);
    if exist(canonicalFile,'file')
        try
            S=load(canonicalFile,'dataset');
            [ok,reason]=response_dataset_merge_compatible(S.dataset,cfg,caseName);
            if ok
                dataset=S.dataset; datasetFile=canonicalFile;
                msg=sprintf('canonical compatible dataset found (%d rows)',size(dataset.X,1));
                return
            else
                msg=['canonical dataset incompatible: ' reason];
            end
        catch ME
            msg=['canonical dataset unreadable: ' ME.message];
        end
    end
end

% 2) Legacy fallback: scan outputs/training_* artifacts so existing studies
% can be migrated without rerunning expensive trajectories.
pattern=sprintf('training_%s_response_*',lower(char(caseName)));
D=dir(fullfile(projectRoot,cfg.output.root,pattern));
D=D([D.isdir]);
if isempty(D), return; end
candidates=struct('dataset',{},'file',{},'n',{},'datenum',{}); lastReason='';
for ii=1:numel(D)
    f=fullfile(D(ii).folder,D(ii).name,'reserve_response_dataset.mat');
    if ~exist(f,'file'), continue; end
    try
        S=load(f,'dataset');
        [ok,reason]=response_dataset_merge_compatible(S.dataset,cfg,caseName);
        if ok
            c=struct('dataset',S.dataset,'file',f,'n',size(S.dataset.X,1),'datenum',D(ii).datenum);
            candidates(end+1)=c; %#ok<AGROW>
        else
            lastReason=reason;
        end
    catch ME
        lastReason=ME.message;
    end
end
if isempty(candidates)
    if ~isempty(lastReason), msg=['no compatible dataset: ' lastReason]; end
    return
end
M=[[candidates.n]' [candidates.datenum]'];
[~,ord]=sortrows(M,[-1 -2]); best=candidates(ord(1));
dataset=best.dataset; datasetFile=best.file;
msg=sprintf('compatible dataset found (%d rows)',best.n);
end
