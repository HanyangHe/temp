function model = train_reserve_krr(dataset,aiCfg)
%TRAIN_RESERVE_KRR Train KRR frequency-stress response surface.
%
% Inputs are FOUR-dimensional for learning only:
%   [Pnet, |Delta Pnet|, DG upward headroom, candidate alpha].
% The first three entries are the frozen causal operating-state features;
% alpha is the queried reserve-control variable.  The target is normalized
% CoI frequency stress, not alpha*.  A one-sided calibration offset protects
% against stress underprediction.  Online alpha is selected by searching the
% calibrated response surface over cfg.ai.candidateAlphaGrid.

requiredKind='IslandEMSFrequencyStressResponseDatasetV1';
if ~isfield(dataset,'kind') || ~strcmp(dataset.kind,requiredKind)
    error(['Training dataset is not the randomized-alpha frequency-stress ', ...
        'response dataset. Regenerate it with train_AIReserve.m.']);
end
stateNames=reserve_feature_names();
expectedInputNames=[stateNames {'reserveRatio'}];
if ~isequal(string(dataset.stateFeatureNames(:)),string(stateNames(:))) || ...
        ~isequal(string(dataset.inputNames(:)),string(expectedInputNames(:)))
    error('Dataset feature/input contract does not match the frozen response model.');
end
X=dataset.X; y=dataset.yStress(:); group=dataset.groupID(:);
valid=all(isfinite(X),2) & isfinite(y) & y>=0;
X=X(valid,:); y=y(valid); group=group(valid);
if size(X,2)~=4 || size(X,1)<20
    error('Need at least 20 finite four-input response samples for KRR training.');
end
alphaObserved=sort(unique(X(:,4))).';
alphaCounts=arrayfun(@(a)sum(abs(X(:,4)-a)<1e-12),alphaObserved);
fprintf('Response alpha-bin counts used by KRR:\n');
disp(table(alphaObserved(:),alphaCounts(:),'VariableNames',{'Alpha','Count'}));
if min(alphaCounts)>0 && max(alphaCounts)/min(alphaCounts)>1.30
    warning(['Response alpha bins are imbalanced by more than 30%% (max/min=%.2f). ', ...
        'Consider matched-parity enrichment before final-paper training.'], ...
        max(alphaCounts)/min(alphaCounts));
end

rng(11,'twister');
ug=unique(group(:),'stable');
nG=numel(ug);
if nG>=3
    ug=ug(randperm(nG));
    if nG>=5
        nTe=max(1,round(0.20*nG));
        nCal=max(1,round(0.20*nG));
        nTr=nG-nTe-nCal;
    else
        % quick/pipeline profile: keep one whole trajectory for calibration
        % and one for held-out testing, even though training is small.
        nTr=max(1,nG-2); nCal=1; nTe=nG-nTr-nCal;
    end
    trG=ug(1:nTr);
    calG=ug(nTr+1:nTr+nCal);
    teG=ug(nTr+nCal+1:end);
    itr=ismember(group,trG); ical=ismember(group,calG); ite=ismember(group,teG);
else
    warning('Fewer than three trajectory groups; sample-level split is smoke-only.');
    n=size(X,1); ord=randperm(n);
    nTr=max(1,floor(0.70*n)); nCal=max(1,floor(0.15*n));
    if nTr+nCal>=n, nCal=max(0,n-nTr-1); end
    itr=false(n,1); ical=false(n,1); ite=false(n,1);
    itr(ord(1:nTr))=true;
    if nCal>0, ical(ord(nTr+1:nTr+nCal))=true; end
    ite(ord(nTr+nCal+1:end))=true;
    if ~any(ite), ite=itr; end
end

mu=mean(X(itr,:),1,'omitnan');
sig=std(X(itr,:),0,1,'omitnan'); sig(sig<1e-10)=1;
Xs=(X-mu)./sig;
Xtr=Xs(itr,:); ytr=y(itr); groupTr=group(itr);

% Standard KRR uses a dense nTrain-by-nTrain kernel matrix. At the present
% paper-scale datasets (~10^3 total samples/grid; typically ~6x10^2-9x10^2
% training rows after trajectory-group splitting) this is still small.
nTrain=size(Xtr,1);
kernelMemoryMB=8*double(nTrain)^2/1024^2;
fprintf('KRR training rows: %d | kernel matrix memory ~%.1f MB\n',nTrain,kernelMemoryMB);
if nTrain>3000
    warning(['KRR training set exceeds 3000 rows. Direct kernel solve may become expensive; ', ...
        'consider Nystrom/random-feature approximation before further scaling.']);
end

kernelSigma=aiCfg.kernelSigma;
lambda=aiCfg.lambda;
cvInfo=struct('used',false);
if isfield(aiCfg,'tuneHyperparameters') && aiCfg.tuneHyperparameters && ...
        numel(unique(groupTr))>=3
    [kernelSigma,lambda,cvRaw]=select_krr_hyperparameters( ...
        Xtr,ytr,groupTr,aiCfg.kernelSigmaGrid,aiCfg.lambdaGrid);
    cvInfo=cvRaw; cvInfo.used=true;
elseif isfield(aiCfg,'tuneHyperparameters') && aiCfg.tuneHyperparameters
    warning(['Grouped KRR tuning skipped because the TRAINING split has fewer ', ...
        'than three trajectory groups. Using configured fallback sigma/lambda.']);
end

K=rbf_kernel(Xtr,Xtr,kernelSigma);
coef=(K+lambda*eye(size(K)))\ytr;

model=struct();
model.type='physics-guided-frequency-stress-krr';
model.learningTarget='frequency-stress-response';
model.stateFeatureNames=stateNames;
model.inputNames=expectedInputNames;
model.mu=mu; model.sigma=sig;
model.stateMu=mu(1:3); model.stateSigma=sig(1:3);
model.Xtrain=Xtr; model.coef=coef;
model.trainStateZMin=min(Xtr(:,1:3),[],1);
model.trainStateZMax=max(Xtr(:,1:3),[],1);
model.kernelSigma=kernelSigma;
model.lambda=lambda;
model.hyperparameterCV=cvInfo;
model.alphaMin=aiCfg.alphaMin; model.alphaMax=aiCfg.alphaMax;
model.candidateAlphaGrid=aiCfg.candidateAlphaGrid(:).';
model.calibrationOffset=0;
model.split=struct('trainGroups',unique(group(itr)), ...
    'calibrationGroups',unique(group(ical)), 'testGroups',unique(group(ite)));
model.caseName=char(dataset.caseName);
model.responseSecurityTarget='coi';
model.created=datestr(now,30);

% Raw response predictions and one-sided calibration for stress
predTr=predict_frequency_stress(model,X(itr,1:3),X(itr,4));
predTeRaw=predict_frequency_stress(model,X(ite,1:3),X(ite,4));
if any(ical)
    predCal=predict_frequency_stress(model,X(ical,1:3),X(ical,4));
    underResidual=y(ical)-predCal; % positive => unsafe stress underprediction
    q=empirical_quantile(underResidual,1-aiCfg.calibrationRisk);
    model.calibrationOffset=max(q,0);
end
predTeCal=predTeRaw+model.calibrationOffset;

model.metrics.trainStressRMSE=sqrt(mean((predTr-y(itr)).^2,'omitnan'));
model.metrics.testStressRMSE=sqrt(mean((predTeRaw-y(ite)).^2,'omitnan'));
model.metrics.testStressMAE=mean(abs(predTeRaw-y(ite)),'omitnan');
model.metrics.testCalibrationCoverage=mean(y(ite)<=predTeCal,'omitnan');
model.metrics.testCalibrationMissRate=mean(y(ite)>predTeCal,'omitnan');
trueSafe=y(ite)<=1;
predSafeRaw=predTeRaw<=1;
predSafeCal=predTeCal<=1;
model.metrics.rawTestFalseSafeRate=mean(predSafeRaw & ~trueSafe,'omitnan');
model.metrics.calibratedTestFalseSafeRate=mean(predSafeCal & ~trueSafe,'omitnan');
model.metrics.calibratedTestConservativeRate=mean(~predSafeCal & trueSafe,'omitnan');
model.metrics.nTrain=sum(itr); model.metrics.nCalibration=sum(ical); model.metrics.nTest=sum(ite);
model.metrics.nSamples=size(X,1); model.metrics.nGroups=nG;

% G1 baseline: derive one global fixed alpha from TRAINING operating states
% only.  P1 must therefore beat more than a manually chosen smaller reserve.
trainStates=X(itr,1:3);
policyCfg=aiCfg; policyCfg.useSafetyCalibration=true;
[aReq,~]=select_reserve_alpha_batch(model,trainStates,policyCfg,true);
model.globalFixedAlpha=empirical_quantile(aReq,1-aiCfg.calibrationRisk);
model.globalFixedAlpha=min(max(model.globalFixedAlpha,aiCfg.alphaMin),aiCfg.alphaMax);

fprintf('KRR stress model hyperparameters: sigma=%.4g, lambda=%.4g\n', ...
    model.kernelSigma,model.lambda);
fprintf('One-sided stress calibration offset: %.4f\n',model.calibrationOffset);
fprintf('Training-only global fixed-ratio baseline (G1): alpha=%.4f\n',model.globalFixedAlpha);
fprintf(['Stress response test: RMSE %.4f | MAE %.4f | calibrated coverage %.2f%% | ', ...
    'false-safe %.2f%%\n'],model.metrics.testStressRMSE,model.metrics.testStressMAE, ...
    100*model.metrics.testCalibrationCoverage,100*model.metrics.calibratedTestFalseSafeRate);
end
