function merged = merge_reserve_response_datasets(base,extra,cfg,caseName)
%MERGE_RESERVE_RESPONSE_DATASETS Append new exploration rows safely.
%
% For matched final-paper parity enrichment, extra trajectories deliberately
% use the SAME (decayRatio, randomSeed) scenario grid as the existing paper
% dataset.  Their retained missing-alpha rows are mapped back onto the same
% trajectory group IDs.  This preserves trajectory-grouped train/cal/test
% splitting and prevents closely related scenario realizations from leaking
% across splits.

[ok,msg]=response_dataset_merge_compatible(base,cfg,caseName);
if ~ok, error('Base response dataset is incompatible: %s',msg); end
[ok,msg]=response_dataset_merge_compatible(extra,cfg,caseName);
if ~ok, error('Extra response dataset is incompatible: %s',msg); end

merged=base;
baseGroup=base.groupID(:);
extraGroupRaw=extra.groupID(:);
extraGroupMapped=zeros(size(extraGroupRaw));
nextGroup=0;
if ~isempty(baseGroup), nextGroup=max(baseGroup); end
matchedGroups=0; appendedGroups=0;

uExtra=unique(extraGroupRaw(:),'stable');
for ii=1:numel(uExtra)
    g=uExtra(ii);
    idxE=find(extraGroupRaw==g);
    d=extra.decayRatio(idxE(1));
    s=extra.randomSeed(idxE(1));
    idxB=find(abs(base.decayRatio(:)-d)<1e-12 & base.randomSeed(:)==s);
    gMatch=unique(baseGroup(idxB));
    if numel(gMatch)==1
        gNew=gMatch;
        matchedGroups=matchedGroups+1;
    else
        nextGroup=nextGroup+1;
        gNew=nextGroup;
        appendedGroups=appendedGroups+1;
    end
    extraGroupMapped(idxE)=gNew;
end

rowFields={'Xstate','alpha','X','yStress','maxAbsFreqDev_Hz','maxAbsRoCoF_Hz_s', ...
    'secure','decayRatio','randomSeed','intervalIndex','time_h'};
for i=1:numel(rowFields)
    f=rowFields{i};
    if ~isfield(base,f) || ~isfield(extra,f), error('Missing merge field %s.',f); end
    merged.(f)=[base.(f);extra.(f)];
end
merged.groupID=[baseGroup;extraGroupMapped];

% Preserve base group metadata for matched scenarios.  Append metadata only
% for genuinely new scenario groups.
merged.groupMeta=base.groupMeta;
if isfield(extra,'groupMeta') && ~isempty(extra.groupMeta)
    gm=extra.groupMeta;
    for ii=1:numel(gm)
        oldID=gm(ii).groupID;
        idx=find(extraGroupRaw==oldID,1,'first');
        if isempty(idx), continue; end
        mappedID=extraGroupMapped(idx);
        if any(arrayfun(@(x)isfield(x,'groupID') && x.groupID==mappedID,merged.groupMeta))
            continue
        end
        gm(ii).groupID=mappedID;
        if isempty(merged.groupMeta), merged.groupMeta=gm(ii); else, merged.groupMeta(end+1)=gm(ii); end %#ok<AGROW>
    end
end

merged.alphaLevels=sort(unique(merged.alpha(:))).';
merged.created=datestr(now,30);
merged.trainingSignature=ai_reserve_model_signature(cfg,caseName);
merged.mergeInfo=struct('baseSamples',size(base.X,1),'addedSamples',size(extra.X,1), ...
    'baseGroups',numel(unique(base.groupID)),'addedGroups',appendedGroups, ...
    'matchedGroups',matchedGroups,'finalSamples',size(merged.X,1), ...
    'finalGroups',numel(unique(merged.groupID)));
counts=arrayfun(@(a)sum(abs(merged.alpha-a)<1e-12),merged.alphaLevels);
merged.summary=struct('nSamples',size(merged.X,1),'nGroups',numel(unique(merged.groupID)), ...
    'safeFraction',mean(merged.secure),'stressMean',mean(merged.yStress), ...
    'stressMax',max(merged.yStress),'alphaCounts',counts(:));
end
