function varargout = predict_reserve_ratio_batch(varargin)
%PREDICT_RESERVE_RATIO_BATCH Deprecated direct-alpha predictor guard.
% The former model directly regressed alpha*.  That expensive oracle scheme
% has been removed.  Use select_reserve_alpha_batch / predict_frequency_stress.
error('predict_reserve_ratio_batch:Deprecated', ...
    ['Direct alpha-regression has been removed. Use the randomized-alpha ', ...
     'frequency-stress response model instead.']);
end
