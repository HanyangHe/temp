function [bestSigma,bestLambda,cv] = select_krr_hyperparameters(X,y,group,sigmaGrid,lambdaGrid)
%SELECT_KRR_HYPERPARAMETERS Grouped cross-validation for toolbox-free KRR.
% X is assumed already standardized using training-split statistics.
% Entire physical scenario groups stay in the same fold.

y=y(:); group=group(:);
ug=unique(group,'stable');
nG=numel(ug);
if nG<3
    error('Grouped KRR tuning requires at least three training scenario groups.');
end
nFold=min(5,nG);
foldOfGroup=mod((0:nG-1),nFold)+1;

scores=nan(numel(sigmaGrid),numel(lambdaGrid));
for is=1:numel(sigmaGrid)
    sigma=sigmaGrid(is);
    for il=1:numel(lambdaGrid)
        lambda=lambdaGrid(il);
        sqerr=[];
        for f=1:nFold
            valGroups=ug(foldOfGroup==f);
            iva=ismember(group,valGroups);
            itr=~iva;
            if ~any(iva) || ~any(itr), continue; end

            Ktr=rbf_kernel(X(itr,:),X(itr,:),sigma);
            coef=(Ktr+lambda*eye(size(Ktr,1)))\y(itr);
            Kva=rbf_kernel(X(iva,:),X(itr,:),sigma);
            pred=Kva*coef;
            sqerr=[sqerr;(pred-y(iva)).^2]; %#ok<AGROW>
        end
        if ~isempty(sqerr)
            scores(is,il)=mean(sqerr,'omitnan');
        end
    end
end

[minScore,idx]=min(scores(:),[],'omitnan');
if isempty(idx) || ~isfinite(minScore)
    error('Grouped KRR hyperparameter search did not produce a finite score.');
end
[is,il]=ind2sub(size(scores),idx);
bestSigma=sigmaGrid(is);
bestLambda=lambdaGrid(il);
cv=struct('sigmaGrid',sigmaGrid,'lambdaGrid',lambdaGrid, ...
    'mse',scores,'bestMSE',minScore,'nGroups',nG,'nFolds',nFold);
end
