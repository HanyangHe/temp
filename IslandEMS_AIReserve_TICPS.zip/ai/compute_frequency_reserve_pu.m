function [reserveDownPu,reserveUpPu,meta] = compute_frequency_reserve_pu( ...
    mode,fixedRatio,Rdroop,H,dfReserveHz,rocofLimitHzS,f0,aiModel,feature, ...
    PminPu,PmaxPu,aiCfg)
%COMPUTE_FREQUENCY_RESERVE_PU Consistent rating-based reserve calculation.
%
% All returned reserves are per unit on EACH DG's own active-power rating.
% Droop reserve: df/(R f0)
% RoCoF reserve: 2 H RoCoF/f0
% The AI model predicts frequency stress over candidate alpha values and selects
% a dimensionless multiplier before MPC optimization. The selected alpha is a
% fixed parameter inside that MPC solve, so the optimization remains convex.

Rdroop=Rdroop(:).';
if isscalar(H), H=H*ones(size(Rdroop)); else, H=reshape(H,1,[]); end
if numel(H)~=numel(Rdroop)
    error('H and Rdroop must be scalar-compatible or have equal length.');
end

droopPu = dfReserveHz./(Rdroop*f0);
rocofPu = 2*H*rocofLimitHzS/f0;
physicsPu = max(droopPu,rocofPu);

switch lower(mode)
    case 'none'
        alpha=0;
        predInfo=struct('raw',0,'calibrated',0,'clipped',false);
    case {'fixed','scheduled'}
        alpha=fixedRatio;
        predInfo=struct('raw',alpha,'calibrated',alpha,'clipped',false,'source',lower(mode));
    case 'global'
        if isempty(aiModel) || ~isfield(aiModel,'globalFixedAlpha')
            error('Global fixed-ratio baseline requires a trained model with globalFixedAlpha.');
        end
        alpha=aiModel.globalFixedAlpha;
        predInfo=struct('raw',alpha,'calibrated',alpha,'clipped',false,'source','training-global-quantile');
    case 'ai'
        if isempty(aiModel) || isempty(feature)
            error('AI reserve mode requires a trained model and a feature row.');
        end
        if any(~isfinite(feature))
            % The first decision of a fresh simulation has no prior measured
            % SG output, hence no causal headroom feature.  Use the transparent
            % physics fallback instead of fabricating a headroom value.
            alpha=aiCfg.fallbackAlpha;
            predInfo=struct('raw',NaN,'calibrated',alpha,'clipped',false, ...
                'oodFallback',true,'source','missing-causal-feature-fallback');
        else
            [alpha,predInfo]=predict_reserve_ratio(aiModel,feature,aiCfg);
        end
    otherwise
        error('Unknown reserve mode: %s',mode);
end

alphaRequested=alpha;
% AI predictions are bounded by the learned-model design range. Fixed and
% no-reserve baselines must NOT be forced above aiCfg.alphaMin.
if any(strcmpi(mode,{'ai','global'}))
    alpha=min(max(alpha,aiCfg.alphaMin),aiCfg.alphaMax);
elseif any(strcmpi(mode,{'fixed','scheduled'}))
    alpha=max(alpha,0);
else
    alpha=0;
end
maxSymmetricPu=max((PmaxPu-PminPu)/2-1e-6,0);
reservePu=alpha*physicsPu;
clippedByFeasibility=reservePu>maxSymmetricPu;
reservePu=min(reservePu,maxSymmetricPu);

reserveDownPu=reservePu;
reserveUpPu=reservePu;
meta=struct('mode',mode,'alpha',alpha,'alphaRequested',alphaRequested, ...
    'droopPu',droopPu,'rocofPu',rocofPu,'physicsPu',physicsPu, ...
    'reservePu',reservePu,'maxSymmetricPu',maxSymmetricPu, ...
    'clippedByFeasibility',any(clippedByFeasibility),'prediction',predInfo);
end
