function datasetFile = get_ai_reserve_dataset_file(projectRoot,cfg,caseName)
%GET_AI_RESERVE_DATASET_FILE Canonical per-grid final-paper AI dataset path.
% Reusable training datasets live under ai/datasets/<caseName>/ and are kept
% separate from temporary generation artifacts in outputs/.
if nargin<3 || isempty(caseName)
    error('get_ai_reserve_dataset_file:MissingCase','caseName is required.');
end
caseTag=regexprep(lower(char(caseName)),'[^a-z0-9_]+','_');
datasetFile=fullfile(projectRoot,cfg.ai.datasetRoot,caseTag,cfg.ai.datasetFileName);
end
