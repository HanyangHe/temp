function stress = predict_frequency_stress(model,stateFeatures,alpha)
%PREDICT_FREQUENCY_STRESS KRR response prediction for candidate reserve ratios.
%
% stateFeatures: N-by-3 matrix with the frozen causal physics state
%   [Pnet, |Delta Pnet|, DG upward headroom].
% alpha: scalar or N-vector candidate reserve ratio.
% stress: predicted normalized CoI frequency stress, where stress<=1 means
%   both |df_CoI| and |RoCoF_CoI| are within configured security limits.

if isvector(stateFeatures) && numel(stateFeatures)==numel(reserve_feature_names())
    stateFeatures=reshape(stateFeatures,1,[]);
end
if size(stateFeatures,2)~=numel(reserve_feature_names())
    error('predict_frequency_stress:FeatureDimension', ...
        'Expected %d state features but received %d.', ...
        numel(reserve_feature_names()),size(stateFeatures,2));
end
n=size(stateFeatures,1);
if isscalar(alpha)
    alpha=repmat(alpha,n,1);
else
    alpha=alpha(:);
    if numel(alpha)~=n
        error('alpha must be scalar or have one value per state row.');
    end
end
X=[stateFeatures alpha];
if size(X,2)~=numel(model.inputNames)
    error('Model input dimension does not match the response-model contract.');
end
Xs=(X-model.mu)./model.sigma;
K=rbf_kernel(Xs,model.Xtrain,model.kernelSigma);
stress=K*model.coef;
% Frequency stress is nonnegative by definition. KRR may have a very small
% negative extrapolation/interpolation near zero; clip only this impossible
% negative tail, not the upper response.
stress=max(stress,0);
end
