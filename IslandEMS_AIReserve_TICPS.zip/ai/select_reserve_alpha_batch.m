function [alpha,detail] = select_reserve_alpha_batch(model,stateFeatures,aiCfg,useCalibration)
%SELECT_RESERVE_ALPHA_BATCH Choose the smallest predicted-secure reserve ratio.
% The learned object predicts frequency stress as a function of the current
% three-state physics vector AND a candidate alpha.  A one-sided calibration
% offset is added for the proposed P1 policy.  To avoid selecting an isolated
% nonmonotone KRR dip, a candidate is accepted only when it and every larger
% candidate in the search grid are predicted secure (safe-suffix rule).

if nargin<4 || isempty(useCalibration)
    useCalibration=isfield(aiCfg,'useSafetyCalibration') && aiCfg.useSafetyCalibration;
end
if isvector(stateFeatures) && numel(stateFeatures)==numel(reserve_feature_names())
    stateFeatures=reshape(stateFeatures,1,[]);
end
n=size(stateFeatures,1);
if size(stateFeatures,2)~=numel(reserve_feature_names())
    error('select_reserve_alpha_batch:FeatureDimension','Expected three frozen state features.');
end
alphaGrid=unique(aiCfg.candidateAlphaGrid(:).','sorted');
alphaGrid=alphaGrid(alphaGrid>=aiCfg.alphaMin-1e-12 & alphaGrid<=aiCfg.alphaMax+1e-12);
if isempty(alphaGrid) || abs(alphaGrid(end)-aiCfg.fallbackAlpha)>1e-12
    alphaGrid=unique([alphaGrid aiCfg.fallbackAlpha],'sorted');
end

alpha=aiCfg.fallbackAlpha*ones(n,1);
rawCurve=nan(n,numel(alphaGrid));
safeCurve=nan(n,numel(alphaGrid));
ood=false(n,1);
noSafe=false(n,1);
missing=false(n,1);
for i=1:n
    s=stateFeatures(i,:);
    if any(~isfinite(s))
        missing(i)=true;
        continue
    end
    if isfield(aiCfg,'useOODFallback') && aiCfg.useOODFallback && ...
            isfield(model,'trainStateZMin') && isfield(model,'trainStateZMax')
        z=(s-model.stateMu)./model.stateSigma;
        margin=aiCfg.oodMarginStd;
        if any(z < model.trainStateZMin-margin | z > model.trainStateZMax+margin)
            ood(i)=true;
            continue
        end
    end
    S=repmat(s,numel(alphaGrid),1);
    raw=predict_frequency_stress(model,S,alphaGrid(:));
    calibrated=raw;
    if useCalibration && isfield(model,'calibrationOffset')
        calibrated=calibrated+model.calibrationOffset;
    end
    rawCurve(i,:)=raw(:).';
    safeCurve(i,:)=calibrated(:).';
    safe=calibrated<=1;
    safeSuffix=false(size(safe));
    for j=1:numel(safe)
        safeSuffix(j)=all(safe(j:end));
    end
    idx=find(safeSuffix,1,'first');
    if isempty(idx)
        noSafe(i)=true;
        alpha(i)=aiCfg.fallbackAlpha;
    else
        alpha(i)=alphaGrid(idx);
    end
end
alpha=min(max(alpha,aiCfg.alphaMin),aiCfg.alphaMax);
detail=struct('alphaGrid',alphaGrid,'rawStress',rawCurve,'decisionStress',safeCurve, ...
    'oodFallback',ood,'missingFeatureFallback',missing,'noSafeCandidateFallback',noSafe, ...
    'usedCalibration',logical(useCalibration));
end
