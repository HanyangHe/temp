function [ok,msg] = response_dataset_merge_compatible(dataset,cfg,caseName)
%RESPONSE_DATASET_MERGE_COMPATIBLE Check whether old response data can be reused.
% This intentionally ignores the old exploration-alpha list/profile details:
% changing the OFFLINE exploration set does not invalidate already observed
% physical response samples. Physics, state-feature, target and time-base
% contracts must still match exactly.
ok=false; msg='';
try
    if ~isstruct(dataset) || ~isfield(dataset,'kind') || ...
            ~strcmp(dataset.kind,'IslandEMSFrequencyStressResponseDatasetV1')
        error('not a randomized-alpha frequency-response dataset');
    end
    if ~isfield(dataset,'caseName') || ~strcmpi(char(dataset.caseName),char(caseName))
        error('caseName mismatch');
    end
    names=reserve_feature_names();
    expectedInputs=[names {'reserveRatio'}];
    if ~isfield(dataset,'stateFeatureNames') || ...
            ~isequal(string(dataset.stateFeatureNames(:)),string(names(:)))
        error('state-feature contract mismatch');
    end
    if ~isfield(dataset,'inputNames') || ...
            ~isequal(string(dataset.inputNames(:)),string(expectedInputs(:)))
        error('response input contract mismatch');
    end
    if ~isfield(dataset,'X') || size(dataset.X,2)~=4 || ...
            ~isfield(dataset,'alpha') || ~isfield(dataset,'yStress') || ...
            ~isfield(dataset,'groupID')
        error('required response arrays are missing');
    end
    if ~isfield(dataset,'securityLimits') || ...
            abs(dataset.securityLimits.df_Hz-cfg.frequency.securityDeviation_Hz)>1e-12 || ...
            abs(dataset.securityLimits.rocof_Hz_s-cfg.frequency.securityRoCoF_Hz_s)>1e-12
        error('frequency-security limits differ');
    end
    % If a prior signature exists, use the physical/time-base fields only.
    if isfield(dataset,'trainingSignature') && isstruct(dataset.trainingSignature)
        a=dataset.trainingSignature;
        req={'reserveDeviation_Hz','reserveRoCoF_Hz_s','securityDeviation_Hz', ...
            'securityRoCoF_Hz_s','nominal_Hz','droop_pu','H_s', ...
            'decisionInterval_h','predictionStep_h','horizon_h'};
        b=ai_reserve_model_signature(cfg,caseName);
        for i=1:numel(req)
            f=req{i};
            if ~isfield(a,f) || abs(double(a.(f))-double(b.(f)))>1e-12
                error('physical/time-base signature differs at %s',f);
            end
        end
        if isfield(a,'securityTarget') && ~strcmpi(char(a.securityTarget),'coi')
            error('old dataset is not CoI-target response data');
        end
    end
    ok=true; msg='compatible';
catch ME
    msg=ME.message;
end
end
