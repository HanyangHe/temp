function sig = ai_reserve_model_signature(cfg,caseName)
%AI_RESERVE_MODEL_SIGNATURE Reusable-model contract + nonbinding provenance.
%
% IMPORTANT:
%   Fields at the top level describe the physics / feature / online-policy
%   contract that materially affects whether a stored model can be reused.
%   Data-generation bookkeeping (decay boxes, parity/enrichment schedules,
%   random seeds, etc.) is stored under sig.provenance and must NOT by itself
%   invalidate an already-trained deployable model.

sig = struct();
sig.signatureVersion = 2;
sig.caseName = char(caseName);
sig.stateFeatureNames = reserve_feature_names();
sig.inputNames = [reserve_feature_names() {'reserveRatio'}];
sig.learningTarget = char(cfg.ai.learningTarget);
sig.securityTarget = char(cfg.ai.response.securityTarget);
sig.modelType = char(cfg.ai.modelType);

% Online/deployment policy contract.
sig.alphaMin = cfg.ai.alphaMin;
sig.alphaMax = cfg.ai.alphaMax;
sig.fallbackAlpha = cfg.ai.fallbackAlpha;
sig.calibrationRisk = cfg.ai.calibrationRisk;
sig.candidateAlphaGrid = cfg.ai.candidateAlphaGrid(:).';

% Physical model / security-definition contract.
sig.reserveDeviation_Hz = cfg.frequency.reserveDeviation_Hz;
sig.reserveRoCoF_Hz_s = cfg.frequency.reserveRoCoF_Hz_s;
sig.securityDeviation_Hz = cfg.frequency.securityDeviation_Hz;
sig.securityRoCoF_Hz_s = cfg.frequency.securityRoCoF_Hz_s;
sig.nominal_Hz = cfg.frequency.nominal_Hz;
sig.droop_pu = cfg.frequency.droop_pu;
sig.H_s = cfg.frequency.H_s;

% MPC time-base contract used to generate response data.
sig.decisionInterval_h = cfg.mpc.decisionInterval_h;
sig.predictionStep_h = cfg.mpc.predictionStep_h;
sig.horizon_h = cfg.mpc.horizon_h;

% Offline response-model domain / target contract.
sig.responseBaselineID = char(cfg.ai.response.baselineID);
sig.responseTrainingAlphaMin = cfg.ai.response.trainingAlphaMin;
sig.responseTrainingAlphaMax = cfg.ai.response.trainingAlphaMax;
sig.responseAlphaLevels = cfg.ai.response.alphaLevels(:).';

% -------------------------------------------------------------------------
% Reproducibility/provenance only.  These describe HOW the dataset was
% generated.  They are intentionally nested and are not deployment-validity
% fields.  Changing them later must not make an already trained model stale.
% -------------------------------------------------------------------------
p = struct();
p.responseProfile = get_text(cfg.ai.response,'profile','');
p.responseScheduleMode = get_text(cfg.ai.response,'scheduleMode','');
p.responseDecayRatios = get_array(cfg.ai.response,'decayRatios');
p.responseRandomSeeds = get_array(cfg.ai.response,'randomSeeds');
p.incrementalReuseExistingDataset = get_logical(cfg.ai.response,'incrementalReuseExistingDataset',false);

if isfield(cfg.ai.response,'parity') && isstruct(cfg.ai.response.parity)
    p.parityEnabled = get_logical(cfg.ai.response.parity,'enabled',false);
    p.parityDecayRatios = get_array(cfg.ai.response.parity,'decayRatios');
    p.parityRandomSeeds = get_array(cfg.ai.response.parity,'randomSeeds');
    p.parityReferenceAlphaLevels = get_array(cfg.ai.response.parity,'referenceExistingAlphaLevels');
    p.parityTargetCountPerTrajectory = get_scalar(cfg.ai.response.parity,'targetCountPerTrajectory',NaN);
end
if isfield(cfg.ai.response,'enrichment') && isstruct(cfg.ai.response.enrichment)
    p.enrichmentDecayRatios = get_array(cfg.ai.response.enrichment,'decayRatios');
    p.enrichmentRandomSeeds = get_array(cfg.ai.response.enrichment,'randomSeeds');
end
p.kernelSigmaGrid = cfg.ai.kernelSigmaGrid(:).';
p.lambdaGrid = cfg.ai.lambdaGrid(:).';
sig.provenance = p;
end

function v=get_array(s,f)
if isfield(s,f) && ~isempty(s.(f)), v=double(s.(f)(:).'); else, v=[]; end
end
function v=get_scalar(s,f,d)
if isfield(s,f) && ~isempty(s.(f)), v=double(s.(f)); else, v=d; end
end
function v=get_logical(s,f,d)
if isfield(s,f) && ~isempty(s.(f)), v=logical(s.(f)); else, v=d; end
end
function v=get_text(s,f,d)
if isfield(s,f) && ~isempty(s.(f)), v=char(s.(f)); else, v=d; end
end
