function modelFile = get_ai_reserve_model_file(projectRoot,cfg,caseName)
%GET_AI_RESERVE_MODEL_FILE Canonical per-grid AI-reserve model path.
% Reusable models live under ai/models/<caseName>/ and are not mixed with
% formal simulation outputs.
if nargin<3 || isempty(caseName)
    error('get_ai_reserve_model_file:MissingCase','caseName is required.');
end
caseTag = regexprep(lower(char(caseName)),'[^a-z0-9_]+','_');
modelFile = fullfile(projectRoot,cfg.ai.modelRoot,caseTag,cfg.ai.modelFileName);
end
