function [dataset,datasetFile] = generate_reserve_oracle_dataset(cfg,projectRoot)
%GENERATE_RESERVE_ORACLE_DATASET Legacy-name compatibility wrapper.
% The former fixed-alpha full-day alpha* oracle has been REMOVED.  Calls to
% this legacy function are redirected to the efficient randomized-alpha
% frequency-stress response generator so no old oracle sweep can run.
warning('generate_reserve_oracle_dataset:DeprecatedName', ...
    ['The direct alpha* oracle sweep was removed. Redirecting to ', ...
     'generate_reserve_response_dataset.']);
[dataset,datasetFile]=generate_reserve_response_dataset(cfg,projectRoot);
end
