function q = empirical_quantile(x,p)
%EMPIRICAL_QUANTILE Toolbox-free empirical quantile with linear interpolation.
x=sort(x(isfinite(x)));
if isempty(x), q=0; return; end
p=min(max(p,0),1);
r=1+(numel(x)-1)*p;
lo=floor(r); hi=ceil(r);
if lo==hi, q=x(lo); else, q=x(lo)+(r-lo)*(x(hi)-x(lo)); end
end
