function [ok,msg] = validate_ai_reserve_model(model,cfg,caseName)
%VALIDATE_AI_RESERVE_MODEL Validate only MODEL/DEPLOYMENT-critical contract.
%
% Data-generation provenance (decay boxes, random seeds, parity/enrichment
% schedules, hyperparameter-search grids, etc.) is intentionally NOT used to
% invalidate a trained model.  Those fields describe how the saved dataset
% was produced, not whether the already-trained response surface is usable
% by the current EMS.
%
% This also remains backward compatible with legacy flat trainingSignature
% structs created before signatureVersion=2.

ok=false; msg='';
try
    expected=ai_reserve_model_signature(cfg,caseName);
    if ~isstruct(model), error('Loaded object is not a model struct.'); end
    if ~isfield(model,'caseName') || ~strcmpi(char(model.caseName),char(caseName))
        error('model.caseName does not match %s.',char(caseName));
    end
    if ~isfield(model,'learningTarget') || ...
            ~strcmpi(char(model.learningTarget),'frequency-stress-response')
        error('stored model uses a deprecated/non-response learning target.');
    end
    if ~isfield(model,'stateFeatureNames') || ...
            ~isequal(string(model.stateFeatureNames(:)),string(expected.stateFeatureNames(:)))
        error('state feature contract does not match the frozen three-feature model.');
    end
    if ~isfield(model,'inputNames') || ...
            ~isequal(string(model.inputNames(:)),string(expected.inputNames(:)))
        error('response-model input contract differs (three states + alpha expected).');
    end
    if ~isfield(model,'trainingSignature') || ~isstruct(model.trainingSignature)
        error('trainingSignature is missing (stale model).');
    end

    a=model.trainingSignature; b=expected;

    % Text fields that materially define the learned response problem.
    check_text(a,b,'caseName');
    check_text(a,b,'learningTarget');
    check_text(a,b,'securityTarget');
    check_text(a,b,'modelType');
    check_text(a,b,'responseBaselineID');

    if ~isfield(a,'stateFeatureNames') || ...
            ~isequal(string(a.stateFeatureNames(:)),string(b.stateFeatureNames(:))) || ...
       ~isfield(a,'inputNames') || ...
            ~isequal(string(a.inputNames(:)),string(b.inputNames(:)))
        error('trainingSignature input names differ.');
    end

    % Scalars that change physics, security definition, online policy, or
    % the offline alpha domain actually represented by this response model.
    scalarFields={ ...
        'alphaMin','alphaMax','calibrationRisk', ...
        'reserveDeviation_Hz','reserveRoCoF_Hz_s', ...
        'securityDeviation_Hz','securityRoCoF_Hz_s','nominal_Hz', ...
        'droop_pu','H_s','decisionInterval_h','predictionStep_h','horizon_h', ...
        'responseTrainingAlphaMin','responseTrainingAlphaMax'};
    for i=1:numel(scalarFields)
        check_scalar(a,b,scalarFields{i});
    end

    % fallbackAlpha was absent from some legacy signatures.  Validate it
    % from the trained model when available; otherwise tolerate legacy data.
    if isfield(a,'fallbackAlpha')
        check_scalar(a,b,'fallbackAlpha');
    elseif isfield(model,'alphaMax') && abs(double(cfg.ai.fallbackAlpha)-1)>1e-12
        error('Legacy model signature lacks fallbackAlpha under a nondefault policy.');
    end

    % Arrays that affect online selection / actual learned alpha domain.
    arrayFields={'candidateAlphaGrid','responseAlphaLevels'};
    for i=1:numel(arrayFields)
        check_array(a,b,arrayFields{i});
    end

    % Cross-check trained model's own alpha contract where stored.
    if isfield(model,'alphaMin') && abs(double(model.alphaMin)-double(cfg.ai.alphaMin))>1e-12
        error('model.alphaMin differs from current online policy.');
    end
    if isfield(model,'alphaMax') && abs(double(model.alphaMax)-double(cfg.ai.alphaMax))>1e-12
        error('model.alphaMax differs from current online policy.');
    end
    if isfield(model,'candidateAlphaGrid') && ...
            ~isequaln(double(model.candidateAlphaGrid(:)),double(cfg.ai.candidateAlphaGrid(:)))
        error('model.candidateAlphaGrid differs from current online policy.');
    end

    % Explicitly DO NOT compare the following legacy/provenance fields:
    %   responseProfile, responseScheduleMode,
    %   responseDecayRatios, responseRandomSeeds,
    %   responseEnrichmentDecayRatios, responseEnrichmentRandomSeeds,
    %   responseParity*, responseIncrementalReuse,
    %   kernelSigmaGrid, lambdaGrid.
    % A change in these only changes how future data would be generated or
    % retrained; it does not change the already-fitted deployable model.

    ok=true; msg='valid (deployment/model contract matched; provenance-only differences ignored)';
catch ME
    msg=ME.message;
end
end

function check_text(a,b,f)
if ~isfield(a,f) || ~isfield(b,f) || ~strcmpi(char(a.(f)),char(b.(f)))
    error('trainingSignature.%s differs from current model contract.',f);
end
end
function check_scalar(a,b,f)
if ~isfield(a,f) || ~isfield(b,f) || ...
        ~isscalar(a.(f)) || ~isscalar(b.(f)) || ...
        ~isfinite(double(a.(f))) || ~isfinite(double(b.(f))) || ...
        abs(double(a.(f))-double(b.(f)))>1e-12
    error('trainingSignature.%s differs from current model contract.',f);
end
end
function check_array(a,b,f)
if ~isfield(a,f) || ~isfield(b,f) || ...
        ~isequaln(double(a.(f)(:)),double(b.(f)(:)))
    error('trainingSignature.%s differs from current model contract.',f);
end
end
