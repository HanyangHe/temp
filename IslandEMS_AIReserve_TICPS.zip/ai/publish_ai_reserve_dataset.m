function datasetFile = publish_ai_reserve_dataset(projectRoot,cfg,caseName,dataset,sourceDatasetFile,sourceFiles)
%PUBLISH_AI_RESERVE_DATASET Publish one canonical reusable dataset per grid.
% The canonical file is written atomically to
%   ai/datasets/<caseName>/reserve_response_dataset_paper.mat
% while outputs/training_* folders remain generation/provenance artifacts.
if nargin<5, sourceDatasetFile=''; end
if nargin<6, sourceFiles=struct(); end
[ok,msg]=response_dataset_merge_compatible(dataset,cfg,caseName);
if ~ok
    error('publish_ai_reserve_dataset:IncompatibleDataset', ...
        '[%s] Refusing to publish incompatible dataset: %s',caseName,msg);
end

datasetFile=get_ai_reserve_dataset_file(projectRoot,cfg,caseName);
outDir=fileparts(datasetFile);
if ~exist(outDir,'dir'), mkdir(outDir); end

provenance=struct();
provenance.caseName=char(caseName);
provenance.publishedAt=datestr(now,30);
provenance.sourceDatasetFile=char(sourceDatasetFile);
provenance.sourceFiles=sourceFiles;
provenance.nSamples=size(dataset.X,1);
provenance.nGroups=numel(unique(dataset.groupID));
provenance.alphaLevels=sort(unique(dataset.alpha(:))).';

% Atomic-ish replace: save alongside canonical file, then move into place.
tmpFile=[datasetFile '.tmp.mat'];
if exist(tmpFile,'file'), delete(tmpFile); end
save(tmpFile,'dataset','provenance','-v7.3');
if exist(datasetFile,'file'), delete(datasetFile); end
[okMove,msgMove]=movefile(tmpFile,datasetFile,'f');
if ~okMove
    error('publish_ai_reserve_dataset:MoveFailed','Could not publish dataset: %s',msgMove);
end
fprintf('[%s] Published canonical final-paper response dataset:\n  %s\n',caseName,datasetFile);
end
