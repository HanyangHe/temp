# AI models

`train_AIReserve.m` writes `reserve_krr_model.mat` here. The trained model is not bundled because it must be regenerated after the corrected physical-frequency model is validated in MATLAB.
