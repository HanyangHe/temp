FINAL 33-BUS RUNTIME REPAIR V1
================================

Why this patch is needed
------------------------
The previous preflight resolved:
  archive/.../production_backup/config_island_ems.m

instead of the LIVE production config. The reason is that:
  addpath(genpath(pwd))
also adds archive/ and outputs/ subtrees containing backup/shadow copies.

That is dangerous for BOTH preflight and training.

This package fixes the issue by:
1) finding the live config explicitly;
2) removing archive/, outputs/, and patch_files/ from MATLAB runtime path;
3) repairing the live config/engine/catalog idempotently;
4) patching train_AIReserve.m so it removes those non-runtime trees itself;
5) printing the average-input mode in train_AIReserve's banner;
6) providing a final preflight that explicitly prints average-input status.

Run order
---------
1. Dry run:
   clear functions
   rehash
   addpath(genpath(pwd))
   Rfix = repair_final_33bus_inputavg_runtime_v1(pwd,false);

2. If the dry-run paths/state look correct, apply:
   Rfix = repair_final_33bus_inputavg_runtime_v1(pwd,true);

3. Final preflight:
   clear functions
   rehash
   addpath(genpath(pwd))
   Rpre = preflight_33bus_retrain_final_v3(pwd);

4. ONLY if PRE-FLIGHT STATUS: PASS:
   clear functions
   rehash
   addpath(genpath(pwd))
   train_AIReserve

Expected preflight status
-------------------------
AVERAGE-INPUT MODE STATUS
  config field exists : 1
  enabled             : 1
  mode                : adjacent-endpoint
  engine blocks       : 2
  true 1-s curves avg : NO
  output interpolation: NO (original ZOH)

PRE-FLIGHT STATUS: PASS
AVERAGE INPUT MODE: ENABLED (adjacent-endpoint)
