function p=normalize_path_for_compare_v1(p0)
%NORMALIZE_PATH_FOR_COMPARE_V1 Canonical lowercase path for comparison.

try
    p=lower(string(char(java.io.File(p0).getCanonicalPath())));
catch
    p=lower(string(p0));
end

end
