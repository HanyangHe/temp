function report = repair_final_33bus_inputavg_runtime_v1(projectRoot,applyChanges)
%REPAIR_FINAL_33BUS_INPUTAVG_RUNTIME_V1
% Repair/verify the final 33-bus production runtime after archived backups
% accidentally became visible on the MATLAB path.
%
% This utility is idempotent and does NOT launch simulation/training.
%
% It ensures:
%   1) MATLAB runtime path excludes archive/, outputs/, and patch_files/.
%   2) the LIVE config_island_ems.m is patched, not an archived backup.
%   3) final 33bus DG/PV ratings are installed.
%   4) predictive 15-min input averaging is enabled in config + engine.
%   5) train_AIReserve.m removes archive/output shadow paths at startup.
%   6) train_AIReserve prints the average-input mode in its banner.
%
% Dry run:
%   R = repair_final_33bus_inputavg_runtime_v1(pwd,false);
%
% Apply:
%   clear functions
%   rehash
%   addpath(genpath(pwd))
%   R = repair_final_33bus_inputavg_runtime_v1(pwd,true);

if nargin<1 || isempty(projectRoot)
    projectRoot=pwd;
end
if nargin<2 || isempty(applyChanges)
    applyChanges=false;
end

projectRoot=char(projectRoot);
applyChanges=logical(applyChanges);

% Remove non-runtime trees from the CURRENT MATLAB path immediately.
remove_nonruntime_paths_local(projectRoot);

liveCfgFile=find_live_config_local(projectRoot);
catalogFile=fullfile(projectRoot,'config','system_case_catalog.m');
engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');
trainFile=fullfile(projectRoot,'train_AIReserve.m');

assert(exist(liveCfgFile,'file')==2,'Live config file not found.');
assert(exist(catalogFile,'file')==2,'Missing catalog: %s',catalogFile);
assert(exist(engineFile,'file')==2,'Missing engine: %s',engineFile);
assert(exist(trainFile,'file')==2,'Missing train_AIReserve.m: %s',trainFile);

cfgText=fileread(liveCfgFile);
catalogText=fileread(catalogFile);
engineText=fileread(engineFile);
trainText=fileread(trainFile);

fprintf('\n=============================================================\n');
if applyChanges
    fprintf(' FINAL 33-BUS RUNTIME REPAIR -- APPLY\n');
else
    fprintf(' FINAL 33-BUS RUNTIME REPAIR -- DRY RUN\n');
end
fprintf('=============================================================\n');
fprintf('LIVE config : %s\n',liveCfgFile);
fprintf('Catalog     : %s\n',catalogFile);
fprintf('Engine      : %s\n',engineFile);
fprintf('Trainer     : %s\n',trainFile);

% -------------------------------------------------------------------------
% A) Prepare LIVE config patch.
% -------------------------------------------------------------------------
flagLine='cfg.forecast.useMPCIntervalAverage = true;';
modeLine='cfg.forecast.mpcIntervalAverageMode = ''adjacent-endpoint'';';

newCfgText=cfgText;

if contains(newCfgText,'cfg.forecast.useMPCIntervalAverage')
    newCfgText=regexprep(newCfgText, ...
        'cfg\.forecast\.useMPCIntervalAverage\s*=\s*(?:true|false)\s*;', ...
        flagLine,'once');
else
    forecastAnchors={ ...
        'cfg.forecast.upstreamTrustWeight', ...
        'cfg.forecast.interpolationMethod', ...
        'cfg.forecast.nativeStep_h'};

    inserted=false;

    for ia=1:numel(forecastAnchors)
        pat=[regexptranslate('escape',forecastAnchors{ia}) '\s*=\s*[^;]+;'];
        [s,e]=regexp(newCfgText,pat,'start','end','once');

        if ~isempty(s)
            originalLine=newCfgText(s:e);

            block=[originalLine newline ...
                '% Final MPC time discretization: each 15-min stage uses the' newline ...
                '% adjacent-point average of PREDICTIVE load/PV samples.' newline ...
                '% True 1-s physical load/PV trajectories remain unchanged.' newline ...
                flagLine newline ...
                modeLine];

            newCfgText=[newCfgText(1:s-1) block newCfgText(e+1:end)];
            inserted=true;
            break;
        end
    end

    assert(inserted,'Could not find a safe forecast-config insertion anchor.');
end

if contains(newCfgText,'cfg.forecast.mpcIntervalAverageMode')
    newCfgText=regexprep(newCfgText, ...
        'cfg\.forecast\.mpcIntervalAverageMode\s*=\s*[^;]+;', ...
        modeLine,'once');
else
    newCfgText=strrep(newCfgText,flagLine,[flagLine newline modeLine]);
end

expPat='cfg\.experiment\.systemCases\s*=\s*\{[^\n;]*\}\s*;';
respPat='cfg\.ai\.response\.systemCases\s*=\s*\{[^\n;]*\}\s*;';

assert(~isempty(regexp(newCfgText,expPat,'once')), ...
    'Could not find cfg.experiment.systemCases.');
assert(~isempty(regexp(newCfgText,respPat,'once')), ...
    'Could not find cfg.ai.response.systemCases.');

newCfgText=regexprep(newCfgText,expPat, ...
    'cfg.experiment.systemCases = {''33bus''}; % current final-development target', ...
    'once');

newCfgText=regexprep(newCfgText,respPat, ...
    'cfg.ai.response.systemCases = {''33bus''}; % regenerate final 33bus AI assets', ...
    'once');

% -------------------------------------------------------------------------
% B) Prepare final 33-bus physical case.
% -------------------------------------------------------------------------
dgOldPattern='sys\.DieselG_Pgfm_rate\s*=\s*\[0\.15\s*;\s*0\.15\s*;\s*0\.15\s*\]\s*;';
pvOldPattern='sys\.PVInv_P_rateIn\s*=\s*\[0\.25\s*;\s*0\.20\s*;\s*0\.20\s*;\s*0\.25\s*\]\s*;';

dgNewPattern='sys\.DieselG_Pgfm_rate\s*=\s*\[0\.17\s*;\s*0\.17\s*;\s*0\.17\s*\]\s*;';
pvNewPattern=['sys\.PVInv_P_rateIn\s*=\s*\[\s*' ...
    '(?:1/6|0\.1666666667)\s*;\s*' ...
    '(?:2/15|0\.1333333333)\s*;\s*' ...
    '(?:2/15|0\.1333333333)\s*;\s*' ...
    '(?:1/6|0\.1666666667)\s*\]\s*;'];

newCatalogText=catalogText;

if isempty(regexp(newCatalogText,dgNewPattern,'once'))
    assert(numel(regexp(newCatalogText,dgOldPattern,'match'))==1, ...
        'Cannot safely identify the old 33bus DG line.');

    newCatalogText=regexprep(newCatalogText,dgOldPattern, ...
        'sys.DieselG_Pgfm_rate = [0.17;0.17;0.17];','once');
end

if isempty(regexp(newCatalogText,pvNewPattern,'once'))
    assert(numel(regexp(newCatalogText,pvOldPattern,'match'))==1, ...
        'Cannot safely identify the old 33bus PV line.');

    newCatalogText=regexprep(newCatalogText,pvOldPattern, ...
        'sys.PVInv_P_rateIn = [1/6;2/15;2/15;1/6];','once');
end

% -------------------------------------------------------------------------
% C) Prepare final engine input-average patch if it is not already present.
% -------------------------------------------------------------------------
markerBegin='% FINAL_MPC_INPUT_INTERVAL_AVERAGE_BEGIN';
markerEnd='% FINAL_MPC_INPUT_INTERVAL_AVERAGE_END';

newEngineText=engineText;
markerCount=numel(strfind(newEngineText,markerBegin));

if markerCount==0
    oldBlock=[ ...
        'Sload=resample_horizon_anchors(Sload_anchor,dt_pre,dt_mpc, ...' newline ...
        '            cfg.mpc.horizon_h,cfg.forecast.interpolationMethod);'];

    nAnchors=numel(strfind(newEngineText,oldBlock));

    assert(nAnchors==2, ...
        ['Expected exactly two receding-MPC Sload resampling blocks; ' ...
         'found %d.'],nAnchors);

    avgBlock=[oldBlock newline ...
        '        ' markerBegin newline ...
        '        % Ordinary stage-value preprocessing on PREDICTIVE curves only.' newline ...
        '        % True 1-s Pload_true_box/PV1_curve are not modified.' newline ...
        '        if isfield(cfg.forecast,''useMPCIntervalAverage'') && ...' newline ...
        '                cfg.forecast.useMPCIntervalAverage' newline ...
        '            if size(Sload,2)>=2' newline ...
        '                Sload=[0.5*(Sload(:,1:end-1)+Sload(:,2:end)) Sload(:,end)];' newline ...
        '            end' newline ...
        '            if size(P_PV,2)>=2' newline ...
        '                P_PV=[0.5*(P_PV(:,1:end-1)+P_PV(:,2:end)) P_PV(:,end)];' newline ...
        '            end' newline ...
        '        end' newline ...
        '        ' markerEnd];

    newEngineText=strrep(newEngineText,oldBlock,avgBlock);
    markerCount=numel(strfind(newEngineText,markerBegin));
end

assert(markerCount==2, ...
    'Expected exactly two final predictive-input-average blocks; found %d.', ...
    markerCount);

assert(~contains(newEngineText,'MIDPOINT_EXEC_SMOKE_BEGIN'), ...
    'Production engine contains midpoint-execution smoke code.');
assert(~contains(newEngineText,'WHOLEAVG_EXEC_SMOKE_BEGIN'), ...
    'Production engine contains whole-average-execution smoke code.');

% -------------------------------------------------------------------------
% D) Prepare train_AIReserve path hygiene + visible average-mode banner.
% -------------------------------------------------------------------------
pathMarkerBegin='% TRAIN_AIRESERVE_PATH_HYGIENE_BEGIN';
pathMarkerEnd='% TRAIN_AIRESERVE_PATH_HYGIENE_END';

newTrainText=trainText;

if ~contains(newTrainText,pathMarkerBegin)
    anchor='addpath(genpath(projectRoot));';
    assert(contains(newTrainText,anchor), ...
        'Could not find train_AIReserve addpath(genpath(projectRoot)) line.');

    hygiene=[anchor newline ...
        pathMarkerBegin newline ...
        '% Archived/output copies must never shadow live production functions.' newline ...
        'nonRuntimeTrees={''archive'',''outputs'',''patch_files''};' newline ...
        'for iPath=1:numel(nonRuntimeTrees)' newline ...
        '    pDrop=fullfile(projectRoot,nonRuntimeTrees{iPath});' newline ...
        '    if exist(pDrop,''dir'')==7' newline ...
        '        try, rmpath(genpath(pDrop)); catch, end' newline ...
        '    end' newline ...
        'end' newline ...
        'clear config_island_ems system_case_catalog engine_island_ems' newline ...
        'rehash' newline ...
        pathMarkerEnd];

    newTrainText=strrep(newTrainText,anchor,hygiene);
end

bannerMarker='% TRAIN_AIRESERVE_INPUTAVG_BANNER';

if ~contains(newTrainText,bannerMarker)
    anchor='fprintf('' profile          : %s\n'',cfg.ai.response.profile);';

    assert(contains(newTrainText,anchor), ...
        'Could not find the training banner profile line.');

    banner=[anchor newline ...
        bannerMarker newline ...
        'if isfield(cfg.forecast,''useMPCIntervalAverage'')' newline ...
        '    avgModeOn=logical(cfg.forecast.useMPCIntervalAverage);' newline ...
        'else' newline ...
        '    avgModeOn=false;' newline ...
        'end' newline ...
        'if isfield(cfg.forecast,''mpcIntervalAverageMode'')' newline ...
        '    avgModeName=string(cfg.forecast.mpcIntervalAverageMode);' newline ...
        'else' newline ...
        '    avgModeName="not-configured";' newline ...
        'end' newline ...
        'fprintf('' MPC input average: %d (%s)\n'',avgModeOn,avgModeName);'];

    newTrainText=strrep(newTrainText,anchor,banner);
end

% -------------------------------------------------------------------------
% E) Display the intended state before changing anything.
% -------------------------------------------------------------------------
fprintf('\nINTENDED FINAL RUNTIME STATE\n');
fprintf('  Predictive MPC input averaging : ENABLED\n');
fprintf('  Average mode                    : adjacent-endpoint\n');
fprintf('  True 1-s physical input curves : UNCHANGED\n');
fprintf('  Output execution               : original ZOH\n');
fprintf('  33bus DG                       : [0.17 0.17 0.17] MW\n');
fprintf('  33bus PV                       : [1/6 2/15 2/15 1/6] MW\n');
fprintf('  Current training target        : 33bus only\n');
fprintf('  Engine average blocks          : %d\n',markerCount);
fprintf('  Trainer path hygiene present   : %d\n', ...
    contains(newTrainText,pathMarkerBegin));
fprintf('  Trainer average banner present : %d\n', ...
    contains(newTrainText,bannerMarker));

report=struct();
report.applyChanges=applyChanges;
report.liveConfigFile=string(liveCfgFile);
report.catalogFile=string(catalogFile);
report.engineFile=string(engineFile);
report.trainFile=string(trainFile);
report.engineAverageBlocks=markerCount;
report.trainPathHygienePlanned=contains(newTrainText,pathMarkerBegin);
report.trainAverageBannerPlanned=contains(newTrainText,bannerMarker);

if ~applyChanges
    fprintf('\nDRY RUN COMPLETE. No production file was modified.\n');
    return;
end

% -------------------------------------------------------------------------
% F) Backup LIVE production files, then write patches.
% -------------------------------------------------------------------------
stamp=datestr(now,'yyyymmdd_HHMMSS');
backupRoot=fullfile(projectRoot,'archive', ...
    ['runtime_repair_' stamp]);

if ~exist(backupRoot,'dir')
    mkdir(backupRoot);
end

copyfile(liveCfgFile,fullfile(backupRoot,'config_island_ems.m'));
copyfile(catalogFile,fullfile(backupRoot,'system_case_catalog.m'));
copyfile(engineFile,fullfile(backupRoot,'engine_island_ems.m'));
copyfile(trainFile,fullfile(backupRoot,'train_AIReserve.m'));

write_text_local(liveCfgFile,newCfgText);
write_text_local(catalogFile,newCatalogText);
write_text_local(engineFile,newEngineText);
write_text_local(trainFile,newTrainText);

% Remove non-runtime paths AGAIN because the backup we just created must not
% become visible if the user later calls addpath(genpath(projectRoot)).
remove_nonruntime_paths_local(projectRoot);

clear config_island_ems system_case_catalog engine_island_ems train_AIReserve
rehash

% Explicitly put the live config directory first.
addpath(fileparts(liveCfgFile),'-begin');

resolvedCfg=which('config_island_ems');

assert(strcmpi(char(resolvedCfg),char(liveCfgFile)), ...
    ['Path hygiene verification failed.\nResolved config: %s\nExpected: %s'], ...
    resolvedCfg,liveCfgFile);

cfg=config_island_ems();

assert(isfield(cfg.forecast,'useMPCIntervalAverage') && ...
    logical(cfg.forecast.useMPCIntervalAverage), ...
    'LIVE config still does not enable predictive input averaging.');

assert(isfield(cfg.forecast,'mpcIntervalAverageMode'), ...
    'LIVE config is missing mpcIntervalAverageMode.');

assert(string(cfg.forecast.mpcIntervalAverageMode)=="adjacent-endpoint", ...
    'Unexpected mpcIntervalAverageMode.');

assert(isequal(string(cfg.experiment.systemCases),"33bus"), ...
    'experiment.systemCases is not 33bus.');

assert(isequal(string(cfg.ai.response.systemCases),"33bus"), ...
    'ai.response.systemCases is not 33bus.');

rng(0,'twister');
sys=system_case_catalog('33bus',cfg);

assert(max(abs(double(sys.DieselG_Pgfm_rate(:))-[0.17;0.17;0.17]))<1e-12, ...
    'Final DG verification failed.');

assert(max(abs(double(sys.PVInv_P_rateIn(:))-[1/6;2/15;2/15;1/6]))<1e-10, ...
    'Final PV verification failed.');

fprintf('\n=============================================================\n');
fprintf(' LIVE RUNTIME REPAIR: PASS\n');
fprintf('=============================================================\n');
fprintf('Resolved LIVE config             : %s\n',resolvedCfg);
fprintf('AVERAGE INPUT MODE               : ENABLED\n');
fprintf('Average-input definition         : %s\n', ...
    string(cfg.forecast.mpcIntervalAverageMode));
fprintf('Production engine average blocks : %d\n', ...
    numel(strfind(fileread(engineFile),markerBegin)));
fprintf('Output execution                 : original ZOH\n');
fprintf('33bus DG total                   : %.5f MW\n', ...
    sum(double(sys.DieselG_Pgfm_rate(:))));
fprintf('33bus PV total                   : %.5f MW\n', ...
    sum(double(sys.PVInv_P_rateIn(:))));
fprintf('Current training target          : %s\n', ...
    strjoin(string(cfg.ai.response.systemCases),','));
fprintf('Backup                           : %s\n',backupRoot);
fprintf('Simulation/training launched     : NO\n');
fprintf('=============================================================\n');

report.backupRoot=string(backupRoot);
report.resolvedConfigAfter=string(resolvedCfg);
report.averageInputEnabled=true;
report.averageInputMode=string(cfg.forecast.mpcIntervalAverageMode);

end


function cfgFile=find_live_config_local(projectRoot)

preferred={ ...
    fullfile(projectRoot,'config','config_island_ems.m'), ...
    fullfile(projectRoot,'config_island_ems.m')};

for i=1:numel(preferred)
    if exist(preferred{i},'file')==2
        cfgFile=preferred{i};
        return;
    end
end

D=dir(fullfile(projectRoot,'**','config_island_ems.m'));
candidates=strings(0,1);

for i=1:numel(D)
    f=fullfile(D(i).folder,D(i).name);
    low=lower(string(f));

    if contains(low,[filesep 'archive' filesep]) || ...
            contains(low,[filesep 'outputs' filesep]) || ...
            contains(low,[filesep 'patch_files' filesep])
        continue;
    end

    candidates(end+1,1)=string(f); %#ok<AGROW>
end

assert(numel(candidates)==1, ...
    'Could not uniquely identify LIVE config_island_ems.m. Candidates: %s', ...
    strjoin(candidates,' | '));

cfgFile=char(candidates(1));

end


function remove_nonruntime_paths_local(projectRoot)

dropNames={'archive','outputs','patch_files'};

for i=1:numel(dropNames)
    p=fullfile(projectRoot,dropNames{i});

    if exist(p,'dir')==7
        try
            rmpath(genpath(p));
        catch
        end
    end
end

end


function write_text_local(fileName,text)

tmp=[fileName '.tmp_runtime_repair'];

fid=fopen(tmp,'w');
assert(fid>0,'Could not write temporary file: %s',tmp);
fwrite(fid,text,'char');
fclose(fid);

[ok,msg]=movefile(tmp,fileName,'f');
assert(ok,'Could not install %s: %s',fileName,msg);

end
