function pCmd = common_forecast_shaped_bess_value_v2( ...
    Pbatt_opt_Dec,execIdx,RealStep,samplesPerDecision,ii, ...
    Sload,P_PV,BatteryGFL_P_rate,BusOfBattery, ...
    SOC,SOCmin,SOCmax,BatteryGFM_Num)
%COMMON_FORECAST_SHAPED_BESS_VALUE_V2
% Forecast-shaped, zero-mean intra-interval realization for one stationary
% GFL BESS active-power command.
%
% Positive battery power = discharge/injection.
%
% Aggregate shaping law:
%   dPnet = Pnet_hat(2)-Pnet_hat(1)
%   xi    = (t-t_k)/DeltaT
%   dPBESS_total = (xi-1/2)*dPnet
%
% The requested support has zero continuous-time interval mean because
% integral_0^1 (xi-1/2) dxi = 0.
%
% The four stationary BESS units share support by their active-power ratings.
% Power ratings and SoC limits are enforced. No fitted/tuned gain is used.

N=size(Pbatt_opt_Dec,1);
k=min(max(round(execIdx),1),N);
pBase=double(Pbatt_opt_Dec(k,1,ii));

if size(Sload,2)<2 || size(P_PV,2)<2
    pCmd=pBase;
    return;
end

pNet1=sum(real(double(Sload(:,1)))) - sum(real(double(P_PV(:,1))));
pNet2=sum(real(double(Sload(:,2)))) - sum(real(double(P_PV(:,2))));
dPnet=pNet2-pNet1;

r=mod(round(RealStep)-1,samplesPerDecision);
xi=double(r)/double(samplesPerDecision);
xi=min(max(xi,0),1);

dPtotal=(xi-0.5)*dPnet;

nBatt=numel(BusOfBattery);
pmax=zeros(nBatt,1);

% Support both bus-indexed and unit-indexed rating vectors.
useBusIndex=size(BatteryGFL_P_rate,1)>=max(BusOfBattery);

for jj=1:nBatt
    if useBusIndex
        pmax(jj)=double(BatteryGFL_P_rate(BusOfBattery(jj),1));
    else
        pmax(jj)=double(BatteryGFL_P_rate(jj,1));
    end
end

sumPmax=sum(pmax);

if sumPmax<=0
    pCmd=pBase;
    return;
end

dPi=(pmax(ii)/sumPmax)*dPtotal;

% Directional SoC protection. Stationary GFL BESS states follow any GFM
% battery states in the storage state vector.
socIdx=BatteryGFM_Num+ii;

if socIdx>=1 && socIdx<=size(SOC,1)
    socNow=double(SOC(socIdx,RealStep));
    tol=1e-4;

    if dPi>0 && socNow<=double(SOCmin)+tol
        dPi=0;
    end

    if dPi<0 && socNow>=double(SOCmax)-tol
        dPi=0;
    end
end

pCmd=pBase+dPi;
pCmd=min(max(pCmd,-pmax(ii)),pmax(ii));

end
