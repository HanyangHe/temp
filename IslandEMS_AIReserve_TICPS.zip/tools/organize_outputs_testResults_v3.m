function report = organize_outputs_testResults_v3(projectRoot,applyChanges)
%ORGANIZE_OUTPUTS_TESTRESULTS_V3
% Move ONLY clearly unofficial/test-development outputs under outputs/testResults.
%
% v3 change:
%   - DO NOT move any 10bus or 18bus training-response folders.
%   - These may be part of the provenance/backups for the already-frozen
%     formal 10/18 studies and should remain outside testResults for now.
%   - Only known 33bus case-design / diagnostic / training-development
%     folders are moved automatically.
%
% Dry run:
%   R = organize_outputs_testResults_v3(pwd,false);
%
% Apply:
%   R = organize_outputs_testResults_v3(pwd,true);

if nargin<1 || isempty(projectRoot)
    projectRoot=pwd;
end
if nargin<2 || isempty(applyChanges)
    applyChanges=false;
end

projectRoot=char(projectRoot);
applyChanges=logical(applyChanges);

outRoot=fullfile(projectRoot,'outputs');
testRoot=fullfile(outRoot,'testResults');

assert(exist(outRoot,'dir')==7,'outputs folder not found: %s',outRoot);

groups=struct();

groups.caseDesign33bus={ ...
    'temporary_modelroot', ...
    'DG160kW_PV600kW', ...
    'shadow_catalog', ...
    'DG160kW_PV900kW', ...
    'DG170kW_PV600kW', ...
    'midpoint_residual_diagnosis', ...
    'residual_diagnosis', ...
    'shadow_runtime', ...
    'shadow_runtime_inputavg_midexec_v1', ...
    'shadow_runtime_inputavg_wholeavg_v1', ...
    'shadow_runtime_v3', ...
    'DG180kW_PV600kW', ...
    'residual_transient_forensics', ...
    'diagnosis_vs_DG016', ...
    '33bus_seed2_enrichment_candidate', ...
    '33bus_rebalanced_case_F1_test', ...
    '33bus_PV_effect_fixed_DG016', ...
    '33bus_input_interval_average_smoke', ...
    '33bus_dispatch_transition_audit', ...
    '33bus_case_screen_DG018_PV060', ...
    '33bus_case_screen_DG017_PV060', ...
    '33bus_case_parameter_audit'};

groups.diagnostics={ ...
    'DG_governor_MPC_ramp_audit', ...
    'diagnose_full_reserve_envelope', ...
    'krr_seed_learning_curve_33bus', ...
    'krr_hyperparam_scan_33bus', ...
    'krr_diagnostics_33bus', ...
    'krr_crossgrid_grouped_consistency', ...
    'krr_boundary_weight_test_33bus'};

% Only 33-bus training-development runs are classified as test/development.
groups.training33busDevelopment={ ...
    'training_33bus_response_*'};

% Explicitly protected formal/frozen outputs and training provenance.
protectedExact={ ...
    '20260910_finalP1_10bus', ...
    '20260908_finalP1S3_18bus'};

protectedPatterns={ ...
    'training_10bus_response_*', ...
    'training_18bus_response_*'};

fprintf('\n=============================================================\n');
if applyChanges
    fprintf(' ORGANIZE outputs/testResults V3 -- APPLY\n');
else
    fprintf(' ORGANIZE outputs/testResults V3 -- DRY RUN\n');
end
fprintf('=============================================================\n');

moveRows=struct([]);
groupNames=fieldnames(groups);

for ig=1:numel(groupNames)
    groupName=groupNames{ig};
    patterns=groups.(groupName);

    for ip=1:numel(patterns)
        pat=patterns{ip};
        D=dir(fullfile(outRoot,pat));

        for id=1:numel(D)
            if ~D(id).isdir || any(strcmp(D(id).name,{'.','..'}))
                continue;
            end

            name=D(id).name;

            if strcmp(name,'testResults') || any(strcmp(name,protectedExact))
                continue;
            end

            if matches_any_pattern_local(name,protectedPatterns)
                continue;
            end

            src=fullfile(outRoot,name);
            dstDir=fullfile(testRoot,groupName);
            dst=fullfile(dstDir,name);

            if ~isempty(moveRows)
                existing=string({moveRows.source});
                if any(existing==string(src))
                    continue;
                end
            end

            r=struct();
            r.group=string(groupName);
            r.name=string(name);
            r.source=string(src);
            r.destination=string(dst);
            r.status="PLANNED";

            if isempty(moveRows)
                moveRows=r;
            else
                moveRows(end+1)=r; %#ok<AGROW>
            end
        end
    end
end

if isempty(moveRows)
    T=table();
    fprintf('No matching unofficial output folders were found.\n');
else
    T=struct2table(moveRows);
    disp(T(:,{'group','name','source','destination'}));
end

fprintf('\nProtected formal/frozen folders:\n');
for i=1:numel(protectedExact)
    fprintf('  %-40s exists=%d\n',protectedExact{i}, ...
        exist(fullfile(outRoot,protectedExact{i}),'dir')==7);
end

fprintf('\nProtected training provenance patterns:\n');
for i=1:numel(protectedPatterns)
    D=dir(fullfile(outRoot,protectedPatterns{i}));
    fprintf('  %-40s matches=%d\n',protectedPatterns{i}, ...
        nnz([D.isdir]));
end

if ~applyChanges
    fprintf('\nDRY RUN COMPLETE. Nothing moved.\n');
    fprintf('10bus/18bus training-response folders are explicitly protected.\n');

    report=struct();
    report.table=T;
    report.applied=false;
    report.testRoot=string(testRoot);
    report.protectedExact=string(protectedExact);
    report.protectedPatterns=string(protectedPatterns);
    return;
end

if ~exist(testRoot,'dir')
    mkdir(testRoot);
end

for i=1:height(T)
    src=char(T.source(i));
    dst=char(T.destination(i));
    dstDir=fileparts(dst);

    if ~exist(dstDir,'dir')
        mkdir(dstDir);
    end

    if exist(dst,'dir')==7
        stamp=datestr(now,'yyyymmdd_HHMMSS');
        dst=[dst '__moved_' stamp];
        T.destination(i)=string(dst);
    end

    [ok,msg]=movefile(src,dst);
    assert(ok,'Failed moving %s -> %s: %s',src,dst,msg);

    T.status(i)="MOVED";
end

stamp=datestr(now,'yyyymmdd_HHMMSS');
manifest=fullfile(testRoot,['move_manifest_v3_' stamp '.csv']);
writetable(T,manifest);

fprintf('\nOrganization complete.\n');
fprintf('testResults root: %s\n',testRoot);
fprintf('Manifest        : %s\n',manifest);
fprintf('10bus/18bus training provenance was NOT moved.\n');
fprintf('No data was deleted.\n');

report=struct();
report.table=T;
report.applied=true;
report.testRoot=string(testRoot);
report.manifest=string(manifest);
report.protectedExact=string(protectedExact);
report.protectedPatterns=string(protectedPatterns);

end


function tf=matches_any_pattern_local(name,patterns)

tf=false;

for i=1:numel(patterns)
    pat=patterns{i};

    % Convert the simple wildcard convention used here to regexp.
    expr=regexptranslate('wildcard',pat);

    if ~isempty(regexp(name,['^' expr '$'],'once'))
        tf=true;
        return;
    end
end

end
