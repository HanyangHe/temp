function report = organize_outputs_testResults(projectRoot,applyChanges)
%ORGANIZE_OUTPUTS_TESTRESULTS Move known unofficial output folders under
% outputs/testResults. Uses an explicit whitelist; unknown folders are left.
%
% Dry run: R=organize_outputs_testResults(pwd,false);
% Apply:   R=organize_outputs_testResults(pwd,true);

if nargin<1 || isempty(projectRoot), projectRoot=pwd; end
if nargin<2 || isempty(applyChanges), applyChanges=false; end
projectRoot=char(projectRoot); applyChanges=logical(applyChanges);

outRoot=fullfile(projectRoot,'outputs');
testRoot=fullfile(outRoot,'testResults');
assert(exist(outRoot,'dir')==7,'outputs folder not found: %s',outRoot);

groups=struct();
groups.caseDesign33bus={ ...
    '33bus_seed2_enrichment_candidate', ...
    '33bus_rebalanced_case_F1_test', ...
    '33bus_PV_effect_fixed_DG016', ...
    '33bus_input_interval_average_smoke', ...
    '33bus_dispatch_transition_audit', ...
    '33bus_case_screen_DG018_PV060', ...
    '33bus_case_screen_DG017_PV060', ...
    '33bus_case_parameter_audit'};

groups.diagnostics={ ...
    'DG_governor_MPC_ramp_audit', ...
    'diagnose_full_reserve_envelope', ...
    'krr_seed_learning_curve_33bus', ...
    'krr_hyperparam_scan_33bus', ...
    'krr_diagnostics_33bus', ...
    'krr_crossgrid_grouped_consistency', ...
    'krr_boundary_weight_test_33bus'};

groups.trainingArchive={ ...
    'training_pipeline_inspection', ...
    'training_checkpoints', ...
    'training_33bus_response_*', ...
    'training_10bus_response_*', ...
    'training_18bus_response_*'};

protected={'20260910_finalP1_10bus','20260908_finalP1S3_18bus'};

fprintf('\n=============================================================\n');
fprintf(' ORGANIZE outputs/testResults -- %s\n',ternary_local(applyChanges,'APPLY','DRY RUN'));
fprintf('=============================================================\n');

rows=struct([]); names=fieldnames(groups);
for ig=1:numel(names)
    group=names{ig}; pats=groups.(group);
    for ip=1:numel(pats)
        D=dir(fullfile(outRoot,pats{ip}));
        for id=1:numel(D)
            if ~D(id).isdir || any(strcmp(D(id).name,{'.','..'})), continue; end
            nm=D(id).name;
            if strcmp(nm,'testResults') || any(strcmp(nm,protected)), continue; end
            src=fullfile(outRoot,nm);
            if ~isempty(rows) && any(string({rows.source})==string(src)), continue; end
            r=struct('group',string(group),'name',string(nm), ...
                'source',string(src), ...
                'destination',string(fullfile(testRoot,group,nm)), ...
                'status',"PLANNED");
            if isempty(rows), rows=r; else, rows(end+1)=r; end %#ok<AGROW>
        end
    end
end

if isempty(rows)
    T=table(); fprintf('No known unofficial folders found.\n');
else
    T=struct2table(rows); disp(T(:,{'group','name','destination'}));
end

fprintf('\nProtected formal folders remain top-level:\n');
for i=1:numel(protected)
    fprintf('  %-30s exists=%d\n',protected{i},exist(fullfile(outRoot,protected{i}),'dir')==7);
end

if ~applyChanges
    fprintf('\nDRY RUN COMPLETE -- nothing moved.\n');
    report=struct('table',T,'applied',false,'testRoot',string(testRoot)); return;
end

if ~exist(testRoot,'dir'), mkdir(testRoot); end
for i=1:height(T)
    src=char(T.source(i)); dst=char(T.destination(i)); dstDir=fileparts(dst);
    if ~exist(dstDir,'dir'), mkdir(dstDir); end
    if exist(dst,'dir')==7
        dst=[dst '__moved_' datestr(now,'yyyymmdd_HHMMSS')];
        T.destination(i)=string(dst);
    end
    [ok,msg]=movefile(src,dst); assert(ok,'Failed %s -> %s: %s',src,dst,msg);
    T.status(i)="MOVED";
end

stamp=datestr(now,'yyyymmdd_HHMMSS');
manifest=fullfile(testRoot,['move_manifest_' stamp '.csv']);
writetable(T,manifest);
fprintf('\nOrganization complete. No data deleted.\n');
fprintf('testResults: %s\nManifest: %s\n',testRoot,manifest);
report=struct('table',T,'applied',true,'testRoot',string(testRoot),'manifest',string(manifest));
end

function out=ternary_local(tf,a,b)
if tf, out=a; else, out=b; end
end
