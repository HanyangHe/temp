function report = organize_outputs_testResults_v2(projectRoot,applyChanges)
%ORGANIZE_OUTPUTS_TESTRESULTS_V2
% Move KNOWN unofficial diagnostic/smoke/development output folders under
% outputs/testResults. Unknown folders are never moved automatically.
%
% Dry run:
%   R = organize_outputs_testResults_v2(pwd,false);
%
% Apply:
%   R = organize_outputs_testResults_v2(pwd,true);

if nargin<1 || isempty(projectRoot)
    projectRoot=pwd;
end
if nargin<2 || isempty(applyChanges)
    applyChanges=false;
end

projectRoot=char(projectRoot);
applyChanges=logical(applyChanges);

outRoot=fullfile(projectRoot,'outputs');
testRoot=fullfile(outRoot,'testResults');

assert(exist(outRoot,'dir')==7,'outputs folder not found: %s',outRoot);

groups=struct();

groups.caseDesign33bus={ ...
    '33bus_seed2_enrichment_candidate', ...
    '33bus_rebalanced_case_F1_test', ...
    '33bus_PV_effect_fixed_DG016', ...
    '33bus_input_interval_average_smoke', ...
    '33bus_dispatch_transition_audit', ...
    '33bus_case_screen_DG018_PV060', ...
    '33bus_case_screen_DG017_PV060', ...
    '33bus_case_parameter_audit'};

groups.diagnostics={ ...
    'DG_governor_MPC_ramp_audit', ...
    'diagnose_full_reserve_envelope', ...
    'krr_seed_learning_curve_33bus', ...
    'krr_hyperparam_scan_33bus', ...
    'krr_diagnostics_33bus', ...
    'krr_crossgrid_grouped_consistency', ...
    'krr_boundary_weight_test_33bus'};

groups.trainingArchive={ ...
    'training_pipeline_inspection', ...
    'training_checkpoints', ...
    'training_33bus_response_*', ...
    'training_10bus_response_*', ...
    'training_18bus_response_*'};

protected={ ...
    '20260910_finalP1_10bus', ...
    '20260908_finalP1S3_18bus'};

fprintf('\n=============================================================\n');

if applyChanges
    fprintf(' ORGANIZE outputs/testResults -- APPLY\n');
else
    fprintf(' ORGANIZE outputs/testResults -- DRY RUN\n');
end

fprintf('=============================================================\n');

moveRows=struct([]);
groupNames=fieldnames(groups);

for ig=1:numel(groupNames)
    groupName=groupNames{ig};
    patterns=groups.(groupName);

    for ip=1:numel(patterns)
        pat=patterns{ip};
        D=dir(fullfile(outRoot,pat));

        for id=1:numel(D)
            if ~D(id).isdir || any(strcmp(D(id).name,{'.','..'}))
                continue;
            end

            name=D(id).name;

            if strcmp(name,'testResults') || any(strcmp(name,protected))
                continue;
            end

            src=fullfile(outRoot,name);
            dstDir=fullfile(testRoot,groupName);
            dst=fullfile(dstDir,name);

            if ~isempty(moveRows)
                existing=string({moveRows.source});
                if any(existing==string(src))
                    continue;
                end
            end

            r=struct();
            r.group=string(groupName);
            r.name=string(name);
            r.source=string(src);
            r.destination=string(dst);
            r.status="PLANNED";

            if isempty(moveRows)
                moveRows=r;
            else
                moveRows(end+1)=r; %#ok<AGROW>
            end
        end
    end
end

if isempty(moveRows)
    T=table();
    fprintf('No matching unofficial output folders were found.\n');
else
    T=struct2table(moveRows);
    disp(T(:,{'group','name','source','destination'}));
end

fprintf('\nProtected formal folders:\n');
for i=1:numel(protected)
    fprintf('  %s  exists=%d\n',protected{i}, ...
        exist(fullfile(outRoot,protected{i}),'dir')==7);
end

if ~applyChanges
    fprintf('\nDRY RUN COMPLETE. Nothing moved.\n');

    report=struct();
    report.table=T;
    report.applied=false;
    report.testRoot=string(testRoot);
    return;
end

if ~exist(testRoot,'dir')
    mkdir(testRoot);
end

for i=1:height(T)
    src=char(T.source(i));
    dst=char(T.destination(i));
    dstDir=fileparts(dst);

    if ~exist(dstDir,'dir')
        mkdir(dstDir);
    end

    if exist(dst,'dir')==7
        stamp=datestr(now,'yyyymmdd_HHMMSS');
        dst=[dst '__moved_' stamp];
        T.destination(i)=string(dst);
    end

    [ok,msg]=movefile(src,dst);
    assert(ok,'Failed moving %s -> %s: %s',src,dst,msg);

    T.status(i)="MOVED";
end

stamp=datestr(now,'yyyymmdd_HHMMSS');
manifest=fullfile(testRoot,['move_manifest_' stamp '.csv']);
writetable(T,manifest);

fprintf('\nOrganization complete.\n');
fprintf('testResults root: %s\n',testRoot);
fprintf('Manifest        : %s\n',manifest);
fprintf('No data was deleted.\n');

report=struct();
report.table=T;
report.applied=true;
report.testRoot=string(testRoot);
report.manifest=string(manifest);

end
