function write_text_atomic_v1(fileName,text)
%WRITE_TEXT_ATOMIC_V1 Write text through a temporary file then move.

tmp=[fileName '.tmp_write_atomic_v1'];

fid=fopen(tmp,'w');
assert(fid>0,'Could not write temporary file: %s',tmp);

fwrite(fid,text,'char');
fclose(fid);

[ok,msg]=movefile(tmp,fileName,'f');
assert(ok,'Could not install %s: %s',fileName,msg);

end
