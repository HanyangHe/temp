function report = restore_boundary_crossfade_engine_v1(projectRoot)
%RESTORE_BOUNDARY_CROSSFADE_ENGINE_V1
% Emergency restore for the temporary boundary-crossfade test.
%
% Safe to run if no marker remains.
%
% Usage:
%   Rrestore = restore_boundary_crossfade_engine_v1(pwd);

if nargin<1 || isempty(projectRoot)
    projectRoot=pwd;
end
projectRoot=char(projectRoot);

engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');
assert(exist(engineFile,'file')==2,'Engine missing: %s',engineFile);

marker='% TEST_ENERGY_NEUTRAL_BOUNDARY_CROSSFADE_V1_BEGIN';
txt=fileread(engineFile);

report=struct();
report.engineFile=string(engineFile);
report.markerCount=numel(strfind(txt,marker));
report.restored=false;

if report.markerCount==0
    fprintf('Boundary-crossfade marker is not present. No restore needed.\n');
    return;
end

backupRoot=fullfile(projectRoot,'outputs','cache', ...
    'energy_neutral_boundary_crossfade_test_v1');

D=dir(fullfile(backupRoot,'**','engine_island_ems_before_test_*.m'));
assert(~isempty(D),'No pre-test engine backup was found.');

[~,idx]=max([D.datenum]);
backupFile=fullfile(D(idx).folder,D(idx).name);
backupText=fileread(backupFile);

assert(~contains(backupText,marker), ...
    'Newest backup unexpectedly contains the test marker.');

tmp=[engineFile '.tmp_restore_crossfade_v1'];
fid=fopen(tmp,'w');
assert(fid>0,'Could not write restore temp file.');
fwrite(fid,backupText,'char');
fclose(fid);

[ok,msg]=movefile(tmp,engineFile,'f');
assert(ok,'Could not restore engine: %s',msg);

clear engine_island_ems
rehash;

assert(strcmp(fileread(engineFile),backupText), ...
    'Restoration verification failed.');

report.backupFile=string(backupFile);
report.restored=true;

fprintf('Engine restored from:\n  %s\n',backupFile);
fprintf('Verification: PASS\n');

end
