function report = apply_final_P1_S3_formal_patch(projectRoot)
%APPLY_FINAL_P1_S3_FORMAL_PATCH Install the final P1 forecast-guard policy.
%
% Final paper semantics:
%   P1U = uncalibrated KRR adaptive reserve, NO forecast guard
%   P1  = uncalibrated KRR adaptive reserve + two-branch forecast guard
%   C0/C1/P1 share the same guarded reserve policy in Part II
%
% Frozen guard parameters:
%   moderate net-load drop threshold : 0.02 pu
%   moderate branch net-load minimum : 0.60 pu
%   severe net-load drop threshold   : 0.11 pu
%   shield alpha                     : 1.00
%
% The KRR feature contract and trained model are unchanged.
% Existing 18-bus KRR model does NOT need retraining for this patch.
%
% The installer:
%   1) backs up every production file it changes;
%   2) installs final paper_method_catalog / paper_study_catalog;
%   3) installs final build_reserve_features / predict_reserve_ratio;
%   4) installs the study-specific run_experiments scheduler;
%   5) patches run_single_experiment so the guard is method-specific;
%   6) patches/normalizes the engine forecast-metadata hook;
%   7) updates config defaults/comments;
%   8) runs a no-simulation contract test.

if nargin<1 || isempty(projectRoot)
    projectRoot=pwd;
end
projectRoot=char(projectRoot);

patchRoot=fileparts(fileparts(mfilename('fullpath')));
addpath(genpath(projectRoot));
addpath(genpath(patchRoot));
rehash;

stamp=datestr(now,'yyyymmdd_HHMMSS');
backups={};

fprintf('\n=============================================================\n');
fprintf(' INSTALL FINAL P1 FORECAST-GUARD FORMAL PATCH\n');
fprintf('=============================================================\n');

%% Required project files
cfgFile=fullfile(projectRoot,'config','config_island_ems.m');
methodFile=fullfile(projectRoot,'config','paper_method_catalog.m');
studyFile=fullfile(projectRoot,'config','paper_study_catalog.m');
engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');

runSingleFile=which('run_single_experiment');
runExperimentsFile=which('run_experiments');

assert(exist(cfgFile,'file')==2,'Missing %s',cfgFile);
assert(exist(engineFile,'file')==2,'Missing %s',engineFile);
assert(~isempty(runSingleFile),'Could not locate run_single_experiment.m.');
assert(~isempty(runExperimentsFile),'Could not locate run_experiments.m.');

assert(startsWith(lower(runSingleFile),lower(projectRoot)), ...
    'run_single_experiment resolves outside project: %s',runSingleFile);
assert(startsWith(lower(runExperimentsFile),lower(projectRoot)), ...
    'run_experiments resolves outside project: %s',runExperimentsFile);

%% Install complete supplied files
pairs={ ...
    fullfile(patchRoot,'config','paper_method_catalog.m'), methodFile; ...
    fullfile(patchRoot,'config','paper_study_catalog.m'), studyFile; ...
    fullfile(patchRoot,'ai','build_reserve_features.m'), ...
        fullfile(projectRoot,'ai','build_reserve_features.m'); ...
    fullfile(patchRoot,'ai','predict_reserve_ratio.m'), ...
        fullfile(projectRoot,'ai','predict_reserve_ratio.m'); ...
    fullfile(patchRoot,'core','run_experiments.m'), runExperimentsFile};

for k=1:size(pairs,1)
    src=pairs{k,1};
    dst=pairs{k,2};
    assert(exist(src,'file')==2,'Patch source missing: %s',src);
    assert(exist(dst,'file')==2,'Project target missing: %s',dst);
    backups{end+1}=backup_local(dst,stamp); %#ok<AGROW>
    copyfile(src,dst,'f');
    fprintf('[INSTALLED] %s\n',dst);
end

%% Patch config_island_ems.m
txt=normalize_newlines_local(fileread(cfgFile));
oldTxt=txt;

% Final deployment no longer uses the global additive calibration.
txt=strrep(txt, ...
    'cfg.ai.useSafetyCalibration = true;', ...
    'cfg.ai.useSafetyCalibration = false;');

% Remove stale "calibrated predicted stress" wording when present.
txt=strrep(txt, ...
    'the smallest candidate alpha whose CALIBRATED predicted stress is <=1 is', ...
    'the smallest candidate alpha whose predicted stress is <=1 is');

% Remove stale claim that alpha=1 is intrinsically secure.
txt=strrep(txt, ...
    ['% Formal reserve-policy range.  After increasing the nominal physics reserve' newline ...
     '% to the 0.30-Hz design bandwidth, alpha=1 is secure in the representative' newline ...
     '% radial 18-bus smoke test.  The AI is therefore only allowed to REMOVE' newline ...
     '% unnecessary conservatism; it never requests more than the full physics' newline ...
     '% reserve in the formal study.'], ...
    ['% Formal reserve-policy range. alpha=1 is the conventional full physics' newline ...
     '% reserve baseline. Because 15-min EMS decisions are evaluated against' newline ...
     '% 1-s physical dynamics, residual cross-layer frequency discrepancies are' newline ...
     '% assessed a posteriori rather than treating alpha=1 as a hard dynamic' newline ...
     '% security certificate.']);

marker='% FINAL_P1_FORECAST_GUARD_DEFAULTS';

if ~contains(txt,marker)
    anchor='cfg.ai.useSafetyCalibration = false;';
    assert(contains(txt,anchor), ...
        'Could not locate cfg.ai.useSafetyCalibration assignment.');

    block=[anchor newline ...
        marker newline ...
        '% Method-specific enable/disable is applied in run_single_experiment.' newline ...
        '% Keep the global default OFF so training/legacy runs are unaffected.' newline ...
        'cfg.ai.enableForecastSafetyShield = false;' newline ...
        'cfg.ai.forecastSafetyShieldDropThreshold_pu = 0.02;' newline ...
        'cfg.ai.forecastSafetyShieldNetLoadMin_pu = 0.60;' newline ...
        'cfg.ai.forecastSafetyShieldSevereDropEnabled = true;' newline ...
        'cfg.ai.forecastSafetyShieldSevereDropThreshold_pu = 0.11;' newline ...
        'cfg.ai.forecastSafetyShieldAlpha = 1.00;'];

    txt=strrep(txt,anchor,block);
end

if ~strcmp(txt,oldTxt)
    backups{end+1}=backup_local(cfgFile,stamp); %#ok<AGROW>
    write_text_local(cfgFile,txt);
    fprintf('[PATCHED]   %s\n',cfgFile);
else
    fprintf('[UNCHANGED] %s\n',cfgFile);
end

%% Patch run_single_experiment.m: method-specific final guard settings
txt=normalize_newlines_local(fileread(runSingleFile));
oldTxt=txt;

marker='% FINAL_P1_METHOD_SPECIFIC_FORECAST_GUARD';

if ~contains(txt,marker)
    anchor='aiCfgRun.useSafetyCalibration = runCfg.aiSafetyCalibration;';
    assert(contains(txt,anchor), ...
        ['Could not locate aiCfgRun.useSafetyCalibration assignment in ' ...
         'run_single_experiment.m.']);

    block=[anchor newline ...
        marker newline ...
        '% P1/P1U guard selection belongs to the method catalog, not global cfg.' newline ...
        'aiCfgRun.enableForecastSafetyShield = false;' newline ...
        'if isfield(runCfg,''aiForecastSafetyShield'') && ~isempty(runCfg.aiForecastSafetyShield)' newline ...
        '    aiCfgRun.enableForecastSafetyShield = logical(runCfg.aiForecastSafetyShield);' newline ...
        'end' newline ...
        'if isfield(runCfg,''aiForecastSafetyShieldDropThreshold_pu'') && isfinite(runCfg.aiForecastSafetyShieldDropThreshold_pu)' newline ...
        '    aiCfgRun.forecastSafetyShieldDropThreshold_pu = runCfg.aiForecastSafetyShieldDropThreshold_pu;' newline ...
        'end' newline ...
        'if isfield(runCfg,''aiForecastSafetyShieldNetLoadMin_pu'') && isfinite(runCfg.aiForecastSafetyShieldNetLoadMin_pu)' newline ...
        '    aiCfgRun.forecastSafetyShieldNetLoadMin_pu = runCfg.aiForecastSafetyShieldNetLoadMin_pu;' newline ...
        'end' newline ...
        'if isfield(runCfg,''aiForecastSafetyShieldSevereDropEnabled'') && ~isempty(runCfg.aiForecastSafetyShieldSevereDropEnabled)' newline ...
        '    aiCfgRun.forecastSafetyShieldSevereDropEnabled = logical(runCfg.aiForecastSafetyShieldSevereDropEnabled);' newline ...
        'end' newline ...
        'if isfield(runCfg,''aiForecastSafetyShieldSevereDropThreshold_pu'') && isfinite(runCfg.aiForecastSafetyShieldSevereDropThreshold_pu)' newline ...
        '    aiCfgRun.forecastSafetyShieldSevereDropThreshold_pu = runCfg.aiForecastSafetyShieldSevereDropThreshold_pu;' newline ...
        'end' newline ...
        'if isfield(runCfg,''aiForecastSafetyShieldAlpha'') && isfinite(runCfg.aiForecastSafetyShieldAlpha)' newline ...
        '    aiCfgRun.forecastSafetyShieldAlpha = runCfg.aiForecastSafetyShieldAlpha;' newline ...
        'end'];

    txt=strrep(txt,anchor,block);
end

if ~strcmp(txt,oldTxt)
    backups{end+1}=backup_local(runSingleFile,stamp); %#ok<AGROW>
    write_text_local(runSingleFile,txt);
    fprintf('[PATCHED]   %s\n',runSingleFile);
else
    fprintf('[ALREADY]   method-specific run_single_experiment guard hook\n');
end

%% Patch/normalize engine forecast metadata hook
txt=normalize_newlines_local(fileread(engineFile));
oldTxt=txt;

oldMarker='P1_FORECAST_SAFETY_SHIELD_EXPERIMENTAL';
finalMarker='P1_FORECAST_SAFETY_GUARD_FINAL';

if contains(txt,oldMarker)
    txt=strrep(txt,oldMarker,finalMarker);
end

if ~contains(txt,finalMarker)

    oldA=[ ...
        '        reserveFeature = build_reserve_features(Sload,P_PV, ...' newline ...
        '            DieselG_Pgfm_rate,dgUpHeadroom_pu);' newline ...
        '        reserveFeatureHistory(predictionStep,:) = reserveFeature;'];

    newA=[ ...
        '        [reserveFeature,reserveFeatureMeta] = build_reserve_features(Sload,P_PV, ...' newline ...
        '            DieselG_Pgfm_rate,dgUpHeadroom_pu);' newline ...
        '        reserveFeatureHistory(predictionStep,:) = reserveFeature;'];

    assert(contains(txt,oldA), ...
        'Could not locate original build_reserve_features call in engine.');
    txt=strrep(txt,oldA,newA);

    oldB=[ ...
        '        reserveTimer=tic;' newline ...
        '        [dP_RESVdown,dP_RESVup,reserveMeta] = compute_frequency_reserve_pu( ...' newline ...
        '            runCfg.reserveMode, reserveRatioRequest, Rdroop, phys.H, ...' newline ...
        '            df_reserve_Hz, rocof_limit_Hz_s, f_rate, aiModel, reserveFeature, ...' newline ...
        '            P_DGmin, P_DGmax, aiCfgRun);'];

    newB=[ ...
        '        % P1_FORECAST_SAFETY_GUARD_FINAL' newline ...
        '        % Directional forecast metadata is available before this MPC solve.' newline ...
        '        % It is used only by the post-KRR forecast guard, not by the frozen KRR input.' newline ...
        '        aiCfgStep = aiCfgRun;' newline ...
        '        aiCfgStep.forecastNetLoadNow_pu = reserveFeatureMeta.netLoadNow_pu;' newline ...
        '        aiCfgStep.forecastSignedNetRamp_pu = reserveFeatureMeta.signedNetRampForecast_pu;' newline ...
        '        aiCfgStep.forecastNetDrop_pu = reserveFeatureMeta.netDropForecast_pu;' newline ...
        '        reserveTimer=tic;' newline ...
        '        [dP_RESVdown,dP_RESVup,reserveMeta] = compute_frequency_reserve_pu( ...' newline ...
        '            runCfg.reserveMode, reserveRatioRequest, Rdroop, phys.H, ...' newline ...
        '            df_reserve_Hz, rocof_limit_Hz_s, f_rate, aiModel, reserveFeature, ...' newline ...
        '            P_DGmin, P_DGmax, aiCfgStep);'];

    assert(contains(txt,oldB), ...
        'Could not locate original compute_frequency_reserve_pu call in engine.');
    txt=strrep(txt,oldB,newB);
end

% If old experimental comments/hooks are already present, ensure the final
% marker is visible without duplicating the hook.
if contains(txt,'aiCfgStep.forecastNetDrop_pu') && ~contains(txt,finalMarker)
    anchor='        aiCfgStep = aiCfgRun;';
    txt=strrep(txt,anchor, ...
        ['        % P1_FORECAST_SAFETY_GUARD_FINAL' newline anchor]);
end

if ~strcmp(txt,oldTxt)
    backups{end+1}=backup_local(engineFile,stamp); %#ok<AGROW>
    write_text_local(engineFile,txt);
    fprintf('[PATCHED]   %s\n',engineFile);
else
    fprintf('[ALREADY]   final engine forecast-guard hook\n');
end

%% Reload + validate
clear config_island_ems paper_method_catalog paper_study_catalog ...
    run_single_experiment run_experiments build_reserve_features ...
    predict_reserve_ratio
rehash;
addpath(genpath(projectRoot));
addpath(genpath(patchRoot));

cfg=config_island_ems();
validate_config(cfg);

catalog=paper_method_catalog();
ids=string({catalog.id});
assert(all(ismember(["A0","T7","G1","P1U","P1","C0","C1"],ids)), ...
    'Final paper method catalog is incomplete.');

% Run contract test from patch folder.
test_final_P1_S3_formal_contract(projectRoot);

report=struct();
report.status='PASS';
report.projectRoot=projectRoot;
report.backups=backups;
report.finalP1='KRR + two-branch forecast guard, no global calibration';
report.guardParameters=[0.02 0.60 0.11 1.00];

fprintf('\n=============================================================\n');
fprintf(' FINAL P1 FORMAL PATCH: PASS\n');
fprintf('=============================================================\n');
fprintf('P1U : KRR, no calibration, no forecast guard\n');
fprintf('P1  : KRR, no calibration, final two-branch forecast guard\n');
fprintf('C0/C1/P1 use the same P1 reserve policy in Part II.\n');
fprintf('Part I remains decayRatio=1.00 only.\n');
fprintf('No KRR retraining is required for the existing 18-bus model.\n');
fprintf('=============================================================\n');
end


function p=backup_local(filePath,stamp)
p=[filePath '.before_final_P1_S3_' stamp '.bak'];
copyfile(filePath,p,'f');
fprintf('[BACKUP]    %s\n',p);
end


function txt=normalize_newlines_local(txt)
txt=strrep(txt,sprintf('\r\n'),sprintf('\n'));
txt=strrep(txt,sprintf('\r'),sprintf('\n'));
end


function write_text_local(filePath,txt)
fid=fopen(filePath,'w');
assert(fid>=0,'Could not open %s for writing.',filePath);
c=onCleanup(@() fclose(fid)); %#ok<NASGU>
fwrite(fid,txt,'char');
end
