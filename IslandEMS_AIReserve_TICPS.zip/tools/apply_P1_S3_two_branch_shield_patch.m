function apply_P1_S3_two_branch_shield_patch()
%APPLY_P1_S3_TWO_BRANCH_SHIELD_PATCH
% Replaces ONLY ai/predict_reserve_ratio.m with the experimental two-branch
% forecast-aware shield. The previous forecast metadata engine hook must
% already be installed.

clc;
projectRoot=pwd;
patchRoot=fileparts(fileparts(mfilename('fullpath')));

src=fullfile(patchRoot,'patch_files','ai','predict_reserve_ratio.m');
dst=fullfile(projectRoot,'ai','predict_reserve_ratio.m');
engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');

assert(exist(src,'file')==2,'Missing patch source: %s',src);
assert(exist(dst,'file')==2,'Missing project file: %s',dst);
assert(exist(engineFile,'file')==2,'Missing engine file: %s',engineFile);

assert(contains(fileread(engineFile),'P1_FORECAST_SAFETY_SHIELD_EXPERIMENTAL'), ...
    ['The previous forecast-shield engine hook is not installed. ', ...
     'Apply the earlier forecast-safety-shield smoke patch first.']);

stamp=datestr(now,'yyyymmdd_HHMMSS');
backup=[dst '.before_S3_two_branch_' stamp '.bak'];
copyfile(dst,backup,'f');
copyfile(src,dst,'f');

clear functions
rehash;
addpath(genpath(projectRoot));

assert(contains(fileread(dst),'forecastSafetyShieldSevereBranch'), ...
    'S3 predict_reserve_ratio.m verification failed.');

fprintf('\n=============================================================\n');
fprintf(' S3 TWO-BRANCH SHIELD PATCH APPLIED\n');
fprintf('=============================================================\n');
fprintf('Backup : %s\n',backup);
fprintf('Patched: %s\n',dst);
fprintf('No formal configuration was changed.\n');
fprintf('=============================================================\n');
end
