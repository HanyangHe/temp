function v = common_boundary_crossfade_value_v1(U,execIdx,RealStep, ...
    samplesPerDecision,blendWindowSamples,unitIndex)
%COMMON_BOUNDARY_CROSSFADE_VALUE_V1
% Symmetric, energy-neutral linear crossfade around an MPC boundary.

N=size(U,1);
k=min(max(round(execIdx),1),N);
uNow=double(U(k,1,unitIndex));

if N<=1 || samplesPerDecision<=1 || blendWindowSamples<2
    v=uNow;
    return;
end

H=floor(blendWindowSamples/2);
H=max(H,1);
r=mod(round(RealStep)-1,samplesPerDecision);

% First half after current boundary: previous -> current.
if r < H && k>1
    uPrev=double(U(k-1,1,unitIndex));
    beta=0.5 + 0.5*(double(r)/double(H));
    beta=min(max(beta,0),1);
    v=(1-beta)*uPrev + beta*uNow;
    return;
end

% Last half before next boundary: current -> next.
if r >= samplesPerDecision-H && k<N
    uNext=double(U(k+1,1,unitIndex));
    q=double(r-(samplesPerDecision-H))/double(H);
    beta=0.5*min(max(q,0),1);
    v=(1-beta)*uNow + beta*uNext;
    return;
end

v=uNow;

end
