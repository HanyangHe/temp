function report = organize_outputs_testResults_v4(projectRoot,applyChanges)
%ORGANIZE_OUTPUTS_TESTRESULTS_V4
% Robust organizer for unofficial 33-bus/test-development outputs.
%
% v4 changes:
%   1) 10bus/18bus formal results and training provenance remain protected.
%   2) Runtime scaffolding folders (temporary_modelroot, shadow_*) are NOT
%      moved automatically; they are reported separately.
%   3) A missing/already-moved source no longer aborts the entire organizer.
%   4) movefile failures are recorded in a manifest and processing continues.
%   5) No data is deleted.
%
% Dry run:
%   R = organize_outputs_testResults_v4(pwd,false);
%
% Apply:
%   R = organize_outputs_testResults_v4(pwd,true);

if nargin<1 || isempty(projectRoot)
    projectRoot=pwd;
end
if nargin<2 || isempty(applyChanges)
    applyChanges=false;
end

projectRoot=char(projectRoot);
applyChanges=logical(applyChanges);

outRoot=fullfile(projectRoot,'outputs');
testRoot=fullfile(outRoot,'testResults');

assert(exist(outRoot,'dir')==7,'outputs folder not found: %s',outRoot);

% -------------------------------------------------------------------------
% Explicit move whitelist: only actual result/data folders.
% -------------------------------------------------------------------------
groups=struct();

groups.caseDesign33bus={ ...
    'DG160kW_PV600kW', ...
    'DG160kW_PV900kW', ...
    'DG170kW_PV600kW', ...
    'DG180kW_PV600kW', ...
    'midpoint_residual_diagnosis', ...
    'residual_diagnosis', ...
    'residual_transient_forensics', ...
    'diagnosis_vs_DG016', ...
    '33bus_seed2_enrichment_candidate', ...
    '33bus_rebalanced_case_F1_test', ...
    '33bus_PV_effect_fixed_DG016', ...
    '33bus_input_interval_average_smoke', ...
    '33bus_dispatch_transition_audit', ...
    '33bus_case_screen_DG018_PV060', ...
    '33bus_case_screen_DG017_PV060', ...
    '33bus_case_parameter_audit'};

groups.diagnostics={ ...
    'DG_governor_MPC_ramp_audit', ...
    'diagnose_full_reserve_envelope', ...
    'krr_seed_learning_curve_33bus', ...
    'krr_hyperparam_scan_33bus', ...
    'krr_diagnostics_33bus', ...
    'krr_crossgrid_grouped_consistency', ...
    'krr_boundary_weight_test_33bus'};

groups.training33busDevelopment={ ...
    'training_33bus_response_*'};

% Runtime scaffolding is NOT valuable result provenance. Report it, but do
% not move or delete it automatically.
scaffoldPatterns={ ...
    'temporary_modelroot', ...
    'shadow_catalog', ...
    'shadow_runtime*'};

% Explicitly protected formal/frozen outputs and training provenance.
protectedExact={ ...
    '20260910_finalP1_10bus', ...
    '20260908_finalP1S3_18bus'};

protectedPatterns={ ...
    'training_10bus_response_*', ...
    'training_18bus_response_*'};

fprintf('\n=============================================================\n');
if applyChanges
    fprintf(' ORGANIZE outputs/testResults V4 -- APPLY\n');
else
    fprintf(' ORGANIZE outputs/testResults V4 -- DRY RUN\n');
end
fprintf('=============================================================\n');

% -------------------------------------------------------------------------
% Build move plan.
% -------------------------------------------------------------------------
moveRows=struct([]);
groupNames=fieldnames(groups);

for ig=1:numel(groupNames)
    groupName=groupNames{ig};
    patterns=groups.(groupName);

    for ip=1:numel(patterns)
        pat=patterns{ip};
        D=dir(fullfile(outRoot,pat));

        for id=1:numel(D)
            if ~D(id).isdir || any(strcmp(D(id).name,{'.','..'}))
                continue;
            end

            name=D(id).name;

            if strcmp(name,'testResults') || any(strcmp(name,protectedExact))
                continue;
            end

            if matches_any_pattern_local(name,protectedPatterns)
                continue;
            end

            if matches_any_pattern_local(name,scaffoldPatterns)
                continue;
            end

            src=fullfile(outRoot,name);
            dstDir=fullfile(testRoot,groupName);
            dst=fullfile(dstDir,name);

            if ~isempty(moveRows)
                existing=string({moveRows.source});
                if any(existing==string(src))
                    continue;
                end
            end

            r=struct();
            r.group=string(groupName);
            r.name=string(name);
            r.source=string(src);
            r.destination=string(dst);
            r.status="PLANNED";
            r.message="";

            if isempty(moveRows)
                moveRows=r;
            else
                moveRows(end+1)=r; %#ok<AGROW>
            end
        end
    end
end

if isempty(moveRows)
    T=table();
    fprintf('No matching unofficial result folders were found.\n');
else
    T=struct2table(moveRows);
    disp(T(:,{'group','name','source','destination'}));
end

% -------------------------------------------------------------------------
% Report protected content.
% -------------------------------------------------------------------------
fprintf('\nProtected formal/frozen folders:\n');
for i=1:numel(protectedExact)
    fprintf('  %-40s exists=%d\n',protectedExact{i}, ...
        exist(fullfile(outRoot,protectedExact{i}),'dir')==7);
end

fprintf('\nProtected training provenance patterns:\n');
for i=1:numel(protectedPatterns)
    D=dir(fullfile(outRoot,protectedPatterns{i}));
    fprintf('  %-40s matches=%d\n',protectedPatterns{i}, ...
        nnz([D.isdir]));
end

fprintf('\nRuntime scaffolding left untouched:\n');
scaffoldRows=struct([]);

for i=1:numel(scaffoldPatterns)
    D=dir(fullfile(outRoot,scaffoldPatterns{i}));

    for j=1:numel(D)
        if ~D(j).isdir || any(strcmp(D(j).name,{'.','..'}))
            continue;
        end

        r=struct();
        r.name=string(D(j).name);
        r.path=string(fullfile(outRoot,D(j).name));

        if isempty(scaffoldRows)
            scaffoldRows=r;
        else
            scaffoldRows(end+1)=r; %#ok<AGROW>
        end
    end
end

if isempty(scaffoldRows)
    Tscaffold=table();
    fprintf('  <none>\n');
else
    Tscaffold=struct2table(scaffoldRows);
    disp(Tscaffold);
end

if ~applyChanges
    fprintf('\nDRY RUN COMPLETE. Nothing moved.\n');
    fprintf('10bus/18bus training-response folders are protected.\n');
    fprintf('Runtime shadow/temporary folders are left untouched.\n');

    report=struct();
    report.table=T;
    report.scaffolding=Tscaffold;
    report.applied=false;
    report.testRoot=string(testRoot);
    return;
end

% -------------------------------------------------------------------------
% Apply move plan robustly.
% -------------------------------------------------------------------------
if ~exist(testRoot,'dir')
    mkdir(testRoot);
end

for i=1:height(T)
    src=char(T.source(i));
    dst=char(T.destination(i));

    % Refresh actual filesystem state immediately before each move.
    if exist(src,'dir')~=7
        if exist(dst,'dir')==7
            T.status(i)="ALREADY_MOVED";
            T.message(i)="Source absent; destination already exists.";
        else
            T.status(i)="SKIPPED_MISSING";
            T.message(i)="Source folder no longer exists.";
        end
        continue;
    end

    dstDir=fileparts(dst);
    if ~exist(dstDir,'dir')
        mkdir(dstDir);
    end

    if exist(dst,'dir')==7
        stamp=datestr(now,'yyyymmdd_HHMMSS');
        dst=[dst '__moved_' stamp];
        T.destination(i)=string(dst);
    end

    [ok,msg]=movefile(src,dst);

    if ok
        T.status(i)="MOVED";
        T.message(i)="";
    else
        % Do not abort the entire organization and do not delete anything.
        T.status(i)="FAILED";
        T.message(i)=string(msg);
    end
end

% Always write a manifest, including failures/skips.
stamp=datestr(now,'yyyymmdd_HHMMSS');
manifest=fullfile(testRoot,['move_manifest_v4_' stamp '.csv']);
writetable(T,manifest);

nMoved=nnz(T.status=="MOVED");
nAlready=nnz(T.status=="ALREADY_MOVED");
nSkipped=nnz(T.status=="SKIPPED_MISSING");
nFailed=nnz(T.status=="FAILED");

fprintf('\n=============================================================\n');
fprintf(' ORGANIZATION SUMMARY\n');
fprintf('=============================================================\n');
fprintf('Moved          : %d\n',nMoved);
fprintf('Already moved  : %d\n',nAlready);
fprintf('Skipped missing: %d\n',nSkipped);
fprintf('Failed         : %d\n',nFailed);
fprintf('Manifest       : %s\n',manifest);
fprintf('No data was deleted.\n');

if nFailed>0
    fprintf('\nFolders that failed to move:\n');
    disp(T(T.status=="FAILED",{'name','source','destination','message'}));
end

if nSkipped>0
    fprintf('\nFolders skipped because the source was absent:\n');
    disp(T(T.status=="SKIPPED_MISSING",{'name','source','destination'}));
end

report=struct();
report.table=T;
report.scaffolding=Tscaffold;
report.applied=true;
report.testRoot=string(testRoot);
report.manifest=string(manifest);
report.nMoved=nMoved;
report.nAlreadyMoved=nAlready;
report.nSkippedMissing=nSkipped;
report.nFailed=nFailed;

end


function tf=matches_any_pattern_local(name,patterns)

tf=false;

for i=1:numel(patterns)
    expr=regexptranslate('wildcard',patterns{i});

    if ~isempty(regexp(name,['^' expr '$'],'once'))
        tf=true;
        return;
    end
end

end
