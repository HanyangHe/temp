function out=atomic_save_result_v73_v1(outDir,stamp,result,testContract)
%ATOMIC_SAVE_RESULT_V73_V1
% Save full result to unique temp MAT, verify, then atomically rename.

out=struct();
out.saved=false;
out.finalFile="";
out.errorMessage="";

tmpFile=fullfile(outDir,['tmp_full_result_' stamp '.mat']);
finalFile=fullfile(outDir,['F1_boundary_crossfade_full_result_' stamp '.mat']);

try
    if exist(tmpFile,'file')==2
        delete(tmpFile);
    end

    save(tmpFile,'result','testContract','-v7.3');

    info=whos('-file',tmpFile);
    names=string({info.name});

    assert(any(names=="result"), ...
        'Temporary MAT verification found no result variable.');

    [ok,msg]=movefile(tmpFile,finalFile,'f');
    assert(ok,'Atomic full-result move failed: %s',msg);

    out.saved=true;
    out.finalFile=string(finalFile);

catch ME
    out.errorMessage=string(getReport(ME,'basic','hyperlinks','off'));

    if exist(tmpFile,'file')==2
        failedFile=fullfile(outDir,['failed_full_result_' stamp '.mat']);

        try
            movefile(tmpFile,failedFile,'f');
        catch
        end
    end
end

end
