function report = restore_forecast_shaped_bess_engine_v2(projectRoot)
%RESTORE_FORECAST_SHAPED_BESS_ENGINE_V2
% Emergency/manual restore for the temporary V2 forecast-shaped BESS test.
% Safe when no marker remains.

if nargin<1 || isempty(projectRoot)
    projectRoot=pwd;
end
projectRoot=char(projectRoot);

engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');
assert(exist(engineFile,'file')==2,'Engine missing: %s',engineFile);

marker='% TEST_FORECAST_SHAPED_BESS_REALIZATION_V2_BEGIN';
currentText=fileread(engineFile);

report=struct();
report.engineFile=string(engineFile);
report.markerCount=numel(strfind(currentText,marker));
report.restored=false;

if report.markerCount==0
    fprintf('V2 forecast-shaped BESS marker is not present. No restore needed.\n');
    return;
end

backupRoot=fullfile(projectRoot,'outputs','cache', ...
    'forecast_shaped_bess_realization_test_v2');

D=dir(fullfile(backupRoot,'**','engine_island_ems_before_test_*.m'));
assert(~isempty(D), ...
    ['Live engine contains V2 marker(s), but no pre-test backup was found. ' ...
     'Do not run another simulation until restored.']);

[~,idx]=max([D.datenum]);
backupFile=fullfile(D(idx).folder,D(idx).name);
backupText=fileread(backupFile);

assert(~contains(backupText,marker), ...
    'Newest backup unexpectedly contains the V2 marker.');

tmp=[engineFile '.tmp_restore_forecast_bess_v2'];
fid=fopen(tmp,'w');
assert(fid>0,'Could not write restore temporary file.');
fwrite(fid,backupText,'char');
fclose(fid);

[ok,msg]=movefile(tmp,engineFile,'f');
assert(ok,'Could not restore engine: %s',msg);

clear engine_island_ems
rehash;

assert(strcmp(fileread(engineFile),backupText), ...
    'Engine restoration verification failed.');

report.backupFile=string(backupFile);
report.restored=true;

fprintf('Engine restored from:\n  %s\n',backupFile);
fprintf('Verification: PASS\n');

end
