function v=get_table_scalar_crossfade_v1(T,name,defaultValue)
%GET_TABLE_SCALAR_CROSSFADE_V1 Read scalar table value if present.

v=defaultValue;

if ismember(name,T.Properties.VariableNames)
    x=T.(name);

    if isnumeric(x) && isscalar(x) && isfinite(x)
        v=double(x);
    end
end

end
