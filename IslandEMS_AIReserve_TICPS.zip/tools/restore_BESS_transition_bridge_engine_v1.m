function report = restore_BESS_transition_bridge_engine_v1(projectRoot)
%RESTORE_BESS_TRANSITION_BRIDGE_ENGINE_V1
% Emergency/manual restore for the temporary BESS transition-bridge test.
% Normally unnecessary because the test uses onCleanup.
%
% Usage:
%   clear functions
%   rehash
%   addpath(genpath(pwd))
%   Rrestore = restore_BESS_transition_bridge_engine_v1(pwd);

if nargin<1 || isempty(projectRoot)
    projectRoot=pwd;
end
projectRoot=char(projectRoot);

engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');
assert(exist(engineFile,'file')==2,'Engine missing: %s',engineFile);

marker='% TEST_BESS_TRANSITION_BRIDGE_V1_BEGIN';
currentText=fileread(engineFile);

report=struct();
report.engineFile=string(engineFile);
report.markerCount=numel(strfind(currentText,marker));
report.restored=false;

if report.markerCount==0
    fprintf('BESS transition-bridge marker is NOT present.\n');
    fprintf('No restoration is required.\n');
    return;
end

backupRoot=fullfile(projectRoot,'outputs','cache', ...
    'bess_transition_bridge_test_v1');

D=dir(fullfile(backupRoot,'**','engine_island_ems_before_test_*.m'));

assert(~isempty(D), ...
    ['Live engine contains BESS bridge marker(s), but no backup was found.\n' ...
     'Do not run another simulation until restored.']);

[~,idx]=max([D.datenum]);
backupFile=fullfile(D(idx).folder,D(idx).name);
backupText=fileread(backupFile);

assert(~contains(backupText,marker), ...
    'Newest backup unexpectedly contains the BESS bridge marker.');

tmp=[engineFile '.tmp_restore_bess_bridge_v1'];

fid=fopen(tmp,'w');
assert(fid>0,'Could not write restore temporary file.');
fwrite(fid,backupText,'char');
fclose(fid);

[ok,msg]=movefile(tmp,engineFile,'f');
assert(ok,'Could not restore engine: %s',msg);

clear engine_island_ems
rehash;

verifyText=fileread(engineFile);
assert(strcmp(verifyText,backupText), ...
    'Engine restoration verification failed.');

report.backupFile=string(backupFile);
report.restored=true;

fprintf('Engine restored successfully from:\n  %s\n',backupFile);
fprintf('Verification: PASS\n');

end
