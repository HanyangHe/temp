function restore_engine_from_text_v1(engineFile,originalText)
%RESTORE_ENGINE_FROM_TEXT_V1 Restore exact engine source text.

try
    currentText='';

    if exist(engineFile,'file')==2
        currentText=fileread(engineFile);
    end

    if ~strcmp(currentText,originalText)
        write_text_atomic_v1(engineFile,originalText);
    end

    clear engine_island_ems
    rehash;
catch ME
    warning('BoundaryCrossfadeV3:RestoreFailed', ...
        'Automatic engine restoration failed: %s',ME.message);
end

end
