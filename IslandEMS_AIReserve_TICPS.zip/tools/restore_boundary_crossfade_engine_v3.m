function report=restore_boundary_crossfade_engine_v3(projectRoot)
%RESTORE_BOUNDARY_CROSSFADE_ENGINE_V3
% Emergency/manual restore if MATLAB/Windows is force-killed during V3.
%
% Safe to run when no V3 marker remains.

if nargin<1 || isempty(projectRoot)
    projectRoot=pwd;
end
projectRoot=char(projectRoot);

engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');
assert(exist(engineFile,'file')==2,'Engine missing: %s',engineFile);

marker='% TEST_ENERGY_NEUTRAL_BOUNDARY_CROSSFADE_V3_BEGIN';
txt=fileread(engineFile);

report=struct();
report.engineFile=string(engineFile);
report.markerCount=numel(strfind(txt,marker));
report.restored=false;

if report.markerCount==0
    fprintf('V3 boundary-crossfade marker is not present. No restore needed.\n');
    return;
end

backupRoot=fullfile(projectRoot,'outputs','cache', ...
    'energy_neutral_boundary_crossfade_test_v3');

D=dir(fullfile(backupRoot,'**','engine_island_ems_before_test_*.m'));
assert(~isempty(D),'No V3 pre-test engine backup was found.');

[~,idx]=max([D.datenum]);
backupFile=fullfile(D(idx).folder,D(idx).name);
backupText=fileread(backupFile);

assert(~contains(backupText,marker), ...
    'Newest backup unexpectedly contains the V3 marker.');

write_text_atomic_v1(engineFile,backupText);

clear engine_island_ems
rehash;

assert(strcmp(fileread(engineFile),backupText), ...
    'Restoration verification failed.');

report.backupFile=string(backupFile);
report.restored=true;

fprintf('Engine restored from:\n  %s\n',backupFile);
fprintf('Verification: PASS\n');

end
