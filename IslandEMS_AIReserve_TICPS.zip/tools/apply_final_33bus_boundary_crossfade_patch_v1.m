function report = apply_final_33bus_boundary_crossfade_patch_v1(projectRoot,applyChanges)
%APPLY_FINAL_33BUS_BOUNDARY_CROSSFADE_PATCH_V1
% Install the frozen 5-min boundary-crossfade realization into production.
% No simulation or training is launched.

if nargin<1 || isempty(projectRoot), projectRoot=pwd; end
if nargin<2 || isempty(applyChanges), applyChanges=false; end

projectRoot=char(projectRoot);
applyChanges=logical(applyChanges);

cfgFile=fullfile(projectRoot,'config','config_island_ems.m');
engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');
helperFile=fullfile(projectRoot,'core','execution','paper_boundary_crossfade_value_v1.m');

assert(exist(cfgFile,'file')==2,'Missing config: %s',cfgFile);
assert(exist(engineFile,'file')==2,'Missing engine: %s',engineFile);
assert(exist(helperFile,'file')==2,'Missing production helper: %s',helperFile);

cfgText=fileread(cfgFile);
engineText=fileread(engineFile);

fprintf('\n=============================================================\n');
if applyChanges
    fprintf(' FINAL 33-BUS PAPER CROSSFADE PATCH V1 -- APPLY\n');
else
    fprintf(' FINAL 33-BUS PAPER CROSSFADE PATCH V1 -- DRY RUN\n');
end
fprintf('=============================================================\n');

flagLine='cfg.execution.boundaryCrossfadeEnabled = true;';
windowLine='cfg.execution.boundaryCrossfadeTotal_s = 300;';
modeLine='cfg.execution.boundaryCrossfadeMode = ''symmetric-linear-5min-total'';';
scopeLine=['cfg.execution.boundaryCrossfadeAppliesTo = ' ...
    '{''DG'',''BESS_GFM'',''BESS_GFL'',''EVBESS''};'];

newCfgText=cfgText;

if contains(newCfgText,'cfg.execution.boundaryCrossfadeEnabled')
    newCfgText=regexprep(newCfgText, ...
        'cfg\.execution\.boundaryCrossfadeEnabled\s*=\s*(?:true|false)\s*;', ...
        flagLine,'once');
else
    pat='cfg\.forecast\.mpcIntervalAverageMode\s*=\s*[^;]+;';
    [s,e]=regexp(newCfgText,pat,'start','end','once');
    assert(~isempty(s),'Could not find input-average config anchor.');

    oldLine=newCfgText(s:e);
    block=[oldLine newline newline ...
        '% Final paper command-realization layer (common to all methods).' newline ...
        '% MPC remains 15 min; execution uses a 5-min total boundary crossfade.' newline ...
        flagLine newline windowLine newline modeLine newline scopeLine];

    newCfgText=[newCfgText(1:s-1) block newCfgText(e+1:end)];
end

if contains(newCfgText,'cfg.execution.boundaryCrossfadeTotal_s')
    newCfgText=regexprep(newCfgText, ...
        'cfg\.execution\.boundaryCrossfadeTotal_s\s*=\s*[^;]+;', ...
        windowLine,'once');
else
    newCfgText=strrep(newCfgText,flagLine,[flagLine newline windowLine]);
end

if contains(newCfgText,'cfg.execution.boundaryCrossfadeMode')
    newCfgText=regexprep(newCfgText, ...
        'cfg\.execution\.boundaryCrossfadeMode\s*=\s*[^;]+;', ...
        modeLine,'once');
else
    newCfgText=strrep(newCfgText,windowLine,[windowLine newline modeLine]);
end

if contains(newCfgText,'cfg.execution.boundaryCrossfadeAppliesTo')
    newCfgText=regexprep(newCfgText, ...
        'cfg\.execution\.boundaryCrossfadeAppliesTo\s*=\s*\{[^\n;]*\}\s*;', ...
        scopeLine,'once');
else
    newCfgText=strrep(newCfgText,modeLine,[modeLine newline scopeLine]);
end

newCfgText=regexprep(newCfgText, ...
    'cfg\.experiment\.systemCases\s*=\s*\{[^\n;]*\}\s*;', ...
    'cfg.experiment.systemCases = {''33bus''};','once');

newCfgText=regexprep(newCfgText, ...
    'cfg\.ai\.response\.systemCases\s*=\s*\{[^\n;]*\}\s*;', ...
    'cfg.ai.response.systemCases = {''33bus''};','once');

newEngineText=engineText;

rawTargets={ ...
    'P_DG_opt_Dec(execIdx,1,ii)', ...
    'PbattGFM_opt_Dec(execIdx,1,ii)', ...
    'Pbatt_opt_Dec(execIdx,1,ii)', ...
    'PbattEV_opt_Dec(execIdx,1,ii)'};

arrayNames={ ...
    'P_DG_opt_Dec', ...
    'PbattGFM_opt_Dec', ...
    'Pbatt_opt_Dec', ...
    'PbattEV_opt_Dec'};

expectedCounts=[2 2 2 2];
finalCounts=zeros(4,1);

for i=1:4
    helperCall=sprintf('paper_boundary_crossfade_value_v1(%s,execIdx,RealStep,cfg,ii)',arrayNames{i});
    helperCount=numel(strfind(newEngineText,helperCall));

    if helperCount==expectedCounts(i)
        finalCounts(i)=helperCount;
        continue;
    end

    assert(helperCount==0,'Unexpected partial helper patch for %s.',arrayNames{i});

    nRaw=numel(strfind(newEngineText,rawTargets{i}));
    assert(nRaw==expectedCounts(i), ...
        'Expected %d raw %s handoffs; found %d.',expectedCounts(i),arrayNames{i},nRaw);

    newEngineText=strrep(newEngineText,rawTargets{i},helperCall);
    finalCounts(i)=numel(strfind(newEngineText,helperCall));
end

assert(all(finalCounts==expectedCounts(:)),'Final helper-call counts are wrong.');

temporaryMarkers={ ...
    '% TEST_ENERGY_NEUTRAL_BOUNDARY_CROSSFADE', ...
    '% TEST_MULTIRATE_5MIN_CROSSFADE', ...
    '% TEST_ENERGY_PRESERVING_RECONSTRUCTION', ...
    '% TEST_FORECAST_SHAPED_BESS_REALIZATION', ...
    '% TEST_DG_TRANSITION_CORRECTOR', ...
    '% TEST_BESS_TRANSITION_BRIDGE'};

for i=1:numel(temporaryMarkers)
    assert(~contains(newEngineText,temporaryMarkers{i}), ...
        'Temporary diagnostic marker found in production engine.');
end

fprintf('\nFROZEN OFFICIAL EXECUTION CONTRACT\n');
fprintf('  MPC optimization interval  : 15 min\n');
fprintf('  Physical simulation step   : 1 s\n');
fprintf('  Boundary crossfade total   : 5 min\n');
fprintf('  Before/after each boundary : 2.5 / 2.5 min\n');
fprintf('  Crossfade type             : symmetric linear\n');
fprintf('  Extra MPC solves           : 0\n');
fprintf('  KRR/model/training change  : NO\n');
fprintf('  Helper call counts         : [%d %d %d %d]\n',finalCounts);

report=struct();
report.applyChanges=applyChanges;
report.configFile=string(cfgFile);
report.engineFile=string(engineFile);
report.helperFile=string(helperFile);
report.finalHelperCounts=finalCounts;

if ~applyChanges
    fprintf('\nDRY RUN COMPLETE. No production file was modified.\n');
    return;
end

stamp=datestr(now,'yyyymmdd_HHMMSS');
backupRoot=fullfile(projectRoot,'archive', ...
    ['final33bus_crossfade_patch_' stamp],'production_backup');

if ~exist(backupRoot,'dir'), mkdir(backupRoot); end

copyfile(cfgFile,fullfile(backupRoot,'config_island_ems.m'));
copyfile(engineFile,fullfile(backupRoot,'engine_island_ems.m'));

tmpCfg=[cfgFile '.tmp_final33_crossfade'];
fid=fopen(tmpCfg,'w'); assert(fid>0,'Could not write temp config.');
fwrite(fid,newCfgText,'char'); fclose(fid);
[ok,msg]=movefile(tmpCfg,cfgFile,'f');
assert(ok,'Could not install config patch: %s',msg);

tmpEngine=[engineFile '.tmp_final33_crossfade'];
fid=fopen(tmpEngine,'w'); assert(fid>0,'Could not write temp engine.');
fwrite(fid,newEngineText,'char'); fclose(fid);
[ok,msg]=movefile(tmpEngine,engineFile,'f');
assert(ok,'Could not install engine patch: %s',msg);

clear config_island_ems engine_island_ems paper_boundary_crossfade_value_v1
rehash

cfg=config_island_ems();

assert(isfield(cfg,'execution') && ...
    logical(cfg.execution.boundaryCrossfadeEnabled), ...
    'Applied config does not enable boundary crossfade.');

assert(abs(double(cfg.execution.boundaryCrossfadeTotal_s)-300)<1e-12, ...
    'Applied crossfade total window is not 300 s.');

fprintf('\n=============================================================\n');
fprintf(' FINAL 33-BUS PAPER CROSSFADE PATCH: PASS\n');
fprintf('=============================================================\n');
fprintf('Backup: %s\n',backupRoot);
fprintf('Simulation/training launched: NO\n');

report.backupRoot=string(backupRoot);
report.pass=true;
end
