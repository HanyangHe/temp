function report = restore_transition_corrector_test_engine_v1(projectRoot)
%RESTORE_TRANSITION_CORRECTOR_TEST_ENGINE_V1
% Emergency/manual restoration utility for the temporary transition-corrector
% test. Normally it is NOT needed because the test uses onCleanup restoration.
%
% It searches the V1 test cache for the newest saved pre-test engine backup
% and restores it only if the live engine still contains the V1 test marker.
%
% Usage:
%   clear functions
%   rehash
%   addpath(genpath(pwd))
%   Rrestore = restore_transition_corrector_test_engine_v1(pwd);

if nargin<1 || isempty(projectRoot)
    projectRoot=pwd;
end
projectRoot=char(projectRoot);

engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');
assert(exist(engineFile,'file')==2,'Engine missing: %s',engineFile);

marker='% TEST_DG_TRANSITION_CORRECTOR_V1_BEGIN';
currentText=fileread(engineFile);

report=struct();
report.engineFile=string(engineFile);
report.markerPresent=contains(currentText,marker);
report.restored=false;

if ~report.markerPresent
    fprintf('V1 transition-corrector marker is NOT present.\n');
    fprintf('No restoration is required. Engine was not modified.\n');
    return;
end

backupRoot=fullfile(projectRoot,'outputs','cache', ...
    'transition_corrector_test_v1');

D=dir(fullfile(backupRoot,'**', ...
    'engine_island_ems_before_test_*.m'));

assert(~isempty(D), ...
    ['Live engine contains the test marker but no backup was found under ' ...
     '%s. Do not run another simulation until manually restored.'], ...
    backupRoot);

[~,idx]=max([D.datenum]);
backupFile=fullfile(D(idx).folder,D(idx).name);
backupText=fileread(backupFile);

assert(~contains(backupText,marker), ...
    'Newest backup unexpectedly contains the test marker.');

tmp=[engineFile '.tmp_restore_transition_corrector_v1'];

fid=fopen(tmp,'w');
assert(fid>0,'Could not write restore temporary file.');
fwrite(fid,backupText,'char');
fclose(fid);

[ok,msg]=movefile(tmp,engineFile,'f');
assert(ok,'Could not restore engine: %s',msg);

clear engine_island_ems
rehash;

verifyText=fileread(engineFile);

assert(strcmp(verifyText,backupText), ...
    'Engine restoration verification failed.');

report.backupFile=string(backupFile);
report.restored=true;

fprintf('Engine restored successfully from:\n  %s\n',backupFile);
fprintf('Verification: PASS\n');

end
