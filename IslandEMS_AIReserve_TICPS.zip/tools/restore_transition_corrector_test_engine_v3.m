function report = restore_transition_corrector_test_engine_v3(projectRoot)
%RESTORE_TRANSITION_CORRECTOR_TEST_ENGINE_V3
% Emergency restore for the temporary V3 DG transition-corrector test.
%
% Normally unnecessary because the test uses onCleanup. Safe to run even
% when no V3 marker remains.
%
% Usage:
%   clear functions
%   rehash
%   addpath(genpath(pwd))
%   Rrestore = restore_transition_corrector_test_engine_v3(pwd);

if nargin<1 || isempty(projectRoot)
    projectRoot=pwd;
end
projectRoot=char(projectRoot);

engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');
assert(exist(engineFile,'file')==2,'Engine missing: %s',engineFile);

marker='% TEST_DG_TRANSITION_CORRECTOR_V3_BEGIN';
currentText=fileread(engineFile);

report=struct();
report.engineFile=string(engineFile);
report.markerCount=numel(strfind(currentText,marker));
report.restored=false;

if report.markerCount==0
    fprintf('V3 transition-corrector marker is NOT present.\n');
    fprintf('No restoration is required.\n');
    return;
end

backupRoot=fullfile(projectRoot,'outputs','cache', ...
    'transition_corrector_test_v3');

D=dir(fullfile(backupRoot,'**','engine_island_ems_before_test_*.m'));

assert(~isempty(D), ...
    ['Live engine contains V3 marker(s), but no V3 backup was found under:\n' ...
     '%s\nDo not run another simulation until restored.'],backupRoot);

[~,idx]=max([D.datenum]);
backupFile=fullfile(D(idx).folder,D(idx).name);
backupText=fileread(backupFile);

assert(~contains(backupText,marker), ...
    'Newest V3 backup unexpectedly contains the V3 marker.');

tmp=[engineFile '.tmp_restore_transition_corrector_v3'];

fid=fopen(tmp,'w');
assert(fid>0,'Could not write restore temporary file.');
fwrite(fid,backupText,'char');
fclose(fid);

[ok,msg]=movefile(tmp,engineFile,'f');
assert(ok,'Could not restore engine: %s',msg);

clear engine_island_ems
rehash;

verifyText=fileread(engineFile);
assert(strcmp(verifyText,backupText), ...
    'Engine restoration verification failed.');

report.backupFile=string(backupFile);
report.restored=true;

fprintf('Engine restored successfully from:\n  %s\n',backupFile);
fprintf('Verification: PASS\n');

end
