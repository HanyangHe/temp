function remove_tree_from_path_silent_v1(rootDir)
%REMOVE_TREE_FROM_PATH_SILENT_V1 Remove only path entries actually present.

if exist(rootDir,'dir')~=7
    return;
end

entries=string(strsplit(path,pathsep));
rootNorm=normalize_path_for_compare_v1(rootDir);
rootPrefix=rootNorm+string(filesep);

for k=1:numel(entries)
    if strlength(entries(k))==0
        continue;
    end

    pk=normalize_path_for_compare_v1(char(entries(k)));

    if pk==rootNorm || startsWith(pk,rootPrefix)
        try
            rmpath(char(entries(k)));
        catch
        end
    end
end

end
