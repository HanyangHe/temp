function report = consolidate_outputs_cache_v1(projectRoot,applyChanges)
%CONSOLIDATE_OUTPUTS_CACHE_V1
% Clean outputs/ so only formal final results + README + one cache/ folder
% remain at the top level.
%
% This matches the intended project organization:
%
%   outputs/
%     README.md
%     20260910_finalP1_10bus/
%     20260908_finalP1S3_18bus/
%     <future folders containing "finalP1"...>
%     cache/
%       legacy_nonfinal_YYYYMMDD_HHMMSS/
%         ...all other current top-level files/folders...
%
% IMPORTANT
% ---------
% * Nothing is deleted.
% * Existing testResults/, delete/, diagnostics, training-response folders,
%   old dated runs, audit CSVs, and 33-bus development folders are all moved
%   under ONE top-level outputs/cache/ tree.
% * Formal final result folders are kept at outputs/ top level.
% * Future final folders whose names contain "finalP1" are also protected.
%
% Dry run:
%   R = consolidate_outputs_cache_v1(pwd,false);
%
% Apply:
%   R = consolidate_outputs_cache_v1(pwd,true);

if nargin<1 || isempty(projectRoot)
    projectRoot=pwd;
end
if nargin<2 || isempty(applyChanges)
    applyChanges=false;
end

projectRoot=char(projectRoot);
applyChanges=logical(applyChanges);

outRoot=fullfile(projectRoot,'outputs');
cacheRoot=fullfile(outRoot,'cache');

assert(exist(outRoot,'dir')==7,'outputs folder not found: %s',outRoot);

timestamp=datestr(now,'yyyymmdd_HHMMSS');
archiveName=['legacy_nonfinal_' timestamp];
archiveRoot=fullfile(cacheRoot,archiveName);

% -------------------------------------------------------------------------
% Keep policy: deliberately small.
% -------------------------------------------------------------------------
keepExact={ ...
    'README.md', ...
    '20260910_finalP1_10bus', ...
    '20260908_finalP1S3_18bus', ...
    'cache'};

% Future formal paper result folders should use "finalP1" in the name.
keepPattern='finalP1';

D=dir(outRoot);

rows=struct([]);

for i=1:numel(D)
    name=D(i).name;

    if any(strcmp(name,{'.','..'}))
        continue;
    end

    keep=false;
    reason="";

    if any(strcmp(name,keepExact))
        keep=true;
        reason="KEEP_EXACT";
    elseif contains(lower(name),lower(keepPattern))
        keep=true;
        reason="KEEP_FINAL_PATTERN";
    end

    if keep
        continue;
    end

    src=fullfile(outRoot,name);
    dst=fullfile(archiveRoot,name);

    r=struct();
    r.Name=string(name);
    r.Type=string(ternary_local(D(i).isdir,'folder','file'));
    r.Source=string(src);
    r.Destination=string(dst);
    r.Status="PLANNED";
    r.Message="";

    if isempty(rows)
        rows=r;
    else
        rows(end+1)=r; %#ok<AGROW>
    end
end

if isempty(rows)
    T=table();
else
    T=struct2table(rows);
end

fprintf('\n=============================================================\n');
if applyChanges
    fprintf(' CONSOLIDATE outputs/ INTO ONE cache/ -- APPLY\n');
else
    fprintf(' CONSOLIDATE outputs/ INTO ONE cache/ -- DRY RUN\n');
end
fprintf('=============================================================\n');

fprintf('\nTOP-LEVEL ITEMS TO KEEP:\n');
fprintf('  README.md\n');
fprintf('  20260910_finalP1_10bus/\n');
fprintf('  20260908_finalP1S3_18bus/\n');
fprintf('  any future folder containing "finalP1"\n');
fprintf('  cache/\n');

fprintf('\nARCHIVE DESTINATION:\n');
fprintf('  %s\n',archiveRoot);

fprintf('\nITEMS TO MOVE INTO cache:\n');

if isempty(T)
    fprintf('  <none>\n');
else
    disp(T(:,{'Name','Type','Source','Destination'}));
end

if ~applyChanges
    fprintf('\nDRY RUN COMPLETE. Nothing moved.\n');
    fprintf(['After APPLY, outputs/ top level will contain only the formal ', ...
        'final folders, README.md, and cache/.\n']);

    report=struct();
    report.applied=false;
    report.plan=T;
    report.archiveRoot=string(archiveRoot);
    report.cacheRoot=string(cacheRoot);
    return;
end

% -------------------------------------------------------------------------
% Apply robustly.
% -------------------------------------------------------------------------
if ~exist(cacheRoot,'dir')
    mkdir(cacheRoot);
end

if ~exist(archiveRoot,'dir')
    mkdir(archiveRoot);
end

for i=1:height(T)
    src=char(T.Source(i));
    dst=char(T.Destination(i));

    isFolder=exist(src,'dir')==7;
    isFile=exist(src,'file')==2;

    if ~isFolder && ~isFile
        T.Status(i)="SKIPPED_MISSING";
        T.Message(i)="Source disappeared before move.";
        continue;
    end

    if exist(dst,'dir')==7 || exist(dst,'file')==2
        suffix=datestr(now,'HHMMSSFFF');
        [dstParent,dstName,dstExt]=fileparts(dst);
        dst=fullfile(dstParent,[dstName '__duplicate_' suffix dstExt]);
        T.Destination(i)=string(dst);
    end

    [ok,msg]=movefile(src,dst);

    if ok
        T.Status(i)="MOVED";
        T.Message(i)="";
    else
        T.Status(i)="FAILED";
        T.Message(i)=string(msg);
    end
end

manifest=fullfile(archiveRoot,'move_manifest.csv');
writetable(T,manifest);

% -------------------------------------------------------------------------
% Verify the top level after organization.
% -------------------------------------------------------------------------
After=dir(outRoot);
topNames=string({After.name});
topNames=topNames(~ismember(topNames,[".",".."]));

unexpected=strings(0,1);

for i=1:numel(topNames)
    name=char(topNames(i));

    if any(strcmp(name,keepExact))
        continue;
    end

    if contains(lower(name),lower(keepPattern))
        continue;
    end

    unexpected(end+1,1)=string(name); %#ok<AGROW>
end

nMoved=nnz(T.Status=="MOVED");
nSkipped=nnz(T.Status=="SKIPPED_MISSING");
nFailed=nnz(T.Status=="FAILED");

fprintf('\n=============================================================\n');
fprintf(' CONSOLIDATION SUMMARY\n');
fprintf('=============================================================\n');
fprintf('Moved          : %d\n',nMoved);
fprintf('Skipped missing: %d\n',nSkipped);
fprintf('Failed         : %d\n',nFailed);
fprintf('Manifest       : %s\n',manifest);

fprintf('\nCURRENT outputs/ TOP LEVEL:\n');
After=dir(outRoot);

for i=1:numel(After)
    if any(strcmp(After(i).name,{'.','..'}))
        continue;
    end

    if After(i).isdir
        fprintf('  [folder] %s\n',After(i).name);
    else
        fprintf('  [file]   %s\n',After(i).name);
    end
end

if ~isempty(unexpected)
    fprintf('\nWARNING: unexpected top-level items remain:\n');
    disp(unexpected);
else
    fprintf('\nTOP-LEVEL CLEANLINESS CHECK: PASS\n');
end

if nFailed>0
    fprintf('\nFAILED MOVES:\n');
    disp(T(T.Status=="FAILED",{'Name','Source','Destination','Message'}));
end

fprintf('\nNo data was deleted.\n');

report=struct();
report.applied=true;
report.table=T;
report.archiveRoot=string(archiveRoot);
report.manifest=string(manifest);
report.nMoved=nMoved;
report.nSkippedMissing=nSkipped;
report.nFailed=nFailed;
report.unexpectedTopLevel=unexpected;
report.cleanTopLevel=isempty(unexpected);

end


function out=ternary_local(tf,a,b)

if tf
    out=a;
else
    out=b;
end

end
