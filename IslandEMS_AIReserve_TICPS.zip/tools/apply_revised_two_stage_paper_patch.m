function report = apply_revised_two_stage_paper_patch(projectRoot)
%APPLY_REVISED_TWO_STAGE_PAPER_PATCH Enable revised paper methods C0/C1.
%
% v2: locates validate_config.m and run_experiments.m from the active project
% path instead of assuming validate_config.m lives in config/.

if nargin < 1 || isempty(projectRoot)
    projectRoot = pwd;
end
projectRoot = char(projectRoot);

addpath(genpath(projectRoot));
rehash;

assert(exist(fullfile(projectRoot,'config','paper_method_catalog.m'),'file')==2, ...
    'Missing config/paper_method_catalog.m');
assert(exist(fullfile(projectRoot,'config','paper_study_catalog.m'),'file')==2, ...
    'Missing config/paper_study_catalog.m');

runFile = which('run_experiments');
valFile = which('validate_config');

assert(~isempty(runFile),'Could not locate run_experiments.m on MATLAB path.');
assert(~isempty(valFile),'Could not locate validate_config.m on MATLAB path.');

% Refuse to patch a shadowed copy outside this project.
assert(startsWith(lower(runFile),lower(projectRoot)), ...
    'run_experiments resolves outside project root: %s',runFile);
assert(startsWith(lower(valFile),lower(projectRoot)), ...
    'validate_config resolves outside project root: %s',valFile);

targets = {runFile,valFile};
oldCall = 'baseline_catalog()';
newCall = 'paper_method_catalog()';

texts = cell(size(targets));
needPatch = false(size(targets));

% Verify all files first, before modifying anything.
for k = 1:numel(targets)
    texts{k} = fileread(targets{k});

    if contains(texts{k},newCall)
        needPatch(k) = false;
    elseif contains(texts{k},oldCall)
        needPatch(k) = true;
    else
        % Some validate_config implementations do not inspect method catalog.
        % In that case no catalog replacement is required.
        if strcmpi(targets{k},valFile)
            fprintf('[NO CATALOG CALL — NO PATCH NEEDED] %s\n',targets{k});
            needPatch(k) = false;
        else
            error(['Could not find baseline_catalog() or paper_method_catalog() in:\n', ...
                   '%s\nNo files were modified.'],targets{k});
        end
    end
end

timestamp = datestr(now,'yyyymmdd_HHMMSS');
backups = cell(size(targets));

for k = 1:numel(targets)
    if ~needPatch(k)
        if contains(texts{k},newCall)
            fprintf('[ALREADY PATCHED] %s\n',targets{k});
        end
        continue;
    end

    backups{k} = [targets{k} '.before_two_stage_patch_' timestamp '.bak'];
    copyfile(targets{k},backups{k},'f');

    newTxt = strrep(texts{k},oldCall,newCall);
    assert(contains(newTxt,newCall), ...
        'Internal replacement failed for %s',targets{k});

    fid = fopen(targets{k},'w');
    assert(fid>=0,'Could not open %s for writing.',targets{k});
    cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>
    fwrite(fid,newTxt,'char');
    clear cleanupObj

    installed = fileread(targets{k});
    assert(contains(installed,newCall), ...
        'Write verification failed for %s. Restore %s',targets{k},backups{k});

    fprintf('[PATCHED] %s\n',targets{k});
end

clear paper_method_catalog paper_study_catalog config_island_ems validate_config run_experiments
rehash;
addpath(genpath(projectRoot));

cfg = config_island_ems();
validate_config(cfg);

% Confirm C0/C1 are visible to the runner catalog.
catalog = paper_method_catalog();
ids = string({catalog.id});
assert(all(ismember(["C0","C1"],ids)), ...
    'C0/C1 are not visible in paper_method_catalog().');

report = struct();
report.status = 'PASS';
report.runExperimentsFile = runFile;
report.validateConfigFile = valFile;
report.backups = backups;
report.enabledMethods = cfg.experiment.enabledMethods;

fprintf('\nRevised two-stage paper-method patch installed.\n');
fprintf('  run_experiments : %s\n',runFile);
fprintf('  validate_config : %s\n',valFile);
fprintf('  Part I labels   : A0, F1, G1, P1U, P1\n');
fprintf('  Part II methods : C0, C1, P1\n');
fprintf('  Run order       : %s\n\n', ...
    strjoin(string(cfg.experiment.enabledMethods),', '));
end
