function report = run_final_33bus_paper_suite_crossfade_v1(projectRoot,runNow)
%RUN_FINAL_33BUS_PAPER_SUITE_CROSSFADE_V1
% Official final 33-bus paper suite with frozen 5-min boundary crossfade.
%
% Unique formal cases = 19.
% Part I, decay=1: A0, F1, G1, P1U, P1.
% Part II: C0, C1, P1 for decay=[0.2 0.4 0.6 0.8 1.0].
% P1/decay=1 is shared and run only once.
%
% Preflight:
%   Rpre = run_final_33bus_paper_suite_crossfade_v1(pwd,false);
% Start/resume:
%   R33 = run_final_33bus_paper_suite_crossfade_v1(pwd,true);

if nargin<1 || isempty(projectRoot), projectRoot=pwd; end
if nargin<2 || isempty(runNow), runNow=false; end

projectRoot=char(projectRoot);
runNow=logical(runNow);

%% Path hygiene
dropNames={'archive','outputs','patch_files'};

for iDrop=1:numel(dropNames)
    rootDir=fullfile(projectRoot,dropNames{iDrop});
    if exist(rootDir,'dir')~=7, continue; end
    entries=string(strsplit(path,pathsep));

    try
        rootNorm=lower(string(char(java.io.File(rootDir).getCanonicalPath())));
    catch
        rootNorm=lower(string(rootDir));
    end

    rootPrefix=rootNorm+string(filesep);

    for iPath=1:numel(entries)
        if strlength(entries(iPath))==0, continue; end

        try
            pNorm=lower(string(char(java.io.File(char(entries(iPath))).getCanonicalPath())));
        catch
            pNorm=lower(entries(iPath));
        end

        if pNorm==rootNorm || startsWith(pNorm,rootPrefix)
            try, rmpath(char(entries(iPath))); catch, end
        end
    end
end

rehash;
clear config_island_ems system_case_catalog engine_island_ems

cfgFile=fullfile(projectRoot,'config','config_island_ems.m');
engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');
helperFile=fullfile(projectRoot,'core','execution','paper_boundary_crossfade_value_v1.m');

assert(exist(cfgFile,'file')==2,'Missing live config.');
assert(exist(engineFile,'file')==2,'Missing production engine.');
assert(exist(helperFile,'file')==2,'Missing production crossfade helper.');

addpath(fileparts(cfgFile),'-begin');
rehash

cfg=config_island_ems();
validate_config(cfg);

cfg.output.saveResults=false;
cfg.output.showFigures=false;
cfg.output.exportFigures=false;

if isfield(cfg,'performance') && isfield(cfg.performance,'cacheStaticMPCSOCP')
    cfg.performance.cacheStaticMPCSOCP=true;
end

assert(isfield(cfg,'execution') && ...
    logical(cfg.execution.boundaryCrossfadeEnabled), ...
    'Official boundary crossfade is not enabled.');
assert(abs(double(cfg.execution.boundaryCrossfadeTotal_s)-300)<1e-12, ...
    'Official boundary crossfade must be 300 s total.');
assert(string(cfg.execution.boundaryCrossfadeMode)== ...
    "symmetric-linear-5min-total", ...
    'Unexpected official execution mode.');

rng(0,'twister');
sys=system_case_catalog('33bus',cfg);

dg=double(sys.DieselG_Pgfm_rate(:));
pv=double(sys.PVInv_P_rateIn(:));

assert(max(abs(dg-[0.17;0.17;0.17]))<1e-12,'Final 33bus DG ratings are incorrect.');
assert(max(abs(pv-[1/6;2/15;2/15;1/6]))<1e-10,'Final 33bus PV ratings are incorrect.');

modelFile=fullfile(projectRoot,'ai','models','33bus','reserve_krr_model.mat');
datasetFile=fullfile(projectRoot,'ai','datasets','33bus','reserve_response_dataset_paper.mat');

assert(exist(modelFile,'file')==2,'Canonical 33bus model missing.');
assert(exist(datasetFile,'file')==2,'Canonical 33bus dataset missing.');

modelInfo=dir(modelFile);
datasetInfo=dir(datasetFile);

catalog=paper_method_catalog();
catalogIDs=string({catalog.id});

required=["A0","G1","P1U","P1","C0","C1"];

for i=1:numel(required)
    assert(any(catalogIDs==required(i)),'Required method %s is missing.',required(i));
end

idxF1=find(catalogIDs=="F1",1);
internalF1="F1";

if isempty(idxF1)
    idxF1=find(catalogIDs=="T7",1);
    internalF1="T7";
end

assert(~isempty(idxF1),'Neither F1 nor internal T7 exists.');

%% Build 19-case manifest
StudyPart=strings(19,1);
Method=strings(19,1);
InternalID=strings(19,1);
DecayRatio=zeros(19,1);
RandomSeed=zeros(19,1);
row=0;

partI=["A0","F1","G1","P1U","P1"];

for i=1:numel(partI)
    row=row+1;
    StudyPart(row)="PartI";
    Method(row)=partI(i);
    if partI(i)=="F1"
        InternalID(row)=internalF1;
    else
        InternalID(row)=partI(i);
    end
    DecayRatio(row)=1.0;
    RandomSeed(row)=0;
end

decays=[0.2 0.4 0.6 0.8 1.0];
partIIMethods=["C0","C1","P1"];

for id=1:numel(decays)
    for im=1:numel(partIIMethods)
        m=partIIMethods(im);
        d=decays(id);

        if m=="P1" && abs(d-1.0)<1e-12
            continue;
        end

        row=row+1;
        StudyPart(row)="PartII";
        Method(row)=m;
        InternalID(row)=m;
        DecayRatio(row)=d;
        RandomSeed(row)=0;
    end
end

assert(row==19,'Expected 19 unique formal cases; built %d.',row);

CaseKey=strings(19,1);

for i=1:19
    CaseKey(i)=sprintf('%s_decay_%03d_seed_%03d', ...
        Method(i),round(100*DecayRatio(i)),RandomSeed(i));
end

manifest=table(StudyPart,Method,InternalID,DecayRatio,RandomSeed,CaseKey);

%% Formal output root
runTag=[datestr(now,'yyyymmdd') '_finalP1_33bus'];
outRoot=fullfile(projectRoot,'outputs',runTag);

if ~exist(outRoot,'dir'), mkdir(outRoot); end

writetable(manifest,fullfile(outRoot,'formal_case_manifest.csv'));

contract=struct();
contract.grid="33bus";
contract.dgRatings_MW=dg;
contract.pvRatings_MW=pv;
contract.averageInputEnabled=logical(cfg.forecast.useMPCIntervalAverage);
contract.averageInputMode=string(cfg.forecast.mpcIntervalAverageMode);
contract.executionMode=string(cfg.execution.boundaryCrossfadeMode);
contract.boundaryCrossfadeTotal_s=300;
contract.boundaryCrossfadeHalf_s=150;
contract.extraMPCSolveCount=0;
contract.modelFile=string(modelFile);
contract.modelBytes=double(modelInfo.bytes);
contract.modelDatenum=double(modelInfo.datenum);
contract.datasetFile=string(datasetFile);
contract.datasetBytes=double(datasetInfo.bytes);
contract.datasetDatenum=double(datasetInfo.datenum);
contract.formalSeed=0;
contract.expectedUniqueCases=19;
contract.runnerVersion="run_final_33bus_paper_suite_crossfade_v1";

save(fullfile(outRoot,'formal_contract.mat'),'contract','manifest','-v7');

readmeFile=fullfile(outRoot,'README.md');
fid=fopen(readmeFile,'w');

if fid>0
    fprintf(fid,'# Final 33-bus paper run\n\n');
    fprintf(fid,'Grid: 33bus\n\n');
    fprintf(fid,'DG: [0.17 0.17 0.17] MW\n\n');
    fprintf(fid,'PV total: 0.60 MW\n\n');
    fprintf(fid,'MPC interval: 15 min\n\n');
    fprintf(fid,'Predictive input averaging: enabled\n\n');
    fprintf(fid,['Common execution layer: symmetric linear 5-min total boundary ' ...
        'crossfade (2.5 min before + 2.5 min after)\n\n']);
    fprintf(fid,'Extra MPC solves: 0\n\n');
    fprintf(fid,'Formal seed: 0\n\n');
    fprintf(fid,'Unique formal cases: 19\n\n');
    fprintf(fid,'Completed cases are saved immediately; reruns resume compatible cases.\n');
    fclose(fid);
end

fprintf('\n=============================================================\n');
fprintf(' FINAL 33-BUS OFFICIAL PAPER SUITE -- 5-MIN CROSSFADE\n');
fprintf('=============================================================\n');
fprintf('Output root          : %s\n',outRoot);
fprintf('Formal cases         : 19 unique\n');
fprintf('F1 internal ID       : %s\n',internalF1);
fprintf('MPC interval         : 15 min\n');
fprintf('Boundary crossfade   : 5 min total (2.5 + 2.5)\n');
fprintf('Extra MPC solves     : 0\n');
fprintf('KRR/model retraining : NO\n');
fprintf('DG total             : %.5f MW\n',sum(dg));
fprintf('PV total             : %.5f MW\n',sum(pv));
fprintf('Resume support       : ON\n');
fprintf('=============================================================\n');

disp(manifest);

report=struct();
report.ready=true;
report.runNow=runNow;
report.outputRoot=string(outRoot);
report.contract=contract;
report.manifest=manifest;

if ~runNow
    fprintf('\nFORMAL SUITE PREFLIGHT: PASS\n');
    fprintf('Simulation launched: NO\n');
    fprintf('To start/resume:\n');
    fprintf('  R33 = run_final_33bus_paper_suite_crossfade_v1(pwd,true);\n');
    return;
end

%% Run/resume 19 cases
summaryRows=table();

for iCase=1:height(manifest)
    manuscriptMethod=manifest.Method(iCase);
    internalID=manifest.InternalID(iCase);
    decay=manifest.DecayRatio(iCase);
    seed=manifest.RandomSeed(iCase);

    methodIdx=find(catalogIDs==internalID,1);
    assert(~isempty(methodIdx),'Internal method %s not found.',internalID);

    runCfg=catalog(methodIdx);
    runCfg.caseName='33bus';
    runCfg.dayType=cfg.scenario.dayType;
    runCfg.decayRatio=decay;
    runCfg.randomSeed=seed;

    methodDir=fullfile(outRoot,char(manuscriptMethod));
    caseDir=fullfile(methodDir, ...
        sprintf('decay_%03d_seed_%03d',round(100*decay),seed));

    if ~exist(caseDir,'dir'), mkdir(caseDir); end

    caseFile=fullfile(caseDir,'result.mat');

    fprintf('\n-------------------------------------------------------------\n');
    fprintf(' FORMAL CASE %02d / %02d\n',iCase,height(manifest));
    fprintf(' part      : %s\n',manifest.StudyPart(iCase));
    fprintf(' manuscript: %s\n',manuscriptMethod);
    fprintf(' internal  : %s\n',internalID);
    fprintf(' decay     : %.2f\n',decay);
    fprintf(' seed      : %d\n',seed);
    fprintf('-------------------------------------------------------------\n');

    reuse=false;
    result=[];
    caseRecord=struct();

    if exist(caseFile,'file')==2
        try
            info=whos('-file',caseFile);
            varNames=string({info.name});

            if all(ismember(["result","caseRecord"],varNames))
                S=load(caseFile,'result','caseRecord');
                R=S.caseRecord;

                compatible=isfield(R,'completed') && logical(R.completed) && ...
                    string(R.manuscriptMethod)==manuscriptMethod && ...
                    string(R.internalID)==internalID && ...
                    abs(double(R.decayRatio)-decay)<1e-12 && ...
                    double(R.randomSeed)==seed && ...
                    string(R.executionMode)==contract.executionMode && ...
                    abs(double(R.boundaryCrossfadeTotal_s)-300)<1e-12 && ...
                    double(R.modelBytes)==contract.modelBytes && ...
                    abs(double(R.modelDatenum)-contract.modelDatenum)<1e-9;

                if compatible
                    result=S.result;
                    caseRecord=R;
                    reuse=true;
                end
            end
        catch
            reuse=false;
        end
    end

    if reuse
        fprintf('Reusing compatible completed formal case.\n');
    else
        fprintf('Launching coupled MPC + 1-s physical validation...\n');
        rng(seed,'twister');
        tCase=tic;

        try
            result=run_single_experiment(cfg,runCfg,projectRoot,modelFile,false);

            caseRecord=struct();
            caseRecord.completed=true;
            caseRecord.manuscriptMethod=manuscriptMethod;
            caseRecord.internalID=internalID;
            caseRecord.decayRatio=decay;
            caseRecord.randomSeed=seed;
            caseRecord.executionMode=contract.executionMode;
            caseRecord.boundaryCrossfadeTotal_s=300;
            caseRecord.modelBytes=contract.modelBytes;
            caseRecord.modelDatenum=contract.modelDatenum;
            caseRecord.datasetBytes=contract.datasetBytes;
            caseRecord.datasetDatenum=contract.datasetDatenum;
            caseRecord.elapsed_s=toc(tCase);
            caseRecord.completedAt=string(datetime('now'));

            tmpFile=[caseFile '.tmp'];
            if exist(tmpFile,'file')==2, delete(tmpFile); end

            save(tmpFile,'result','caseRecord','-v7.3');

            info=whos('-file',tmpFile);
            names=string({info.name});
            assert(all(ismember(["result","caseRecord"],names)), ...
                'Temporary formal case MAT verification failed.');

            [ok,msg]=movefile(tmpFile,caseFile,'f');
            assert(ok,'Could not finalize formal case MAT: %s',msg);

            fprintf('Case cached immediately:\n  %s\n',caseFile);

        catch ME
            failure=struct();
            failure.manuscriptMethod=manuscriptMethod;
            failure.internalID=internalID;
            failure.decayRatio=decay;
            failure.randomSeed=seed;
            failure.failedAt=string(datetime('now'));
            failure.identifier=string(ME.identifier);
            failure.message=string(ME.message);
            failure.report=string(getReport(ME,'extended','hyperlinks','off'));

            save(fullfile(caseDir,'FAILURE.mat'),'failure','-v7');

            fid=fopen(fullfile(caseDir,'FAILURE.txt'),'w');
            if fid>0
                fprintf(fid,'%s\n',failure.report);
                fclose(fid);
            end

            fprintf(2,'Case failed. Previous completed cases remain cached.\n');
            rethrow(ME);
        end
    end

    %% Summary row
    df=double(result.interval.maxAbsFreqDev_Hz(:));
    rc=double(result.interval.maxAbsRoCoF_Hz_s(:));
    stress=max(df/cfg.frequency.securityDeviation_Hz, ...
        rc/cfg.frequency.securityRoCoF_Hz_s);
    bad=stress>1+1e-12;

    totalCost=NaN;
    meanAlpha=NaN;
    minAlpha=NaN;
    maxAlpha=NaN;
    meanReserve_kW=NaN;
    maxReserve_kW=NaN;
    oodRate=NaN;
    noSafeRate=NaN;
    evalTime_ms=NaN;
    minV=NaN;
    maxV=NaN;
    maxI=NaN;
    optFail=NaN;
    pfFail=NaN;

    if isfield(result,'totalCost') && isnumeric(result.totalCost)
        totalCost=double(result.totalCost);
    end

    if isfield(result,'summary') && isstruct(result.summary)
        Ssum=result.summary;
        if isfield(Ssum,'meanReserveRatio'), meanAlpha=double(Ssum.meanReserveRatio); end
        if isfield(Ssum,'meanTotalDGReserve_kW'), meanReserve_kW=double(Ssum.meanTotalDGReserve_kW); end
        if isfield(Ssum,'maxTotalDGReserve_kW'), maxReserve_kW=double(Ssum.maxTotalDGReserve_kW); end
        if isfield(Ssum,'aiOODFallbackRate'), oodRate=double(Ssum.aiOODFallbackRate); end
        if isfield(Ssum,'aiNoSafeCandidateFallbackRate'), noSafeRate=double(Ssum.aiNoSafeCandidateFallbackRate); end
        if isfield(Ssum,'meanReserveEvalTime_ms'), evalTime_ms=double(Ssum.meanReserveEvalTime_ms); end
        if isfield(Ssum,'minVoltage_pu'), minV=double(Ssum.minVoltage_pu); end
        if isfield(Ssum,'maxVoltage_pu'), maxV=double(Ssum.maxVoltage_pu); end
        if isfield(Ssum,'maxCurrentRatio'), maxI=double(Ssum.maxCurrentRatio); end
        if isfield(Ssum,'optimizationFailureRate'), optFail=double(Ssum.optimizationFailureRate); end
        if isfield(Ssum,'physicalPFFailureRate'), pfFail=double(Ssum.physicalPFFailureRate); end
    end

    if isfield(result,'reserve') && isstruct(result.reserve) && ...
            isfield(result.reserve,'ratio') && isnumeric(result.reserve.ratio)
        alpha=double(result.reserve.ratio(:));
        if ~isempty(alpha)
            meanAlpha=mean(alpha,'omitnan');
            minAlpha=min(alpha,[],'omitnan');
            maxAlpha=max(alpha,[],'omitnan');
        end
    end

    if isnan(minAlpha) && isfinite(meanAlpha), minAlpha=meanAlpha; end
    if isnan(maxAlpha) && isfinite(meanAlpha), maxAlpha=meanAlpha; end

    elapsedMin=NaN;
    if isfield(caseRecord,'elapsed_s'), elapsedMin=double(caseRecord.elapsed_s)/60; end

    newRow=table( ...
        manuscriptMethod,internalID,decay,seed,totalCost, ...
        max(df),max(rc),max(stress),nnz(bad),nnz(bad)/numel(bad), ...
        string(mat2str(find(bad).')), ...
        meanAlpha,minAlpha,maxAlpha,meanReserve_kW,maxReserve_kW, ...
        oodRate,noSafeRate,evalTime_ms,minV,maxV,maxI,optFail,pfFail,elapsedMin, ...
        'VariableNames',{ ...
        'Method','InternalID','DecayRatio','RandomSeed','TotalCost', ...
        'MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s','MaxSecurityStress', ...
        'SecurityViolationCount','SecurityViolationRate','UnsafeSteps', ...
        'MeanReserveRatio','MinReserveRatio','MaxReserveRatio', ...
        'MeanTotalDGReserve_kW','MaxTotalDGReserve_kW', ...
        'AIOODFallbackRate','AINoSafeCandidateFallbackRate', ...
        'MeanReserveEvalTime_ms','MinVoltage_pu','MaxVoltage_pu', ...
        'MaxCurrentRatio','OptimizationFailureRate','PhysicalPFFailureRate', ...
        'Elapsed_min'});

    if isempty(summaryRows)
        summaryRows=newRow;
    else
        summaryRows=[summaryRows;newRow]; %#ok<AGROW>
    end

    writetable(summaryRows,fullfile(outRoot,'formal_33bus_summary.csv'));

    runState=struct();
    runState.contract=contract;
    runState.manifest=manifest;
    runState.completedSummary=summaryRows;
    runState.completedCases=height(summaryRows);
    runState.totalCases=19;
    runState.updatedAt=string(datetime('now'));

    save(fullfile(outRoot,'formal_33bus_run_state.mat'),'runState','-v7');

    fprintf('\nCurrent row:\n');
    disp(newRow);
    fprintf('Progress: %d / 19\n',height(summaryRows));
end

%% Final paper tables
assert(height(summaryRows)==19,'Formal suite incomplete: %d/19.',height(summaryRows));

partIOrder=["A0","F1","G1","P1U","P1"];
partIMask=summaryRows.DecayRatio==1 & ismember(summaryRows.Method,partIOrder);
partI=summaryRows(partIMask,:);

rank=zeros(height(partI),1);
for i=1:height(partI)
    rank(i)=find(partIOrder==partI.Method(i),1);
end
[~,ord]=sort(rank);
partI=partI(ord,:);

partIIMask=ismember(summaryRows.Method,["C0","C1","P1"]);
partII=summaryRows(partIIMask,:);

methodRank=zeros(height(partII),1);
for i=1:height(partII)
    if partII.Method(i)=="C0"
        methodRank(i)=1;
    elseif partII.Method(i)=="C1"
        methodRank(i)=2;
    else
        methodRank(i)=3;
    end
end

[~,ord]=sortrows([partII.DecayRatio methodRank],[1 2]);
partII=partII(ord,:);

writetable(partI,fullfile(outRoot,'formal_33bus_partI_normal.csv'));
writetable(partII,fullfile(outRoot,'formal_33bus_partII_hierarchical.csv'));

report.complete=true;
report.summary=summaryRows;
report.partI=partI;
report.partII=partII;
report.completedAt=string(datetime('now'));

save(fullfile(outRoot,'formal_33bus_complete.mat'),'report','-v7.3');

fprintf('\n=============================================================\n');
fprintf(' FINAL 33-BUS PAPER SUITE: COMPLETE\n');
fprintf('=============================================================\n');
fprintf('Formal cases : 19 / 19\n');
fprintf('Output root  : %s\n',outRoot);
fprintf('Production execution: frozen 5-min boundary crossfade\n');
fprintf('10-/18-bus results touched: NO\n');
end
