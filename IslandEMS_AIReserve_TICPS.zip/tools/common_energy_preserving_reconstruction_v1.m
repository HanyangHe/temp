function uExe = common_energy_preserving_reconstruction_v1( ...
    U,execIdx,RealStep,samplesPerDecision,unitIndex)
%COMMON_ENERGY_PRESERVING_RECONSTRUCTION_V1
% Continuous, interval-energy-preserving realization of a discrete MPC
% active-power sequence.
%
% For the current MPC interval k:
%
%   uPrev = u_{k-1},  uNow = u_k,  uNext = u_{k+1}
%
%   bL = (uPrev + uNow)/2
%   bR = (uNow  + uNext)/2
%
%   xi = (t-t_k)/DeltaT in [0,1)
%
%   uExe(xi) = (1-xi)*bL + xi*bR ...
%            + 6*xi*(1-xi)*(uNow-(bL+bR)/2)
%
% Properties in continuous time:
%   1) uExe(0) = bL
%   2) uExe(1) = bR
%   3) adjacent intervals are continuous because
%        bR(k) = bL(k+1) = (u_k+u_{k+1})/2
%   4) interval average is exactly u_k:
%        integral_0^1 uExe(xi) dxi = u_k
%
% First/last interval handling:
%   uPrev=uNow at the first interval;
%   uNext=uNow at the last interval.
%
% No clipping is applied here. If this reconstruction requests an
% unacceptable actuator value in the physical model, the test should be
% rejected rather than silently breaking the energy-preserving property.

N=size(U,1);
k=min(max(round(execIdx),1),N);

uNow=double(U(k,1,unitIndex));

if k>1
    uPrev=double(U(k-1,1,unitIndex));
else
    uPrev=uNow;
end

if k<N
    uNext=double(U(k+1,1,unitIndex));
else
    uNext=uNow;
end

bL=0.5*(uPrev+uNow);
bR=0.5*(uNow+uNext);

r=mod(round(RealStep)-1,samplesPerDecision);
xi=double(r)/double(samplesPerDecision);
xi=min(max(xi,0),1);

uExe=(1-xi)*bL + xi*bR + ...
    6*xi*(1-xi)*(uNow-0.5*(bL+bR));

end
