function v=get_summary_scalar_v1(result,fieldName,defaultValue)
%GET_SUMMARY_SCALAR_V1 Read finite numeric scalar from result.summary.

v=defaultValue;

if isfield(result,'summary') && isstruct(result.summary) && ...
        isfield(result.summary,fieldName)

    x=result.summary.(fieldName);

    if isnumeric(x) && isscalar(x) && isfinite(x)
        v=double(x);
    end
end

end
