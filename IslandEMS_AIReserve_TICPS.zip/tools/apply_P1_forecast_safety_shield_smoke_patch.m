function apply_P1_forecast_safety_shield_smoke_patch()
%APPLY_P1_FORECAST_SAFETY_SHIELD_SMOKE_PATCH
% Experimental, reversible patch for the focused P1 closed-loop smoke test.
%
% Changes:
%   1) build_reserve_features.m keeps the frozen 3-feature KRR contract but
%      exposes forecast signed net-load ramp/drop as an OPTIONAL second output.
%   2) engine_island_ems.m passes those forecast-only quantities through the
%      per-step aiCfg to the online reserve selector.
%   3) predict_reserve_ratio.m applies an OPTIONAL post-KRR shield that can
%      only increase alpha.
%
% This patch does NOT enable the shield globally.  The smoke test enables it
% explicitly through cfg.ai fields.
%
% Backups are created next to every modified production file.

clc;

projectRoot = pwd;
patchRoot = fileparts(fileparts(mfilename('fullpath')));

srcBuild = fullfile(patchRoot,'patch_files','ai','build_reserve_features.m');
srcPred  = fullfile(patchRoot,'patch_files','ai','predict_reserve_ratio.m');

dstBuild = fullfile(projectRoot,'ai','build_reserve_features.m');
dstPred  = fullfile(projectRoot,'ai','predict_reserve_ratio.m');
engineFile = fullfile(projectRoot,'core','engine','engine_island_ems.m');

assert(exist(srcBuild,'file')==2,'Patch file missing: %s',srcBuild);
assert(exist(srcPred,'file')==2,'Patch file missing: %s',srcPred);
assert(exist(dstBuild,'file')==2,'Project file missing: %s',dstBuild);
assert(exist(dstPred,'file')==2,'Project file missing: %s',dstPred);
assert(exist(engineFile,'file')==2,'Project file missing: %s',engineFile);

stamp = datestr(now,'yyyymmdd_HHMMSS');

fprintf('\n=============================================================\n');
fprintf(' APPLY EXPERIMENTAL P1 FORECAST-SAFETY-SHIELD PATCH\n');
fprintf('=============================================================\n');

% -------------------------------------------------------------------------
% Back up and replace the two small AI functions.
% -------------------------------------------------------------------------
backup_once_local(dstBuild,stamp);
backup_once_local(dstPred,stamp);

copyfile(srcBuild,dstBuild,'f');
copyfile(srcPred,dstPred,'f');

fprintf('[REPLACED] %s\n',dstBuild);
fprintf('[REPLACED] %s\n',dstPred);

% -------------------------------------------------------------------------
% Patch the engine call site.
% -------------------------------------------------------------------------
txt = fileread(engineFile);
txt = normalize_newlines_local(txt);

marker = 'P1_FORECAST_SAFETY_SHIELD_EXPERIMENTAL';

if contains(txt,marker)
    fprintf('[ALREADY PATCHED] %s\n',engineFile);
else
    backup_once_local(engineFile,stamp);

    oldA = [ ...
        '        reserveFeature = build_reserve_features(Sload,P_PV, ...' newline ...
        '            DieselG_Pgfm_rate,dgUpHeadroom_pu);' newline ...
        '        reserveFeatureHistory(predictionStep,:) = reserveFeature;'];

    newA = [ ...
        '        [reserveFeature,reserveFeatureMeta] = build_reserve_features(Sload,P_PV, ...' newline ...
        '            DieselG_Pgfm_rate,dgUpHeadroom_pu);' newline ...
        '        reserveFeatureHistory(predictionStep,:) = reserveFeature;'];

    assert(contains(txt,oldA), ...
        ['Could not locate the expected build_reserve_features call. ', ...
         'The engine source may have changed. No engine patch was applied.']);

    txt = strrep(txt,oldA,newA);

    oldB = [ ...
        '        reserveTimer=tic;' newline ...
        '        [dP_RESVdown,dP_RESVup,reserveMeta] = compute_frequency_reserve_pu( ...' newline ...
        '            runCfg.reserveMode, reserveRatioRequest, Rdroop, phys.H, ...' newline ...
        '            df_reserve_Hz, rocof_limit_Hz_s, f_rate, aiModel, reserveFeature, ...' newline ...
        '            P_DGmin, P_DGmax, aiCfgRun);'];

    newB = [ ...
        '        % P1_FORECAST_SAFETY_SHIELD_EXPERIMENTAL' newline ...
        '        % Forecast-only directional quantities are passed through aiCfgStep.' newline ...
        '        % They are available before the current MPC solve and are NOT added' newline ...
        '        % to the frozen three-feature KRR input vector.' newline ...
        '        aiCfgStep = aiCfgRun;' newline ...
        '        aiCfgStep.forecastNetLoadNow_pu = reserveFeatureMeta.netLoadNow_pu;' newline ...
        '        aiCfgStep.forecastSignedNetRamp_pu = reserveFeatureMeta.signedNetRampForecast_pu;' newline ...
        '        aiCfgStep.forecastNetDrop_pu = reserveFeatureMeta.netDropForecast_pu;' newline ...
        '        reserveTimer=tic;' newline ...
        '        [dP_RESVdown,dP_RESVup,reserveMeta] = compute_frequency_reserve_pu( ...' newline ...
        '            runCfg.reserveMode, reserveRatioRequest, Rdroop, phys.H, ...' newline ...
        '            df_reserve_Hz, rocof_limit_Hz_s, f_rate, aiModel, reserveFeature, ...' newline ...
        '            P_DGmin, P_DGmax, aiCfgStep);'];

    assert(contains(txt,oldB), ...
        ['Could not locate the expected compute_frequency_reserve_pu call. ', ...
         'The engine source may have changed.']);

    txt = strrep(txt,oldB,newB);

    fid = fopen(engineFile,'w');
    assert(fid>=0,'Could not open engine file for writing.');
    cleaner = onCleanup(@() fclose(fid)); %#ok<NASGU>
    fwrite(fid,txt,'char');
    clear cleaner

    fprintf('[PATCHED]  %s\n',engineFile);
end

clear functions
rehash;
addpath(genpath(projectRoot));

% -------------------------------------------------------------------------
% Contract verification.
% -------------------------------------------------------------------------
assert(contains(fileread(dstBuild),'signedNetRampForecast_pu'), ...
    'Patched build_reserve_features.m verification failed.');

assert(contains(fileread(dstPred),'forecastSafetyShieldTriggered'), ...
    'Patched predict_reserve_ratio.m verification failed.');

assert(contains(fileread(engineFile),marker), ...
    'Patched engine verification failed.');

fprintf('\nPatch verification: PASS\n');
fprintf(['The shield is still OFF by default. It is enabled only by the ', ...
    'focused smoke test.\n']);
fprintf('=============================================================\n');
end


function backup_once_local(filePath,stamp)
backupPath = [filePath '.before_P1_forecast_shield_' stamp '.bak'];
copyfile(filePath,backupPath,'f');
fprintf('[BACKUP]   %s\n',backupPath);
end


function txt = normalize_newlines_local(txt)
txt = strrep(txt,sprintf('\r\n'),sprintf('\n'));
txt = strrep(txt,sprintf('\r'),sprintf('\n'));
end
