function v=get_result_scalar_v1(result,fieldName,defaultValue)
%GET_RESULT_SCALAR_V1 Read finite numeric scalar from result root.

v=defaultValue;

if isfield(result,fieldName)
    x=result.(fieldName);

    if isnumeric(x) && isscalar(x) && isfinite(x)
        v=double(x);
    end
end

end
