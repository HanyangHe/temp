function report = apply_final_33bus_inputavg_patch(projectRoot,applyChanges)
%APPLY_FINAL_33BUS_INPUTAVG_PATCH Final production patch for 33bus.
% - DG=[0.17;0.17;0.17] MW; PV=[1/6;2/15;2/15;1/6] MW.
% - Average only PREDICTIVE Sload/P_PV on the 15-min MPC grid.
% - Keep original output-side ZOH execution.
% - Set current experiment/training target to 33bus.
% - Archive old canonical 33bus AI dataset/model before retraining.
% - Do not touch 10bus/18bus physical cases or canonical AI assets.
%
% Dry run: R=apply_final_33bus_inputavg_patch(pwd,false);
% Apply:   R=apply_final_33bus_inputavg_patch(pwd,true);

if nargin<1 || isempty(projectRoot), projectRoot=pwd; end
if nargin<2 || isempty(applyChanges), applyChanges=false; end
projectRoot=char(projectRoot); applyChanges=logical(applyChanges);

catalogFile=fullfile(projectRoot,'config','system_case_catalog.m');
engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');
cfgFile=fullfile(projectRoot,'config_island_ems.m');
assert(exist(catalogFile,'file')==2,'Missing %s',catalogFile);
assert(exist(engineFile,'file')==2,'Missing %s',engineFile);
assert(exist(cfgFile,'file')==2,'Missing %s',cfgFile);

catalogText=fileread(catalogFile);
engineText=fileread(engineFile);
cfgText=fileread(cfgFile);

ts=datestr(now,'yyyymmdd_HHMMSS');
archiveRoot=fullfile(projectRoot,'archive',['pre_final33bus_inputavg_' ts]);

fprintf('\n=============================================================\n');
fprintf(' FINAL 33-BUS INPUT-AVERAGE PATCH -- %s\n',ternary_local(applyChanges,'APPLY','DRY RUN'));
fprintf('=============================================================\n');

%% 1) 33bus case ratings
oldDG='sys\.DieselG_Pgfm_rate\s*=\s*\[0\.15\s*;\s*0\.15\s*;\s*0\.15\s*\]\s*;';
oldPV='sys\.PVInv_P_rateIn\s*=\s*\[0\.25\s*;\s*0\.20\s*;\s*0\.20\s*;\s*0\.25\s*\]\s*;';
newDG='sys\.DieselG_Pgfm_rate\s*=\s*\[0\.17\s*;\s*0\.17\s*;\s*0\.17\s*\]\s*;';
newPV=['sys\.PVInv_P_rateIn\s*=\s*\[\s*' ...
    '(?:1/6|0\.1666666667)\s*;\s*(?:2/15|0\.1333333333)\s*;\s*' ...
    '(?:2/15|0\.1333333333)\s*;\s*(?:1/6|0\.1666666667)\s*\]\s*;'];

oldDGn=numel(regexp(catalogText,oldDG,'match')); oldPVn=numel(regexp(catalogText,oldPV,'match'));
newDGn=numel(regexp(catalogText,newDG,'match')); newPVn=numel(regexp(catalogText,newPV,'match'));

if newDGn==1 && newPVn==1
    newCatalogText=catalogText; catalogNeedsPatch=false;
elseif oldDGn==1 && oldPVn==1
    newCatalogText=regexprep(catalogText,oldDG,'sys.DieselG_Pgfm_rate = [0.17;0.17;0.17];','once');
    newCatalogText=regexprep(newCatalogText,oldPV,'sys.PVInv_P_rateIn = [1/6;2/15;2/15;1/6];','once');
    catalogNeedsPatch=true;
else
    error('Cannot safely identify 33bus DG/PV lines. oldDG=%d oldPV=%d newDG=%d newPV=%d',oldDGn,oldPVn,newDGn,newPVn);
end

%% 2) Config: formal averaging switch + current 33bus target
flagLine='cfg.forecast.useMPCIntervalAverage = true;';
modeLine='cfg.forecast.mpcIntervalAverageMode = ''adjacent-endpoint'';';
newCfgText=cfgText;
if ~contains(newCfgText,'cfg.forecast.useMPCIntervalAverage')
    anchor='cfg.forecast.upstreamTrustWeight = 0.1;';
    assert(contains(newCfgText,anchor),'Forecast config insertion anchor not found.');
    block=[anchor newline ...
        '% Use interval-average PREDICTIVE load/PV values for each 15-min MPC stage.' newline ...
        '% True 1-s physical load/PV trajectories remain unchanged.' newline ...
        flagLine newline modeLine];
    newCfgText=strrep(newCfgText,anchor,block);
else
    newCfgText=regexprep(newCfgText,'cfg\.forecast\.useMPCIntervalAverage\s*=\s*(?:true|false)\s*;',flagLine,'once');
    if contains(newCfgText,'cfg.forecast.mpcIntervalAverageMode')
        newCfgText=regexprep(newCfgText,'cfg\.forecast\.mpcIntervalAverageMode\s*=\s*[^;]+;',modeLine,'once');
    else
        newCfgText=strrep(newCfgText,flagLine,[flagLine newline modeLine]);
    end
end

newCfgText=regexprep(newCfgText,'cfg\.experiment\.systemCases\s*=\s*\{[^\n;]*\}\s*;', ...
    'cfg.experiment.systemCases = {''33bus''}; % current formal-development target','once');
newCfgText=regexprep(newCfgText,'cfg\.ai\.response\.systemCases\s*=\s*\{[^\n;]*\}\s*;', ...
    'cfg.ai.response.systemCases = {''33bus''}; % regenerate final 33bus response/model','once');

%% 3) Engine: exact smoke-tested INPUT averaging only
beginMark='% FINAL_MPC_INPUT_INTERVAL_AVERAGE_BEGIN';
endMark='% FINAL_MPC_INPUT_INTERVAL_AVERAGE_END';
if contains(engineText,beginMark)
    newEngineText=engineText; engineNeedsPatch=false;
else
    oldBlock=['Sload=resample_horizon_anchors(Sload_anchor,dt_pre,dt_mpc, ...' newline ...
        '            cfg.mpc.horizon_h,cfg.forecast.interpolationMethod);'];
    n=numel(strfind(engineText,oldBlock));
    assert(n==2,'Expected exactly 2 receding-MPC Sload resampling blocks; found %d.',n);
    addBlock=[oldBlock newline ...
        '        ' beginMark newline ...
        '        % Ordinary interval representation of PREDICTIVE MPC inputs.' newline ...
        '        % Do NOT alter Pload_true_box or PV1_curve used by 1-s physics.' newline ...
        '        if isfield(cfg.forecast,''useMPCIntervalAverage'') && ...' newline ...
        '                cfg.forecast.useMPCIntervalAverage' newline ...
        '            if size(Sload,2)>=2' newline ...
        '                Sload=[0.5*(Sload(:,1:end-1)+Sload(:,2:end)) Sload(:,end)];' newline ...
        '            end' newline ...
        '            if size(P_PV,2)>=2' newline ...
        '                P_PV=[0.5*(P_PV(:,1:end-1)+P_PV(:,2:end)) P_PV(:,end)];' newline ...
        '            end' newline ...
        '        end' newline ...
        '        ' endMark];
    newEngineText=strrep(engineText,oldBlock,addBlock);
    engineNeedsPatch=true;
end
blockCount=numel(strfind(newEngineText,beginMark));
assert(blockCount==2,'Expected exactly 2 final input-average blocks; found %d.',blockCount);
assert(~contains(newEngineText,'MIDPOINT_EXEC_SMOKE_BEGIN'),'Midpoint smoke code found in production engine text.');
assert(~contains(newEngineText,'WHOLEAVG_EXEC_SMOKE_BEGIN'),'Whole-average smoke code found in production engine text.');

%% 4) Old canonical 33bus assets
setDir=fullfile(projectRoot,'ai','datasets','33bus');
modelDir=fullfile(projectRoot,'ai','models','33bus');
setFile=fullfile(setDir,'reserve_response_dataset_paper.mat');
modelFile=fullfile(modelDir,'reserve_krr_model.mat');

fprintf('Target DG total / PV total : 0.51 / 0.60 MW\n');
fprintf('Predictive input averaging : ON\n');
fprintf('Output execution           : original ZOH\n');
fprintf('Experiment/training target : 33bus\n');
fprintf('Engine average blocks      : %d\n',blockCount);
fprintf('Old canonical dataset/model: %d / %d\n',exist(setFile,'file')==2,exist(modelFile,'file')==2);
fprintf('Archive root               : %s\n',archiveRoot);

report=struct('applyChanges',applyChanges,'archiveRoot',string(archiveRoot), ...
    'catalogNeedsPatch',catalogNeedsPatch,'engineNeedsPatch',engineNeedsPatch, ...
    'engineAverageBlockCount',blockCount);

if ~applyChanges
    fprintf('\nDRY RUN COMPLETE -- no files modified.\n');
    return;
end

%% 5) Back up, archive old 33bus assets, install patch
mkdir(archiveRoot); backupDir=fullfile(archiveRoot,'production_backup'); mkdir(backupDir);
copyfile(catalogFile,fullfile(backupDir,'system_case_catalog.m'));
copyfile(engineFile,fullfile(backupDir,'engine_island_ems.m'));
copyfile(cfgFile,fullfile(backupDir,'config_island_ems.m'));

archiveSetParent=fullfile(archiveRoot,'ai','datasets'); mkdir(archiveSetParent);
archiveModelParent=fullfile(archiveRoot,'ai','models'); mkdir(archiveModelParent);
if exist(setDir,'dir')==7
    [ok,msg]=movefile(setDir,fullfile(archiveSetParent,'33bus')); assert(ok,'%s',msg);
end
if exist(modelDir,'dir')==7
    [ok,msg]=movefile(modelDir,fullfile(archiveModelParent,'33bus')); assert(ok,'%s',msg);
end
mkdir(setDir); mkdir(modelDir);

write_text_local(catalogFile,newCatalogText);
write_text_local(cfgFile,newCfgText);
write_text_local(engineFile,newEngineText);

clear system_case_catalog config_island_ems
rehash
cfg=config_island_ems();
assert(isfield(cfg.forecast,'useMPCIntervalAverage') && cfg.forecast.useMPCIntervalAverage,'Average-input flag verification failed.');
assert(isequal(string(cfg.experiment.systemCases),"33bus"),'experiment.systemCases is not 33bus.');
assert(isequal(string(cfg.ai.response.systemCases),"33bus"),'ai.response.systemCases is not 33bus.');
rng(0,'twister'); sys=system_case_catalog('33bus',cfg);
assert(max(abs(double(sys.DieselG_Pgfm_rate(:))-[0.17;0.17;0.17]))<1e-12,'DG verification failed.');
assert(max(abs(double(sys.PVInv_P_rateIn(:))-[1/6;2/15;2/15;1/6]))<1e-10,'PV verification failed.');
assert(exist(setFile,'file')~=2 && exist(modelFile,'file')~=2,'Old 33bus canonical AI assets still visible.');

manifest=struct('timestamp',ts,'dgRatings_MW',[0.17;0.17;0.17], ...
    'pvRatings_MW',[1/6;2/15;2/15;1/6],'predictiveInputAverage',true, ...
    'outputExecution','original-ZOH','trainingCase','33bus', ...
    'simulationLaunched',false,'trainingLaunched',false);
save(fullfile(archiveRoot,'final33bus_inputavg_patch_manifest.mat'),'manifest','-v7.3');

fprintf('\nFINAL PATCH APPLIED AND VERIFIED.\n');
fprintf('Old 33bus AI assets archived; 10bus/18bus untouched.\n');
fprintf('No simulation or training launched.\n');
report.manifest=manifest;
end

function write_text_local(fileName,text)
tmp=[fileName '.tmp_final33bus_inputavg'];
fid=fopen(tmp,'w'); assert(fid>0,'Cannot write %s',tmp); fwrite(fid,text,'char'); fclose(fid);
[ok,msg]=movefile(tmp,fileName,'f'); assert(ok,'Cannot install %s: %s',fileName,msg);
end

function out=ternary_local(tf,a,b)
if tf, out=a; else, out=b; end
end
