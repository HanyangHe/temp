function report = patch_replay_saved_operating_profiles_final33_v1(projectRoot,applyChanges)
%PATCH_REPLAY_SAVED_OPERATING_PROFILES_FINAL33_V1
% Add support for the official final 33-bus result layout to the EXISTING
% replay_saved_operating_profiles.m without changing its public interface.
%
% Existing 10-/18-bus lookup remains unchanged.
%
% Official 33-bus layout:
%   outputs/<runTag>/<PaperLabel>/decay_XXX_seed_XXX/result.mat
%
% In particular:
%   internal method T7 -> paper folder F1
%
% Dry run:
%   R = patch_replay_saved_operating_profiles_final33_v1(pwd,false);
%
% Apply:
%   R = patch_replay_saved_operating_profiles_final33_v1(pwd,true);

if nargin<1 || isempty(projectRoot)
    projectRoot=pwd;
end
if nargin<2 || isempty(applyChanges)
    applyChanges=false;
end

projectRoot=char(projectRoot);
applyChanges=logical(applyChanges);

targetFile=fullfile(projectRoot,'replay_saved_operating_profiles.m');

assert(exist(targetFile,'file')==2, ...
    'Cannot find replay_saved_operating_profiles.m at project root: %s', ...
    targetFile);

src=fileread(targetFile);

marker='% FINAL33_OFFICIAL_RESULT_LAYOUT_FALLBACK_V1';

fprintf('\n=============================================================\n');
if applyChanges
    fprintf(' PATCH replay_saved_operating_profiles -- APPLY\n');
else
    fprintf(' PATCH replay_saved_operating_profiles -- DRY RUN\n');
end
fprintf('=============================================================\n');
fprintf('Target: %s\n',targetFile);

% Idempotent behavior.
if contains(src,marker)
    fprintf('Patch marker already present. No duplicate insertion needed.\n');
    report=struct();
    report.targetFile=string(targetFile);
    report.alreadyPatched=true;
    report.applied=false;
    report.pass=true;
    return;
end

% We intentionally patch only a very small discovery block. These tokens
% confirm that the current file is the expected replay implementation.
requiredTokens={ ...
    'hits', ...
    'runRoot', ...
    'caseName', ...
    'methodID', ...
    'decay', ...
    'Expected exactly one saved result'};

for i=1:numel(requiredTokens)
    assert(contains(src,requiredTokens{i}), ...
        'Unexpected replay_saved_operating_profiles.m: missing token "%s".', ...
        requiredTokens{i});
end

% Insert immediately before the existing "exactly one result" assertion.
assertToken='assert(numel(hits)==1';

pos=strfind(src,assertToken);

assert(numel(pos)==1, ...
    ['Expected exactly one assert(numel(hits)==1 ...) statement in ' ...
     'replay_saved_operating_profiles.m; found %d.'],numel(pos));

insertPos=pos(1);

fallbackBlock=[ ...
    marker newline ...
    '% The original profile replay searches the legacy flat MAT-file layout.' newline ...
    '% The official final 33-bus suite instead stores each result as:' newline ...
    '%   <PaperLabel>/decay_XXX_seed_XXX/result.mat' newline ...
    '% Preserve the legacy search for 10/18bus, then use this fallback only' newline ...
    '% when the requested case is 33bus and the legacy search did not find' newline ...
    '% exactly one result.' newline ...
    'if numel(hits)~=1 && strcmpi(string(caseName),"33bus")' newline ...
    '    profilePaperLabel=string(methodID);' newline ...
    '    if profilePaperLabel=="T7"' newline ...
    '        profilePaperLabel="F1";' newline ...
    '    end' newline ...
    '' newline ...
    '    profileSeed=0;' newline ...
    '    if exist(''seed'',''var'') && isnumeric(seed) && isscalar(seed)' newline ...
    '        profileSeed=double(seed);' newline ...
    '    end' newline ...
    '' newline ...
    '    profileCaseDir=sprintf(''decay_%03d_seed_%03d'',' newline ...
    '        round(100*double(decay)),round(profileSeed));' newline ...
    '' newline ...
    '    profileDirectFile=fullfile(runRoot,char(profilePaperLabel),' newline ...
    '        profileCaseDir,''result.mat'');' newline ...
    '' newline ...
    '    if exist(profileDirectFile,''file'')==2' newline ...
    '        hits=dir(profileDirectFile);' newline ...
    '    end' newline ...
    'end' newline ...
    '% FINAL33_OFFICIAL_RESULT_LAYOUT_FALLBACK_V1_END' newline ...
    newline];

patched=[src(1:insertPos-1) fallbackBlock src(insertPos:end)];

% Static content checks before touching the user's file.
assert(contains(patched,marker), ...
    'Internal patch construction failed: marker missing.');
assert(contains(patched,'profilePaperLabel="F1"'), ...
    'Internal patch construction failed: T7->F1 mapping missing.');
assert(contains(patched,'result.mat'), ...
    'Internal patch construction failed: official result path missing.');

report=struct();
report.targetFile=string(targetFile);
report.alreadyPatched=false;
report.applied=false;
report.pass=false;

fprintf('\nPatch behavior:\n');
fprintf('  10bus legacy lookup : unchanged\n');
fprintf('  18bus legacy lookup : unchanged\n');
fprintf('  33bus fallback      : <PaperLabel>/decay_XXX_seed_XXX/result.mat\n');
fprintf('  T7 folder mapping   : F1\n');

if ~applyChanges
    fprintf('\nDRY RUN PASS. No source file was modified.\n');
    report.pass=true;
    return;
end

stamp=datestr(now,'yyyymmdd_HHMMSS');
backupDir=fullfile(projectRoot,'archive', ...
    ['replay_saved_profiles_final33_patch_' stamp]);

if ~exist(backupDir,'dir')
    mkdir(backupDir);
end

backupFile=fullfile(backupDir,'replay_saved_operating_profiles.m');
copyfile(targetFile,backupFile);

tmpFile=[targetFile '.tmp_final33_profile_patch'];

fid=fopen(tmpFile,'w');
assert(fid>0,'Could not write temporary patched file.');
fwrite(fid,patched,'char');
fclose(fid);

[ok,msg]=movefile(tmpFile,targetFile,'f');
assert(ok,'Could not install patched replay file: %s',msg);

clear replay_saved_operating_profiles
rehash

verify=fileread(targetFile);

assert(contains(verify,marker), ...
    'Post-write verification failed: patch marker absent.');
assert(contains(verify,'profilePaperLabel="F1"'), ...
    'Post-write verification failed: T7->F1 mapping absent.');

fprintf('\n=============================================================\n');
fprintf(' PATCH INSTALLED: PASS\n');
fprintf('=============================================================\n');
fprintf('Backup: %s\n',backupFile);
fprintf('No simulation was launched.\n');

report.backupFile=string(backupFile);
report.applied=true;
report.pass=true;

end
