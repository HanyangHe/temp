function pCmd = common_forecast_shaped_bess_value_v1( ...
    Pbatt_opt_Dec,execIdx,RealStep,samplesPerDecision,ii, ...
    Sload,P_PV,BatteryGFL_P_rate,BusOfBattery, ...
    SOC,SOCmin,SOCmax,BatteryGFM_Num)
%COMMON_FORECAST_SHAPED_BESS_VALUE_V1
% Common method-independent forecast-shaped stationary-BESS realization.
%
% Base MPC command:
%   pBase = Pbatt_opt_Dec(execIdx,1,ii)
%
% Predicted net-load trend from the CURRENT MPC forecast horizon:
%   dPnet = [Pload_hat(2)-PPV_hat(2)]-[Pload_hat(1)-PPV_hat(1)]
%
% Inside the current 15-min interval:
%   xi = (t-t_k)/DeltaT in [0,1)
%   dPBESS,total = (xi-1/2)*dPnet
%
% The requested correction has zero continuous-time interval mean because
% integral_0^1 (xi-1/2) dxi = 0. The stationary BESS fleet shares the
% correction according to fixed power-rating weights.
%
% Positive battery power = discharge/injection.
% Only forecast Sload/P_PV are used; true future load/PV and frequency
% outcomes are never used.

N=size(Pbatt_opt_Dec,1);
k=min(max(round(execIdx),1),N);
pBase=double(Pbatt_opt_Dec(k,1,ii));

if size(Sload,2)<2 || size(P_PV,2)<2
    pCmd=pBase;
    return;
end

pLoad1=sum(real(double(Sload(:,1))));
pLoad2=sum(real(double(Sload(:,2))));
pPV1=sum(real(double(P_PV(:,1))));
pPV2=sum(real(double(P_PV(:,2))));

pNet1=pLoad1-pPV1;
pNet2=pLoad2-pPV2;
dPnet=pNet2-pNet1;

r=mod(round(RealStep)-1,samplesPerDecision);
xi=double(r)/double(samplesPerDecision);
xi=min(max(xi,0),1);

dPtotal=(xi-0.5)*dPnet;

nBatt=numel(BusOfBattery);
pmax=zeros(nBatt,1);

for jj=1:nBatt
    pmax(jj)=double(BatteryGFL_P_rate(BusOfBattery(jj),1));
end

sumPmax=sum(pmax);

if sumPmax<=0
    pCmd=pBase;
    return;
end

weight=pmax(ii)/sumPmax;
dPi=weight*dPtotal;

% Directional SoC protection for stationary BESS state ordering.
socIdx=BatteryGFM_Num+ii;

if socIdx>=1 && socIdx<=size(SOC,1)
    socNow=double(SOC(socIdx,RealStep));
    tol=1e-4;

    if dPi>0 && socNow<=double(SOCmin)+tol
        dPi=0;
    end

    if dPi<0 && socNow>=double(SOCmax)-tol
        dPi=0;
    end
end

pCmd=pBase+dPi;

% Enforce stationary-BESS active-power rating.
pCmd=min(max(pCmd,-pmax(ii)),pmax(ii));

end
