function report = apply_final_33bus_inputavg_patch_v2(projectRoot,applyChanges)
%APPLY_FINAL_33BUS_INPUTAVG_PATCH_V2
% Final production patch for the 33-bus study.
%
% Fix in v2:
%   config_island_ems.m is resolved from the MATLAB path with WHICH rather
%   than being incorrectly assumed to live in projectRoot.
%
% Final production decisions:
%   1) 33bus DG ratings = [0.17;0.17;0.17] MW
%   2) 33bus PV ratings = [1/6;2/15;2/15;1/6] MW (0.60 MW total)
%   3) MPC PREDICTIVE load/PV trajectories are represented by adjacent-point
%      averages on the 15-min MPC grid before optimization.
%   4) True 1-s physical load/PV curves are unchanged.
%   5) Original ZOH output execution is retained.
%   6) Current experiment/training target is 33bus only.
%   7) Old canonical 33bus AI dataset/model folders are archived.
%
% NO simulation or training is launched.
%
% Dry run:
%   R = apply_final_33bus_inputavg_patch_v2(pwd,false);
%
% Apply:
%   clear functions
%   rehash
%   addpath(genpath(pwd))
%   R = apply_final_33bus_inputavg_patch_v2(pwd,true);

if nargin<1 || isempty(projectRoot)
    projectRoot=pwd;
end
if nargin<2 || isempty(applyChanges)
    applyChanges=false;
end

projectRoot=char(projectRoot);
applyChanges=logical(applyChanges);

addpath(genpath(projectRoot));
rehash;

catalogFile=fullfile(projectRoot,'config','system_case_catalog.m');
engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');

cfgFile=which('config_island_ems');
assert(~isempty(cfgFile), ...
    'config_island_ems.m is not visible on the MATLAB path.');

assert(exist(catalogFile,'file')==2,'Missing: %s',catalogFile);
assert(exist(engineFile,'file')==2,'Missing: %s',engineFile);
assert(exist(cfgFile,'file')==2,'Missing resolved config file: %s',cfgFile);

fprintf('\nResolved files:\n');
fprintf('  config_island_ems : %s\n',cfgFile);
fprintf('  system catalog    : %s\n',catalogFile);
fprintf('  EMS engine        : %s\n',engineFile);

catalogText=fileread(catalogFile);
engineText=fileread(engineFile);
cfgText=fileread(cfgFile);

timestamp=datestr(now,'yyyymmdd_HHMMSS');
archiveRoot=fullfile(projectRoot,'archive', ...
    ['pre_final33bus_inputavg_' timestamp]);

fprintf('\n=============================================================\n');
if applyChanges
    fprintf(' FINAL 33-BUS INPUT-AVERAGE PATCH V2 -- APPLY\n');
else
    fprintf(' FINAL 33-BUS INPUT-AVERAGE PATCH V2 -- DRY RUN\n');
end
fprintf('=============================================================\n');

%% 1) Prepare 33-bus case patch
dgOldPattern='sys\.DieselG_Pgfm_rate\s*=\s*\[0\.15\s*;\s*0\.15\s*;\s*0\.15\s*\]\s*;';
pvOldPattern='sys\.PVInv_P_rateIn\s*=\s*\[0\.25\s*;\s*0\.20\s*;\s*0\.20\s*;\s*0\.25\s*\]\s*;';

dgNewPattern='sys\.DieselG_Pgfm_rate\s*=\s*\[0\.17\s*;\s*0\.17\s*;\s*0\.17\s*\]\s*;';
pvNewPattern=['sys\.PVInv_P_rateIn\s*=\s*\[\s*' ...
    '(?:1/6|0\.1666666667)\s*;\s*' ...
    '(?:2/15|0\.1333333333)\s*;\s*' ...
    '(?:2/15|0\.1333333333)\s*;\s*' ...
    '(?:1/6|0\.1666666667)\s*\]\s*;'];

oldDG=numel(regexp(catalogText,dgOldPattern,'match'));
oldPV=numel(regexp(catalogText,pvOldPattern,'match'));
newDG=numel(regexp(catalogText,dgNewPattern,'match'));
newPV=numel(regexp(catalogText,pvNewPattern,'match'));

if newDG==1 && newPV==1
    catalogNeedsPatch=false;
elseif oldDG==1 && oldPV==1
    catalogNeedsPatch=true;
else
    error(['Cannot safely identify the 33-bus DG/PV lines. ' ...
        'oldDG=%d oldPV=%d newDG=%d newPV=%d'], ...
        oldDG,oldPV,newDG,newPV);
end

newCatalogText=catalogText;

if catalogNeedsPatch
    newCatalogText=regexprep(newCatalogText,dgOldPattern, ...
        'sys.DieselG_Pgfm_rate = [0.17;0.17;0.17];','once');

    newCatalogText=regexprep(newCatalogText,pvOldPattern, ...
        'sys.PVInv_P_rateIn = [1/6;2/15;2/15;1/6];','once');
end

%% 2) Prepare config patch
newCfgText=cfgText;

flagLine='cfg.forecast.useMPCIntervalAverage = true;';
modeLine='cfg.forecast.mpcIntervalAverageMode = ''adjacent-endpoint'';';

if contains(newCfgText,'cfg.forecast.useMPCIntervalAverage')
    newCfgText=regexprep(newCfgText, ...
        'cfg\.forecast\.useMPCIntervalAverage\s*=\s*(?:true|false)\s*;', ...
        flagLine,'once');
else
    % Insert next to an existing forecast field, without assuming the config
    % file resides in the project root.
    forecastAnchors={ ...
        'cfg.forecast.upstreamTrustWeight', ...
        'cfg.forecast.interpolationMethod', ...
        'cfg.forecast.nativeStep_h'};

    inserted=false;

    for ia=1:numel(forecastAnchors)
        pat=[regexptranslate('escape',forecastAnchors{ia}) '\s*=\s*[^;]+;'];
        [s,e]=regexp(newCfgText,pat,'start','end','once');

        if ~isempty(s)
            originalLine=newCfgText(s:e);
            block=[originalLine newline ...
                '% Final MPC time-discretization: use adjacent-point averages of' newline ...
                '% PREDICTIVE 15-min load/PV samples. True 1-s curves are unchanged.' newline ...
                flagLine newline ...
                modeLine];

            newCfgText=[newCfgText(1:s-1) block newCfgText(e+1:end)];
            inserted=true;
            break;
        end
    end

    assert(inserted, ...
        'Could not find a safe cfg.forecast insertion anchor.');
end

if contains(newCfgText,'cfg.forecast.mpcIntervalAverageMode')
    newCfgText=regexprep(newCfgText, ...
        'cfg\.forecast\.mpcIntervalAverageMode\s*=\s*[^;]+;', ...
        modeLine,'once');
else
    newCfgText=strrep(newCfgText,flagLine,[flagLine newline modeLine]);
end

% Set only the CURRENT work/training target to 33bus. Existing 10/18 files
% and results are not deleted or modified.
expPat='cfg\.experiment\.systemCases\s*=\s*\{[^\n;]*\}\s*;';
respPat='cfg\.ai\.response\.systemCases\s*=\s*\{[^\n;]*\}\s*;';

assert(~isempty(regexp(newCfgText,expPat,'once')), ...
    'Could not find cfg.experiment.systemCases in config.');

assert(~isempty(regexp(newCfgText,respPat,'once')), ...
    'Could not find cfg.ai.response.systemCases in config.');

newCfgText=regexprep(newCfgText,expPat, ...
    'cfg.experiment.systemCases = {''33bus''}; % current formal-development target', ...
    'once');

newCfgText=regexprep(newCfgText,respPat, ...
    'cfg.ai.response.systemCases = {''33bus''}; % regenerate final 33bus dataset/model', ...
    'once');

%% 3) Prepare production engine patch
markerBegin='% FINAL_MPC_INPUT_INTERVAL_AVERAGE_BEGIN';
markerEnd='% FINAL_MPC_INPUT_INTERVAL_AVERAGE_END';

if contains(engineText,markerBegin)
    engineNeedsPatch=false;
    newEngineText=engineText;
    markerCount=numel(strfind(newEngineText,markerBegin));
else
    engineNeedsPatch=true;

    oldBlock=[ ...
        'Sload=resample_horizon_anchors(Sload_anchor,dt_pre,dt_mpc, ...' newline ...
        '            cfg.mpc.horizon_h,cfg.forecast.interpolationMethod);'];

    nAnchors=numel(strfind(engineText,oldBlock));

    assert(nAnchors==2, ...
        ['Expected exactly two receding-MPC Sload resampling blocks; found %d. ' ...
         'No production file was changed.'],nAnchors);

    avgBlock=[oldBlock newline ...
        '        ' markerBegin newline ...
        '        % Represent each 15-min MPC stage by the adjacent-point average' newline ...
        '        % of its PREDICTIVE load/PV samples. Physical 1-s true curves' newline ...
        '        % Pload_true_box and PV1_curve are intentionally unchanged.' newline ...
        '        if isfield(cfg.forecast,''useMPCIntervalAverage'') && ...' newline ...
        '                cfg.forecast.useMPCIntervalAverage' newline ...
        '            if size(Sload,2)>=2' newline ...
        '                Sload=[0.5*(Sload(:,1:end-1)+Sload(:,2:end)) Sload(:,end)];' newline ...
        '            end' newline ...
        '            if size(P_PV,2)>=2' newline ...
        '                P_PV=[0.5*(P_PV(:,1:end-1)+P_PV(:,2:end)) P_PV(:,end)];' newline ...
        '            end' newline ...
        '        end' newline ...
        '        ' markerEnd];

    newEngineText=strrep(engineText,oldBlock,avgBlock);
    markerCount=numel(strfind(newEngineText,markerBegin));

    assert(markerCount==2, ...
        'Engine patch verification failed: expected 2 final average-input blocks.');
end

assert(markerCount==2, ...
    'Production engine must contain exactly 2 final average-input blocks.');

% Never formalize the execution-layer smoke variants.
assert(~contains(newEngineText,'MIDPOINT_EXEC_SMOKE_BEGIN'), ...
    'Production engine unexpectedly contains midpoint-execution smoke code.');

assert(~contains(newEngineText,'WHOLEAVG_EXEC_SMOKE_BEGIN'), ...
    'Production engine unexpectedly contains whole-average-execution smoke code.');

%% 4) Identify old canonical 33-bus assets
datasetDir=fullfile(projectRoot,'ai','datasets','33bus');
modelDir=fullfile(projectRoot,'ai','models','33bus');

datasetFile=fullfile(datasetDir,'reserve_response_dataset_paper.mat');
modelFile=fullfile(modelDir,'reserve_krr_model.mat');

fprintf('Target case:\n');
fprintf('  DG = [0.17 0.17 0.17] MW, total 0.51 MW\n');
fprintf('  PV = [1/6 2/15 2/15 1/6] MW, total 0.60 MW\n');
fprintf('Predictive input averaging: ON\n');
fprintf('Output-side midpoint/FOH   : OFF\n');
fprintf('Current experiment grid    : 33bus\n');
fprintf('Current AI-response grid   : 33bus\n');
fprintf('Engine average blocks      : %d\n',markerCount);
fprintf('Old 33bus canonical dataset exists: %d\n',exist(datasetFile,'file')==2);
fprintf('Old 33bus canonical model exists  : %d\n',exist(modelFile,'file')==2);
fprintf('Archive root: %s\n',archiveRoot);

report=struct();
report.applyChanges=applyChanges;
report.cfgFile=string(cfgFile);
report.catalogFile=string(catalogFile);
report.engineFile=string(engineFile);
report.archiveRoot=string(archiveRoot);
report.catalogNeedsPatch=catalogNeedsPatch;
report.engineNeedsPatch=engineNeedsPatch;
report.engineAverageBlockCount=markerCount;
report.datasetExistedBefore=exist(datasetFile,'file')==2;
report.modelExistedBefore=exist(modelFile,'file')==2;

if ~applyChanges
    fprintf('\nDRY RUN COMPLETE. No file was modified.\n');
    fprintf('If this report is correct, rerun with applyChanges=true.\n');
    return;
end

%% 5) APPLY with backups
if ~exist(archiveRoot,'dir')
    mkdir(archiveRoot);
end

backupDir=fullfile(archiveRoot,'production_backup');
if ~exist(backupDir,'dir')
    mkdir(backupDir);
end

copyfile(catalogFile,fullfile(backupDir,'system_case_catalog.m'));
copyfile(engineFile,fullfile(backupDir,'engine_island_ems.m'));
copyfile(cfgFile,fullfile(backupDir,'config_island_ems.m'));

archiveDatasetParent=fullfile(archiveRoot,'ai','datasets');
archiveModelParent=fullfile(archiveRoot,'ai','models');

if ~exist(archiveDatasetParent,'dir'), mkdir(archiveDatasetParent); end
if ~exist(archiveModelParent,'dir'), mkdir(archiveModelParent); end

if exist(datasetDir,'dir')==7
    [ok,msg]=movefile(datasetDir,fullfile(archiveDatasetParent,'33bus'));
    assert(ok,'Failed to archive 33bus dataset directory: %s',msg);
end

if exist(modelDir,'dir')==7
    [ok,msg]=movefile(modelDir,fullfile(archiveModelParent,'33bus'));
    assert(ok,'Failed to archive 33bus model directory: %s',msg);
end

if ~exist(datasetDir,'dir'), mkdir(datasetDir); end
if ~exist(modelDir,'dir'), mkdir(modelDir); end

write_text_local(catalogFile,newCatalogText);
write_text_local(cfgFile,newCfgText);
write_text_local(engineFile,newEngineText);

clear system_case_catalog
clear config_island_ems
rehash

cfg=config_island_ems();

assert(isfield(cfg.forecast,'useMPCIntervalAverage') && ...
    logical(cfg.forecast.useMPCIntervalAverage), ...
    'Config verification failed: predictive interval averaging is OFF.');

assert(isequal(string(cfg.experiment.systemCases),"33bus"), ...
    'Config verification failed: experiment.systemCases is not 33bus.');

assert(isequal(string(cfg.ai.response.systemCases),"33bus"), ...
    'Config verification failed: ai.response.systemCases is not 33bus.');

rng(0,'twister');
sys=system_case_catalog('33bus',cfg);

assert(max(abs(double(sys.DieselG_Pgfm_rate(:))-[0.17;0.17;0.17]))<1e-12, ...
    'Production 33bus DG verification failed.');

assert(max(abs(double(sys.PVInv_P_rateIn(:))-[1/6;2/15;2/15;1/6]))<1e-10, ...
    'Production 33bus PV verification failed.');

finalEngineText=fileread(engineFile);

assert(numel(strfind(finalEngineText,markerBegin))==2, ...
    'Production engine does not contain exactly two final average-input blocks.');

assert(exist(datasetFile,'file')~=2, ...
    'Old canonical 33bus dataset is still visible after archival.');

assert(exist(modelFile,'file')~=2, ...
    'Old canonical 33bus model is still visible after archival.');

manifest=struct();
manifest.timestamp=timestamp;
manifest.dgRatings_MW=[0.17;0.17;0.17];
manifest.pvRatings_MW=[1/6;2/15;2/15;1/6];
manifest.predictiveInputAverage=true;
manifest.outputExecution='original-ZOH';
manifest.experimentCases={'33bus'};
manifest.trainingCases={'33bus'};
manifest.simulationLaunched=false;
manifest.trainingLaunched=false;
manifest.archiveRoot=archiveRoot;

save(fullfile(archiveRoot,'final33bus_inputavg_patch_manifest.mat'), ...
    'manifest','-v7.3');

fprintf('\n=============================================================\n');
fprintf(' FINAL PATCH APPLIED AND VERIFIED\n');
fprintf('=============================================================\n');
fprintf('33bus DG/PV production case      : UPDATED\n');
fprintf('Predictive MPC input averaging   : ENABLED\n');
fprintf('Output-side midpoint/FOH         : NOT ENABLED\n');
fprintf('Old canonical 33bus AI assets    : ARCHIVED\n');
fprintf('10bus/18bus canonical AI assets  : NOT TOUCHED\n');
fprintf('Simulation/training launched     : NO\n');
fprintf('Backup/archive                   : %s\n',archiveRoot);
fprintf('=============================================================\n');

report.manifest=manifest;

end


function write_text_local(fileName,text)

tmp=[fileName '.tmp_final33bus_inputavg_v2'];

fid=fopen(tmp,'w');
assert(fid>0,'Could not open temporary file: %s',tmp);

fwrite(fid,text,'char');
fclose(fid);

[ok,msg]=movefile(tmp,fileName,'f');
assert(ok,'Could not install patched file %s: %s',fileName,msg);

end
