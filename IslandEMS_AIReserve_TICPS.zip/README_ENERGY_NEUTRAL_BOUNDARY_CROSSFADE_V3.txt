ENERGY-NEUTRAL BOUNDARY CROSSFADE TEST V3
==========================================

Why V3
------
V2 had a MATLAB parser error because multiple local helper functions were
mixed incorrectly in one file. V3 removes that entire failure mode:

- the main test file has exactly ONE function definition;
- every helper is a separate .m file under tools/;
- the physical experiment is unchanged from V1/V2;
- persistence remains summary-first and robust.

Project structure
-----------------
tests/
  test_F1_33bus_energy_neutral_boundary_crossfade_v3.m

tools/
  common_boundary_crossfade_value_v1.m
  remove_tree_from_path_silent_v1.m
  normalize_path_for_compare_v1.m
  write_text_atomic_v1.m
  restore_engine_from_text_v1.m
  build_crossfade_summary_v1.m
  get_result_scalar_v1.m
  get_summary_scalar_v1.m
  find_f1_reference_csv_crossfade_v1.m
  get_table_scalar_crossfade_v1.m
  atomic_save_result_v73_v1.m
  restore_boundary_crossfade_engine_v3.m

Run preflight
-------------
clear functions
rehash
addpath(genpath(pwd))
Rpre = test_F1_33bus_energy_neutral_boundary_crossfade_v3(pwd,false);

Only if PASS
------------
Rxf = test_F1_33bus_energy_neutral_boundary_crossfade_v3(pwd,true);

Expected runtime
----------------
About 50-55 minutes for the one 33-bus F1 simulation.

Emergency restore
-----------------
Only if MATLAB/Windows is force-killed while the temporary patch is active:

Rrestore = restore_boundary_crossfade_engine_v3(pwd);
