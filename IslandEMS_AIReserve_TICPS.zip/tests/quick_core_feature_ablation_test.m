function report = quick_core_feature_ablation_test(varargin)
%QUICK_CORE_FEATURE_ABLATION_TEST Fast, no-simulation ablation of the five
%physics-core candidates used for AI reserve adaptation.
%
% PURPOSE
%   Determine whether all five current candidate features are needed before
%   generating an expensive alpha* oracle dataset. The test reuses the small
%   96-row feature-screen snapshot created by smoke_T7_18bus(). It does NOT
%   launch MPC or physical simulation and does NOT write to outputs/.
%
% FIVE CANDIDATES
%   1) netLoadNow_pu        : active-power operating point P_net
%   2) absNetLoadRamp_pu    : forecast net-load variation magnitude
%   3) absPVRamp_pu         : forecast PV variation magnitude
%   4) dgUpHeadroom_pu      : available SG upward active-power headroom
%   5) bessMeanSOC          : BESS energy state
%
% TARGET
%   Realized frequency-stress index in the following 15-min interval:
%       stress_k = max(max|df|/df_limit, max|RoCoF|/RoCoF_limit)
%
% TESTS
%   A) Full 5-feature model performance using blocked nested CV.
%   B) Leave-one-feature-out (LOFO): remove one feature at a time.
%      Positive RMSE/MAE penalty means the removed feature was useful.
%   C) Incremental first-principles build-up:
%        S1 = [Pnet, |dPnet|]
%        S2 = S1 + DG upward headroom
%        S3 = S2 + |dPV|
%        S4 = S3 + BESS SOC
%   D) Partial Spearman association of each feature with stress while
%      conditioning on the other four features.
%   E) Pairwise feature redundancy (Spearman correlation).
%
% USAGE
%   report = quick_core_feature_ablation_test();
%   report = quick_core_feature_ablation_test(snapshotStruct);
%   report = quick_core_feature_ablation_test(fullSmokeResultStruct);
%
% INPUT DISCOVERY ORDER
%   explicit input -> base featureScreenSnapshot/result/base -> OS temp cache
%
% OUTPUT POLICY
%   No files are saved. No formal outputs/ folder is touched.
%
% INTERPRETATION
%   This is a one-day screening against frequency stress, NOT final alpha*.
%   Use it to simplify the candidate feature set before costly oracle runs.

snapshot = resolve_snapshot(varargin{:});
if isempty(snapshot)
    fprintf('\nCORE FEATURE ABLATION NOT RUN: no feature-screen snapshot is available.\n');
    fprintf('This test will NOT launch a costly simulation.\n');
    fprintf('Run once:  base = smoke_T7_18bus();\n');
    fprintf('Then run:  report = quick_core_feature_ablation_test();\n\n');
    report = [];
    return;
end

featureNames = ["netLoadNow_pu","absNetLoadRamp_pu","absPVRamp_pu", ...
                "dgUpHeadroom_pu","bessMeanSOC"];
shortNames = ["Pnet","|dPnet|","|dPV|","DG headroom","BESS SOC"];
allNames = string(snapshot.features.names(:));
D = snapshot.features.data;
y = snapshot.target.stress(:);
time_h = snapshot.time_h(:);

idx = zeros(numel(featureNames),1);
for i = 1:numel(featureNames)
    j = find(allNames == featureNames(i),1);
    if isempty(j)
        error('quick_core_feature_ablation_test:MissingFeature', ...
            'Required feature "%s" is not present in the snapshot.',featureNames(i));
    end
    idx(i)=j;
end

X = D(:,idx);
good = isfinite(y) & all(isfinite(X),2) & isfinite(time_h);
X=X(good,:); y=y(good); t=time_h(good);
if numel(y)<48
    warning('Only %d complete rows are available; conclusions will be weak.',numel(y));
end

fprintf('\n=============================================================\n');
fprintf(' QUICK 5-FEATURE PHYSICS ABLATION (NO SIMULATION)\n');
fprintf('=============================================================\n');
fprintf(' case / method : %s / %s\n',string(snapshot.meta.caseName),string(snapshot.meta.methodID));
fprintf(' samples       : %d decision intervals\n',numel(y));
fprintf(' target        : realized frequency stress\n');
fprintf(' CV policy     : 4 contiguous outer blocks + inner tuning\n');
fprintf(' models        : ridge + RBF-KRR (toolbox-free local code)\n');
fprintf(' persistence   : OFF\n');
fprintf(' candidates    : %s\n',strjoin(cellstr(featureNames),', '));
fprintf('=============================================================\n');

foldId = contiguous_folds(numel(y),4);

% ---- Full model ---------------------------------------------------------
[pRFull,mRFull] = blocked_oof_model(X,y,foldId,'ridge');
[pKFull,mKFull] = blocked_oof_model(X,y,foldId,'krr');

fprintf('\nFull five-feature blocked-CV performance:\n');
FullMetrics = table(["Ridge";"RBF-KRR"], ...
    [mRFull.RMSE;mKFull.RMSE],[mRFull.MAE;mKFull.MAE], ...
    [mRFull.R2;mKFull.R2],[mRFull.Corr;mKFull.Corr], ...
    'VariableNames',{'Model','RMSE','MAE','R2','Corr'});
disp(FullMetrics);

% ---- Leave-one-feature-out ---------------------------------------------
nF=numel(featureNames);
partialRho=nan(nF,1);
ridgeRmseWithout=nan(nF,1); krrRmseWithout=nan(nF,1);
ridgeRmsePenalty=nan(nF,1); krrRmsePenalty=nan(nF,1);
ridgeMaePenalty=nan(nF,1); krrMaePenalty=nan(nF,1);
for i=1:nF
    keep=setdiff(1:nF,i,'stable');
    [~,mR]=blocked_oof_model(X(:,keep),y,foldId,'ridge');
    [~,mK]=blocked_oof_model(X(:,keep),y,foldId,'krr');
    ridgeRmseWithout(i)=mR.RMSE; krrRmseWithout(i)=mK.RMSE;
    ridgeRmsePenalty(i)=100*(mR.RMSE-mRFull.RMSE)/max(mRFull.RMSE,eps);
    krrRmsePenalty(i)=100*(mK.RMSE-mKFull.RMSE)/max(mKFull.RMSE,eps);
    ridgeMaePenalty(i)=100*(mR.MAE-mRFull.MAE)/max(mRFull.MAE,eps);
    krrMaePenalty(i)=100*(mK.MAE-mKFull.MAE)/max(mKFull.MAE,eps);
    partialRho(i)=partial_spearman(X(:,i),y,X(:,keep));
end
LOFO=table(featureNames(:),ridgeRmseWithout,krrRmseWithout,ridgeRmsePenalty, ...
    krrRmsePenalty,ridgeMaePenalty,krrMaePenalty,partialRho, ...
    'VariableNames',{'RemovedFeature','Ridge_RMSE_without','KRR_RMSE_without', ...
    'Ridge_RMSE_penalty_pct','KRR_RMSE_penalty_pct', ...
    'Ridge_MAE_penalty_pct','KRR_MAE_penalty_pct','PartialSpearman'});

fprintf('\nLeave-one-feature-out test (positive penalty = feature helps):\n');
disp(LOFO);

% ---- Incremental first-principles build-up -----------------------------
sets = { [1 2], [1 2 4], [1 2 4 3], [1 2 4 3 5] };
setLabels = ["S1: Pnet+ramp","S2: +DG headroom","S3: +PV ramp","S4: +BESS SOC"];
nS=numel(sets);
setFeatureText=strings(nS,1);
ridgeRmse=nan(nS,1); krrRmse=nan(nS,1); ridgeMae=nan(nS,1); krrMae=nan(nS,1);
ridgeInc=nan(nS,1); krrInc=nan(nS,1);
for s=1:nS
    jj=sets{s};
    setFeatureText(s)=strjoin(cellstr(featureNames(jj)),', ');
    [~,mR]=blocked_oof_model(X(:,jj),y,foldId,'ridge');
    [~,mK]=blocked_oof_model(X(:,jj),y,foldId,'krr');
    ridgeRmse(s)=mR.RMSE; krrRmse(s)=mK.RMSE; ridgeMae(s)=mR.MAE; krrMae(s)=mK.MAE;
    if s>1
        ridgeInc(s)=100*(ridgeRmse(s-1)-ridgeRmse(s))/max(ridgeRmse(s-1),eps);
        krrInc(s)=100*(krrRmse(s-1)-krrRmse(s))/max(krrRmse(s-1),eps);
    end
end
Incremental=table(setLabels(:),setFeatureText,ridgeRmse,krrRmse,ridgeMae,krrMae,ridgeInc,krrInc, ...
    'VariableNames',{'Set','Features','Ridge_RMSE','KRR_RMSE','Ridge_MAE','KRR_MAE', ...
    'Ridge_incrementalImprove_pct','KRR_incrementalImprove_pct'});

fprintf('\nIncremental first-principles build-up:\n');
disp(Incremental);

% ---- Redundancy matrix --------------------------------------------------
rhoMat=nan(nF,nF);
for i=1:nF
    for j=1:nF
        rhoMat(i,j)=spearman_safe(X(:,i),X(:,j));
    end
end
Redundancy=array2table(rhoMat,'VariableNames',matlab.lang.makeValidName(cellstr(shortNames)), ...
    'RowNames',cellstr(shortNames));
fprintf('\nPairwise Spearman redundancy among the five candidates:\n');
disp(Redundancy);

% ---- Conservative data-only recommendation -----------------------------
% Do not force-delete first-principles variables just because one one-day
% sample is weak. The recommendation separates data evidence from physics.
Decision=strings(nF,1); Reason=strings(nF,1);
for i=1:nF
    pK=LOFO.KRR_RMSE_penalty_pct(i);
    pR=LOFO.Ridge_RMSE_penalty_pct(i);
    qK=LOFO.KRR_MAE_penalty_pct(i);
    pr=abs(LOFO.PartialSpearman(i));

    if (pK>=5 && qK>=3 && pr>=0.15) || (pK>=3 && pR>=3 && pr>=0.15)
        Decision(i)="KEEP_STRONG";
        Reason(i)=sprintf('Removal worsens CV error materially (KRR RMSE %+0.1f%%, Ridge %+0.1f%%; partial |rho| %.2f).',pK,pR,pr);
    elseif pK<=-3 && pR<=1 && pr<0.10
        Decision(i)="DROP_CANDIDATE";
        Reason(i)=sprintf('Removal improves/non-worsens prediction (KRR RMSE %+0.1f%%, Ridge %+0.1f%%; partial |rho| %.2f).',pK,pR,pr);
    else
        Decision(i)="REVIEW";
        Reason(i)=sprintf('Incremental value is weak/mixed (KRR RMSE %+0.1f%%, Ridge %+0.1f%%; partial |rho| %.2f).',pK,pR,pr);
    end
end

% Physics priority note for the swing-equation core.
PhysicsRole=[ ...
    "Active-power operating point"; ...
    "Net active-power variation"; ...
    "PV-specific variation beyond net ramp"; ...
    "Available SG upward regulation margin"; ...
    "Storage energy availability" ];
Recommendation=table(featureNames(:),PhysicsRole,Decision, ...
    LOFO.KRR_RMSE_penalty_pct,LOFO.Ridge_RMSE_penalty_pct, ...
    LOFO.KRR_MAE_penalty_pct,LOFO.PartialSpearman,Reason, ...
    'VariableNames',{'Feature','PhysicsRole','DataDecision','KRR_RMSE_penalty_pct', ...
    'Ridge_RMSE_penalty_pct','KRR_MAE_penalty_pct','PartialSpearman','Reason'});

fprintf('\n=============================================================\n');
fprintf(' PRELIMINARY FIVE-FEATURE DECISION\n');
fprintf('=============================================================\n');
disp(Recommendation);
fprintf('Interpretation: positive LOFO penalty means removing that feature hurts prediction.\n');
fprintf('This is a one-day stress screen; final alpha* labels should confirm borderline REVIEW items.\n');
fprintf('=============================================================\n\n');

% ---- Plots --------------------------------------------------------------
figure('Name','Five-feature ablation screening');
tiledlayout(2,2,'TileSpacing','compact');

nexttile;
bar(categorical(cellstr(shortNames)), ...
    [LOFO.Ridge_RMSE_penalty_pct LOFO.KRR_RMSE_penalty_pct]);
yline(0,'k--'); grid on; box on;
ylabel('RMSE penalty when removed (%)');
legend('Ridge','RBF-KRR','Location','best');
title('Leave-one-feature-out importance');

nexttile;
bar(categorical(cellstr(setLabels)), ...
    [Incremental.Ridge_RMSE Incremental.KRR_RMSE]);
grid on; box on; ylabel('Blocked-CV RMSE');
legend('Ridge','RBF-KRR','Location','best');
title('Incremental physics feature sets');

nexttile;
imagesc(rhoMat,[-1 1]); axis square; colorbar;
xticks(1:nF); yticks(1:nF); xticklabels(cellstr(shortNames)); yticklabels(cellstr(shortNames));
xtickangle(30); title('Feature redundancy (Spearman)');

nexttile;
plot(t,y,'k','LineWidth',1.2); hold on;
plot(t,pKFull,'LineWidth',1.0); yline(1,'k--');
grid on; box on; xlabel('Time (h)'); ylabel('Frequency stress');
legend('Realized','5-feature KRR OOF','Security boundary','Location','best');
title('Full-core blocked OOF prediction');

report=struct();
report.kind='IslandEMSQuickCoreFeatureAblationV1';
report.featureNames=featureNames;
report.fullMetrics=FullMetrics;
report.LOFO=LOFO;
report.incremental=Incremental;
report.redundancy=Redundancy;
report.recommendation=Recommendation;
report.oof=struct('time_h',t,'target',y,'ridgeFull',pRFull,'krrFull',pKFull,'foldId',foldId);
report.snapshotMeta=snapshot.meta;
end

% ========================================================================
function snapshot=resolve_snapshot(varargin)
snapshot=[];
if nargin>=1 && isstruct(varargin{1})
    x=varargin{1};
    if is_snapshot(x), snapshot=x; return; end
    if is_full_result(x), snapshot=build_feature_screening_snapshot(x); return; end
end
vars={'featureScreenSnapshot','lastSmokeResult','result','base'};
for i=1:numel(vars)
    nm=vars{i};
    if evalin('base',sprintf('exist(''%s'',''var'')',nm))
        x=evalin('base',nm);
        if is_snapshot(x), snapshot=x; return; end
        if is_full_result(x), snapshot=build_feature_screening_snapshot(x); return; end
    end
end
cacheFile=fullfile(tempdir,'IslandEMS_feature_screening_snapshot.mat');
if isfile(cacheFile)
    S=load(cacheFile,'snapshot');
    if isfield(S,'snapshot') && is_snapshot(S.snapshot), snapshot=S.snapshot; end
end
end
function tf=is_snapshot(x)
tf=isstruct(x)&&isfield(x,'kind')&&strcmp(string(x.kind),'IslandEMSFeatureScreenSnapshotV1')&&isfield(x,'features')&&isfield(x,'target');
end
function tf=is_full_result(r)
tf=isstruct(r)&&isfield(r,'meta')&&isfield(r,'cfgSnapshot')&&isfield(r,'freq_Hz')&&isfield(r,'P_DG_MW')&&isfield(r,'totalLoad_MW');
end
function f=contiguous_folds(n,K)
f=ceil((1:n)'*K/n); f(f<1)=1; f(f>K)=K;
end
function [oof,m]=blocked_oof_model(X,y,foldId,type)
n=numel(y); oof=nan(n,1); K=max(foldId);
for k=1:K
    te=(foldId==k); tr=~te;
    param=tune_inner(X(tr,:),y(tr),type);
    oof(te)=fit_predict(X(tr,:),y(tr),X(te,:),type,param);
end
m=metrics(y,oof);
end
function param=tune_inner(X,y,type)
n=size(X,1); fid=contiguous_folds(n,min(3,n));
if strcmp(type,'ridge')
    grid=logspace(-4,1,6); loss=inf(numel(grid),1);
    for q=1:numel(grid)
        pred=nan(n,1);
        for k=1:max(fid)
            te=fid==k; tr=~te;
            if sum(tr)<8 || sum(te)<1, continue; end
            pred(te)=fit_predict(X(tr,:),y(tr),X(te,:),'ridge',grid(q));
        end
        loss(q)=rmse_safe(y,pred);
    end
    [~,i]=min(loss); param=grid(i);
else
    lambdas=[1e-4 1e-3 1e-2 1e-1]; scales=[0.5 1 2];
    best=inf; param=[1e-2 1];
    for a=1:numel(lambdas)
        for b=1:numel(scales)
            pred=nan(n,1);
            for k=1:max(fid)
                te=fid==k; tr=~te;
                if sum(tr)<8 || sum(te)<1, continue; end
                pred(te)=fit_predict(X(tr,:),y(tr),X(te,:),'krr',[lambdas(a) scales(b)]);
            end
            L=rmse_safe(y,pred);
            if L<best, best=L; param=[lambdas(a) scales(b)]; end
        end
    end
end
end
function pred=fit_predict(Xtr,ytr,Xte,type,param)
mu=mean(Xtr,1); sd=std(Xtr,0,1); sd(sd<1e-10)=1;
Ztr=(Xtr-mu)./sd; Zte=(Xte-mu)./sd;
if strcmp(type,'ridge')
    A=[ones(size(Ztr,1),1) Ztr]; B=[ones(size(Zte,1),1) Zte];
    P=eye(size(A,2)); P(1,1)=0;
    beta=(A'*A+param*P)\(A'*ytr);
    pred=B*beta;
else
    lambda=param(1); scale=param(2);
    D2=dist2(Ztr,Ztr); v=sqrt(D2(triu(true(size(D2)),1))); v=v(isfinite(v)&v>0);
    if isempty(v), sig=1; else, sig=median(v); end
    sig=max(sig*scale,1e-6); gamma=1/(2*sig^2);
    K=exp(-gamma*D2);
    beta=(K+lambda*eye(size(K)))\ytr;
    pred=exp(-gamma*dist2(Zte,Ztr))*beta;
end
end
function D2=dist2(A,B)
D2=sum(A.^2,2)+sum(B.^2,2)'-2*(A*B'); D2=max(D2,0);
end
function m=metrics(y,p)
mask=isfinite(y)&isfinite(p); y=y(mask); p=p(mask); e=y-p;
m=struct(); m.RMSE=sqrt(mean(e.^2)); m.MAE=mean(abs(e));
den=sum((y-mean(y)).^2); if den>0, m.R2=1-sum(e.^2)/den; else, m.R2=NaN; end
m.Corr=pearson_safe(y,p);
end
function r=rmse_safe(y,p)
mask=isfinite(y)&isfinite(p); if sum(mask)<3, r=inf; else, r=sqrt(mean((y(mask)-p(mask)).^2)); end
end
function r=partial_spearman(x,y,Z)
% Rank-transform then partial out all remaining features with ridge-free OLS.
x=rank_average(x(:)); y=rank_average(y(:));
ZR=zeros(size(Z)); for j=1:size(Z,2), ZR(:,j)=rank_average(Z(:,j)); end
A=[ones(size(ZR,1),1) ZR];
rx=x-A*(A\x); ry=y-A*(A\y); r=pearson_safe(rx,ry);
end
function r=spearman_safe(x,y)
x=x(:); y=y(:); m=isfinite(x)&isfinite(y); x=x(m); y=y(m);
if numel(x)<4 || std(x)==0 || std(y)==0, r=NaN; return; end
r=pearson_safe(rank_average(x),rank_average(y));
end
function r=pearson_safe(x,y)
x=x(:); y=y(:); m=isfinite(x)&isfinite(y); x=x(m); y=y(m);
if numel(x)<4 || std(x)==0 || std(y)==0, r=NaN; return; end
x=x-mean(x); y=y-mean(y); r=sum(x.*y)/sqrt(sum(x.^2)*sum(y.^2));
end
function r=rank_average(x)
[sorted,ord]=sort(x); n=numel(x); rs=zeros(n,1); i=1;
while i<=n
    j=i; while j<n && sorted(j+1)==sorted(i), j=j+1; end
    rs(ord(i:j))=(i+j)/2; i=j+1;
end
r=rs;
end
