%% diagnose_F1_seed1_physical_envelope_forensics_18bus.m
% NO-SIMULATION forensic test for the F1 seed-1 failure.
%
% Required in base workspace:
%   F1_seed1_result
% Optional:
%   S3_seed_robustness_results.seed_001
%
% Main purpose:
%   - inspect F1 unsafe steps 28,29,59,60;
%   - compare actual net-load excursions with the implemented alpha=1 reserve;
%   - compare F1/S3 history where both may have the same current alpha;
%   - inspect the reserve-sizing source code.
%
% No MPC solve. No physical simulation. Expected runtime: a few seconds.

clc;

assert(evalin('base','exist(''F1_seed1_result'',''var'')==1'), ...
    'F1_seed1_result is not available in the base workspace.');

F1 = evalin('base','F1_seed1_result');

haveS3 = evalin('base', ...
    ['exist(''S3_seed_robustness_results'',''var'')==1 && ', ...
     'isstruct(S3_seed_robustness_results) && ', ...
     'isfield(S3_seed_robustness_results,''seed_001'')']);

if haveS3
    R = evalin('base','S3_seed_robustness_results');
    S3 = R.seed_001;
else
    S3 = [];
end

projectRoot = pwd;
addpath(genpath(projectRoot));
rehash;
cfg = config_island_ems();

TF1 = make_table_local(F1,cfg,"F1");
if haveS3
    TS3 = make_table_local(S3,cfg,"S3");
else
    TS3 = table();
end

fprintf('\n=============================================================\n');
fprintf(' F1 SEED-1 PHYSICAL-ENVELOPE FORENSICS -- NO SIMULATION\n');
fprintf('=============================================================\n');
fprintf('S3 seed-1 available: %d\n',haveS3);

fprintf('\n=============================================================\n');
fprintf(' A. F1 UNSAFE INTERVALS\n');
fprintf('=============================================================\n');
disp(TF1(TF1.CoIUnsafe,:));

fprintf('\n=============================================================\n');
fprintf(' B. F1 MORNING HISTORY -- STEPS 24:31\n');
fprintf('=============================================================\n');
disp(TF1(ismember(TF1.MPCStep,24:31),:));

fprintf('\n=============================================================\n');
fprintf(' C. F1 MIDDAY HISTORY -- STEPS 55:63\n');
fprintf('=============================================================\n');
disp(TF1(ismember(TF1.MPCStep,55:63),:));

if haveS3
    fprintf('\n=============================================================\n');
    fprintf(' D1. F1 vs S3 MORNING -- STEPS 24:31\n');
    fprintf('=============================================================\n');
    disp(compare_local(TF1,TS3,24:31));

    fprintf('\n=============================================================\n');
    fprintf(' D2. F1 vs S3 MIDDAY -- STEPS 55:63\n');
    fprintf('=============================================================\n');
    disp(compare_local(TF1,TS3,55:63));

    fprintf('\n=============================================================\n');
    fprintf(' D3. F1 vs S3 LATE DAY -- STEPS 85:91\n');
    fprintf('=============================================================\n');
    disp(compare_local(TF1,TS3,85:91));
end

fprintf('\n=============================================================\n');
fprintf(' E. AUTOMATIC FORENSIC FLAGS FOR F1 UNSAFE STEPS\n');
fprintf('=============================================================\n');

badSteps = TF1.MPCStep(TF1.CoIUnsafe).';

for k = badSteps
    r = TF1(TF1.MPCStep==k,:);

    fprintf('\nStep %d (%.2f h)\n',k,r.StartTime_h);
    fprintf('  reserve                   = %.6f MW (%.4f pu of DG rating)\n', ...
        r.AggregateReserve_MW,r.AggregateReserve_puDG);
    fprintf('  DG upward headroom        = %.6f pu\n',r.DGUpHeadroom_pu);
    fprintf('  forecast |net-load ramp|  = %.6f pu\n',r.ForecastAbsNetRamp_pu);
    fprintf('  actual net-load change    = %+0.6f MW\n',r.NetLoadChange_MW);
    fprintf('  max net-load excursion    = %.6f MW\n',r.MaxNetLoadExcursion_MW);
    fprintf('  boundary net-load jump    = %+0.6f MW\n',r.BoundaryNetLoadJump_MW);
    fprintf('  excursion/reserve         = %.4f\n',r.ExcursionToReserve);
    fprintf('  boundary-jump/reserve     = %.4f\n',r.BoundaryJumpToReserve);
    fprintf('  max recorded imbalance    = %.6f MW\n',r.MaxRecordedImbalance_MW);
    fprintf('  max|df| / max|RoCoF|      = %.6f / %.6f\n', ...
        r.MaxAbsDf_Hz,r.MaxAbsRoCoF_Hz_s);

    if isfinite(r.ExcursionToReserve) && r.ExcursionToReserve>1
        fprintf('  FLAG: actual net-load excursion exceeds scheduled alpha=1 reserve.\n');
    end
    if isfinite(r.BoundaryJumpToReserve) && r.BoundaryJumpToReserve>1
        fprintf('  FLAG: boundary net-load jump exceeds scheduled alpha=1 reserve.\n');
    end
    if r.MaxAbsRoCoF_Hz_s>cfg.frequency.securityRoCoF_Hz_s
        fprintf('  FLAG: RoCoF security limit is violated.\n');
    end
    if r.MaxAbsDf_Hz>cfg.frequency.securityDeviation_Hz
        fprintf('  FLAG: frequency-deviation security limit is violated.\n');
    end
end

if haveS3
    fprintf('\n=============================================================\n');
    fprintf(' F. SAME-CURRENT-ALPHA / DIFFERENT-STRESS CHECK\n');
    fprintf('=============================================================\n');

    C = compare_local(TF1,TS3,1:height(TF1));
    same = abs(C.F1_Alpha-C.S3_Alpha)<1e-12;
    different = abs(C.F1_Stress-C.S3_Stress)>0.15;
    disp(C(same & different,:));

    fprintf(['Large differences with the same current alpha support the ', ...
        'history/dispatch dependence hypothesis.\n']);

    fprintf('\nS3 Step 89 physical counterpart:\n');
    disp(TS3(TS3.MPCStep==89,:));
end

fprintf('\n=============================================================\n');
fprintf(' G. RESERVE-SIZING SOURCE AUDIT\n');
fprintf('=============================================================\n');

reserveFile = which('compute_frequency_reserve_pu');
if isempty(reserveFile)
    reserveFile = fullfile(projectRoot,'ai','compute_frequency_reserve_pu.m');
end

if exist(reserveFile,'file')==2
    print_source_local(reserveFile,180);
else
    fprintf('<compute_frequency_reserve_pu.m not found>\n');
end

fprintf('\n=============================================================\n');
fprintf(' H. CONCISE EVENT TABLE\n');
fprintf('=============================================================\n');

wanted = {'MPCStep','StartTime_h','Alpha', ...
    'AggregateReserve_MW','AggregateReserve_puDG', ...
    'DGUpHeadroom_pu','ForecastAbsNetRamp_pu', ...
    'NetLoadChange_MW','MaxNetLoadExcursion_MW', ...
    'BoundaryNetLoadJump_MW','ExcursionToReserve', ...
    'MaxRecordedImbalance_MW', ...
    'MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s','SecurityStress','CoIUnsafe'};

disp(TF1(ismember(TF1.MPCStep,[28 29 59 60]),wanted));

assignin('base','F1_seed1_physical_forensics',TF1);
if haveS3
    assignin('base','S3_seed1_physical_forensics',TS3);
end

fprintf('\nPlease send Sections A, D1, D2, E, F, G, and H.\n');


%% ========================================================================
% Local functions
% =========================================================================

function T = make_table_local(result,cfg,label)

n = numel(result.interval.maxAbsFreqDev_Hz);
step = (1:n).';
time_h = (step-1)*cfg.mpc.decisionInterval_h;

df = double(result.interval.maxAbsFreqDev_Hz(:));
roc = double(result.interval.maxAbsRoCoF_Hz_s(:));
stress = max(df/cfg.frequency.securityDeviation_Hz, ...
             roc/cfg.frequency.securityRoCoF_Hz_s);
unsafe = stress>1+1e-12;

alpha = nan(n,1);
if isfield(result,'reserve') && isfield(result.reserve,'ratio')
    alpha = fit_n_local(result.reserve.ratio,n);
end

forecastRamp = nan(n,1);
headroom = nan(n,1);
if isfield(result,'reserve') && isfield(result.reserve,'features')
    X = double(result.reserve.features);
    if size(X,1)==n && size(X,2)>=3
        forecastRamp = X(:,2);
        headroom = X(:,3);
    end
end

reserveMW = nan(n,1);
reservePuDG = nan(n,1);

rating = [];
if isfield(result,'DG_rating_MW')
    rating = double(result.DG_rating_MW(:));
end

if isfield(result,'reserve') && isfield(result.reserve,'metaHistory')
    H = result.reserve.metaHistory;
    for k=1:min(n,numel(H))
        m = H{k};
        if isstruct(m) && isfield(m,'reservePu')
            rp = double(m.reservePu(:));
            if ~isempty(rating) && numel(rp)==numel(rating)
                reserveMW(k) = sum(rp.*rating,'omitnan');
                reservePuDG(k) = reserveMW(k)/max(sum(rating),eps);
            else
                reservePuDG(k) = mean(rp,'omitnan');
            end
        end
    end
end

loadTS = signal_local(result,'totalLoad_MW');
pvTS   = signal_local(result,'totalPV_MW');
if isempty(pvTS), pvTS = signal_local(result,'P_PV_MW'); end
genTS  = signal_local(result,'totalGeneration_MW');

netTS = binary_local(loadTS,pvTS,@minus);
imbTS = binary_local(loadTS,genTS,@minus);

netChange = nan(n,1);
netExc = nan(n,1);
boundaryJump = nan(n,1);
maxImb = nan(n,1);

for k=1:n
    seg = segment_local(netTS,n,k);
    if ~isempty(seg) && any(isfinite(seg))
        z = seg(isfinite(seg));
        netChange(k) = z(end)-z(1);
        netExc(k) = max(abs(z-z(1)));
    end

    if k>1 && ~isempty(netTS)
        a = segment_local(netTS,n,k-1);
        b = segment_local(netTS,n,k);
        a = a(isfinite(a)); b = b(isfinite(b));
        if ~isempty(a) && ~isempty(b)
            boundaryJump(k) = b(1)-a(end);
        end
    end

    segI = segment_local(imbTS,n,k);
    if ~isempty(segI) && any(isfinite(segI))
        maxImb(k) = max(abs(segI),[],'omitnan');
    end
end

excRatio = netExc./max(reserveMW,eps);
jumpRatio = abs(boundaryJump)./max(reserveMW,eps);

T = table( ...
    repmat(string(label),n,1),step,time_h,alpha, ...
    reserveMW,reservePuDG,headroom,forecastRamp, ...
    netChange,netExc,boundaryJump,excRatio,jumpRatio,maxImb, ...
    df,roc,stress,unsafe, ...
    'VariableNames',{ ...
    'Method','MPCStep','StartTime_h','Alpha', ...
    'AggregateReserve_MW','AggregateReserve_puDG', ...
    'DGUpHeadroom_pu','ForecastAbsNetRamp_pu', ...
    'NetLoadChange_MW','MaxNetLoadExcursion_MW', ...
    'BoundaryNetLoadJump_MW','ExcursionToReserve', ...
    'BoundaryJumpToReserve','MaxRecordedImbalance_MW', ...
    'MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s','SecurityStress','CoIUnsafe'});
end


function y = signal_local(result,name)
y = [];
if ~isfield(result,name), return; end
x = double(result.(name));
if isempty(x), return; end
if isvector(x)
    y = x(:);
else
    [~,td] = max(size(x));
    if td==2
        y = sum(x,1,'omitnan').';
    else
        y = sum(x,2,'omitnan');
    end
end
end


function y = binary_local(a,b,fun)
y = [];
if isempty(a) || isempty(b), return; end
m = min(numel(a),numel(b));
y = fun(a(1:m),b(1:m));
end


function seg = segment_local(x,n,k)
seg = [];
if isempty(x), return; end
x = x(:);
N = numel(x);
i1 = floor((k-1)*N/n)+1;
i2 = floor(k*N/n);
i1 = min(max(i1,1),N);
i2 = min(max(i2,i1),N);
seg = x(i1:i2);
end


function y = fit_n_local(x,n)
x = double(x(:));
y = nan(n,1);
m = min(n,numel(x));
y(1:m) = x(1:m);
end


function C = compare_local(A,B,steps)
A = A(ismember(A.MPCStep,steps),:);
B = B(ismember(B.MPCStep,steps),:);
common = intersect(A.MPCStep,B.MPCStep,'stable');
A = A(ismember(A.MPCStep,common),:);
B = B(ismember(B.MPCStep,common),:);
[~,ia] = ismember(common,A.MPCStep);
[~,ib] = ismember(common,B.MPCStep);
A=A(ia,:); B=B(ib,:);

C = table();
C.MPCStep = common;
C.StartTime_h = A.StartTime_h;
C.F1_Alpha = A.Alpha;
C.S3_Alpha = B.Alpha;
C.F1_Reserve_MW = A.AggregateReserve_MW;
C.S3_Reserve_MW = B.AggregateReserve_MW;
C.F1_Headroom_pu = A.DGUpHeadroom_pu;
C.S3_Headroom_pu = B.DGUpHeadroom_pu;
C.F1_NetExcursion_MW = A.MaxNetLoadExcursion_MW;
C.S3_NetExcursion_MW = B.MaxNetLoadExcursion_MW;
C.F1_Df = A.MaxAbsDf_Hz;
C.S3_Df = B.MaxAbsDf_Hz;
C.F1_RoCoF = A.MaxAbsRoCoF_Hz_s;
C.S3_RoCoF = B.MaxAbsRoCoF_Hz_s;
C.F1_Stress = A.SecurityStress;
C.S3_Stress = B.SecurityStress;
C.F1_Unsafe = A.CoIUnsafe;
C.S3_Unsafe = B.CoIUnsafe;
end


function print_source_local(filePath,maxLines)
fprintf('File: %s\n\n',filePath);
lines = splitlines(string(fileread(filePath)));
m = min(numel(lines),maxLines);
for k=1:m
    fprintf('%4d | %s\n',k,lines(k));
end
if numel(lines)>m
    fprintf('... (%d additional lines not printed)\n',numel(lines)-m);
end
end
