%% smoke_P1_S3_two_branch_shield_closed_loop_18bus.m
% Exact P1-only closed-loop test for S3:
%
%   KRR WITHOUT global calibration
%       +
%   two-branch forecast-aware safety shield
%
% Branch A:
%   netDrop >= 0.02 AND netLoadNow >= 0.60
%
% Branch B:
%   netDrop >= 0.10 regardless of netLoadNow
%
% If either branch is true and KRR alpha < 1:
%   alpha_final = 1
%
% Scope:
%   18bus
%   decay = 1.00
%   P1 only
%   saveResults = false
%
% This is a mechanism test.  Thresholds are not yet final paper constants.

clear;
clc;
close all force;

%% Experimental parameters
DROP_THRESHOLD_PU = 0.02;
NETLOAD_MIN_PU = 0.60;
SEVERE_DROP_THRESHOLD_PU = 0.10;
SHIELD_ALPHA = 1.00;

%% Setup
projectRoot=pwd;
addpath(genpath(projectRoot));
rehash;

cfg=config_island_ems();

% Verify prior engine hook + S3 selector patch.
engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');
predFile=which('predict_reserve_ratio');

assert(exist(engineFile,'file')==2 && ...
    contains(fileread(engineFile),'P1_FORECAST_SAFETY_SHIELD_EXPERIMENTAL'), ...
    'Forecast-shield engine hook is not active.');

assert(~isempty(predFile) && ...
    contains(fileread(predFile),'forecastSafetyShieldSevereBranch'), ...
    ['S3 two-branch predict_reserve_ratio.m is not active. Run ', ...
     'apply_P1_S3_two_branch_shield_patch first.']);

%% Fixed Part-I scope
caseName='18bus';
decayRatio=1.00;
seed=0;

cfg.output.saveResults=false;
cfg.output.showFigures=false;

cfg.ai.enableForecastSafetyShield=true;
cfg.ai.forecastSafetyShieldDropThreshold_pu=DROP_THRESHOLD_PU;
cfg.ai.forecastSafetyShieldNetLoadMin_pu=NETLOAD_MIN_PU;
cfg.ai.forecastSafetyShieldSevereDropEnabled=true;
cfg.ai.forecastSafetyShieldSevereDropThreshold_pu=SEVERE_DROP_THRESHOLD_PU;
cfg.ai.forecastSafetyShieldAlpha=SHIELD_ALPHA;

catalog=paper_method_catalog();
ids=string({catalog.id});
idxP1=find(ids=="P1",1);
assert(~isempty(idxP1),'P1 not found in paper_method_catalog().');

runCfg=catalog(idxP1);
runCfg.caseName=caseName;
runCfg.dayType=cfg.scenario.dayType;
runCfg.decayRatio=decayRatio;
runCfg.randomSeed=seed;

% S3 explicitly removes calibration.
runCfg.aiSafetyCalibration=false;

%% Saved references
formalRunTag='20260907_115951';
formalRoot=fullfile(projectRoot,cfg.output.root,formalRunTag);

refF1=load_reference_local(formalRoot,'T7',caseName,decayRatio,seed);
refP1=load_reference_local(formalRoot,'P1',caseName,decayRatio,seed);

fprintf('\n=============================================================\n');
fprintf(' EXACT P1 S3 TWO-BRANCH SHIELD CLOSED-LOOP SMOKE\n');
fprintf('=============================================================\n');
fprintf('case                 : %s\n',caseName);
fprintf('decayRatio           : %.2f\n',decayRatio);
fprintf('calibration          : 0\n');
fprintf('moderate drop thr    : %.4f pu\n',DROP_THRESHOLD_PU);
fprintf('moderate netload min : %.4f pu\n',NETLOAD_MIN_PU);
fprintf('severe drop thr      : %.4f pu\n',SEVERE_DROP_THRESHOLD_PU);
fprintf('shield alpha         : %.4f\n',SHIELD_ALPHA);
fprintf('save results         : 0\n');
fprintf('=============================================================\n');

fprintf('\nSaved references:\n');
print_reference_local('F1 saved',refF1,cfg);
print_reference_local('P1 saved',refP1,cfg);

%% Exact closed loop
fprintf('\n=============================================================\n');
fprintf(' RUNNING S3\n');
fprintf('=============================================================\n');

result=run_single_experiment(cfg,runCfg,projectRoot,'',false);

%% Metrics
df=double(result.interval.maxAbsFreqDev_Hz(:));
rocof=double(result.interval.maxAbsRoCoF_Hz_s(:));

dfLim=cfg.frequency.securityDeviation_Hz;
rLim=cfg.frequency.securityRoCoF_Hz_s;

stress=max(df/dfLim,rocof/rLim);
unsafe=stress>1+1e-12;

alpha=double(result.reserve.ratio(:));
n=numel(alpha);
step=(1:n).';
time_h=(step-1)*cfg.mpc.decisionInterval_h;

preAlpha=nan(n,1);
shieldTrig=false(n,1);
moderateTrig=false(n,1);
severeTrig=false(n,1);
forecastNet=nan(n,1);
forecastRamp=nan(n,1);
forecastDrop=nan(n,1);

H=result.reserve.metaHistory;

for k=1:min(n,numel(H))
    m=H{k};
    if ~isstruct(m) || ~isfield(m,'prediction') || ~isstruct(m.prediction)
        continue;
    end
    q=m.prediction;

    preAlpha(k)=get_scalar_local(q,'preShieldAlpha',NaN);
    shieldTrig(k)=get_logical_local(q,'forecastSafetyShieldTriggered',false);
    moderateTrig(k)=get_logical_local(q,'forecastSafetyShieldModerateBranch',false);
    severeTrig(k)=get_logical_local(q,'forecastSafetyShieldSevereBranch',false);
    forecastNet(k)=get_scalar_local(q,'forecastNetLoadNow_pu',NaN);
    forecastRamp(k)=get_scalar_local(q,'forecastSignedNetRamp_pu',NaN);
    forecastDrop(k)=get_scalar_local(q,'forecastNetDrop_pu',NaN);
end

summaryT=table();
summaryT.Variant="S3";
summaryT.CalibrationEnabled=false;
summaryT.TotalCost=double(result.totalCost);
summaryT.MeanAlpha=mean(alpha,'omitnan');
summaryT.MinAlpha=min(alpha);
summaryT.MaxAlpha=max(alpha);
summaryT.MaxAbsDf_Hz=max(df);
summaryT.MaxAbsRoCoF_Hz_s=max(rocof);
summaryT.MaxSecurityStress=max(stress);
summaryT.CoIUnsafeCount=nnz(unsafe);
summaryT.CoIUnsafeRate=mean(unsafe);
summaryT.ShieldTriggerCount=nnz(shieldTrig);
summaryT.ModerateBranchCount=nnz(moderateTrig);
summaryT.SevereBranchCount=nnz(severeTrig);
summaryT.SevereOnlyCount=nnz(severeTrig & ~moderateTrig);
summaryT.MeanPreShieldAlpha=mean(preAlpha,'omitnan');
summaryT.MeanFinalAlpha=mean(alpha,'omitnan');
summaryT.MeanShieldAlphaIncrease=mean(alpha-preAlpha,'omitnan');

fprintf('\nS3 result:\n');
disp(summaryT);

%% Trigger table
triggerIdx=find(shieldTrig);

triggerT=table( ...
    step(triggerIdx),time_h(triggerIdx), ...
    preAlpha(triggerIdx),alpha(triggerIdx), ...
    moderateTrig(triggerIdx),severeTrig(triggerIdx), ...
    forecastNet(triggerIdx),forecastRamp(triggerIdx),forecastDrop(triggerIdx), ...
    df(triggerIdx),rocof(triggerIdx),stress(triggerIdx),unsafe(triggerIdx), ...
    'VariableNames',{ ...
    'MPCStep','StartTime_h','PreShieldAlpha','FinalAlpha', ...
    'ModerateBranch','SevereBranch', ...
    'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu','ForecastNetDrop_pu', ...
    'MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s','SecurityStress','CoIUnsafe'});

fprintf('\nS3 shield trigger intervals:\n');
if isempty(triggerT)
    fprintf('  NONE\n');
else
    disp(triggerT);
end

%% Severe-only interventions
idx=find(severeTrig & ~moderateTrig);

fprintf('\nS3 severe-branch-only intervals:\n');
if isempty(idx)
    fprintf('  NONE\n');
else
    severeOnlyT=table( ...
        step(idx),time_h(idx),preAlpha(idx),alpha(idx), ...
        forecastNet(idx),forecastRamp(idx),forecastDrop(idx), ...
        df(idx),rocof(idx),stress(idx), ...
        'VariableNames',{ ...
        'MPCStep','StartTime_h','PreShieldAlpha','FinalAlpha', ...
        'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu','ForecastNetDrop_pu', ...
        'MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s','SecurityStress'});
    disp(severeOnlyT);
end

%% Unsafe
idx=find(unsafe);

fprintf('\nS3 remaining CoI-unsafe intervals:\n');
if isempty(idx)
    fprintf('  NONE\n');
else
    unsafeT=table( ...
        step(idx),time_h(idx),alpha(idx),shieldTrig(idx), ...
        moderateTrig(idx),severeTrig(idx), ...
        forecastNet(idx),forecastRamp(idx),forecastDrop(idx), ...
        df(idx),rocof(idx),stress(idx), ...
        'VariableNames',{ ...
        'MPCStep','StartTime_h','FinalAlpha','ShieldTriggered', ...
        'ModerateBranch','SevereBranch', ...
        'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu','ForecastNetDrop_pu', ...
        'MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s','SecurityStress'});
    disp(unsafeT);
end

%% Reference comparison
fprintf('\n=============================================================\n');
fprintf(' COMPARISON AGAINST SAVED F1 / ORIGINAL P1\n');
fprintf('=============================================================\n');

fprintf('F1 cost        : %.6f\n',double(refF1.totalCost));
fprintf('S3 cost        : %.6f\n',double(result.totalCost));
fprintf('Original P1    : %.6f\n',double(refP1.totalCost));

fprintf('F1 mean alpha  : %.6f\n',mean(double(refF1.reserve.ratio(:)),'omitnan'));
fprintf('S3 mean alpha  : %.6f\n',mean(alpha,'omitnan'));
fprintf('Old P1 alpha   : %.6f\n',mean(double(refP1.reserve.ratio(:)),'omitnan'));

fprintf('S3 reserve reduction vs F1: %.3f %%\n', ...
    100*(1-mean(alpha,'omitnan')));

fprintf('S3 cost change vs F1      : %.3f %%\n', ...
    100*(double(result.totalCost)-double(refF1.totalCost))/double(refF1.totalCost));

fprintf('\n=============================================================\n');
if nnz(unsafe)==0
    fprintf(' >>> S3 COI FREQUENCY SAFETY: PASS <<<\n');
    fprintf(['If mean alpha/cost are comparable to or better than S1, this is ', ...
        'evidence that the two-branch forecast shield may replace the ', ...
        'global calibration in this 18-bus normal-case mechanism test.\n']);
else
    fprintf(' >>> S3 COI FREQUENCY SAFETY: FAIL <<<\n');
    fprintf(['Do not tune calibration yet. Inspect the remaining unsafe state ', ...
        'and decide whether S1 should remain the preferred architecture.\n']);
end
fprintf('=============================================================\n');

assignin('base','S3_result',result);
assignin('base','S3_summary',summaryT);

fprintf('\nExported to base workspace:\n');
fprintf('  S3_result\n');
fprintf('  S3_summary\n');


%% =========================================================================
% Local helpers
% =========================================================================

function result=load_reference_local(formalRoot,methodID,caseName,decayRatio,seed)
methodDir=fullfile(formalRoot,methodID);
decayCode=round(100*decayRatio);
pattern=sprintf('%s_*_decay%03d_seed%03d_*.mat',caseName,decayCode,seed);
hits=dir(fullfile(methodDir,pattern));
assert(numel(hits)==1,'Expected one saved %s reference; found %d.',methodID,numel(hits));

S=load(fullfile(hits(1).folder,hits(1).name));
if isfield(S,'result')
    result=S.result;
    return;
end

names=fieldnames(S);
for k=1:numel(names)
    if isstruct(S.(names{k}))
        result=S.(names{k});
        return;
    end
end
error('Could not identify saved result struct.');
end


function print_reference_local(label,result,cfg)
df=double(result.interval.maxAbsFreqDev_Hz(:));
r=double(result.interval.maxAbsRoCoF_Hz_s(:));
unsafe=df>cfg.frequency.securityDeviation_Hz+1e-12 | ...
       r>cfg.frequency.securityRoCoF_Hz_s+1e-12;

fprintf(['  %-10s cost=%9.4f | mean alpha=%.6f | max|df|=%.6f | ', ...
    'max|RoCoF|=%.6f | unsafe=%d\n'], ...
    label,double(result.totalCost), ...
    mean(double(result.reserve.ratio(:)),'omitnan'), ...
    max(df),max(r),nnz(unsafe));
end


function v=get_scalar_local(s,name,defaultValue)
v=defaultValue;
if isstruct(s) && isfield(s,name)
    x=s.(name);
    if isnumeric(x) && isscalar(x)
        v=double(x);
    end
end
end


function v=get_logical_local(s,name,defaultValue)
v=logical(defaultValue);
if isstruct(s) && isfield(s,name)
    x=s.(name);
    if (islogical(x) || isnumeric(x)) && isscalar(x)
        v=logical(x);
    end
end
end
