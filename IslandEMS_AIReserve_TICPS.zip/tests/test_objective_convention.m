%% Static regression test for revised economic-objective convention
projectRoot=fileparts(fileparts(mfilename('fullpath')));
engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');
txt=fileread(engineFile);

% These legacy patterns would reintroduce duplicate monetary charging of
% physical network/battery losses. The physical balances must carry losses;
% the objective charges actual DG energy once plus degradation/curtailment.
forbidden={ ...
    'C_dieselG*dt_pre*r_line', ...
    'C_dieselG*(1-inta_batt_ch)', ...
    'C_dieselG*(1-inta_batt_dis)'};
for k=1:numel(forbidden)
    assert(~contains(txt,forbidden{k}), ...
        'Legacy loss double-counting pattern reappeared: %s',forbidden{k});
end
assert(contains(txt,'1000*[DG_GFM_coefBox'), ...
    'MW-to-kWh conversion factor is missing from optimization objective assembly.');
assert(contains(txt,'CostRecord(1,RealStep)=(C_dieselG*sum(P_DG'), ...
    'Running-cost recorder no longer follows the corrected DG-generation convention.');
fprintf('Economic-objective source audit passed.\n');
