%% smoke_P1_step31_forensics_18bus.m
% Focused NO-SIMULATION forensic test for the current P1 Part-I failure.
%
% Scope:
%   18bus, decayRatio = 1.00, seed = 0
%   Methods: F1(T7), G1, P1U, P1
%   Window: MPC steps 27:35
%   Critical steps from previous smoke: 31 and 32
%
% Purpose:
%   Compare selected alpha, AI stress signals, frozen AI features,
%   OOD/fallback flags, and realized CoI frequency response around the
%   unsafe interval.
%
% IMPORTANT:
%   This script does NOT run MPC or physical simulation.
%   It only loads existing saved formal MAT results.
%
% Native RoCoF:
%   By default, this script does NOT reconstruct RoCoF with gradient(freq)
%   because the previous smoke showed that derived replay RoCoF did not match
%   the formal stored summary. Native saved RoCoF is used when available.

clear;
clc;

%% User options
FORMAL_RUN_TAG = '20260907_115951';

WINDOW_STEPS   = 27:35;
CRITICAL_STEPS = [31 32];

EXPORT_CSV = true;
ALLOW_DERIVED_ROCOF = false;

%% Project setup
projectRoot = pwd;
addpath(genpath(projectRoot));
rehash;

cfg = config_island_ems();

caseName   = '18bus';
decayRatio = 1.00;
seed       = 0;

runRoot = fullfile(projectRoot,cfg.output.root,FORMAL_RUN_TAG);
assert(exist(runRoot,'dir')==7, ...
    'Formal run folder not found: %s',runRoot);

fprintf('\n=============================================================\n');
fprintf(' P1 STEP-31/32 FORENSIC SMOKE TEST -- NO SIMULATION\n');
fprintf('=============================================================\n');
fprintf(' case          : %s\n',caseName);
fprintf(' decayRatio    : %.2f (Part-I normal case)\n',decayRatio);
fprintf(' window steps  : %s\n',mat2str(WINDOW_STEPS));
fprintf(' critical      : %s\n',mat2str(CRITICAL_STEPS));
fprintf(' |df| limit    : %.4f Hz\n',cfg.frequency.securityDeviation_Hz);
fprintf(' RoCoF limit   : %.4f Hz/s\n',cfg.frequency.securityRoCoF_Hz_s);
fprintf('=============================================================\n');

%% Methods
internalIDs = ["T7","G1","P1U","P1"];
paperLabels = ["F1","G1","P1U","P1"];

diagByMethod = struct();

for k = 1:numel(internalIDs)

    id    = internalIDs(k);
    label = paperLabels(k);

    filePath = find_one_result_local( ...
        fullfile(runRoot,char(id)),caseName,decayRatio,seed);

    result = load_result_local(filePath);

    key = matlab.lang.makeValidName(char(label));

    fprintf('\n-------------------------------------------------------------\n');
    fprintf(' METHOD %s\n',label);
    fprintf(' file: %s\n',filePath);
    fprintf('-------------------------------------------------------------\n');

    D = build_step_diagnostics_local( ...
        result,cfg,WINDOW_STEPS,ALLOW_DERIVED_ROCOF);

    diagByMethod.(key) = D;

    disp(D.table);

    fprintf('\nResolved signal sources for %s:\n',label);
    print_sources_local(D.sources);

    fprintf('\nFormal summary for %s:\n',label);
    fprintf('  max |df|                  : %.6g Hz\n', ...
        get_summary_local(result,'maxAbsFreqDev_Hz',NaN));
    fprintf('  max |RoCoF|               : %.6g Hz/s\n', ...
        get_summary_local(result,'maxAbsRoCoF_Hz_s',NaN));
    fprintf('  security violation rate   : %.6g\n', ...
        get_summary_local(result,'securityViolationRate',NaN));
    fprintf('  mean alpha                : %.6g\n', ...
        get_summary_local(result,'meanReserveRatio',NaN));
    fprintf('  std alpha                 : %.6g\n', ...
        get_summary_local(result,'stdReserveRatio',NaN));
    fprintf('  OOD fallback rate         : %.6g\n', ...
        get_summary_local(result,'aiOODFallbackRate',NaN));
    fprintf('  no-safe fallback rate     : %.6g\n', ...
        get_summary_local(result,'aiNoSafeCandidateFallbackRate',NaN));
end

%% Critical-step cross-method comparison
criticalTable = table();

for step = CRITICAL_STEPS

    for k = 1:numel(paperLabels)

        label = paperLabels(k);
        key = matlab.lang.makeValidName(char(label));

        T = diagByMethod.(key).table;
        row = T(T.MPCStep==step,:);

        if isempty(row)
            continue;
        end

        one = table();
        one.Method = label;
        one.MPCStep = step;
        one.StartTime_h = row.StartTime_h;

        one.Alpha = row.Alpha;
        one.RawPredStress = row.RawPredStress;
        one.CalibratedPredStress = row.CalibratedPredStress;

        one.NetLoadNow_pu = row.NetLoadNow_pu;
        one.AbsNetLoadRamp_pu = row.AbsNetLoadRamp_pu;
        one.DGUpHeadroom_pu = row.DGUpHeadroom_pu;

        one.OODFlag = row.OODFlag;
        one.NoSafeCandidateFlag = row.NoSafeCandidateFlag;
        one.FallbackFlag = row.FallbackFlag;

        one.RealizedMaxAbsDf_Hz = row.RealizedMaxAbsDf_Hz;
        one.RealizedMaxAbsRoCoF_Hz_s = row.RealizedMaxAbsRoCoF_Hz_s;

        one.FreqViolation = row.FreqViolation;
        one.RoCoFViolation = row.RoCoFViolation;

        if isempty(criticalTable)
            criticalTable = one;
        else
            criticalTable = [criticalTable; one]; %#ok<AGROW>
        end
    end
end

fprintf('\n=============================================================\n');
fprintf(' CRITICAL STEPS 31/32 -- CROSS-METHOD COMPARISON\n');
fprintf('=============================================================\n');
disp(criticalTable);

%% Calibration effectiveness: P1U versus P1
fprintf('\n=============================================================\n');
fprintf(' CALIBRATION EFFECTIVENESS CHECK: P1U vs P1\n');
fprintf('=============================================================\n');

P1U = diagByMethod.P1U.table;
P1  = diagByMethod.P1.table;

for step = CRITICAL_STEPS

    u = P1U(P1U.MPCStep==step,:);
    p = P1(P1.MPCStep==step,:);

    if isempty(u) || isempty(p)
        continue;
    end

    fprintf('\nMPC step %d (%.2f h)\n',step,p.StartTime_h);
    fprintf('  alpha P1U -> P1          : %.6g -> %.6g  (delta = %+g)\n', ...
        u.Alpha,p.Alpha,p.Alpha-u.Alpha);

    fprintf('  raw predicted stress     : P1U %.6g | P1 %.6g\n', ...
        u.RawPredStress,p.RawPredStress);

    fprintf('  calibrated stress        : P1U %.6g | P1 %.6g\n', ...
        u.CalibratedPredStress,p.CalibratedPredStress);

    fprintf('  realized max |df|        : P1U %.6g | P1 %.6g Hz\n', ...
        u.RealizedMaxAbsDf_Hz,p.RealizedMaxAbsDf_Hz);

    fprintf('  OOD flag                 : P1U %g | P1 %g\n', ...
        u.OODFlag,p.OODFlag);

    fprintf('  no-safe-candidate flag   : P1U %g | P1 %g\n', ...
        u.NoSafeCandidateFlag,p.NoSafeCandidateFlag);

    fprintf('  fallback flag            : P1U %g | P1 %g\n', ...
        u.FallbackFlag,p.FallbackFlag);
end

%% F1 versus P1 at the critical steps
fprintf('\n=============================================================\n');
fprintf(' F1 vs P1 AT CRITICAL STEPS\n');
fprintf('=============================================================\n');

F1 = diagByMethod.F1.table;
P1 = diagByMethod.P1.table;

for step = CRITICAL_STEPS

    f = F1(F1.MPCStep==step,:);
    p = P1(P1.MPCStep==step,:);

    if isempty(f) || isempty(p)
        continue;
    end

    fprintf('\nMPC step %d (%.2f h)\n',step,p.StartTime_h);
    fprintf('  alpha                    : F1 %.6g | P1 %.6g\n', ...
        f.Alpha,p.Alpha);
    fprintf('  realized max |df| (Hz)   : F1 %.6g | P1 %.6g\n', ...
        f.RealizedMaxAbsDf_Hz,p.RealizedMaxAbsDf_Hz);
    fprintf('  realized max |RoCoF|     : F1 %.6g | P1 %.6g Hz/s\n', ...
        f.RealizedMaxAbsRoCoF_Hz_s,p.RealizedMaxAbsRoCoF_Hz_s);
end

%% Export
if EXPORT_CSV

    outDir = fullfile(runRoot,'diagnostics','P1_step31_forensics');

    if ~exist(outDir,'dir')
        mkdir(outDir);
    end

    labels = fieldnames(diagByMethod);

    for k = 1:numel(labels)

        label = labels{k};

        writetable( ...
            diagByMethod.(label).table, ...
            fullfile(outDir,sprintf('%s_steps_%02d_%02d.csv', ...
            label,WINDOW_STEPS(1),WINDOW_STEPS(end))));
    end

    writetable(criticalTable, ...
        fullfile(outDir,'critical_steps_31_32_cross_method.csv'));

    fprintf('\nDiagnostics exported to:\n  %s\n',outDir);
end

fprintf('\n=============================================================\n');
fprintf(' INTERPRETATION GUIDE\n');
fprintf('=============================================================\n');
fprintf(['1) If P1 and P1U have the SAME alpha at step 31/32, calibration is\n', ...
         '   ineffective at the actually dangerous state.\n']);
fprintf(['2) If calibrated predicted stress says SAFE but realized |df| > limit,\n', ...
         '   the predictor/certificate is not conservative enough.\n']);
fprintf(['3) If OOD/no-safe flag is active but alpha is still < 1, inspect fallback\n', ...
         '   implementation immediately.\n']);
fprintf(['4) If alpha=1 but the physical response is unsafe, alpha alone cannot\n', ...
         '   guarantee safety and a corrective-action layer is needed.\n']);
fprintf(['5) NaN in raw/calibrated stress/features means that signal was not found\n', ...
         '   under the candidate saved-field names; use the printed source\n', ...
         '   paths to refine the extractor.\n']);
fprintf('=============================================================\n');


%% =========================================================================
% Local functions
% =========================================================================

function D = build_step_diagnostics_local(result,cfg,steps,allowDerivedRoCoF)

nMPC = round(24/cfg.mpc.decisionInterval_h);

% Step-level signals.
[alpha,alphaPath] = find_signal_local(result,{ ...
    'reserve.ratio','reserve.reserveRatio','reserve.alpha', ...
    'reserve.alphaSelected','reserve.selectedAlpha', ...
    'ai.alpha','ai.selectedAlpha','alphaRecord','reserveRatioRecord'}, ...
    {'ratio','reserveRatio','alpha','alphaSelected','selectedAlpha', ...
     'alphaRecord','reserveRatioRecord'});

[rawStress,rawStressPath] = find_signal_local(result,{ ...
    'ai.rawPredictedStress','ai.predictedStressRaw', ...
    'ai.rawStressPrediction','ai.rawStress', ...
    'reserve.rawPredictedStress','reserve.rawStress'}, ...
    {'rawPredictedStress','predictedStressRaw','rawStressPrediction', ...
     'rawStress','predictionRaw'});

[calStress,calStressPath] = find_signal_local(result,{ ...
    'ai.calibratedPredictedStress','ai.predictedStressCalibrated', ...
    'ai.calibratedStress','reserve.calibratedPredictedStress', ...
    'reserve.calibratedStress'}, ...
    {'calibratedPredictedStress','predictedStressCalibrated', ...
     'calibratedStress','safetyCalibratedStress'});

[netLoadNow,netLoadNowPath] = find_signal_local(result,{ ...
    'ai.netLoadNow_pu','reserve.netLoadNow_pu', ...
    'ai.features.netLoadNow_pu'}, ...
    {'netLoadNow_pu'});

[netLoadRamp,netLoadRampPath] = find_signal_local(result,{ ...
    'ai.absNetLoadRamp_pu','reserve.absNetLoadRamp_pu', ...
    'ai.features.absNetLoadRamp_pu'}, ...
    {'absNetLoadRamp_pu'});

[dgHeadroom,dgHeadroomPath] = find_signal_local(result,{ ...
    'ai.dgUpHeadroom_pu','reserve.dgUpHeadroom_pu', ...
    'ai.features.dgUpHeadroom_pu'}, ...
    {'dgUpHeadroom_pu'});

[oodFlag,oodPath] = find_signal_local(result,{ ...
    'ai.oodFlag','reserve.oodFlag','ai.OODFlag'}, ...
    {'oodFlag','OODFlag','isOOD'});

[noSafeFlag,noSafePath] = find_signal_local(result,{ ...
    'ai.noSafeCandidateFlag','reserve.noSafeCandidateFlag'}, ...
    {'noSafeCandidateFlag','noSafeCandidate','noSafeAlphaFlag'});

[fallbackFlag,fallbackPath] = find_signal_local(result,{ ...
    'ai.fallbackFlag','reserve.fallbackFlag'}, ...
    {'fallbackFlag','usedFallback','fallbackUsed'});

% Realized physical frequency.
[freq,freqPath] = find_signal_local(result,{ ...
    'freq_Hz','frequency.freq_Hz','frequency.coi_Hz', ...
    'frequency.coifreq_Hz'}, ...
    {'freq_Hz','coiFrequency_Hz','CoIFrequency_Hz'});

[nativeRoCoF,nativeRoCoFPath] = find_signal_local(result,{ ...
    'rocof_Hz_s','RoCoF_Hz_s','coiRoCoF_Hz_s', ...
    'frequency.rocof_Hz_s','frequency.coiRoCoF_Hz_s'}, ...
    {'rocof_Hz_s','RoCoF_Hz_s','coiRoCoF_Hz_s','CoIRoCoF_Hz_s'});

[tSec,timePath] = find_time_seconds_local(result,numel(freq));
[tRoCoFSec,rocofTimePath] = find_time_seconds_local(result,numel(nativeRoCoF));

if isempty(nativeRoCoF) && allowDerivedRoCoF && ~isempty(freq) && ~isempty(tSec)
    nativeRoCoF = gradient(real(double(freq(:))),tSec);
    nativeRoCoFPath = "DERIVED: gradient(freq,time)";
    tRoCoFSec = tSec;
    rocofTimePath = timePath;
end

% Build requested step window.
MPCStep = steps(:);
StartTime_h = (MPCStep-1)*cfg.mpc.decisionInterval_h;

n = numel(MPCStep);

Alpha = nan(n,1);
RawPredStress = nan(n,1);
CalibratedPredStress = nan(n,1);

NetLoadNow_pu = nan(n,1);
AbsNetLoadRamp_pu = nan(n,1);
DGUpHeadroom_pu = nan(n,1);

OODFlag = nan(n,1);
NoSafeCandidateFlag = nan(n,1);
FallbackFlag = nan(n,1);

RealizedMaxAbsDf_Hz = nan(n,1);
RealizedMaxAbsRoCoF_Hz_s = nan(n,1);

FreqViolation = false(n,1);
RoCoFViolation = false(n,1);

for ii = 1:n

    k = MPCStep(ii);

    Alpha(ii) = step_value_local(alpha,k,nMPC);
    RawPredStress(ii) = step_value_local(rawStress,k,nMPC);
    CalibratedPredStress(ii) = step_value_local(calStress,k,nMPC);

    NetLoadNow_pu(ii) = step_value_local(netLoadNow,k,nMPC);
    AbsNetLoadRamp_pu(ii) = step_value_local(netLoadRamp,k,nMPC);
    DGUpHeadroom_pu(ii) = step_value_local(dgHeadroom,k,nMPC);

    OODFlag(ii) = step_value_local(oodFlag,k,nMPC);
    NoSafeCandidateFlag(ii) = step_value_local(noSafeFlag,k,nMPC);
    FallbackFlag(ii) = step_value_local(fallbackFlag,k,nMPC);

    t0 = (k-1)*cfg.mpc.decisionInterval_h*3600;
    t1 = k*cfg.mpc.decisionInterval_h*3600;

    if ~isempty(freq) && ~isempty(tSec)

        if k<nMPC
            idx = tSec>=t0 & tSec<t1;
        else
            idx = tSec>=t0 & tSec<=t1;
        end

        if any(idx)
            f = real(double(freq(:)));
            RealizedMaxAbsDf_Hz(ii) = ...
                max(abs(f(idx)-cfg.frequency.nominal_Hz),[],'omitnan');
        end
    end

    if ~isempty(nativeRoCoF) && ~isempty(tRoCoFSec)

        if k<nMPC
            idxR = tRoCoFSec>=t0 & tRoCoFSec<t1;
        else
            idxR = tRoCoFSec>=t0 & tRoCoFSec<=t1;
        end

        if any(idxR)
            r = real(double(nativeRoCoF(:)));
            RealizedMaxAbsRoCoF_Hz_s(ii) = ...
                max(abs(r(idxR)),[],'omitnan');
        end
    end

    FreqViolation(ii) = ...
        RealizedMaxAbsDf_Hz(ii) > ...
        cfg.frequency.securityDeviation_Hz + 1e-9;

    RoCoFViolation(ii) = ...
        RealizedMaxAbsRoCoF_Hz_s(ii) > ...
        cfg.frequency.securityRoCoF_Hz_s + 1e-9;
end

T = table( ...
    MPCStep,StartTime_h, ...
    Alpha,RawPredStress,CalibratedPredStress, ...
    NetLoadNow_pu,AbsNetLoadRamp_pu,DGUpHeadroom_pu, ...
    OODFlag,NoSafeCandidateFlag,FallbackFlag, ...
    RealizedMaxAbsDf_Hz,RealizedMaxAbsRoCoF_Hz_s, ...
    FreqViolation,RoCoFViolation);

sources = struct();
sources.Alpha = alphaPath;
sources.RawPredStress = rawStressPath;
sources.CalibratedPredStress = calStressPath;
sources.NetLoadNow_pu = netLoadNowPath;
sources.AbsNetLoadRamp_pu = netLoadRampPath;
sources.DGUpHeadroom_pu = dgHeadroomPath;
sources.OODFlag = oodPath;
sources.NoSafeCandidateFlag = noSafePath;
sources.FallbackFlag = fallbackPath;
sources.Frequency = freqPath;
sources.FrequencyTime = timePath;
sources.NativeRoCoF = nativeRoCoFPath;
sources.NativeRoCoFTime = rocofTimePath;

D = struct();
D.table = T;
D.sources = sources;
end


function x = step_value_local(v,k,nMPC)

x = NaN;

if isempty(v) || ~(isnumeric(v) || islogical(v))
    return;
end

v = squeeze(v);

if isvector(v)

    v = double(v(:));

    if numel(v)==nMPC || numel(v)==nMPC+1
        x = v(k);
    end
end
end


function [value,pathFound] = find_signal_local(root,preferredPaths,leafCandidates)

value = [];
pathFound = "";

for k = 1:numel(preferredPaths)

    [ok,v] = get_path_local(root,preferredPaths{k});

    if ok && (isnumeric(v) || islogical(v)) && ~isempty(v)
        value = v;
        pathFound = string(preferredPaths{k});
        return;
    end
end

[value,pathFound] = recursive_leaf_search_local(root,leafCandidates,"");
end


function [value,pathFound] = recursive_leaf_search_local(x,candidates,prefix)

value = [];
pathFound = "";

if ~isstruct(x) || numel(x)~=1
    return;
end

names = fieldnames(x);

for i = 1:numel(names)

    name = names{i};

    if strlength(prefix)==0
        path = string(name);
    else
        path = prefix + "." + string(name);
    end

    v = x.(name);

    if any(strcmpi(name,candidates)) && ...
            (isnumeric(v) || islogical(v)) && ~isempty(v)

        value = v;
        pathFound = path;
        return;
    end
end

for i = 1:numel(names)

    name = names{i};
    v = x.(name);

    if ~isstruct(v) || numel(v)~=1
        continue;
    end

    if strlength(prefix)==0
        path = string(name);
    else
        path = prefix + "." + string(name);
    end

    [value,pathFound] = recursive_leaf_search_local(v,candidates,path);

    if strlength(pathFound)>0
        return;
    end
end
end


function [ok,v] = get_path_local(root,pathText)

ok = false;
v = [];

parts = split(string(pathText),'.');
x = root;

for k = 1:numel(parts)

    field = char(parts(k));

    if ~isstruct(x) || numel(x)~=1 || ~isfield(x,field)
        return;
    end

    x = x.(field);
end

ok = true;
v = x;
end


function [tSec,pathFound] = find_time_seconds_local(result,n)

tSec = [];
pathFound = "";

if n==0
    return;
end

candidatesH = { ...
    'time_h','frequency.time_h','physical.time_h','simulation.time_h'};

for k = 1:numel(candidatesH)

    [ok,t] = get_path_local(result,candidatesH{k});

    if ok && isnumeric(t) && numel(t)==n

        tSec = double(t(:))*3600;
        pathFound = string(candidatesH{k});

        if all(isfinite(tSec)) && all(diff(tSec)>0)
            return;
        end

        tSec = [];
        pathFound = "";
    end
end

candidatesS = { ...
    'time_s','frequency.time_s','physical.time_s','simulation.time_s'};

for k = 1:numel(candidatesS)

    [ok,t] = get_path_local(result,candidatesS{k});

    if ok && isnumeric(t) && numel(t)==n

        tSec = double(t(:));
        pathFound = string(candidatesS{k});

        if all(isfinite(tSec)) && all(diff(tSec)>0)
            return;
        end

        tSec = [];
        pathFound = "";
    end
end

% Fallback only for interval localization of long physical traces.
if n > 96
    tSec = linspace(0,24*3600,n).';
    pathFound = "FALLBACK: uniform 24-h mapping";
end
end


function print_sources_local(s)

names = fieldnames(s);

for k = 1:numel(names)

    name = names{k};
    path = string(s.(name));

    if strlength(path)==0
        path = "<NOT FOUND>";
    end

    fprintf('  %-28s : %s\n',name,path);
end
end


function filePath = find_one_result_local(methodDir,caseName,decayRatio,seed)

decayCode = round(100*decayRatio);

pattern = sprintf('%s_*_decay%03d_seed%03d_*.mat', ...
    caseName,decayCode,seed);

hits = dir(fullfile(methodDir,pattern));

assert(~isempty(hits), ...
    'No saved result found in %s matching %s.',methodDir,pattern);

assert(numel(hits)==1, ...
    'Expected one result in %s matching %s, found %d.', ...
    methodDir,pattern,numel(hits));

filePath = fullfile(hits(1).folder,hits(1).name);
end


function result = load_result_local(filePath)

S = load(filePath);

if isfield(S,'result') && isstruct(S.result)
    result = S.result;
    return;
end

names = fieldnames(S);

for k = 1:numel(names)

    x = S.(names{k});

    if isstruct(x) && ...
            (isfield(x,'summary') || ...
             isfield(x,'freq_Hz') || ...
             isfield(x,'totalCost'))

        result = x;
        return;
    end
end

error('Could not identify result struct in %s.',filePath);
end


function value = get_summary_local(result,name,defaultValue)

value = defaultValue;

if isfield(result,name)

    x = result.(name);

    if (isnumeric(x) || islogical(x)) && isscalar(x)
        value = double(x);
        return;
    end
end

if ~isfield(result,'summary') || isempty(result.summary)
    return;
end

s = result.summary;

if isstruct(s) && isfield(s,name)

    x = s.(name);

    if (isnumeric(x) || islogical(x)) && isscalar(x)
        value = double(x);
    end

elseif istable(s) && ismember(name,s.Properties.VariableNames)

    x = s.(name);

    if isnumeric(x) && ~isempty(x)
        value = double(x(1));
    end
end
end
