%% Synthetic no-simulation unit test for the new stress-response KRR pipeline
cfg=config_island_ems();
rng(23,'twister');
nG=6; nPer=20; n=nG*nPer;
group=repelem((1:nG).',nPer);
Pnet=0.2+0.7*rand(n,1);
ramp=0.15*rand(n,1);
head=0.15+0.75*rand(n,1);
levels=cfg.ai.response.alphaLevels(:);
alpha=levels(randi(numel(levels),n,1));
% Smooth synthetic response: higher Pnet/ramp increase stress, greater
% headroom/alpha decrease it. Small noise avoids an unrealistically exact fit.
y=0.45+0.55*Pnet+1.10*ramp-0.25*head+0.55*(1-alpha)+0.01*randn(n,1);
y=max(y,0);

dataset=struct();
dataset.kind='IslandEMSFrequencyStressResponseDatasetV1';
dataset.caseName='18bus';
dataset.stateFeatureNames=reserve_feature_names();
dataset.inputNames=[reserve_feature_names() {'reserveRatio'}];
dataset.Xstate=[Pnet ramp head];
dataset.alpha=alpha;
dataset.X=[dataset.Xstate alpha];
dataset.yStress=y;
dataset.groupID=group;
dataset.secure=y<=1;
dataset.trainingSignature=ai_reserve_model_signature(cfg,'18bus');

aiCfg=cfg.ai; aiCfg.tuneHyperparameters=false;
model=train_reserve_krr(dataset,aiCfg);
assert(strcmpi(model.learningTarget,'frequency-stress-response'),'Wrong learned target.');
assert(numel(model.stateFeatureNames)==3 && numel(model.inputNames)==4,'Wrong response input contract.');
assert(isfinite(model.calibrationOffset) && model.calibrationOffset>=0,'Invalid safety calibration.');
[a,info]=predict_reserve_ratio(model,[0.5 0.05 0.4],aiCfg);
assert(isfinite(a) && a>=aiCfg.alphaMin-1e-12 && a<=aiCfg.alphaMax+1e-12,'Invalid online alpha.');
assert(numel(info.alphaGrid)>=3,'Online candidate search was not executed.');

fprintf('Synthetic randomized-alpha stress-response model test passed.\n');
