%% smoke_P1_forecast_safety_shield_closed_loop_18bus.m
% Focused EXACT closed-loop test of the experimental P1 post-KRR shield.
%
% Run this AFTER:
%   apply_P1_forecast_safety_shield_smoke_patch
%
% Scope:
%   18bus
%   decayRatio = 1.00
%   P1 only
%   no formal result persistence
%   no figures
%
% Two variants are available:
%
%   S2 = KRR WITHOUT global calibration + forecast safety shield
%   S1 = KRR WITH current global calibration + forecast safety shield
%
% Default is S2 only for speed.  If S2 becomes frequency-safe, change:
%
%   RUN_VARIANTS = ["S2","S1"];
%
% to quantify whether calibration adds anything after the shield exists.
%
% Experimental shield used in this smoke:
%
%   if alpha_KRR < 1
%      AND forecastNetDrop_pu >= 0.02
%      AND forecastNetLoadNow_pu >= 0.60
%   then
%      alpha_final = 1.00
%   end
%
% IMPORTANT:
% These thresholds are debugging candidates from the 18-bus saved trajectory,
% NOT final universal paper parameters.

clear;
clc;
close all force;

%% User switch
RUN_VARIANTS = ["S1"];        % fastest next step
% RUN_VARIANTS = ["S2","S1"]; % use later for calibration ablation

%% Experimental shield parameters
SHIELD_DROP_THRESHOLD_PU = 0.02;
SHIELD_NETLOAD_MIN_PU    = 0.60;
SHIELD_ALPHA             = 1.00;

%% Setup
projectRoot = pwd;
addpath(genpath(projectRoot));
rehash;

cfg = config_island_ems();

% Verify experimental patch is active.
predFile = which('predict_reserve_ratio');
engineFile = fullfile(projectRoot,'core','engine','engine_island_ems.m');

assert(~isempty(predFile) && ...
    contains(fileread(predFile),'forecastSafetyShieldTriggered'), ...
    ['Experimental predict_reserve_ratio.m is not active. Run ', ...
     'apply_P1_forecast_safety_shield_smoke_patch first.']);

assert(exist(engineFile,'file')==2 && ...
    contains(fileread(engineFile),'P1_FORECAST_SAFETY_SHIELD_EXPERIMENTAL'), ...
    ['Experimental engine hook is not active. Run ', ...
     'apply_P1_forecast_safety_shield_smoke_patch first.']);

%% Fixed Part-I scope
caseName   = '18bus';
decayRatio = 1.00;
seed       = 0;

cfg.output.saveResults = false;
cfg.output.showFigures = false;

% Enable shield ONLY inside this smoke test.
cfg.ai.enableForecastSafetyShield = true;
cfg.ai.forecastSafetyShieldDropThreshold_pu = SHIELD_DROP_THRESHOLD_PU;
cfg.ai.forecastSafetyShieldNetLoadMin_pu = SHIELD_NETLOAD_MIN_PU;
cfg.ai.forecastSafetyShieldAlpha = SHIELD_ALPHA;

catalog = paper_method_catalog();
ids = string({catalog.id});
idxP1 = find(ids=="P1",1);
assert(~isempty(idxP1),'P1 not found in paper_method_catalog().');

baseRunCfg = catalog(idxP1);
baseRunCfg.caseName = caseName;
baseRunCfg.dayType = cfg.scenario.dayType;
baseRunCfg.decayRatio = decayRatio;
baseRunCfg.randomSeed = seed;

%% Saved references
formalRunTag = '20260907_115951';
formalRoot = fullfile(projectRoot,cfg.output.root,formalRunTag);

refF1 = load_reference_local( ...
    formalRoot,'T7',caseName,decayRatio,seed);

refP1 = load_reference_local( ...
    formalRoot,'P1',caseName,decayRatio,seed);

fprintf('\n=============================================================\n');
fprintf(' EXACT P1 FORECAST-SAFETY-SHIELD CLOSED-LOOP SMOKE\n');
fprintf('=============================================================\n');
fprintf('case              : %s\n',caseName);
fprintf('decayRatio        : %.2f\n',decayRatio);
fprintf('variants          : %s\n',strjoin(RUN_VARIANTS,', '));
fprintf('shield drop thr   : %.4f pu\n',SHIELD_DROP_THRESHOLD_PU);
fprintf('shield netload min: %.4f pu\n',SHIELD_NETLOAD_MIN_PU);
fprintf('shield alpha      : %.4f\n',SHIELD_ALPHA);
fprintf('save results      : 0\n');
fprintf('=============================================================\n');

fprintf('\nSaved reference results:\n');
print_result_summary_local('F1 saved',refF1,cfg);
print_result_summary_local('P1 saved',refP1,cfg);

%% Run selected variants
summaryTable = table();
results = struct();

for iv = 1:numel(RUN_VARIANTS)

    variant = RUN_VARIANTS(iv);

    runCfg = baseRunCfg;

    switch variant
        case "S2"
            runCfg.aiSafetyCalibration = false;
            calibrationEnabled = false;

        case "S1"
            runCfg.aiSafetyCalibration = true;
            calibrationEnabled = true;

        otherwise
            error('Unknown variant: %s',variant);
    end

    fprintf('\n\n=============================================================\n');
    fprintf(' RUNNING %s\n',variant);
    fprintf(' calibration = %d\n',calibrationEnabled);
    fprintf(' shield      = 1\n');
    fprintf('=============================================================\n');

    result = run_single_experiment( ...
        cfg,runCfg,projectRoot,'',false);

    results.(char(variant)) = result;

    metrics = summarize_variant_local( ...
        result,cfg,variant,calibrationEnabled);

    if isempty(summaryTable)
        summaryTable = metrics.summaryRow;
    else
        summaryTable = [summaryTable;metrics.summaryRow]; %#ok<AGROW>
    end

    fprintf('\n%s result:\n',variant);
    disp(metrics.summaryRow);

    fprintf('\n%s shield trigger intervals:\n',variant);
    if isempty(metrics.triggerTable)
        fprintf('  none\n');
    else
        disp(metrics.triggerTable);
    end

    fprintf('\n%s remaining CoI-unsafe intervals:\n',variant);
    if isempty(metrics.unsafeTable)
        fprintf('  NONE\n');
    else
        disp(metrics.unsafeTable);
    end

    % Hard safety gate for each experimental variant.
    if metrics.summaryRow.CoIUnsafeCount==0
        fprintf('\n>>> %s COI FREQUENCY SAFETY: PASS <<<\n',variant);
    else
        fprintf('\n>>> %s COI FREQUENCY SAFETY: FAIL <<<\n',variant);
    end
end

%% Comparison
fprintf('\n\n=============================================================\n');
fprintf(' VARIANT COMPARISON\n');
fprintf('=============================================================\n');
disp(summaryTable);

if all(ismember(["S2","S1"],RUN_VARIANTS))
    s2 = summaryTable(summaryTable.Variant=="S2",:);
    s1 = summaryTable(summaryTable.Variant=="S1",:);

    fprintf('\nCalibration value AFTER adding the same safety shield:\n');
    fprintf('  S2 mean alpha = %.6f | cost = %.6f | unsafe = %d\n', ...
        s2.MeanAlpha,s2.TotalCost,s2.CoIUnsafeCount);
    fprintf('  S1 mean alpha = %.6f | cost = %.6f | unsafe = %d\n', ...
        s1.MeanAlpha,s1.TotalCost,s1.CoIUnsafeCount);

    if s2.CoIUnsafeCount==0 && s1.CoIUnsafeCount==0
        fprintf(['  Both are safe.  If S2 is no worse economically/reserve-wise, ', ...
            'the global calibration has little evidence of added value.\n']);
    end
end

%% Acceptance guidance
fprintf('\n=============================================================\n');
fprintf(' NEXT DECISION\n');
fprintf('=============================================================\n');

if any(summaryTable.Variant=="S2")
    s2 = summaryTable(summaryTable.Variant=="S2",:);

    if s2.CoIUnsafeCount==0
        fprintf(['S2 passed the first exact closed-loop safety test.\n', ...
            'Next: run S1 too, then decide whether calibration should be removed.\n']);
    else
        fprintf(['S2 is still unsafe.  Do NOT tune calibration yet.\n', ...
            'Use the remaining unsafe intervals + forecast-shield diagnostics ', ...
            'to refine the post-KRR correction.\n']);
    end
end

fprintf('=============================================================\n');


%% =========================================================================
% Local helpers
% =========================================================================

function out = summarize_variant_local(result,cfg,variant,calibrationEnabled)

df = double(result.interval.maxAbsFreqDev_Hz(:));
rocof = double(result.interval.maxAbsRoCoF_Hz_s(:));

dfLim = cfg.frequency.securityDeviation_Hz;
rLim  = cfg.frequency.securityRoCoF_Hz_s;

stress = max(df/dfLim,rocof/rLim);
unsafe = stress>1+1e-12;

alpha = double(result.reserve.ratio(:));

n = numel(alpha);
step = (1:n).';
time_h = (step-1)*cfg.mpc.decisionInterval_h;

shieldTriggered = false(n,1);
preShieldAlpha = nan(n,1);
postShieldAlpha = alpha;
forecastDrop = nan(n,1);
forecastNetNow = nan(n,1);
signedForecastRamp = nan(n,1);
usedCalibration = false(n,1);

if isfield(result.reserve,'metaHistory')
    H = result.reserve.metaHistory;

    for k = 1:min(n,numel(H))
        m = H{k};

        if ~isstruct(m) || ~isfield(m,'prediction') || ...
                ~isstruct(m.prediction)
            continue;
        end

        q = m.prediction;

        shieldTriggered(k) = get_logical_local( ...
            q,'forecastSafetyShieldTriggered',false);

        preShieldAlpha(k) = get_scalar_local( ...
            q,'preShieldAlpha',NaN);

        postShieldAlpha(k) = get_scalar_local( ...
            q,'postShieldAlpha',alpha(k));

        forecastDrop(k) = get_scalar_local( ...
            q,'forecastNetDrop_pu',NaN);

        forecastNetNow(k) = get_scalar_local( ...
            q,'forecastNetLoadNow_pu',NaN);

        signedForecastRamp(k) = get_scalar_local( ...
            q,'forecastSignedNetRamp_pu',NaN);

        usedCalibration(k) = get_logical_local( ...
            q,'usedCalibration',false);
    end
end

summaryRow = table();
summaryRow.Variant = string(variant);
summaryRow.CalibrationEnabled = logical(calibrationEnabled);
summaryRow.TotalCost = double(result.totalCost);
summaryRow.MeanAlpha = mean(alpha,'omitnan');
summaryRow.MinAlpha = min(alpha,[],'omitnan');
summaryRow.MaxAlpha = max(alpha,[],'omitnan');
summaryRow.MaxAbsDf_Hz = max(df,[],'omitnan');
summaryRow.MaxAbsRoCoF_Hz_s = max(rocof,[],'omitnan');
summaryRow.MaxSecurityStress = max(stress,[],'omitnan');
summaryRow.CoIUnsafeCount = nnz(unsafe);
summaryRow.CoIUnsafeRate = mean(unsafe);
summaryRow.ShieldTriggerCount = nnz(shieldTriggered);
summaryRow.ShieldTriggerRate = mean(shieldTriggered);
summaryRow.MeanPreShieldAlpha = mean(preShieldAlpha,'omitnan');
summaryRow.MeanPostShieldAlpha = mean(postShieldAlpha,'omitnan');
summaryRow.MeanShieldAlphaIncrease = ...
    mean(postShieldAlpha-preShieldAlpha,'omitnan');

triggerTable = table();

if any(shieldTriggered)
    idx = find(shieldTriggered);

    triggerTable = table( ...
        step(idx),time_h(idx), ...
        preShieldAlpha(idx),postShieldAlpha(idx), ...
        forecastNetNow(idx),signedForecastRamp(idx),forecastDrop(idx), ...
        df(idx),rocof(idx),stress(idx),unsafe(idx), ...
        'VariableNames',{ ...
        'MPCStep','StartTime_h','PreShieldAlpha','PostShieldAlpha', ...
        'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu', ...
        'ForecastNetDrop_pu','MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s', ...
        'SecurityStress','CoIUnsafe'});
end

unsafeTable = table();

if any(unsafe)
    idx = find(unsafe);

    unsafeTable = table( ...
        step(idx),time_h(idx),alpha(idx), ...
        shieldTriggered(idx),preShieldAlpha(idx), ...
        forecastNetNow(idx),signedForecastRamp(idx),forecastDrop(idx), ...
        df(idx),rocof(idx),stress(idx), ...
        'VariableNames',{ ...
        'MPCStep','StartTime_h','FinalAlpha', ...
        'ShieldTriggered','PreShieldAlpha', ...
        'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu', ...
        'ForecastNetDrop_pu','MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s', ...
        'SecurityStress'});
end

out = struct();
out.summaryRow = summaryRow;
out.triggerTable = triggerTable;
out.unsafeTable = unsafeTable;
end


function result = load_reference_local( ...
    formalRoot,methodID,caseName,decayRatio,seed)

methodDir = fullfile(formalRoot,methodID);
decayCode = round(100*decayRatio);

pattern = sprintf('%s_*_decay%03d_seed%03d_*.mat', ...
    caseName,decayCode,seed);

hits = dir(fullfile(methodDir,pattern));

assert(numel(hits)==1, ...
    'Expected one saved %s reference; found %d.',methodID,numel(hits));

S = load(fullfile(hits(1).folder,hits(1).name));

if isfield(S,'result')
    result = S.result;
else
    names = fieldnames(S);
    result = [];
    for k=1:numel(names)
        if isstruct(S.(names{k}))
            result=S.(names{k});
            break;
        end
    end
    assert(~isempty(result),'Could not identify saved result struct.');
end
end


function print_result_summary_local(label,result,cfg)

df = double(result.interval.maxAbsFreqDev_Hz(:));
rocof = double(result.interval.maxAbsRoCoF_Hz_s(:));
unsafe = df>cfg.frequency.securityDeviation_Hz+1e-12 | ...
         rocof>cfg.frequency.securityRoCoF_Hz_s+1e-12;

fprintf(['  %-10s cost=%9.4f | mean alpha=%.6f | max|df|=%.6f | ', ...
    'max|RoCoF|=%.6f | unsafe=%d\n'], ...
    label,double(result.totalCost), ...
    mean(double(result.reserve.ratio(:)),'omitnan'), ...
    max(df),max(rocof),nnz(unsafe));
end


function v = get_scalar_local(s,name,defaultValue)
v=defaultValue;
if isstruct(s) && isfield(s,name)
    x=s.(name);
    if isnumeric(x) && isscalar(x)
        v=double(x);
    end
end
end


function v = get_logical_local(s,name,defaultValue)
v=logical(defaultValue);
if isstruct(s) && isfield(s,name)
    x=s.(name);
    if (islogical(x) || isnumeric(x)) && isscalar(x)
        v=logical(x);
    end
end
end
