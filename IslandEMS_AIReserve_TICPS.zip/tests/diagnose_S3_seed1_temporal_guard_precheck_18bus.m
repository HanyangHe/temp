%% diagnose_S3_seed1_temporal_guard_precheck_18bus.m
% NO-SIMULATION precheck before spending ~25 min on another closed-loop run.
%
% Why this precheck is needed
% ---------------------------
% We previously proposed a one-step persistence guard:
%
%   if the S3 shield triggers at step k,
%   keep alpha=1 also at step k+1.
%
% After reviewing the seed-1 trigger log, however, Step 28 already had
% alpha=1 at BOTH Steps 27 and 28, while Step 89 was not preceded by a shield
% trigger. Therefore persistence may not change either unsafe event.
%
% This script checks that directly from:
%   S3_seed_robustness_results.seed_001
%
% It also screens a ONE-STEP ANTICIPATORY version:
%
%   if the S3 shield would trigger at step k+1,
%   raise alpha at step k.
%
% This is only a schedule/mechanism precheck. It does NOT claim physical
% safety without a later exact closed-loop rerun.
%
% Runtime: a few seconds. No MPC solve. No physical simulation.

clc;

%% Load seed-1 S3 result
assert(evalin('base', ...
    ['exist(''S3_seed_robustness_results'',''var'')==1 && ', ...
     'isstruct(S3_seed_robustness_results) && ', ...
     'isfield(S3_seed_robustness_results,''seed_001'')']), ...
    'S3_seed_robustness_results.seed_001 is not available in base workspace.');

R = evalin('base','S3_seed_robustness_results');
S3 = R.seed_001;

cfg = config_island_ems();

alpha = double(S3.reserve.ratio(:));
n = numel(alpha);

step = (1:n).';
time_h = (step-1)*cfg.mpc.decisionInterval_h;

df = double(S3.interval.maxAbsFreqDev_Hz(:));
rocof = double(S3.interval.maxAbsRoCoF_Hz_s(:));
stress = max(df/cfg.frequency.securityDeviation_Hz, ...
             rocof/cfg.frequency.securityRoCoF_Hz_s);
unsafe = stress>1+1e-12;

%% Recover base S3 trigger diagnostics
baseTrigger = false(n,1);
moderateTrigger = false(n,1);
severeTrigger = false(n,1);
preShieldAlpha = nan(n,1);

forecastNet = nan(n,1);
forecastRamp = nan(n,1);
forecastDrop = nan(n,1);

H = S3.reserve.metaHistory;

for k=1:min(n,numel(H))

    m = H{k};

    if ~isstruct(m) || ~isfield(m,'prediction') || ...
            ~isstruct(m.prediction)
        continue;
    end

    q = m.prediction;

    moderateTrigger(k) = get_logical_local( ...
        q,'forecastSafetyShieldModerateBranch',false);

    severeTrigger(k) = get_logical_local( ...
        q,'forecastSafetyShieldSevereBranch',false);

    % Existing S3 implementation:
    baseTrigger(k) = get_logical_local( ...
        q,'forecastSafetyShieldTriggered', ...
        moderateTrigger(k) || severeTrigger(k));

    preShieldAlpha(k) = get_scalar_local( ...
        q,'preShieldAlpha',NaN);

    forecastNet(k) = get_scalar_local( ...
        q,'forecastNetLoadNow_pu',NaN);

    forecastRamp(k) = get_scalar_local( ...
        q,'forecastSignedNetRamp_pu',NaN);

    forecastDrop(k) = get_scalar_local( ...
        q,'forecastNetDrop_pu',NaN);
end

%% ------------------------------------------------------------------------
% A. One-step persistence counterfactual
% -------------------------------------------------------------------------
% Persistence does NOT self-propagate. It is driven only by the preceding
% BASE S3 trigger.

persistenceForce = [false; baseTrigger(1:end-1)];

alphaPersistence = alpha;
idxPersist = persistenceForce & alphaPersistence<1-1e-12;
alphaPersistence(idxPersist)=1;

%% ------------------------------------------------------------------------
% B. One-step anticipatory counterfactual
% -------------------------------------------------------------------------
% If next interval has a BASE S3 trigger, raise reserve one interval earlier.
% This is only a schedule diagnostic; a production version must use
% forecast-horizon quantities available at step k rather than future realized
% trigger metadata.

leadOneForce = [baseTrigger(2:end); false];

alphaLeadOne = alpha;
idxLead = leadOneForce & alphaLeadOne<1-1e-12;
alphaLeadOne(idxLead)=1;

%% Combined lead + persistence schedule diagnostic
alphaLeadPersist = alpha;

idxCombined = (leadOneForce | persistenceForce) & ...
              alphaLeadPersist<1-1e-12;

alphaLeadPersist(idxCombined)=1;

%% Main table
T = table( ...
    step,time_h, ...
    preShieldAlpha,alpha, ...
    baseTrigger,moderateTrigger,severeTrigger, ...
    persistenceForce,alphaPersistence, ...
    leadOneForce,alphaLeadOne,alphaLeadPersist, ...
    forecastNet,forecastRamp,forecastDrop, ...
    df,rocof,stress,unsafe, ...
    'VariableNames',{ ...
    'MPCStep','StartTime_h', ...
    'PreShieldAlpha','S3FinalAlpha', ...
    'BaseShieldTrigger','ModerateBranch','SevereBranch', ...
    'PersistenceForce','AlphaWithPersistence', ...
    'LeadOneForce','AlphaWithLeadOne','AlphaWithLeadPlusPersistence', ...
    'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu','ForecastNetDrop_pu', ...
    'MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s','SecurityStress','CoIUnsafe'});

fprintf('\n=============================================================\n');
fprintf(' S3 SEED-1 TEMPORAL-GUARD PRECHECK -- NO SIMULATION\n');
fprintf('=============================================================\n');
fprintf('Unsafe steps: %s\n',mat2str(find(unsafe).'));
fprintf('=============================================================\n');

fprintf('\nA. CURRENT UNSAFE STEPS\n');
disp(T(unsafe,:));

fprintf('\nB. MORNING WINDOW -- STEPS 24:31\n');
disp(T(24:31,:));

fprintf('\nC. LATE-DAY WINDOW -- STEPS 85:91\n');
disp(T(85:91,:));

%% Does persistence actually alter the current unsafe steps?
unsafeIdx = find(unsafe);

persistChangesUnsafe = ...
    alphaPersistence(unsafeIdx) > alpha(unsafeIdx)+1e-12;

leadChangesPrehistory = false(size(unsafeIdx));

for i=1:numel(unsafeIdx)
    k=unsafeIdx(i);

    % Did the lead rule increase alpha in one of the two immediately
    % preceding intervals?
    lo=max(1,k-2);
    hi=max(1,k-1);

    leadChangesPrehistory(i)=any( ...
        alphaLeadOne(lo:hi)>alpha(lo:hi)+1e-12);
end

decision = table( ...
    unsafeIdx, ...
    alpha(unsafeIdx), ...
    alphaPersistence(unsafeIdx), ...
    persistChangesUnsafe, ...
    leadChangesPrehistory, ...
    'VariableNames',{ ...
    'UnsafeStep','OriginalAlpha','PersistenceAlpha', ...
    'PersistenceChangesUnsafeStep', ...
    'LeadOneChangesRecentPrehistory'});

fprintf('\n=============================================================\n');
fprintf(' D. TEMPORAL-GUARD DECISION TABLE\n');
fprintf('=============================================================\n');
disp(decision);

fprintf('\n=============================================================\n');
fprintf(' E. PRECHECK CONCLUSION\n');
fprintf('=============================================================\n');

if any(persistChangesUnsafe)
    fprintf(['One-step persistence directly changes alpha at at least one ', ...
        'currently unsafe interval. An exact persistence closed-loop test ', ...
        'may be worthwhile.\n']);
else
    fprintf(['One-step persistence does NOT directly increase alpha at any ', ...
        'currently unsafe interval.\n']);
end

if any(leadChangesPrehistory)
    fprintf(['One-step anticipation DOES change the recent prehistory before ', ...
        'at least one unsafe event. This is more consistent with the ', ...
        'history/timing hypothesis and is a better candidate for the next ', ...
        'exact closed-loop test.\n']);
else
    fprintf(['One-step anticipation does not change the recent prehistory ', ...
        'before the current unsafe events either.\n']);
end

fprintf(['\nImportant: this precheck only tells us whether the temporal guard ', ...
    'changes the reserve schedule around the failures. It does NOT predict ', ...
    'the resulting frequency trajectory.\n']);
fprintf('=============================================================\n');

assignin('base','S3_seed1_temporal_guard_precheck',T);
assignin('base','S3_seed1_temporal_guard_decision',decision);

fprintf('\nExported:\n');
fprintf('  S3_seed1_temporal_guard_precheck\n');
fprintf('  S3_seed1_temporal_guard_decision\n');


%% =========================================================================
% Local functions
% =========================================================================

function v=get_scalar_local(s,name,defaultValue)
v=defaultValue;
if isstruct(s) && isfield(s,name)
    x=s.(name);
    if isnumeric(x) && isscalar(x)
        v=double(x);
    end
end
end


function v=get_logical_local(s,name,defaultValue)
v=logical(defaultValue);
if isstruct(s) && isfield(s,name)
    x=s.(name);
    if (islogical(x) || isnumeric(x)) && isscalar(x)
        v=logical(x);
    end
end
end
