function report = test_final_P1_S3_formal_contract(projectRoot)
%TEST_FINAL_P1_S3_FORMAL_CONTRACT No-simulation final-method contract test.

if nargin<1 || isempty(projectRoot)
    projectRoot=pwd;
end
projectRoot=char(projectRoot);

addpath(genpath(projectRoot));
rehash;

cfg=config_island_ems();
plan=paper_study_catalog();
catalog=paper_method_catalog();
ids=string({catalog.id});

fprintf('\n=============================================================\n');
fprintf(' FINAL P1/S3 FORMAL CONTRACT TEST -- NO SIMULATION\n');
fprintf('=============================================================\n');

%% Config
assert(~cfg.ai.useSafetyCalibration, ...
    'Final deployment default must not use global safety calibration.');

requiredCfgFields={ ...
    'enableForecastSafetyShield', ...
    'forecastSafetyShieldDropThreshold_pu', ...
    'forecastSafetyShieldNetLoadMin_pu', ...
    'forecastSafetyShieldSevereDropEnabled', ...
    'forecastSafetyShieldSevereDropThreshold_pu', ...
    'forecastSafetyShieldAlpha'};

for k=1:numel(requiredCfgFields)
    assert(isfield(cfg.ai,requiredCfgFields{k}), ...
        'Missing cfg.ai.%s',requiredCfgFields{k});
end

assert(~cfg.ai.enableForecastSafetyShield, ...
    'Global forecast-guard default must remain OFF; methods enable it explicitly.');
assert(abs(cfg.ai.forecastSafetyShieldDropThreshold_pu-0.02)<1e-12);
assert(abs(cfg.ai.forecastSafetyShieldNetLoadMin_pu-0.60)<1e-12);
assert(cfg.ai.forecastSafetyShieldSevereDropEnabled);
assert(abs(cfg.ai.forecastSafetyShieldSevereDropThreshold_pu-0.11)<1e-12);
assert(abs(cfg.ai.forecastSafetyShieldAlpha-1.00)<1e-12);

%% Method catalog
required=["A0","T7","G1","P1U","P1","C0","C1"];
assert(all(ismember(required,ids)), ...
    'Final paper catalog is missing required methods.');

P1U=catalog(ids=="P1U");
P1=catalog(ids=="P1");
C0=catalog(ids=="C0");
C1=catalog(ids=="C1");

assert(numel(P1U)==1 && numel(P1)==1 && numel(C0)==1 && numel(C1)==1);

assert(strcmpi(P1U.reserveMode,'ai'));
assert(~P1U.aiSafetyCalibration);
assert(~P1U.aiForecastSafetyShield);
assert(strcmpi(P1U.curtailmentMode,'hierarchical'));

for m=[P1 C0 C1]
    assert(strcmpi(m.reserveMode,'ai'));
    assert(~m.aiSafetyCalibration);
    assert(m.aiForecastSafetyShield);
    assert(abs(m.aiForecastSafetyShieldDropThreshold_pu-0.02)<1e-12);
    assert(abs(m.aiForecastSafetyShieldNetLoadMin_pu-0.60)<1e-12);
    assert(m.aiForecastSafetyShieldSevereDropEnabled);
    assert(abs(m.aiForecastSafetyShieldSevereDropThreshold_pu-0.11)<1e-12);
    assert(abs(m.aiForecastSafetyShieldAlpha-1.00)<1e-12);
end

assert(strcmpi(C0.curtailmentMode,'none'));
assert(strcmpi(C1.curtailmentMode,'bess'));
assert(strcmpi(P1.curtailmentMode,'hierarchical'));

%% Paper scope
assert(isequal(string(plan.aiReserveAblation.methods), ...
    ["A0","T7","G1","P1U","P1"]));
assert(isequal(double(plan.aiReserveAblation.decayRatios),1.00));

assert(isequal(string(plan.curtailmentAllocationCost.methods), ...
    ["C0","C1","P1"]));
assert(isequal(double(plan.curtailmentAllocationCost.decayRatios), ...
    [0.20 0.40 0.60 0.80 1.00]));

assert(plan.useStudySpecificDecayScheduling);
assert(plan.rerun18bus.expectedRerunCount==16);
assert(plan.rerun18bus.expectedFinalUniquePairCount==19);

%% Independent count of final unique schedule
keys=strings(0,1);

for id=string(plan.aiReserveAblation.methods)
    for d=double(plan.aiReserveAblation.decayRatios)
        keys(end+1,1)=sprintf('%s@%.2f',id,d); %#ok<AGROW>
    end
end

for id=string(plan.curtailmentAllocationCost.methods)
    for d=double(plan.curtailmentAllocationCost.decayRatios)
        keys(end+1,1)=sprintf('%s@%.2f',id,d); %#ok<AGROW>
    end
end

keys=unique(keys,'stable');
assert(numel(keys)==19,'Full fresh formal schedule must contain 19 unique pairs.');

% Exact incremental rerun count.
rerunKeys="P1U@1.00";
for d=double(plan.curtailmentAllocationCost.decayRatios)
    for id=["C0","C1","P1"]
        rerunKeys(end+1,1)=sprintf('%s@%.2f',id,d); %#ok<AGROW>
    end
end
rerunKeys=unique(rerunKeys,'stable');
assert(numel(rerunKeys)==16, ...
    'Required/recommended 18-bus rerun schedule must contain 16 rows.');

%% Source hooks
predFile=which('predict_reserve_ratio');
featureFile=which('build_reserve_features');
runSingleFile=which('run_single_experiment');
engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');

assert(~isempty(predFile) && ...
    contains(fileread(predFile),'forecastSafetyShieldSevereBranch'), ...
    'Final two-branch predict_reserve_ratio is not active.');

assert(~isempty(featureFile) && ...
    contains(fileread(featureFile),'signedNetRampForecast_pu'), ...
    'Final forecast metadata build_reserve_features is not active.');

assert(~isempty(runSingleFile) && ...
    contains(fileread(runSingleFile),'FINAL_P1_METHOD_SPECIFIC_FORECAST_GUARD'), ...
    'Method-specific P1/P1U guard hook is not installed.');

assert(exist(engineFile,'file')==2 && ...
    contains(fileread(engineFile),'P1_FORECAST_SAFETY_GUARD_FINAL'), ...
    'Final engine forecast metadata hook is not installed.');

%% Existing KRR model contract remains frozen
modelFile=fullfile(projectRoot,char(cfg.ai.modelRoot),'18bus',char(cfg.ai.modelFileName));

if exist(modelFile,'file')==2
    M=load(modelFile);
    assert(isfield(M,'model'),'18-bus model file lacks variable model.');
    expected={'netLoadNow_pu','absNetLoadRamp_pu','dgUpHeadroom_pu'};
    assert(isequal(string(M.model.stateFeatureNames(:)),string(expected(:))), ...
        'KRR state-feature contract unexpectedly changed.');
    modelStatus="FOUND_AND_COMPATIBLE";
else
    modelStatus="NOT_FOUND";
    warning('18-bus KRR model not found at expected path: %s',modelFile);
end

report=struct();
report.status='PASS';
report.finalP1='uncalibrated KRR + frozen two-branch forecast guard';
report.P1U='uncalibrated KRR without forecast guard';
report.fullFreshUniquePairs=19;
report.incremental18busReruns=16;
report.modelStatus=modelStatus;

fprintf('P1U contract                 : PASS\n');
fprintf('P1 final guarded contract    : PASS\n');
fprintf('C0/C1/P1 reserve parity      : PASS\n');
fprintf('Part-I decay=1 only          : PASS\n');
fprintf('Full fresh schedule          : 19 unique pairs\n');
fprintf('18-bus incremental reruns    : 16 rows\n');
fprintf('KRR model                    : %s\n',modelStatus);
fprintf('=============================================================\n');
end
