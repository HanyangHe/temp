%% Project-level structural audit
projectRoot = fileparts(fileparts(mfilename('fullpath')));

cfg = config_island_ems();
validate_config(cfg);

assert(isfield(cfg.frequency,'reserveDeviation_Hz') && ...
       isfield(cfg.frequency,'securityDeviation_Hz'), ...
    'Reserve-design and security-evaluation thresholds must remain separately named.');

% Do not duplicate the tunable reserve-design value in the test itself.
% The important structural requirements are positivity and explicit separation
% from the physical security limit.
assert(isfinite(cfg.frequency.reserveDeviation_Hz) && ...
       cfg.frequency.reserveDeviation_Hz > 0, ...
    'Nominal EMS reserve-design bandwidth must be positive and finite.');
assert(abs(cfg.frequency.securityDeviation_Hz-0.50)<1e-12, ...
    'Physical security-evaluation limit must remain 0.50 Hz unless the study definition is intentionally revised.');
assert(cfg.frequency.reserveDeviation_Hz < cfg.frequency.securityDeviation_Hz, ...
    'Reserve-design bandwidth must remain below the physical security limit.');

catalog = baseline_catalog();
ids = string({catalog.id});
expected = ["T1","T2","T3","T4","T5","T6","T7","A0","G1","P1U","P1"];
assert(all(ismember(expected,ids)),'Baseline catalog is incomplete.');

assert(exist(fullfile(projectRoot,'config','system_case_catalog.m'),'file')==2, ...
    'Central system-case catalog missing.');
assert(exist(fullfile(projectRoot,'outputs'),'dir')==7,'outputs directory missing.');
assert(exist(fullfile(projectRoot,'ai','models'),'dir')==7,'AI model directory missing.');
assert(exist(fullfile(projectRoot,'utils','check_solver_solution.m'),'file')==2, ...
    'Solver-output guard missing.');
assert(cfg.ev.terminalNumericalSlackMax==0, ...
    'Hidden EV terminal numerical slack must be disabled.');
assert(strcmpi(cfg.ai.modelType,'krr'), ...
    'Current AI implementation is expected to use local KRR.');

dynTxt = fileread(fullfile(projectRoot,'core','dynamics','MicrogridSys_ODEAE_expIterSolver.m'));
assert(~contains(dynTxt,'1.05*SOCmax'), ...
    'Legacy 5%% EV overcharge threshold must not reappear.');

fprintf('Project structural audit passed (reserve design %.3f Hz, security limit %.3f Hz).\n', ...
    cfg.frequency.reserveDeviation_Hz,cfg.frequency.securityDeviation_Hz);
