function report = quick_AIReserve_test(varargin)
%QUICK_AIRESERVE_TEST In-memory pilot for the AI-adaptive reserve idea.
%
% PURPOSE
%   This is an INFORMAL research gate, not a paper experiment.  It checks
%   whether the required frequency-reserve multiplier alpha is genuinely
%   operating-state dependent before a large oracle/training campaign.
%
%   Nothing is written to outputs/, no model is saved, and no dataset is
%   persisted.  All results live only in MATLAB memory.
%
% DEFAULT PILOT
%   case  : 18bus (radial)
%   day   : Unusual day
%   decay : 1.00
%   seed  : 0
%   alpha : [0.70 1.00 1.30]
%
% USAGE FROM PROJECT ROOT
%   addpath(genpath(pwd));
%   report = quick_AIReserve_test();
%
% OPTIONAL: reuse a just-completed alpha=1 smoke result to avoid rerunning
% that case (saves roughly one full-day simulation):
%   base = smoke_T7_18bus();
%   report = quick_AIReserve_test(base);
%
% OPTIONAL PROFILE
%   report = quick_AIReserve_test('quick');
%     uses alpha=[0.60 0.80 1.00 1.20 1.40] for a finer pilot.
%
%   report = quick_AIReserve_test(base,'quick');
%
% IMPORTANT
%   The primary AI-oracle diagnostic in this pilot uses SYSTEM/CoI
%   frequency and RoCoF, which are the natural EMS-level frequency
%   quantities.  The stricter "all individual DG frequencies" security
%   result is also reported side-by-side so the modeling choice remains
%   transparent.

% ---------------- Parse optional inputs ---------------------------------
baselineResult = [];
profile = 'mini';
for i = 1:nargin
    a = varargin{i};
    if isstruct(a) && isfield(a,'meta')
        baselineResult = a;
    elseif ischar(a) || (isstring(a) && isscalar(a))
        profile = lower(char(a));
    else
        error('quick_AIReserve_test:BadInput', ...
            'Inputs may be a prior result struct and/or profile ''mini''/''quick''.');
    end
end

switch profile
    case 'mini'
        alphaGrid = [0.70 1.00 1.30];
    case 'quick'
        alphaGrid = [0.60 0.80 1.00 1.20 1.40];
    otherwise
        error('Unknown profile: %s. Use ''mini'' or ''quick''.',profile);
end

% ---------------- Robust project-root discovery -------------------------
thisFile = mfilename('fullpath');
if isempty(thisFile)
    error('Cannot resolve quick_AIReserve_test.m location.');
end
thisDir = fileparts(thisFile);
if strcmpi(get_last_path_part(thisDir),'tests')
    projectRoot = fileparts(thisDir);
else
    % Allows the downloaded file to be tested before moving it into tests/.
    candidate = thisDir;
    if exist(fullfile(candidate,'config','config_island_ems.m'),'file')
        projectRoot = candidate;
    else
        projectRoot = pwd;
    end
end
if ~exist(fullfile(projectRoot,'config','config_island_ems.m'),'file')
    error(['Project root not found. Put this file in <projectRoot>/tests/ ', ...
        'and run it with the project root as the MATLAB Current Folder.']);
end
addpath(genpath(projectRoot));

cfg = config_island_ems();
validate_config(cfg);

% ---------------- Freeze this pilot -------------------------------------
caseName = '18bus';
dayType = 'Unusual day';
decayRatio = 1.00;
randomSeed = 0;

if isfield(cfg,'network') && isfield(cfg.network,'allowMeshedCases') && cfg.network.allowMeshedCases
    warning('Formal radial-only policy is currently disabled in config. This pilot still forces 18bus.');
end

fprintf('\n=============================================================\n');
fprintf(' QUICK AI-RESERVE PILOT (in-memory only)\n');
fprintf('=============================================================\n');
fprintf(' case            : %s\n',caseName);
fprintf(' day / decay     : %s / %.2f\n',dayType,decayRatio);
fprintf(' seed            : %d\n',randomSeed);
fprintf(' reserve design  : %.3f Hz\n',cfg.frequency.reserveDeviation_Hz);
fprintf(' security limits : |df| <= %.3f Hz, |RoCoF| <= %.3f Hz/s\n', ...
    cfg.frequency.securityDeviation_Hz,cfg.frequency.securityRoCoF_Hz_s);
fprintf(' alpha grid      : %s\n',mat2str(alphaGrid,3));
fprintf(' profile         : %s\n',profile);
fprintf(' persistence     : OFF (nothing saved under outputs/)\n');
if abs(cfg.frequency.reserveDeviation_Hz-0.30)>1e-12
    warning(['The current reserve-design bandwidth is %.3f Hz, not the ', ...
        'recently selected 0.300 Hz. The pilot will use the CURRENT config.'], ...
        cfg.frequency.reserveDeviation_Hz);
end
fprintf('=============================================================\n\n');

% ---------------- Prepare T7 fixed-reserve baseline ---------------------
catalog = baseline_catalog();
ids = string({catalog.id});
base = catalog(ids=="T7");
if isempty(base)
    error('T7 not found in baseline_catalog.m.');
end
base = base(1);

nA = numel(alphaGrid);
runs = cell(nA,1);
reused = false(nA,1);

% Reuse an optional alpha=1 smoke run only if its scenario/config match.
idxOne = find(abs(alphaGrid-1)<1e-12,1);
if ~isempty(baselineResult) && ~isempty(idxOne)
    if compatible_baseline(baselineResult,cfg,caseName,dayType,decayRatio,randomSeed)
        runs{idxOne} = baselineResult;
        reused(idxOne) = true;
        fprintf('[alpha %.2f] reusing supplied smoke result.\n',alphaGrid(idxOne));
    else
        warning('Supplied baseline result does not match this pilot; alpha=1 will be rerun.');
    end
end

% No output folder is created because saveOutput=false.
for ia = 1:nA
    if ~isempty(runs{ia}), continue; end
    runCfg = base;
    runCfg.reserveMode = 'fixed';
    runCfg.reserveFixedRatio = alphaGrid(ia);
    runCfg.caseName = caseName;
    runCfg.dayType = dayType;
    runCfg.decayRatio = decayRatio;
    runCfg.randomSeed = randomSeed;

    fprintf('\n--- Pilot fixed-alpha run %d/%d: alpha = %.2f ---\n',ia,nA,alphaGrid(ia));
    tRun = tic;
    runs{ia} = run_single_experiment(cfg,runCfg,projectRoot,'',false);
    fprintf('alpha %.2f finished in %.2f min.\n',alphaGrid(ia),toc(tRun)/60);
    close all force;
end

% ---------------- Align features and interval security ------------------
featureRef = [];
Nint = inf;
for ia = 1:nA
    r = runs{ia};
    if isempty(r.reserve.features)
        error('Reserve features were not returned for alpha %.2f.',alphaGrid(ia));
    end
    if isempty(featureRef)
        featureRef = r.reserve.features;
    else
        ncmp = min(size(featureRef,1),size(r.reserve.features,1));
        featErr = max(abs(featureRef(1:ncmp,:)-r.reserve.features(1:ncmp,:)),[],'all');
        if featErr > 1e-10
            warning(['Reserve features differ across alpha runs (max diff %.3e). ', ...
                'Oracle features should be exogenous to alpha.'],featErr);
        end
    end
    Nint = min(Nint,numel(r.interval.maxAbsFreqDev_Hz));
end
Nint = min(Nint,size(featureRef,1));
featureRef = featureRef(1:Nint,:);

secureCoI = false(nA,Nint);
secureStrict = false(nA,Nint);
summaryRows = cell(nA,1);
for ia = 1:nA
    r = runs{ia};
    int = r.interval;
    coiFreqOK = int.maxAbsFreqDev_Hz(1:Nint) <= cfg.frequency.securityDeviation_Hz;
    coiRoCoF = int.maxAbsRoCoF_Hz_s(1:Nint);
    coiRoCoFOK = ~isfinite(coiRoCoF) | coiRoCoF <= cfg.frequency.securityRoCoF_Hz_s;
    secureCoI(ia,:) = coiFreqOK & coiRoCoFOK;
    secureStrict(ia,:) = logical(int.frequencySecure(1:Nint));

    warnRate = mean(r.solver.optimizationExitflag(:)==-7,'omitnan');
    hardRate = mean(r.solver.optimizationExitflag(:)<0 & r.solver.optimizationExitflag(:)~=-7,'omitnan');
    summaryRows{ia} = {alphaGrid(ia), ...
        r.summary.meanTotalDGReserve_kW, r.summary.totalCost, ...
        r.summary.maxAbsFreqDev_Hz, r.summary.maxAbsRoCoF_Hz_s, ...
        mean(secureCoI(ia,:)), mean(secureStrict(ia,:)), ...
        warnRate,hardRate,mean(r.decisionTime_s,'omitnan'), ...
        r.performance.totalCoupledRuntime_s,reused(ia)};
end

pilotTable = cell2table(vertcat(summaryRows{:}), 'VariableNames', { ...
    'Alpha','MeanTotalDGReserve_kW','TotalCost_USD', ...
    'MaxCoIFreqDev_Hz','MaxCoIRoCoF_Hz_s', ...
    'CoISecureIntervalFraction','StrictSecureIntervalFraction', ...
    'SolverWarningRate','SolverHardFailureRate','MeanDecisionTime_s', ...
    'Runtime_s','ReusedRun'});

fprintf('\n=== Fixed-alpha pilot summary ===\n');
disp(pilotTable);

% ---------------- Construct alpha* labels -------------------------------
[yCoI,censoredCoI,nonmonoCoI] = minimum_safe_alpha(alphaGrid,secureCoI);
[yStrict,censoredStrict,nonmonoStrict] = minimum_safe_alpha(alphaGrid,secureStrict);

fprintf('\n=== Oracle-label diagnostic ===\n');
print_label_summary('CoI/system-frequency oracle',yCoI,censoredCoI,nonmonoCoI);
print_label_summary('Strict all-DG oracle',yStrict,censoredStrict,nonmonoStrict);

% ---------------- Train a tiny in-memory KRR sanity model ----------------
% This is NOT a paper model. It only checks whether a state->alpha rule can
% be fitted at all from the pilot labels.
dataset = struct();
dataset.X = featureRef;
dataset.y = yCoI(:);
dataset.groupID = ones(Nint,1);  % one physical scenario -> smoke split only
dataset.censored = censoredCoI(:);
dataset.nonmonotone = nonmonoCoI(:);
dataset.featureNames = reserve_feature_names();
dataset.alphaGrid = alphaGrid;
dataset.sampleMeta = struct([]);
dataset.created = datestr(now,30);

model = [];
yPred = nan(Nint,1);
exact = ~dataset.censored & all(isfinite(dataset.X),2) & isfinite(dataset.y);
if sum(exact) >= 20 && numel(unique(dataset.y(exact))) >= 2
    aiQuick = cfg.ai;
    aiQuick.alphaMin = min(alphaGrid);
    aiQuick.alphaMax = max(alphaGrid);
    aiQuick.tuneHyperparameters = false; % pilot: avoid meaningless CV on one scenario
    aiQuick.useOODFallback = false;
    model = train_reserve_krr(dataset,aiQuick);
    yPred = predict_reserve_ratio_batch(model,featureRef,aiQuick);
else
    fprintf(['\nKRR sanity fit skipped: exact samples=%d, distinct exact alpha labels=%d.\n', ...
        'This itself is useful: expand alpha range or scenario diversity before training.\n'], ...
        sum(exact),numel(unique(dataset.y(exact))));
end

% ---------------- Research gate -----------------------------------------
exactY = yCoI(~censoredCoI);
if isempty(exactY)
    gate = 'NO-GO: all intervals are censored; alpha range is too small or reserve is ineffective.';
else
    spread = max(exactY)-min(exactY);
    fracBelow1 = mean(exactY<1);
    fracAbove1 = mean(exactY>1);
    censRate = mean(censoredCoI);
    nonmonoRate = mean(nonmonoCoI);
    if spread >= 0.20 && censRate <= 0.25 && nonmonoRate <= 0.10
        gate = 'PROMISING: alpha* shows meaningful state dependence. Proceed to a broader oracle dataset.';
    elseif censRate > 0.25
        gate = 'INCONCLUSIVE: too many censored intervals. Extend the upper alpha range before AI training.';
    elseif spread < 0.10
        gate = 'WEAK: alpha* is nearly constant. A globally tuned fixed reserve may be sufficient.';
    else
        gate = 'MIXED: some state dependence exists; use the 5-point quick profile before deciding.';
    end
    fprintf('\nAlpha* spread = %.3f | <1 = %.1f%% | >1 = %.1f%% | censored = %.1f%% | nonmonotone = %.1f%%\n', ...
        spread,100*fracBelow1,100*fracAbove1,100*censRate,100*nonmonoRate);
end
fprintf('\n*** AI-RESERVE PILOT GATE: %s ***\n',gate);

% ---------------- Diagnostic plots (display only, never saved) -----------
figure('Name','AI reserve pilot: fixed-alpha response');
tiledlayout(2,1);
nexttile;
plot(alphaGrid,100*mean(secureCoI,2),'o-','LineWidth',1.2); hold on;
plot(alphaGrid,100*mean(secureStrict,2),'s--','LineWidth',1.0);
ylabel('Secure intervals (%)'); xlabel('\alpha'); grid on;
legend('CoI/system','Strict all-DG','Location','best');
title('Frequency-security response to fixed reserve multiplier');
nexttile;
plot(alphaGrid,[pilotTable.MaxCoIFreqDev_Hz pilotTable.MaxCoIRoCoF_Hz_s],'-o','LineWidth',1.1);
yline(cfg.frequency.securityDeviation_Hz,'--');
xlabel('\alpha'); ylabel('Peak metric'); grid on;
legend('Max |\Delta f_{CoI}| (Hz)','Max |RoCoF_{CoI}| (Hz/s)','0.5 reference','Location','best');

figure('Name','AI reserve pilot: oracle labels');
t=(0:Nint-1)*cfg.mpc.decisionInterval_h;
plot(t,yCoI,'o-','LineWidth',1.0); hold on;
yline(1,'--');
if any(censoredCoI), plot(t(censoredCoI),yCoI(censoredCoI),'rx','MarkerSize',8,'LineWidth',1.5); end
xlabel('Time (h)'); ylabel('\alpha^*'); grid on;
title('CoI/system-frequency oracle reserve multiplier');

figure('Name','AI reserve pilot: alpha-star histogram');
histogram(yCoI(~censoredCoI),'BinMethod','integers');
xlabel('\alpha^*'); ylabel('Intervals'); grid on;
title('Exact pilot oracle labels');

if ~isempty(model)
    figure('Name','AI reserve pilot: KRR sanity fit');
    plot(t,yCoI,'ko','DisplayName','Oracle \alpha^*'); hold on;
    plot(t,yPred,'-','LineWidth',1.2,'DisplayName','KRR pilot prediction');
    yline(1,'--','DisplayName','Physics baseline');
    xlabel('Time (h)'); ylabel('\alpha'); grid on; legend('Location','best');
    title('In-memory KRR sanity fit (not a paper result)');
end

% ---------------- Return everything in memory ---------------------------
report = struct();
report.projectRoot = projectRoot;
report.profile = profile;
report.cfgSnapshot = cfg;
report.alphaGrid = alphaGrid;
report.runs = runs;
report.pilotTable = pilotTable;
report.features = featureRef;
report.secureCoI = secureCoI;
report.secureStrict = secureStrict;
report.alphaStarCoI = yCoI;
report.alphaStarStrict = yStrict;
report.censoredCoI = censoredCoI;
report.nonmonotoneCoI = nonmonoCoI;
report.censoredStrict = censoredStrict;
report.nonmonotoneStrict = nonmonoStrict;
report.dataset = dataset;
report.model = model;
report.predictedAlpha = yPred;
report.gate = gate;

fprintf('\nQuick AI-reserve pilot completed. No files were written to outputs/.\n');
end

% ========================================================================
function [y,censored,nonmonotone] = minimum_safe_alpha(alphaGrid,secure)
% Conservative monotone-suffix label: smallest alpha from which all larger
% tested alphas remain secure.  If alphaMax is still unsafe, label is a
% lower bound and marked censored.
nA=size(secure,1); N=size(secure,2);
y=nan(N,1); censored=false(N,1); nonmonotone=false(N,1);
for k=1:N
    sk=logical(secure(:,k));
    nonmonotone(k)=any(diff(double(sk))<0);
    suffixSafe=flip(cumprod(double(flip(sk))))>0;
    good=find(suffixSafe,1,'first');
    if isempty(good)
        good=nA;
        censored(k)=true;
    end
    y(k)=alphaGrid(good);
end
end

function print_label_summary(name,y,censored,nonmonotone)
exact=~censored & isfinite(y);
fprintf('%s:\n',name);
fprintf('  intervals=%d | exact=%d | censored=%d (%.1f%%) | nonmonotone=%d (%.1f%%)\n', ...
    numel(y),sum(exact),sum(censored),100*mean(censored), ...
    sum(nonmonotone),100*mean(nonmonotone));
if any(exact)
    fprintf('  exact alpha*: min %.2f | median %.2f | mean %.3f | max %.2f | std %.3f\n', ...
        min(y(exact)),median(y(exact)),mean(y(exact)),max(y(exact)),std(y(exact)));
    fprintf('  alpha* < 1: %.1f%% | =1: %.1f%% | >1: %.1f%%\n', ...
        100*mean(y(exact)<1),100*mean(abs(y(exact)-1)<1e-12),100*mean(y(exact)>1));
end
end

function tf = compatible_baseline(r,cfg,caseName,dayType,decayRatio,seed)
tf=false;
try
    tf = strcmpi(r.meta.methodID,'T7') && strcmpi(r.meta.caseName,caseName) && ...
        strcmpi(r.meta.dayType,dayType) && abs(r.meta.decayRatio-decayRatio)<1e-12 && ...
        r.meta.randomSeed==seed && strcmpi(r.meta.reserveMode,'fixed') && ...
        abs(r.meta.reserveFixedRatio-1)<1e-12;
    if tf && isfield(r,'cfgSnapshot') && isfield(r.cfgSnapshot,'frequency')
        tf = abs(r.cfgSnapshot.frequency.reserveDeviation_Hz- ...
            cfg.frequency.reserveDeviation_Hz)<1e-12;
    end
catch
    tf=false;
end
end

function s=get_last_path_part(p)
[~,s]=fileparts(p);
end
