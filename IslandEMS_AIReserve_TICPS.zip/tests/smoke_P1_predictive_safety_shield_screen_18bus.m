%% smoke_P1_predictive_safety_shield_screen_18bus.m
% NO-SIMULATION screening test for a post-KRR frequency-safety correction.
%
% This test intentionally follows the two current working hypotheses:
%
%   H1) The present KRR selector uses the current 3-state feature vector and
%       does not provide a reliable closed-loop/dynamic look-ahead guarantee.
%
%   H2) A lightweight ONLINE POST-KRR SAFETY CORRECTION may be more useful
%       than the present single global calibration offset.  Candidate rules
%       are screened using ramp/headroom/current KRR stress and a short-horizon
%       look-ahead proxy.
%
% IMPORTANT
% ---------
% This script does NOT modify P1.
% It does NOT run MPC or physical simulation.
% It only screens whether simple safety-shield triggers would have detected
% the actual unsafe CoI intervals in the saved 18-bus normal-case trajectory.
%
% The script tests BOTH high-headroom and low-headroom interpretations.
% We do not assume beforehand that either is correct.
%
% Primary safety target:
%   CoI frequency security:
%       max |Delta f_CoI| <= securityDeviation_Hz
%       max |RoCoF_CoI|   <= securityRoCoF_Hz_s
%
% The short-horizon quantities built from the next saved state are DIAGNOSTIC
% PROXIES only.  If they look useful, the production implementation must use
% forecast-available quantities, not future realized states.

clear;
clc;

%% User options
FORMAL_RUN_TAG = '20260907_115951';
EXPORT_CSV = true;

% Candidate threshold grids for the shield screen.
rampGrid     = 0.06:0.01:0.18;
headroomGrid = 0.10:0.05:0.80;
stressGrid   = 0.35:0.05:0.95;
signedGrid   = 0.02:0.02:0.16;

TOP_N = 30;

%% Setup
projectRoot = pwd;
addpath(genpath(projectRoot));
rehash;

cfg = config_island_ems();

caseName   = '18bus';
decayRatio = 1.00;
seed       = 0;

runRoot = fullfile(projectRoot,cfg.output.root,FORMAL_RUN_TAG);
assert(exist(runRoot,'dir')==7,'Formal run folder not found: %s',runRoot);

%% Load P1 and F1
p1File = find_one_result_local( ...
    fullfile(runRoot,'P1'),caseName,decayRatio,seed);

f1File = find_one_result_local( ...
    fullfile(runRoot,'T7'),caseName,decayRatio,seed);

P1 = load_result_local(p1File);
F1 = load_result_local(f1File);

assert(isfield(P1,'reserve') && isfield(P1.reserve,'features'), ...
    'P1 result.reserve.features is missing.');
assert(isfield(P1.reserve,'ratio'),'P1 result.reserve.ratio is missing.');
assert(isfield(P1,'interval'),'P1 result.interval is missing.');

%% Use exact saved AI config and exact model
if isfield(P1,'cfgSnapshot') && isfield(P1.cfgSnapshot,'ai')
    aiCfg = P1.cfgSnapshot.ai;
else
    aiCfg = cfg.ai;
end

if isfield(P1,'cfgSnapshot') && isfield(P1.cfgSnapshot,'frequency')
    freqCfg = P1.cfgSnapshot.frequency;
else
    freqCfg = cfg.frequency;
end

if isfield(P1,'cfgSnapshot') && isfield(P1.cfgSnapshot,'mpc') && ...
        isfield(P1.cfgSnapshot.mpc,'decisionInterval_h')
    dt_h = double(P1.cfgSnapshot.mpc.decisionInterval_h);
else
    dt_h = double(cfg.mpc.decisionInterval_h);
end

modelFile = fullfile(projectRoot, ...
    char(aiCfg.modelRoot),caseName,char(aiCfg.modelFileName));

if exist(modelFile,'file')~=2
    modelFile = fullfile(projectRoot, ...
        char(aiCfg.modelRoot),char(aiCfg.modelFileName));
end

assert(exist(modelFile,'file')==2,'AI model not found: %s',modelFile);

M = load(modelFile);
assert(isfield(M,'model'),'reserve_krr_model.mat lacks variable model.');
model = M.model;

%% Basic vectors
X = double(P1.reserve.features);
alphaSaved = double(P1.reserve.ratio(:));

n = size(X,1);
assert(n==numel(alphaSaved),'Feature/alpha length mismatch.');

if isfield(P1.reserve,'featureNames')
    names = string(P1.reserve.featureNames);
else
    names = string(model.stateFeatureNames);
end

idxNet  = find(names=="netLoadNow_pu",1);
idxRamp = find(names=="absNetLoadRamp_pu",1);
idxHead = find(names=="dgUpHeadroom_pu",1);

assert(~isempty(idxNet) && ~isempty(idxRamp) && ~isempty(idxHead), ...
    'Required 3-feature contract not found.');

netNow   = X(:,idxNet);
absRamp  = X(:,idxRamp);
headroom = X(:,idxHead);

%% Exact current KRR/calibrated selector replay
aiC = aiCfg;
aiC.useSafetyCalibration = true;

[alphaReplay,d] = select_reserve_alpha_batch(model,X,aiC,true);
alphaReplay = double(alphaReplay(:));

assert(all(abs(alphaReplay-alphaSaved)<=1e-12), ...
    'Selector replay does not reproduce the saved P1 alpha.');

alphaGrid = double(d.alphaGrid(:).');
rawCurve  = double(d.rawStress);
decCurve  = double(d.decisionStress);

rawAtSelected = nan(n,1);
decAtSelected = nan(n,1);

for k = 1:n
    j = find(abs(alphaGrid-alphaSaved(k))<1e-12,1);
    if ~isempty(j)
        rawAtSelected(k) = rawCurve(k,j);
        decAtSelected(k) = decCurve(k,j);
    end
end

oodFlag    = logical(d.oodFallback(:));
missingFlg = logical(d.missingFeatureFallback(:));
noSafeFlg  = logical(d.noSafeCandidateFallback(:));

%% Actual CoI security labels
df = double(P1.interval.maxAbsFreqDev_Hz(:));
rocof = double(P1.interval.maxAbsRoCoF_Hz_s(:));

dfLim = double(freqCfg.securityDeviation_Hz);
rocofLim = double(freqCfg.securityRoCoF_Hz_s);

actualStress = max(df/dfLim,rocof/rocofLim);
coiUnsafe = actualStress > 1+1e-12;

if isfield(P1.interval,'frequencySecureCoI')
    coiUnsafeStored = ~logical(P1.interval.frequencySecureCoI(:));
    if any(coiUnsafe~=coiUnsafeStored)
        warning(['Computed CoI safety labels differ from stored ', ...
            'frequencySecureCoI at %d intervals.'],nnz(coiUnsafe~=coiUnsafeStored));
    end
end

if isfield(P1.interval,'frequencySecure')
    overallFreqUnsafe = ~logical(P1.interval.frequencySecure(:));
else
    overallFreqUnsafe = coiUnsafe;
end

%% F1 same-step reference
if isfield(F1,'interval') && isfield(F1.interval,'frequencySecureCoI')
    f1CoISafe = logical(F1.interval.frequencySecureCoI(:));
else
    f1Df = double(F1.interval.maxAbsFreqDev_Hz(:));
    f1R  = double(F1.interval.maxAbsRoCoF_Hz_s(:));
    f1CoISafe = f1Df<=dfLim+1e-12 & f1R<=rocofLim+1e-12;
end

%% Short-horizon diagnostic proxies
% These use the next SAVED state only for screening.  They are NOT yet
% suitable for production because future realized states are unavailable
% online.  If useful, replace them later with forecast-derived counterparts.

netNext = [netNow(2:end); NaN];
signedNetChange1 = netNext-netNow;

absSignedNetChange1 = abs(signedNetChange1);

futureMaxRamp1 = absRamp;
futureMinHead1 = headroom;
futureMaxHead1 = headroom;
futureMaxKRRDecision1 = decAtSelected;

for k = 1:n-1
    futureMaxRamp1(k) = max(absRamp(k:k+1));
    futureMinHead1(k) = min(headroom(k:k+1));
    futureMaxHead1(k) = max(headroom(k:k+1));
    futureMaxKRRDecision1(k) = max(decAtSelected(k:k+1));
end

%% Build per-step diagnostic table
step = (1:n).';
time_h = (step-1)*dt_h;

stepTable = table( ...
    step,time_h,alphaSaved, ...
    netNow,absRamp,headroom, ...
    signedNetChange1,absSignedNetChange1, ...
    futureMaxRamp1,futureMinHead1,futureMaxHead1, ...
    rawAtSelected,decAtSelected,futureMaxKRRDecision1, ...
    df,rocof,actualStress,coiUnsafe,overallFreqUnsafe, ...
    oodFlag,missingFlg,noSafeFlg,f1CoISafe, ...
    'VariableNames',{ ...
    'MPCStep','StartTime_h','SavedAlpha', ...
    'NetLoadNow_pu','AbsNetLoadRamp_pu','DGUpHeadroom_pu', ...
    'SignedNetChangeToNext_pu','AbsNetChangeToNext_pu', ...
    'FutureMaxRamp_1step','FutureMinHeadroom_1step', ...
    'FutureMaxHeadroom_1step', ...
    'RawKRRStressAtSavedAlpha','DecisionStressAtSavedAlpha', ...
    'FutureMaxDecisionStress_1step', ...
    'ActualMaxAbsDf_Hz','ActualMaxAbsRoCoF_Hz_s', ...
    'ActualSecurityStress','CoIUnsafe','OverallFreqUnsafe', ...
    'OODFallback','MissingFeatureFallback','NoSafeCandidateFallback', ...
    'F1CoISafeSameStep'});

fprintf('\n=============================================================\n');
fprintf(' P1 PREDICTIVE SAFETY-SHIELD SCREEN -- NO SIMULATION\n');
fprintf('=============================================================\n');
fprintf('P1 file  : %s\n',p1File);
fprintf('F1 file  : %s\n',f1File);
fprintf('model    : %s\n',modelFile);
fprintf('CoI unsafe intervals: %s\n',mat2str(find(coiUnsafe).'));
fprintf('=============================================================\n');

fprintf('\nCritical neighborhood (steps 27:35):\n');
disp(stepTable(27:35,:));

%% ------------------------------------------------------------------------
% Candidate shield rules
% -------------------------------------------------------------------------
% Each rule means:
%   if trigger is true -> proposed corrected alpha = 1.0
%   otherwise          -> keep saved KRR/P1 alpha
%
% This test evaluates DETECTION and RESERVE BURDEN only.
% It does NOT claim the corrected physical frequency without a rerun.

ruleRows = table();

% Baseline reference: current KRR P1 (no post correction)
ruleRows = append_rule_local(ruleRows, ...
    "BASE","Current P1, no post-KRR correction", ...
    false(n,1),alphaSaved,coiUnsafe,f1CoISafe,NaN,NaN,NaN);

% 1) Current absolute-ramp trigger.
for r = rampGrid
    trig = absRamp>=r;
    ruleRows = append_rule_local(ruleRows, ...
        "RAMP",sprintf('absRamp >= %.3f',r), ...
        trig,alphaSaved,coiUnsafe,f1CoISafe,r,NaN,NaN);
end

% 2) High ramp + LOW headroom.
for r = rampGrid
    for h = headroomGrid
        trig = absRamp>=r & headroom<=h;
        ruleRows = append_rule_local(ruleRows, ...
            "RAMP_LOW_HEAD", ...
            sprintf('absRamp >= %.3f AND headroom <= %.3f',r,h), ...
            trig,alphaSaved,coiUnsafe,f1CoISafe,r,h,NaN);
    end
end

% 3) High ramp + HIGH headroom.
% Included explicitly because this is one of the user's proposed correction
% hypotheses.  The screen will tell us whether it catches the unsafe states.
for r = rampGrid
    for h = headroomGrid
        trig = absRamp>=r & headroom>=h;
        ruleRows = append_rule_local(ruleRows, ...
            "RAMP_HIGH_HEAD", ...
            sprintf('absRamp >= %.3f AND headroom >= %.3f',r,h), ...
            trig,alphaSaved,coiUnsafe,f1CoISafe,r,h,NaN);
    end
end

% 4) KRR risk margin alone: intervene before the nominal stress limit of 1.
for s = stressGrid
    trig = decAtSelected>=s;
    ruleRows = append_rule_local(ruleRows, ...
        "KRR_MARGIN",sprintf('decisionStress >= %.3f',s), ...
        trig,alphaSaved,coiUnsafe,f1CoISafe,NaN,NaN,s);
end

% 5) Ramp OR KRR margin.
for r = rampGrid
    for s = stressGrid
        trig = absRamp>=r | decAtSelected>=s;
        ruleRows = append_rule_local(ruleRows, ...
            "RAMP_OR_KRR", ...
            sprintf('absRamp >= %.3f OR decisionStress >= %.3f',r,s), ...
            trig,alphaSaved,coiUnsafe,f1CoISafe,r,NaN,s);
    end
end

% 6) Ramp AND KRR margin.
for r = rampGrid
    for s = stressGrid
        trig = absRamp>=r & decAtSelected>=s;
        ruleRows = append_rule_local(ruleRows, ...
            "RAMP_AND_KRR", ...
            sprintf('absRamp >= %.3f AND decisionStress >= %.3f',r,s), ...
            trig,alphaSaved,coiUnsafe,f1CoISafe,r,NaN,s);
    end
end

% 7) One-step LOOK-AHEAD proxy using next saved-state ramp.
for r = rampGrid
    trig = futureMaxRamp1>=r;
    trig(end)=false;
    ruleRows = append_rule_local(ruleRows, ...
        "LOOKAHEAD_RAMP", ...
        sprintf('max(current,next) absRamp >= %.3f',r), ...
        trig,alphaSaved,coiUnsafe,f1CoISafe,r,NaN,NaN);
end

% 8) Look-ahead ramp + minimum headroom across current/next state.
for r = rampGrid
    for h = headroomGrid
        trig = futureMaxRamp1>=r & futureMinHead1<=h;
        trig(end)=false;
        ruleRows = append_rule_local(ruleRows, ...
            "LOOKAHEAD_RAMP_LOW_HEAD", ...
            sprintf('futureRamp >= %.3f AND futureMinHead <= %.3f',r,h), ...
            trig,alphaSaved,coiUnsafe,f1CoISafe,r,h,NaN);
    end
end

% 9) Look-ahead ramp + maximum headroom across current/next state.
for r = rampGrid
    for h = headroomGrid
        trig = futureMaxRamp1>=r & futureMaxHead1>=h;
        trig(end)=false;
        ruleRows = append_rule_local(ruleRows, ...
            "LOOKAHEAD_RAMP_HIGH_HEAD", ...
            sprintf('futureRamp >= %.3f AND futureMaxHead >= %.3f',r,h), ...
            trig,alphaSaved,coiUnsafe,f1CoISafe,r,h,NaN);
    end
end

% 10) Signed direction: fast net-load decrease (e.g. morning PV increase).
for dth = signedGrid
    trig = signedNetChange1<=-dth;
    trig(end)=false;
    ruleRows = append_rule_local(ruleRows, ...
        "NET_DROP", ...
        sprintf('next net-load change <= -%.3f',dth), ...
        trig,alphaSaved,coiUnsafe,f1CoISafe,NaN,NaN,dth);
end

% 11) Signed direction: fast net-load increase.
for dth = signedGrid
    trig = signedNetChange1>=dth;
    trig(end)=false;
    ruleRows = append_rule_local(ruleRows, ...
        "NET_RISE", ...
        sprintf('next net-load change >= %.3f',dth), ...
        trig,alphaSaved,coiUnsafe,f1CoISafe,NaN,NaN,dth);
end

% 12) Large signed change magnitude.
for dth = signedGrid
    trig = absSignedNetChange1>=dth;
    trig(end)=false;
    ruleRows = append_rule_local(ruleRows, ...
        "NET_CHANGE_MAG", ...
        sprintf('|next net-load change| >= %.3f',dth), ...
        trig,alphaSaved,coiUnsafe,f1CoISafe,NaN,NaN,dth);
end

%% Rank rules
% Primary objective:
%   1) miss zero actual CoI-unsafe intervals;
%   2) among zero-miss rules, trigger as few intervals as possible;
%   3) then minimize mean corrected alpha.

ruleRows = sortrows(ruleRows, ...
    {'MissedUnsafe','TriggerCount','MeanCorrectedAlpha','FalseTriggerCount'}, ...
    {'ascend','ascend','ascend','ascend'});

zeroMiss = ruleRows(ruleRows.MissedUnsafe==0,:);

fprintf('\n=============================================================\n');
fprintf(' TOP ZERO-MISS SHIELD CANDIDATES\n');
fprintf('=============================================================\n');

if isempty(zeroMiss)
    fprintf('No screened rule captures every CoI-unsafe interval.\n');
else
    disp(zeroMiss(1:min(TOP_N,height(zeroMiss)),:));
end

%% Best candidate by rule family
fprintf('\n=============================================================\n');
fprintf(' BEST ZERO-MISS CANDIDATE BY RULE FAMILY\n');
fprintf('=============================================================\n');

families = unique(ruleRows.RuleFamily,'stable');
bestFamily = table();

for i = 1:numel(families)
    T = ruleRows(ruleRows.RuleFamily==families(i) & ...
                 ruleRows.MissedUnsafe==0,:);
    if isempty(T)
        continue;
    end
    one = T(1,:);
    if isempty(bestFamily)
        bestFamily = one;
    else
        bestFamily = [bestFamily;one]; %#ok<AGROW>
    end
end

disp(bestFamily);

%% Explicitly inspect the user's "high ramp + high headroom" hypothesis
fprintf('\n=============================================================\n');
fprintf(' HIGH-RAMP + HIGH-HEADROOM HYPOTHESIS\n');
fprintf('=============================================================\n');

RH = ruleRows(ruleRows.RuleFamily=="RAMP_HIGH_HEAD",:);
RH = sortrows(RH, ...
    {'MissedUnsafe','TriggerCount','MeanCorrectedAlpha'}, ...
    {'ascend','ascend','ascend'});

disp(RH(1:min(15,height(RH)),:));

%% Show which rules trigger steps 31/32
fprintf('\n=============================================================\n');
fprintf(' CRITICAL-STEP FEATURE VALUES\n');
fprintf('=============================================================\n');

crit = stepTable(ismember(stepTable.MPCStep,[31 32]),:);
disp(crit);

fprintf(['\nInterpretation reminder:\n', ...
    '- A rule that catches steps 31/32 is only a candidate safety shield.\n', ...
    '- "MeanCorrectedAlpha" is the reserve burden if trigger -> alpha=1.\n', ...
    '- "F1SafeOnTriggeredRate" is supporting evidence from the saved F1 run,\n', ...
    '  not a substitute for the final exact P1 closed-loop rerun.\n', ...
    '- LOOKAHEAD_* rules use future saved states only as diagnostic proxies.\n']);

%% Export
if EXPORT_CSV
    outDir = fullfile(runRoot,'diagnostics','P1_predictive_shield_screen');
    if ~exist(outDir,'dir')
        mkdir(outDir);
    end

    writetable(stepTable,fullfile(outDir,'per_step_diagnostics.csv'));
    writetable(ruleRows,fullfile(outDir,'all_shield_rule_screen.csv'));
    writetable(zeroMiss,fullfile(outDir,'zero_miss_shield_candidates.csv'));
    if ~isempty(bestFamily)
        writetable(bestFamily,fullfile(outDir,'best_zero_miss_by_family.csv'));
    end

    fprintf('\nDiagnostics exported to:\n  %s\n',outDir);
end

fprintf('\n=============================================================\n');
fprintf(' WHAT TO SEND BACK\n');
fprintf('=============================================================\n');
fprintf(['Please send:\n', ...
    '  1) TOP ZERO-MISS SHIELD CANDIDATES;\n', ...
    '  2) BEST ZERO-MISS CANDIDATE BY RULE FAMILY;\n', ...
    '  3) HIGH-RAMP + HIGH-HEADROOM HYPOTHESIS;\n', ...
    '  4) CRITICAL-STEP FEATURE VALUES.\n']);
fprintf('=============================================================\n');


%% =========================================================================
% Local helpers
% =========================================================================

function T = append_rule_local(T,family,description,trig,alphaBase,unsafe,f1Safe,p1,p2,p3)

trig = logical(trig(:));
unsafe = logical(unsafe(:));

correctedAlpha = alphaBase(:);
correctedAlpha(trig) = 1.0;

nUnsafe = nnz(unsafe);
captured = nnz(trig & unsafe);
missed = nnz(~trig & unsafe);
falseTrig = nnz(trig & ~unsafe);
triggerCount = nnz(trig);

if nUnsafe>0
    captureRate = captured/nUnsafe;
else
    captureRate = NaN;
end

if triggerCount>0
    f1SafeRate = mean(double(f1Safe(trig)));
else
    f1SafeRate = NaN;
end

one = table();
one.RuleFamily = string(family);
one.Description = string(description);
one.TriggerCount = triggerCount;
one.CapturedUnsafe = captured;
one.MissedUnsafe = missed;
one.CaptureRate = captureRate;
one.FalseTriggerCount = falseTrig;
one.MeanOriginalAlpha = mean(alphaBase,'omitnan');
one.MeanCorrectedAlpha = mean(correctedAlpha,'omitnan');
one.MeanAlphaIncrease = one.MeanCorrectedAlpha-one.MeanOriginalAlpha;
one.F1SafeOnTriggeredRate = f1SafeRate;
one.Param1 = p1;
one.Param2 = p2;
one.Param3 = p3;

if isempty(T)
    T = one;
else
    T = [T;one]; %#ok<AGROW>
end
end


function filePath = find_one_result_local(methodDir,caseName,decayRatio,seed)

decayCode = round(100*decayRatio);

pattern = sprintf('%s_*_decay%03d_seed%03d_*.mat', ...
    caseName,decayCode,seed);

hits = dir(fullfile(methodDir,pattern));

assert(~isempty(hits), ...
    'No saved result found in %s matching %s.',methodDir,pattern);

assert(numel(hits)==1, ...
    'Expected one matching result in %s; found %d.', ...
    methodDir,numel(hits));

filePath = fullfile(hits(1).folder,hits(1).name);
end


function result = load_result_local(filePath)

S = load(filePath);

if isfield(S,'result') && isstruct(S.result)
    result = S.result;
    return;
end

names = fieldnames(S);

for k = 1:numel(names)
    x = S.(names{k});
    if isstruct(x) && (isfield(x,'summary') || isfield(x,'reserve'))
        result = x;
        return;
    end
end

error('Could not identify result struct in %s.',filePath);
end
