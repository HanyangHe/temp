% Static contract test for step-65 terminal-constraint diagnostic hook.
root=fileparts(fileparts(mfilename('fullpath')));
eng=fileread(fullfile(root,'core','engine','engine_island_ems.m'));
tst=fileread(fullfile(root,'tests','diagnose_P1_step65_terminal_constraint_ablation.m'));
assert(contains(eng,'terminalConstraintAblation'));
assert(contains(eng,'DROP_BESS1_HORIZON_END'));
assert(contains(eng,'DROP_ALL_BESS_HORIZON_END'));
assert(contains(eng,'DROP_ALL_EV_HORIZON_END'));
assert(contains(eng,'DROP_ALL_STORAGE_HORIZON_END'));
assert(contains(tst,'terminalConstraintAblation', 'IgnoreCase',false));
fprintf('Step-65 terminal-constraint ablation contract test passed.\n');
