%% AI feature/sign and centralized-system configuration checks
cfg=config_island_ems();
validate_config(cfg);

% Revised 15-min MPC time-base contract.
assert(abs(cfg.mpc.decisionInterval_h-0.25)<1e-12,'Default MPC decision interval must be 15 min.');
assert(abs(cfg.mpc.predictionStep_h-0.25)<1e-12,'Default MPC prediction step must be 15 min.');
assert(cfg.mpc.decisionLevelSteps==96,'15-min MPC must perform 96 updates/day.');
assert(cfg.mpc.predictionHorizon==96,'24-h/15-min MPC horizon must contain 96 stages.');
assert(abs(cfg.forecast.nativeStep_h-1)<1e-12,'Inherited KRR forecast native step must remain hourly.');

% Anchor-resampling contract: 25 hourly anchors -> 96 15-min stages.
yAnchor=0:24;
yFine=resample_horizon_anchors(yAnchor,1,0.25,24,'linear');
assert(numel(yFine)==96 && abs(yFine(2)-0.25)<1e-12 && abs(yFine(end)-23.75)<1e-12, ...
    'Hourly-to-15-min forecast resampling failed.');

% Formal AI feature contract: exactly three physics variables.
expectedNames={'netLoadNow_pu','absNetLoadRamp_pu','dgUpHeadroom_pu'};
assert(isequal(reserve_feature_names(),expectedNames), ...
    'Formal AI reserve feature names must be exactly the frozen three-feature set.');

% Loads are negative network injections; PV is positive injection.
Sload=zeros(3,4);
Sload(2,:)=-[0.20 0.24 0.22 0.21];
Sload(3,:)=-[0.10 0.11 0.12 0.12];
Ppv=zeros(3,4);
Ppv(2,:)=[0.05 0.08 0.10 0.09];
DGPrate=[0.14 0.14];
headroom=0.35;
feat=build_reserve_features(Sload,Ppv,DGPrate,headroom);
expectedNet=(0.30-0.05)/0.28;
expectedRamp=abs((0.35-0.08)-(0.30-0.05))/0.28;
assert(numel(feat)==3,'Formal AI feature vector must have exactly three entries.');
assert(abs(feat(1)-expectedNet)<1e-12,'Net-load feature has an incorrect sign/base.');
assert(abs(feat(2)-expectedRamp)<1e-12,'Absolute net-load ramp feature is incorrect.');
assert(abs(feat(3)-headroom)<1e-12,'DG upward-headroom feature is incorrect.');

% Missing first-step headroom must remain missing, not be silently replaced.
feat0=build_reserve_features(Sload,Ppv,DGPrate,NaN);
assert(isnan(feat0(3)),'Missing causal SG headroom must remain NaN for fallback handling.');

% Formal paper cases are radial.
s18=system_case_catalog('18bus',cfg);
assert(strcmp(s18.CaseName,'18bus') && strcmp(s18.Topology,'18bus-CIRED'));
assert(numel(s18.DieselG_Pgfm_rate)==2 && all(abs(s18.DieselG_Pgfm_rate(:)-0.14)<1e-12));
assert(numel(s18.BatteryGFL_P_rate)==3 && all(abs(s18.BatteryGFL_P_rate(:)-0.10)<1e-12));

s33=system_case_catalog('33bus',cfg);
assert(strcmp(s33.CaseName,'33bus') && strcmp(s33.Topology,'33bus-IEEE'));
assert(numel(s33.BatteryGFL_P_rate)==4,'Uploaded 33-bus code contains four BESS units.');
E33=s33.BatteryGFL_P_rate(:)*cfg.storage.bessDuration_h;
assert(numel(unique(E33))>1,'Per-device BESS energy capacities should preserve heterogeneous ratings.');

assert(cfg.ev.terminalNumericalSlackMax==0, ...
    'Unreported legacy EV terminal numerical slack must remain disabled by default.');
fprintf('Feature/configuration and frozen three-feature AI contract audit passed.\n');
