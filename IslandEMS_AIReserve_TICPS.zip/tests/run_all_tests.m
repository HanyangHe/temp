%% Static/unit checks before any full simulation
% clear; clc;
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(genpath(projectRoot));

test_reserve_units;
test_dg_base_convention;
test_baseline_catalog;
test_solver_diagnostics;
test_soc_numerical_guard;
test_sparse_soc_equivalence;
test_radial_study_policy;
test_project_audit;
test_feature_and_config;
test_ai_feature_contract;
test_ai_response_pipeline_contract;
if exist('test_ai_incremental_dataset_contract','file'), test_ai_incremental_dataset_contract; end
if exist('test_response_generation_resume_contract','file'), test_response_generation_resume_contract; end
test_ai_response_model_synthetic;
test_ai_asset_layout_contract;
test_objective_convention;
test_legacy_refinement_removed;
test_radial_angle_recovery_guard;

fprintf('\nAll revised-project unit/static tests passed.\n');
