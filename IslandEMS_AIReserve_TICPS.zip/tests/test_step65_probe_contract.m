%% Static contract for exact-state step-65 feasibility diagnostic.
clearvars -except projectRoot
if ~exist('projectRoot','var') || isempty(projectRoot)
    projectRoot=fileparts(fileparts(mfilename('fullpath')));
end
engineFile=fullfile(projectRoot,'core','engine','engine_island_ems.m');
testFile=fullfile(projectRoot,'tests','diagnose_P1_step65_feasibility.m');
assert(exist(engineFile,'file')==2 && exist(testFile,'file')==2);
e=fileread(engineFile); t=fileread(testFile);
assert(contains(e,'feasibilityProbe') && contains(e,'probeAlphaGrid'));
assert(contains(e,'IslandEMSStepReserveFeasibilityProbeV1'));
assert(contains(t,'CURRENT_STEP_BACKTRACKING_CAN_RESTORE_FEASIBILITY'));
assert(contains(t,'RECURSIVE_STATE_INFEASIBILITY'));
fprintf('Step-65 exact-state feasibility-probe contract test passed.\n');
