%% smoke_P1_frequency_safety_18bus.m
% Focused P1 frequency-safety smoke test for the Part-I normal case.
%
% PURPOSE
% -------
% Fast iteration while repairing P1 reserve selection / safety enforcement.
%
% Part I scope is fixed:
%   caseName   = 18bus
%   decayRatio = 1.00
%   methods    = F1(T7) reference and P1
%
% The script has two modes:
%
%   1) diagnosticOnly (default)
%      Loads the existing saved F1/P1 normal-case results, identifies the
%      frequency-unsafe intervals, and prints a concise forensic report.
%      NO optimization or physical simulation.
%
%   2) exact P1 regression
%      Set RUN_EXACT_P1 = true.  The script reruns ONLY P1 at decay=1.00,
%      with no result persistence and no figures, then applies hard PASS/FAIL
%      frequency criteria.  F1 is NOT rerun.
%
% HARD ACCEPTANCE CRITERIA
% ------------------------
%   max |Delta f_CoI| <= cfg.frequency.securityDeviation_Hz
%   max |RoCoF_CoI|   <= cfg.frequency.securityRoCoF_Hz_s
%   securityViolationRate == 0
%
% This is intentionally stricter than "AI prediction looks safe".  The final
% implemented alpha must be safe in the physical closed-loop response.

clear;
clc;

%% User switch
RUN_EXACT_P1 = false;   % false = instant saved-result diagnosis
                        % true  = rerun P1 only (full exact physical test)

FORMAL_RUN_TAG = '20260907_115951';

%% Project setup
projectRoot = pwd;
addpath(genpath(projectRoot));
rehash;

cfg = config_island_ems();

caseName = '18bus';
decayRatio = 1.00;
seed = 0;

dfLimit = cfg.frequency.securityDeviation_Hz;
rocofLimit = cfg.frequency.securityRoCoF_Hz_s;
f0 = cfg.frequency.nominal_Hz;

fprintf('\n=============================================================\n');
fprintf(' P1 FREQUENCY-SAFETY SMOKE TEST\n');
fprintf('=============================================================\n');
fprintf(' case        : %s\n',caseName);
fprintf(' decayRatio  : %.2f (Part-I normal case)\n',decayRatio);
fprintf(' |df| limit  : %.4f Hz\n',dfLimit);
fprintf(' RoCoF limit : %.4f Hz/s\n',rocofLimit);
fprintf(' exact rerun : %d\n',RUN_EXACT_P1);
fprintf('=============================================================\n');

%% ------------------------------------------------------------------------
%  Stage A -- Load current saved F1 and P1 reference results
% -------------------------------------------------------------------------

runRoot = fullfile(projectRoot,cfg.output.root,FORMAL_RUN_TAG);

assert(exist(runRoot,'dir')==7, ...
    'Formal run folder not found: %s',runRoot);

f1File = find_one_result_local( ...
    fullfile(runRoot,'T7'),caseName,decayRatio,seed);

p1File = find_one_result_local( ...
    fullfile(runRoot,'P1'),caseName,decayRatio,seed);

F1 = load_result_local(f1File);
P1saved = load_result_local(p1File);

fprintf('\nSaved references:\n');
fprintf('  F1 : %s\n',f1File);
fprintf('  P1 : %s\n',p1File);

f1Metrics = frequency_metrics_local(F1,cfg);
p1Metrics = frequency_metrics_local(P1saved,cfg);

fprintf('\nCurrent saved-result comparison\n');
print_metrics_local('F1',f1Metrics);
print_metrics_local('P1',p1Metrics);

fprintf('\nCurrent P1 reserve diagnostics\n');
fprintf('  Mean alpha                    : %.6g\n', ...
    get_summary_local(P1saved,'meanReserveRatio',NaN));
fprintf('  Std alpha                     : %.6g\n', ...
    get_summary_local(P1saved,'stdReserveRatio',NaN));
fprintf('  Mean total DG reserve (kW)    : %.6g\n', ...
    get_summary_local(P1saved,'meanTotalDGReserve_kW',NaN));
fprintf('  OOD fallback rate             : %.6g\n', ...
    get_summary_local(P1saved,'aiOODFallbackRate',NaN));
fprintf('  No-safe-candidate fallback    : %.6g\n', ...
    get_summary_local(P1saved,'aiNoSafeCandidateFallbackRate',NaN));

%% Identify unsafe physical intervals in the current saved P1
bad = unsafe_intervals_local(P1saved,cfg);

fprintf('\nCurrent saved P1 unsafe intervals\n');

if isempty(bad)
    fprintf('  none\n');
else
    disp(bad);
end

%% ------------------------------------------------------------------------
%  Stage B -- Exact P1-only rerun after a code change
% -------------------------------------------------------------------------

if RUN_EXACT_P1

    fprintf('\n=============================================================\n');
    fprintf(' RUNNING EXACT P1 NORMAL-CASE REGRESSION\n');
    fprintf(' This runs P1 only; no output files are persisted.\n');
    fprintf('=============================================================\n');

    catalog = paper_method_catalog();
    ids = string({catalog.id});

    idx = find(ids=="P1",1);
    assert(~isempty(idx),'P1 is missing from paper_method_catalog().');

    runCfg = catalog(idx);

    runCfg.caseName = caseName;
    runCfg.dayType = cfg.scenario.dayType;
    runCfg.decayRatio = decayRatio;
    runCfg.randomSeed = seed;

    % Smoke-test output policy
    cfg.output.showFigures = false;
    cfg.output.saveResults = false;

    result = run_single_experiment( ...
        cfg,runCfg,projectRoot,'',false);

    m = frequency_metrics_local(result,cfg);

    fprintf('\nExact P1 regression result\n');
    print_metrics_local('P1-new',m);

    fprintf('\nReserve diagnostics\n');
    fprintf('  Mean alpha                    : %.6g\n', ...
        get_summary_local(result,'meanReserveRatio',NaN));
    fprintf('  Std alpha                     : %.6g\n', ...
        get_summary_local(result,'stdReserveRatio',NaN));
    fprintf('  OOD fallback rate             : %.6g\n', ...
        get_summary_local(result,'aiOODFallbackRate',NaN));
    fprintf('  No-safe-candidate fallback    : %.6g\n', ...
        get_summary_local(result,'aiNoSafeCandidateFallbackRate',NaN));

    badNew = unsafe_intervals_local(result,cfg);

    if ~isempty(badNew)
        fprintf('\nUnsafe intervals after the code change:\n');
        disp(badNew);
    end

    % HARD regression gates.
    tol = 1e-9;

    assert(m.maxAbsDf_Hz <= dfLimit + tol, ...
        ['P1 FREQUENCY-SAFETY FAIL: max |Delta f_CoI| = %.6g Hz ', ...
         '> %.6g Hz.'],m.maxAbsDf_Hz,dfLimit);

    assert(m.maxAbsRoCoF_Hz_s <= rocofLimit + tol, ...
        ['P1 FREQUENCY-SAFETY FAIL: max |RoCoF_CoI| = %.6g Hz/s ', ...
         '> %.6g Hz/s.'],m.maxAbsRoCoF_Hz_s,rocofLimit);

    if isfinite(m.securityViolationRate)
        assert(m.securityViolationRate <= tol, ...
            ['P1 FREQUENCY-SAFETY FAIL: securityViolationRate = %.6g, ', ...
             'expected zero.'],m.securityViolationRate);
    end

    fprintf('\n=============================================================\n');
    fprintf(' P1 FREQUENCY-SAFETY SMOKE TEST: PASS\n');
    fprintf('=============================================================\n');
end


%% =========================================================================
% Local helpers
% =========================================================================

function filePath = find_one_result_local(methodDir,caseName,decayRatio,seed)

decayCode = round(100*decayRatio);

pattern = sprintf('%s_*_decay%03d_seed%03d_*.mat', ...
    caseName,decayCode,seed);

hits = dir(fullfile(methodDir,pattern));

assert(~isempty(hits), ...
    'No saved result found in %s matching %s.',methodDir,pattern);

assert(numel(hits)==1, ...
    'Expected one result in %s matching %s, found %d.', ...
    methodDir,pattern,numel(hits));

filePath = fullfile(hits(1).folder,hits(1).name);
end


function result = load_result_local(filePath)

S = load(filePath);

if isfield(S,'result') && isstruct(S.result)
    result = S.result;
    return;
end

names = fieldnames(S);

for k = 1:numel(names)
    x = S.(names{k});

    if isstruct(x) && ...
            (isfield(x,'summary') || ...
             isfield(x,'freq_Hz') || ...
             isfield(x,'totalCost'))
        result = x;
        return;
    end
end

error('Could not identify result struct in %s.',filePath);
end


function m = frequency_metrics_local(result,cfg)

m = struct();

m.maxAbsDf_Hz = get_summary_local(result,'maxAbsFreqDev_Hz',NaN);
m.maxAbsRoCoF_Hz_s = get_summary_local(result,'maxAbsRoCoF_Hz_s',NaN);
m.securityViolationRate = ...
    get_summary_local(result,'securityViolationRate',NaN);

% Fallback calculation from trajectory if summary fields are unavailable.
if isfield(result,'freq_Hz') && ~isempty(result.freq_Hz)

    f = real(double(result.freq_Hz(:)));

    if ~isfinite(m.maxAbsDf_Hz)
        m.maxAbsDf_Hz = max(abs(f-cfg.frequency.nominal_Hz),[],'omitnan');
    end

    [tSec,ok] = time_seconds_local(result,numel(f));

    if ok
        r = gradient(f,tSec);

        if ~isfinite(m.maxAbsRoCoF_Hz_s)
            m.maxAbsRoCoF_Hz_s = max(abs(r),[],'omitnan');
        end
    end
end
end


function bad = unsafe_intervals_local(result,cfg)
% Create a per-15-min forensic table from the saved CoI trajectory.
%
% This is diagnostic only.  It lets us see exactly where the present P1
% violates physical safety without rerunning the full simulation.

bad = table();

if ~isfield(result,'freq_Hz') || isempty(result.freq_Hz)
    return;
end

f = real(double(result.freq_Hz(:)));
n = numel(f);

[tSec,ok] = time_seconds_local(result,n);

if ~ok
    % Evenly map the saved trajectory onto 24 h if no explicit time vector
    % exists.  This is sufficient for locating the responsible MPC block.
    tSec = linspace(0,24*3600,n).';
end

if n<2
    return;
end

r = gradient(f,tSec);

nMPC = 96;
edges = linspace(0,24*3600,nMPC+1);

step = zeros(nMPC,1);
start_h = zeros(nMPC,1);
maxDf = nan(nMPC,1);
maxR = nan(nMPC,1);
freqFail = false(nMPC,1);
rocofFail = false(nMPC,1);

for k = 1:nMPC

    if k<nMPC
        idx = tSec>=edges(k) & tSec<edges(k+1);
    else
        idx = tSec>=edges(k) & tSec<=edges(k+1);
    end

    step(k) = k;
    start_h(k) = edges(k)/3600;

    if ~any(idx)
        continue;
    end

    maxDf(k) = max(abs(f(idx)-cfg.frequency.nominal_Hz),[],'omitnan');
    maxR(k) = max(abs(r(idx)),[],'omitnan');

    freqFail(k) = maxDf(k) > cfg.frequency.securityDeviation_Hz + 1e-9;
    rocofFail(k) = maxR(k) > cfg.frequency.securityRoCoF_Hz_s + 1e-9;
end

T = table(step,start_h,maxDf,maxR,freqFail,rocofFail, ...
    'VariableNames',{ ...
    'MPCStep','StartTime_h','MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s', ...
    'FreqViolation','RoCoFViolation'});

bad = T(T.FreqViolation | T.RoCoFViolation,:);
end


function [tSec,ok] = time_seconds_local(result,n)

ok = false;
tSec = [];

if isfield(result,'time_h') && ~isempty(result.time_h)
    t = double(result.time_h(:));

    if numel(t)==n
        tSec = t*3600;
        ok = all(isfinite(tSec)) && all(diff(tSec)>0);
        return;
    end
end

if isfield(result,'time_s') && ~isempty(result.time_s)
    t = double(result.time_s(:));

    if numel(t)==n
        tSec = t;
        ok = all(isfinite(tSec)) && all(diff(tSec)>0);
        return;
    end
end
end


function value = get_summary_local(result,name,defaultValue)

value = defaultValue;

if isfield(result,name)
    x = result.(name);

    if (isnumeric(x) || islogical(x)) && isscalar(x)
        value = double(x);
        return;
    end
end

if ~isfield(result,'summary') || isempty(result.summary)
    return;
end

s = result.summary;

if isstruct(s) && isfield(s,name)
    x = s.(name);

    if (isnumeric(x) || islogical(x)) && isscalar(x)
        value = double(x);
    end

elseif istable(s) && ismember(name,s.Properties.VariableNames)

    x = s.(name);

    if isnumeric(x) && ~isempty(x)
        value = double(x(1));
    end
end
end


function print_metrics_local(label,m)

fprintf('  %-8s max|df| = %.6f Hz | max|RoCoF| = %.6f Hz/s | violationRate = %.6g\n', ...
    label,m.maxAbsDf_Hz,m.maxAbsRoCoF_Hz_s,m.securityViolationRate);
end
