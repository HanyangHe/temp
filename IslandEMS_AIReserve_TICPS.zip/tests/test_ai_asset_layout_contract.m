%% Canonical AI dataset/model asset layout contract (no simulation)
projectRoot=fileparts(fileparts(mfilename('fullpath')));
addpath(genpath(projectRoot));
cfg=config_island_ems();

assert(strcmp(cfg.ai.modelRoot,fullfile('ai','models')),'AI modelRoot must be ai/models.');
assert(strcmp(cfg.ai.datasetRoot,fullfile('ai','datasets')),'AI datasetRoot must be ai/datasets.');
assert(strcmp(cfg.ai.modelFileName,'reserve_krr_model.mat'),'Unexpected AI model file name.');
assert(strcmp(cfg.ai.datasetFileName,'reserve_response_dataset_paper.mat'),'Unexpected AI dataset file name.');

cases={'10bus','18bus','33bus'};
mp=strings(numel(cases),1); dp=strings(numel(cases),1);
for i=1:numel(cases)
    mp(i)=string(get_ai_reserve_model_file(projectRoot,cfg,cases{i}));
    dp(i)=string(get_ai_reserve_dataset_file(projectRoot,cfg,cases{i}));
    assert(contains(mp(i),fullfile('ai','models',cases{i})),'Model path is not per-grid canonical.');
    assert(contains(dp(i),fullfile('ai','datasets',cases{i})),'Dataset path is not per-grid canonical.');
end
assert(numel(unique(mp))==3 && numel(unique(dp))==3,'Per-grid AI asset paths must be unique.');

trainTxt=fileread(fullfile(projectRoot,'train_AIReserve.m'));
assert(contains(trainTxt,'publish_ai_reserve_dataset'),'train_AIReserve must publish a canonical dataset.');
findTxt=fileread(fullfile(projectRoot,'ai','find_latest_compatible_response_dataset.m'));
assert(contains(findTxt,'get_ai_reserve_dataset_file'),'Reusable-data search must prefer canonical ai/datasets assets.');

fprintf('Canonical per-grid AI dataset/model asset-layout contract test passed.\n');
