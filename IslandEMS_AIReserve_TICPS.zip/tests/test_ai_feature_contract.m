%% Formal AI feature contract and no-leakage source audit
names=reserve_feature_names();
expected={'netLoadNow_pu','absNetLoadRamp_pu','dgUpHeadroom_pu'};
assert(isequal(names,expected),'AI feature contract changed unexpectedly.');

projectRoot=fileparts(fileparts(mfilename('fullpath')));
buildTxt=fileread(fullfile(projectRoot,'ai','build_reserve_features.m'));
engineTxt=fileread(fullfile(projectRoot,'core','engine','engine_island_ems.m'));

% Previously screened-out variables must not be formal learner inputs.
for token={'evAvailability','timeSin','timeCos','pvFractionNow','absPVRamp_pu','bessMeanSOC'}
    assert(~contains(buildTxt,token{1}), ...
        'Screened-out feature %s re-entered build_reserve_features.m.',token{1});
end

% Headroom must be based on the previous realized physical SG sample.
assert(contains(engineTxt,'P_DG(:,RealStep-1)'), ...
    'DG headroom must use the pre-decision realized SG output.');
assert(contains(engineTxt,'dgUpHeadroom_pu'), ...
    'Engine is missing the causal DG upward-headroom feature.');

fprintf('Frozen three-feature AI/no-leakage contract test passed.\n');
