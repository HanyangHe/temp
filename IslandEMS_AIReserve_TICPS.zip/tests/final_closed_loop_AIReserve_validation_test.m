function report = final_closed_loop_AIReserve_validation_test()
%FINAL_CLOSED_LOOP_AIRESERVE_VALIDATION_TEST
% Focused scientific closed-loop validation before formal mainV4 runs.
%
% Compares, on exactly the same representative scenario:
%   G1  : globally tuned fixed reserve ratio
%   T7  : conventional full physics reserve (alpha = 1)
%   P1U : learned state-dependent reserve without safety calibration
%   P1  : proposed learned reserve with one-sided safety calibration
%
% Scenario (fixed for this validation):
%   case    = 18bus (radial)
%   day     = Unusual day
%   decay   = 1.00
%   seed    = 0
%   MPC     = 15 min / 24 h horizon
%
% IMPORTANT
% - This is NOT a formal paper sweep and writes nothing to outputs/.
% - A small resume checkpoint is stored only in MATLAB tempdir so a long
%   validation is not lost if MATLAB stops between methods.
% - The checkpoint stores compact signals only (frequency, alpha, interval
%   metrics and summaries), not the full 86400-point network state arrays.
% - On successful completion the temporary checkpoint is deleted.
%
% Usage from project root:
%   addpath(genpath(pwd));
%   report = final_closed_loop_AIReserve_validation_test();
%
% Expected scientific pattern (not hard-coded as a pass/fail requirement):
%   G1 : economical, potentially less secure
%   T7 : most conservative fixed reserve (alpha=1)
%   P1 : ideally approaches T7 security with lower reserve/cost
%   P1U: isolates the effect of one-sided safety calibration

clc;
thisFile = mfilename('fullpath');
projectRoot = fileparts(fileparts(thisFile)); % file should live in tests/
if ~is_project_root(projectRoot)
    candidate = pwd;
    if is_project_root(candidate)
        projectRoot = candidate;
    else
        cfgHit = which('config_island_ems');
        if ~isempty(cfgHit)
            candidate = fileparts(fileparts(cfgHit));
            if is_project_root(candidate), projectRoot = candidate; end
        end
    end
end
if ~is_project_root(projectRoot)
    error('IslandEMS:ProjectRoot', ...
        'Cannot identify project root. Run from IslandEMS_AIReserve_TICPS or put this file under tests/.');
end
addpath(genpath(projectRoot));

cfg = config_island_ems();
validate_config(cfg);

% --- Fixed focused validation scenario ----------------------------------
cfg.experiment.systemCases = {'18bus'};
cfg.scenario.dayType = 'Unusual day';
cfg.scenario.decayRatios = 1.00;
cfg.experiment.randomSeeds = 0;

% Informal-test output policy.
if ~isfield(cfg,'output'), cfg.output=struct(); end
cfg.output.saveResults = false;
cfg.output.writeSummaryCSV = false;
cfg.output.exportFigures = false;
cfg.output.showFigures = false;

% The model/dataset asset contract must be valid before spending ~1-2 h.
fprintf('\nRunning no-simulation AI asset/model preflight first...\n');
preflight = final_AIReserve_pre_main_test({'18bus'}); %#ok<NASGU>

catalog = baseline_catalog();
allIDs = string({catalog.id});
% Run G1 first to expose the low-reserve baseline, then T7, P1U, P1.
methodOrder = ["G1","T7","P1U","P1"];
for i=1:numel(methodOrder)
    assert(any(allIDs==methodOrder(i)),'Missing method %s in baseline_catalog.',methodOrder(i));
end

modelFile = get_ai_reserve_model_file(projectRoot,cfg,'18bus');
d = dir(modelFile);
if isempty(d), error('AI model missing after successful preflight: %s',modelFile); end
Smodel = load(modelFile,'model');
globalAlpha = getfield_default(Smodel.model,'globalFixedAlpha',NaN);

fprintf('\n=============================================================\n');
fprintf(' FINAL SCIENTIFIC CLOSED-LOOP AI-RESERVE VALIDATION\n');
fprintf('=============================================================\n');
fprintf(' case            : 18bus (radial)\n');
fprintf(' day / decay     : %s / %.2f\n',cfg.scenario.dayType,1.0);
fprintf(' seed            : 0\n');
fprintf(' MPC             : %.0f min decision / %.0f min prediction / %.1f h horizon\n', ...
    60*cfg.mpc.decisionInterval_h,60*cfg.mpc.predictionStep_h,cfg.mpc.horizon_h);
fprintf(' security limits : |df_CoI| <= %.3f Hz, |RoCoF_CoI| <= %.3f Hz/s\n', ...
    cfg.frequency.securityDeviation_Hz,cfg.frequency.securityRoCoF_Hz_s);
fprintf(' T7 fixed alpha  : 1.000\n');
fprintf(' G1 fixed alpha  : %.3f (training-only global baseline)\n',globalAlpha);
fprintf(' P1 online alpha : [%.2f, %.2f], fallback %.2f\n', ...
    cfg.ai.alphaMin,cfg.ai.alphaMax,cfg.ai.fallbackAlpha);
fprintf(' methods         : %s\n',strjoin(cellstr(methodOrder),', '));
fprintf(' persistence     : OFF for outputs/; compact resume cache only in tempdir\n');
fprintf('=============================================================\n\n');

% --- Resume checkpoint ---------------------------------------------------
checkpointFile = fullfile(tempdir,'IslandEMS_final_closed_loop_AIReserve_validation_checkpoint.mat');
signature = make_signature(cfg,modelFile,d);
compact = struct();
completed = strings(0,1);
if exist(checkpointFile,'file')
    try
        C = load(checkpointFile,'cache');
        if isfield(C,'cache') && isfield(C.cache,'signature') && isequaln(C.cache.signature,signature)
            compact = C.cache.compact;
            completed = string(C.cache.completed(:));
            fprintf('Resuming compatible temporary validation checkpoint: %s\n',checkpointFile);
            fprintf('Already completed: %s\n\n',strjoin(cellstr(completed),', '));
        else
            fprintf('Ignoring stale temporary validation checkpoint.\n\n');
        end
    catch ME
        fprintf('Ignoring unreadable temporary validation checkpoint (%s).\n\n',ME.message);
    end
end

failures = struct();
for im=1:numel(methodOrder)
    id = methodOrder(im);
    fieldID = char(id);
    if any(completed==id) && isfield(compact,fieldID)
        fprintf('[%s] checkpointed result found -> SKIP rerun.\n',id);
        continue
    end
    method = catalog(allIDs==id);
    runCfg = method;
    runCfg.caseName = '18bus';
    runCfg.dayType = cfg.scenario.dayType;
    runCfg.decayRatio = 1.00;
    runCfg.randomSeed = 0;

    fprintf('\n-------------------------------------------------------------\n');
    fprintf('[%s] %s\n',id,method.description);
    fprintf('-------------------------------------------------------------\n');
    tMethod = tic;
    try
        r = run_single_experiment(cfg,runCfg,projectRoot,'',false);
        compact.(fieldID) = compact_result(r,cfg);
        completed(end+1,1) = id; %#ok<AGROW>
        cache = struct('signature',signature,'compact',compact,'completed',completed); %#ok<NASGU>
        save(checkpointFile,'cache','-v7.3');
        fprintf('[%s] completed in %.2f min | cost $%.2f | max|df| %.3f Hz | max|RoCoF| %.3f Hz/s | freq violation %.2f%% | mean alpha %.3f\n', ...
            id,toc(tMethod)/60,r.summary.totalCost,r.summary.maxAbsFreqDev_Hz, ...
            r.summary.maxAbsRoCoF_Hz_s,100*r.summary.frequencyViolationRate, ...
            r.summary.meanReserveRatio);
        clear r
    catch ME
        failures.(fieldID) = ME;
        fprintf(2,'[%s] FAILED after %.2f min: %s\n',id,toc(tMethod)/60,ME.message);
        % Preserve all previously completed methods and continue so that a
        % later method can still be tested. Re-running this function resumes.
        cache = struct('signature',signature,'compact',compact,'completed',completed); %#ok<NASGU>
        save(checkpointFile,'cache','-v7.3');
    end
end

% --- Summary table -------------------------------------------------------
rows = cell(numel(methodOrder),18);
for im=1:numel(methodOrder)
    id = methodOrder(im); f=char(id);
    if isfield(compact,f)
        c=compact.(f); s=c.summary;
        rows(im,:)={id,"OK", ...
            getfield_default(s,'totalCost',NaN), ...
            getfield_default(s,'maxAbsFreqDev_Hz',NaN), ...
            getfield_default(s,'maxAbsRoCoF_Hz_s',NaN), ...
            100*getfield_default(s,'frequencyViolationRate',NaN), ...
            100*getfield_default(s,'securityViolationRate',NaN), ...
            getfield_default(s,'meanReserveRatio',NaN), ...
            getfield_default(s,'stdReserveRatio',NaN), ...
            getfield_default(s,'meanTotalDGReserve_kW',NaN), ...
            100*getfield_default(s,'aiOODFallbackRate',NaN), ...
            100*getfield_default(s,'aiNoSafeCandidateFallbackRate',NaN), ...
            100*getfield_default(s,'aiMissingFeatureFallbackRate',NaN), ...
            getfield_default(s,'maxCurrentRatio',NaN), ...
            getfield_default(s,'minVoltage_pu',NaN), ...
            getfield_default(s,'maxVoltage_pu',NaN), ...
            getfield_default(s,'meanDecisionTime_s',NaN), ...
            getfield_default(s,'totalCoupledRuntime_s',NaN)/60};
    else
        rows(im,:)={id,"FAILED",NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN};
    end
end
T = cell2table(rows,'VariableNames',{ ...
    'Method','Status','TotalCost','MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s', ...
    'FreqViolation_pct','SecurityViolation_pct','MeanAlpha','StdAlpha', ...
    'MeanDGReserve_kW','OODFallback_pct','NoSafeFallback_pct','MissingFeatureFallback_pct', ...
    'MaxCurrentRatio','MinVoltage_pu','MaxVoltage_pu','MeanDecisionTime_s','Runtime_min'});

fprintf('\n=============================================================\n');
fprintf(' CLOSED-LOOP VALIDATION SUMMARY\n');
fprintf('=============================================================\n');
disp(T);

% --- Scientific comparison ---------------------------------------------
assessment = struct();
if all(ismember(["G1","T7","P1"],completed))
    g=compact.G1.summary; t=compact.T7.summary; p=compact.P1.summary;
    gStress=max(g.maxAbsFreqDev_Hz/cfg.frequency.securityDeviation_Hz, ...
        g.maxAbsRoCoF_Hz_s/cfg.frequency.securityRoCoF_Hz_s);
    tStress=max(t.maxAbsFreqDev_Hz/cfg.frequency.securityDeviation_Hz, ...
        t.maxAbsRoCoF_Hz_s/cfg.frequency.securityRoCoF_Hz_s);
    pStress=max(p.maxAbsFreqDev_Hz/cfg.frequency.securityDeviation_Hz, ...
        p.maxAbsRoCoF_Hz_s/cfg.frequency.securityRoCoF_Hz_s);
    assessment.G1PeakStress=gStress;
    assessment.T7PeakStress=tStress;
    assessment.P1PeakStress=pStress;
    assessment.P1CostSavingVsT7_pct=100*(t.totalCost-p.totalCost)/max(abs(t.totalCost),eps);
    assessment.P1StressReductionVsG1_pct=100*(gStress-pStress)/max(abs(gStress),eps);
    assessment.P1FreqViolationReductionVsG1_pct=100*(g.frequencyViolationRate-p.frequencyViolationRate)/max(g.frequencyViolationRate,eps);
    assessment.P1ReserveReductionVsT7_pct=100*(t.meanTotalDGReserve_kW-p.meanTotalDGReserve_kW)/max(t.meanTotalDGReserve_kW,eps);

    fprintf('\nScientific gate (descriptive, not forced pass/fail):\n');
    fprintf('  G1 peak normalized stress : %.3f\n',gStress);
    fprintf('  T7 peak normalized stress : %.3f\n',tStress);
    fprintf('  P1 peak normalized stress : %.3f\n',pStress);
    fprintf('  P1 cost saving vs T7      : %+7.3f %%\n',assessment.P1CostSavingVsT7_pct);
    fprintf('  P1 stress reduction vs G1 : %+7.3f %%\n',assessment.P1StressReductionVsG1_pct);
    fprintf('  P1 reserve reduction vs T7: %+7.3f %%\n',assessment.P1ReserveReductionVsT7_pct);
    if p.frequencyViolationRate <= t.frequencyViolationRate + 1e-12 && p.totalCost < t.totalCost
        fprintf('  -> PROMISING: P1 matches/improves T7 frequency-violation rate while reducing cost.\n');
    elseif p.frequencyViolationRate < g.frequencyViolationRate && p.totalCost < t.totalCost
        fprintf('  -> PARTIALLY PROMISING: P1 improves G1 security and reduces T7 cost, but does not fully match T7 security.\n');
    else
        fprintf('  -> NOT YET CONCLUSIVE: inspect alpha/stress trajectories and calibration behavior before formal mainV4.\n');
    end
end

if all(ismember(["P1U","P1"],completed))
    u=compact.P1U.summary; p=compact.P1.summary;
    assessment.CalibrationFreqViolationDelta_pct=100*(u.frequencyViolationRate-p.frequencyViolationRate);
    fprintf('  Safety calibration: P1 frequency-violation improvement over P1U = %+7.3f percentage points.\n', ...
        assessment.CalibrationFreqViolationDelta_pct);
end

% --- Diagnostic plots ---------------------------------------------------
plot_validation(compact,completed,methodOrder,cfg);

report = struct();
report.kind='IslandEMSFinalClosedLoopAIReserveValidationV1';
report.scenario=struct('caseName','18bus','dayType',cfg.scenario.dayType,'decayRatio',1.0,'randomSeed',0);
report.table=T;
report.assessment=assessment;
report.results=compact;
report.completedMethods=completed;
report.failures=failures;
report.modelFile=modelFile;
report.timestamp=datestr(now,30);

if isempty(fieldnames(failures)) && numel(completed)==numel(methodOrder)
    if exist(checkpointFile,'file'), delete(checkpointFile); end
    fprintf('\nValidation completed. Temporary resume checkpoint removed.\n');
else
    fprintf('\nValidation incomplete. Compact resume checkpoint kept at:\n  %s\n',checkpointFile);
end
fprintf('Nothing was written to the formal outputs/ directory.\n');
end

% =======================================================================
function c=compact_result(r,cfg)
c=struct();
c.meta=r.meta;
c.summary=r.summary;
c.time_h=r.time_h;
c.freq_Hz=r.freq_Hz;
c.reserveRatio=r.reserve.ratio;
c.interval=r.interval;
c.securityLimits=struct('df_Hz',cfg.frequency.securityDeviation_Hz, ...
    'rocof_Hz_s',cfg.frequency.securityRoCoF_Hz_s);
end

function plot_validation(C,completed,methodOrder,cfg)
ids=methodOrder(ismember(methodOrder,completed));
if isempty(ids), return; end

% Figure 1: CoI frequency trajectories.
figure('Name','Closed-loop AI reserve validation - frequency','NumberTitle','off');
hold on;
for i=1:numel(ids)
    c=C.(char(ids(i)));
    t=(0:numel(c.freq_Hz)-1)/cfg.simulation.samplePerHour;
    plot(t,c.freq_Hz,'LineWidth',1.0,'DisplayName',char(ids(i)));
end
yline(cfg.frequency.nominal_Hz+cfg.frequency.securityDeviation_Hz,'--','HandleVisibility','off');
yline(cfg.frequency.nominal_Hz-cfg.frequency.securityDeviation_Hz,'--','HandleVisibility','off');
xlabel('Time (h)'); ylabel('CoI frequency (Hz)'); grid on; legend('Location','best');
title('System frequency: fixed vs learned reserve policies');

% Figure 2: reserve-ratio trajectories and realized stress.
figure('Name','Closed-loop AI reserve validation - reserve policy','NumberTitle','off');
subplot(2,1,1); hold on;
for i=1:numel(ids)
    c=C.(char(ids(i)));
    a=c.reserveRatio(:).';
    tt=(0:numel(a)-1)*cfg.mpc.decisionInterval_h;
    stairs(tt,a,'LineWidth',1.2,'DisplayName',char(ids(i)));
end
yline(1,'--','HandleVisibility','off');
yline(cfg.ai.alphaMin,':','HandleVisibility','off');
xlabel('Time (h)'); ylabel('Reserve ratio \alpha'); grid on; legend('Location','best');
title('Reserve-ratio decisions');
subplot(2,1,2); hold on;
for id=["G1","T7","P1U","P1"]
    if ~any(completed==id), continue; end
    c=C.(char(id));
    st=max(c.interval.maxAbsFreqDev_Hz/cfg.frequency.securityDeviation_Hz, ...
        c.interval.maxAbsRoCoF_Hz_s/cfg.frequency.securityRoCoF_Hz_s);
    tt=(0:numel(st)-1)*cfg.mpc.decisionInterval_h;
    stairs(tt,st,'LineWidth',1.1,'DisplayName',char(id));
end
yline(1,'--','Security boundary','HandleVisibility','on');
xlabel('Time (h)'); ylabel('Realized CoI frequency stress'); grid on; legend('Location','best');
title('Realized interval frequency stress');

% Figure 3: compact scientific metrics.
figure('Name','Closed-loop AI reserve validation - metrics','NumberTitle','off');
labels=cellstr(ids);
cost=nan(1,numel(ids)); stress=nan(1,numel(ids)); viol=nan(1,numel(ids)); reserve=nan(1,numel(ids));
for i=1:numel(ids)
    s=C.(char(ids(i))).summary;
    cost(i)=s.totalCost;
    stress(i)=max(s.maxAbsFreqDev_Hz/cfg.frequency.securityDeviation_Hz, ...
        s.maxAbsRoCoF_Hz_s/cfg.frequency.securityRoCoF_Hz_s);
    viol(i)=100*s.frequencyViolationRate;
    reserve(i)=s.meanTotalDGReserve_kW;
end
subplot(2,2,1); bar(categorical(labels),cost); ylabel('Cost ($)'); title('Operating cost'); grid on;
subplot(2,2,2); bar(categorical(labels),stress); yline(1,'--'); ylabel('Peak normalized stress'); title('Frequency security'); grid on;
subplot(2,2,3); bar(categorical(labels),viol); ylabel('Violation rate (%)'); title('Frequency-violation intervals'); grid on;
subplot(2,2,4); bar(categorical(labels),reserve); ylabel('Mean DG reserve (kW)'); title('Reserve usage'); grid on;
end

function sig=make_signature(cfg,modelFile,d)
sig=struct();
sig.version='ClosedLoopAIValidationV1';
sig.caseName='18bus';
sig.dayType=cfg.scenario.dayType;
sig.decay=1.0;
sig.seed=0;
sig.decisionInterval_h=cfg.mpc.decisionInterval_h;
sig.predictionStep_h=cfg.mpc.predictionStep_h;
sig.horizon_h=cfg.mpc.horizon_h;
sig.reserveDesign_Hz=cfg.frequency.reserveDeviation_Hz;
sig.securityDf_Hz=cfg.frequency.securityDeviation_Hz;
sig.securityRoCoF_Hz_s=cfg.frequency.securityRoCoF_Hz_s;
sig.alphaMin=cfg.ai.alphaMin;
sig.alphaMax=cfg.ai.alphaMax;
sig.modelFile=modelFile;
sig.modelBytes=d.bytes;
sig.modelDatenum=d.datenum;
end

function tf=is_project_root(p)
tf=isfolder(p) && isfolder(fullfile(p,'config')) && ...
    isfolder(fullfile(p,'core')) && isfolder(fullfile(p,'ai')) && ...
    exist(fullfile(p,'config','config_island_ems.m'),'file')==2;
end

function v=getfield_default(s,name,defaultValue)
if isfield(s,name), v=s.(name); else, v=defaultValue; end
end
