%% Deployment validation must ignore provenance-only training-data changes.
clear; clc;
projectRoot=fileparts(fileparts(mfilename('fullpath')));
addpath(genpath(projectRoot));
cfg=config_island_ems();
caseName='18bus';

% Build a minimal model compatible with current response-model contract.
sig=ai_reserve_model_signature(cfg,caseName);
m=struct();
m.caseName=caseName;
m.learningTarget='frequency-stress-response';
m.stateFeatureNames=reserve_feature_names();
m.inputNames=[reserve_feature_names() {'reserveRatio'}];
m.trainingSignature=sig;
m.alphaMin=cfg.ai.alphaMin;
m.alphaMax=cfg.ai.alphaMax;
m.candidateAlphaGrid=cfg.ai.candidateAlphaGrid(:).';

[ok,msg]=validate_ai_reserve_model(m,cfg,caseName);
assert(ok,msg);

% Provenance-only changes must NOT stale the deployed model.
cfg2=cfg;
if isfield(cfg2.ai.response,'parity')
    cfg2.ai.response.parity.decayRatios=[0.2 1.0];
    cfg2.ai.response.parity.randomSeeds=9:10;
end
if isfield(cfg2.ai.response,'enrichment')
    cfg2.ai.response.enrichment.decayRatios=[0.4 0.8];
    cfg2.ai.response.enrichment.randomSeeds=77;
end
cfg2.ai.response.decayRatios=[0.4 0.8];
cfg2.ai.response.randomSeeds=123;
cfg2.ai.kernelSigmaGrid=[0.5 2.0];
cfg2.ai.lambdaGrid=[1e-4 1e-2];
[ok,msg]=validate_ai_reserve_model(m,cfg2,caseName);
assert(ok,['Provenance-only change incorrectly invalidated model: ' msg]);

% A physical/security contract change MUST stale the model.
cfg3=cfg; cfg3.frequency.reserveDeviation_Hz=cfg.frequency.reserveDeviation_Hz+0.01;
[ok,~]=validate_ai_reserve_model(m,cfg3,caseName);
assert(~ok,'Physical reserve-design change must invalidate the stored model.');

% Online alpha policy change MUST also stale the model.
cfg4=cfg; cfg4.ai.alphaMin=cfg.ai.alphaMin+0.01;
[ok,~]=validate_ai_reserve_model(m,cfg4,caseName);
assert(~ok,'Online alpha policy change must invalidate the stored model.');

fprintf('AI model deployment-vs-provenance validation contract test passed.\n');
