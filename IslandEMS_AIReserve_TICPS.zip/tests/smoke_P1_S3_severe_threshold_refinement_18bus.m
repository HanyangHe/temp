%% smoke_P1_S3_severe_threshold_refinement_18bus.m
% Exact closed-loop refinement of the S3 severe-drop threshold.
%
% Current S3:
%   KRR without global calibration
%      +
%   Branch A: netDrop >= 0.02 AND netLoadNow >= 0.60
%   Branch B: netDrop >= severeThreshold
%      ->
%   alpha_final = 1
%
% Previous S3@0.10 PASSED:
%   mean alpha = 0.762292
%   cost       = 1164.054847
%   CoI unsafe = 0
%
% Default next test: severeThreshold = 0.11.
%
% Previous S3 trajectory:
%   Step 34 drop = 0.12092 -> should still trigger
%   Step 35 drop = 0.10892 -> should no longer trigger
%
% This must be an exact closed-loop test because changing one shield action
% can change later MPC states and dispatch. No formal results are saved.

clear;
clc;
close all force;

%% User switch
SEVERE_THRESHOLDS = 0.11;
% Optional later robustness sweep:
% SEVERE_THRESHOLDS = [0.11 0.12];

%% Fixed shield settings
DROP_THRESHOLD_PU = 0.02;
NETLOAD_MIN_PU    = 0.60;
SHIELD_ALPHA      = 1.00;

%% Setup
projectRoot = pwd;
addpath(genpath(projectRoot));
rehash;

cfg = config_island_ems();

engineFile = fullfile(projectRoot,'core','engine','engine_island_ems.m');
predFile   = which('predict_reserve_ratio');

assert(exist(engineFile,'file')==2 && ...
    contains(fileread(engineFile),'P1_FORECAST_SAFETY_SHIELD_EXPERIMENTAL'), ...
    'Forecast-shield engine hook is not active.');

assert(~isempty(predFile) && ...
    contains(fileread(predFile),'forecastSafetyShieldSevereBranch'), ...
    ['S3 two-branch predict_reserve_ratio.m is not active. ', ...
     'Apply the S3 patch first.']);

%% Fixed Part-I scope
caseName   = '18bus';
decayRatio = 1.00;
seed       = 0;

cfg.output.saveResults = false;
cfg.output.showFigures = false;

cfg.ai.enableForecastSafetyShield = true;
cfg.ai.forecastSafetyShieldDropThreshold_pu = DROP_THRESHOLD_PU;
cfg.ai.forecastSafetyShieldNetLoadMin_pu = NETLOAD_MIN_PU;
cfg.ai.forecastSafetyShieldSevereDropEnabled = true;
cfg.ai.forecastSafetyShieldAlpha = SHIELD_ALPHA;

catalog = paper_method_catalog();
ids = string({catalog.id});
idxP1 = find(ids=="P1",1);
assert(~isempty(idxP1),'P1 not found in paper_method_catalog().');

baseRunCfg = catalog(idxP1);
baseRunCfg.caseName = caseName;
baseRunCfg.dayType = cfg.scenario.dayType;
baseRunCfg.decayRatio = decayRatio;
baseRunCfg.randomSeed = seed;
baseRunCfg.aiSafetyCalibration = false;

%% Saved references
formalRunTag = '20260907_115951';
formalRoot = fullfile(projectRoot,cfg.output.root,formalRunTag);

refF1 = load_reference_local(formalRoot,'T7',caseName,decayRatio,seed);
refP1 = load_reference_local(formalRoot,'P1',caseName,decayRatio,seed);

fprintf('\n=============================================================\n');
fprintf(' S3 SEVERE-THRESHOLD CLOSED-LOOP REFINEMENT\n');
fprintf('=============================================================\n');
fprintf('case                 : %s\n',caseName);
fprintf('decayRatio           : %.2f\n',decayRatio);
fprintf('calibration          : 0\n');
fprintf('moderate drop thr    : %.4f pu\n',DROP_THRESHOLD_PU);
fprintf('moderate netload min : %.4f pu\n',NETLOAD_MIN_PU);
fprintf('severe thresholds    : %s\n',mat2str(SEVERE_THRESHOLDS,4));
fprintf('shield alpha         : %.4f\n',SHIELD_ALPHA);
fprintf('save results         : 0\n');
fprintf('=============================================================\n');

fprintf('\nSaved references:\n');
print_reference_local('F1 saved',refF1,cfg);
print_reference_local('P1 saved',refP1,cfg);

priorS3Available = evalin('base','exist(''S3_result'',''var'')==1');
if priorS3Available
    priorS3 = evalin('base','S3_result');
    fprintf('\nPrior in-memory S3@0.10 reference:\n');
    print_reference_local('S3@0.10',priorS3,cfg);
end

%% Exact closed-loop threshold tests
allSummary = table();
allResults = struct();

for iq = 1:numel(SEVERE_THRESHOLDS)

    severeThr = SEVERE_THRESHOLDS(iq);

    cfgRun = cfg;
    cfgRun.ai.forecastSafetyShieldSevereDropThreshold_pu = severeThr;

    runCfg = baseRunCfg;

    fprintf('\n\n=============================================================\n');
    fprintf(' RUNNING S3 severe threshold = %.4f pu\n',severeThr);
    fprintf('=============================================================\n');

    result = run_single_experiment(cfgRun,runCfg,projectRoot,'',false);

    tag = sprintf('thr_%03d',round(1000*severeThr));
    allResults.(tag) = result;

    metrics = summarize_result_local(result,cfgRun,severeThr);

    if isempty(allSummary)
        allSummary = metrics.summary;
    else
        allSummary = [allSummary;metrics.summary]; %#ok<AGROW>
    end

    fprintf('\nResult for severe threshold %.4f:\n',severeThr);
    disp(metrics.summary);

    fprintf('\nShield-trigger intervals:\n');
    if isempty(metrics.triggerTable)
        fprintf('  NONE\n');
    else
        disp(metrics.triggerTable);
    end

    fprintf('\nSevere-branch-only intervals:\n');
    if isempty(metrics.severeOnlyTable)
        fprintf('  NONE\n');
    else
        disp(metrics.severeOnlyTable);
    end

    fprintf('\nRemaining CoI-unsafe intervals:\n');
    if isempty(metrics.unsafeTable)
        fprintf('  NONE\n');
    else
        disp(metrics.unsafeTable);
    end

    if metrics.summary.CoIUnsafeCount==0
        fprintf('\n>>> threshold %.4f: COI SAFETY PASS <<<\n',severeThr);
    else
        fprintf('\n>>> threshold %.4f: COI SAFETY FAIL <<<\n',severeThr);
    end
end

%% Comparison
fprintf('\n\n=============================================================\n');
fprintf(' THRESHOLD COMPARISON\n');
fprintf('=============================================================\n');
disp(allSummary);

fprintf('\nF1 reference:\n');
fprintf('  cost       = %.6f\n',double(refF1.totalCost));
fprintf('  mean alpha = %.6f\n',mean(double(refF1.reserve.ratio(:)),'omitnan'));

if priorS3Available
    priorMetric = summarize_result_local(priorS3,cfg,0.10);

    fprintf('\nPrior S3@0.10:\n');
    disp(priorMetric.summary);

    fprintf('\nDelta relative to S3@0.10:\n');
    for i=1:height(allSummary)
        fprintf(['  thr %.3f: dMeanAlpha=%+.6f | dCost=%+.6f | ', ...
            'dShieldCount=%+d | unsafe=%d\n'], ...
            allSummary.SevereThreshold_pu(i), ...
            allSummary.MeanAlpha(i)-priorMetric.summary.MeanAlpha, ...
            allSummary.TotalCost(i)-priorMetric.summary.TotalCost, ...
            allSummary.ShieldTriggerCount(i)-priorMetric.summary.ShieldTriggerCount, ...
            allSummary.CoIUnsafeCount(i));
    end
end

%% Decision guidance
fprintf('\n=============================================================\n');
fprintf(' DECISION GUIDANCE\n');
fprintf('=============================================================\n');

safeRows = allSummary(allSummary.CoIUnsafeCount==0,:);

if isempty(safeRows)
    fprintf(['No tested higher severe threshold remained safe.\n', ...
        'Keep severe threshold = 0.10 for now; do not continue raising it.\n']);
else
    safeRows = sortrows(safeRows, ...
        {'MeanAlpha','TotalCost','ShieldTriggerCount'}, ...
        {'ascend','ascend','ascend'});

    best = safeRows(1,:);

    fprintf('Best safe tested refinement:\n');
    disp(best);

    fprintf(['If Step 35 is removed from the severe-only interventions while ', ...
        'Step 34 remains protected, this is a cleaner severe branch.\n']);

    if numel(SEVERE_THRESHOLDS)==1 && abs(SEVERE_THRESHOLDS-0.11)<1e-12
        fprintf(['If 0.11 passes, 0.12 is an optional robustness point. ', ...
            'It is not necessary unless you want to characterize the ', ...
            'upper threshold margin.\n']);
    end
end

fprintf('=============================================================\n');

assignin('base','S3_threshold_refinement_results',allResults);
assignin('base','S3_threshold_refinement_summary',allSummary);

fprintf('\nExported to base workspace:\n');
fprintf('  S3_threshold_refinement_results\n');
fprintf('  S3_threshold_refinement_summary\n');


%% =========================================================================
% Local helpers
% =========================================================================

function out = summarize_result_local(result,cfg,severeThr)

df = double(result.interval.maxAbsFreqDev_Hz(:));
rocof = double(result.interval.maxAbsRoCoF_Hz_s(:));

dfLim = cfg.frequency.securityDeviation_Hz;
rLim  = cfg.frequency.securityRoCoF_Hz_s;

stress = max(df/dfLim,rocof/rLim);
unsafe = stress>1+1e-12;

alpha = double(result.reserve.ratio(:));
n = numel(alpha);

step = (1:n).';
time_h = (step-1)*cfg.mpc.decisionInterval_h;

preAlpha = nan(n,1);
shieldTrig = false(n,1);
moderateTrig = false(n,1);
severeTrig = false(n,1);
forecastNet = nan(n,1);
forecastRamp = nan(n,1);
forecastDrop = nan(n,1);

H = result.reserve.metaHistory;

for k=1:min(n,numel(H))
    m = H{k};
    if ~isstruct(m) || ~isfield(m,'prediction') || ~isstruct(m.prediction)
        continue;
    end

    q = m.prediction;
    preAlpha(k) = get_scalar_local(q,'preShieldAlpha',NaN);
    shieldTrig(k) = get_logical_local(q,'forecastSafetyShieldTriggered',false);
    moderateTrig(k) = get_logical_local(q,'forecastSafetyShieldModerateBranch',false);
    severeTrig(k) = get_logical_local(q,'forecastSafetyShieldSevereBranch',false);
    forecastNet(k) = get_scalar_local(q,'forecastNetLoadNow_pu',NaN);
    forecastRamp(k) = get_scalar_local(q,'forecastSignedNetRamp_pu',NaN);
    forecastDrop(k) = get_scalar_local(q,'forecastNetDrop_pu',NaN);
end

summary = table();
summary.SevereThreshold_pu = severeThr;
summary.TotalCost = double(result.totalCost);
summary.MeanAlpha = mean(alpha,'omitnan');
summary.MinAlpha = min(alpha);
summary.MaxAlpha = max(alpha);
summary.MaxAbsDf_Hz = max(df);
summary.MaxAbsRoCoF_Hz_s = max(rocof);
summary.MaxSecurityStress = max(stress);
summary.CoIUnsafeCount = nnz(unsafe);
summary.CoIUnsafeRate = mean(unsafe);
summary.ShieldTriggerCount = nnz(shieldTrig);
summary.ModerateBranchCount = nnz(moderateTrig);
summary.SevereBranchCount = nnz(severeTrig);
summary.SevereOnlyCount = nnz(severeTrig & ~moderateTrig);
summary.MeanPreShieldAlpha = mean(preAlpha,'omitnan');
summary.MeanFinalAlpha = mean(alpha,'omitnan');
summary.MeanShieldAlphaIncrease = mean(alpha-preAlpha,'omitnan');

idx = find(shieldTrig);
triggerTable = table( ...
    step(idx),time_h(idx),preAlpha(idx),alpha(idx), ...
    moderateTrig(idx),severeTrig(idx), ...
    forecastNet(idx),forecastRamp(idx),forecastDrop(idx), ...
    df(idx),rocof(idx),stress(idx),unsafe(idx), ...
    'VariableNames',{ ...
    'MPCStep','StartTime_h','PreShieldAlpha','FinalAlpha', ...
    'ModerateBranch','SevereBranch', ...
    'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu', ...
    'ForecastNetDrop_pu','MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s', ...
    'SecurityStress','CoIUnsafe'});

idx = find(severeTrig & ~moderateTrig);
severeOnlyTable = table( ...
    step(idx),time_h(idx),preAlpha(idx),alpha(idx), ...
    forecastNet(idx),forecastRamp(idx),forecastDrop(idx), ...
    df(idx),rocof(idx),stress(idx), ...
    'VariableNames',{ ...
    'MPCStep','StartTime_h','PreShieldAlpha','FinalAlpha', ...
    'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu', ...
    'ForecastNetDrop_pu','MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s', ...
    'SecurityStress'});

idx = find(unsafe);
unsafeTable = table( ...
    step(idx),time_h(idx),alpha(idx),shieldTrig(idx), ...
    moderateTrig(idx),severeTrig(idx), ...
    forecastNet(idx),forecastRamp(idx),forecastDrop(idx), ...
    df(idx),rocof(idx),stress(idx), ...
    'VariableNames',{ ...
    'MPCStep','StartTime_h','FinalAlpha','ShieldTriggered', ...
    'ModerateBranch','SevereBranch', ...
    'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu', ...
    'ForecastNetDrop_pu','MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s', ...
    'SecurityStress'});

out = struct();
out.summary = summary;
out.triggerTable = triggerTable;
out.severeOnlyTable = severeOnlyTable;
out.unsafeTable = unsafeTable;
end


function result = load_reference_local(formalRoot,methodID,caseName,decayRatio,seed)

methodDir = fullfile(formalRoot,methodID);
decayCode = round(100*decayRatio);

pattern = sprintf('%s_*_decay%03d_seed%03d_*.mat', ...
    caseName,decayCode,seed);

hits = dir(fullfile(methodDir,pattern));

assert(numel(hits)==1, ...
    'Expected one saved %s reference; found %d.',methodID,numel(hits));

S = load(fullfile(hits(1).folder,hits(1).name));

if isfield(S,'result')
    result = S.result;
    return;
end

names = fieldnames(S);
for k=1:numel(names)
    if isstruct(S.(names{k}))
        result = S.(names{k});
        return;
    end
end

error('Could not identify saved result struct.');
end


function print_reference_local(label,result,cfg)

df = double(result.interval.maxAbsFreqDev_Hz(:));
rocof = double(result.interval.maxAbsRoCoF_Hz_s(:));

unsafe = df>cfg.frequency.securityDeviation_Hz+1e-12 | ...
         rocof>cfg.frequency.securityRoCoF_Hz_s+1e-12;

fprintf(['  %-10s cost=%9.4f | mean alpha=%.6f | max|df|=%.6f | ', ...
    'max|RoCoF|=%.6f | unsafe=%d\n'], ...
    label,double(result.totalCost), ...
    mean(double(result.reserve.ratio(:)),'omitnan'), ...
    max(df),max(rocof),nnz(unsafe));
end


function v = get_scalar_local(s,name,defaultValue)
v = defaultValue;
if isstruct(s) && isfield(s,name)
    x = s.(name);
    if isnumeric(x) && isscalar(x)
        v = double(x);
    end
end
end


function v = get_logical_local(s,name,defaultValue)
v = logical(defaultValue);
if isstruct(s) && isfield(s,name)
    x = s.(name);
    if (islogical(x) || isnumeric(x)) && isscalar(x)
        v = logical(x);
    end
end
end
