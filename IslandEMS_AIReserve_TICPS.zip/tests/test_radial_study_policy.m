%% Formal revised-paper experiments must remain radial-only.
cfg=config_island_ems();
validate_config(cfg);
assert(all(ismember(string(cfg.network.paperCases),["10bus","18bus","33bus"])), ...
    'Paper-case list must contain radial cases only.');
cfgBad=cfg; cfgBad.experiment.systemCases={'18bus_loop'};
didFail=false;
try
    validate_config(cfgBad);
catch ME
    didFail=contains(ME.message,'radial-only') || contains(ME.message,'radial');
end
assert(didFail,'validate_config must reject meshed formal cases when allowMeshedCases=false.');
fprintf('Radial-only formal-study policy test passed.\n');
