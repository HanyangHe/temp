%% DG droop/inertia local-base regression test
Prate=0.14; R=0.03; f0=60;
phys=struct('H',1,'D',0,'omega_b',2*pi*f0);
ctrl=[1.5 0];
Z=0.02+1j*0.25;
kQ=0;
MainGFM=0;

% Set E=V so Pe=0. With +0.2 Hz, droop request should fall by 15.56 kW.
df=0.2; dw=2*pi*df;
Pref=0.10;
X=[-pi/2;dw;Pref;0];
Ref=[1;Pref;0]; FDBK=[1;1];
[~,~,Psee]=DG_Diesel_SG_DynModel_4States(Ref,FDBK,Prate,Z,ctrl,R,kQ,phys,MainGFM,X);
expectedDeltaMW=-(Prate/R)*(df/f0);
assert(abs((Psee(2)-Pref)-expectedDeltaMW)<1e-10, ...
    'Droop response is not on the DG local active-power rating base.');

% Inertia test: a 0.1-pu local-machine imbalance at H=1 s gives 3 Hz/s.
Pm=0.1*Prate; X=[-pi/2;0;Pm;0]; Ref=[1;Pm;0];
[~,dotX,~]=DG_Diesel_SG_DynModel_4States(Ref,FDBK,Prate,Z,ctrl,R,kQ,phys,MainGFM,X);
rocof_Hz_s = (dotX(2)/3600)/(2*pi);
assert(abs(rocof_Hz_s-3)<1e-10, ...
    'Swing equation inertia is not on the DG local active-power rating base.');
fprintf('DG-base test passed: droop %.3f kW at 0.2 Hz; RoCoF %.3f Hz/s at 0.1 pu.\n', ...
    1000*abs(expectedDeltaMW),rocof_Hz_s);
