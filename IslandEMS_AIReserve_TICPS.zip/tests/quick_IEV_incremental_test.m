function report = quick_IEV_incremental_test(varargin)
%QUICK_IEV_INCREMENTAL_TEST Fast, no-simulation test of whether EV availability
%adds meaningful incremental predictive value for AI frequency-reserve features.
%
% PURPOSE
%   Compare a physics-core feature set against the same set plus I_EV using
%   blocked (time-ordered) cross-validation. This is intentionally a cheap
%   screening test: it reuses the 96-row feature snapshot created by
%   smoke_T7_18bus() and NEVER launches MPC/physical simulation.
%
% DEFAULT PHYSICS CORE
%   netLoadNow_pu
%   absNetLoadRamp_pu
%   absPVRamp_pu
%   dgUpHeadroom_pu
%   bessMeanSOC
%
% TESTED ADDITION
%   evAvailability
%
% TARGET
%   realized frequency-stress index in the following 15-min interval:
%       max(max|df|/df_limit, max|RoCoF|/RoCoF_limit)
%
% USAGE
%   report = quick_IEV_incremental_test();
%   report = quick_IEV_incremental_test(snapshotStruct);
%   report = quick_IEV_incremental_test(fullSmokeResultStruct);
%
% INPUT DISCOVERY ORDER
%   explicit input -> base featureScreenSnapshot/result/base -> OS temp cache
%
% OUTPUT POLICY
%   No files are saved. No formal outputs/ folder is touched.
%
% DECISION RULE
%   Because the project prefers a compact physics feature set, I_EV is kept
%   only if it shows STRONG incremental value beyond the physics core.
%   Otherwise the recommendation is DROP I_EV for the first AI model.
%
% NOTE
%   This is still screening against frequency stress, not the final alpha*.
%   The conclusion should later be sanity-checked once alpha* labels exist.

snapshot = resolve_snapshot(varargin{:});
if isempty(snapshot)
    fprintf('\nIEV INCREMENTAL TEST NOT RUN: no feature-screen snapshot is available.\n');
    fprintf('This test will NOT launch a costly simulation.\n');
    fprintf('Run once:  base = smoke_T7_18bus();\n');
    fprintf('Then run:  report = quick_IEV_incremental_test();\n\n');
    report = [];
    return;
end

names = string(snapshot.features.names(:));
D = snapshot.features.data;
y = snapshot.target.stress(:);
time_h = snapshot.time_h(:);

coreNames = ["netLoadNow_pu","absNetLoadRamp_pu","absPVRamp_pu", ...
             "dgUpHeadroom_pu","bessMeanSOC"];
ievName = "evAvailability";

coreIdx = zeros(numel(coreNames),1);
for i=1:numel(coreNames)
    j=find(names==coreNames(i),1);
    if isempty(j)
        error('quick_IEV_incremental_test:MissingFeature', ...
            'Required core feature "%s" is not present in the snapshot.',coreNames(i));
    end
    coreIdx(i)=j;
end
jIEV=find(names==ievName,1);
if isempty(jIEV)
    error('quick_IEV_incremental_test:MissingIEV', ...
        'Feature "evAvailability" is not present in the snapshot.');
end

Xcore = D(:,coreIdx);
iev = D(:,jIEV);
Xplus = [Xcore iev];

% Fair comparison: use the identical finite rows for both models.
good = isfinite(y) & all(isfinite(Xplus),2);
Xcore=Xcore(good,:); Xplus=Xplus(good,:); iev=iev(good); y=y(good); t=time_h(good);
if numel(y)<48
    warning('Only %d complete rows are available; the IEV conclusion will be weak.',numel(y));
end

fprintf('\n=============================================================\n');
fprintf(' QUICK I_EV INCREMENTAL FEATURE TEST (NO SIMULATION)\n');
fprintf('=============================================================\n');
fprintf(' case / method : %s / %s\n',string(snapshot.meta.caseName),string(snapshot.meta.methodID));
fprintf(' samples       : %d decision intervals\n',numel(y));
fprintf(' target        : realized frequency stress\n');
fprintf(' CV policy     : 4 contiguous outer blocks + inner tuning\n');
fprintf(' models        : ridge + RBF-KRR (toolbox-free local code)\n');
fprintf(' persistence   : OFF\n');
fprintf(' core features : %s\n',strjoin(cellstr(coreNames),', '));
fprintf(' tested add-on : evAvailability\n');
fprintf('=============================================================\n');

% Time-ordered nested cross-validation.  Same outer folds for all models.
foldId = contiguous_folds(numel(y),4);
[pR0,mR0] = blocked_oof_model(Xcore,y,foldId,'ridge');
[pR1,mR1] = blocked_oof_model(Xplus,y,foldId,'ridge');
[pK0,mK0] = blocked_oof_model(Xcore,y,foldId,'krr');
[pK1,mK1] = blocked_oof_model(Xplus,y,foldId,'krr');

imp = table( ...
    ["Ridge";"RBF-KRR"], ...
    [mR0.RMSE;mK0.RMSE],[mR1.RMSE;mK1.RMSE], ...
    pct_improve([mR0.RMSE;mK0.RMSE],[mR1.RMSE;mK1.RMSE]), ...
    [mR0.MAE;mK0.MAE],[mR1.MAE;mK1.MAE], ...
    pct_improve([mR0.MAE;mK0.MAE],[mR1.MAE;mK1.MAE]), ...
    [mR0.R2;mK0.R2],[mR1.R2;mK1.R2], ...
    [mR0.Corr;mK0.Corr],[mR1.Corr;mK1.Corr], ...
    'VariableNames',{'Model','RMSE_Core','RMSE_CorePlusIEV','RMSE_Improve_pct', ...
    'MAE_Core','MAE_CorePlusIEV','MAE_Improve_pct','R2_Core','R2_CorePlusIEV', ...
    'Corr_Core','Corr_CorePlusIEV'});

% Incremental/residual association: does IEV explain what the core misses?
residK = y-pK0;
residR = y-pR0;
rhoResidualK = spearman_safe(iev,residK);
rhoResidualR = spearman_safe(iev,residR);
partialRho = partial_spearman(iev,y,Xcore);

% Redundancy/time-proxy diagnostics.
coreRho = nan(numel(coreNames),1);
for i=1:numel(coreNames), coreRho(i)=spearman_safe(iev,Xcore(:,i)); end
Redundancy = table(coreNames(:),coreRho,abs(coreRho), ...
    'VariableNames',{'CoreFeature','Spearman_IEV','AbsSpearman_IEV'});
Redundancy=sortrows(Redundancy,'AbsSpearman_IEV','descend');

rhoTime = NaN; rhoTimeCos=NaN; rhoTimeSin=NaN;
j=find(names=="timeCos",1); if ~isempty(j), z=D(good,j); rhoTimeCos=spearman_safe(iev,z); end
j=find(names=="timeSin",1); if ~isempty(j), z=D(good,j); rhoTimeSin=spearman_safe(iev,z); end
rhoTime=max(abs([rhoTimeCos rhoTimeSin]),[],'omitnan');

fprintf('\nBlocked-CV incremental prediction test:\n');
disp(imp);
fprintf('\nIncremental-information diagnostics:\n');
fprintf('  Spearman(IEV, KRR core OOF residual)   = %+0.3f\n',rhoResidualK);
fprintf('  Spearman(IEV, ridge core OOF residual) = %+0.3f\n',rhoResidualR);
fprintf('  Partial Spearman(IEV, stress | core)   = %+0.3f\n',partialRho);
fprintf('  Max |Spearman(IEV, core feature)|      = %0.3f\n',max(abs(coreRho),[],'omitnan'));
fprintf('  Max |Spearman(IEV, timeSin/timeCos)|   = %0.3f\n',rhoTime);
fprintf('\nIEV redundancy with physics core:\n');
disp(Redundancy);

% Conservative KEEP rule: user preference is to omit IEV unless it is strong.
krrRmseImp = imp.RMSE_Improve_pct(imp.Model=="RBF-KRR");
krrMaeImp  = imp.MAE_Improve_pct(imp.Model=="RBF-KRR");
ridgeRmseImp = imp.RMSE_Improve_pct(imp.Model=="Ridge");

strongNonlinear = krrRmseImp>=5 && krrMaeImp>=3 && abs(partialRho)>=0.20;
robustBoth = krrRmseImp>=3 && ridgeRmseImp>=3 && abs(partialRho)>=0.15;
if strongNonlinear || robustBoth
    recommendation = "KEEP_IEV";
    reason = sprintf(['IEV adds strong incremental information: KRR RMSE %+0.1f%%, ', ...
        'KRR MAE %+0.1f%%, partial Spearman |rho|=%.2f.'], ...
        krrRmseImp,krrMaeImp,abs(partialRho));
else
    recommendation = "DROP_IEV";
    reason = sprintf(['IEV does not clear the conservative keep threshold: KRR RMSE %+0.1f%%, ', ...
        'KRR MAE %+0.1f%%, ridge RMSE %+0.1f%%, partial Spearman |rho|=%.2f. ', ...
        'Prefer the smaller physics feature set.'], ...
        krrRmseImp,krrMaeImp,ridgeRmseImp,abs(partialRho));
end

fprintf('\n=============================================================\n');
fprintf(' PRELIMINARY IEV DECISION: %s\n',recommendation);
fprintf(' %s\n',reason);
fprintf(' This is a one-day stress-screen decision; alpha* labels can later confirm it.\n');
fprintf('=============================================================\n\n');

% --------------------------- Plots ---------------------------------------
figure('Name','I_EV incremental feature test');
tiledlayout(2,2,'TileSpacing','compact');
nexttile;
bar(categorical({'Ridge','RBF-KRR'}), ...
    [mR0.RMSE mR1.RMSE; mK0.RMSE mK1.RMSE]);
ylabel('Blocked-CV RMSE'); grid on; box on;
legend('Physics core','Core + I_{EV}','Location','best');
title('Incremental prediction value');

nexttile;
plot(t,y,'k','LineWidth',1.2); hold on;
plot(t,pK0,'LineWidth',1.0); plot(t,pK1,'LineWidth',1.0);
yline(1,'k--'); grid on; box on;
xlabel('Time (h)'); ylabel('Frequency stress');
legend('Realized','KRR core','KRR core + I_{EV}','Security boundary','Location','best');
title('Blocked out-of-fold predictions');

nexttile;
scatter(iev,residK,24,'filled'); hold on; yline(0,'k--');
grid on; box on; xlabel('I_{EV}'); ylabel('Core-model OOF residual');
title(sprintf('Residual association: \rho_s=%+.2f',rhoResidualK));

nexttile;
plot(t,normalize01(iev),'LineWidth',1.1); hold on;
plot(t,normalize01(y),'LineWidth',1.1);
grid on; box on; xlabel('Time (h)'); ylabel('Normalized');
legend('I_{EV}','Frequency stress','Location','best');
title(sprintf('Time co-variation (proxy check %.2f)',rhoTime));

report=struct();
report.kind='IslandEMSQuickIEVIncrementalTestV1';
report.coreFeatures=coreNames;
report.testedFeature=ievName;
report.metrics=imp;
report.partialSpearman=partialRho;
report.residualSpearmanKRR=rhoResidualK;
report.residualSpearmanRidge=rhoResidualR;
report.redundancy=Redundancy;
report.timeProxySpearman=rhoTime;
report.recommendation=recommendation;
report.reason=reason;
report.oof=struct('time_h',t,'target',y,'ridgeCore',pR0,'ridgePlusIEV',pR1, ...
                  'krrCore',pK0,'krrPlusIEV',pK1,'foldId',foldId);
report.snapshotMeta=snapshot.meta;
end

% ========================================================================
function snapshot=resolve_snapshot(varargin)
snapshot=[];
if nargin>=1 && isstruct(varargin{1})
    x=varargin{1};
    if is_snapshot(x), snapshot=x; return; end
    if is_full_result(x), snapshot=build_feature_screening_snapshot(x); return; end
end
vars={'featureScreenSnapshot','lastSmokeResult','result','base'};
for i=1:numel(vars)
    nm=vars{i};
    if evalin('base',sprintf('exist(''%s'',''var'')',nm))
        x=evalin('base',nm);
        if is_snapshot(x), snapshot=x; return; end
        if is_full_result(x), snapshot=build_feature_screening_snapshot(x); return; end
    end
end
cacheFile=fullfile(tempdir,'IslandEMS_feature_screening_snapshot.mat');
if isfile(cacheFile)
    S=load(cacheFile,'snapshot');
    if isfield(S,'snapshot') && is_snapshot(S.snapshot), snapshot=S.snapshot; end
end
end
function tf=is_snapshot(x)
tf=isstruct(x)&&isfield(x,'kind')&&strcmp(string(x.kind),'IslandEMSFeatureScreenSnapshotV1')&&isfield(x,'features')&&isfield(x,'target');
end
function tf=is_full_result(r)
tf=isstruct(r)&&isfield(r,'meta')&&isfield(r,'cfgSnapshot')&&isfield(r,'freq_Hz')&&isfield(r,'P_DG_MW')&&isfield(r,'totalLoad_MW');
end
function f=contiguous_folds(n,K)
f=ceil((1:n)'*K/n); f(f<1)=1; f(f>K)=K;
end
function [oof,m]=blocked_oof_model(X,y,foldId,type)
n=numel(y); oof=nan(n,1); K=max(foldId);
for k=1:K
    te=(foldId==k); tr=~te;
    param=tune_inner(X(tr,:),y(tr),type);
    oof(te)=fit_predict(X(tr,:),y(tr),X(te,:),type,param);
end
m=metrics(y,oof);
end
function param=tune_inner(X,y,type)
n=size(X,1); fid=contiguous_folds(n,min(3,n));
if strcmp(type,'ridge')
    grid=logspace(-4,1,6); loss=inf(numel(grid),1);
    for q=1:numel(grid)
        pred=nan(n,1);
        for k=1:max(fid)
            te=fid==k; tr=~te;
            if sum(tr)<8 || sum(te)<1, continue; end
            pred(te)=fit_predict(X(tr,:),y(tr),X(te,:),'ridge',grid(q));
        end
        loss(q)=rmse_safe(y,pred);
    end
    [~,i]=min(loss); param=grid(i);
else
    lambdas=[1e-4 1e-3 1e-2 1e-1]; scales=[0.5 1 2];
    best=inf; param=[1e-2 1];
    for a=1:numel(lambdas)
        for b=1:numel(scales)
            pred=nan(n,1);
            for k=1:max(fid)
                te=fid==k; tr=~te;
                if sum(tr)<8 || sum(te)<1, continue; end
                pred(te)=fit_predict(X(tr,:),y(tr),X(te,:),'krr',[lambdas(a) scales(b)]);
            end
            L=rmse_safe(y,pred);
            if L<best, best=L; param=[lambdas(a) scales(b)]; end
        end
    end
end
end
function pred=fit_predict(Xtr,ytr,Xte,type,param)
mu=mean(Xtr,1); sd=std(Xtr,0,1); sd(sd<1e-10)=1;
Ztr=(Xtr-mu)./sd; Zte=(Xte-mu)./sd;
if strcmp(type,'ridge')
    A=[ones(size(Ztr,1),1) Ztr]; B=[ones(size(Zte,1),1) Zte];
    P=eye(size(A,2)); P(1,1)=0;
    beta=(A'*A+param*P)\(A'*ytr);
    pred=B*beta;
else
    lambda=param(1); scale=param(2);
    D2=dist2(Ztr,Ztr); v=sqrt(D2(triu(true(size(D2)),1))); v=v(isfinite(v)&v>0);
    if isempty(v), sig=1; else, sig=median(v); end
    sig=max(sig*scale,1e-6); gamma=1/(2*sig^2);
    K=exp(-gamma*D2);
    beta=(K+lambda*eye(size(K)))\ytr;
    pred=exp(-gamma*dist2(Zte,Ztr))*beta;
end
end
function D2=dist2(A,B)
D2=sum(A.^2,2)+sum(B.^2,2)'-2*(A*B'); D2=max(D2,0);
end
function m=metrics(y,p)
mask=isfinite(y)&isfinite(p); y=y(mask); p=p(mask); e=y-p;
m=struct(); m.RMSE=sqrt(mean(e.^2)); m.MAE=mean(abs(e));
den=sum((y-mean(y)).^2); if den>0, m.R2=1-sum(e.^2)/den; else, m.R2=NaN; end
m.Corr=pearson_safe(y,p);
end
function r=rmse_safe(y,p)
mask=isfinite(y)&isfinite(p); if sum(mask)<3, r=inf; else, r=sqrt(mean((y(mask)-p(mask)).^2)); end
end
function z=pct_improve(a,b)
z=100*(a-b)./max(abs(a),eps);
end
function r=partial_spearman(x,y,Z)
x=rank_average(x(:)); y=rank_average(y(:));
ZR=zeros(size(Z)); for j=1:size(Z,2), ZR(:,j)=rank_average(Z(:,j)); end
A=[ones(size(ZR,1),1) ZR]; rx=x-A*(A\x); ry=y-A*(A\y); r=pearson_safe(rx,ry);
end
function r=spearman_safe(x,y)
x=x(:); y=y(:); m=isfinite(x)&isfinite(y); x=x(m); y=y(m);
if numel(x)<4 || std(x)==0 || std(y)==0, r=NaN; return; end
r=pearson_safe(rank_average(x),rank_average(y));
end
function r=pearson_safe(x,y)
x=x(:); y=y(:); m=isfinite(x)&isfinite(y); x=x(m); y=y(m);
if numel(x)<4 || std(x)==0 || std(y)==0, r=NaN; return; end
x=x-mean(x); y=y-mean(y); r=sum(x.*y)/sqrt(sum(x.^2)*sum(y.^2));
end
function r=rank_average(x)
[sorted,ord]=sort(x); n=numel(x); rs=zeros(n,1); i=1;
while i<=n
    j=i; while j<n && sorted(j+1)==sorted(i), j=j+1; end
    rs(ord(i:j))=(i+j)/2; i=j+1;
end
r=rs;
end
function z=normalize01(x)
x=x(:); lo=min(x,[],'omitnan'); hi=max(x,[],'omitnan');
if ~isfinite(lo)||~isfinite(hi)||hi-lo<eps, z=zeros(size(x)); else, z=(x-lo)/(hi-lo); end
end
