%% smoke_P1_metaHistory_candidate_curve_18bus.m
% NO-SIMULATION forensic test for the P1 frequency-safety failure.
%
% This is the next focused diagnostic after:
%   - smoke_P1_frequency_safety_18bus.m
%   - smoke_P1_step31_forensics_18bus.m
%   - smoke_P1_ai_internal_structure_18bus.m
%
% What this test does
% -------------------
% For MPC steps 29:34, especially 31/32, it:
%
%   1) reads the SAVED P1 feature vector and metaHistory;
%   2) loads the exact 18-bus KRR model;
%   3) replays ONLY the AI alpha-selection calculation, with NO simulation;
%   4) evaluates BOTH:
%          P1U = no calibration
%          P1  = current one-sided calibration
%      on the same saved feature vector;
%   5) prints the full alpha candidate curve:
%          alpha
%          raw predicted stress
%          uncalibrated decision stress
%          calibrated decision stress
%          inferred safe/unsafe status
%   6) compares predicted stress with the ACTUAL saved interval frequency
%      outcome at the same MPC step;
%   7) automatically flags the most likely failure class:
%          false-safe model prediction
%          ineffective calibration
%          OOD/fallback inconsistency
%          selector inconsistency
%
% IMPORTANT
% ---------
% NO MPC solve.
% NO physical simulation.
% NO formal result overwrite.
%
% The test uses result.cfgSnapshot.ai rather than today's cfg.ai whenever
% possible so that the selector replay matches the formal saved run.

clear;
clc;

%% User settings
FORMAL_RUN_TAG = '20260907_115951';

WINDOW_STEPS   = 29:34;
CRITICAL_STEPS = [31 32];

EXPORT_CSV = true;

% The learned target is a normalized frequency-stress response.  The online
% selector is expected to use a normalized safe boundary.  Keep the inferred
% threshold here for diagnostics only; the script ALSO prints the exact
% selector source so we can verify the real criterion.
INFERRED_SAFE_STRESS_THRESHOLD = 1.0;

%% Project setup
projectRoot = pwd;
addpath(genpath(projectRoot));
rehash;

cfgNow = config_island_ems();

caseName   = '18bus';
decayRatio = 1.00;
seed       = 0;

runRoot = fullfile(projectRoot,cfgNow.output.root,FORMAL_RUN_TAG);
assert(exist(runRoot,'dir')==7, ...
    'Formal run folder not found: %s',runRoot);

%% Load saved P1 result
p1File = find_one_result_local( ...
    fullfile(runRoot,'P1'),caseName,decayRatio,seed);

result = load_result_local(p1File);

assert(isfield(result,'reserve') && isfield(result.reserve,'features'), ...
    'Saved P1 result does not contain result.reserve.features.');
assert(isfield(result.reserve,'ratio'), ...
    'Saved P1 result does not contain result.reserve.ratio.');
assert(isfield(result.reserve,'metaHistory'), ...
    'Saved P1 result does not contain result.reserve.metaHistory.');
assert(isfield(result,'interval'), ...
    'Saved P1 result does not contain result.interval.');

%% Use exact AI configuration snapshot from formal run if available
if isfield(result,'cfgSnapshot') && isfield(result.cfgSnapshot,'ai')
    aiCfgBase = result.cfgSnapshot.ai;
    fprintf('Using saved result.cfgSnapshot.ai for selector replay.\n');
else
    aiCfgBase = cfgNow.ai;
    warning('Saved cfgSnapshot.ai not found; using current cfg.ai.');
end

%% Resolve frequency security limits from saved snapshot when possible
if isfield(result,'cfgSnapshot') && isfield(result.cfgSnapshot,'frequency')
    freqCfg = result.cfgSnapshot.frequency;
else
    freqCfg = cfgNow.frequency;
end

dfSecurity_Hz = getfield_default_local( ...
    freqCfg,'securityDeviation_Hz',cfgNow.frequency.securityDeviation_Hz);

rocofSecurity_Hz_s = getfield_default_local( ...
    freqCfg,'securityRoCoF_Hz_s',cfgNow.frequency.securityRoCoF_Hz_s);

%% Load exact 18-bus model
modelFile = fullfile(projectRoot, ...
    char(aiCfgBase.modelRoot),caseName,char(aiCfgBase.modelFileName));

if exist(modelFile,'file')~=2
    modelFile = fullfile(projectRoot, ...
        char(aiCfgBase.modelRoot),char(aiCfgBase.modelFileName));
end

assert(exist(modelFile,'file')==2, ...
    'Could not find 18-bus AI model: %s',modelFile);

M = load(modelFile);
assert(isfield(M,'model'),'Model MAT file does not contain variable "model".');
model = M.model;

assert(exist('select_reserve_alpha_batch','file')==2, ...
    'select_reserve_alpha_batch.m is not on the MATLAB path.');

%% Header
fprintf('\n=============================================================\n');
fprintf(' P1 META-HISTORY + CANDIDATE-CURVE FORENSICS\n');
fprintf(' NO SIMULATION\n');
fprintf('=============================================================\n');
fprintf(' P1 result : %s\n',p1File);
fprintf(' model     : %s\n',modelFile);
fprintf(' steps     : %s\n',mat2str(WINDOW_STEPS));
fprintf(' critical  : %s\n',mat2str(CRITICAL_STEPS));
fprintf(' df limit  : %.6g Hz\n',dfSecurity_Hz);
fprintf(' RoCoF lim : %.6g Hz/s\n',rocofSecurity_Hz_s);
fprintf('=============================================================\n');

%% Feature names
if isfield(result.reserve,'featureNames')
    featureNames = string(result.reserve.featureNames);
elseif isfield(model,'stateFeatureNames')
    featureNames = string(model.stateFeatureNames);
else
    featureNames = "feature" + (1:size(result.reserve.features,2));
end

fprintf('\nSaved feature ordering:\n');
for j = 1:numel(featureNames)
    fprintf('  column %d : %s\n',j,featureNames(j));
end

%% Print exact selector source
fprintf('\n=============================================================\n');
fprintf(' A. EXACT select_reserve_alpha_batch.m SOURCE\n');
fprintf('=============================================================\n');
print_source_file_local(which('select_reserve_alpha_batch'),120);

fprintf('\n=============================================================\n');
fprintf(' B. EXACT predict_reserve_ratio.m SOURCE\n');
fprintf('=============================================================\n');
predFile = which('predict_reserve_ratio');
if ~isempty(predFile)
    print_source_file_local(predFile,100);
else
    fprintf('<predict_reserve_ratio.m not found on path>\n');
end

%% Re-evaluate selector at each saved state
allCandidateRows = table();
stepSummary = table();

for step = WINDOW_STEPS

    feature = double(result.reserve.features(step,:));
    savedAlpha = double(result.reserve.ratio(step));

    actualDf = double(result.interval.maxAbsFreqDev_Hz(step));
    actualRoCoF = double(result.interval.maxAbsRoCoF_Hz_s(step));

    actualSecurityStress = max( ...
        actualDf/dfSecurity_Hz, ...
        actualRoCoF/rocofSecurity_Hz_s);

    actualSafe = actualDf <= dfSecurity_Hz + 1e-12 && ...
                 actualRoCoF <= rocofSecurity_Hz_s + 1e-12;

    % Exact online selector replay, no calibration = P1U policy.
    aiU = aiCfgBase;
    aiU.useSafetyCalibration = false;

    [alphaU,dU] = select_reserve_alpha_batch( ...
        model,feature,aiU,false);

    % Exact online selector replay, current calibration = P1 policy.
    aiC = aiCfgBase;
    aiC.useSafetyCalibration = true;

    [alphaC,dC] = select_reserve_alpha_batch( ...
        model,feature,aiC,true);

    alphaU = double(alphaU(1));
    alphaC = double(alphaC(1));

    % Pull exact returned curves.
    alphaGridU = row_vector_local(get_detail_local(dU,'alphaGrid',[]));
    alphaGridC = row_vector_local(get_detail_local(dC,'alphaGrid',[]));

    rawU = first_row_local(get_detail_local(dU,'rawStress',[]));
    decU = first_row_local(get_detail_local(dU,'decisionStress',[]));

    rawC = first_row_local(get_detail_local(dC,'rawStress',[]));
    decC = first_row_local(get_detail_local(dC,'decisionStress',[]));

    assert(~isempty(alphaGridU), ...
        'Selector detail did not return alphaGrid at step %d.',step);
    assert(isequaln(alphaGridU,alphaGridC), ...
        'P1U/P1 alpha grids differ unexpectedly at step %d.',step);

    alphaGrid = alphaGridU;

    % Raw model prediction should be the same with/without calibration.
    rawCurve = choose_curve_local(rawC,rawU,numel(alphaGrid));

    if isempty(decU)
        decU = rawCurve;
    end

    if isempty(decC)
        decC = rawCurve;
        if isfield(model,'calibrationOffset')
            decC = decC + double(model.calibrationOffset);
        end
    end

    decU = force_length_local(decU,numel(alphaGrid));
    decC = force_length_local(decC,numel(alphaGrid));
    rawCurve = force_length_local(rawCurve,numel(alphaGrid));

    inferredSafeU = decU <= INFERRED_SAFE_STRESS_THRESHOLD + 1e-12;
    inferredSafeC = decC <= INFERRED_SAFE_STRESS_THRESHOLD + 1e-12;

    selectedU = abs(alphaGrid-alphaU)<1e-12;
    selectedC = abs(alphaGrid-alphaC)<1e-12;
    selectedSaved = abs(alphaGrid-savedAlpha)<1e-12;

    rawAtSaved = value_at_alpha_local(alphaGrid,rawCurve,savedAlpha);
    decCAtSaved = value_at_alpha_local(alphaGrid,decC,savedAlpha);
    decUAtSaved = value_at_alpha_local(alphaGrid,decU,savedAlpha);

    oodU = logical_scalar_local( ...
        get_detail_local(dU,'oodFallback',false));
    oodC = logical_scalar_local( ...
        get_detail_local(dC,'oodFallback',false));

    missingU = logical_scalar_local( ...
        get_detail_local(dU,'missingFeatureFallback',false));
    missingC = logical_scalar_local( ...
        get_detail_local(dC,'missingFeatureFallback',false));

    noSafeU = logical_scalar_local( ...
        get_detail_local(dU,'noSafeCandidateFallback',false));
    noSafeC = logical_scalar_local( ...
        get_detail_local(dC,'noSafeCandidateFallback',false));

    % Saved metadata for this formal decision.
    savedMeta = result.reserve.metaHistory{step};

    fprintf('\n\n=============================================================\n');
    fprintf(' MPC STEP %d  |  start %.2f h\n', ...
        step,(step-1)*freqCfg.decisionInterval_h);
    fprintf('=============================================================\n');

    fprintf('Saved feature vector:\n');
    for j = 1:numel(feature)
        if j<=numel(featureNames)
            fprintf('  %-24s = %.9g\n',featureNames(j),feature(j));
        else
            fprintf('  feature%d                = %.9g\n',j,feature(j));
        end
    end

    fprintf('\nSaved formal outcome:\n');
    fprintf('  saved alpha             = %.6g\n',savedAlpha);
    fprintf('  realized max |df|       = %.6g Hz\n',actualDf);
    fprintf('  realized max |RoCoF|    = %.6g Hz/s\n',actualRoCoF);
    fprintf('  realized security stress= %.6g\n',actualSecurityStress);
    fprintf('  actual safe             = %d\n',actualSafe);

    fprintf('\nExact selector replay:\n');
    fprintf('  P1U alpha (uncalibrated)= %.6g\n',alphaU);
    fprintf('  P1  alpha (calibrated)  = %.6g\n',alphaC);
    fprintf('  calibration delta alpha = %+g\n',alphaC-alphaU);

    fprintf('\nFallback diagnostics:\n');
    fprintf('  P1U: OOD=%d | missing=%d | noSafe=%d\n', ...
        oodU,missingU,noSafeU);
    fprintf('  P1 : OOD=%d | missing=%d | noSafe=%d\n', ...
        oodC,missingC,noSafeC);

    fprintf('\nAt the SAVED alpha %.2f:\n',savedAlpha);
    fprintf('  raw predicted stress    = %.9g\n',rawAtSaved);
    fprintf('  uncal decision stress   = %.9g\n',decUAtSaved);
    fprintf('  cal decision stress     = %.9g\n',decCAtSaved);
    fprintf('  actual security stress  = %.9g\n',actualSecurityStress);

    candidateT = table( ...
        repmat(step,numel(alphaGrid),1), ...
        repmat((step-1)*freqCfg.decisionInterval_h,numel(alphaGrid),1), ...
        alphaGrid(:),rawCurve(:),decU(:),decC(:), ...
        inferredSafeU(:),inferredSafeC(:), ...
        selectedU(:),selectedC(:),selectedSaved(:), ...
        repmat(actualSecurityStress,numel(alphaGrid),1), ...
        'VariableNames',{ ...
        'MPCStep','StartTime_h','Alpha', ...
        'RawPredictedStress','UncalDecisionStress','CalDecisionStress', ...
        'InferredSafeUncal','InferredSafeCal', ...
        'SelectedByP1U','SelectedByP1','SelectedInSavedRun', ...
        'ActualSecurityStress'});

    fprintf('\nCandidate alpha curve:\n');
    disp(candidateT);

    fprintf('\nSaved metaHistory{%d} structure:\n',step);
    if isstruct(savedMeta)
        print_struct_tree_local(savedMeta,'meta',0,5);
    else
        disp(savedMeta);
    end

    % Automatic diagnosis.
    diagnosis = diagnose_step_local( ...
        savedAlpha,alphaU,alphaC, ...
        rawAtSaved,decCAtSaved, ...
        actualSecurityStress,actualSafe, ...
        oodC,missingC,noSafeC, ...
        INFERRED_SAFE_STRESS_THRESHOLD);

    fprintf('\nAUTOMATIC DIAGNOSIS:\n  %s\n',diagnosis);

    % Summary row.
    one = table();
    one.MPCStep = step;
    one.StartTime_h = (step-1)*freqCfg.decisionInterval_h;
    one.SavedAlpha = savedAlpha;
    one.ReplayedP1UAlpha = alphaU;
    one.ReplayedP1Alpha = alphaC;
    one.CalibrationAlphaDelta = alphaC-alphaU;
    one.RawPredStressAtSavedAlpha = rawAtSaved;
    one.CalPredStressAtSavedAlpha = decCAtSaved;
    one.ActualSecurityStress = actualSecurityStress;
    one.ActualMaxAbsDf_Hz = actualDf;
    one.ActualMaxAbsRoCoF_Hz_s = actualRoCoF;
    one.ActualSafe = actualSafe;
    one.P1OODFallback = oodC;
    one.P1MissingFeatureFallback = missingC;
    one.P1NoSafeCandidateFallback = noSafeC;
    one.Diagnosis = string(diagnosis);

    if isempty(stepSummary)
        stepSummary = one;
    else
        stepSummary = [stepSummary; one]; %#ok<AGROW>
    end

    if isempty(allCandidateRows)
        allCandidateRows = candidateT;
    else
        allCandidateRows = [allCandidateRows; candidateT]; %#ok<AGROW>
    end
end

%% Critical-step summary only
fprintf('\n\n=============================================================\n');
fprintf(' C. CRITICAL STEP SUMMARY\n');
fprintf('=============================================================\n');

criticalSummary = stepSummary( ...
    ismember(stepSummary.MPCStep,CRITICAL_STEPS),:);

disp(criticalSummary);

%% Calibration effectiveness summary
fprintf('\n=============================================================\n');
fprintf(' D. CALIBRATION EFFECTIVENESS AT STEPS 31/32\n');
fprintf('=============================================================\n');

for i = 1:height(criticalSummary)
    r = criticalSummary(i,:);

    fprintf('\nStep %d:\n',r.MPCStep);
    fprintf('  P1U alpha -> P1 alpha    : %.6g -> %.6g\n', ...
        r.ReplayedP1UAlpha,r.ReplayedP1Alpha);
    fprintf('  alpha increase           : %+g\n', ...
        r.CalibrationAlphaDelta);
    fprintf('  calibrated predicted     : %.6g\n', ...
        r.CalPredStressAtSavedAlpha);
    fprintf('  actual security stress   : %.6g\n', ...
        r.ActualSecurityStress);
    fprintf('  actual safe              : %d\n',r.ActualSafe);
end

%% Reproduction consistency check
fprintf('\n=============================================================\n');
fprintf(' E. SAVED-vs-REPLAYED SELECTOR CONSISTENCY\n');
fprintf('=============================================================\n');

alphaMismatch = abs(stepSummary.SavedAlpha-stepSummary.ReplayedP1Alpha)>1e-12;

consistencyT = stepSummary(:,{ ...
    'MPCStep','SavedAlpha','ReplayedP1Alpha'});

consistencyT.Match = ~alphaMismatch;

disp(consistencyT);

if any(alphaMismatch)
    warning(['The no-simulation selector replay does NOT reproduce the ', ...
        'saved alpha at every step. Inspect metaHistory/config/model ', ...
        'versioning before changing the policy.']);
else
    fprintf('PASS: replayed P1 alpha exactly reproduces saved alpha for all tested steps.\n');
end

%% Export CSVs
if EXPORT_CSV

    outDir = fullfile(runRoot,'diagnostics','P1_candidate_curve_forensics');

    if ~exist(outDir,'dir')
        mkdir(outDir);
    end

    writetable(stepSummary, ...
        fullfile(outDir,'step_summary_29_34.csv'));

    writetable(criticalSummary, ...
        fullfile(outDir,'critical_steps_31_32_summary.csv'));

    writetable(allCandidateRows, ...
        fullfile(outDir,'candidate_alpha_curves_29_34.csv'));

    fprintf('\nDiagnostics exported to:\n  %s\n',outDir);
end

fprintf('\n=============================================================\n');
fprintf(' WHAT TO SEND BACK\n');
fprintf('=============================================================\n');
fprintf(['Please send:\n', ...
    '  1) the Candidate alpha curve for Step 31;\n', ...
    '  2) the Candidate alpha curve for Step 32;\n', ...
    '  3) AUTOMATIC DIAGNOSIS for Steps 31/32;\n', ...
    '  4) the Critical Step Summary;\n', ...
    '  5) the exact selector source printed in Section A.\n']);
fprintf('=============================================================\n');


%% =========================================================================
% Local functions
% =========================================================================

function filePath = find_one_result_local(methodDir,caseName,decayRatio,seed)

decayCode = round(100*decayRatio);

pattern = sprintf('%s_*_decay%03d_seed%03d_*.mat', ...
    caseName,decayCode,seed);

hits = dir(fullfile(methodDir,pattern));

assert(~isempty(hits), ...
    'No saved result found in %s matching %s.',methodDir,pattern);

assert(numel(hits)==1, ...
    'Expected one matching result in %s; found %d.', ...
    methodDir,numel(hits));

filePath = fullfile(hits(1).folder,hits(1).name);
end


function result = load_result_local(filePath)

S = load(filePath);

if isfield(S,'result') && isstruct(S.result)
    result = S.result;
    return;
end

names = fieldnames(S);

for k = 1:numel(names)

    x = S.(names{k});

    if isstruct(x) && ...
            (isfield(x,'summary') || isfield(x,'reserve'))

        result = x;
        return;
    end
end

error('Could not identify result struct in %s.',filePath);
end


function value = get_detail_local(d,name,defaultValue)

value = defaultValue;

if isstruct(d) && isfield(d,name)
    value = d.(name);
end
end


function y = row_vector_local(x)

if isempty(x)
    y = [];
else
    y = double(x(:).');
end
end


function y = first_row_local(x)

if isempty(x)
    y = [];
    return;
end

x = double(x);

if isvector(x)
    y = x(:).';
else
    y = x(1,:);
end
end


function curve = choose_curve_local(a,b,n)

if ~isempty(a)
    curve = a;
elseif ~isempty(b)
    curve = b;
else
    curve = nan(1,n);
end
end


function y = force_length_local(x,n)

x = row_vector_local(x);

if isempty(x)
    y = nan(1,n);
elseif numel(x)==n
    y = x;
else
    error('Expected curve length %d, found %d.',n,numel(x));
end
end


function v = value_at_alpha_local(alphaGrid,curve,alpha)

idx = find(abs(alphaGrid-alpha)<1e-12,1);

if isempty(idx)
    v = NaN;
else
    v = curve(idx);
end
end


function x = logical_scalar_local(v)

if isempty(v)
    x = false;
else
    v = v(:);
    x = logical(v(1));
end
end


function diagnosis = diagnose_step_local( ...
    savedAlpha,alphaU,alphaC, ...
    rawAtSaved,calAtSaved, ...
    actualStress,actualSafe, ...
    ood,missing,noSafe,safeThreshold)

pieces = strings(0,1);

if missing
    pieces(end+1) = "MISSING-FEATURE fallback active"; %#ok<AGROW>
end

if ood
    pieces(end+1) = "OOD fallback active"; %#ok<AGROW>

    if alphaC < 1-1e-12
        pieces(end+1) = "WARNING: OOD fallback but final alpha < 1"; %#ok<AGROW>
    end
end

if noSafe
    pieces(end+1) = "NO-SAFE-CANDIDATE fallback active"; %#ok<AGROW>

    if alphaC < 1-1e-12
        pieces(end+1) = "WARNING: no-safe fallback but final alpha < 1"; %#ok<AGROW>
    end
end

if ~actualSafe

    if isfinite(calAtSaved) && calAtSaved <= safeThreshold+1e-12

        pieces(end+1) = sprintf( ...
            ['FALSE-SAFE: calibrated selector sees alpha %.2f as safe ', ...
             '(decision stress %.4f <= %.4f), but realized stress %.4f is unsafe'], ...
             savedAlpha,calAtSaved,safeThreshold,actualStress); %#ok<AGROW>

    elseif isfinite(calAtSaved) && calAtSaved > safeThreshold+1e-12 && ...
            abs(alphaC-savedAlpha)<1e-12

        pieces(end+1) = sprintf( ...
            ['SELECTOR INCONSISTENCY: chosen alpha %.2f has decision stress ', ...
             '%.4f > safe threshold %.4f'], ...
             alphaC,calAtSaved,safeThreshold); %#ok<AGROW>

    else
        pieces(end+1) = "REALIZED PHYSICAL FREQUENCY IS UNSAFE"; %#ok<AGROW>
    end
end

if abs(alphaC-alphaU)<1e-12
    pieces(end+1) = "calibration does NOT change selected alpha"; %#ok<AGROW>
else
    pieces(end+1) = sprintf( ...
        'calibration changes selected alpha %.2f -> %.2f', ...
        alphaU,alphaC); %#ok<AGROW>
end

if isfinite(rawAtSaved) && isfinite(calAtSaved)
    pieces(end+1) = sprintf( ...
        'calibration stress increment at saved alpha = %.4f', ...
        calAtSaved-rawAtSaved); %#ok<AGROW>
end

if isempty(pieces)
    diagnosis = "No automatic diagnosis.";
else
    diagnosis = strjoin(pieces," | ");
end
end


function print_struct_tree_local(x,prefix,depth,maxDepth)

if depth>maxDepth
    return;
end

if ~isstruct(x) || numel(x)~=1
    fprintf('%s  [%s %s]\n',prefix,class(x),size_text_local(x));
    return;
end

names = fieldnames(x);

for i = 1:numel(names)

    name = names{i};
    v = x.(name);
    p = string(prefix)+"."+string(name);

    if isstruct(v) && numel(v)==1
        fprintf('%s  [struct]\n',p);
        print_struct_tree_local(v,p,depth+1,maxDepth);
    else
        fprintf('%s  [%s %s]  %s\n', ...
            p,class(v),size_text_local(v),preview_local(v));
    end
end
end


function print_source_file_local(filePath,maxLines)

if isempty(filePath)
    fprintf('<source file not found>\n');
    return;
end

fprintf('File: %s\n\n',filePath);

txt = fileread(filePath);
lines = splitlines(string(txt));

n = min(numel(lines),maxLines);

for k = 1:n
    fprintf('%4d | %s\n',k,lines(k));
end

if numel(lines)>n
    fprintf('... (%d additional lines not printed)\n',numel(lines)-n);
end
end


function s = size_text_local(v)

sz = size(v);
s = sprintf('%dx',sz);

if ~isempty(s)
    s = s(1:end-1);
end
end


function p = preview_local(v)

try
    if isempty(v)
        p = '<empty>';
    elseif ischar(v)
        p = string(v);
    elseif isstring(v)
        vv = v(:);
        p = strjoin(vv(1:min(end,4))',', ');
    elseif isnumeric(v) || islogical(v)
        if isscalar(v)
            p = sprintf('%.8g',double(v));
        elseif numel(v)<=10
            p = mat2str(double(v));
        else
            finiteV = double(v(isfinite(v)));
            if isempty(finiteV)
                p = '<nonfinite>';
            else
                p = sprintf('min %.6g | max %.6g', ...
                    min(finiteV),max(finiteV));
            end
        end
    elseif iscell(v)
        p = sprintf('<cell %s>',size_text_local(v));
    else
        p = "<"+string(class(v))+">";
    end
catch
    p = '<preview unavailable>';
end

p = string(p);
end


function v = getfield_default_local(s,name,defaultValue)

v = defaultValue;

if isstruct(s) && isfield(s,name)
    v = s.(name);
end
end
