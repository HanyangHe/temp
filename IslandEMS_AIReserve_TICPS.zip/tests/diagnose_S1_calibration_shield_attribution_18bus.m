%% diagnose_S1_calibration_shield_attribution_18bus.m
% NO-SIMULATION attribution of calibration vs forecast safety shield
% using the successful in-memory results.S1 closed-loop trajectory.
%
% REQUIRED WORKSPACE VARIABLE
% ---------------------------
%   results.S1
%
% This script does NOT run MPC and does NOT run the physical simulation.
%
% Purpose
% -------
% On the EXACT realized S1 trajectory, separate:
%
%   A) KRR proposal without calibration
%   B) KRR proposal with calibration
%   C) hypothetical no-calibration + SAME forecast shield
%   D) calibrated KRR + SAME forecast shield = actual S1 logic
%
% This answers:
%   1) Which intervals are changed by calibration?
%   2) Which intervals are changed by the shield?
%   3) Where does calibration still add alpha after accounting for the shield?
%   4) What happens around steps 28:35 and 78:90?
%
% IMPORTANT INTERPRETATION
% ------------------------
% "No-calibration + shield" below is a SAME-STATE counterfactual evaluated
% on the already-realized S1 state trajectory.  It is useful for mechanism
% attribution, but it is NOT a replacement for the exact S2 closed-loop run,
% because removing calibration changes the future state/dispatch trajectory.
%
% No files are modified and no formal outputs are overwritten.

clc;

%% ------------------------------------------------------------------------
% 0. Get successful S1 result from caller/base workspace
% -------------------------------------------------------------------------
assert(evalin('base','exist(''results'',''var'')==1'), ...
    ['Workspace variable "results" was not found. Run this diagnostic in ', ...
     'the same MATLAB session that contains results.S1.']);

resultsWS = evalin('base','results');

assert(isstruct(resultsWS) && isfield(resultsWS,'S1'), ...
    'Workspace variable results does not contain results.S1.');

S1 = resultsWS.S1;

assert(isfield(S1,'reserve') && isfield(S1.reserve,'features'), ...
    'results.S1.reserve.features is missing.');
assert(isfield(S1.reserve,'ratio'), ...
    'results.S1.reserve.ratio is missing.');
assert(isfield(S1.reserve,'metaHistory'), ...
    'results.S1.reserve.metaHistory is missing.');
assert(isfield(S1,'interval'), ...
    'results.S1.interval is missing.');

projectRoot = pwd;
addpath(genpath(projectRoot));
rehash;

cfgNow = config_island_ems();

%% ------------------------------------------------------------------------
% 1. Resolve exact saved configuration/model
% -------------------------------------------------------------------------
if isfield(S1,'cfgSnapshot') && isfield(S1.cfgSnapshot,'ai')
    aiCfgBase = S1.cfgSnapshot.ai;
else
    aiCfgBase = cfgNow.ai;
    warning('S1.cfgSnapshot.ai missing; using current cfg.ai.');
end

if isfield(S1,'cfgSnapshot') && isfield(S1.cfgSnapshot,'frequency')
    freqCfg = S1.cfgSnapshot.frequency;
else
    freqCfg = cfgNow.frequency;
end

if isfield(S1,'cfgSnapshot') && isfield(S1.cfgSnapshot,'mpc') && ...
        isfield(S1.cfgSnapshot.mpc,'decisionInterval_h')
    dt_h = double(S1.cfgSnapshot.mpc.decisionInterval_h);
else
    dt_h = double(cfgNow.mpc.decisionInterval_h);
end

caseName = '18bus';
if isfield(S1,'meta') && isfield(S1.meta,'caseName')
    caseName = char(S1.meta.caseName);
end

modelFile = fullfile(projectRoot, ...
    char(aiCfgBase.modelRoot),caseName,char(aiCfgBase.modelFileName));

if exist(modelFile,'file')~=2
    modelFile = fullfile(projectRoot, ...
        char(aiCfgBase.modelRoot),char(aiCfgBase.modelFileName));
end

assert(exist(modelFile,'file')==2, ...
    'Could not find AI model: %s',modelFile);

M = load(modelFile);
assert(isfield(M,'model'),'Model MAT does not contain variable "model".');
model = M.model;

assert(exist('select_reserve_alpha_batch','file')==2, ...
    'select_reserve_alpha_batch.m is not on MATLAB path.');

%% ------------------------------------------------------------------------
% 2. Exact S1 state trajectory
% -------------------------------------------------------------------------
X = double(S1.reserve.features);
alphaFinalSaved = double(S1.reserve.ratio(:));
n = size(X,1);

assert(numel(alphaFinalSaved)==n, ...
    'Feature/alpha length mismatch.');

if isfield(S1.reserve,'featureNames')
    featureNames = string(S1.reserve.featureNames);
elseif isfield(model,'stateFeatureNames')
    featureNames = string(model.stateFeatureNames);
else
    featureNames = ["netLoadNow_pu","absNetLoadRamp_pu","dgUpHeadroom_pu"];
end

iNet  = find(featureNames=="netLoadNow_pu",1);
iRamp = find(featureNames=="absNetLoadRamp_pu",1);
iHead = find(featureNames=="dgUpHeadroom_pu",1);

assert(~isempty(iNet) && ~isempty(iRamp) && ~isempty(iHead), ...
    'Required frozen 3-feature contract not found.');

netNowFeature = X(:,iNet);
absRampFeature = X(:,iRamp);
headroom = X(:,iHead);

%% ------------------------------------------------------------------------
% 3. Replay KRR selector twice on the SAME S1 states
% -------------------------------------------------------------------------
aiU = aiCfgBase;
aiU.useSafetyCalibration = false;

[alphaKRR_U,dU] = select_reserve_alpha_batch( ...
    model,X,aiU,false);

alphaKRR_U = double(alphaKRR_U(:));

aiC = aiCfgBase;
aiC.useSafetyCalibration = true;

[alphaKRR_C,dC] = select_reserve_alpha_batch( ...
    model,X,aiC,true);

alphaKRR_C = double(alphaKRR_C(:));

alphaGrid = double(dC.alphaGrid(:).');
rawCurve = double(dC.rawStress);
calCurve = double(dC.decisionStress);

%% ------------------------------------------------------------------------
% 4. Pull EXACT forecast-shield information saved during S1
% -------------------------------------------------------------------------
forecastNetNow = nan(n,1);
forecastSignedRamp = nan(n,1);
forecastDrop = nan(n,1);

actualPreShieldAlpha = nan(n,1);
actualPostShieldAlpha = nan(n,1);
actualShieldTriggered = false(n,1);
actualShieldEnabled = false(n,1);
actualUsedCalibration = false(n,1);

savedOOD = false(n,1);
savedNoSafe = false(n,1);
savedMissing = false(n,1);

H = S1.reserve.metaHistory;

for k = 1:min(n,numel(H))
    m = H{k};

    if ~isstruct(m) || ~isfield(m,'prediction') || ...
            ~isstruct(m.prediction)
        continue;
    end

    q = m.prediction;

    forecastNetNow(k) = get_scalar_local( ...
        q,'forecastNetLoadNow_pu',NaN);

    forecastSignedRamp(k) = get_scalar_local( ...
        q,'forecastSignedNetRamp_pu',NaN);

    forecastDrop(k) = get_scalar_local( ...
        q,'forecastNetDrop_pu',NaN);

    actualPreShieldAlpha(k) = get_scalar_local( ...
        q,'preShieldAlpha',NaN);

    actualPostShieldAlpha(k) = get_scalar_local( ...
        q,'postShieldAlpha',alphaFinalSaved(k));

    actualShieldTriggered(k) = get_logical_local( ...
        q,'forecastSafetyShieldTriggered',false);

    actualShieldEnabled(k) = get_logical_local( ...
        q,'forecastSafetyShieldEnabled',false);

    actualUsedCalibration(k) = get_logical_local( ...
        q,'usedCalibration',false);

    savedOOD(k) = get_logical_local(q,'oodFallback',false);
    savedNoSafe(k) = get_logical_local(q,'noSafeCandidateFallback',false);
    savedMissing(k) = get_logical_local(q,'missingFeatureFallback',false);
end

% If saved forecast netNow is absent for any row, feature 1 is equivalent.
forecastNetNow(~isfinite(forecastNetNow)) = ...
    netNowFeature(~isfinite(forecastNetNow));

%% ------------------------------------------------------------------------
% 5. Resolve shield settings actually used
% -------------------------------------------------------------------------
dropThreshold = getfield_default_local( ...
    aiCfgBase,'forecastSafetyShieldDropThreshold_pu',0.02);

netLoadMin = getfield_default_local( ...
    aiCfgBase,'forecastSafetyShieldNetLoadMin_pu',0.60);

shieldAlpha = getfield_default_local( ...
    aiCfgBase,'forecastSafetyShieldAlpha', ...
    getfield_default_local(aiCfgBase,'fallbackAlpha',1.0));

% Use saved metadata as primary evidence that shield was enabled.
shieldEnabled = any(actualShieldEnabled);
if ~shieldEnabled
    shieldEnabled = getfield_default_local( ...
        aiCfgBase,'enableForecastSafetyShield',false);
end

%% ------------------------------------------------------------------------
% 6. Reconstruct SAME shield on uncalibrated/calibrated KRR proposals
% -------------------------------------------------------------------------
shieldEligibleForecast = ...
    isfinite(forecastDrop) & ...
    isfinite(forecastNetNow) & ...
    forecastDrop >= dropThreshold-1e-12 & ...
    forecastNetNow >= netLoadMin-1e-12;

wouldTrigger_U = shieldEnabled & ...
    shieldEligibleForecast & ...
    alphaKRR_U < shieldAlpha-1e-12;

wouldTrigger_C = shieldEnabled & ...
    shieldEligibleForecast & ...
    alphaKRR_C < shieldAlpha-1e-12;

alpha_U_plusShield = alphaKRR_U;
alpha_U_plusShield(wouldTrigger_U) = shieldAlpha;

alpha_C_plusShield = alphaKRR_C;
alpha_C_plusShield(wouldTrigger_C) = shieldAlpha;

%% ------------------------------------------------------------------------
% 7. Consistency checks against actual S1
% -------------------------------------------------------------------------
tol = 1e-10;

preShieldMatch = ...
    ~isfinite(actualPreShieldAlpha) | ...
    abs(actualPreShieldAlpha-alphaKRR_C)<=tol;

postShieldMatch = ...
    abs(alphaFinalSaved-alpha_C_plusShield)<=tol;

triggerMatch = actualShieldTriggered==wouldTrigger_C;

%% ------------------------------------------------------------------------
% 8. KRR stresses at selected proposals
% -------------------------------------------------------------------------
rawStressAtU = nan(n,1);
rawStressAtC = nan(n,1);
calStressAtU = nan(n,1);
calStressAtC = nan(n,1);
rawStressAtFinal = nan(n,1);
calStressAtFinal = nan(n,1);

for k=1:n
    rawStressAtU(k) = curve_value_at_alpha_local( ...
        alphaGrid,rawCurve(k,:),alphaKRR_U(k));

    rawStressAtC(k) = curve_value_at_alpha_local( ...
        alphaGrid,rawCurve(k,:),alphaKRR_C(k));

    calStressAtU(k) = curve_value_at_alpha_local( ...
        alphaGrid,calCurve(k,:),alphaKRR_U(k));

    calStressAtC(k) = curve_value_at_alpha_local( ...
        alphaGrid,calCurve(k,:),alphaKRR_C(k));

    rawStressAtFinal(k) = curve_value_at_alpha_local( ...
        alphaGrid,rawCurve(k,:),alphaFinalSaved(k));

    calStressAtFinal(k) = curve_value_at_alpha_local( ...
        alphaGrid,calCurve(k,:),alphaFinalSaved(k));
end

%% ------------------------------------------------------------------------
% 9. Realized physical frequency outcome
% -------------------------------------------------------------------------
df = double(S1.interval.maxAbsFreqDev_Hz(:));
rocof = double(S1.interval.maxAbsRoCoF_Hz_s(:));

dfLim = double(freqCfg.securityDeviation_Hz);
rocofLim = double(freqCfg.securityRoCoF_Hz_s);

actualStress = max(df/dfLim,rocof/rocofLim);
coiUnsafe = actualStress>1+1e-12;

step = (1:n).';
time_h = (step-1)*dt_h;

%% ------------------------------------------------------------------------
% 10. Attribution quantities
% -------------------------------------------------------------------------
calChangedPreShield = abs(alphaKRR_C-alphaKRR_U)>tol;
shieldChangedActual = actualShieldTriggered & ...
    isfinite(actualPreShieldAlpha) & ...
    actualPostShieldAlpha>actualPreShieldAlpha+tol;

% Same-state comparison after applying identical forecast shield.
calAddsAfterShield = alpha_C_plusShield > alpha_U_plusShield+tol;
calReducesAfterShield = alpha_C_plusShield < alpha_U_plusShield-tol;

calIncrementPreShield = alphaKRR_C-alphaKRR_U;
shieldIncrementActual = alphaFinalSaved-alphaKRR_C;
calIncrementAfterSameShield = alpha_C_plusShield-alpha_U_plusShield;

%% ------------------------------------------------------------------------
% 11. Main per-step table
% -------------------------------------------------------------------------
T = table( ...
    step,time_h, ...
    netNowFeature,absRampFeature,headroom, ...
    forecastNetNow,forecastSignedRamp,forecastDrop, ...
    alphaKRR_U,alphaKRR_C, ...
    wouldTrigger_U,wouldTrigger_C, ...
    alpha_U_plusShield,alpha_C_plusShield, ...
    actualPreShieldAlpha,actualShieldTriggered,alphaFinalSaved, ...
    calChangedPreShield,shieldChangedActual,calAddsAfterShield, ...
    calIncrementPreShield,shieldIncrementActual, ...
    calIncrementAfterSameShield, ...
    rawStressAtU,calStressAtU,rawStressAtC,calStressAtC, ...
    rawStressAtFinal,calStressAtFinal, ...
    df,rocof,actualStress,coiUnsafe, ...
    savedOOD,savedNoSafe,savedMissing, ...
    preShieldMatch,postShieldMatch,triggerMatch, ...
    'VariableNames',{ ...
    'MPCStep','StartTime_h', ...
    'NetLoadNowFeature_pu','AbsNetLoadRampFeature_pu','DGUpHeadroom_pu', ...
    'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu','ForecastNetDrop_pu', ...
    'AlphaKRR_Uncal','AlphaKRR_Cal', ...
    'ShieldWouldTrigger_Uncal','ShieldWouldTrigger_Cal', ...
    'AlphaUncalPlusShield','AlphaCalPlusShield', ...
    'ActualPreShieldAlpha','ActualShieldTriggered','ActualFinalAlpha', ...
    'CalibrationChangedPreShield','ShieldChangedActual', ...
    'CalibrationAddsAfterSameShield', ...
    'CalibrationIncrementPreShield','ShieldIncrementActual', ...
    'CalibrationIncrementAfterSameShield', ...
    'RawStressAtUncalAlpha','CalStressAtUncalAlpha', ...
    'RawStressAtCalAlpha','CalStressAtCalAlpha', ...
    'RawStressAtFinalAlpha','CalStressAtFinalAlpha', ...
    'ActualMaxAbsDf_Hz','ActualMaxAbsRoCoF_Hz_s', ...
    'ActualSecurityStress','CoIUnsafe', ...
    'OODFallback','NoSafeCandidateFallback','MissingFeatureFallback', ...
    'PreShieldReplayMatch','PostShieldReplayMatch','ShieldTriggerReplayMatch'});

%% ------------------------------------------------------------------------
% 12. Print results
% -------------------------------------------------------------------------
fprintf('\n=============================================================\n');
fprintf(' S1 CALIBRATION + FORECAST-SHIELD ATTRIBUTION\n');
fprintf(' NO SIMULATION -- IN-MEMORY results.S1\n');
fprintf('=============================================================\n');
fprintf('case                : %s\n',caseName);
fprintf('n MPC intervals     : %d\n',n);
fprintf('shield enabled      : %d\n',shieldEnabled);
fprintf('shield drop thr     : %.6f pu\n',dropThreshold);
fprintf('shield net-load min : %.6f pu\n',netLoadMin);
fprintf('shield alpha        : %.6f\n',shieldAlpha);
fprintf('calibration offset  : %.6f\n', ...
    getfield_default_local(model,'calibrationOffset',NaN));
fprintf('=============================================================\n');

fprintf('\nA. HARD CONSISTENCY CHECKS\n');
fprintf('-------------------------------------------------------------\n');
fprintf('Calibrated pre-shield replay mismatches : %d\n',nnz(~preShieldMatch));
fprintf('Final alpha replay mismatches           : %d\n',nnz(~postShieldMatch));
fprintf('Shield-trigger replay mismatches        : %d\n',nnz(~triggerMatch));
fprintf('Actual S1 CoI unsafe intervals          : %s\n',mat2str(find(coiUnsafe).'));

if any(~preShieldMatch | ~postShieldMatch | ~triggerMatch)
    warning(['Attribution replay does not exactly reproduce all S1 metadata. ', ...
        'Inspect mismatching rows before drawing conclusions.']);
else
    fprintf('PASS: attribution exactly reproduces the saved S1 online logic.\n');
end

fprintf('\nB. OVERALL ATTRIBUTION SUMMARY\n');
fprintf('-------------------------------------------------------------\n');

summaryT = table();
summaryT.Metric = [ ...
    "Mean alpha: KRR uncalibrated"; ...
    "Mean alpha: KRR calibrated"; ...
    "Mean alpha: uncalibrated + same shield"; ...
    "Mean alpha: calibrated + same shield"; ...
    "Mean alpha: actual saved S1"; ...
    "Calibration-changed pre-shield intervals"; ...
    "Actual shield-trigger intervals"; ...
    "Calibration adds alpha after same shield"; ...
    "Actual CoI-unsafe intervals"];

summaryT.Value = [ ...
    mean(alphaKRR_U,'omitnan'); ...
    mean(alphaKRR_C,'omitnan'); ...
    mean(alpha_U_plusShield,'omitnan'); ...
    mean(alpha_C_plusShield,'omitnan'); ...
    mean(alphaFinalSaved,'omitnan'); ...
    nnz(calChangedPreShield); ...
    nnz(actualShieldTriggered); ...
    nnz(calAddsAfterShield); ...
    nnz(coiUnsafe)];

disp(summaryT);

fprintf('\nMean alpha increments on this SAME S1 state trajectory:\n');
fprintf('  calibration before shield : %+0.6f\n', ...
    mean(alphaKRR_C-alphaKRR_U,'omitnan'));
fprintf('  actual shield after cal   : %+0.6f\n', ...
    mean(alphaFinalSaved-alphaKRR_C,'omitnan'));
fprintf('  calibration after applying same shield to both branches: %+0.6f\n', ...
    mean(alpha_C_plusShield-alpha_U_plusShield,'omitnan'));

fprintf('\nC. INTERVALS CHANGED BY CALIBRATION BEFORE SHIELD\n');
fprintf('-------------------------------------------------------------\n');
idx = calChangedPreShield;
if any(idx)
    disp(T(idx,{ ...
        'MPCStep','StartTime_h', ...
        'AlphaKRR_Uncal','AlphaKRR_Cal', ...
        'ShieldWouldTrigger_Uncal','ShieldWouldTrigger_Cal', ...
        'AlphaUncalPlusShield','AlphaCalPlusShield', ...
        'ActualFinalAlpha', ...
        'ForecastNetLoadNow_pu','ForecastNetDrop_pu', ...
        'CalStressAtUncalAlpha','CalStressAtCalAlpha', ...
        'ActualSecurityStress'}));
else
    fprintf('NONE\n');
end

fprintf('\nD. ACTUAL S1 SHIELD-TRIGGER INTERVALS\n');
fprintf('-------------------------------------------------------------\n');
idx = actualShieldTriggered;
if any(idx)
    disp(T(idx,{ ...
        'MPCStep','StartTime_h', ...
        'AlphaKRR_Uncal','AlphaKRR_Cal', ...
        'ActualPreShieldAlpha','ActualFinalAlpha', ...
        'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu', ...
        'ForecastNetDrop_pu','DGUpHeadroom_pu', ...
        'ActualSecurityStress'}));
else
    fprintf('NONE\n');
end

fprintf('\nE. WHERE CALIBRATION STILL ADDS ALPHA AFTER THE SAME SHIELD\n');
fprintf('-------------------------------------------------------------\n');
idx = calAddsAfterShield;
if any(idx)
    disp(T(idx,{ ...
        'MPCStep','StartTime_h', ...
        'AlphaKRR_Uncal','AlphaKRR_Cal', ...
        'ShieldWouldTrigger_Uncal','ShieldWouldTrigger_Cal', ...
        'AlphaUncalPlusShield','AlphaCalPlusShield', ...
        'ForecastNetLoadNow_pu','ForecastNetDrop_pu', ...
        'ActualSecurityStress'}));
else
    fprintf(['NONE on the S1 state trajectory.  This would mean the shield ', ...
        'fully masks the calibration alpha increase at all states.\n']);
end

fprintf('\nF. MORNING MECHANISM WINDOW -- STEPS 27:36\n');
fprintf('-------------------------------------------------------------\n');
w = 27:min(36,n);
disp(T(w,{ ...
    'MPCStep','StartTime_h', ...
    'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu','ForecastNetDrop_pu', ...
    'DGUpHeadroom_pu', ...
    'AlphaKRR_Uncal','AlphaKRR_Cal', ...
    'ShieldWouldTrigger_Uncal','ShieldWouldTrigger_Cal', ...
    'AlphaUncalPlusShield','ActualFinalAlpha', ...
    'ActualSecurityStress','CoIUnsafe'}));

fprintf('\nG. LATE-DAY MECHANISM WINDOW -- STEPS 76:92\n');
fprintf('-------------------------------------------------------------\n');
w = 76:min(92,n);
disp(T(w,{ ...
    'MPCStep','StartTime_h', ...
    'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu','ForecastNetDrop_pu', ...
    'DGUpHeadroom_pu', ...
    'AlphaKRR_Uncal','AlphaKRR_Cal', ...
    'ShieldWouldTrigger_Uncal','ShieldWouldTrigger_Cal', ...
    'AlphaUncalPlusShield','ActualFinalAlpha', ...
    'ActualSecurityStress','CoIUnsafe'}));

fprintf('\nH. STEP 34 FOCUSED ATTRIBUTION\n');
fprintf('-------------------------------------------------------------\n');
if n>=34
    disp(T(34,{ ...
        'MPCStep','StartTime_h', ...
        'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu','ForecastNetDrop_pu', ...
        'DGUpHeadroom_pu', ...
        'AlphaKRR_Uncal','AlphaKRR_Cal', ...
        'ShieldWouldTrigger_Uncal','ShieldWouldTrigger_Cal', ...
        'AlphaUncalPlusShield','AlphaCalPlusShield','ActualFinalAlpha', ...
        'RawStressAtUncalAlpha','CalStressAtUncalAlpha', ...
        'RawStressAtCalAlpha','CalStressAtCalAlpha', ...
        'ActualMaxAbsDf_Hz','ActualMaxAbsRoCoF_Hz_s','ActualSecurityStress'}));
end

fprintf('\nI. MECHANISM INTERPRETATION GUARDRAIL\n');
fprintf('-------------------------------------------------------------\n');
fprintf(['The columns AlphaUncalPlusShield and AlphaCalPlusShield are ', ...
    'same-state policy counterfactuals on the REALIZED S1 trajectory.\n']);
fprintf(['They identify which layer changes alpha at a given S1 state, but ', ...
    'they do NOT prove what the physical trajectory would have been if ', ...
    'calibration had been removed from the beginning of the day.\n']);
fprintf(['The exact S2 closed-loop run remains the evidence for that different ', ...
    'trajectory.\n']);

%% ------------------------------------------------------------------------
% 13. Export convenient workspace variables
% -------------------------------------------------------------------------
assignin('base','S1_attribution_table',T);
assignin('base','S1_attribution_summary',summaryT);

fprintf('\n=============================================================\n');
fprintf(' EXPORTED TO BASE WORKSPACE\n');
fprintf('=============================================================\n');
fprintf('  S1_attribution_table\n');
fprintf('  S1_attribution_summary\n');
fprintf('\nPlease send back Sections B, C, D, E, F, and H.\n');
fprintf('=============================================================\n');


%% =========================================================================
% Local functions
% =========================================================================

function v = curve_value_at_alpha_local(alphaGrid,curve,alpha)
j = find(abs(alphaGrid-alpha)<1e-12,1);
if isempty(j)
    v = NaN;
else
    v = double(curve(j));
end
end


function v = getfield_default_local(s,name,defaultValue)
v = defaultValue;
if isstruct(s) && isfield(s,name)
    v = s.(name);
end
end


function v = get_scalar_local(s,name,defaultValue)
v = defaultValue;
if isstruct(s) && isfield(s,name)
    x = s.(name);
    if isnumeric(x) && isscalar(x)
        v = double(x);
    end
end
end


function v = get_logical_local(s,name,defaultValue)
v = logical(defaultValue);
if isstruct(s) && isfield(s,name)
    x = s.(name);
    if (islogical(x) || isnumeric(x)) && isscalar(x)
        v = logical(x);
    end
end
end
