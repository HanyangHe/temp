function test_paper_study_plan()
%TEST_PAPER_STUDY_PLAN Static paper-scope contract.
%
% Critical rule:
%   Part I adaptive-reserve ablation runs at decayRatio=1.00 ONLY.
%
% Part II keeps the full generation-shortage sweep.

cfg = config_island_ems();
plan = cfg.experiment.paperStudies;
catalog = paper_method_catalog();
ids = string({catalog.id});

expectedAI = ["A0","T7","G1","P1U","P1"];
expectedAILabels = ["A0","F1","G1","P1U","P1"];
expectedCurt = ["C0","C1","P1"];
expectedRunOrder = ["A0","T7","G1","P1U","P1","C0","C1"];
expectedPart2Decay = [0.20 0.40 0.60 0.80 1.00];

assert(isequal(string(plan.aiReserveAblation.methods),expectedAI), ...
    'Part-I method set changed unexpectedly.');
assert(isequal(string(plan.aiReserveAblation.paperLabels),expectedAILabels), ...
    'Part-I paper labels changed unexpectedly.');

% CRITICAL CONTRACT
assert(isscalar(plan.aiReserveAblation.decayRatios) && ...
       abs(plan.aiReserveAblation.decayRatios-1.0)<1e-12, ...
    ['Part I MUST run only at decayRatio=1.00. ', ...
     'Generation-shortage decay sweeps are forbidden for Part I.']);

assert(isequal(string(plan.curtailmentAllocationCost.methods),expectedCurt), ...
    'Part-II method set changed unexpectedly.');
assert(isequal(plan.curtailmentAllocationCost.decayRatios,expectedPart2Decay), ...
    'Part-II shortage decay sweep changed unexpectedly.');

assert(isequal(string(cfg.experiment.enabledMethods),expectedRunOrder), ...
    'Formal method union changed unexpectedly.');
assert(plan.useStudySpecificDecayScheduling, ...
    'Formal runner must use study-specific decay scheduling.');

assert(all(ismember(expectedRunOrder,ids)), ...
    'Paper method catalog is missing a formal method.');

% Part II must hold reserve/controller structure fixed.
C0 = catalog(find(ids=="C0",1));
C1 = catalog(find(ids=="C1",1));
P1 = catalog(find(ids=="P1",1));

stage2 = {C0,C1,P1};
expectedCurtModes = ["none","bess","hierarchical"];
for k = 1:3
    m = stage2{k};
    assert(m.legacyCase==9, ...
        '%s must use the same MPC-SOCP engine as P1.',m.id);
    assert(strcmpi(m.reserveMode,'ai'), ...
        '%s must use adaptive reserve.',m.id);
    assert(m.aiSafetyCalibration, ...
        '%s must use calibrated adaptive reserve.',m.id);
    assert(strcmpi(m.curtailmentMode,expectedCurtModes(k)), ...
        '%s has an unexpected curtailment mode.',m.id);
end

% Build the expected formal method/decay pairs.
pairs = strings(0,1);
for d = plan.aiReserveAblation.decayRatios
    for m = string(plan.aiReserveAblation.methods)
        pairs(end+1,1) = sprintf('%s@%.2f',m,d); %#ok<AGROW>
    end
end
for d = plan.curtailmentAllocationCost.decayRatios
    for m = string(plan.curtailmentAllocationCost.methods)
        pairs(end+1,1) = sprintf('%s@%.2f',m,d); %#ok<AGROW>
    end
end
pairs = unique(pairs,'stable');

% 5 Part-I pairs + 15 Part-II pairs - shared P1@1 = 19.
assert(numel(pairs)==19, ...
    'Expected exactly 19 unique method/decay pairs per grid.');

assert(~any(contains(pairs,["A0@0.20","A0@0.40","A0@0.60","A0@0.80"])), ...
    'Part-I A0 shortage cases must not be scheduled.');
assert(~any(contains(pairs,["T7@0.20","T7@0.40","T7@0.60","T7@0.80"])), ...
    'Part-I F1/T7 shortage cases must not be scheduled.');
assert(~any(contains(pairs,["G1@0.20","G1@0.40","G1@0.60","G1@0.80"])), ...
    'Part-I G1 shortage cases must not be scheduled.');
assert(~any(contains(pairs,["P1U@0.20","P1U@0.40","P1U@0.60","P1U@0.80"])), ...
    'Part-I P1U shortage cases must not be scheduled.');

% P1 shortage results MUST remain because they belong to Part II.
for d = [0.20 0.40 0.60 0.80]
    assert(any(pairs==sprintf('P1@%.2f',d)), ...
        'P1 decay %.2f must be retained for Part II.',d);
end

fprintf(['Paper study-plan test passed:\n', ...
    '  Part I  : A0, F1(T7), G1, P1U, P1 at decay=1.00 ONLY\n', ...
    '  Part II : C0, C1, P1 across decay=[0.20 0.40 0.60 0.80 1.00]\n', ...
    '  Formal unique schedule: 19 method/decay pairs per grid.\n']);
end
