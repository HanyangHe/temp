%% smoke_P1_ai_internal_structure_18bus.m
% NO-SIMULATION source/structure forensic test for the P1 reserve controller.
%
% Why this test exists
% --------------------
% The previous Step-31/32 forensic test proved that P1 and P1U both choose
% alpha=0.60 exactly at the unsafe intervals, but the saved result did not
% expose the AI feature/prediction/calibration/fallback fields under the
% guessed names.
%
% This script does NOT guess further.  Instead it:
%   1) inventories the saved P1 result structure, especially reserve/interval;
%   2) finds every 96/97-step numeric signal and prints steps 27:35;
%   3) inventories the trained model MAT file and searches for calibration,
%      feature, normalization, OOD, and stress metadata;
%   4) scans project MATLAB source files for the exact online reserve-decision
%      implementation and prints matching file names + line numbers.
%
% NO optimization. NO physical simulation. NO result overwrite.

clear;
clc;

%% User options
FORMAL_RUN_TAG = '20260907_115951';
WINDOW_STEPS = 27:35;
MAX_SOURCE_MATCHES_PER_TOKEN = 30;
MAX_TREE_DEPTH = 6;

%% Setup
projectRoot = pwd;
addpath(genpath(projectRoot));
rehash;

cfg = config_island_ems();

caseName = '18bus';
decayRatio = 1.00;
seed = 0;

runRoot = fullfile(projectRoot,cfg.output.root,FORMAL_RUN_TAG);
assert(exist(runRoot,'dir')==7,'Run root not found: %s',runRoot);

p1File = find_one_result_local( ...
    fullfile(runRoot,'P1'),caseName,decayRatio,seed);

result = load_result_local(p1File);

fprintf('\n=============================================================\n');
fprintf(' P1 AI INTERNAL-STRUCTURE / SOURCE FORENSICS -- NO SIMULATION\n');
fprintf('=============================================================\n');
fprintf(' P1 file       : %s\n',p1File);
fprintf(' window steps  : %s\n',mat2str(WINDOW_STEPS));
fprintf('=============================================================\n');

%% ------------------------------------------------------------------------
% A. Exact saved-result field inventory
% -------------------------------------------------------------------------

fprintf('\n=============================================================\n');
fprintf(' A. TOP-LEVEL RESULT FIELDS\n');
fprintf('=============================================================\n');
disp(fieldnames(result));

if isfield(result,'reserve')
    fprintf('\n=============================================================\n');
    fprintf(' B. result.reserve FIELD TREE\n');
    fprintf('=============================================================\n');
    print_struct_tree_local(result.reserve,'result.reserve',0,MAX_TREE_DEPTH);
else
    fprintf('\nresult.reserve does not exist.\n');
end

if isfield(result,'interval')
    fprintf('\n=============================================================\n');
    fprintf(' C. result.interval FIELD TREE\n');
    fprintf('=============================================================\n');
    print_struct_tree_local(result.interval,'result.interval',0,MAX_TREE_DEPTH);
else
    fprintf('\nresult.interval does not exist.\n');
end

if isfield(result,'meta')
    fprintf('\n=============================================================\n');
    fprintf(' D. result.meta FIELD TREE\n');
    fprintf('=============================================================\n');
    print_struct_tree_local(result.meta,'result.meta',0,4);
end

%% ------------------------------------------------------------------------
% B. Search all saved-result leaves for AI/reserve-related names
% -------------------------------------------------------------------------

keywords = [ ...
    "alpha","reserve","stress","predict","calib","ood","fallback", ...
    "safe","feature","netload","ramp","headroom","krr","model", ...
    "candidate","query","raw","offset","coverage","risk"];

allLeaves = collect_leaves_local(result,'result',0,MAX_TREE_DEPTH);

keep = false(height(allLeaves),1);
for i = 1:height(allLeaves)
    p = lower(allLeaves.Path(i));
    keep(i) = any(contains(p,keywords));
end

interestingLeaves = allLeaves(keep,:);

fprintf('\n=============================================================\n');
fprintf(' E. AI / RESERVE-RELATED SAVED LEAVES\n');
fprintf('=============================================================\n');

if isempty(interestingLeaves)
    fprintf('No matching leaves found.\n');
else
    disp(interestingLeaves(:,{'Path','Class','SizeText','Preview'}));
end

%% ------------------------------------------------------------------------
% C. Find all step-level 96/97 signals and print window values
% -------------------------------------------------------------------------

fprintf('\n=============================================================\n');
fprintf(' F. ALL SAVED 96/97-STEP NUMERIC SIGNALS\n');
fprintf('=============================================================\n');

stepSignals = find_step_signals_local(result,'result',96,0,MAX_TREE_DEPTH);

if isempty(stepSignals)
    fprintf('No 96/97-step numeric signals found.\n');
else
    disp(stepSignals(:,{'Path','Class','SizeText'}));
end

fprintf('\n=============================================================\n');
fprintf(' G. VALUES AT MPC STEPS %d:%d\n',WINDOW_STEPS(1),WINDOW_STEPS(end));
fprintf('=============================================================\n');

for i = 1:height(stepSignals)

    path = stepSignals.Path(i);
    [ok,v] = get_path_local(result,erase(path,"result."));

    if ~ok
        continue;
    end

    fprintf('\n%s   size=%s\n',path,stepSignals.SizeText(i));
    print_step_window_local(v,WINDOW_STEPS);
end

%% ------------------------------------------------------------------------
% D. Trained AI model MAT inventory
% -------------------------------------------------------------------------

modelFile = resolve_model_file_local(cfg,projectRoot,caseName);

fprintf('\n=============================================================\n');
fprintf(' H. AI MODEL FILE\n');
fprintf('=============================================================\n');

if strlength(modelFile)==0 || exist(modelFile,'file')~=2
    fprintf('Model file could not be resolved automatically.\n');
else
    fprintf('Model file: %s\n',modelFile);

    M = load(modelFile);

    fprintf('\nTop-level model MAT fields:\n');
    disp(fieldnames(M));

    modelLeaves = collect_leaves_local(M,'modelMAT',0,MAX_TREE_DEPTH);

    modelKeywords = [ ...
        "feature","name","mean","std","scale","norm","kernel","lambda", ...
        "sigma","calib","offset","risk","coverage","ood","bound","stress", ...
        "alpha","train","group","rmse","mae","threshold","fallback"];

    keepM = false(height(modelLeaves),1);
    for i = 1:height(modelLeaves)
        p = lower(modelLeaves.Path(i));
        keepM(i) = any(contains(p,modelKeywords));
    end

    modelInteresting = modelLeaves(keepM,:);

    fprintf('\nAI-model metadata relevant to prediction/safety:\n');
    if isempty(modelInteresting)
        fprintf('No matching model metadata leaves found.\n');
    else
        disp(modelInteresting(:,{'Path','Class','SizeText','Preview'}));
    end
end

%% ------------------------------------------------------------------------
% E. Static source-code locator for the actual online P1 decision
% -------------------------------------------------------------------------

fprintf('\n=============================================================\n');
fprintf(' I. SOURCE-CODE LOCATOR FOR ONLINE RESERVE DECISION\n');
fprintf('=============================================================\n');

sourceTokens = { ...
    'candidateAlphaGrid', ...
    'useSafetyCalibration', ...
    'calibrationRisk', ...
    'calibrationOffset', ...
    'noSafeCandidate', ...
    'fallbackAlpha', ...
    'useOODFallback', ...
    'oodMarginStd', ...
    'netLoadNow_pu', ...
    'absNetLoadRamp_pu', ...
    'dgUpHeadroom_pu', ...
    'predictedStress', ...
    'reserveRatio', ...
    'alphaGrid', ...
    'predict('};

mFiles = dir(fullfile(projectRoot,'**','*.m'));

% Exclude outputs and generated replay/diagnostic folders from source scan.
valid = true(numel(mFiles),1);
for i = 1:numel(mFiles)
    f = fullfile(mFiles(i).folder,mFiles(i).name);
    fLow = lower(strrep(f,'/','\'));
    if contains(fLow,[filesep 'outputs' filesep]) || ...
       contains(fLow,[filesep 'manuscript_replay' filesep]) || ...
       contains(fLow,[filesep 'diagnostics' filesep])
        valid(i)=false;
    end
end
mFiles = mFiles(valid);

allSourceHits = table();

for it = 1:numel(sourceTokens)

    token = sourceTokens{it};
    hitCount = 0;

    fprintf('\n----- token: %s -----\n',token);

    for i = 1:numel(mFiles)

        filePath = fullfile(mFiles(i).folder,mFiles(i).name);

        try
            txt = fileread(filePath);
        catch
            continue;
        end

        lines = splitlines(string(txt));

        idx = find(contains(lower(lines),lower(string(token))));

        for j = 1:numel(idx)

            lineNo = idx(j);
            lineText = strtrim(lines(lineNo));

            fprintf('%s : %d\n',relative_path_local(filePath,projectRoot),lineNo);
            fprintf('    %s\n',lineText);

            one = table();
            one.Token = string(token);
            one.File = string(relative_path_local(filePath,projectRoot));
            one.Line = lineNo;
            one.Text = lineText;

            if isempty(allSourceHits)
                allSourceHits = one;
            else
                allSourceHits = [allSourceHits; one]; %#ok<AGROW>
            end

            hitCount = hitCount + 1;

            if hitCount >= MAX_SOURCE_MATCHES_PER_TOKEN
                break;
            end
        end

        if hitCount >= MAX_SOURCE_MATCHES_PER_TOKEN
            break;
        end
    end

    if hitCount==0
        fprintf('  <no source match>\n');
    end
end

%% ------------------------------------------------------------------------
% F. Rank likely decision-logic files by number of relevant source hits
% -------------------------------------------------------------------------

fprintf('\n=============================================================\n');
fprintf(' J. LIKELY ONLINE RESERVE-DECISION FILES\n');
fprintf('=============================================================\n');

if isempty(allSourceHits)
    fprintf('No relevant source hits found.\n');
else
    filesUnique = unique(allSourceHits.File);
    nHits = zeros(numel(filesUnique),1);
    tokensFound = strings(numel(filesUnique),1);

    for i = 1:numel(filesUnique)
        idx = allSourceHits.File==filesUnique(i);
        nHits(i)=nnz(idx);
        tokensFound(i)=strjoin(unique(allSourceHits.Token(idx))',', ');
    end

    rankTable = table(filesUnique,nHits,tokensFound, ...
        'VariableNames',{'File','RelevantHitCount','TokensFound'});

    rankTable = sortrows(rankTable,'RelevantHitCount','descend');
    disp(rankTable);

    fprintf('\nMOST LIKELY FILE TO INSPECT FIRST:\n');
    fprintf('  %s\n',rankTable.File(1));
end

%% Export source hits
outDir = fullfile(runRoot,'diagnostics','P1_ai_structure_forensics');
if ~exist(outDir,'dir')
    mkdir(outDir);
end

if ~isempty(interestingLeaves)
    writetable(interestingLeaves, ...
        fullfile(outDir,'saved_result_ai_related_leaves.csv'));
end

if ~isempty(stepSignals)
    writetable(stepSignals, ...
        fullfile(outDir,'saved_result_step_signals.csv'));
end

if ~isempty(allSourceHits)
    writetable(allSourceHits, ...
        fullfile(outDir,'source_code_hits.csv'));
end

fprintf('\n=============================================================\n');
fprintf(' WHAT TO SEND BACK\n');
fprintf('=============================================================\n');
fprintf(['Please send the output from sections:\n', ...
         '  B/C  result.reserve and result.interval field trees\n', ...
         '  H    AI-model metadata\n', ...
         '  J    likely online reserve-decision files\n', ...
         'and preferably the source-hit lines around candidateAlphaGrid,\n', ...
         'calibration, predictedStress, OOD, and fallbackAlpha.\n']);
fprintf('\nNo simulation was launched.\n');
fprintf('Diagnostics folder:\n  %s\n',outDir);
fprintf('=============================================================\n');


%% =========================================================================
% Local functions
% =========================================================================

function filePath = find_one_result_local(methodDir,caseName,decayRatio,seed)
decayCode = round(100*decayRatio);
pattern = sprintf('%s_*_decay%03d_seed%03d_*.mat', ...
    caseName,decayCode,seed);
hits = dir(fullfile(methodDir,pattern));
assert(~isempty(hits),'No saved result matches %s in %s.',pattern,methodDir);
assert(numel(hits)==1,'Expected one matching result; found %d.',numel(hits));
filePath = fullfile(hits(1).folder,hits(1).name);
end


function result = load_result_local(filePath)
S = load(filePath);
if isfield(S,'result') && isstruct(S.result)
    result=S.result;
    return;
end
names=fieldnames(S);
for k=1:numel(names)
    x=S.(names{k});
    if isstruct(x) && (isfield(x,'summary') || isfield(x,'reserve'))
        result=x;
        return;
    end
end
error('Could not identify result struct in %s.',filePath);
end


function print_struct_tree_local(x,prefix,depth,maxDepth)
if depth>maxDepth
    return;
end
if ~isstruct(x) || numel(x)~=1
    fprintf('%s  [%s %s]\n',prefix,class(x),size_text_local(x));
    return;
end
names=fieldnames(x);
for i=1:numel(names)
    name=names{i};
    v=x.(name);
    p=prefix+"."+string(name);
    if isstruct(v) && numel(v)==1
        fprintf('%s  [struct]\n',p);
        print_struct_tree_local(v,p,depth+1,maxDepth);
    else
        fprintf('%s  [%s %s]  %s\n', ...
            p,class(v),size_text_local(v),preview_local(v));
    end
end
end


function T = collect_leaves_local(x,prefix,depth,maxDepth)
T=table();
if depth>maxDepth
    return;
end
if ~isstruct(x) || numel(x)~=1
    one=leaf_row_local(prefix,x);
    T=one;
    return;
end
names=fieldnames(x);
for i=1:numel(names)
    name=names{i};
    v=x.(name);
    p=prefix+"."+string(name);
    if isstruct(v) && numel(v)==1
        sub=collect_leaves_local(v,p,depth+1,maxDepth);
        if ~isempty(sub)
            T=[T;sub]; %#ok<AGROW>
        end
    else
        one=leaf_row_local(p,v);
        T=[T;one]; %#ok<AGROW>
    end
end
end


function one = leaf_row_local(path,v)
one=table();
one.Path=string(path);
one.Class=string(class(v));
one.SizeText=string(size_text_local(v));
one.Preview=string(preview_local(v));
end


function T = find_step_signals_local(x,prefix,nMPC,depth,maxDepth)
T=table();
if depth>maxDepth || ~isstruct(x) || numel(x)~=1
    return;
end
names=fieldnames(x);
for i=1:numel(names)
    name=names{i};
    v=x.(name);
    p=prefix+"."+string(name);

    if isstruct(v) && numel(v)==1
        sub=find_step_signals_local(v,p,nMPC,depth+1,maxDepth);
        if ~isempty(sub)
            T=[T;sub]; %#ok<AGROW>
        end
        continue;
    end

    if ~(isnumeric(v) || islogical(v))
        continue;
    end

    sz=size(v);
    isStep = isvector(v) && any(numel(v)==[nMPC nMPC+1]);

    % Also permit small matrices with a step dimension.
    if ~isStep && ismatrix(v)
        isStep = (any(sz==nMPC) || any(sz==nMPC+1)) && min(sz)<=10;
    end

    if isStep
        one=table();
        one.Path=string(p);
        one.Class=string(class(v));
        one.SizeText=string(size_text_local(v));
        T=[T;one]; %#ok<AGROW>
    end
end
end


function print_step_window_local(v,steps)
v=squeeze(v);
sz=size(v);

if isvector(v)
    vv=v(:);
    if max(steps)<=numel(vv)
        disp(table(steps(:),double(vv(steps)), ...
            'VariableNames',{'MPCStep','Value'}));
    end
    return;
end

% Small matrix, detect which dimension is the step dimension.
if sz(1)>=max(steps) && sz(2)<=10
    block=double(v(steps,:));
    fprintf('Rows are MPC steps; columns are signal components:\n');
    disp(block);
elseif sz(2)>=max(steps) && sz(1)<=10
    block=double(v(:,steps));
    fprintf('Columns are MPC steps; rows are signal components:\n');
    disp(block);
else
    fprintf('Signal shape is not suitable for compact window display.\n');
end
end


function modelFile = resolve_model_file_local(cfg,projectRoot,caseName)
modelFile="";

if ~isfield(cfg,'ai')
    return;
end

if isfield(cfg.ai,'modelRoot') && isfield(cfg.ai,'modelFileName')
    candidates = { ...
        fullfile(projectRoot,cfg.ai.modelRoot,caseName,cfg.ai.modelFileName), ...
        fullfile(projectRoot,cfg.ai.modelRoot,cfg.ai.modelFileName)};

    for i=1:numel(candidates)
        if exist(candidates{i},'file')==2
            modelFile=string(candidates{i});
            return;
        end
    end
end

hits=dir(fullfile(projectRoot,'**','reserve_krr_model.mat'));
if ~isempty(hits)
    % Prefer path containing the case name.
    for i=1:numel(hits)
        p=fullfile(hits(i).folder,hits(i).name);
        if contains(lower(p),lower(caseName))
            modelFile=string(p);
            return;
        end
    end
    modelFile=string(fullfile(hits(1).folder,hits(1).name));
end
end


function [ok,v] = get_path_local(root,pathText)
ok=false; v=[];
if strlength(string(pathText))==0
    return;
end
parts=split(string(pathText),'.');
x=root;
for k=1:numel(parts)
    f=char(parts(k));
    if ~isstruct(x) || numel(x)~=1 || ~isfield(x,f)
        return;
    end
    x=x.(f);
end
ok=true; v=x;
end


function s = size_text_local(v)
sz=size(v);
s=sprintf('%dx',sz);
if ~isempty(s)
    s=s(1:end-1);
end
end


function p = preview_local(v)
try
    if isempty(v)
        p='<empty>';
    elseif ischar(v)
        p=string(v);
    elseif isstring(v)
        vv=v(:);
        p=strjoin(vv(1:min(end,4))',', ');
    elseif isnumeric(v) || islogical(v)
        if isscalar(v)
            p=sprintf('%.8g',double(v));
        elseif numel(v)<=8
            p=mat2str(double(v));
        else
            finiteV=double(v(isfinite(v)));
            if isempty(finiteV)
                p='<nonfinite>';
            else
                p=sprintf('min %.6g | max %.6g',min(finiteV),max(finiteV));
            end
        end
    elseif iscell(v)
        p=sprintf('<cell %s>',size_text_local(v));
    elseif istable(v)
        p=sprintf('<table %d rows x %d vars>',height(v),width(v));
    else
        p="<"+string(class(v))+">";
    end
catch
    p='<preview unavailable>';
end
p=string(p);
end


function rel = relative_path_local(filePath,projectRoot)
f=string(filePath);
r=string(projectRoot);
if startsWith(lower(f),lower(r))
    rel=extractAfter(f,strlength(r));
    if startsWith(rel,filesep)
        rel=extractAfter(rel,1);
    end
else
    rel=f;
end
end
