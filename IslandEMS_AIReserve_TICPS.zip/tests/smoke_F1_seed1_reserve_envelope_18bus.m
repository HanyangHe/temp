%% smoke_F1_seed1_reserve_envelope_18bus.m
% Exact closed-loop diagnostic for the next root-cause question:
%
%   Is full physics reserve (F1/T7, alpha = 1) itself sufficient on seed 1?
%
% Why this test matters
% ---------------------
% Frozen S3@0.11 failed on hold-out seed 1 at:
%   Step 28: alpha = 1 already, but RoCoF still unsafe.
%   Step 89: alpha = 0.6 and shield did not trigger.
%
% This single F1 run distinguishes two cases:
%
%   CASE A: F1 seed 1 is SAFE
%       -> alpha=1 reserve envelope is sufficient.
%       -> S3 Step-28 failure is mainly timing/history/dispatch-state related.
%       -> next design should focus on anticipatory/persistent safety action.
%
%   CASE B: F1 seed 1 is UNSAFE
%       -> even alpha=1 is insufficient for this trajectory.
%       -> revisit the physical reserve formulation before modifying AI/shield.
%
% Scope:
%   18bus
%   decayRatio = 1.00
%   seed = 1
%   F1/T7 only
%   no formal result persistence
%
% Optional:
%   If S3_seed_robustness_results.seed_001 is still in the workspace,
%   this script compares F1 and S3 directly around steps 25:30 and 86:90.

clearvars -except S3_seed_robustness_results S3_seed_robustness_summary
clc;
close all force;

%% Setup
projectRoot = pwd;
addpath(genpath(projectRoot));
rehash;

cfg = config_island_ems();

caseName   = '18bus';
decayRatio = 1.00;
seed       = 1;

cfg.output.saveResults = false;
cfg.output.showFigures = false;

%% Resolve F1/T7 method
catalog = paper_method_catalog();
ids = string({catalog.id});

idxF1 = find(ids=="T7",1);
if isempty(idxF1)
    idxF1 = find(ids=="F1",1);
end

assert(~isempty(idxF1), ...
    'Could not find internal F1/T7 method in paper_method_catalog().');

runCfg = catalog(idxF1);
runCfg.caseName = caseName;
runCfg.dayType = cfg.scenario.dayType;
runCfg.decayRatio = decayRatio;
runCfg.randomSeed = seed;

% Defensive enforcement: full fixed reserve.
runCfg.reserveMode = 'fixed';
runCfg.reserveFixedRatio = 1.0;

fprintf('\n=============================================================\n');
fprintf(' F1/T7 FULL-RESERVE SEED-1 ENVELOPE TEST\n');
fprintf('=============================================================\n');
fprintf('case          : %s\n',caseName);
fprintf('decayRatio    : %.2f\n',decayRatio);
fprintf('randomSeed    : %d\n',seed);
fprintf('reserve mode  : fixed\n');
fprintf('alpha         : 1.0000\n');
fprintf('save results  : 0\n');
fprintf('=============================================================\n');

%% Optional S3 seed-1 reference from current workspace
haveS3 = exist('S3_seed_robustness_results','var')==1 && ...
    isstruct(S3_seed_robustness_results) && ...
    isfield(S3_seed_robustness_results,'seed_001');

if haveS3
    S3 = S3_seed_robustness_results.seed_001;

    fprintf('\nExisting in-memory S3 seed-1 reference:\n');
    print_summary_local('S3 seed1',S3,cfg);
else
    S3 = [];
    fprintf('\nNo in-memory S3 seed-1 result found; F1 test will run standalone.\n');
end

%% Exact F1 closed-loop run
fprintf('\n=============================================================\n');
fprintf(' RUNNING F1/T7 SEED 1\n');
fprintf('=============================================================\n');

F1 = run_single_experiment(cfg,runCfg,projectRoot,'',false);

%% Analyze F1
F1metrics = analyze_result_local(F1,cfg);

fprintf('\n=============================================================\n');
fprintf(' F1 SEED-1 SUMMARY\n');
fprintf('=============================================================\n');
disp(F1metrics.summary);

fprintf('\nF1 CoI-unsafe intervals:\n');
if isempty(F1metrics.unsafeTable)
    fprintf('  NONE\n');
else
    disp(F1metrics.unsafeTable);
end

%% Focused windows
fprintf('\n=============================================================\n');
fprintf(' F1 MORNING WINDOW -- STEPS 25:30\n');
fprintf('=============================================================\n');
disp(F1metrics.stepTable(25:30,:));

fprintf('\n=============================================================\n');
fprintf(' F1 LATE-DAY WINDOW -- STEPS 86:90\n');
fprintf('=============================================================\n');
disp(F1metrics.stepTable(86:90,:));

%% Direct F1 vs S3 comparison if S3 is available
if haveS3

    S3metrics = analyze_result_local(S3,cfg);

    fprintf('\n=============================================================\n');
    fprintf(' F1 vs S3 SEED-1 SUMMARY\n');
    fprintf('=============================================================\n');

    Tcmp = [ ...
        add_method_label_local(F1metrics.summary,"F1"); ...
        add_method_label_local(S3metrics.summary,"S3")];

    Tcmp = movevars(Tcmp,'Method','Before',1);
    disp(Tcmp);

    fprintf('\n=============================================================\n');
    fprintf(' F1 vs S3 AROUND STEP 28\n');
    fprintf('=============================================================\n');

    cmp28 = compare_steps_local(F1metrics.stepTable,S3metrics.stepTable,25:30);
    disp(cmp28);

    fprintf('\n=============================================================\n');
    fprintf(' F1 vs S3 AROUND STEP 89\n');
    fprintf('=============================================================\n');

    cmp89 = compare_steps_local(F1metrics.stepTable,S3metrics.stepTable,86:90);
    disp(cmp89);
end

%% Root-cause decision
fprintf('\n=============================================================\n');
fprintf(' ROOT-CAUSE DECISION\n');
fprintf('=============================================================\n');

if F1metrics.summary.CoIUnsafeCount==0

    fprintf('F1 seed 1 is SAFE with alpha=1.\n');
    fprintf(['Conclusion: the full-physics reserve envelope is sufficient ', ...
        'for this hold-out trajectory.\n']);

    if haveS3
        s3Unsafe = S3metrics.summary.CoIUnsafeCount;

        if s3Unsafe>0
            fprintf(['Because S3 is unsafe while F1 is safe, the adaptive ', ...
                'failure is NOT evidence that alpha=1 is physically inadequate.\n']);
            fprintf(['The next design question is temporal: when/how long the ', ...
                'safety layer must raise reserve so the closed-loop dispatch ', ...
                'enters the dangerous transition with adequate protection.\n']);
        end
    end

else

    fprintf('F1 seed 1 is UNSAFE even with alpha=1.\n');
    fprintf(['Conclusion: do NOT continue tuning the AI shield. The physical ', ...
        'reserve envelope itself is insufficient for this trajectory.\n']);
    fprintf(['Next step should revisit reserve sizing / frequency-security ', ...
        'formulation before any additional AI changes.\n']);
end

fprintf('=============================================================\n');

%% Export
assignin('base','F1_seed1_result',F1);
assignin('base','F1_seed1_metrics',F1metrics);

fprintf('\nExported to base workspace:\n');
fprintf('  F1_seed1_result\n');
fprintf('  F1_seed1_metrics\n');


%% =========================================================================
% Local helpers
% =========================================================================

function out = analyze_result_local(result,cfg)

df = double(result.interval.maxAbsFreqDev_Hz(:));
rocof = double(result.interval.maxAbsRoCoF_Hz_s(:));

dfLim = cfg.frequency.securityDeviation_Hz;
rLim  = cfg.frequency.securityRoCoF_Hz_s;

stress = max(df/dfLim,rocof/rLim);
unsafe = stress>1+1e-12;

if isfield(result,'reserve') && isfield(result.reserve,'ratio')
    alpha = double(result.reserve.ratio(:));
else
    alpha = nan(size(df));
end

n = numel(df);
step = (1:n).';
time_h = (step-1)*cfg.mpc.decisionInterval_h;

stepTable = table( ...
    step,time_h,alpha,df,rocof,stress,unsafe, ...
    'VariableNames',{ ...
    'MPCStep','StartTime_h','Alpha', ...
    'MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s', ...
    'SecurityStress','CoIUnsafe'});

idx = find(unsafe);
unsafeTable = stepTable(idx,:);

summary = table();
summary.TotalCost = double(result.totalCost);
summary.MeanAlpha = mean(alpha,'omitnan');
summary.MinAlpha = min(alpha,[],'omitnan');
summary.MaxAlpha = max(alpha,[],'omitnan');
summary.MaxAbsDf_Hz = max(df,[],'omitnan');
summary.MaxAbsRoCoF_Hz_s = max(rocof,[],'omitnan');
summary.MaxSecurityStress = max(stress,[],'omitnan');
summary.CoIUnsafeCount = nnz(unsafe);
summary.CoIUnsafeRate = mean(unsafe);

out = struct();
out.summary = summary;
out.stepTable = stepTable;
out.unsafeTable = unsafeTable;
end


function print_summary_local(label,result,cfg)

m = analyze_result_local(result,cfg).summary;

fprintf(['  %-10s cost=%9.4f | mean alpha=%.6f | max|df|=%.6f | ', ...
    'max|RoCoF|=%.6f | unsafe=%d\n'], ...
    label,m.TotalCost,m.MeanAlpha, ...
    m.MaxAbsDf_Hz,m.MaxAbsRoCoF_Hz_s,m.CoIUnsafeCount);
end


function T = add_method_label_local(summary,label)

T = summary;
T.Method = string(label);
end


function T = compare_steps_local(F1,S3,steps)

idxF = ismember(F1.MPCStep,steps);
idxS = ismember(S3.MPCStep,steps);

A = F1(idxF,:);
B = S3(idxS,:);

assert(isequal(A.MPCStep,B.MPCStep), ...
    'F1/S3 step mismatch in requested comparison window.');

T = table();
T.MPCStep = A.MPCStep;
T.StartTime_h = A.StartTime_h;

T.F1_Alpha = A.Alpha;
T.S3_Alpha = B.Alpha;

T.F1_MaxAbsDf_Hz = A.MaxAbsDf_Hz;
T.S3_MaxAbsDf_Hz = B.MaxAbsDf_Hz;

T.F1_MaxAbsRoCoF_Hz_s = A.MaxAbsRoCoF_Hz_s;
T.S3_MaxAbsRoCoF_Hz_s = B.MaxAbsRoCoF_Hz_s;

T.F1_SecurityStress = A.SecurityStress;
T.S3_SecurityStress = B.SecurityStress;

T.F1_Unsafe = A.CoIUnsafe;
T.S3_Unsafe = B.CoIUnsafe;
end
