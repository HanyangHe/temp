function report = final_AIReserve_pre_main_test(caseNames)
%FINAL_AIRESERVE_PRE_MAIN_TEST Last no-simulation gate before formal mainV4.
% Run AFTER train_AIReserve.m. Verifies one current frequency-stress response
% model per requested grid and exercises online alpha selection at a known
% in-distribution state. No MPC/physical simulation is launched.

thisFile=mfilename('fullpath');
projectRoot=fileparts(fileparts(thisFile));
addpath(genpath(projectRoot));
cfg=config_island_ems(); validate_config(cfg);
if nargin<1 || isempty(caseNames), caseNames=cfg.experiment.systemCases; end
caseNames=cellstr(string(caseNames));

fprintf('\n=============================================================\n');
fprintf(' FINAL AI-RESERVE PRE-mainV4 TEST (NO SIMULATION)\n');
fprintf(' state features : %s\n',strjoin(reserve_feature_names(),', '));
fprintf(' learned query  : candidate reserveRatio alpha\n');
fprintf(' target         : normalized CoI frequency stress\n');
fprintf(' alpha          : [%.2f, %.2f]\n',cfg.ai.alphaMin,cfg.ai.alphaMax);
fprintf(' cases          : %s\n',strjoin(caseNames,', '));
fprintf('=============================================================\n');

expectedFeatures=string({'netLoadNow_pu','absNetLoadRamp_pu','dgUpHeadroom_pu'});
assert(isequal(string(reserve_feature_names()),expectedFeatures), ...
    'Frozen AI state-feature contract changed unexpectedly.');
assert(strcmpi(cfg.ai.learningTarget,'frequency-stress-response'), ...
    'AI model must learn frequency stress, not direct alpha.');
assert(strcmpi(cfg.ai.response.securityTarget,'coi'),'Response security target must be CoI.');
assert(abs(cfg.ai.alphaMax-1)<1e-12 && abs(cfg.ai.fallbackAlpha-1)<1e-12, ...
    'Formal policy must cap/fallback at alpha=1.');

rows=cell(numel(caseNames),14); missing={}; stale={}; paths=strings(numel(caseNames),1);
for i=1:numel(caseNames)
    c=caseNames{i};
    modelFile=get_ai_reserve_model_file(projectRoot,cfg,c); paths(i)=string(modelFile);
    if ~exist(modelFile,'file')
        missing{end+1}=c; %#ok<AGROW>
        rows(i,:)={c,"MISSING",modelFile,"",false,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN};
        continue
    end
    S=load(modelFile,'model'); [ok,msg]=validate_ai_reserve_model(S.model,cfg,c);
    if ~ok
        stale{end+1}=sprintf('%s: %s',c,msg); %#ok<AGROW>
        rows(i,:)={c,"STALE",modelFile,"",false,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN};
        continue
    end
    m=S.model;
    canonicalDatasetFile=get_ai_reserve_dataset_file(projectRoot,cfg,c);
    datasetExists=exist(canonicalDatasetFile,'file')==2;
    assert(datasetExists,'[%s] canonical AI dataset is missing: %s',c,canonicalDatasetFile);
    assert(isfield(m,'datasetFile') && strcmpi(char(m.datasetFile),canonicalDatasetFile), ...
        '[%s] model dataset pointer is not canonical. Run migrate_AIReserve_assets.m.',c);
    Sd=load(canonicalDatasetFile,'dataset');
    [okData,msgData]=response_dataset_merge_compatible(Sd.dataset,cfg,c);
    assert(okData,'[%s] canonical dataset incompatible: %s',c,msgData);
    if isfield(m,'metrics') && isfield(m.metrics,'nSamples') && isfinite(m.metrics.nSamples)
        assert(size(Sd.dataset.X,1)==m.metrics.nSamples, ...
            '[%s] model/dataset sample-count mismatch (%d vs %d).', ...
            c,m.metrics.nSamples,size(Sd.dataset.X,1));
    end
    assert(isfield(m,'globalFixedAlpha') && isfinite(m.globalFixedAlpha), ...
        '[%s] globalFixedAlpha missing.',c);
    assert(m.globalFixedAlpha>=cfg.ai.alphaMin-1e-12 && m.globalFixedAlpha<=1+1e-12, ...
        '[%s] globalFixedAlpha outside formal range.',c);

    state0=m.stateMu;
    [a,info]=predict_reserve_ratio(m,state0,cfg.ai);
    assert(isfinite(a) && a>=cfg.ai.alphaMin-1e-12 && a<=1+1e-12, ...
        '[%s] online inference returned invalid alpha.',c);
    assert(~info.oodFallback,'[%s] training-center state incorrectly triggered OOD fallback.',c);

    rows(i,:)={c,"VALID",modelFile,canonicalDatasetFile,true, ...
        getmetric(m,'nSamples'),getmetric(m,'nGroups'), ...
        getmetric(m,'testStressRMSE'),getmetric(m,'testStressMAE'), ...
        getmetric(m,'testCalibrationCoverage'),getmetric(m,'calibratedTestFalseSafeRate'), ...
        m.globalFixedAlpha,getfield_default(m,'calibrationOffset',NaN),a};
end
if numel(unique(paths))~=numel(paths), error('Per-grid model paths are not unique.'); end

T=cell2table(rows,'VariableNames',{ ...
    'CaseName','Status','ModelFile','DatasetFile','DatasetExists','NSamples','NGroups', ...
    'StressTestRMSE','StressTestMAE','CalibrationCoverage','FalseSafeRate', ...
    'GlobalFixedAlpha','CalibrationOffset','InferenceAtMean'});
disp(T);

if ~isempty(missing)
    fprintf('\nMissing models: %s\n',strjoin(missing,', '));
    fprintf(['Set cfg.ai.response.systemCases to the missing grid(s) and run ', ...
        'train_AIReserve.m. Valid existing models are skipped automatically.\n']);
    error('final_AIReserve_pre_main_test:MissingModels','Required grid response model(s) are missing.');
end
if ~isempty(stale)
    fprintf('\nStale/incompatible models:\n  %s\n',strjoin(stale,'\n  '));
    error('final_AIReserve_pre_main_test:StaleModels', ...
        'Delete/retrain stale model(s) with train_AIReserve.m.');
end
fprintf('\nPASS: all requested grid-specific frequency-stress models are reusable and current.\n');
fprintf('No MPC/physical simulation was launched and nothing was written to outputs/.\n');
report=struct('table',T,'caseNames',{caseNames},'passed',true,'config',cfg.ai);
end

function v=getmetric(m,name)
if isfield(m,'metrics') && isfield(m.metrics,name), v=m.metrics.(name); else, v=NaN; end
end
function v=getfield_default(s,name,d)
if isfield(s,name), v=s.(name); else, v=d; end
end
