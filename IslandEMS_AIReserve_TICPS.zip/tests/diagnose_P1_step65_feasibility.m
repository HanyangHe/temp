function report = diagnose_P1_step65_feasibility(methodID)
%DIAGNOSE_P1_STEP65_FEASIBILITY Exact-state feasibility-spectrum diagnostic.
%
% Replays ONLY the learned-policy trajectory up to MPC step 65, then freezes
% the exact physical/MPC state and resolves that SAME optimization problem for
% alpha = [1.0 0.9 0.8 0.7 0.6].  This distinguishes:
%   (A) current-step reserve-bound conflict: lower alpha restores feasibility;
%   (B) recursive-state infeasibility: even alpha=0.6 is infeasible;
%   (C) numerical solver anomaly.
%
% No result is written to formal outputs/. A compact probe is temporarily
% written under tempdir and removed after this function reads it.
%
% Usage:
%   report = diagnose_P1_step65_feasibility();       % P1 (recommended first)
%   report = diagnose_P1_step65_feasibility('P1U'); % optional comparison

if nargin<1 || isempty(methodID), methodID='P1'; end
methodID=upper(string(methodID));
assert(any(methodID==["P1","P1U"]),'methodID must be P1 or P1U.');
clc;

thisFile=mfilename('fullpath');
projectRoot=fileparts(fileparts(thisFile));
if ~is_project_root(projectRoot)
    if is_project_root(pwd)
        projectRoot=pwd;
    else
        hit=which('config_island_ems');
        if ~isempty(hit)
            candidate=fileparts(fileparts(hit));
            if is_project_root(candidate), projectRoot=candidate; end
        end
    end
end
if ~is_project_root(projectRoot)
    error('IslandEMS:ProjectRoot','Cannot identify IslandEMS project root.');
end
addpath(genpath(projectRoot));

cfg=config_island_ems();
validate_config(cfg);
cfg.experiment.systemCases={'18bus'};
cfg.scenario.dayType='Unusual day';
cfg.scenario.decayRatios=1.00;
cfg.experiment.randomSeeds=0;
if ~isfield(cfg,'output'), cfg.output=struct(); end
cfg.output.saveResults=false;
cfg.output.writeSummaryCSV=false;
cfg.output.exportFigures=false;
cfg.output.showFigures=false;

fprintf('\nRunning no-simulation AI model preflight...\n');
final_AIReserve_pre_main_test({'18bus'});

probeFile=fullfile(tempdir,sprintf('IslandEMS_%s_step65_feasibility_probe.mat',char(methodID)));
if exist(probeFile,'file'), delete(probeFile); end
if ~isfield(cfg,'diagnostics'), cfg.diagnostics=struct(); end
cfg.diagnostics.feasibilityProbe=struct( ...
    'enabled',true, ...
    'targetStep',65, ...
    'alphaGrid',[1.0 0.9 0.8 0.7 0.6], ...
    'stopAfterProbe',true, ...
    'file',probeFile);
if ~isfield(cfg.diagnostics,'progress'), cfg.diagnostics.progress=struct(); end
cfg.diagnostics.progress.enabled=true;
cfg.diagnostics.progress.everyN=8;

catalog=baseline_catalog();
ids=string({catalog.id});
idx=find(ids==methodID,1);
assert(~isempty(idx),'%s missing from baseline_catalog.',methodID);
runCfg=catalog(idx);
runCfg.caseName='18bus';
runCfg.dayType=cfg.scenario.dayType;
runCfg.decayRatio=1.00;
runCfg.randomSeed=0;

fprintf('\n=============================================================\n');
fprintf(' %s STEP-65 EXACT-STATE FEASIBILITY DIAGNOSTIC\n',methodID);
fprintf('=============================================================\n');
fprintf(' case / scenario : 18bus / Unusual day / decay 1.00 / seed 0\n');
fprintf(' target step     : 65 (t = 16.00 h)\n');
fprintf(' alpha probes    : [1.0 0.9 0.8 0.7 0.6]\n');
fprintf(' formal outputs  : OFF\n');
fprintf(' expected runtime: about time-to-step65 + five same-state SOCP probes\n');
fprintf('=============================================================\n\n');

tRun=tic;
try
    run_single_experiment(cfg,runCfg,projectRoot,'',false);
    error('IslandEMS:ProbeNotTriggered','Run unexpectedly completed without diagnostic stop.');
catch ME
    if ~strcmp(ME.identifier,'IslandEMS:DiagnosticStop')
        if ~exist(probeFile,'file')
            rethrow(ME);
        end
        fprintf(2,'Run ended after probe generation with: %s\n',ME.message);
    else
        fprintf('\nTarget diagnostic stop reached as intended.\n');
    end
end
fprintf('Elapsed diagnostic runtime: %.2f min\n',toc(tRun)/60);
assert(exist(probeFile,'file')==2,'Expected feasibility-probe file was not created.');
S=load(probeFile,'probeReport');
p=S.probeReport;
delete(probeFile);

fprintf('\n---------------- Target-state report ----------------\n');
fprintf('AI-selected alpha at step %d : %.3f\n',p.targetStep,p.selectedAlpha);
fprintf('Pre-decision state features   : Pnet %.4f pu | |dPnet| %.4f pu | DG headroom %.4f pu\n', ...
    p.targetFeature(1),p.targetFeature(2),p.targetFeature(3));
if ~isempty(p.currentDG_MW)
    fprintf('Measured DG outputs before solve: %s MW\n',mat2str(p.currentDG_MW(:).',4));
end
fprintf('Primary solve at selected alpha: exitflag %d | primal %.3e | dual %.3e\n', ...
    p.primaryAtTarget.exitflag,p.primaryAtTarget.primalFeasibility,p.primaryAtTarget.dualFeasibility);

disp(p.probeTable);

a=p.alphaHistory(:);
valid=isfinite(a);
levels=unique(round(a(valid),4));
counts=zeros(size(levels));
for i=1:numel(levels), counts(i)=sum(abs(a-levels(i))<1e-8); end
alphaDist=table(levels,counts,100*counts/max(sum(counts),1), ...
    'VariableNames',{'Alpha','Count','Pct'});
fprintf('\nSelected-alpha history through step 65:\n');
disp(alphaDist);
lastIdx=max(1,numel(a)-19):numel(a);
last20=table(lastIdx(:),(lastIdx(:)-1)*cfg.mpc.decisionInterval_h,a(lastIdx), ...
    p.featureHistory(lastIdx,1),p.featureHistory(lastIdx,2),p.featureHistory(lastIdx,3), ...
    'VariableNames',{'Step','Time_h','Alpha','Pnet_pu','AbsDPnet_pu','DGHeadroom_pu'});
fprintf('Last 20 P1 decisions before target:\n');
disp(last20);

pred=struct();
if isfield(p.selectedReserveMeta,'prediction')
    pred=p.selectedReserveMeta.prediction;
end
if isfield(pred,'alphaGrid') && isfield(pred,'rawStressCurve')
    targetCurve=table(pred.alphaGrid(:),pred.rawStressCurve(:),pred.decisionStressCurve(:), ...
        'VariableNames',{'Alpha','PredictedStressRaw','PredictedStressDecision'});
    fprintf('\nAI-predicted frequency-stress curve at step 65:\n');
    disp(targetCurve);
else
    targetCurve=table();
end

probe=p.probeTable;
usableAlpha=probe.Alpha(probe.Usable);
verdict="INCONCLUSIVE";
reason="";
if isempty(usableAlpha)
    verdict="RECURSIVE_STATE_INFEASIBILITY";
    reason="None of the probed reserve ratios [1.0..0.6] is feasible at the exact step-65 state; current-step backtracking alone cannot repair it.";
elseif any(abs(usableAlpha-p.selectedAlpha)<1e-9)
    verdict="SELECTED_ALPHA_FEASIBLE_IN_PROBE";
    reason="The same selected alpha is feasible when re-solved at the frozen state; investigate solver stochastic/numerical behavior rather than reserve-bound conflict.";
elseif any(usableAlpha < p.selectedAlpha-1e-9)
    verdict="CURRENT_STEP_BACKTRACKING_CAN_RESTORE_FEASIBILITY";
    aBest=max(usableAlpha(usableAlpha<p.selectedAlpha));
    reason=sprintf('AI selected alpha %.3f is infeasible, while lower alpha %.3f is feasible at the identical state. A feasibility backtracking safeguard is directly justified.',p.selectedAlpha,aBest);
else
    verdict="UNEXPECTED_FEASIBILITY_PATTERN";
    reason="Only larger reserve ratios appear feasible; inspect the bound construction and numerical solver diagnostics.";
end

fprintf('\n=============================================================\n');
fprintf(' STEP-65 DIAGNOSTIC VERDICT: %s\n',verdict);
fprintf(' %s\n',reason);
fprintf('=============================================================\n');

t=(0:numel(a)-1)*cfg.mpc.decisionInterval_h;
figure('Name',sprintf('%s step-65 diagnostic - policy history',methodID));
tiledlayout(2,1);
nexttile;
stairs(t,a,'LineWidth',1.2); hold on;
yline(cfg.ai.alphaMin,'--'); yline(cfg.ai.alphaMax,'--');
xline(p.targetTime_h,':','Step 65');
ylabel('\alpha'); xlabel('Time (h)'); grid on;
title(sprintf('%s learned reserve-ratio history to step 65',methodID));
nexttile;
plot(t,p.featureHistory(:,1),'LineWidth',1.0); hold on;
plot(t,p.featureHistory(:,2),'LineWidth',1.0);
plot(t,p.featureHistory(:,3),'LineWidth',1.0);
xline(p.targetTime_h,':'); grid on; xlabel('Time (h)');
ylabel('p.u.'); legend('P_{net}','|\Delta P_{net}|','DG headroom','Location','best');
title('Causal state features');

figure('Name',sprintf('%s step-65 diagnostic - feasibility spectrum',methodID));
tiledlayout(1,2);
nexttile;
scatter(probe.Alpha,double(probe.Usable),80,'filled'); hold on;
xline(p.selectedAlpha,':','AI selected');
yticks([0 1]); yticklabels({'Infeasible','Usable'}); ylim([-0.15 1.15]);
xlabel('\alpha'); grid on; title('Same-state MPC feasibility spectrum');
nexttile;
semilogy(probe.Alpha,max(probe.DualFeasibility,eps),'o-','LineWidth',1.0); hold on;
semilogy(probe.Alpha,max(probe.PrimalFeasibility,eps),'s-','LineWidth',1.0);
xline(p.selectedAlpha,':'); xlabel('\alpha'); ylabel('Solver residual');
grid on; legend('Dual feasibility','Primal feasibility','Location','best');
title('Probe numerical quality');

if ~isempty(targetCurve)
    figure('Name',sprintf('%s step-65 diagnostic - learned stress',methodID));
    plot(targetCurve.Alpha,targetCurve.PredictedStressRaw,'o-','LineWidth',1.0); hold on;
    plot(targetCurve.Alpha,targetCurve.PredictedStressDecision,'s-','LineWidth',1.0);
    yline(1,'--','Security boundary'); xline(p.selectedAlpha,':','Selected alpha');
    xlabel('\alpha'); ylabel('Predicted normalized frequency stress');
    grid on; legend('Raw KRR','Decision/calibrated','Location','best');
    title('Learned reserve-response curve at exact step-65 state');
end

report=struct();
report.kind='IslandEMSStep65FeasibilityDiagnosticV1';
report.methodID=methodID;
report.probe=p;
report.alphaDistribution=alphaDist;
report.last20=last20;
report.targetStressCurve=targetCurve;
report.verdict=verdict;
report.reason=reason;
report.timestamp=datestr(now,30);
end

function tf=is_project_root(p)
tf=isfolder(p) && isfolder(fullfile(p,'config')) && isfolder(fullfile(p,'core')) && ...
    exist(fullfile(p,'config','config_island_ems.m'),'file')==2;
end
