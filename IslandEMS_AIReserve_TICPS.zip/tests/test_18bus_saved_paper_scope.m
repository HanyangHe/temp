function test_18bus_saved_paper_scope(runTag)
%TEST_18BUS_SAVED_PAPER_SCOPE Validate saved 18-bus result scope.
%
% No simulation.
%
% Usage:
%   test_18bus_saved_paper_scope('20260907_115951')
%
% Checks:
%   Part-I-only methods A0/T7/G1/P1U exist ONLY at decay=1.00.
%   P1 is retained across Part-II decay sweep.
%   C0/C1 exist across Part-II decay sweep.

if nargin<1 || isempty(runTag)
    runTag = '20260907_115951';
end

projectRoot = pwd;
cfg = config_island_ems();
runRoot = fullfile(projectRoot,cfg.output.root,runTag);

assert(exist(runRoot,'dir')==7,'Run folder not found: %s',runRoot);

part1Only = ["A0","T7","G1","P1U"];
obsoleteDecays = [0.20 0.40 0.60 0.80];
part2Decays = cfg.experiment.paperStudies.curtailmentAllocationCost.decayRatios;

% No obsolete Part-I-only MAT files may remain.
for id = part1Only
    for decay = obsoleteDecays
        code = round(100*decay);
        hits = dir(fullfile(runRoot,char(id),sprintf( ...
            '18bus_unusual_day_decay%03d_seed000_*.mat',code)));
        assert(isempty(hits), ...
            'Obsolete Part-I result still exists: %s decay %.2f.',id,decay);
    end

    % Normal case must exist.
    hits = dir(fullfile(runRoot,char(id), ...
        '18bus_unusual_day_decay100_seed000_*.mat'));
    assert(~isempty(hits), ...
        'Required Part-I normal result is missing: %s decay 1.00.',id);
end

% P1 is shared: keep every Part-II decay including shortage cases.
for decay = part2Decays
    code = round(100*decay);
    hits = dir(fullfile(runRoot,'P1',sprintf( ...
        '18bus_unusual_day_decay%03d_seed000_*.mat',code)));
    assert(~isempty(hits), ...
        'Required P1 Part-II result missing at decay %.2f.',decay);
end

for id = ["C0","C1"]
    for decay = part2Decays
        code = round(100*decay);
        hits = dir(fullfile(runRoot,char(id),sprintf( ...
            '18bus_unusual_day_decay%03d_seed000_*.mat',code)));
        assert(~isempty(hits), ...
            'Required %s Part-II result missing at decay %.2f.',id,decay);
    end
end

fprintf(['Saved 18-bus paper-scope test passed:\n', ...
    '  Part I  A0/F1/G1/P1U/P1 uses decay=1.00 only\n', ...
    '  Part II C0/C1/P1 shortage results are retained.\n']);
end
