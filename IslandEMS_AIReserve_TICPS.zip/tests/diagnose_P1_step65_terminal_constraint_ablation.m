function report = diagnose_P1_step65_terminal_constraint_ablation()
%DIAGNOSE_P1_STEP65_TERMINAL_CONSTRAINT_ABLATION
% Frozen-state selective SoC terminal-constraint ablation at P1 MPC step 65.
%
% Replays P1 only to step 65, freezes the exact current physical/MPC state,
% then resolves the SAME problem under alpha = 1.0 and 0.6 while selectively
% removing ONLY specific SoC terminal rows.  No formal outputs are written.
%
% Variants:
%   BASELINE                         : unchanged formulation
%   RELAX_FIRST_BESS_SOCMAX_1E4     : +1e-4 diagnostic tolerance only
%   DROP_BESS1_HORIZON_END          : remove first BESS end>=current row
%   DROP_ALL_BESS_HORIZON_END       : remove all BESS end>=current rows
%   DROP_ALL_EV_HORIZON_END         : remove EV end-of-horizon equality pairs
%   DROP_ALL_STORAGE_HORIZON_END    : remove both BESS and EV hidden end rows
%   DROP_BESS_DAILY_TARGET          : remove natural-day BESS target rows
%   DROP_EV_DAILY_TARGET            : remove natural-day EV target pairs
%
% The test is diagnostic only.  It does not change the formal model.

clc;
thisFile=mfilename('fullpath');
projectRoot=fileparts(fileparts(thisFile));
if ~is_project_root(projectRoot)
    if is_project_root(pwd)
        projectRoot=pwd;
    else
        hit=which('config_island_ems');
        if ~isempty(hit)
            candidate=fileparts(fileparts(hit));
            if is_project_root(candidate), projectRoot=candidate; end
        end
    end
end
if ~is_project_root(projectRoot)
    error('IslandEMS:ProjectRoot','Cannot identify IslandEMS project root.');
end
addpath(genpath(projectRoot));

cfg=config_island_ems();
validate_config(cfg);
cfg.experiment.systemCases={'18bus'};
cfg.scenario.dayType='Unusual day';
cfg.scenario.decayRatios=1.00;
cfg.experiment.randomSeeds=0;
if ~isfield(cfg,'output'), cfg.output=struct(); end
cfg.output.saveResults=false;
cfg.output.writeSummaryCSV=false;
cfg.output.exportFigures=false;
cfg.output.showFigures=false;

fprintf('\nRunning no-simulation AI model preflight...\n');
final_AIReserve_pre_main_test({'18bus'});

cacheDir=fullfile(projectRoot,'tests','cache');
if ~exist(cacheDir,'dir'), mkdir(cacheDir); end
probeFile=fullfile(cacheDir,'P1_step65_terminal_constraint_ablation.mat');
if exist(probeFile,'file'), delete(probeFile); end

if ~isfield(cfg,'diagnostics'), cfg.diagnostics=struct(); end
cfg.diagnostics.feasibilityProbe=struct( ...
    'enabled',true, ...
    'targetStep',65, ...
    'alphaGrid',[1.0 0.6], ...
    'terminalConstraintAblation',true, ...
    'terminalAlphaGrid',[1.0 0.6], ...
    'stopAfterProbe',true, ...
    'file',probeFile);
if ~isfield(cfg.diagnostics,'progress'), cfg.diagnostics.progress=struct(); end
cfg.diagnostics.progress.enabled=true;
cfg.diagnostics.progress.everyN=8;

catalog=baseline_catalog();
ids=string({catalog.id});
idx=find(ids=="P1",1);
assert(~isempty(idx),'P1 missing from baseline_catalog.');
runCfg=catalog(idx);
runCfg.caseName='18bus';
runCfg.dayType=cfg.scenario.dayType;
runCfg.decayRatio=1.00;
runCfg.randomSeed=0;

fprintf('\n=============================================================\n');
fprintf(' P1 STEP-65 TERMINAL-CONSTRAINT FAMILY ABLATION\n');
fprintf('=============================================================\n');
fprintf(' exact state      : 18bus / Unusual day / decay 1 / seed 0 / step 65\n');
fprintf(' alpha probes     : [1.0, 0.6]\n');
fprintf(' purpose          : identify the blocking SoC terminal family\n');
fprintf(' formal outputs   : OFF; persistent diagnostic only under tests/cache/\n');
fprintf(' expected runtime : time-to-step65 + ~16 same-state SOCP solves\n');
fprintf('=============================================================\n\n');

tRun=tic;
try
    run_single_experiment(cfg,runCfg,projectRoot,'',false);
    error('IslandEMS:ProbeNotTriggered','Run unexpectedly completed without diagnostic stop.');
catch ME
    if ~strcmp(ME.identifier,'IslandEMS:DiagnosticStop')
        if ~exist(probeFile,'file'), rethrow(ME); end
        fprintf(2,'Run ended after probe generation with: %s\n',ME.message);
    else
        fprintf('\nTarget diagnostic stop reached as intended.\n');
    end
end
elapsed=toc(tRun)/60;
fprintf('Elapsed diagnostic runtime: %.2f min\n',elapsed);
assert(exist(probeFile,'file')==2,'Expected terminal-ablation probe file was not created.');
S=load(probeFile,'probeReport');
p=S.probeReport;
assert(isfield(p,'terminalAblationTable') && istable(p.terminalAblationTable), ...
    'Engine did not return terminalAblationTable. Replace core/engine/engine_island_ems.m with the supplied patch.');
T=p.terminalAblationTable;

fprintf('\n---------------- Frozen-state terminal ablation ----------------\n');
disp(T);

% Summarize feasibility by variant at alpha 1 and 0.6.
variants=unique(T.Variant,'stable');
alpha1=false(numel(variants),1); alpha06=false(numel(variants),1);
for i=1:numel(variants)
    q=T(T.Variant==variants(i),:);
    alpha1(i)=any(q.Usable & abs(q.Alpha-1.0)<1e-9);
    alpha06(i)=any(q.Usable & abs(q.Alpha-0.6)<1e-9);
end
summaryTable=table(variants,alpha1,alpha06,'VariableNames',{'Variant','FeasibleAlpha1','FeasibleAlpha06'});
fprintf('\nFeasibility summary by constraint variant:\n');
disp(summaryTable);

verdict="OTHER_CONSTRAINT_FAMILY";
reason="No selective terminal-row ablation restored feasibility; inspect non-terminal energy/network constraints next.";
getv=@(name) summaryTable(summaryTable.Variant==string(name),:);

qTol=getv('RELAX_FIRST_BESS_SOCMAX_1E4');
qB1=getv('DROP_BESS1_HORIZON_END');
qBA=getv('DROP_ALL_BESS_HORIZON_END');
qEV=getv('DROP_ALL_EV_HORIZON_END');
qALL=getv('DROP_ALL_STORAGE_HORIZON_END');
qBD=getv('DROP_BESS_DAILY_TARGET');
qED=getv('DROP_EV_DAILY_TARGET');

if ~isempty(qTol) && (qTol.FeasibleAlpha1 || qTol.FeasibleAlpha06)
    verdict="NUMERICAL_SOC_UPPER_BOUND_PRESSURE";
    reason="A +1e-4 diagnostic tolerance on the first BESS SoC upper bound restores feasibility; physical-state clipping/tolerance handling is the first remedy.";
elseif ~isempty(qB1) && (qB1.FeasibleAlpha1 || qB1.FeasibleAlpha06)
    verdict="BESS1_HARD_HORIZON_END_ROW_BLOCKS";
    reason="Removing only BESS1's hidden end>=current row restores feasibility. The BESS rolling-horizon terminal implementation is the direct blocker.";
elseif ~isempty(qBA) && (qBA.FeasibleAlpha1 || qBA.FeasibleAlpha06)
    verdict="BESS_HARD_HORIZON_END_FAMILY_BLOCKS";
    reason="Removing the BESS horizon-end sustainability rows restores feasibility; the current hidden hard end>=current constraints should be reformulated/softened.";
elseif ~isempty(qEV) && (qEV.FeasibleAlpha1 || qEV.FeasibleAlpha06)
    verdict="EV_HARD_HORIZON_END_FAMILY_BLOCKS";
    reason="Removing the EV hidden end-of-horizon equality rows restores feasibility; EV rolling-horizon terminal logic is the direct blocker.";
elseif ~isempty(qALL) && (qALL.FeasibleAlpha1 || qALL.FeasibleAlpha06)
    verdict="COMBINED_STORAGE_HORIZON_END_ROWS_BLOCK";
    reason="Neither BESS nor EV end rows alone are sufficient, but removing both restores feasibility. The hidden sliding-horizon sustainability constraints jointly block the MPC.";
elseif ~isempty(qBD) && (qBD.FeasibleAlpha1 || qBD.FeasibleAlpha06)
    verdict="BESS_DAILY_TARGET_BLOCKS";
    reason="The fixed natural-day BESS target, rather than the hidden horizon-end row, is the direct blocker. Review its target/relaxation magnitude.";
elseif ~isempty(qED) && (qED.FeasibleAlpha1 || qED.FeasibleAlpha06)
    verdict="EV_DAILY_TARGET_BLOCKS";
    reason="The EV daily full-charge target family is the direct blocker. Review commuting-energy/terminal-relaxation logic.";
end

fprintf('\n=============================================================\n');
fprintf(' TERMINAL-CONSTRAINT DIAGNOSTIC VERDICT: %s\n',verdict);
fprintf(' %s\n',reason);
fprintf('=============================================================\n');

% Compact plot.
figure('Name','P1 step65 terminal-constraint ablation');
tiledlayout(1,2);
nexttile;
Y=[double(alpha1) double(alpha06)];
bar(categorical(variants),Y); ylabel('Feasible (1/0)'); ylim([0 1.2]);
legend('\alpha=1.0','\alpha=0.6','Location','best'); grid on;
title('Frozen-state feasibility by terminal-row ablation');
nexttile;
sel=T.Alpha==1.0;
bar(categorical(T.Variant(sel)),T.SolveTime_s(sel)); ylabel('Solve time (s)'); grid on;
title('\alpha=1.0 probe solve time');

report=struct();
report.kind='IslandEMSStep65TerminalConstraintAblationV1';
report.probe=p;
report.table=T;
report.summary=summaryTable;
report.verdict=verdict;
report.reason=reason;
report.elapsed_min=elapsed;
report.cacheFile=probeFile;
report.timestamp=char(datetime('now','Format','yyyyMMdd''T''HHmmss'));
end

function tf=is_project_root(p)
tf=isfolder(fullfile(p,'config')) && isfolder(fullfile(p,'core')) && ...
    isfolder(fullfile(p,'tests')) && exist(fullfile(p,'config','config_island_ems.m'),'file')==2;
end
