%% Baseline-catalog construction regression test
catalog=baseline_catalog();
expectedIDs=["T1","T2","T3","T4","T5","T6","T7","A0","G1","P1U","P1"];
ids=string({catalog.id});
assert(numel(catalog)==numel(expectedIDs),'Baseline catalog has an unexpected number of methods.');
assert(isequal(ids,expectedIDs),'Baseline catalog IDs/order do not match the intended experiment design.');
requiredFields={'id','description','legacyCase','reserveMode','reserveFixedRatio','curtailmentMode','aiSafetyCalibration'};
assert(all(ismember(requiredFields,fieldnames(catalog))), ...
    'Baseline catalog entries do not share the required structure fields.');
fprintf('Baseline-catalog construction test passed: %d methods.\n',numel(catalog));
