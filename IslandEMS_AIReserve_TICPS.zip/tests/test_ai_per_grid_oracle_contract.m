%% Deprecated test-name compatibility shim (old oracle scheme removed)
warning('test_ai_per_grid_oracle_contract:DeprecatedName', ...
    'Deprecated oracle test name redirected to randomized response-pipeline test.');
test_ai_response_pipeline_contract;
