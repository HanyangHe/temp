%% Numerical SoC-boundary guard regression test
clear;

socMin=0.20; socMax=0.90; tol=1e-4;
x=[0.9000085721; 0.81084; 0.199995; 0.50];
[y,m]=sanitize_soc_state(x,socMin,socMax,tol,'unit test');
assert(abs(y(1)-socMax)<1e-14);
assert(abs(y(3)-socMin)<1e-14);
assert(m.clipCount==2);
assert(abs(m.maxCorrection-8.5721e-06)<1e-10);

% A true violation must NOT be silently clipped.
threw=false;
try
    sanitize_soc_state([0.9002;0.5],socMin,socMax,tol,'true violation test');
catch ME
    threw = strcmp(ME.identifier,'IslandEMS:PhysicalSOCViolation');
end
assert(threw,'A true SoC violation beyond tolerance must raise an error.');

fprintf('Numerical SoC guard test passed: tiny overshoots clip to hard bounds; true violations fail loudly.\n');
