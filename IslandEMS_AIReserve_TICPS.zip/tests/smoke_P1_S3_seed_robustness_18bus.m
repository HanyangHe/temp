%% smoke_P1_S3_seed_robustness_18bus.m
% Exact closed-loop robustness test for the FROZEN S3@0.11 architecture.
%
% Frozen architecture:
%   KRR WITHOUT global calibration
%       +
%   Branch A:
%       forecastNetDrop_pu >= 0.02
%       AND forecastNetLoadNow_pu >= 0.60
%       OR
%   Branch B:
%       forecastNetDrop_pu >= 0.11
%       ->
%   alpha_final = 1.0
%
% Scope:
%   18bus
%   decayRatio = 1.00 only
%   P1 only
%   different random seed(s)
%   no formal result persistence
%
% DEFAULT next test:
%   TEST_SEEDS = 1
%
% IMPORTANT:
% Do NOT retune the thresholds after seeing this hold-out result.

clear;
clc;
close all force;

%% Frozen S3@0.11 parameters
DROP_THRESHOLD_PU        = 0.02;
NETLOAD_MIN_PU           = 0.60;
SEVERE_DROP_THRESHOLD_PU = 0.11;
SHIELD_ALPHA             = 1.00;

%% New hold-out seed(s)
TEST_SEEDS = 1;
% Optional later expansion:
% TEST_SEEDS = [1 2 3];

%% Setup
projectRoot = pwd;
addpath(genpath(projectRoot));
rehash;

cfg = config_island_ems();

engineFile = fullfile(projectRoot,'core','engine','engine_island_ems.m');
predFile   = which('predict_reserve_ratio');

assert(exist(engineFile,'file')==2 && ...
    contains(fileread(engineFile),'P1_FORECAST_SAFETY_SHIELD_EXPERIMENTAL'), ...
    'Forecast-shield engine hook is not active.');

assert(~isempty(predFile) && ...
    contains(fileread(predFile),'forecastSafetyShieldSevereBranch'), ...
    ['S3 two-branch predict_reserve_ratio.m is not active. ', ...
     'Apply the S3 patch first.']);

%% Fixed Part-I scope
caseName   = '18bus';
decayRatio = 1.00;

cfg.output.saveResults = false;
cfg.output.showFigures = false;

cfg.ai.enableForecastSafetyShield = true;
cfg.ai.forecastSafetyShieldDropThreshold_pu = DROP_THRESHOLD_PU;
cfg.ai.forecastSafetyShieldNetLoadMin_pu = NETLOAD_MIN_PU;
cfg.ai.forecastSafetyShieldSevereDropEnabled = true;
cfg.ai.forecastSafetyShieldSevereDropThreshold_pu = SEVERE_DROP_THRESHOLD_PU;
cfg.ai.forecastSafetyShieldAlpha = SHIELD_ALPHA;

catalog = paper_method_catalog();
ids = string({catalog.id});
idxP1 = find(ids=="P1",1);
assert(~isempty(idxP1),'P1 not found in paper_method_catalog().');

baseRunCfg = catalog(idxP1);
baseRunCfg.caseName = caseName;
baseRunCfg.dayType = cfg.scenario.dayType;
baseRunCfg.decayRatio = decayRatio;
baseRunCfg.aiSafetyCalibration = false;

fprintf('\n=============================================================\n');
fprintf(' S3@0.11 HOLD-OUT SEED ROBUSTNESS TEST\n');
fprintf('=============================================================\n');
fprintf('case                 : %s\n',caseName);
fprintf('decayRatio           : %.2f\n',decayRatio);
fprintf('calibration          : 0\n');
fprintf('moderate drop thr    : %.4f pu\n',DROP_THRESHOLD_PU);
fprintf('moderate netload min : %.4f pu\n',NETLOAD_MIN_PU);
fprintf('severe drop thr      : %.4f pu\n',SEVERE_DROP_THRESHOLD_PU);
fprintf('shield alpha         : %.4f\n',SHIELD_ALPHA);
fprintf('hold-out seeds       : %s\n',mat2str(TEST_SEEDS));
fprintf('save results         : 0\n');
fprintf('=============================================================\n');

%% Optional seed-0 successful reference from workspace
seed0Available = false;
seed0Summary = table();

if evalin('base','exist(''S3_threshold_refinement_results'',''var'')==1')
    R0 = evalin('base','S3_threshold_refinement_results');

    if isstruct(R0) && isfield(R0,'thr_110')
        seed0Available = true;
        seed0Result = R0.thr_110;

        seed0Summary = summarize_result_local( ...
            seed0Result,cfg,0, ...
            DROP_THRESHOLD_PU,NETLOAD_MIN_PU,SEVERE_DROP_THRESHOLD_PU);

        fprintf('\nExisting successful seed-0 S3@0.11 reference:\n');
        disp(seed0Summary);
    end
end

%% Exact hold-out runs
allSummary = table();
allResults = struct();

for iseed = 1:numel(TEST_SEEDS)

    seed = TEST_SEEDS(iseed);

    runCfg = baseRunCfg;
    runCfg.randomSeed = seed;

    fprintf('\n\n=============================================================\n');
    fprintf(' RUNNING HOLD-OUT SEED %d\n',seed);
    fprintf(' thresholds remain frozen\n');
    fprintf('=============================================================\n');

    result = run_single_experiment( ...
        cfg,runCfg,projectRoot,'',false);

    tag = sprintf('seed_%03d',seed);
    allResults.(tag) = result;

    metrics = analyze_result_local( ...
        result,cfg,seed, ...
        DROP_THRESHOLD_PU,NETLOAD_MIN_PU,SEVERE_DROP_THRESHOLD_PU);

    if isempty(allSummary)
        allSummary = metrics.summary;
    else
        allSummary = [allSummary;metrics.summary]; %#ok<AGROW>
    end

    fprintf('\nSeed %d summary:\n',seed);
    disp(metrics.summary);

    fprintf('\nSeed %d shield-trigger intervals:\n',seed);
    if isempty(metrics.triggerTable)
        fprintf('  NONE\n');
    else
        disp(metrics.triggerTable);
    end

    fprintf('\nSeed %d severe-only intervals:\n',seed);
    if isempty(metrics.severeOnlyTable)
        fprintf('  NONE\n');
    else
        disp(metrics.severeOnlyTable);
    end

    fprintf('\nSeed %d remaining CoI-unsafe intervals:\n',seed);
    if isempty(metrics.unsafeTable)
        fprintf('  NONE\n');
    else
        disp(metrics.unsafeTable);
    end

    if metrics.summary.CoIUnsafeCount==0
        fprintf('\n>>> SEED %d: S3@0.11 COI SAFETY PASS <<<\n',seed);
    else
        fprintf('\n>>> SEED %d: S3@0.11 COI SAFETY FAIL <<<\n',seed);
    end
end

%% Cross-seed summary
fprintf('\n\n=============================================================\n');
fprintf(' CROSS-SEED ROBUSTNESS SUMMARY\n');
fprintf('=============================================================\n');

if seed0Available
    combinedSummary = [seed0Summary; allSummary];
else
    combinedSummary = allSummary;
end

disp(combinedSummary);

fprintf('\nAggregate over tested hold-out seed(s):\n');
fprintf('  total unsafe intervals   = %d\n',sum(allSummary.CoIUnsafeCount));
fprintf('  worst max |df|           = %.6f Hz\n',max(allSummary.MaxAbsDf_Hz));
fprintf('  worst max |RoCoF|        = %.6f Hz/s\n',max(allSummary.MaxAbsRoCoF_Hz_s));
fprintf('  worst security stress    = %.6f\n',max(allSummary.MaxSecurityStress));
fprintf('  mean daily mean alpha    = %.6f\n',mean(allSummary.MeanAlpha));
fprintf('  mean daily cost          = %.6f\n',mean(allSummary.TotalCost));

%% Decision -- no retuning
fprintf('\n=============================================================\n');
fprintf(' ROBUSTNESS DECISION\n');
fprintf('=============================================================\n');

allSafe = all(allSummary.CoIUnsafeCount==0);

if allSafe
    fprintf(['PASS: every tested hold-out seed is CoI-frequency secure with ', ...
        'the SAME frozen 0.02 / 0.60 / 0.11 shield parameters.\n']);
    fprintf(['Next step: broaden validation rather than tuning these thresholds ', ...
        'again.\n']);
else
    badSeeds = allSummary.RandomSeed(allSummary.CoIUnsafeCount>0);
    fprintf('FAIL: unsafe hold-out seed(s): %s\n',mat2str(badSeeds.'));
    fprintf(['Do NOT retune the thresholds immediately. First inspect the ', ...
        'unsafe interval mechanism and reassess the shield architecture.\n']);
end

fprintf('=============================================================\n');

assignin('base','S3_seed_robustness_results',allResults);
assignin('base','S3_seed_robustness_summary',allSummary);

fprintf('\nExported to base workspace:\n');
fprintf('  S3_seed_robustness_results\n');
fprintf('  S3_seed_robustness_summary\n');


%% =========================================================================
% Local helpers
% =========================================================================

function out = analyze_result_local( ...
    result,cfg,seed,dropThr,netMin,severeThr)

summary = summarize_result_local( ...
    result,cfg,seed,dropThr,netMin,severeThr);

df = double(result.interval.maxAbsFreqDev_Hz(:));
rocof = double(result.interval.maxAbsRoCoF_Hz_s(:));

dfLim = cfg.frequency.securityDeviation_Hz;
rLim  = cfg.frequency.securityRoCoF_Hz_s;

stress = max(df/dfLim,rocof/rLim);
unsafe = stress>1+1e-12;

alpha = double(result.reserve.ratio(:));
n = numel(alpha);

step = (1:n).';
time_h = (step-1)*cfg.mpc.decisionInterval_h;

preAlpha = nan(n,1);
shieldTrig = false(n,1);
moderateTrig = false(n,1);
severeTrig = false(n,1);
forecastNet = nan(n,1);
forecastRamp = nan(n,1);
forecastDrop = nan(n,1);

H = result.reserve.metaHistory;

for k=1:min(n,numel(H))
    m = H{k};
    if ~isstruct(m) || ~isfield(m,'prediction') || ~isstruct(m.prediction)
        continue;
    end

    q = m.prediction;
    preAlpha(k) = get_scalar_local(q,'preShieldAlpha',NaN);
    shieldTrig(k) = get_logical_local(q,'forecastSafetyShieldTriggered',false);
    moderateTrig(k) = get_logical_local(q,'forecastSafetyShieldModerateBranch',false);
    severeTrig(k) = get_logical_local(q,'forecastSafetyShieldSevereBranch',false);
    forecastNet(k) = get_scalar_local(q,'forecastNetLoadNow_pu',NaN);
    forecastRamp(k) = get_scalar_local(q,'forecastSignedNetRamp_pu',NaN);
    forecastDrop(k) = get_scalar_local(q,'forecastNetDrop_pu',NaN);
end

idx = find(shieldTrig);
triggerTable = table( ...
    step(idx),time_h(idx),preAlpha(idx),alpha(idx), ...
    moderateTrig(idx),severeTrig(idx), ...
    forecastNet(idx),forecastRamp(idx),forecastDrop(idx), ...
    df(idx),rocof(idx),stress(idx),unsafe(idx), ...
    'VariableNames',{ ...
    'MPCStep','StartTime_h','PreShieldAlpha','FinalAlpha', ...
    'ModerateBranch','SevereBranch', ...
    'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu', ...
    'ForecastNetDrop_pu','MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s', ...
    'SecurityStress','CoIUnsafe'});

idx = find(severeTrig & ~moderateTrig);
severeOnlyTable = table( ...
    step(idx),time_h(idx),preAlpha(idx),alpha(idx), ...
    forecastNet(idx),forecastRamp(idx),forecastDrop(idx), ...
    df(idx),rocof(idx),stress(idx), ...
    'VariableNames',{ ...
    'MPCStep','StartTime_h','PreShieldAlpha','FinalAlpha', ...
    'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu', ...
    'ForecastNetDrop_pu','MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s', ...
    'SecurityStress'});

idx = find(unsafe);
unsafeTable = table( ...
    step(idx),time_h(idx),alpha(idx),shieldTrig(idx), ...
    moderateTrig(idx),severeTrig(idx), ...
    forecastNet(idx),forecastRamp(idx),forecastDrop(idx), ...
    df(idx),rocof(idx),stress(idx), ...
    'VariableNames',{ ...
    'MPCStep','StartTime_h','FinalAlpha','ShieldTriggered', ...
    'ModerateBranch','SevereBranch', ...
    'ForecastNetLoadNow_pu','ForecastSignedNetRamp_pu', ...
    'ForecastNetDrop_pu','MaxAbsDf_Hz','MaxAbsRoCoF_Hz_s', ...
    'SecurityStress'});

out = struct();
out.summary = summary;
out.triggerTable = triggerTable;
out.severeOnlyTable = severeOnlyTable;
out.unsafeTable = unsafeTable;
end


function summary = summarize_result_local( ...
    result,cfg,seed,dropThr,netMin,severeThr)

df = double(result.interval.maxAbsFreqDev_Hz(:));
rocof = double(result.interval.maxAbsRoCoF_Hz_s(:));

dfLim = cfg.frequency.securityDeviation_Hz;
rLim  = cfg.frequency.securityRoCoF_Hz_s;

stress = max(df/dfLim,rocof/rLim);
unsafe = stress>1+1e-12;

alpha = double(result.reserve.ratio(:));
n = numel(alpha);

shieldTrig = false(n,1);
moderateTrig = false(n,1);
severeTrig = false(n,1);
preAlpha = nan(n,1);

if isfield(result.reserve,'metaHistory')
    H = result.reserve.metaHistory;

    for k=1:min(n,numel(H))
        m = H{k};
        if ~isstruct(m) || ~isfield(m,'prediction') || ~isstruct(m.prediction)
            continue;
        end

        q = m.prediction;
        preAlpha(k) = get_scalar_local(q,'preShieldAlpha',NaN);
        shieldTrig(k) = get_logical_local(q,'forecastSafetyShieldTriggered',false);
        moderateTrig(k) = get_logical_local(q,'forecastSafetyShieldModerateBranch',false);
        severeTrig(k) = get_logical_local(q,'forecastSafetyShieldSevereBranch',false);
    end
end

summary = table();
summary.RandomSeed = seed;
summary.DropThreshold_pu = dropThr;
summary.NetLoadMin_pu = netMin;
summary.SevereThreshold_pu = severeThr;
summary.TotalCost = double(result.totalCost);
summary.MeanAlpha = mean(alpha,'omitnan');
summary.MinAlpha = min(alpha);
summary.MaxAlpha = max(alpha);
summary.MaxAbsDf_Hz = max(df);
summary.MaxAbsRoCoF_Hz_s = max(rocof);
summary.MaxSecurityStress = max(stress);
summary.CoIUnsafeCount = nnz(unsafe);
summary.CoIUnsafeRate = mean(unsafe);
summary.ShieldTriggerCount = nnz(shieldTrig);
summary.ModerateBranchCount = nnz(moderateTrig);
summary.SevereBranchCount = nnz(severeTrig);
summary.SevereOnlyCount = nnz(severeTrig & ~moderateTrig);
summary.MeanPreShieldAlpha = mean(preAlpha,'omitnan');
summary.MeanFinalAlpha = mean(alpha,'omitnan');
summary.MeanShieldAlphaIncrease = mean(alpha-preAlpha,'omitnan');
end


function v = get_scalar_local(s,name,defaultValue)
v = defaultValue;
if isstruct(s) && isfield(s,name)
    x = s.(name);
    if isnumeric(x) && isscalar(x)
        v = double(x);
    end
end
end


function v = get_logical_local(s,name,defaultValue)
v = logical(defaultValue);
if isstruct(s) && isfield(s,name)
    x = s.(name);
    if (islogical(x) || isnumeric(x)) && isscalar(x)
        v = logical(x);
    end
end
end
