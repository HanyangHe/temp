function report = quick_AI_policy_alpha_scan_test(caseName)
%QUICK_AI_POLICY_ALPHA_SCAN_TEST No-simulation check of learned online alpha policy.
%
% PURPOSE
%   Verify that P1/P1U are genuinely state-dependent and are not silently
%   hard-coded to alphaMin.  This test loads the canonical trained model and
%   canonical response dataset, evaluates the learned online selector on all
%   stored state rows, and reports the alpha distribution.
%
%   NO MPC, NO physical simulation, NO writes to outputs/.
%
% USAGE
%   report = quick_AI_policy_alpha_scan_test();          % default 18bus
%   report = quick_AI_policy_alpha_scan_test('18bus');

if nargin<1 || isempty(caseName), caseName='18bus'; end
caseName=char(string(caseName));

% This file is intended to live in <projectRoot>/tests/.
thisFile=mfilename('fullpath');
if isempty(thisFile)
    projectRoot=pwd;
else
    projectRoot=fileparts(fileparts(thisFile));
end
if ~exist(fullfile(projectRoot,'config'),'dir')
    projectRoot=pwd;
end
addpath(genpath(projectRoot));

cfg=config_island_ems();
validate_config(cfg);
modelFile=get_ai_reserve_model_file(projectRoot,cfg,caseName);
datasetFile=get_ai_reserve_dataset_file(projectRoot,cfg,caseName);
assert(exist(modelFile,'file')==2,'Model not found: %s',modelFile);
assert(exist(datasetFile,'file')==2,'Dataset not found: %s',datasetFile);

Sm=load(modelFile,'model'); model=Sm.model;
Sd=load(datasetFile,'dataset'); dataset=Sd.dataset;
[ok,msg]=validate_ai_reserve_model(model,cfg,caseName);
assert(ok,'Model is stale/incompatible: %s',msg);
assert(isfield(dataset,'Xstate') && size(dataset.Xstate,2)==3, ...
    'Canonical dataset does not contain the frozen three-state Xstate matrix.');

X=dataset.Xstate;
valid=all(isfinite(X),2);
Xv=X(valid,:);

% Evaluate the exact same selector used online.
aiU=cfg.ai; aiU.useSafetyCalibration=false;
aiC=cfg.ai; aiC.useSafetyCalibration=true;
[aU,dU]=select_reserve_alpha_batch(model,Xv,aiU,false);
[aC,dC]=select_reserve_alpha_batch(model,Xv,aiC,true);

levels=unique([cfg.ai.candidateAlphaGrid(:); cfg.ai.fallbackAlpha]);
levels=levels(levels>=cfg.ai.alphaMin-1e-12 & levels<=cfg.ai.alphaMax+1e-12);
levels=sort(levels(:));
countU=arrayfun(@(a)sum(abs(aU-a)<1e-12),levels);
countC=arrayfun(@(a)sum(abs(aC-a)<1e-12),levels);
T=table(levels,countU,countC,100*countU/numel(aU),100*countC/numel(aC), ...
    'VariableNames',{'Alpha','P1U_Count','P1_Count','P1U_pct','P1_pct'});

fprintf('\n=============================================================\n');
fprintf(' QUICK LEARNED AI-RESERVE POLICY ALPHA SCAN (NO SIMULATION)\n');
fprintf('=============================================================\n');
fprintf(' case / samples : %s / %d finite stored states\n',caseName,size(Xv,1));
fprintf(' online alpha   : [%.2f, %.2f], fallback %.2f\n', ...
    cfg.ai.alphaMin,cfg.ai.alphaMax,cfg.ai.fallbackAlpha);
fprintf(' P1U            : learned response selector, no calibration\n');
fprintf(' P1             : learned response selector + one-sided calibration\n');
fprintf(' model file     : %s\n',modelFile);
fprintf(' dataset file   : %s\n',datasetFile);
fprintf('=============================================================\n\n');

disp(T);

summary=table( ...
    [mean(aU);mean(aC)], [std(aU);std(aC)], ...
    [min(aU);min(aC)], [max(aU);max(aC)], ...
    [100*mean(abs(aU-cfg.ai.alphaMin)<1e-12);100*mean(abs(aC-cfg.ai.alphaMin)<1e-12)], ...
    [100*mean(abs(aU-cfg.ai.alphaMax)<1e-12);100*mean(abs(aC-cfg.ai.alphaMax)<1e-12)], ...
    [100*mean(dU.oodFallback);100*mean(dC.oodFallback)], ...
    [100*mean(dU.noSafeCandidateFallback);100*mean(dC.noSafeCandidateFallback)], ...
    [100*mean(dU.missingFeatureFallback);100*mean(dC.missingFeatureFallback)], ...
    'RowNames',{'P1U','P1'}, ...
    'VariableNames',{'MeanAlpha','StdAlpha','MinAlpha','MaxAlpha', ...
    'AtLowerBound_pct','AtUpperBound_pct','OODFallback_pct', ...
    'NoSafeFallback_pct','MissingFeatureFallback_pct'});

fprintf('\nPolicy summary:\n');
disp(summary);

% Simple state associations of the SELECTED policy alpha (diagnostic only).
stateNames=string(reserve_feature_names());
assoc=nan(3,2);
for j=1:3
    assoc(j,1)=local_spearman(Xv(:,j),aU);
    assoc(j,2)=local_spearman(Xv(:,j),aC);
end
Ta=table(stateNames(:),assoc(:,1),assoc(:,2), ...
    'VariableNames',{'StateFeature','Spearman_P1U_alpha','Spearman_P1_alpha'});
fprintf('\nSelected-alpha association with state features (diagnostic):\n');
disp(Ta);

% Strong diagnostic conclusion.
fracMinU=mean(abs(aU-cfg.ai.alphaMin)<1e-12);
fracMinC=mean(abs(aC-cfg.ai.alphaMin)<1e-12);
stdU=std(aU); stdC=std(aC);
if fracMinU>0.98 && fracMinC>0.98
    verdict="POLICY_COLLAPSED_TO_LOWER_BOUND";
    fprintf(2,'\nWARNING: Both P1U and P1 choose alphaMin for >98%% of stored states.\n');
    fprintf(2,'The learned online reserve rule is effectively collapsed and must be remedied before closed-loop validation.\n');
elseif fracMinC>0.95
    verdict="CALIBRATED_POLICY_NEARLY_COLLAPSED";
    fprintf(2,'\nWARNING: P1 chooses alphaMin for %.1f%% of stored states. Calibration does not create meaningful reserve adaptation.\n',100*fracMinC);
elseif stdC<0.01
    verdict="CALIBRATED_POLICY_LOW_VARIATION";
    fprintf(2,'\nWARNING: P1 alpha variation is very small (std %.4f). Inspect the response model before claiming state adaptation.\n',stdC);
else
    verdict="STATE_DEPENDENT_POLICY_CONFIRMED_OFFLINE";
    fprintf('\nPASS: learned policy is not hard-coded at alphaMin; P1 alpha std %.4f, lower-bound use %.1f%%.\n',stdC,100*fracMinC);
end

% Plot distributions and state dependence.
figure('Name','AI reserve policy scan - no simulation','NumberTitle','off');
tiledlayout(2,2);
nexttile;
bar(categorical(compose('%.2f',levels)),[countU countC]);
xlabel('\alpha'); ylabel('Count'); title('Selected alpha distribution'); grid on;
legend('P1U','P1','Location','best');

nexttile;
scatter(Xv(:,1),aC,14,Xv(:,2),'filled');
xlabel('P_{net} (pu)'); ylabel('P1 selected \alpha'); title('P1 policy vs P_{net}');
cb=colorbar; ylabel(cb,'|\DeltaP_{net}| (pu)'); grid on;

nexttile;
scatter(Xv(:,3),aC,14,Xv(:,1),'filled');
xlabel('DG upward headroom (pu)'); ylabel('P1 selected \alpha'); title('P1 policy vs DG headroom');
cb=colorbar; ylabel(cb,'P_{net} (pu)'); grid on;

nexttile;
scatter(aU,aC,14,Xv(:,1),'filled'); hold on;
plot([cfg.ai.alphaMin cfg.ai.alphaMax],[cfg.ai.alphaMin cfg.ai.alphaMax],'k--');
xlabel('P1U \alpha'); ylabel('P1 calibrated \alpha'); title('Calibration effect');
cb=colorbar; ylabel(cb,'P_{net} (pu)'); grid on;

report=struct();
report.kind='IslandEMSQuickAIPolicyAlphaScanV1';
report.caseName=caseName;
report.distribution=T;
report.summary=summary;
report.stateAssociation=Ta;
report.alphaP1U=aU;
report.alphaP1=aC;
report.detailP1U=dU;
report.detailP1=dC;
report.verdict=verdict;
report.modelFile=modelFile;
report.datasetFile=datasetFile;

fprintf('Verdict: %s\n',verdict);
fprintf('No MPC/physical simulation was launched and nothing was written to outputs/.\n');
end

function r=local_spearman(x,y)
x=x(:); y=y(:); ok=isfinite(x)&isfinite(y); x=x(ok); y=y(ok);
if numel(x)<3 || std(x)<eps || std(y)<eps, r=NaN; return; end
rx=local_tiedrank(x); ry=local_tiedrank(y);
C=corrcoef(rx,ry); r=C(1,2);
end

function r=local_tiedrank(x)
[sv,ord]=sort(x); r=zeros(size(x)); n=numel(x); i=1;
while i<=n
    j=i;
    while j<n && sv(j+1)==sv(i), j=j+1; end
    rr=(i+j)/2; r(ord(i:j))=rr; i=j+1;
end
end
