%% Sparse SOC-constraint builder must match the inherited dense formulation.
K=4; SOCmax=0.9; SOCmin=0.2;
SOC0=[0.55;0.60]; SOCorigin=[0.50;0.50];
EbG=[]; Eb=0.8; EbEV=0.126;
etaC=0.95; etaD=0.95;
DG=1; BG=0; B=1; EV=1; PV=1; NL=2; NB=4; Nbus=4; dt=0.25;
for step=1:K
    [Aold,bold]=SOC_InequalityConstraints_withEVenShedding_MPC( ...
        K,SOCmax,SOCmin,SOC0,EbG,Eb,EbEV,etaC,etaD,DG,BG,B,EV,PV,NL,NB,Nbus,dt,step,SOCorigin);
    [Anew,bnew]=build_soc_constraints_sparse_mpc( ...
        K,SOCmax,SOCmin,SOC0,EbG,Eb,EbEV,etaC,etaD,DG,BG,B,EV,PV,NL,NB,Nbus,dt,step,SOCorigin);
    assert(isequal(size(Aold),size(Anew)),'Sparse SOC matrix size mismatch at step %d.',step);
    assert(norm(full(Anew)-Aold,'fro')<1e-12,'Sparse SOC matrix differs from legacy formulation at step %d.',step);
    assert(norm(bnew-bold,inf)<1e-12,'Sparse SOC RHS differs from legacy formulation at step %d.',step);
end
fprintf('Sparse SOC-constraint equivalence test passed.\n');
