function report = quick_net_ramp_direction_test(varargin)
%QUICK_NET_RAMP_DIRECTION_TEST Final no-simulation check of net-load ramp sign.
%
% PURPOSE
%   Decide whether the AI-reserve learner should use
%       |Delta P_net|  (absolute net-load ramp)
%   or  Delta P_net    (signed net-load ramp)
%   after the feature screening reduced the physics core to
%       P_net, net-load ramp, DG upward headroom.
%
%   This test reuses the small 96-row feature-screening snapshot produced by
%   smoke_T7_18bus(). It performs NO MPC solve, NO physical simulation, and
%   writes nothing to outputs/.
%
% PRIMARY COMPARISON
%   A) [P_net, |Delta P_net|, DG_up_headroom]
%   B) [P_net,  Delta P_net , DG_up_headroom]
%
% OPTIONAL DIAGNOSTIC
%   C) [P_net, max(Delta P_net,0), max(-Delta P_net,0), DG_up_headroom]
%      This is included only to detect strong direction asymmetry. It is NOT
%      automatically recommended because it adds one feature dimension.
%
% USAGE
%   report = quick_net_ramp_direction_test();
%   report = quick_net_ramp_direction_test(snapshot);
%   report = quick_net_ramp_direction_test(fullSmokeResult);
%
% DECISION POLICY
%   Prefer the simpler absolute-ramp representation unless the signed-ramp
%   version gives a clear and consistent blocked-CV improvement. This keeps
%   the eventual AI input compact and physically interpretable.

snapshot = resolve_snapshot(varargin{:});
if isempty(snapshot)
    fprintf('\nNET-RAMP DIRECTION TEST NOT RUN: no completed smoke snapshot found.\n');
    fprintf('Run smoke_T7_18bus() once, then rerun this test.\n');
    report = struct('kind','IslandEMSQuickNetRampDirectionTestV1', ...
        'recommendation','NO_DATA');
    return;
end

names = string(snapshot.features.names);
Xall = snapshot.features.data;
y = snapshot.target.stress(:);
t = snapshot.time_h(:);

required = ["netLoadNow_pu","netLoadNext_pu","absNetLoadRamp_pu","dgUpHeadroom_pu"];
idx = nan(size(required));
for i=1:numel(required)
    j=find(names==required(i),1);
    if isempty(j)
        error('quick_net_ramp_direction_test:MissingFeature', ...
            'Snapshot is missing required feature "%s".',required(i));
    end
    idx(i)=j;
end

PnetNow = Xall(:,idx(1));
PnetNext = Xall(:,idx(2));
absRampStored = Xall(:,idx(3));
headroom = Xall(:,idx(4));

% Signed forward net-load ramp on exactly the same normalized DG base used
% by build_reserve_features.m.
signedRamp = PnetNext - PnetNow;
absRampDerived = abs(signedRamp);

% Sanity check: the stored absolute ramp should equal the magnitude of the
% reconstructed signed ramp (up to floating-point noise).
rampConsistency = max(abs(absRampStored-absRampDerived),[],'omitnan');
if rampConsistency > 1e-9
    warning('Stored absNetLoadRamp_pu and abs(netLoadNext-netLoadNow) differ by %.3e.',rampConsistency);
end

upRamp = max(signedRamp,0);
downRamp = max(-signedRamp,0);

XA = [PnetNow absRampStored headroom];
XB = [PnetNow signedRamp headroom];
XC = [PnetNow upRamp downRamp headroom];

valid = isfinite(y) & all(isfinite([XA XB XC]),2);
y=y(valid); t=t(valid); XA=XA(valid,:); XB=XB(valid,:); XC=XC(valid,:);
signedRamp=signedRamp(valid); absRampStored=absRampStored(valid);

if numel(y)<32
    error('Too few valid samples (%d) for blocked-CV comparison.',numel(y));
end

fprintf('\n=============================================================\n');
fprintf(' QUICK NET-LOAD RAMP DIRECTION TEST (NO SIMULATION)\n');
fprintf('=============================================================\n');
fprintf(' case / method : %s / %s\n',string(snapshot.meta.caseName),string(snapshot.meta.methodID));
fprintf(' samples       : %d decision intervals\n',numel(y));
fprintf(' target        : realized frequency stress\n');
fprintf(' CV policy     : 4 contiguous outer blocks + inner tuning\n');
fprintf(' physics core  : Pnet + ramp + DG upward headroom\n');
fprintf(' compare       : |dPnet| vs signed dPnet (+ split diagnostic)\n');
fprintf(' persistence   : OFF\n');
fprintf(' ramp check    : max |stored abs ramp - abs(signed ramp)| = %.3e\n',rampConsistency); 
fprintf('=============================================================\n');

foldId=contiguous_folds(numel(y),4);
variants={XA,XB,XC};
labels=["ABS: |dPnet|","SIGNED: dPnet","SPLIT: dPnet+ / dPnet-"];

metricsRows=[];
oof=struct();
for v=1:numel(variants)
    [predR,mR]=blocked_oof_model(variants{v},y,foldId,'ridge');
    [predK,mK]=blocked_oof_model(variants{v},y,foldId,'krr');
    metricsRows=[metricsRows; ... %#ok<AGROW>
        {labels(v),"Ridge",mR.RMSE,mR.MAE,mR.R2,mR.Corr}; ...
        {labels(v),"RBF-KRR",mK.RMSE,mK.MAE,mK.R2,mK.Corr}];
    fld=matlab.lang.makeValidName(char(labels(v)));
    oof.(fld)=struct('ridge',predR,'krr',predK);
end
Metrics=cell2table(metricsRows,'VariableNames',{'FeatureVariant','Model','RMSE','MAE','R2','Corr'});

fprintf('\nBlocked-CV comparison:\n');
disp(Metrics);

% Convenience summary: improvement of SIGNED relative to ABS.
getrow=@(variant,model) Metrics(Metrics.FeatureVariant==variant & Metrics.Model==model,:);
A_R=getrow(labels(1),"Ridge"); B_R=getrow(labels(2),"Ridge"); C_R=getrow(labels(3),"Ridge");
A_K=getrow(labels(1),"RBF-KRR"); B_K=getrow(labels(2),"RBF-KRR"); C_K=getrow(labels(3),"RBF-KRR");

signedImproveRMSE_R=100*(A_R.RMSE-B_R.RMSE)/max(A_R.RMSE,eps);
signedImproveRMSE_K=100*(A_K.RMSE-B_K.RMSE)/max(A_K.RMSE,eps);
signedImproveMAE_R=100*(A_R.MAE-B_R.MAE)/max(A_R.MAE,eps);
signedImproveMAE_K=100*(A_K.MAE-B_K.MAE)/max(A_K.MAE,eps);
splitImproveRMSE_K=100*(A_K.RMSE-C_K.RMSE)/max(A_K.RMSE,eps);

rhoSignedStress=spearman_safe(signedRamp,y);
rhoAbsStress=spearman_safe(absRampStored,y);
rhoSignedDf=spearman_safe(signedRamp,snapshot.target.peakDf_Hz(valid));
rhoSignedRoCoF=spearman_safe(signedRamp,snapshot.target.peakRoCoF_Hz_s(valid));

Direction=table(rhoAbsStress,rhoSignedStress,rhoSignedDf,rhoSignedRoCoF, ...
    mean(signedRamp>0),mean(signedRamp<0), ...
    'VariableNames',{'SpearmanAbsRampStress','SpearmanSignedRampStress', ...
    'SpearmanSignedRampDf','SpearmanSignedRampRoCoF','FractionRampUp','FractionRampDown'});

fprintf('\nDirection diagnostics:\n');
disp(Direction);

fprintf('\nSIGNED relative to ABS:\n');
fprintf('  Ridge   RMSE improvement : %+6.2f %%\n',signedImproveRMSE_R);
fprintf('  Ridge   MAE  improvement : %+6.2f %%\n',signedImproveMAE_R);
fprintf('  RBF-KRR RMSE improvement : %+6.2f %%\n',signedImproveRMSE_K);
fprintf('  RBF-KRR MAE  improvement : %+6.2f %%\n',signedImproveMAE_K);
fprintf('  Split-ramp KRR RMSE improvement vs ABS: %+6.2f %%\n',splitImproveRMSE_K);

% Conservative recommendation: signed should win clearly, not marginally.
% Use both model families to avoid picking directionality from one nonlinear
% fit artifact on a single day.
if signedImproveRMSE_K >= 5 && signedImproveMAE_K >= 3 && signedImproveRMSE_R >= 2
    recommendation="USE_SIGNED_RAMP";
    reason=sprintf(['Signed dPnet gives clear incremental value: KRR RMSE %+0.1f%%, ' ...
        'KRR MAE %+0.1f%%, Ridge RMSE %+0.1f%% relative to |dPnet|.'], ...
        signedImproveRMSE_K,signedImproveMAE_K,signedImproveRMSE_R);
elseif signedImproveRMSE_K <= -3 || signedImproveRMSE_R <= -3
    recommendation="USE_ABSOLUTE_RAMP";
    reason=sprintf(['Signed dPnet does not generalize better: KRR RMSE %+0.1f%%, ' ...
        'Ridge RMSE %+0.1f%% relative to |dPnet|. Keep the simpler disturbance-magnitude feature.'], ...
        signedImproveRMSE_K,signedImproveRMSE_R);
else
    recommendation="USE_ABSOLUTE_RAMP";
    reason=sprintf(['Signed-ramp gain is small/mixed (KRR RMSE %+0.1f%%, Ridge %+0.1f%%). ' ...
        'Prefer |dPnet| for the symmetric reserve multiplier; alpha* labels can revisit directionality later.'], ...
        signedImproveRMSE_K,signedImproveRMSE_R);
end

% Strong split-ramp gain is reported as a future-model warning, not an
% automatic recommendation because it increases dimension and suggests that
% up/down reserve may eventually deserve separate treatment.
if splitImproveRMSE_K >= 8 && C_R.RMSE <= A_R.RMSE
    splitNote=sprintf(['Split positive/negative ramps improve KRR RMSE by %.1f%% and do not hurt Ridge. ' ...
        'This suggests directional asymmetry; keep as a future up/down-reserve extension, not the first model.'], ...
        splitImproveRMSE_K);
else
    splitNote='No compelling evidence that splitting positive/negative ramps is worth an extra feature dimension.';
end

fprintf('\n=============================================================\n');
fprintf(' FINAL RAMP-FEATURE RECOMMENDATION: %s\n',recommendation);
fprintf(' %s\n',reason);
fprintf(' Split diagnostic: %s\n',splitNote);
fprintf('=============================================================\n\n');

% Plots: compact and directly interpretable.
figure('Name','Net-load ramp direction test');
tiledlayout(2,2,'TileSpacing','compact');

nexttile;
bar(categorical(cellstr(labels)),[ ...
    A_R.RMSE A_K.RMSE; B_R.RMSE B_K.RMSE; C_R.RMSE C_K.RMSE]);
grid on; box on; ylabel('Blocked-CV RMSE');
legend('Ridge','RBF-KRR','Location','best');
title('Ramp representation comparison');

nexttile;
plot(t,signedRamp,'LineWidth',1.0); hold on; yline(0,'k--');
grid on; box on; xlabel('Time (h)'); ylabel('\DeltaP_{net} (p.u.)');
title('Signed forward net-load ramp');

nexttile;
scatter(signedRamp,y,24,'filled'); hold on; xline(0,'k--'); yline(1,'k--');
grid on; box on; xlabel('Signed \DeltaP_{net} (p.u.)'); ylabel('Frequency stress');
title(sprintf('Signed ramp vs stress (\rho_s=%+.2f)',rhoSignedStress));

nexttile;
plot(t,y,'k','LineWidth',1.2); hold on;
plot(t,oof.ABS_dPnet_.krr,'LineWidth',1.0);
plot(t,oof.SIGNED_dPnet.krr,'LineWidth',1.0);
yline(1,'k--'); grid on; box on; xlabel('Time (h)'); ylabel('Frequency stress');
legend('Realized','KRR + |dPnet|','KRR + signed dPnet','Security boundary','Location','best');
title('Blocked OOF predictions');

report=struct();
report.kind='IslandEMSQuickNetRampDirectionTestV1';
report.metrics=Metrics;
report.direction=Direction;
report.signedImprovement=struct('ridgeRMSE_pct',signedImproveRMSE_R, ...
    'ridgeMAE_pct',signedImproveMAE_R,'krrRMSE_pct',signedImproveRMSE_K, ...
    'krrMAE_pct',signedImproveMAE_K,'splitKrrRMSE_pct',splitImproveRMSE_K);
report.recommendation=recommendation;
report.reason=reason;
report.splitNote=splitNote;
report.rampConsistency=rampConsistency;
report.oof=oof;
report.snapshotMeta=snapshot.meta;
end

% ========================================================================
function snapshot=resolve_snapshot(varargin)
snapshot=[];
if nargin>=1 && isstruct(varargin{1})
    x=varargin{1};
    if is_snapshot(x), snapshot=x; return; end
    if is_full_result(x), snapshot=build_feature_screening_snapshot(x); return; end
end
vars={'featureScreenSnapshot','lastSmokeResult','result','base'};
for i=1:numel(vars)
    nm=vars{i};
    if evalin('base',sprintf('exist(''%s'',''var'')',nm))
        x=evalin('base',nm);
        if is_snapshot(x), snapshot=x; return; end
        if is_full_result(x), snapshot=build_feature_screening_snapshot(x); return; end
    end
end
cacheFile=fullfile(tempdir,'IslandEMS_feature_screening_snapshot.mat');
if isfile(cacheFile)
    S=load(cacheFile,'snapshot');
    if isfield(S,'snapshot') && is_snapshot(S.snapshot), snapshot=S.snapshot; end
end
end
function tf=is_snapshot(x)
tf=isstruct(x)&&isfield(x,'kind')&&strcmp(string(x.kind),'IslandEMSFeatureScreenSnapshotV1')&&isfield(x,'features')&&isfield(x,'target');
end
function tf=is_full_result(r)
tf=isstruct(r)&&isfield(r,'meta')&&isfield(r,'cfgSnapshot')&&isfield(r,'freq_Hz')&&isfield(r,'P_DG_MW')&&isfield(r,'totalLoad_MW');
end
function f=contiguous_folds(n,K)
f=ceil((1:n)'*K/n); f(f<1)=1; f(f>K)=K;
end
function [oof,m]=blocked_oof_model(X,y,foldId,type)
n=numel(y); oof=nan(n,1); K=max(foldId);
for k=1:K
    te=(foldId==k); tr=~te;
    param=tune_inner(X(tr,:),y(tr),type);
    oof(te)=fit_predict(X(tr,:),y(tr),X(te,:),type,param);
end
m=metrics(y,oof);
end
function param=tune_inner(X,y,type)
n=size(X,1); fid=contiguous_folds(n,min(3,n));
if strcmp(type,'ridge')
    grid=logspace(-4,1,6); loss=inf(numel(grid),1);
    for q=1:numel(grid)
        pred=nan(n,1);
        for k=1:max(fid)
            te=fid==k; tr=~te;
            if sum(tr)<8 || sum(te)<1, continue; end
            pred(te)=fit_predict(X(tr,:),y(tr),X(te,:),'ridge',grid(q));
        end
        loss(q)=rmse_safe(y,pred);
    end
    [~,i]=min(loss); param=grid(i);
else
    lambdas=[1e-4 1e-3 1e-2 1e-1]; scales=[0.5 1 2];
    best=inf; param=[1e-2 1];
    for a=1:numel(lambdas)
        for b=1:numel(scales)
            pred=nan(n,1);
            for k=1:max(fid)
                te=fid==k; tr=~te;
                if sum(tr)<8 || sum(te)<1, continue; end
                pred(te)=fit_predict(X(tr,:),y(tr),X(te,:),'krr',[lambdas(a) scales(b)]);
            end
            L=rmse_safe(y,pred);
            if L<best, best=L; param=[lambdas(a) scales(b)]; end
        end
    end
end
end
function pred=fit_predict(Xtr,ytr,Xte,type,param)
mu=mean(Xtr,1,'omitnan'); sg=std(Xtr,0,1,'omitnan'); sg(~isfinite(sg)|sg<1e-10)=1;
Xs=(Xtr-mu)./sg; Xt=(Xte-mu)./sg;
ym=mean(ytr,'omitnan'); ys=std(ytr,0,'omitnan'); if ~isfinite(ys)||ys<1e-10, ys=1; end
yz=(ytr-ym)/ys;
if strcmp(type,'ridge')
    lam=param;
    Z=[ones(size(Xs,1),1) Xs]; Zt=[ones(size(Xt,1),1) Xt];
    reg=diag([0;lam*ones(size(Xs,2),1)]);
    beta=(Z'*Z+reg)\(Z'*yz);
    pred=(Zt*beta)*ys+ym;
else
    lam=param(1); scale=param(2);
    D=sqdist(Xs,Xs); dvec=D(triu(true(size(D)),1)); dvec=dvec(dvec>0 & isfinite(dvec));
    if isempty(dvec), sigma=1; else, sigma=sqrt(median(dvec)/2); end
    sigma=max(sigma*scale,1e-6);
    K=exp(-D/(2*sigma^2)); alpha=(K+lam*eye(size(K)))\yz;
    Kt=exp(-sqdist(Xt,Xs)/(2*sigma^2)); pred=(Kt*alpha)*ys+ym;
end
pred=pred(:);
end
function D=sqdist(A,B)
D=max(sum(A.^2,2)+sum(B.^2,2)'-2*(A*B'),0);
end
function m=metrics(y,p)
mask=isfinite(y)&isfinite(p); y=y(mask); p=p(mask);
m=struct(); m.RMSE=sqrt(mean((y-p).^2)); m.MAE=mean(abs(y-p));
ss=sum((y-mean(y)).^2); m.R2=1-sum((y-p).^2)/max(ss,eps);
if numel(y)>2, C=corrcoef(y,p); m.Corr=C(1,2); else, m.Corr=NaN; end
end
function r=rmse_safe(y,p)
mask=isfinite(y)&isfinite(p); if sum(mask)<3, r=Inf; else, r=sqrt(mean((y(mask)-p(mask)).^2)); end
end
function r=spearman_safe(x,y)
mask=isfinite(x)&isfinite(y); x=x(mask); y=y(mask);
if numel(x)<5||std(x)<eps||std(y)<eps, r=NaN; return; end
rx=tied_rank_local(x); ry=tied_rank_local(y); C=corrcoef(rx,ry); r=C(1,2);
end
function r=tied_rank_local(x)
[sv,ord]=sort(x); r=zeros(size(x)); n=numel(x); i=1;
while i<=n
    j=i; while j<n && sv(j+1)==sv(i), j=j+1; end
    r(ord(i:j))=(i+j)/2; i=j+1;
end
end
