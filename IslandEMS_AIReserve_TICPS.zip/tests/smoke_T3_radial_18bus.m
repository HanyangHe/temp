function results = smoke_T3_radial_18bus()
%SMOKE_T3_RADIAL_18BUS T3-only radial integration test, no persistence.

thisFile = mfilename('fullpath');
projectRoot = fileparts(fileparts(thisFile));
addpath(genpath(projectRoot));

cfg = config_island_ems();
cfg.experiment.systemCases = {'18bus'};
cfg.experiment.enabledMethods = {'T3'};
cfg.scenario.dayType = 'Unusual day';
cfg.scenario.decayRatios = 0.20;
cfg.experiment.randomSeeds = 0;

cfg.output.saveResults = false;
cfg.output.showFigures = false;
cfg.output.exportFigures = false;
cfg.output.writeSummaryCSV = false;
cfg.output.runTag = 'DO_NOT_SAVE_T3_RADIAL_SMOKE';

validate_config(cfg);

fprintf('\nT3 radial integration smoke test (in-memory only)\n');
fprintf('  method : T3\n');
fprintf('  case   : 18bus\n');
fprintf('  decay  : 0.20\n');
fprintf('  seed   : 0\n');
fprintf('  output : OFF\n\n');

results = run_experiments(cfg,projectRoot);

fprintf('\nT3 radial integration smoke test completed.\n');
fprintf('No formal result files were created.\n');
end
