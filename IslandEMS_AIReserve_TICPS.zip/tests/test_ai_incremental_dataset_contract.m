%% Synthetic matched-parity response-dataset merge/reuse contract test (no simulation)
cfg=config_island_ems();
caseName='18bus'; names=reserve_feature_names();
base=make_mock([0.6;0.7;0.8;0.9;1.0],1,0.6,0,names,cfg,caseName);
extra=make_mock([0.3;0.3],2,0.6,0,names,cfg,caseName); % SAME paper scenario
[ok,msg]=response_dataset_merge_compatible(base,cfg,caseName); assert(ok,msg);
[ok,msg]=response_dataset_merge_compatible(extra,cfg,caseName); assert(ok,msg);
merged=merge_reserve_response_datasets(base,extra,cfg,caseName);
assert(size(merged.X,1)==7,'Merged sample count incorrect.');
% Same decay/seed scenario must remain one grouped CV unit after parity merge.
assert(numel(unique(merged.groupID))==1, ...
    'Matched parity rows should reuse the existing scenario group ID.');
assert(merged.mergeInfo.matchedGroups==1 && merged.mergeInfo.addedGroups==0, ...
    'Matched-parity group accounting is incorrect.');
assert(any(abs(merged.alpha-0.3)<1e-12) && any(abs(merged.alpha-1.0)<1e-12), ...
    'Merged alpha coverage incorrect.');
assert(all(ismember([0.3 0.6 0.7 0.8 0.9 1.0],merged.alphaLevels)), ...
    'Merged alphaLevels metadata incorrect.');
fprintf('Matched final-paper alpha=0.30 merge/group-reuse unit test passed.\n');

function d=make_mock(alphas,gid,decay,seed,names,cfg,caseName)
n=numel(alphas); Xs=[linspace(0.1,0.5,n)' linspace(0.01,0.05,n)' linspace(0.2,0.4,n)'];
d=struct(); d.kind='IslandEMSFrequencyStressResponseDatasetV1'; d.caseName=caseName;
d.stateFeatureNames=names; d.inputNames=[names {'reserveRatio'}];
d.Xstate=Xs; d.alpha=alphas(:); d.X=[Xs alphas(:)]; d.yStress=0.5*ones(n,1);
d.maxAbsFreqDev_Hz=0.2*ones(n,1); d.maxAbsRoCoF_Hz_s=0.2*ones(n,1); d.secure=true(n,1);
d.groupID=gid*ones(n,1); d.decayRatio=decay*ones(n,1); d.randomSeed=seed*ones(n,1);
d.intervalIndex=(1:n)'; d.time_h=(0:n-1)'*cfg.mpc.decisionInterval_h;
d.groupMeta=struct('groupID',gid,'decayRatio',decay,'randomSeed',seed); d.alphaLevels=sort(unique(alphas(:))).';
d.securityLimits=struct('df_Hz',cfg.frequency.securityDeviation_Hz,'rocof_Hz_s',cfg.frequency.securityRoCoF_Hz_s);
d.trainingSignature=ai_reserve_model_signature(cfg,caseName); d.created=datestr(now,30);
end
