function report = diagnose_P1_step65_state_rootcause(forceRerun)
%DIAGNOSE_P1_STEP65_STATE_ROOTCAUSE Next-stage root-cause diagnostic.
%
% Purpose
% -------
% The previous exact-state probe established that P1 reaches an MPC state at
% step 65 for which alpha = 1.0...0.6 are ALL infeasible.  This test now
% diagnoses the state/history that produced that recursive infeasibility:
%   1) persist/reuse the full step-65 diagnostic under tests/cache/;
%   2) report BESS and EV SoC at step 65 and margins to hard SoC limits;
%   3) classify every alpha=1 event as learned selection, OOD fallback,
%      no-safe-candidate fallback, or missing-feature fallback;
%   4) show the last 20 policy decisions together with fallback causes;
%   5) explicitly identify whether step 65 alpha=1 was a model decision or
%      a safety fallback;
%   6) audit the current rolling-horizon terminal-SoC implementation source
%      so the next diagnostic can target the correct constraint family.
%
% This is NOT a paper experiment.  It writes only to tests/cache/ and never
% to formal outputs/.
%
% Usage
%   report = diagnose_P1_step65_state_rootcause();       % reuse cache if any
%   report = diagnose_P1_step65_state_rootcause(true);   % force ~17 min rerun
%
% Requires the already installed diagnose_P1_step65_feasibility.m and its
% step-65 engine diagnostic hook.

if nargin < 1 || isempty(forceRerun), forceRerun = false; end
clc;

%% Project root
thisFile = mfilename('fullpath');
projectRoot = fileparts(fileparts(thisFile));
if ~is_project_root(projectRoot)
    if is_project_root(pwd)
        projectRoot = pwd;
    else
        hit = which('config_island_ems');
        if ~isempty(hit)
            candidate = fileparts(fileparts(hit));
            if is_project_root(candidate), projectRoot = candidate; end
        end
    end
end
if ~is_project_root(projectRoot)
    error('IslandEMS:ProjectRoot','Cannot identify IslandEMS project root.');
end
addpath(genpath(projectRoot));

cacheDir = fullfile(projectRoot,'tests','cache');
if ~exist(cacheDir,'dir'), mkdir(cacheDir); end
cacheFile = fullfile(cacheDir,'P1_step65_state_rootcause.mat');

%% Reuse or generate persistent diagnostic
step65Report = [];
if ~forceRerun && exist(cacheFile,'file')==2
    C = load(cacheFile);
    if isfield(C,'step65Report') && isstruct(C.step65Report) && ...
            isfield(C.step65Report,'probe') && isstruct(C.step65Report.probe)
        step65Report = C.step65Report;
        fprintf('\nReusing persistent step-65 cache:\n  %s\n',cacheFile);
    end
end

if isempty(step65Report)
    fprintf('\nNo reusable persistent step-65 report was found.\n');
    fprintf('Running the exact-state P1 diagnostic once (~17 min)...\n\n');
    step65Report = diagnose_P1_step65_feasibility('P1');
    if ~isstruct(step65Report) || ~isfield(step65Report,'probe') || ...
            ~isstruct(step65Report.probe)
        error('IslandEMS:BadStep65Report','Step-65 diagnostic did not return the expected struct.');
    end
    save(cacheFile,'step65Report','-v7.3');
    fprintf('\nPersistent diagnostic saved under tests/cache/:\n  %s\n',cacheFile);
end

p = step65Report.probe;
cfg = config_island_ems();
sys = system_case_catalog('18bus',cfg);

%% Device counts / SoC ordering
nBGFM = numel(sys.BusOfBatteryGFM);
nBESS = numel(sys.BusOfBattery);
nEV   = numel(sys.BusOfEVBattery);
nStorage = nBGFM + nBESS + nEV;
assert(isfield(p,'currentSOC') && numel(p.currentSOC)==nStorage, ...
    'currentSOC length (%d) does not match expected 18bus storage count (%d).', ...
    numel(p.currentSOC),nStorage);

SOCmin = cfg.storage.SOCmin;
SOCmax = cfg.storage.SOCmax;
SOCinit = 0.50; % current benchmark initialization in engine_island_ems.m
soc = p.currentSOC(:);

labels = strings(nStorage,1);
types = strings(nStorage,1);
idx = 0;
for i=1:nBGFM
    idx=idx+1; labels(idx)=sprintf('GFM-BESS%d',i); types(idx)='BESS';
end
for i=1:nBESS
    idx=idx+1; labels(idx)=sprintf('BESS%d',i); types(idx)='BESS';
end
for i=1:nEV
    idx=idx+1; labels(idx)=sprintf('EV%d',i); types(idx)='EV';
end

socTable = table(labels,types,soc,soc-SOCmin,SOCmax-soc,soc-SOCinit, ...
    'VariableNames',{'Device','Type','SoC','MarginToMin','MarginToMax','DeltaFromInit'});

%% Reserve-policy fallback attribution
H = {};
if isfield(p,'reserveMetaHistory'), H = p.reserveMetaHistory; end
nStep = numel(H);
alpha = nan(nStep,1);
ood = false(nStep,1);
noSafe = false(nStep,1);
missing = false(nStep,1);
source = strings(nStep,1);
rawAvailable = false(nStep,1);

for k=1:nStep
    m = H{k};
    if isempty(m) || ~isstruct(m), continue; end
    if isfield(m,'alpha') && isfinite(m.alpha), alpha(k)=double(m.alpha); end
    if isfield(m,'prediction') && isstruct(m.prediction)
        q=m.prediction;
        if isfield(q,'oodFallback'), ood(k)=logical(q.oodFallback); end
        if isfield(q,'noSafeCandidateFallback'), noSafe(k)=logical(q.noSafeCandidateFallback); end
        if isfield(q,'missingFeatureFallback'), missing(k)=logical(q.missingFeatureFallback); end
        if isfield(q,'source'), source(k)=string(q.source); end
        if isfield(q,'rawStressCurve')
            rawAvailable(k)=any(isfinite(q.rawStressCurve));
        end
    end
end

isFull = abs(alpha-1)<1e-9;
isAdaptiveFull = isFull & ~ood & ~noSafe & ~missing;

fallbackSummary = table( ...
    ["All steps";"alpha=1 steps";"alpha=1 due OOD";"alpha=1 due no-safe"; ...
     "alpha=1 due missing";"alpha=1 genuine model selection"], ...
    [sum(isfinite(alpha));sum(isFull);sum(isFull&ood);sum(isFull&noSafe); ...
     sum(isFull&missing);sum(isAdaptiveFull)], ...
    'VariableNames',{'Category','Count'});
fallbackSummary.PctOfObserved = 100*fallbackSummary.Count/max(sum(isfinite(alpha)),1);

%% Last-20 policy table with causes
lastIdx=max(1,nStep-19):nStep;
featureHistory = nan(nStep,3);
if isfield(p,'featureHistory') && size(p.featureHistory,1)>=nStep
    featureHistory=p.featureHistory(1:nStep,:);
end
last20 = table(lastIdx(:),(lastIdx(:)-1)*cfg.mpc.decisionInterval_h,alpha(lastIdx), ...
    featureHistory(lastIdx,1),featureHistory(lastIdx,2),featureHistory(lastIdx,3), ...
    ood(lastIdx),noSafe(lastIdx),missing(lastIdx),rawAvailable(lastIdx),source(lastIdx), ...
    'VariableNames',{'Step','Time_h','Alpha','Pnet_pu','AbsDPnet_pu','DGHeadroom_pu', ...
    'OOD','NoSafe','MissingFeature','StressCurveAvailable','Source'});

%% Step-65 selected-alpha cause
kT = p.targetStep;
targetCause = "learned-model selection";
if kT<=nStep
    if missing(kT), targetCause="missing-feature fallback";
    elseif ood(kT), targetCause="OOD fallback";
    elseif noSafe(kT), targetCause="no-safe-candidate fallback";
    end
end

%% Static audit of rolling-horizon terminal-SoC formulation
builderFile = which('build_soc_constraints_sparse_mpc');
sourceAudit = struct('file',string(builderFile), ...
    'bessHardHorizonEndLower',false,'evHardHorizonEndPair',false, ...
    'bessDailyRelaxationPresent',false);
if ~isempty(builderFile)
    txt = fileread(builderFile);
    sourceAudit.bessHardHorizonEndLower = contains(txt,'b_SOC(rL(end))=0');
    sourceAudit.evHardHorizonEndPair = contains(txt,'b_SOC(rU(end))=0') && contains(txt,'b_SOC(rL(end))=0');
    sourceAudit.bessDailyRelaxationPresent = contains(txt,'A0(rU(index),shedCol)=1') && ...
        contains(txt,'A0(rL(index),shedCol)=-1');
end

%% Heuristic state pressure indicators (diagnostic only)
bessMask = types=="BESS";
evMask = types=="EV";
bessSOC = soc(bessMask);
evSOC = soc(evMask);

bessNearUpper = any(SOCmax-bessSOC < 0.05);
bessNearLower = any(bessSOC-SOCmin < 0.05);
bessAboveInit = any(bessSOC > SOCinit+0.05);
evNearUpper = any(SOCmax-evSOC < 0.05);
evNearLower = any(evSOC-SOCmin < 0.05);

stateFlags = table( ...
    ["BESS near upper SoC";"BESS near lower SoC";"BESS > initial by >0.05"; ...
     "EV near upper SoC";"EV near lower SoC"], ...
    [bessNearUpper;bessNearLower;bessAboveInit;evNearUpper;evNearLower], ...
    'VariableNames',{'Indicator','Triggered'});

%% Print report
fprintf('\n=============================================================\n');
fprintf(' P1 STEP-65 STATE / FALLBACK ROOT-CAUSE DIAGNOSTIC\n');
fprintf('=============================================================\n');
fprintf(' exact-state feasibility verdict : %s\n',string(step65Report.verdict));
fprintf(' selected alpha at step 65       : %.3f\n',p.selectedAlpha);
fprintf(' selected-alpha cause             : %s\n',targetCause);
fprintf(' target feature                   : Pnet %.4f | |dPnet| %.4f | headroom %.4f pu\n', ...
    p.targetFeature(1),p.targetFeature(2),p.targetFeature(3));
fprintf(' SoC limits                       : [%.2f, %.2f]\n',SOCmin,SOCmax);
fprintf(' persistent cache                 : %s\n',cacheFile);
fprintf('=============================================================\n\n');

fprintf('Step-65 storage state:\n');
disp(socTable);

fprintf('Reserve-policy fallback attribution through step 65:\n');
disp(fallbackSummary);

fprintf('Last 20 P1 decisions with fallback causes:\n');
disp(last20);

fprintf('State-pressure flags (diagnostic, not proof of causality):\n');
disp(stateFlags);

fprintf('Rolling-horizon terminal-SoC source audit:\n');
fprintf('  builder                         : %s\n',sourceAudit.file);
fprintf('  BESS hard horizon-end lower row : %d\n',sourceAudit.bessHardHorizonEndLower);
fprintf('  EV hard horizon-end pair        : %d\n',sourceAudit.evHardHorizonEndPair);
fprintf('  BESS daily-boundary relaxation  : %d\n',sourceAudit.bessDailyRelaxationPresent);

fprintf('\nInterpretation gate:\n');
if targetCause=="OOD fallback"
    fprintf('  * Step 65 alpha=1 is an OOD safety fallback, NOT a learned full-reserve recommendation.\n');
elseif targetCause=="no-safe-candidate fallback"
    fprintf('  * Step 65 alpha=1 is a no-safe-candidate fallback from the stress model.\n');
else
    fprintf('  * Step 65 alpha=1 came from the normal learned-policy search.\n');
end
if sourceAudit.bessHardHorizonEndLower
    fprintf('  * Current code contains the BESS horizon-end lower terminal row b_SOC(rL(end))=0.\n');
    fprintf('    If BESS SoC/state pressure is significant, the NEXT diagnostic should selectively\n');
    fprintf('    relax terminal-energy rows at the frozen step-65 state to identify the blocking family.\n');
end

%% Lightweight plots
figure('Name','P1 step65 root-cause - SoC and policy causes');
tiledlayout(2,2);
nexttile;
bar(categorical(labels),soc); hold on; yline(SOCmin,'--'); yline(SOCmax,'--'); yline(SOCinit,':');
ylabel('SoC'); title('Step-65 storage SoC'); grid on;
nexttile;
stairs((0:nStep-1)*cfg.mpc.decisionInterval_h,alpha,'LineWidth',1.1); hold on;
scatter((find(ood)-1)*cfg.mpc.decisionInterval_h,alpha(ood),45,'filled');
scatter((find(noSafe)-1)*cfg.mpc.decisionInterval_h,alpha(noSafe),55,'x');
yline(cfg.ai.alphaMin,'--'); yline(cfg.ai.alphaMax,'--'); xline((kT-1)*cfg.mpc.decisionInterval_h,':');
xlabel('Time (h)'); ylabel('\alpha'); title('P1 reserve policy / fallbacks'); grid on;
legend('alpha','OOD','No-safe','Location','best');
nexttile;
plot((0:nStep-1)*cfg.mpc.decisionInterval_h,featureHistory(:,1),'LineWidth',1.0); hold on;
plot((0:nStep-1)*cfg.mpc.decisionInterval_h,featureHistory(:,2),'LineWidth',1.0);
plot((0:nStep-1)*cfg.mpc.decisionInterval_h,featureHistory(:,3),'LineWidth',1.0);
xline((kT-1)*cfg.mpc.decisionInterval_h,':'); grid on; xlabel('Time (h)'); ylabel('p.u.');
legend('Pnet','|dPnet|','DG headroom','Location','best'); title('Causal AI state history');
nexttile;
bar([sum(isFull&ood),sum(isFull&noSafe),sum(isFull&missing),sum(isAdaptiveFull)]);
set(gca,'XTickLabel',{'OOD','No-safe','Missing','Model'}); ylabel('alpha=1 count');
title('Why full reserve was selected'); grid on;

%% Persist derived report
report = struct();
report.kind='IslandEMSStep65StateRootCauseDiagnosticV1';
report.step65=step65Report;
report.socTable=socTable;
report.fallbackSummary=fallbackSummary;
report.last20=last20;
report.stateFlags=stateFlags;
report.targetCause=targetCause;
report.sourceAudit=sourceAudit;
report.cacheFile=cacheFile;
report.timestamp=datestr(now,30);
save(cacheFile,'step65Report','report','-v7.3');

fprintf('\nDerived root-cause report persisted to:\n  %s\n',cacheFile);
fprintf('Nothing was written to formal outputs/.\n');
end

function tf=is_project_root(p)
tf=isfolder(p) && isfolder(fullfile(p,'config')) && isfolder(fullfile(p,'core')) && ...
    exist(fullfile(p,'config','config_island_ems.m'),'file')==2;
end
