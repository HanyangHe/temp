%% Unit check for coneprog diagnostic residual calculations
x=[1;2]; A=[1 0]; b=1.1; Aeq=[0 1]; beq=2; lb=[0;0]; ub=[2;3];
Asc={eye(2)}; bsc={[0;0]}; dsc={[0;0]}; gamma={-3};
out=struct('iterations',4,'primalfeasibility',1e-9,'dualfeasibility',2e-8, ...
    'relativegap',3e-9,'message','synthetic');
d=collect_coneprog_diagnostic(out,-7,3,0.1,x,A,b,Aeq,beq,lb,ub,Asc,bsc,dsc,gamma);
assert(d.exitflag==-7 && d.isMinus7);
assert(d.maxIneqViolation==0 && d.maxEqViolation==0);
assert(d.maxLowerBoundViolation==0 && d.maxUpperBoundViolation==0);
assert(d.maxSOCViolation==0);
fprintf('Solver-diagnostic unit test passed.\n');
