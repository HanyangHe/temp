function report = quick_feature_screening_test(varargin)
%QUICK_FEATURE_SCREENING_TEST Fast feature screening for AI reserve.
%
% Preferred use after a smoke run:
%   report = quick_feature_screening_test();
%
% The smoke test now writes only a tiny feature-screen snapshot to the OS
% temporary folder (NOT outputs/). Therefore this function does not depend on
% fragile MATLAB 'ans' state and does not launch any costly simulation.
%
% Other supported inputs:
%   report = quick_feature_screening_test(fullResultStruct)
%   report = quick_feature_screening_test(snapshotStruct)
%
% If neither a result nor a cached snapshot is available, this function
% returns [] with clear instructions instead of throwing a red MATLAB error.

snapshot = [];
source = '';

% 1) Explicit input is always preferred.
if nargin >= 1 && isstruct(varargin{1})
    x = varargin{1};
    if is_snapshot(x)
        snapshot = x; source = 'explicit snapshot';
    elseif is_full_result(x)
        snapshot = build_feature_screening_snapshot(x); source = 'explicit full result';
    end
end

% 2) Robust base-workspace discovery. Do NOT trust ans blindly.
if isempty(snapshot)
    vars = {'featureScreenSnapshot','lastSmokeResult','result','base'};
    for i=1:numel(vars)
        nm=vars{i};
        if evalin('base',sprintf('exist(''%s'',''var'')',nm))
            x=evalin('base',nm);
            if is_snapshot(x)
                snapshot=x; source=['base variable ' nm]; break;
            elseif is_full_result(x)
                snapshot=build_feature_screening_snapshot(x); source=['base variable ' nm]; break;
            end
        end
    end
end

% 3) Tiny OS-temp cache written by smoke_T7_18bus().
cacheFile = feature_cache_file();
if isempty(snapshot) && isfile(cacheFile)
    S=load(cacheFile,'snapshot');
    if isfield(S,'snapshot') && is_snapshot(S.snapshot)
        snapshot=S.snapshot; source='OS-temp smoke snapshot';
    end
end

if isempty(snapshot)
    fprintf('\nFEATURE SCREENING NOT RUN: no completed smoke snapshot is available.\n');
    fprintf('This test intentionally will NOT start a 20+ minute simulation.\n');
    fprintf('Run once:\n');
    fprintf('  base = smoke_T7_18bus();\n');
    fprintf('Then run:\n');
    fprintf('  report = quick_feature_screening_test(base);\n');
    fprintf('Future smoke runs will also create a tiny cache in tempdir automatically,\n');
    fprintf('so afterwards quick_feature_screening_test() works with no input.\n\n');
    report=[];
    return;
end

cfg=snapshot.cfg;
time_h=snapshot.time_h;
stress=snapshot.target.stress;
peakDf=snapshot.target.peakDf_Hz;
peakRoCoF=snapshot.target.peakRoCoF_Hz_s;
dfLim=snapshot.target.dfLimit_Hz;
rLim=snapshot.target.rocofLimit_Hz_s;
violation=snapshot.target.violation;
featureData=snapshot.features.data;
featureNames=snapshot.features.names;
featureGroup=snapshot.features.group;
featureEligible=snapshot.features.eligible(:);
K=snapshot.K;

fprintf('\n=============================================================\n');
fprintf(' QUICK FIRST-PRINCIPLES FEATURE SCREENING\n');
fprintf('=============================================================\n');
fprintf(' source          : %s\n',source);
fprintf(' case            : %s\n',string(snapshot.meta.caseName));
if isfield(snapshot.meta,'methodID'), fprintf(' method          : %s\n',string(snapshot.meta.methodID)); end
fprintf(' MPC intervals   : %d\n',K);
fprintf(' persistence     : OFF (no formal outputs; no simulation)\n');
fprintf(' target          : max(|df|/limit, |RoCoF|/limit) per interval\n');
fprintf('=============================================================\n');

fprintf('Power-sign sanity check: RMS(Pnet_measured-P_DG)/P_DG,rated = %.4f pu.\n',snapshot.balanceMismatch_pu);
if snapshot.balanceMismatch_pu > 0.35
    warning(['Measured aggregate Pnet reconstruction differs substantially from total DG output. ', ...
        'Prefer forecast-derived Pnet features until sign/accounting is audited.']);
end

% ---------------- Correlation/ranking ------------------------------------
nF=size(featureData,2);
rhoP=nan(nF,1); rhoS=nan(nF,1); rhoDf=nan(nF,1); rhoR=nan(nF,1); sig=nan(nF,1);
for j=1:nF
    x=featureData(:,j);
    sig(j)=std(x,0,'omitnan');
    rhoP(j)=pearson_safe(x,stress);
    rhoS(j)=spearman_safe(x,stress);
    rhoDf(j)=spearman_safe(x,peakDf/dfLim);
    rhoR(j)=spearman_safe(x,peakRoCoF/rLim);
end
score=max(abs([rhoP rhoS rhoDf rhoR]),[],2,'omitnan');
score(~isfinite(score))=0;
Ranking=table(string(featureNames(:)),string(featureGroup(:)),logical(featureEligible),sig, ...
    rhoP,rhoS,rhoDf,rhoR,score, ...
    'VariableNames',{'Feature','Group','AIEligible','Std','PearsonStress','SpearmanStress','SpearmanDf','SpearmanRoCoF','Score'});
Ranking=sortrows(Ranking,'Score','descend');

% Nonredundant physics shortlist.
shortIdx=[];
eligIdx=find(featureEligible & sig>1e-8 & isfinite(score));
[~,ord]=sort(score(eligIdx),'descend'); eligIdx=eligIdx(ord);
for ii=1:numel(eligIdx)
    j=eligIdx(ii);
    if score(j)<0.25, continue; end
    redundant=false;
    for q=shortIdx
        if abs(pearson_safe(featureData(:,j),featureData(:,q)))>0.95
            redundant=true; break;
        end
    end
    if ~redundant, shortIdx(end+1)=j; end %#ok<AGROW>
    if numel(shortIdx)>=8, break; end
end
Shortlist=table(string(featureNames(shortIdx))',score(shortIdx),rhoS(shortIdx), ...
    'VariableNames',{'Feature','Score','SpearmanStress'});

M=snapshot.mechanism;
Mechanism=table( ...
    ["futureRealizedNetRange_pu";"futureRealizedMax1sNetRamp_pu";"futureRealizedNetVsDGImbalance_pu"], ...
    [spearman_safe(M.futureNetRange_pu,stress);spearman_safe(M.futureNetMaxRamp1s_pu,stress);spearman_safe(M.futureNetVsDGImbalance_pu,stress)], ...
    [pearson_safe(M.futureNetRange_pu,stress);pearson_safe(M.futureNetMaxRamp1s_pu,stress);pearson_safe(M.futureNetVsDGImbalance_pu,stress)], ...
    'VariableNames',{'DiagnosticOnly_NotAIInput','SpearmanStress','PearsonStress'});

fprintf('\nTop decision-time feature associations (exploratory one-day screen):\n');
disp(Ranking(1:min(15,height(Ranking)),:));
fprintf('\nPreliminary nonredundant PHYSICS shortlist (Score >= 0.25):\n');
if isempty(shortIdx), fprintf('  No feature passed the current exploratory threshold.\n'); else, disp(Shortlist); end
fprintf('\nFirst-principles mechanism diagnostics (FUTURE REALIZED; never AI inputs):\n');
disp(Mechanism);

fprintf('\nInterpretation rules:\n');
fprintf('  * Prefer Pnet/ramp/headroom variables when similarly ranked.\n');
fprintf('  * Load/PV separately are secondary if Pnet already contains their information.\n');
fprintf('  * timeSin/timeCos are proxy variables, not physical causes.\n');
fprintf('  * H/droop cannot be screened in one day because they are constant.\n');
fprintf('  * This screen ranks association with frequency stress, not final alpha*.\n\n');

% ---------------- Compact diagnostic plots -------------------------------
S=snapshot.states;
figure('Name','AI reserve feature screen - physical states');
tiledlayout(5,1,'TileSpacing','compact');
nexttile; hold on;
plot(time_h,S.netNow_pu,'LineWidth',1.2); plot(time_h,S.loadNow_pu,'LineWidth',0.9); plot(time_h,S.pvNow_pu,'LineWidth',0.9);
ylabel('Power (pu)'); grid on; box on; legend('P_{net}','Load','PV','Location','best'); title('Active-power operating point');
nexttile; hold on;
plot(time_h,S.netRampBack_pu,'LineWidth',1.1,'DisplayName','Measured backward');
j=find(string(featureNames)=="absNetLoadRamp_pu",1); if ~isempty(j), plot(time_h,featureData(:,j),'LineWidth',1.0,'DisplayName','Forecast next'); end
j2=find(string(featureNames)=="maxNetLoadRampHorizon_pu",1); if ~isempty(j2), plot(time_h,featureData(:,j2),'LineWidth',1.0,'DisplayName','Forecast horizon max'); end
ylabel('Ramp (pu)'); grid on; box on; legend('show','Location','best'); title('Net-load variation');
nexttile; hold on;
plot(time_h,S.dgLoading_pu,'LineWidth',1.1); plot(time_h,S.dgUpHeadroom_pu,'LineWidth',1.1);
ylabel('pu'); grid on; box on; legend('DG loading','DG up headroom','Location','best'); title('Synchronous-generation operating margin');
nexttile; hold on;
leg={};
if any(isfinite(S.bessMeanSOC)), plot(time_h,S.bessMeanSOC,'LineWidth',1.1); leg{end+1}='BESS mean SoC'; end %#ok<AGROW>
j=find(string(featureNames)=="evAvailability",1); if ~isempty(j), plot(time_h,featureData(:,j),'LineWidth',1.0); leg{end+1}='EV availability'; end %#ok<AGROW>
ylabel('State'); grid on; box on; if ~isempty(leg), legend(leg,'Location','best'); end; title('Storage / EV state');
nexttile; hold on;
plot(time_h,peakDf/dfLim,'LineWidth',1.0); plot(time_h,peakRoCoF/rLim,'LineWidth',1.0); plot(time_h,stress,'k','LineWidth',1.3); yline(1,'k--');
xlabel('Time (h)'); ylabel('Normalized'); grid on; box on; legend('|df|/limit','|RoCoF|/limit','Stress','Security boundary','Location','best'); title('Realized frequency stress');

if ~isempty(shortIdx)
    nPlot=min(6,numel(shortIdx));
    figure('Name','AI reserve feature screen - top associations');
    tiledlayout(2,3,'TileSpacing','compact');
    for ii=1:nPlot
        j=shortIdx(ii); nexttile;
        scatter(featureData(:,j),stress,18,'filled'); grid on; box on;
        xlabel(strrep(featureNames{j},'_','\_')); ylabel('Frequency stress');
        title(sprintf('|score|=%.2f',score(j)));
    end
end

figure('Name','AI reserve feature screen - mechanism only');
tiledlayout(3,1,'TileSpacing','compact');
nexttile; plot(time_h,M.futureNetRange_pu,'LineWidth',1.1); ylabel('pu'); grid on; box on; title('Future realized net-demand range (diagnostic only)');
nexttile; plot(time_h,M.futureNetMaxRamp1s_pu,'LineWidth',1.1); ylabel('pu/1-s step'); grid on; box on; title('Future realized max 1-s net-demand change (diagnostic only)');
nexttile; plot(time_h,stress,'LineWidth',1.2); hold on; yline(1,'k--'); xlabel('Time (h)'); ylabel('Stress'); grid on; box on; title('Frequency stress');

FeatureTable=array2table(featureData,'VariableNames',matlab.lang.makeValidName(featureNames));
FeatureTable.Time_h=time_h; FeatureTable=movevars(FeatureTable,'Time_h','Before',1);
TargetTable=table(time_h,peakDf,peakRoCoF,stress,violation, ...
    'VariableNames',{'Time_h','PeakAbsDf_Hz','PeakAbsRoCoF_Hz_s','NormalizedStress','Violation'});
report=struct('ranking',Ranking,'shortlist',Shortlist,'mechanism',Mechanism, ...
    'featureTable',FeatureTable,'targetTable',TargetTable, ...
    'balanceMismatch_pu',snapshot.balanceMismatch_pu, ...
    'source',source,'snapshot',snapshot);
end

function f=feature_cache_file()
f=fullfile(tempdir,'IslandEMS_feature_screening_snapshot.mat');
end
function tf=is_snapshot(x)
tf=isstruct(x) && isfield(x,'kind') && strcmp(x.kind,'IslandEMSFeatureScreenSnapshotV1') && isfield(x,'features') && isfield(x,'target');
end
function tf=is_full_result(r)
tf=isstruct(r) && isfield(r,'meta') && isfield(r,'cfgSnapshot') && isfield(r,'freq_Hz') && isfield(r,'P_DG_MW') && isfield(r,'totalLoad_MW');
end
function r=pearson_safe(x,y)
x=x(:); y=y(:); m=isfinite(x)&isfinite(y); x=x(m); y=y(m);
if numel(x)<4 || std(x)==0 || std(y)==0, r=NaN; return; end
x=x-mean(x); y=y-mean(y); r=sum(x.*y)/sqrt(sum(x.^2)*sum(y.^2));
end
function r=spearman_safe(x,y)
x=x(:); y=y(:); m=isfinite(x)&isfinite(y); x=x(m); y=y(m);
if numel(x)<4 || std(x)==0 || std(y)==0, r=NaN; return; end
r=pearson_safe(rank_average(x),rank_average(y));
end
function r=rank_average(x)
[sorted,ord]=sort(x); n=numel(x); rs=zeros(n,1); i=1;
while i<=n
    j=i; while j<n && sorted(j+1)==sorted(i), j=j+1; end
    rr=(i+j)/2; rs(ord(i:j))=rr; i=j+1;
end
r=rs;
end
