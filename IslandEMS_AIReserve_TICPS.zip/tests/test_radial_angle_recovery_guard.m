function test_radial_angle_recovery_guard()
%TEST_RADIAL_ANGLE_RECOVERY_GUARD Static regression test; no simulation.

thisFile = mfilename('fullpath');
projectRoot = fileparts(fileparts(thisFile));
engineFile = fullfile(projectRoot,'core','engine','engine_island_ems.m');

assert(exist(engineFile,'file')==2,'Missing engine_island_ems.m.');
txt = fileread(engineFile);

assert(contains(txt,'if Loops > 0'), ...
    'Radial Loops==0 guard is missing.');
assert(contains(txt,'Angle-recovery loop audit skipped:'), ...
    'Radial angle-recovery skip marker is missing.');
assert(contains(txt,'MaxAngleErrorAllLoopInDay=NaN;') && ...
       contains(txt,'MaxMagErrorAllLoopInDay=NaN;'), ...
    'Radial N/A diagnostics are not explicitly defined.');

callLine = 'BranchIndexAndSign=LoopBranchDirectSign(LineBFM,loopNodes,Loops);';
idxCall = strfind(txt,callLine);
idxGuard = strfind(txt,'if Loops > 0');
assert(numel(idxCall)==1, ...
    'Expected exactly one LoopBranchDirectSign call after patching.');
assert(any(idxGuard < idxCall), ...
    'LoopBranchDirectSign is not protected by a preceding Loops>0 guard.');

cfg = config_island_ems();
assert(~cfg.network.allowMeshedCases, ...
    'Current formal study is expected to remain radial-only.');

fprintf(['Radial angle-recovery guard test passed: radial Loops==0 skips ', ...
    'the legacy mesh audit and keeps diagnostics defined.\n']);
end
