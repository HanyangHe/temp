%% smoke_P1_forecast_shield_refinement_18bus.m
% NO-SIMULATION refinement test for the P1 post-KRR safety shield.
%
% This test keeps the current conclusions in view:
%
%   (1) The present KRR decision is based on the current 3-state feature
%       vector and does not itself guarantee the next closed-loop frequency
%       response.
%
%   (2) The current global calibration offset is not a sufficient safety
%       mechanism.  We therefore screen a lightweight POST-KRR correction.
%
%   (3) Directional net-load information is promising.  However, the previous
%       test used next SAVED states as a diagnostic proxy.  The production
%       method must instead use forecast-available information that exists
%       BEFORE the MPC solve.
%
% What this script does
% ---------------------
% A. Re-check ALL CoI-unsafe P1 intervals and print the Step-89 neighborhood.
%
% B. Reconstruct the current selector's KRR decision stress at the SAVED alpha.
%
% C. Screen SPARSER candidate shield triggers based on:
%       signed net-load drop proxy
%       + current alpha < 1
%       + absolute ramp
%       + KRR decision stress
%       + current net-load level
%
%    The objective is:
%       zero missed CoI-unsafe intervals,
%       then minimum trigger count,
%       then minimum mean corrected alpha.
%
% D. Audit the actual source code around build_reserve_features() and the
%    engine call so we can verify what forecast quantities are available
%    online before implementing a leakage-free signed forecast ramp.
%
% IMPORTANT
% ---------
% NO MPC solve.
% NO physical simulation.
% NO production-code modification.
%
% The signed next-state change used here is still only a DIAGNOSTIC PROXY:
%
%     netLoadNow(k+1) - netLoadNow(k)
%
% It must NOT be copied directly into production logic.  The source audit at
% the end tells us where to replace it with the decision-time forecast version.

clear;
clc;

%% User options
FORMAL_RUN_TAG = '20260907_115951';
EXPORT_CSV = true;

% Neighborhoods to display.
MORNING_WINDOW = 27:35;
LATE_WINDOW    = 85:92;

% Sparse shield search grids.
dropGrid   = 0.02:0.01:0.14;       % trigger if signed change <= -drop
rampGrid   = 0.06:0.01:0.18;
stressGrid = 0.30:0.05:0.95;
netGrid    = 0.20:0.05:1.00;

TOP_N = 40;

%% Setup
projectRoot = pwd;
addpath(genpath(projectRoot));
rehash;

cfg = config_island_ems();

caseName   = '18bus';
decayRatio = 1.00;
seed       = 0;

runRoot = fullfile(projectRoot,cfg.output.root,FORMAL_RUN_TAG);
assert(exist(runRoot,'dir')==7,'Formal run folder not found: %s',runRoot);

%% Load saved P1 and F1
p1File = find_one_result_local( ...
    fullfile(runRoot,'P1'),caseName,decayRatio,seed);

f1File = find_one_result_local( ...
    fullfile(runRoot,'T7'),caseName,decayRatio,seed);

P1 = load_result_local(p1File);
F1 = load_result_local(f1File);

assert(isfield(P1,'reserve') && isfield(P1.reserve,'features'), ...
    'P1 result.reserve.features missing.');
assert(isfield(P1.reserve,'ratio'), ...
    'P1 result.reserve.ratio missing.');
assert(isfield(P1,'interval'), ...
    'P1 result.interval missing.');

%% Exact saved AI configuration/model
if isfield(P1,'cfgSnapshot') && isfield(P1.cfgSnapshot,'ai')
    aiCfg = P1.cfgSnapshot.ai;
else
    aiCfg = cfg.ai;
end

if isfield(P1,'cfgSnapshot') && isfield(P1.cfgSnapshot,'frequency')
    freqCfg = P1.cfgSnapshot.frequency;
else
    freqCfg = cfg.frequency;
end

if isfield(P1,'cfgSnapshot') && isfield(P1.cfgSnapshot,'mpc') && ...
        isfield(P1.cfgSnapshot.mpc,'decisionInterval_h')
    dt_h = double(P1.cfgSnapshot.mpc.decisionInterval_h);
else
    dt_h = double(cfg.mpc.decisionInterval_h);
end

modelFile = fullfile(projectRoot, ...
    char(aiCfg.modelRoot),caseName,char(aiCfg.modelFileName));

if exist(modelFile,'file')~=2
    modelFile = fullfile(projectRoot, ...
        char(aiCfg.modelRoot),char(aiCfg.modelFileName));
end

assert(exist(modelFile,'file')==2,'AI model not found: %s',modelFile);

M = load(modelFile);
assert(isfield(M,'model'),'AI model MAT lacks variable model.');
model = M.model;

%% Feature ordering
X = double(P1.reserve.features);
alphaSaved = double(P1.reserve.ratio(:));
n = size(X,1);

assert(numel(alphaSaved)==n,'Feature/alpha length mismatch.');

if isfield(P1.reserve,'featureNames')
    featureNames = string(P1.reserve.featureNames);
else
    featureNames = string(model.stateFeatureNames);
end

iNet  = find(featureNames=="netLoadNow_pu",1);
iRamp = find(featureNames=="absNetLoadRamp_pu",1);
iHead = find(featureNames=="dgUpHeadroom_pu",1);

assert(~isempty(iNet) && ~isempty(iRamp) && ~isempty(iHead), ...
    'Frozen 3-feature ordering not found.');

netNow   = X(:,iNet);
absRamp  = X(:,iRamp);
headroom = X(:,iHead);

%% Exact current calibrated selector replay
aiReplay = aiCfg;
aiReplay.useSafetyCalibration = true;

[alphaReplay,d] = select_reserve_alpha_batch(model,X,aiReplay,true);
alphaReplay = double(alphaReplay(:));

assert(all(abs(alphaReplay-alphaSaved)<=1e-12), ...
    'Selector replay does not reproduce saved P1 alpha.');

alphaGrid = double(d.alphaGrid(:).');
decisionCurve = double(d.decisionStress);
rawCurve = double(d.rawStress);

decisionStress = nan(n,1);
rawStress = nan(n,1);

for k = 1:n
    j = find(abs(alphaGrid-alphaSaved(k))<1e-12,1);
    if ~isempty(j)
        decisionStress(k) = decisionCurve(k,j);
        rawStress(k) = rawCurve(k,j);
    end
end

%% Actual saved CoI safety
df = double(P1.interval.maxAbsFreqDev_Hz(:));
rocof = double(P1.interval.maxAbsRoCoF_Hz_s(:));

dfLim = double(freqCfg.securityDeviation_Hz);
rocofLim = double(freqCfg.securityRoCoF_Hz_s);

actualStress = max(df/dfLim,rocof/rocofLim);
coiUnsafe = actualStress > 1+1e-12;

unsafeSteps = find(coiUnsafe);

%% F1 same-step safety reference
f1df = double(F1.interval.maxAbsFreqDev_Hz(:));
f1rocof = double(F1.interval.maxAbsRoCoF_Hz_s(:));
f1Safe = f1df<=dfLim+1e-12 & f1rocof<=rocofLim+1e-12;

%% Diagnostic directional proxy
% NOTE: future SAVED state, diagnostic only.
netNext = [netNow(2:end); NaN];
signedNetChangeProxy = netNext-netNow;
dropMagnitudeProxy = -signedNetChangeProxy;  % positive when net load drops

step = (1:n).';
time_h = (step-1)*dt_h;

stepTable = table( ...
    step,time_h,alphaSaved, ...
    netNow,absRamp,headroom, ...
    signedNetChangeProxy,dropMagnitudeProxy, ...
    rawStress,decisionStress, ...
    df,rocof,actualStress,coiUnsafe,f1Safe, ...
    'VariableNames',{ ...
    'MPCStep','StartTime_h','SavedAlpha', ...
    'NetLoadNow_pu','AbsNetLoadRamp_pu','DGUpHeadroom_pu', ...
    'SignedNetChangeProxy_pu','NetDropMagnitudeProxy_pu', ...
    'RawKRRStressAtSavedAlpha','DecisionStressAtSavedAlpha', ...
    'ActualMaxAbsDf_Hz','ActualMaxAbsRoCoF_Hz_s', ...
    'ActualSecurityStress','CoIUnsafe','F1SafeSameStep'});

fprintf('\n=============================================================\n');
fprintf(' P1 FORECAST-SHIELD REFINEMENT -- NO SIMULATION\n');
fprintf('=============================================================\n');
fprintf('P1 result    : %s\n',p1File);
fprintf('F1 result    : %s\n',f1File);
fprintf('CoI unsafe   : %s\n',mat2str(unsafeSteps.'));
fprintf('Current mean alpha = %.6f\n',mean(alphaSaved));
fprintf('=============================================================\n');

%% A. Show every unsafe interval
fprintf('\n=============================================================\n');
fprintf(' A. ALL CURRENT P1 CoI-UNSAFE INTERVALS\n');
fprintf('=============================================================\n');
disp(stepTable(coiUnsafe,:));

%% Step-89 neighborhood
fprintf('\n=============================================================\n');
fprintf(' B. MORNING NEIGHBORHOOD\n');
fprintf('=============================================================\n');
disp(stepTable(MORNING_WINDOW,:));

fprintf('\n=============================================================\n');
fprintf(' C. STEP-89 / LATE-DAY NEIGHBORHOOD\n');
fprintf('=============================================================\n');
disp(stepTable(LATE_WINDOW,:));

%% ------------------------------------------------------------------------
% D. Sparse post-KRR shield screening
% -------------------------------------------------------------------------
%
% Every trigger below is additionally conditioned on alphaSaved < 1.
% This encodes a natural post-KRR policy:
%
%     if KRR already chose alpha=1, do nothing.
%     otherwise the shield may increase alpha to 1.
%
% We are screening DETECTION only.  Exact physical safety must later be
% verified by the P1-only closed-loop smoke test.

isReducedReserve = alphaSaved < 1-1e-12;

rules = table();

% Baseline.
rules = append_rule_local( ...
    rules,"BASE","Current P1",false(n,1), ...
    alphaSaved,coiUnsafe,f1Safe,NaN,NaN,NaN,NaN);

% 1. Signed drop + reduced reserve.
for dth = dropGrid
    trig = isReducedReserve & dropMagnitudeProxy>=dth;
    trig(end)=false;

    rules = append_rule_local( ...
        rules,"DROP_ALPHA", ...
        sprintf('alpha<1 AND netDrop >= %.3f',dth), ...
        trig,alphaSaved,coiUnsafe,f1Safe,dth,NaN,NaN,NaN);
end

% 2. Signed drop + absolute ramp + reduced reserve.
for dth = dropGrid
    for r = rampGrid
        trig = isReducedReserve & ...
               dropMagnitudeProxy>=dth & absRamp>=r;
        trig(end)=false;

        rules = append_rule_local( ...
            rules,"DROP_RAMP_ALPHA", ...
            sprintf('alpha<1 AND drop>=%.3f AND ramp>=%.3f',dth,r), ...
            trig,alphaSaved,coiUnsafe,f1Safe,dth,r,NaN,NaN);
    end
end

% 3. Signed drop + KRR decision-stress floor + reduced reserve.
for dth = dropGrid
    for s = stressGrid
        trig = isReducedReserve & ...
               dropMagnitudeProxy>=dth & decisionStress>=s;
        trig(end)=false;

        rules = append_rule_local( ...
            rules,"DROP_KRR_ALPHA", ...
            sprintf('alpha<1 AND drop>=%.3f AND KRRstress>=%.3f',dth,s), ...
            trig,alphaSaved,coiUnsafe,f1Safe,dth,NaN,s,NaN);
    end
end

% 4. Signed drop + ramp + KRR stress.
for dth = dropGrid
    for r = rampGrid
        for s = stressGrid
            trig = isReducedReserve & ...
                   dropMagnitudeProxy>=dth & ...
                   absRamp>=r & ...
                   decisionStress>=s;
            trig(end)=false;

            rules = append_rule_local( ...
                rules,"DROP_RAMP_KRR_ALPHA", ...
                sprintf(['alpha<1 AND drop>=%.3f AND ramp>=%.3f ', ...
                         'AND KRRstress>=%.3f'],dth,r,s), ...
                trig,alphaSaved,coiUnsafe,f1Safe,dth,r,s,NaN);
        end
    end
end

% 5. Signed drop + current net-load level.
for dth = dropGrid
    for q = netGrid
        trig = isReducedReserve & ...
               dropMagnitudeProxy>=dth & netNow>=q;
        trig(end)=false;

        rules = append_rule_local( ...
            rules,"DROP_NET_ALPHA", ...
            sprintf('alpha<1 AND drop>=%.3f AND netNow>=%.3f',dth,q), ...
            trig,alphaSaved,coiUnsafe,f1Safe,dth,NaN,NaN,q);
    end
end

% 6. Signed drop + (ramp OR KRR risk) + reduced reserve.
for dth = dropGrid
    for r = rampGrid
        for s = stressGrid
            trig = isReducedReserve & ...
                   dropMagnitudeProxy>=dth & ...
                   (absRamp>=r | decisionStress>=s);
            trig(end)=false;

            rules = append_rule_local( ...
                rules,"DROP_RAMP_OR_KRR_ALPHA", ...
                sprintf(['alpha<1 AND drop>=%.3f AND ', ...
                         '(ramp>=%.3f OR KRRstress>=%.3f)'],dth,r,s), ...
                trig,alphaSaved,coiUnsafe,f1Safe,dth,r,s,NaN);
        end
    end
end

%% Rank zero-miss rules
rules = sortrows(rules, ...
    {'MissedUnsafe','TriggerCount','MeanCorrectedAlpha','FalseTriggerCount'}, ...
    {'ascend','ascend','ascend','ascend'});

zeroMiss = rules(rules.MissedUnsafe==0,:);

fprintf('\n=============================================================\n');
fprintf(' D. TOP SPARSE ZERO-MISS SHIELD CANDIDATES\n');
fprintf('=============================================================\n');

if isempty(zeroMiss)
    fprintf('No zero-miss rule found in the screened family.\n');
else
    disp(zeroMiss(1:min(TOP_N,height(zeroMiss)),:));
end

%% Best by family
fprintf('\n=============================================================\n');
fprintf(' E. BEST ZERO-MISS RULE BY FAMILY\n');
fprintf('=============================================================\n');

families = unique(rules.RuleFamily,'stable');
best = table();

for i = 1:numel(families)
    T = rules(rules.RuleFamily==families(i) & rules.MissedUnsafe==0,:);
    if isempty(T)
        continue;
    end

    if isempty(best)
        best = T(1,:);
    else
        best = [best;T(1,:)]; %#ok<AGROW>
    end
end

disp(best);

%% Show trigger steps for top candidate
fprintf('\n=============================================================\n');
fprintf(' F. TOP CANDIDATE TRIGGER STEPS\n');
fprintf('=============================================================\n');

if ~isempty(zeroMiss)

    top = zeroMiss(1,:);

    trigTop = reproduce_trigger_local( ...
        top.RuleFamily,top.ParamDrop,top.ParamRamp, ...
        top.ParamStress,top.ParamNet, ...
        isReducedReserve,dropMagnitudeProxy,absRamp, ...
        decisionStress,netNow);

    triggerTable = stepTable(trigTop,:);

    fprintf('Top rule:\n  %s\n',top.Description);
    fprintf('Trigger steps: %s\n',mat2str(find(trigTop).'));
    disp(triggerTable);
else
    triggerTable = table();
end

%% ------------------------------------------------------------------------
% G. Source audit: can signed forecast net-load change be built before solve?
% -------------------------------------------------------------------------

fprintf('\n=============================================================\n');
fprintf(' G. build_reserve_features.m SOURCE AUDIT\n');
fprintf('=============================================================\n');

featureFile = which('build_reserve_features');

if isempty(featureFile)
    fprintf('<build_reserve_features.m not found on MATLAB path>\n');
else
    print_source_file_local(featureFile,160);
end

fprintf('\n=============================================================\n');
fprintf(' H. ENGINE CALL SITE AROUND build_reserve_features()\n');
fprintf('=============================================================\n');

engineFile = which('engine_island_ems');

if isempty(engineFile)
    % which() can fail for package/path layouts; try known project path.
    candidate = fullfile(projectRoot,'core','engine','engine_island_ems.m');
    if exist(candidate,'file')==2
        engineFile = candidate;
    end
end

if isempty(engineFile)
    fprintf('<engine_island_ems.m not found>\n');
else
    print_context_around_token_local( ...
        engineFile,'build_reserve_features',45);
end

fprintf('\n=============================================================\n');
fprintf(' I. SOURCE AUDIT FOR Sload / P_PV AROUND AI DECISION\n');
fprintf('=============================================================\n');

if ~isempty(engineFile)
    print_context_around_token_local(engineFile,'dgUpHeadroom_pu',55);
end

%% Export
if EXPORT_CSV

    outDir = fullfile(runRoot,'diagnostics', ...
        'P1_forecast_shield_refinement');

    if ~exist(outDir,'dir')
        mkdir(outDir);
    end

    writetable(stepTable, ...
        fullfile(outDir,'per_step_diagnostics.csv'));

    writetable(rules, ...
        fullfile(outDir,'all_sparse_shield_rules.csv'));

    writetable(zeroMiss, ...
        fullfile(outDir,'zero_miss_sparse_shield_rules.csv'));

    if ~isempty(best)
        writetable(best, ...
            fullfile(outDir,'best_zero_miss_by_family.csv'));
    end

    if exist('triggerTable','var') && ~isempty(triggerTable)
        writetable(triggerTable, ...
            fullfile(outDir,'top_candidate_trigger_steps.csv'));
    end

    fprintf('\nDiagnostics exported to:\n  %s\n',outDir);
end

fprintf('\n=============================================================\n');
fprintf(' WHAT TO SEND BACK\n');
fprintf('=============================================================\n');
fprintf(['Please send:\n', ...
    '  1) ALL CURRENT P1 CoI-UNSAFE INTERVALS;\n', ...
    '  2) STEP-89 / LATE-DAY NEIGHBORHOOD;\n', ...
    '  3) TOP SPARSE ZERO-MISS SHIELD CANDIDATES;\n', ...
    '  4) BEST ZERO-MISS RULE BY FAMILY;\n', ...
    '  5) TOP CANDIDATE TRIGGER STEPS;\n', ...
    '  6) build_reserve_features.m SOURCE AUDIT;\n', ...
    '  7) ENGINE CALL SITE around build_reserve_features().\n']);
fprintf('=============================================================\n');


%% =========================================================================
% Local helpers
% =========================================================================

function T = append_rule_local( ...
    T,family,description,trig,alphaBase,unsafe,f1Safe, ...
    pDrop,pRamp,pStress,pNet)

trig = logical(trig(:));
unsafe = logical(unsafe(:));

correctedAlpha = alphaBase(:);
correctedAlpha(trig) = 1.0;

nUnsafe = nnz(unsafe);
captured = nnz(trig & unsafe);
missed = nnz(~trig & unsafe);
falseTrig = nnz(trig & ~unsafe);
triggerCount = nnz(trig);

if nUnsafe>0
    captureRate = captured/nUnsafe;
else
    captureRate = NaN;
end

if triggerCount>0
    f1SafeRate = mean(double(f1Safe(trig)));
else
    f1SafeRate = NaN;
end

one = table();
one.RuleFamily = string(family);
one.Description = string(description);
one.TriggerCount = triggerCount;
one.CapturedUnsafe = captured;
one.MissedUnsafe = missed;
one.CaptureRate = captureRate;
one.FalseTriggerCount = falseTrig;
one.MeanOriginalAlpha = mean(alphaBase,'omitnan');
one.MeanCorrectedAlpha = mean(correctedAlpha,'omitnan');
one.MeanAlphaIncrease = one.MeanCorrectedAlpha-one.MeanOriginalAlpha;
one.F1SafeOnTriggeredRate = f1SafeRate;
one.ParamDrop = pDrop;
one.ParamRamp = pRamp;
one.ParamStress = pStress;
one.ParamNet = pNet;

if isempty(T)
    T = one;
else
    T = [T;one]; %#ok<AGROW>
end
end


function trig = reproduce_trigger_local( ...
    family,pDrop,pRamp,pStress,pNet, ...
    reduced,dropMag,ramp,stress,netNow)

family = string(family);
trig = false(size(reduced));

switch family

    case "DROP_ALPHA"
        trig = reduced & dropMag>=pDrop;

    case "DROP_RAMP_ALPHA"
        trig = reduced & dropMag>=pDrop & ramp>=pRamp;

    case "DROP_KRR_ALPHA"
        trig = reduced & dropMag>=pDrop & stress>=pStress;

    case "DROP_RAMP_KRR_ALPHA"
        trig = reduced & dropMag>=pDrop & ramp>=pRamp & stress>=pStress;

    case "DROP_NET_ALPHA"
        trig = reduced & dropMag>=pDrop & netNow>=pNet;

    case "DROP_RAMP_OR_KRR_ALPHA"
        trig = reduced & dropMag>=pDrop & ...
            (ramp>=pRamp | stress>=pStress);

    otherwise
        error('Unknown rule family: %s',family);
end

trig(end)=false;
end


function filePath = find_one_result_local(methodDir,caseName,decayRatio,seed)

decayCode = round(100*decayRatio);

pattern = sprintf('%s_*_decay%03d_seed%03d_*.mat', ...
    caseName,decayCode,seed);

hits = dir(fullfile(methodDir,pattern));

assert(~isempty(hits), ...
    'No saved result found in %s matching %s.',methodDir,pattern);

assert(numel(hits)==1, ...
    'Expected one matching result in %s; found %d.', ...
    methodDir,numel(hits));

filePath = fullfile(hits(1).folder,hits(1).name);
end


function result = load_result_local(filePath)

S = load(filePath);

if isfield(S,'result') && isstruct(S.result)
    result = S.result;
    return;
end

names = fieldnames(S);

for k = 1:numel(names)
    x = S.(names{k});
    if isstruct(x) && (isfield(x,'summary') || isfield(x,'reserve'))
        result = x;
        return;
    end
end

error('Could not identify result struct in %s.',filePath);
end


function print_source_file_local(filePath,maxLines)

fprintf('File: %s\n\n',filePath);

txt = fileread(filePath);
lines = splitlines(string(txt));

n = min(numel(lines),maxLines);

for k = 1:n
    fprintf('%4d | %s\n',k,lines(k));
end

if numel(lines)>n
    fprintf('... (%d additional lines not printed)\n',numel(lines)-n);
end
end


function print_context_around_token_local(filePath,token,halfWindow)

txt = fileread(filePath);
lines = splitlines(string(txt));

idx = find(contains(lower(lines),lower(string(token))));

if isempty(idx)
    fprintf('Token "%s" not found in %s\n',token,filePath);
    return;
end

% Print the first production-relevant hit.
k0 = idx(1);
lo = max(1,k0-halfWindow);
hi = min(numel(lines),k0+halfWindow);

fprintf('File: %s\n',filePath);
fprintf('Token "%s" first hit at line %d\n\n',token,k0);

for k = lo:hi
    marker = ' ';
    if k==k0
        marker = '>';
    end
    fprintf('%s %4d | %s\n',marker,k,lines(k));
end
end
