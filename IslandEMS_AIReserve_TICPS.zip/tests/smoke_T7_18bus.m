function result = smoke_T7_18bus()
%SMOKE_T7_18BUS Full integration smoke test (NOT a paper experiment).
%
% Configuration:
%   method  : T7
%   case    : 18bus
%   day     : Unusual day
%   decay   : 1.00
%   seed    : 0
%
% IMPORTANT:
%   This test is intentionally non-persistent. It does NOT create a folder,
%   MAT file, manifest, CSV, or figure under outputs/. The returned result
%   exists only in MATLAB memory and disappears when cleared.
%
% From the project root, use:
%   addpath(genpath(pwd));
%   result = smoke_T7_18bus();
% You may also open this function in the MATLAB Editor and click Run.

clc;

% This file lives in <projectRoot>/tests/, so moving it from the root does
% not break project discovery.
thisFile = mfilename('fullpath');
projectRoot = fileparts(fileparts(thisFile));

% Fallbacks for unusual Editor/path execution states.
if ~is_project_root(projectRoot)
    candidate = pwd;
    if is_project_root(candidate)
        projectRoot = candidate;
    else
        cfgHit = which('config_island_ems');
        if ~isempty(cfgHit)
            candidate = fileparts(fileparts(cfgHit));
            if is_project_root(candidate)
                projectRoot = candidate;
            end
        end
    end
end

if ~is_project_root(projectRoot)
    error(['Cannot locate the IslandEMS project root. Run this file from ', ...
        '<projectRoot>/tests or set MATLAB Current Folder to the project root.']);
end

addpath(genpath(projectRoot));

cfg = config_island_ems();

% --- Smoke-test overrides -------------------------------------------------
cfg.experiment.systemCases    = {'18bus'};
cfg.scenario.dayType          = 'Unusual day';
cfg.scenario.decayRatios      = 1.00;
cfg.experiment.randomSeeds    = 0;
cfg.experiment.enabledMethods = {'T7'};

% --- Strict no-persistence policy for informal tests ----------------------
cfg.output.saveResults    = false;
cfg.output.showFigures    = false;
cfg.output.exportFigures  = false;
cfg.output.writeSummaryCSV = false;
% runTag is intentionally irrelevant because saveResults=false.
cfg.output.runTag = 'DO_NOT_SAVE_SMOKE_TEST';
% Visible lightweight progress for the long 96-stage diagnostic run.
cfg.diagnostics.progress.enabled = true;
cfg.diagnostics.progress.everyN = 1;
% Audit full manual cone residuals only for the first three -7 warnings;
% native coneprog feasibility/gap metrics are still captured for all 96 solves.
cfg.diagnostics.solver.manualResidualMaxWarningSteps = 3;

validate_config(cfg);

fprintf('\nT7 integration smoke test (in-memory only):\n');
fprintf('  projectRoot : %s\n',projectRoot);
fprintf('  method      : T7\n');
fprintf('  case        : 18bus\n');
fprintf('  dayType     : %s\n',cfg.scenario.dayType);
fprintf('  decay       : %.2f\n',cfg.scenario.decayRatios);
fprintf('  seed        : %d\n',cfg.experiment.randomSeeds);
fprintf('  saveResults : false (nothing will be written to outputs/)\n');
fprintf('  MPC decision: %.2f h (%g min)\n',cfg.mpc.decisionInterval_h,60*cfg.mpc.decisionInterval_h);
fprintf('  MPC predStep: %.2f h (%g min)\n',cfg.mpc.predictionStep_h,60*cfg.mpc.predictionStep_h);
fprintf('  MPC horizon : %.1f h / %d stages\n',cfg.mpc.horizon_h,cfg.mpc.predictionHorizon);
fprintf('  updates/day : %d\n',cfg.mpc.decisionLevelSteps);
fprintf('  forecast nat: %.1f h anchors -> %g-min MPC grid\n', ...
    cfg.forecast.nativeStep_h,60*cfg.mpc.predictionStep_h);
fprintf('  reserve df  : %.2f Hz (EMS design)\n',cfg.frequency.reserveDeviation_Hz);
fprintf('  security df : %.2f Hz (physical criterion)\n',cfg.frequency.securityDeviation_Hz);
rpu=max(cfg.frequency.reserveDeviation_Hz/(cfg.frequency.droop_pu*cfg.frequency.nominal_Hz), ...
        2*cfg.frequency.H_s*cfg.frequency.reserveRoCoF_Hz_s/cfg.frequency.nominal_Hz);
fprintf('  alpha=1 reserve for 140-kW DG: %.3f kW\n\n',140*rpu);

results = run_experiments(cfg,projectRoot);
if numel(results) ~= 1
    error('Smoke test expected exactly one result, but received %d.',numel(results));
end
result = results{1};

% Create a TINY feature-screening cache in the operating-system temp folder.
% This is NOT a formal simulation result and nothing is written under outputs/.
% It contains only 96-row decision-time/interval summaries needed by
% quick_feature_screening_test, so later screening takes only seconds.
try
    snapshot = build_feature_screening_snapshot(result);
    cacheFile = fullfile(tempdir,'IslandEMS_feature_screening_snapshot.mat');
    save(cacheFile,'snapshot','-v7');
    assignin('base','featureScreenSnapshot',snapshot);
    fprintf('\nFeature-screen snapshot cached outside outputs/: %s\n',cacheFile);
catch ME
    warning('Smoke test completed, but lightweight feature-screen snapshot could not be cached: %s',ME.message);
end

fprintf('\nSmoke-test summary (not saved):\n');
disp(struct2table(result.summary));
% Explicit coneprog -7 audit.  This is diagnostic only and is not saved.
print_solver_diagnostics(result,cfg);

% Show a compact set of key physical/optimization plots selected from the
% original main-study diagnostics. Figures remain in memory only.
if cfg.diagnostics.showSmokePlots
    plot_diagnostic_result(result,cfg);
end

if isfield(result,'performance')
    fprintf('\nRuntime breakdown (not saved):\n');
    fprintf('  static SOCP preparation    : %.3f s (cache reused=%d)\n', ...
        result.performance.staticStructureBuild_s,result.performance.staticCacheReused);
    fprintf('  coneprog solve total       : %.3f s\n',result.performance.coneSolveTotal_s);
    fprintf('  decision setup/postprocess : %.3f s\n',result.performance.decisionSetupPost_s);
    fprintf('    forecast construction    : %.3f s\n',result.performance.forecastBuildTotal_s);
    fprintf('    dynamic assembly        : %.3f s\n',result.performance.dynamicAssemblyTotal_s);
    fprintf('    postprocess/unpack      : %.3f s\n',result.performance.postprocessTotal_s);
    fprintf('  physical loop + recording  : %.3f s\n',result.performance.physicalLoopRecord_s);
    fprintf('  total coupled runtime      : %.3f s\n',result.performance.totalCoupledRuntime_s);
end
fprintf('Smoke test completed. No result files were created.\n');
end

function tf = is_project_root(p)
tf = isfolder(fullfile(p,'config')) && ...
     isfolder(fullfile(p,'core')) && ...
     isfolder(fullfile(p,'data')) && ...
     isfolder(fullfile(p,'tests')) && ...
     isfile(fullfile(p,'config','config_island_ems.m')) && ...
     isfile(fullfile(p,'core','engine','engine_island_ems.m'));
end
