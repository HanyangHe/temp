BESS TRANSITION BRIDGE TEST V1
==============================

Inspection conclusion
---------------------
The final 33-bus case has:
- no stationary GFM BESS;
- four stationary GFL BESS units:
    [0.20, 0.15, 0.15, 0.15] MW
  total = 0.65 MW;
- positive Pbatt = discharge/injection;
- negative Pbatt = charging/absorption;
- SoC range = [0.20, 0.90].

The prior 4.5-s DG Pref smoothing changed the F1 result by 0.000%.
Therefore this test leaves the DG command untouched and uses a common
fast-BESS feedforward bridge for the scheduled DG step.

Corrector
---------
Tc = 3*Tg = 4.5 s
gamma(t) = 1 - (3*x^2 - 2*x^3)

dP_BESS,total = gamma(t) * sum(P_DG,new - P_DG,previous)

The support is allocated across stationary BESS units by available
directional power headroom, with BESS power and SoC bounds enforced.

This uses no method-specific information and no security-result feedback.

Files
-----
tests/
  test_F1_33bus_BESS_transition_bridge_v1.m
tools/
  restore_BESS_transition_bridge_engine_v1.m

Run preflight
-------------
clear functions
rehash
addpath(genpath(pwd))
Rpre = test_F1_33bus_BESS_transition_bridge_v1(pwd,false);

Only if PASS:
-------------
Rbess = test_F1_33bus_BESS_transition_bridge_v1(pwd,true);

Expected cost
-------------
Approximately one normal 33-bus case (~50-55 minutes).

Emergency restore
-----------------
Only if MATLAB/Windows is force-killed while the temporary patch is active:

Rrestore = restore_BESS_transition_bridge_engine_v1(pwd);

Do not tune Tc after seeing the result. If this common physical bridge does
not materially improve F1, stop rather than searching event-specific
parameters.
