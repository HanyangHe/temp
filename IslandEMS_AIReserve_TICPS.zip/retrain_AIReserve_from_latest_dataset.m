%% Retrain/recalibrate GRID-SPECIFIC response model(s) from canonical datasets
% No physical simulations are launched. One reusable model is written per grid.
clear; clc;
projectRoot=fileparts(mfilename('fullpath'));
addpath(genpath(projectRoot));

cfg=config_island_ems(); validate_config(cfg);
caseNames=string(cfg.ai.response.systemCases);
for ic=1:numel(caseNames)
    caseName=char(caseNames(ic));
    [dataset,foundFile,msg]=find_latest_compatible_response_dataset(projectRoot,cfg,caseName);
    if isempty(dataset)
        warning('[%s] No compatible response dataset found: %s',caseName,msg);
        continue
    end

    datasetFile=publish_ai_reserve_dataset(projectRoot,cfg,caseName,dataset,foundFile);
    model=train_reserve_krr(dataset,cfg.ai);
    model.caseName=caseName;
    model.trainingSignature=ai_reserve_model_signature(cfg,caseName);
    model.datasetFile=datasetFile;
    modelFile=get_ai_reserve_model_file(projectRoot,cfg,caseName);
    modelDir=fileparts(modelFile); if ~exist(modelDir,'dir'), mkdir(modelDir); end
    save(modelFile,'model','datasetFile','-v7.3');
    fprintf('[%s] Retrained response model from canonical dataset:\n  %s\nSaved model:\n  %s\n', ...
        caseName,datasetFile,modelFile);
end
