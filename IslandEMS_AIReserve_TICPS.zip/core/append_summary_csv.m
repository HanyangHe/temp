function append_summary_csv(fileName,s)
%APPEND_SUMMARY_CSV Append one summary row safely.
T=struct2table(s,'AsArray',true);
if exist(fileName,'file')
    writetable(T,fileName,'WriteMode','append','WriteVariableNames',false);
else
    writetable(T,fileName);
end
end
