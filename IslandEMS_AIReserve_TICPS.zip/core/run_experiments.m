function results = run_experiments(cfg,projectRoot)
%RUN_EXPERIMENTS Execute selected experiments.
%
% Full formal-paper scheduling:
%   Part I  : A0,T7,G1,P1U,P1 @ decay=1.00 only
%   Part II : C0,C1,P1 @ decay=[0.20 0.40 0.60 0.80 1.00]
%
% A full fresh formal grid therefore contains 19 unique method/decay pairs.
%
% For the current 18-bus transition from the old P1 to the final guarded P1,
% use scripts/run_18bus_final_P1_required_recommended_reruns.m instead; that
% incremental runner executes only the 16 required/recommended rows and
% reuses unaffected A0/T7/G1@1 baselines.

catalog = paper_method_catalog();
methodIDs = string({catalog.id});

selectedRaw = string(cfg.experiment.enabledMethods);
selected = unique(selectedRaw,'stable');

unknown = setdiff(selected,methodIDs);
if ~isempty(unknown)
    error('Unknown method IDs: %s',strjoin(unknown,', '));
end

saveResults = true;
if isfield(cfg,'output') && isfield(cfg.output,'saveResults')
    saveResults = logical(cfg.output.saveResults);
end

paperStudies = struct();
if isfield(cfg,'experiment') && isfield(cfg.experiment,'paperStudies')
    paperStudies = cfg.experiment.paperStudies;
end

usePaperSchedule = false;
if ~isempty(fieldnames(paperStudies)) && ...
        isfield(paperStudies,'useStudySpecificDecayScheduling') && ...
        paperStudies.useStudySpecificDecayScheduling && ...
        isfield(paperStudies,'formalRunOrder')
    formalOrder = string(paperStudies.formalRunOrder);
    usePaperSchedule = isequal(selected,formalOrder);
end

if saveResults
    runRoot = fullfile(projectRoot,cfg.output.root,cfg.output.runTag);
    if ~exist(runRoot,'dir'), mkdir(runRoot); end

    manifest = struct( ...
        'cfg',cfg, ...
        'catalog',catalog, ...
        'selectedMethods',{cellstr(selected)}, ...
        'paperStudies',paperStudies, ...
        'studySpecificDecayScheduling',usePaperSchedule, ...
        'created',datestr(now,30), ...
        'projectRoot',projectRoot);

    save(fullfile(runRoot,'run_manifest.mat'),'manifest','-v7.3');
else
    runRoot = '';
end

oldVis = get(groot,'defaultFigureVisible');
cleanupObj = onCleanup(@() set(groot,'defaultFigureVisible',oldVis)); %#ok<NASGU>
if ~cfg.output.showFigures
    set(groot,'defaultFigureVisible','off');
end

results = cell(0,1);
caseNames = string(cfg.experiment.systemCases);

for ic=1:numel(caseNames)
    caseName=char(caseNames(ic));

    if strcmpi(cfg.scenario.dayType,'Usual day')
        decayList=1;
    else
        decayList=cfg.scenario.decayRatios;
    end

    for decay=decayList(:).'

        selectedThisDecay=selected;

        if usePaperSchedule
            selectedThisDecay=methods_for_decay_local(paperStudies,decay);
            selectedThisDecay=selected(ismember(selected,selectedThisDecay));

            if isempty(selectedThisDecay)
                fprintf('[SKIP DECAY %.2f] no paper methods scheduled.\n',decay);
                continue;
            end

            fprintf('\nPaper schedule | decay %.2f | methods: %s\n', ...
                decay,strjoin(selectedThisDecay,', '));
        end

        for seed=cfg.experiment.randomSeeds(:).'
            for id=selectedThisDecay(:).'

                method=catalog(methodIDs==id);
                assert(numel(method)==1,'Ambiguous method ID: %s',id);

                runCfg=method;
                runCfg.caseName=caseName;
                runCfg.dayType=cfg.scenario.dayType;
                runCfg.decayRatio=decay;
                runCfg.randomSeed=seed;

                fprintf('\n=== %s | %s | decay %.2f | seed %d ===\n', ...
                    method.id,caseName,decay,seed);

                result=run_single_experiment( ...
                    cfg,runCfg,projectRoot,runRoot,saveResults);

                results{end+1,1}=result; %#ok<AGROW>

                if ~cfg.output.showFigures
                    close all force;
                end
            end
        end
    end
end

if saveResults
    fprintf('\nAll selected experiments finished. Results: %s\n',runRoot);
else
    fprintf('\nInformal/test run finished. No files were saved under outputs/.\n');
end
end


function methods=methods_for_decay_local(plan,decay)
methods=strings(0,1);

if isfield(plan,'aiReserveAblation') && ...
        isfield(plan.aiReserveAblation,'decayRatios') && ...
        any(abs(plan.aiReserveAblation.decayRatios-decay)<1e-12)
    methods=[methods;string(plan.aiReserveAblation.methods(:))]; %#ok<AGROW>
end

if isfield(plan,'curtailmentAllocationCost') && ...
        isfield(plan.curtailmentAllocationCost,'decayRatios') && ...
        any(abs(plan.curtailmentAllocationCost.decayRatios-decay)<1e-12)
    methods=[methods;string(plan.curtailmentAllocationCost.methods(:))]; %#ok<AGROW>
end

methods=unique(methods,'stable');
end
