function [totalCost]=EMS_results_display(Pload_BoxBasic,Qload_BoxBasic,Pload_true_boxPlt,P_DG,Pbatt,P_res,TotalLoad,TotalConsume,Ploss,TotalGen,TotalBatt,TotalPV,TotalGFM,CostRecord,VsBoxBasic,SOC,T_EVch1,T_EVch2,Xbasic,I_line,LineLimits,Vmin,Vmax,BusOfLoad,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,freq,t_sim,ExportFigForPaper,brhID,ShowFigures)

    if nargin < 34 || isempty(ShowFigures)
        ShowFigures = true;
    end
    totalCost = sum(CostRecord,'all','omitnan');
    % Cost aggregation is always available. Skip legacy plotting entirely
    % during batch/oracle runs to avoid large graphics overhead.
    if ~ShowFigures && ~ExportFigForPaper
        return;
    end

% fontsize=12;
    fontsize=14;

    tTol=t_sim(1,1:end);
    ctTol=length(tTol);

    DG_NumGFM=length(BusOfDieselG_GFM);
    BatteryNumGFM=length(BusOfBatteryGFM);
    BatteryNum=length(BusOfBattery);
    EVBatteryNum=length(BusOfEVBattery);
    SolarNum=length(BusOfPV);

    % figure
    % % legend_entries = cell(BusNum, 1); % Pre-allocate legend entries
    % for ii=1:BusOfLoad
    %     plot(tTol,-Pload_BoxBasic(ii,1:ctTol));
    %     % legend_entries{ii} = sprintf('bus %d', ii); % Add LaTeX legend entry
    % end
    % title('Active power of load');
    % xlabel('t(h)','Interpreter','latex');ylabel('$P_{load}$','Interpreter','latex');
    % xlim([0,24])
    % grid on
    % box on
    % 
    % figure
    % % legend_entries = cell(BusNum, 1); % Pre-allocate legend entries
    % for ii=1:BusOfLoad
    %     plot(tTol,-Qload_BoxBasic(ii,1:ctTol));
    %     % legend_entries{ii} = sprintf('bus %d', ii); % Add LaTeX legend entry
    % end
    % title('Reactive power of load');
    % xlabel('t(h)','Interpreter','latex');ylabel('$Q_{load}$','Interpreter','latex');
    % xlim([0,24])
    % grid on
    % box on
    % drawnow limitrate  
    figure
    hold on
    % legend_entries = cell(BusNum, 1); % Pre-allocate legend entries
    for ii=1:BusOfLoad
        plot(tTol,-Pload_BoxBasic(ii,1:ctTol));
        plot(t_sim,-Pload_true_boxPlt(ii,:), 'k--','LineWidth',2);
        legend_entries{ii} = sprintf('bus %d', ii); % Add LaTeX legend entry
    end
    hold off
    % title('Comparation the case with and without price adj.');
    xlabel('t(h)','Interpreter','latex');ylabel('$P_{load}$','Interpreter','latex');
    xlim([0,24])
    grid on
    box on


    % figure
    % hold on
    % plot(tTol,-Pload_BoxBasic(1,1:ctTol));
    % plot(tTol,-Qload_BoxBasic(1,1:ctTol));
    % hold off
    % title('Power injected by external grid');
    % xlabel('t(h)','Interpreter','latex');ylabel('$MW$','Interpreter','latex');
    % xlim([0,24])
    % legend({'$P_{total load}$','$Q_{total load}$'},'Interpreter','latex');
    % grid on
    % box on
    % drawnow limitrate  
    figure
    hold on
    colors = turbo(DG_NumGFM+BatteryNum+BatteryNumGFM+EVBatteryNum+SolarNum);idx = 0;
    legend_entries = cell(DG_NumGFM+BatteryNum+BatteryNumGFM+EVBatteryNum+SolarNum+1, 1); % Pre-allocate legend entries
    for ii = 1:DG_NumGFM
        idx = idx + 1;
        plot(tTol, P_DG(ii, 1:ctTol), 'Color', colors(idx,:),'LineWidth',2);
        legend_entries{ii} = sprintf('$P_{DG%d}$', ii); % Add LaTeX legend entry
    end
    for ii = 1:BatteryNum+BatteryNumGFM
        idx = idx + 1;
        plot(tTol, Pbatt(ii, 1:ctTol), 'Color', colors(idx,:),'LineWidth',2);
        legend_entries{DG_NumGFM+ii} = sprintf('$P_{batt%d}$', ii); % Add LaTeX legend entry
    end
    for ii = 1:EVBatteryNum
        idx = idx + 1;
        plot(tTol, Pbatt(BatteryNum+BatteryNumGFM+ii, 1:ctTol), 'Color', colors(idx,:),'LineWidth',2);
        legend_entries{DG_NumGFM+BatteryNum+BatteryNumGFM+ii} = sprintf('$P_{EV%d}$', ii); % Add LaTeX legend entry
    end
    for ii = 1:SolarNum
        idx = idx + 1;
        plot(tTol, P_res(ii, 1:ctTol), 'Color', colors(idx,:),'LineWidth',2);
        legend_entries{DG_NumGFM+BatteryNum+BatteryNumGFM+EVBatteryNum+ii} = sprintf('$P_{res%d}$', ii); % Add LaTeX legend entry
    end
    plot(tTol,real(TotalLoad(1,1:ctTol)),'LineWidth',2);
    ax  = gca;
    legend_entries{DG_NumGFM+BatteryNum+BatteryNumGFM+EVBatteryNum+SolarNum+1} = sprintf('$P_{load%d}$', ii);
    hold off
    % title('Power injected by the battery');
    xlabel('t(h)', 'Interpreter', 'latex');
    ylabel('$MW$', 'Interpreter', 'latex');
    set(gca, 'FontName', 'Times New Roman', 'FontSize', fontsize);
    xlim([0,24])
    grid on
    box on
    lgd =legend(legend_entries,'NumColumns',2, 'Interpreter', 'latex','Location','northeast');
    lgd.FontSize = 12; 
    lgd.ItemTokenSize = [12 8];
    u = 0.75;    % x of legend bottom-left inside the axes
    v = 0.80;    % y of legend bottom-left inside the axes
    w = 0.28;    % legend width  (fraction of axes width)
    h = 0.22;    % legend height (fraction of axes height)

    set(lgd,'Units','normalized');          % legend uses figure-normalized units
    axpos = ax.Position;                    % axes box in figure-normalized units
    lgd.Position = [ ...
        axpos(1) + u*axpos(3), ...         % convert (u,v,w,h) from axes→figure
        axpos(2) + v*axpos(4), ...
        w*axpos(3), ...
        h*axpos(4)];
    if ExportFigForPaper==1
        w=7.8;%cm
        h=7;%cm
        filename='AllPowerCurve';
        format='pdf';
        figProcess(w, h, filename, format);
    end

    % drawnow limitrate  
    figure
    hold on
    plot(tTol,real(-TotalConsume(1,1:ctTol)),'LineWidth',2);
    plot(tTol,real(TotalGen(1,1:ctTol)),':','LineWidth',2);
    plot(tTol,real(Ploss(1,1:ctTol)),':','LineWidth',2);
    hold off
    title('Total load and generation power');
    xlabel('t(h)','Interpreter','latex');ylabel('$P(MW)$','Interpreter','latex');
    xlim([0,24])
    set(gca, 'FontName', 'Times New Roman', 'FontSize', fontsize);
    legend({'$P_{cons}$','$P_{gen}$','$P_{loss}$'},'Interpreter','latex');
    grid on
    box on

    % figure
    % hold on
    % stairs(tTol,real(TotalLoad(1,1:ctTol)),'LineWidth',1);
    % stairs(tTol,TotalBatt(1,1:ctTol),'LineWidth',2);
    % stairs(tTol,TotalPV(1,1:ctTol),'LineWidth',1);
    % stairs(tTol,TotalGFM(1,1:ctTol),'LineWidth',1);
    % hold off
    % legend({'$P_{load}$','$P_{batt}$','$P_{PV}$','$P_{GFM}$'},'Interpreter','latex','Location','best','NumColumns',2);
    % xlabel('t(h)','Interpreter','latex');ylabel('$P(MW)$','Interpreter','latex');
    % set(gca, 'FontName', 'Times New Roman', 'FontSize', fontsize);
    % xlim([0,24])
    % grid on
    % box on
    % if ExportFigForPaper==1
    %     w=7.8;%cm
    %     h=7;%cm
    %     filename='AllPowerCurve';
    %     format='pdf';
    %     figProcess(w, h, filename, format);
    % end

    % drawnow limitrate  
    figure
    stairs(tTol,freq(1,1:ctTol),'LineWidth',2)
    xlabel('t(h)','Interpreter','latex');ylabel('$f(Hz)$','Interpreter','latex');
    xlim([0,24])
    set(gca, 'FontName', 'Times New Roman', 'FontSize', fontsize);
    grid on
    box on

    % figure
    % plot(tTol,CostRecord(1,1:ctTol),'LineWidth',2);
    % ylabel('Cost per step($)','Interpreter','latex');
    % xlabel('t(h)','Interpreter','latex');
    % xlim([0,24])
    % set(gca, 'FontName', 'Times New Roman', 'FontSize', fontsize);
    % % disp(['Total cost: ',num2str(sum(CostRecord))])
    % grid on
    % box on

    % drawnow limitrate  
    figure
    legend_entries = cell(BatteryNum+BatteryNumGFM+EVBatteryNum, 1); % Pre-allocate legend entries
    hold on
    for ii = 1:BatteryNumGFM
        plot(tTol,SOC(ii,1:ctTol),'LineWidth',2);
        legend_entries{ii} = sprintf('$SOC_{GFM%d}$', ii);
    end
    for ii = 1:BatteryNum
        plot(tTol,SOC(BatteryNumGFM+ii,1:ctTol),'LineWidth',2);
        legend_entries{BatteryNumGFM+ii} = sprintf('$SOC_{batt%d}$', ii);
    end
    for ii = 1:EVBatteryNum
        SOC_EV=SOC(BatteryNumGFM+BatteryNum+ii,:);SOC_EVini=SOC_EV(1,1);
        dt=tTol(1,2)-tTol(1,1);
        SOC_EV_T_EVch1=SOC_EV(1,1+(T_EVch1+0.5)/dt)-SOC_EV(1,1);
        SOC_EV_T_EVch2=SOC_EV(1,end)-SOC_EV(1,1+T_EVch2/dt);
        SOC_EV(1,1:1+(T_EVch1+0.5)/dt)=SOC_EV(1,1:1+(T_EVch1+0.5)/dt)+SOC_EV_T_EVch2;
        SOC_EV(1,1+(T_EVch1+0.5)/dt+1:1+T_EVch2/dt-1)=SOC_EVini;
        SOC_EV(1,1+(T_EVch2)/dt:end)=SOC_EV(1,1+(T_EVch2)/dt:end)-SOC_EV_T_EVch1;
        plot(tTol,SOC_EV(1,1:ctTol),'LineWidth',2);
        legend_entries{BatteryNumGFM+BatteryNum+ii} = sprintf('$SOC_{EV%d}$', ii);
    end
    plot(tTol,0.2*ones(1,ctTol),'k--','LineWidth',1);
    plot(tTol,0.9*ones(1,ctTol),'k--','LineWidth',1);
    plot(tTol,SOC(1,1)*ones(1,ctTol),'k--','LineWidth',1);
    hold off
    ylabel('SOC','Interpreter','latex');xlabel('t(h)','Interpreter','latex')
    xlim([0,24])
    ylim([0,1])
    set(gca, 'FontName', 'Times New Roman', 'FontSize', fontsize);
    legend(legend_entries,'NumColumns',2, 'Interpreter', 'latex');
    grid on
    box on
    % legend(legend_entries, 'Interpreter', 'latex', 'Location', 'best')
    if ExportFigForPaper==1
        w=8.8*1.1;%cm
        h=3;%cm
        filename='SoC_of_Battery';
        format='pdf';
        figProcess(w, h, filename, format);
    end


    % fprintf('Branch current out-of-limit report:\n')
    % Iline_mag=abs(I_line);
    % idx=0;
    % subFigSize=size(I_line,1);
    % figure
    % for ii=idx+1:idx+subFigSize
    %     subplot(subFigSize,1,ii-idx)
    %     hold on
    %     plot(tTol,Iline_mag(ii,:))
    %     plot(tTol,LineLimits(ii)*ones(size(tTol)),'Color','k','LineStyle','--')
    %     xlim([0,24])
    %     % ylim([0,1.1*LineLimits(ii)])
    %     % title(sprintf('Branch %d', ii))
    %     set(gca, 'FontName', 'Times New Roman', 'FontSize', fontsize);
    %     grid on
    %     box on
    %     hold off
    % end
    % xlabel('t(h)');ylabel('|I|(p.u.)')

    % drawnow limitrate  
    figure%most series branch for displaying
    Iline_mag=abs(I_line);
    hold on
    plot(tTol,Iline_mag(brhID,:),'LineWidth',2)
    plot(tTol,LineLimits(brhID)*ones(size(tTol)),'Color','k','LineStyle','--','LineWidth',1)
    hold off
    xlim([0,24])
    ylim([0,max(1.5*LineLimits(brhID),1.2*max(Iline_mag(brhID,:)))])
    xlabel('t(h)');ylabel('|I|(p.u.)')
    set(gca, 'FontName', 'Times New Roman', 'FontSize', fontsize);
    grid on
    box on
    if ExportFigForPaper==1
        w=8.8*1.1;%cm
        h=3;%cm
        filename='BranchCurrent';
        format='pdf';
        figProcess(w, h, filename, format);
    end

    fprintf('Bus voltage out-of-limit report:\n')
    Vs_mag=abs(VsBoxBasic);
    figure
    hold on 
    for ii=1:size(Vs_mag,1)
        plot(tTol,Vs_mag(ii,:),'LineWidth',1)
    end
    plot(tTol,Vmin*ones(size(tTol)),'Color','k','LineStyle','--','LineWidth',1)
    plot(tTol,Vmax*ones(size(tTol)),'Color','k','LineStyle','--','LineWidth',1)
    hold off
    xlabel('t(h)');ylabel('|V|(p.u.)')
    xlim([0,24])
    ylim([0.75,1.25])
    set(gca, 'FontName', 'Times New Roman', 'FontSize', fontsize);
    grid on
    box on
    if ExportFigForPaper==1
        w=8.8*1.1;%cm
        h=3;%cm
        filename='BusVoltage';
        format='pdf';
        figProcess(w, h, filename, format);
    end
end
