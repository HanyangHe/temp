function [Vs, Vter, X,freq,S_GFM]=InitializationProgramPQ(P_DG_opt_Dec,Q_DG_opt_Dec,PbattGFM_opt_Dec,QbattGFM_opt_Dec,Pbatt_opt_Dec,Qbatt_opt_Dec,PbattEV_opt_Dec,Pres_opt_Dec,Qres_opt_Dec,DieselG_P_rate,Pload_true_box,Qload_true_box,PV1_curve,Q_BattInvMax,V_DC,Zs_DG,Xd_prime,Xm_g,Zmv_g,Y_Bus,SOC0,SOCmin,SOCmax,DGcontrolParams,SoCParams,phys,K_Pdp,K_Qdp,Rdroop,kQ_DG,BusOfDG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,BusNum,DG_GFM_num,BatteryGFM_Num,BatteryNum,EVBatteryNum,SolarNum,MainGFM,dt,Integrator)

    freqbox(:,1)=60*ones(DG_GFM_num+BatteryGFM_Num,1);
    % KA    = DGcontrolParams(1); 
    for RealStep = 1:round(5/dt)       
        if RealStep==1
            % power grid
            Vs=ones(BusNum,1);
            S_load_vec=Pload_true_box(:,1)+1j*Qload_true_box(:,1);

            % DG
            if DG_GFM_num>0
                Xbasic_DG(:,RealStep)=zeros((DG_GFM_num)*4,1);
                idx=0;
                for ii=1:DG_GFM_num
                Vter_DG(ii,1)=1;
                Vbus0=1;
                Qref0 = 0;
                Pref0=P_DG_opt_Dec(1,1,ii);%Pref0=DieselG_P_rate(ii);
                S0   = Pref0 + 1j*Qref0;
                I0   = conj(S0 / Vbus0);
                Eint0 = Vbus0 + Zs_DG(ii) * I0;
                delta0 = angle(Eint0) - pi/2;
                % Id0 =  real(I0)*cos(delta0) + imag(I0)*sin(delta0);
                % Vref0=(abs(Eint0)+ (phys.Xd - Xd_prime)*Id0)/KA+abs(Vbus0);%KA * (Vref0 - abs(Vbus0))=abs(Eint0)+ (Xd - Xd_prime)*Id0


                Xbasic_DG(idx+1,RealStep)=delta0;
                Xbasic_DG(idx+2,RealStep)=0;
                % Xbasic_DG(idx+3,RealStep)=abs(Eint0);% E' 1 pu
                % Xbasic_DG(idx+4,RealStep)=KA * (Vref0 - abs(Vbus0));% Ef 1 pu
                % Xbasic_DG(idx+5,RealStep)=P_DG_opt_Dec(1,1,ii);%DieselG_P_rate(ii)
                Xbasic_DG(idx+3,RealStep)=P_DG_opt_Dec(1,1,ii);%DieselG_P_rate(ii)
                Xbasic_DG(idx+4,RealStep)=0;
                idx=idx+4;
                end
            else
                Vter_DG=[];
                Xbasic_DG=[];
            end

            % inverter
            M = (sqrt(3)/sqrt(2))*0.5*V_DC;
            if BatteryGFM_Num>0
                Vter_GFMinv=ones(BatteryGFM_Num,1);
                Xbasic_GFMinv(:,RealStep)=zeros((BatteryGFM_Num)*3,1);
                Xbasic_GFMinv(3:3:end,RealStep)=1/M;
            else
                Vter_GFMinv=[];
                Xbasic_GFMinv=[];
            end
            if BatteryNum+EVBatteryNum+SolarNum>0
                Vter_inv=ones(BatteryNum+EVBatteryNum+SolarNum,1);
                Xbasic_inv(:,RealStep)=zeros((BatteryNum+EVBatteryNum+SolarNum)*2,1);
                Xbasic_inv(1:2:end,RealStep)=0;
            else
                Vter_inv=[];
                Xbasic_inv=[];
            end
            Xbasic=[Xbasic_DG;Xbasic_GFMinv;Xbasic_inv];
            Vter=[Vter_DG;Vter_GFMinv;Vter_inv];

            Niter=10;
        else
            % update load power
            S_load_vec=Pload_true_box(:,1)+1j*Qload_true_box(:,1);

            Niter=5;
        end

        idx_ref=0;decisionStep=1;
        for ii=1:DG_GFM_num
            Ref(idx_ref+1,RealStep)=1;idx_ref=idx_ref+1;%Vset GFM
            Ref(idx_ref+1,RealStep)=P_DG_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
            Ref(idx_ref+1,RealStep)=Q_DG_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Qg1_bat set
        end
    
        for ii=1:BatteryGFM_Num
            Ref(idx_ref+1,RealStep)=1;idx_ref=idx_ref+1;%Vset GFM
            Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%dw_set GFM
            Ref(idx_ref+1,RealStep)=PbattGFM_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
            Ref(idx_ref+1,RealStep)=QbattGFM_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Qg1_bat set
        end
    
        for ii=1:BatteryNum
            Ref(idx_ref+1,RealStep)=Pbatt_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
            Ref(idx_ref+1,RealStep)=Qbatt_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Qg1_bat set
        end
    
        for ii=1:EVBatteryNum
            Ref(idx_ref+1,RealStep)=PbattEV_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Pg1_bat set
            Ref(idx_ref+1,RealStep)=0;idx_ref=idx_ref+1;%Qg1_bat set
        end
    
        for ii=1:SolarNum
            Ref(idx_ref+1,RealStep)=PV1_curve(1,1);idx_ref=idx_ref+1;%Pg2_bat set
            Ref(idx_ref+1,RealStep)=Qres_opt_Dec(decisionStep,1,ii);idx_ref=idx_ref+1;%Qg2_bat set
        end

        [Xbasic(:,RealStep+1),Vs,Vter,S_busInjVec,S_DG,S_inv_Batt,S_inv_PV,freqbox(:,RealStep+1),~,err, ~]=MicrogridSys_ODEAE_expIterSolver(Xbasic(:,RealStep),Vs,Vter,Ref(:,RealStep),S_load_vec,V_DC,Zs_DG,Xm_g,Zmv_g,Y_Bus,SOC0,SOCmin,SOCmax,DieselG_P_rate,DGcontrolParams,SoCParams,phys,K_Pdp,K_Qdp,Rdroop,kQ_DG,BusOfDG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,MainGFM,dt,Niter,Integrator);
    end
    freq=freqbox(:,end);
    X=Xbasic(:,end);
    S_GFM=S_DG;
    for ii=1:BatteryGFM_Num
        S_GFM=[S_GFM;S_inv_Batt(ii)];
    end
end
