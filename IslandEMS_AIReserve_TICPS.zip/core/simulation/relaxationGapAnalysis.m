function [MaxRelaxationGap,MaxRelaxationRelGap,MaxAngleErrorAllLoopInDay,MaxMagErrorAllLoopInDay]=relaxationGapAnalysis(x,idx,Nbranch,BusNum,Line,LineBFM,loopNodes,Loops,loopBranches,Kday)
    for ii=1:Kday
        P_br(:,ii)=x(idx+1:idx+Nbranch);idx=idx+Nbranch;
        Q_br(:,ii)=x(idx+1:idx+Nbranch);idx=idx+Nbranch;
        l_br(:,ii)=x(idx+1:idx+Nbranch);idx=idx+Nbranch;
        v_bus(:,ii)=x(idx+1:idx+BusNum);idx=idx+BusNum;
    
        num = abs(P_br(2:end,ii).^2+Q_br(2:end,ii).^2 - l_br(2:end,ii).*v_bus(Line(:,1),ii));
        % Here, for the den of the relative gap, may be the results without the
        % constraint will be more reasonable
        % den = max([1e-6*ones(Nbranch-1,1), abs(P_br(2:end,ii).^2), abs(l_br(2:end,ii).*v_br(Line(:,1),ii))], [], 2);
        den = max(max(abs(P_br(2:end,ii).^2)));
    
        relaxationGapBox(:,ii)    = num;          % absolute gap
        relaxationGap(1,ii)       = max(num);     % max absolute gap
        relaxationRelGapBox(:,ii) = num ./ den;   % relative gap
        relaxationRelGap(1,ii)    = max(relaxationRelGapBox(:,ii)); % max relative gap
    end
    % disp('Max relaxation gap of power constraints in a day:');
    MaxRelaxationGap=relaxationGap(1,1);
    
    % disp('Max relative relaxation gap of power constraints in a day:');
    MaxRelaxationRelGap=relaxationRelGap(1,1);
    
    
    % ----angle recovery analysis----
    BranchIndexAndSign=LoopBranchDirectSign(LineBFM,loopNodes,Loops);
    for ii=1:Kday
        for e=1:Loops
            br_n=loopBranches{e};
            node_fr=LineBFM(br_n,1);
            node_to=LineBFM(br_n,2);
            Angle(1)=0;
            MagError(1)=0;
            for jj=1:length(br_n)
                V_from_mag=sqrt(v_bus(node_fr(jj),ii));
                P=P_br(br_n(jj),ii);
                Q=Q_br(br_n(jj),ii);
                z=LineBFM(br_n(jj),3)+1j*LineBFM(br_n(jj),4);
                Isign=BranchIndexAndSign{e}(jj,2);
                Angle(jj+1)=Angle(jj)+Isign*angle(V_from_mag-z*(P-1j*Q)/V_from_mag);
                MagError(jj+1)=abs(abs(V_from_mag-z*(P-1j*Q)/V_from_mag)-sqrt(v_bus(node_to(jj),ii)));
            end
            AngleErrorBox(e,ii)=Angle(jj+1);
            MagErrorBox(e,ii)=max(MagError);
        end
    end
    % disp('max angle error for all loops in a day:');
    tmp=max(abs(AngleErrorBox));
    MaxAngleErrorAllLoopInDay=tmp(1);
    % disp('max magnitude error for all loops in a day:');
    tmp=max(abs(MagErrorBox));
    MaxMagErrorAllLoopInDay=tmp(1);
end
