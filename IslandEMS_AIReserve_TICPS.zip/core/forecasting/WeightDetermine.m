function Xi = WeightDetermine(iniSeqVec,Pmat_curveDic,lag,beta,TpyIdx)
    for ii=1:size(Pmat_curveDic,2)
        for jj=1:size(Pmat_curveDic,1)-lag+1
            compPart=Pmat_curveDic(jj:jj+lag-1,ii);
            for rr=1:size(iniSeqVec,2)
            sbox(rr,jj)=1/(mean((iniSeqVec(:,rr)-compPart).^2)+1e-6);
            end
        end
        for rr=1:size(iniSeqVec,2)
            sCur(rr,ii)=max(sbox(rr,:));
        end
    end
    for rr=1:size(iniSeqVec,2)
        Xi(rr,:)=min(exp(beta*(sCur(rr,:)-max(sCur(rr,:))))/sum(exp(beta*(sCur(rr,:)-max(sCur(rr,:))))),1e9);
        if var(Xi(rr,:))<=1e-2
            Xi(rr,TpyIdx)=1;Xi(rr,setdiff(1:end, TpyIdx))=0;
        end
    end
end
