function y=AnisotropicGaussianKernel(x1,x2,sigma,sigmaT,lag)
    x1=x1(:);
    x2=x2(:);
    diff = (x1(1:lag) - x2(1:lag));
    diffT= (x1(lag+1:end) - x2(lag+1:end));
    y = exp( - (diff' * diff) / (2 * sigma^2) - (diffT' * diffT) / (2 * sigmaT^2));
end
