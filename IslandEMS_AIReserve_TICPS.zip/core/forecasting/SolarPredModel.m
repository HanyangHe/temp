function Xnext=SolarPredModel(X,X_train,Xi,sigma,sigmaT,alpha,NextPoint,predStep,useUpStream,lookAheadStep,StdTime,TypicalIdx)
% X is the input vector formed by i-lag+1 to i-th point
    Nm=size(Xi,2);
    lag=length(X);
    % Use the previous 'lag' predicted points as input
    x = [X StdTime];  % Row vector of length 'lag'

    % =======prediction========
    % MMDG-AKRR
    if Nm==1
        for mm=1:Nm
            % Compute kernel values between x and each training sample (vectorized)
            for kk=1:size(X_train{TypicalIdx},1)
                kx(1,kk)=AnisotropicGaussianKernel(X_train{TypicalIdx}(kk,:),x,sigma(1,mm),sigmaT(1,mm),lag); 
            end
                     
            % Predict the current point using the kernel ridge regression model
            dx=kx * alpha{TypicalIdx};
            xnextEstiVec(mm,1) = dx+X(1, end);
        end
    else
        for mm=1:Nm
            % Compute kernel values between x and each training sample (vectorized)
            for kk=1:size(X_train{1},1)
                kx(1,kk)=AnisotropicGaussianKernel(X_train{mm}(kk,:),x,sigma(1,mm),sigmaT(1,mm),lag); 
            end
                     
            % Predict the current point using the kernel ridge regression model
            dx=kx * alpha{mm};
            xnextEstiVec(mm,1) = dx+X(1, end);
        end
    end
    
    xnextEsti = Xi*xnextEstiVec;

    if useUpStream==1 && predStep<=lookAheadStep
        Xnext = NextPoint;
    else
        Xnext = xnextEsti;
    end
end
