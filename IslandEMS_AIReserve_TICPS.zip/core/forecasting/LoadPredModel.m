function Xnext=LoadPredModel(X,X_train,sigma,sigmaT,alpha_best,StdTime)
    % X is the input vector formed by i-lag+1 to i-th point
    lag=length(X);

    % Use the previous 'lag' predicted points as input
    x = [X StdTime];  % Row vector of length 'lag'

    % Compute kernel values between x and each training sample (vectorized)
    for kk=1:size(X_train,1)
        kx(1,kk)=AnisotropicGaussianKernel(X_train(kk,:),x,sigma,sigmaT,lag); 
    end
    
    % Predict the current point using the kernel ridge regression model
    dx = kx * alpha_best;
    Xnext = dx+X(1, end);
end
