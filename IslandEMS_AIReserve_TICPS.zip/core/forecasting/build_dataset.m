function [Feature, dFeature] = build_dataset(Pmat0, col_indices, lag,dayPoints,usedx)
    Feature = [];
    dFeature = [];

    Pmat=[Pmat0(end-lag+2:end,:); Pmat0; Pmat0(1,:)];
    dP3mat=Pmat(2:end,:)-Pmat(1:end-1,:);

    for col = col_indices
        dcurve = dP3mat(:, col);
        curve = Pmat(:, col);
        n = length(curve);

        for Nt = lag:n-1
            F=curve(Nt-lag+1:Nt)';
            t = mod((Nt-lag),dayPoints)/dayPoints;
            Feature = [Feature; F t];  % Append as a row vector
            % Feature = [Feature; F t w_t*sin(2*pi*t) w_t*cos(2*pi*t)];  % Append as a row vector

            dF=dcurve(Nt)';
            if usedx==1
                dFeature = [dFeature; dF];
            else
                dFeature = [dFeature; curve(Nt)];
            end
        end
    end
end
