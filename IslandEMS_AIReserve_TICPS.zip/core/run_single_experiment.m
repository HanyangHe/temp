function result = run_single_experiment(cfg,runCfg,projectRoot,runRoot,saveOutput)
%RUN_SINGLE_EXPERIMENT Run exactly one method/network/scenario combination.
% The legacy numerical formulations are executed in an isolated function
% workspace and are controlled by runCfg. This prevents cross-baseline
% workspace contamination and makes each result independently replayable.

if nargin < 5, saveOutput = true; end
if nargin < 4 || isempty(runRoot)
    runRoot = fullfile(projectRoot,cfg.output.root,cfg.output.runTag);
end

aiCfgRun = cfg.ai;
if isfield(runCfg,'aiSafetyCalibration')
    aiCfgRun.useSafetyCalibration = runCfg.aiSafetyCalibration;
% FINAL_P1_METHOD_SPECIFIC_FORECAST_GUARD
% P1/P1U forecast-guard selection comes from the method catalog.
aiCfgRun.enableForecastSafetyShield = false;
if isfield(runCfg,'aiForecastSafetyShield') && ~isempty(runCfg.aiForecastSafetyShield)
    aiCfgRun.enableForecastSafetyShield = logical(runCfg.aiForecastSafetyShield);
end
if isfield(runCfg,'aiForecastSafetyShieldDropThreshold_pu') && isfinite(runCfg.aiForecastSafetyShieldDropThreshold_pu)
    aiCfgRun.forecastSafetyShieldDropThreshold_pu = runCfg.aiForecastSafetyShieldDropThreshold_pu;
end
if isfield(runCfg,'aiForecastSafetyShieldNetLoadMin_pu') && isfinite(runCfg.aiForecastSafetyShieldNetLoadMin_pu)
    aiCfgRun.forecastSafetyShieldNetLoadMin_pu = runCfg.aiForecastSafetyShieldNetLoadMin_pu;
end
if isfield(runCfg,'aiForecastSafetyShieldSevereDropEnabled') && ~isempty(runCfg.aiForecastSafetyShieldSevereDropEnabled)
    aiCfgRun.forecastSafetyShieldSevereDropEnabled = logical(runCfg.aiForecastSafetyShieldSevereDropEnabled);
end
if isfield(runCfg,'aiForecastSafetyShieldSevereDropThreshold_pu') && isfinite(runCfg.aiForecastSafetyShieldSevereDropThreshold_pu)
    aiCfgRun.forecastSafetyShieldSevereDropThreshold_pu = runCfg.aiForecastSafetyShieldSevereDropThreshold_pu;
end
if isfield(runCfg,'aiForecastSafetyShieldAlpha') && isfinite(runCfg.aiForecastSafetyShieldAlpha)
    aiCfgRun.forecastSafetyShieldAlpha = runCfg.aiForecastSafetyShieldAlpha;
end
end

aiModel = [];
if any(strcmpi(runCfg.reserveMode,{'ai','global'}))
    modelFile = get_ai_reserve_model_file(projectRoot,cfg,runCfg.caseName);
    if ~exist(modelFile,'file')
        if cfg.ai.requireModelForAI
            error(['AI reserve model for case %s not found: %s\n', ...
                   'Run train_AIReserve.m for this grid before enabling method %s.'], ...
                   runCfg.caseName,modelFile,runCfg.id);
        end
    else
        S = load(modelFile,'model');
        [ok,msg] = validate_ai_reserve_model(S.model,cfg,runCfg.caseName);
        if ~ok
            error(['Stored AI reserve model for %s is stale/incompatible: %s\n', ...
                   'Retrain with train_AIReserve.m.'],runCfg.caseName,msg);
        end
        aiModel = S.model;
    end
end

% Internal script populates optimization/simulation variables in this
% function workspace.
%
% IMPORTANT: MATLAB's Signal Processing Toolbox also defines a function
% named `meanfreq`.  Because the engine is a script executed dynamically by
% run(), MATLAB can otherwise resolve a later bare `meanfreq` reference in
% this function as the toolbox function instead of as the variable created
% by the engine.  Predeclaring it here forces variable semantics in this
% function workspace; the engine then overwrites/fills it normally.
meanfreq = [];
run(fullfile(projectRoot,'core','engine','engine_island_ems.m'));

% Contract check: a completed physical simulation must return the CoI
% frequency trajectory.  Fail here with a project-specific message rather
% than accidentally calling MATLAB's meanfreq() function.
if isempty(meanfreq) || ~isnumeric(meanfreq) || any(~isfinite(meanfreq(:)))
    error('IslandEMS:MissingCoIFrequency', ...
        ['engine_island_ems.m completed without a valid CoI frequency ', ...
         'trajectory in variable meanfreq.']);
end

result = struct();
result.meta = struct('methodID',runCfg.id,'description',runCfg.description, ...
    'caseName',runCfg.caseName,'topologyKey',Topology,'dayType',runCfg.dayType, ...
    'decayRatio',runCfg.decayRatio,'randomSeed',runCfg.randomSeed, ...
    'reserveMode',runCfg.reserveMode,'reserveFixedRatio',runCfg.reserveFixedRatio, ...
    'curtailmentMode',runCfg.curtailmentMode,'aiSafetyCalibration',runCfg.aiSafetyCalibration, ...
    'created',datestr(now,30));
result.cfgSnapshot = cfg;

% Core signals used by replay and paper metrics.
result.time_h = t_sim;
result.freq_Hz = meanfreq; % inertia-weighted DG CoI frequency
if exist('freq','var'), result.freqAll_Hz=freq; else, result.freqAll_Hz=[]; end
result.voltage_pu = VsBoxBasic;
result.current_pu = I_line;
result.lineLimits_pu = LineLimits;
result.soc = SOC;
result.P_DG_MW = P_DG;
result.DG_rating_MW = DieselG_Pgfm_rate(:).';
result.P_batt_MW = Pbatt;
result.P_PV_MW = P_res;
result.totalLoad_MW = TotalLoad;
result.totalGeneration_MW = TotalGen;
result.totalBattery_MW = TotalBatt;
result.totalPV_MW = TotalPV;
result.costRecord = CostRecord;

result.solver = struct();
if exist('solverExitflagHistory','var'), result.solver.optimizationExitflag=solverExitflagHistory; else, result.solver.optimizationExitflag=[]; end
if exist('pfExitflagHistory','var'), result.solver.physicalPFExitflag=pfExitflagHistory; else, result.solver.physicalPFExitflag=[]; end
if exist('solverDiagnosticHistory','var'), result.solver.coneprogDiagnostics=solverDiagnosticHistory; else, result.solver.coneprogDiagnostics={}; end

% Runtime breakdown.  The old variable timeCostMPC measured the entire
% interleaved optimization+physical loop and was previously mislabeled as
% pure physical simulation time.
result.performance = struct();
if exist('coneSolveTotalTime','var'), result.performance.coneSolveTotal_s=coneSolveTotalTime; else, result.performance.coneSolveTotal_s=NaN; end
if exist('staticStructureBuildTime','var'), result.performance.staticStructureBuild_s=staticStructureBuildTime; else, result.performance.staticStructureBuild_s=NaN; end
if exist('staticCacheReused','var'), result.performance.staticCacheReused=logical(staticCacheReused); else, result.performance.staticCacheReused=false; end
if exist('decisionBlockTotalTime','var'), result.performance.decisionBlockTotal_s=decisionBlockTotalTime; else, result.performance.decisionBlockTotal_s=NaN; end
if exist('decisionAssemblyAndPostTime','var'), result.performance.decisionSetupPost_s=decisionAssemblyAndPostTime; else, result.performance.decisionSetupPost_s=NaN; end
if exist('physicalLoopAndRecordTime','var'), result.performance.physicalLoopRecord_s=physicalLoopAndRecordTime; else, result.performance.physicalLoopRecord_s=NaN; end
if exist('timeCostMPC','var'), result.performance.totalCoupledRuntime_s=timeCostMPC; else, result.performance.totalCoupledRuntime_s=NaN; end
if exist('decisionBlockTimeHistory','var'), result.performance.decisionBlockTime_s=decisionBlockTimeHistory; else, result.performance.decisionBlockTime_s=[]; end
if exist('forecastBuildTimeHistory','var'), result.performance.forecastBuildTime_s=forecastBuildTimeHistory; else, result.performance.forecastBuildTime_s=[]; end
if exist('dynamicAssemblyTimeHistory','var'), result.performance.dynamicAssemblyTime_s=dynamicAssemblyTimeHistory; else, result.performance.dynamicAssemblyTime_s=[]; end
if exist('postprocessTimeHistory','var'), result.performance.postprocessTime_s=postprocessTimeHistory; else, result.performance.postprocessTime_s=[]; end
if exist('forecastBuildTotalTime','var'), result.performance.forecastBuildTotal_s=forecastBuildTotalTime; else, result.performance.forecastBuildTotal_s=NaN; end
if exist('dynamicAssemblyTotalTime','var'), result.performance.dynamicAssemblyTotal_s=dynamicAssemblyTotalTime; else, result.performance.dynamicAssemblyTotal_s=NaN; end
if exist('postprocessTotalTime','var'), result.performance.postprocessTotal_s=postprocessTotalTime; else, result.performance.postprocessTotal_s=NaN; end

% Numerical SoC boundary hygiene metrics. These count only tiny (<1e-4)
% physical-integration corrections; genuine larger violations fail loudly.
if exist('socNumericalClipCount','var'), result.performance.socNumericalClipCount=socNumericalClipCount; else, result.performance.socNumericalClipCount=0; end
if exist('socNumericalClipMax','var'), result.performance.maxSocNumericalCorrection=socNumericalClipMax; else, result.performance.maxSocNumericalCorrection=0; end
if exist('socNumericalTol','var'), result.performance.socNumericalTolerance=socNumericalTol; else, result.performance.socNumericalTolerance=NaN; end

% Flexibility/user-impact metrics are saved explicitly for revised-paper
% ablations instead of being reconstructed from plots.
result.flexibility = struct();
dt_h = 1/cfg.simulation.samplePerHour;
if exist('Pload_true_boxPlt','var') && ~isempty(Pload_true_boxPlt)
    result.loadBaseline_MW = Pload_true_boxPlt;
    result.loadExecuted_MW = Pload_BoxBasic;
    loadShedMW = max(Pload_BoxBasic-Pload_true_boxPlt,0); % loads are negative injections
    result.flexibility.loadShed_MW = loadShedMW;
    result.flexibility.loadShedEnergy_kWh = 1000*sum(loadShedMW,'all','omitnan')*dt_h;
else
    result.loadBaseline_MW = [];
    result.loadExecuted_MW = [];
    result.flexibility.loadShed_MW = [];
    result.flexibility.loadShedEnergy_kWh = NaN;
end

if exist('EbattMaxEV','var')
    result.energyCapacity.EV_MWh = EbattMaxEV(:);
else
    result.energyCapacity.EV_MWh = [];
end
if exist('EbattMax','var')
    result.energyCapacity.BESS_MWh = EbattMax(:);
else
    result.energyCapacity.BESS_MWh = [];
end
if exist('EbattMaxGFM','var')
    result.energyCapacity.GFMBESS_MWh = EbattMaxGFM(:);
else
    result.energyCapacity.GFMBESS_MWh = [];
end

if exist('EVBatteryNum','var') && EVBatteryNum>0
    evRows = BatteryGFM_Num+BatteryNum+(1:EVBatteryNum);
    evFinal = SOC(evRows,end);
    result.flexibility.EVFinalSOC = evFinal(:);
    result.flexibility.EVUnmetEnergy_kWh = 1000*sum( ...
        result.energyCapacity.EV_MWh .* max(SOCmax-evFinal(:),0),'omitnan');
    if exist('dSOC_EVcsp','var')
        commutingFloor = SOCmin + dSOC_EVcsp(:);
        result.flexibility.EVCommutingViolation_kWh = 1000*sum( ...
            result.energyCapacity.EV_MWh .* max(commutingFloor-evFinal(:),0),'omitnan');
    else
        result.flexibility.EVCommutingViolation_kWh = NaN;
    end
else
    result.flexibility.EVFinalSOC = [];
    result.flexibility.EVUnmetEnergy_kWh = 0;
    result.flexibility.EVCommutingViolation_kWh = 0;
end

if exist('BatteryNum','var') && BatteryNum>0
    bRows = BatteryGFM_Num+(1:BatteryNum);
    bInitial = SOC(bRows,1);
    bFinal = SOC(bRows,end);
    result.flexibility.BESSInitialSOC = bInitial(:);
    result.flexibility.BESSFinalSOC = bFinal(:);
    result.flexibility.BESSTerminalDeficit_kWh = 1000*sum( ...
        result.energyCapacity.BESS_MWh .* max(bInitial(:)-bFinal(:),0),'omitnan');
else
    result.flexibility.BESSInitialSOC = [];
    result.flexibility.BESSFinalSOC = [];
    result.flexibility.BESSTerminalDeficit_kWh = 0;
end

if exist('PV1_curve','var') && ~isempty(PV1_curve) && ~isempty(P_res)
    pvAvail = PV1_curve(BusOfPV,1:size(P_res,2));
    pvCurt = max(pvAvail-P_res,0);
    result.flexibility.PVCurtailed_MW = pvCurt;
    result.flexibility.PVCurtailedEnergy_kWh = 1000*sum(pvCurt,'all','omitnan')*dt_h;
else
    result.flexibility.PVCurtailed_MW = [];
    result.flexibility.PVCurtailedEnergy_kWh = NaN;
end

if exist('TotC','var')
    result.totalCost = TotC;
elseif exist('totalCost','var')
    result.totalCost = totalCost;
else
    result.totalCost = sum(CostRecord,'all','omitnan');
end

if exist('decisionTimeMPC_withgridBox','var')
    result.decisionTime_s = decisionTimeMPC_withgridBox;
elseif exist('dayahead_linprog_timecost','var')
    result.decisionTime_s = dayahead_linprog_timecost;
elseif exist('dayahead_NPprog_timecost','var')
    result.decisionTime_s = dayahead_NPprog_timecost;
else
    result.decisionTime_s = NaN;
end

if exist('reserveRatioHistory','var')
    result.reserve.ratio = reserveRatioHistory;
else
    if strcmpi(runCfg.reserveMode,'none')
        result.reserve.ratio = zeros(1,cfg.mpc.predictionHorizon);
    elseif strcmpi(runCfg.reserveMode,'fixed')
        result.reserve.ratio = runCfg.reserveFixedRatio*ones(1,cfg.mpc.predictionHorizon);
    elseif strcmpi(runCfg.reserveMode,'scheduled') && isfield(runCfg,'reserveAlphaSchedule')
        result.reserve.ratio = reshape(runCfg.reserveAlphaSchedule,1,[]);
    else
        result.reserve.ratio = nan(1,cfg.mpc.predictionHorizon);
    end
end
if isfield(runCfg,'reserveAlphaSchedule')
    result.reserve.requestedSchedule = reshape(runCfg.reserveAlphaSchedule,1,[]);
else
    result.reserve.requestedSchedule = [];
end
if exist('reserveFeatureHistory','var')
    result.reserve.features = reserveFeatureHistory;
    result.reserve.featureNames = reserve_feature_names();
else
    result.reserve.features = [];
    result.reserve.featureNames = reserve_feature_names();
end
if exist('reserveMetaHistory','var')
    result.reserve.metaHistory = reserveMetaHistory;
else
    result.reserve.metaHistory = {};
end
if exist('reserveEvalTimeHistory','var')
    result.reserve.evalTime_s = reserveEvalTimeHistory;
else
    result.reserve.evalTime_s = NaN;
end
if exist('reserveMetaStatic','var')
    result.reserve.staticMeta = reserveMetaStatic;
else
    result.reserve.staticMeta = struct();
end

if exist('relaxationGap','var'), result.relaxation.branchGap = relaxationGap; end
if exist('relaxationRelGap','var'), result.relaxation.relativeGap = relaxationRelGap; end
if exist('MaxAngleErrorAllLoopInDay','var'), result.relaxation.angleGap = MaxAngleErrorAllLoopInDay; end
if exist('MaxMagErrorAllLoopInDay','var'), result.relaxation.magnitudeGap = MaxMagErrorAllLoopInDay; end

result.interval = collect_interval_metrics(result,cfg);
result.summary = summarize_result(result,cfg);

if saveOutput
    methodDir = fullfile(runRoot,runCfg.id);
    if ~exist(methodDir,'dir'), mkdir(methodDir); end
    caseTag = regexprep(lower(runCfg.caseName),'[^a-z0-9_]+','_');
    dayTag = regexprep(lower(runCfg.dayType),'[^a-z0-9]+','_');
    switch lower(runCfg.reserveMode)
        case 'fixed'
            reserveTag=sprintf('alpha%04d',round(1000*runCfg.reserveFixedRatio));
        case 'ai'
            reserveTag='ai';
        case 'global'
            reserveTag='global';
        case 'scheduled'
            reserveTag='explore';
        otherwise
            reserveTag='noreserve';
    end
    fileName = sprintf('%s_%s_decay%03d_seed%03d_%s.mat', ...
        caseTag,dayTag,round(100*runCfg.decayRatio),runCfg.randomSeed,reserveTag);
    outFile = fullfile(methodDir,fileName);
    save(outFile,'result','-v7.3');
    fprintf('Saved: %s\n',outFile);

    if cfg.output.writeSummaryCSV
        append_summary_csv(fullfile(runRoot,'summary.csv'),result.summary);
    end
end
end
