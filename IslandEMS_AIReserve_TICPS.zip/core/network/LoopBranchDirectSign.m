function BranchIndexAndSign=LoopBranchDirectSign(LineBFM,loopNodes,Loops)

for e=1:Loops
    directBrh{e}=[loopNodes{e}(:),loopNodes{e}([2:numel(loopNodes{e}),1]).'];
    BranchIndexAndSign{e}=findBranchIndexAndSign(LineBFM, directBrh{e});
end
function out = findBranchIndexAndSign(LineBFM, v)

    n = size(v,1);
    out = zeros(n,2);  
    
    for k = 1:n
        a = v(k,1);
        b = v(k,2);
    
        idx1 = find(LineBFM(:,1)==a & LineBFM(:,2)==b, 1);
    
        idx2 = find(LineBFM(:,1)==b & LineBFM(:,2)==a, 1);
    
        if ~isempty(idx1)
            out(k,1) = idx1;   
            out(k,2) = 1;      
        elseif ~isempty(idx2)
            out(k,1) = idx2;   
            out(k,2) = -1;     
        else
            error('Cannot find matching branch for [%d %d] in LineBFM.', a, b);
        end
    end
end
end