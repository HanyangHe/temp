function [Bus_Prate,idx_P_DG_GFM,idx_PbattGFM,idx_Pbatt,idx_P_PV,idx_Pbusi,idx_Presi,idx_P_EV] = busdata(residential_node,business_node,BusOfPV,BusOfDieselG,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusNum,PF,residentialPower,businessPower,PVInv_S_rate,DieselG_Pgfm_rate,BatteryGFM_Pgfm_rate,BatteryInv_S_rate,BatteryEV_P_rate)
%BUSDATA Assemble device/load ratings into the inherited bus-data layout.


% Normalize vector orientations so two-subscript assignments are robust.
residentialPower=residentialPower(:);
businessPower=businessPower(:);
PVInv_S_rate=PVInv_S_rate(:);
DieselG_Pgfm_rate=DieselG_Pgfm_rate(:);
BatteryGFM_Pgfm_rate=BatteryGFM_Pgfm_rate(:);
BatteryInv_S_rate=BatteryInv_S_rate(:);
BatteryEV_P_rate=BatteryEV_P_rate(:);

% S_base=x;%VA (1MVA)
% V_base=x;%V (low level distribution network)

% resiLoadNum=length(residential_node);
% busiLoadNum=length(business_node);
% SolarNum=length(BusOfPV);

% residentialPower=[x;x;x;...];%MW
% businessPower=[x;x;...];%MW

% PVInv_S_rate=x;%MW
% BatteryInv_S_rate=x;%MW

Bus_Prate=[];
idx_P_DG_GFM=5;
idx_PbattGFM=7;
idx_Pbatt=9;
idx_P_PV=11;
idx_Pbusi=13;
idx_Presi=15;
idx_Pdtctr=17;
idx_P_EV=19;

for ii=1:BusNum
    % [bus type Psys Qsys P_DG_GFM Q_DG_GFM P_battGFM Q_battGFM P_batt Q_batt P_PV Q_PV P_busi Q_busi P_resi Q_resi P_dtctr Q_dtctr P_EV Q_EV]
    Bus_Prate=[Bus_Prate;ii 0 0 0 0 0 0 0 0 0 0 0 0 0];
end
Bus_Prate(1,2)=1;
Bus_Prate(2:end,2)=3;

if length(residential_node)>0
Bus_Prate(residential_node,idx_Presi)=-residentialPower;
Bus_Prate(residential_node,idx_Presi+1)=-residentialPower*tan(acos(PF));
else
Bus_Prate(residential_node,idx_Presi)=-0;
Bus_Prate(residential_node,idx_Presi+1)=-0;
end

if length(business_node)>0
Bus_Prate(business_node,idx_Pbusi)=-businessPower;
Bus_Prate(business_node,idx_Pbusi+1)=-businessPower*tan(acos(PF));
else
Bus_Prate(business_node,idx_Pbusi)=-0;
Bus_Prate(business_node,idx_Pbusi+1)=-0;
end


if length(BusOfPV)>0
Bus_Prate(BusOfPV,idx_P_PV)=PVInv_S_rate;
else
Bus_Prate(BusOfPV,idx_P_PV)=0;
end

if length(BusOfBattery)>0
Bus_Prate(BusOfBattery,idx_Pbatt)=BatteryInv_S_rate;
else
Bus_Prate(BusOfBattery,idx_Pbatt)=0;
end

if length(BusOfBatteryGFM)>0
Bus_Prate(BusOfBatteryGFM,idx_PbattGFM)=BatteryGFM_Pgfm_rate;
else
Bus_Prate(BusOfBatteryGFM,idx_PbattGFM)=0;
end

if length(BusOfEVBattery)>0
Bus_Prate(BusOfEVBattery,idx_P_EV)=BatteryEV_P_rate;
else
Bus_Prate(BusOfEVBattery,idx_P_EV)=0;
end

if length(BusOfDieselG)>0
Bus_Prate(BusOfDieselG,idx_P_DG_GFM)=DieselG_Pgfm_rate;
else
Bus_Prate(BusOfDieselG,idx_P_DG_GFM)=0;
end
end
