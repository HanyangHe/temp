
function [z, F, exitflag, iter] = newton_pf_fast_diag(z0,Y_Bus, Yinv_DG_GFM, Yinv_Batt_GFM, Yinv_Batt_GFL, Yinv_Batt_EV, Yinv_PV, ...
	        VterDG_GFM_bus, VinvBattGFM_bus, VinvBatt_bus, VinvEVBatt_bus, VinvPV_bus, ...
	        S_load_vec, S_additional, GFMbatt_noPower, batt_noPower, EVbatt_noPower, opt)
	% English comments only
	if ~isfield(opt,'maxIter'),		opt.maxIter = 6; end
	if ~isfield(opt,'tolInf'),		opt.tolInf = 1e-8; end
	if ~isfield(opt,'tolStepInf'),	opt.tolStepInf = 1e-10; end
	if ~isfield(opt,'lineSearch'),	opt.lineSearch = false; end
	if ~isfield(opt,'reg'),			opt.reg = 0; end

    pf = build_pf_cache_diag( ...
	        Y_Bus, Yinv_DG_GFM, Yinv_Batt_GFM, Yinv_Batt_GFL, Yinv_Batt_EV, Yinv_PV, ...
	        VterDG_GFM_bus, VinvBattGFM_bus, VinvBatt_bus, VinvEVBatt_bus, VinvPV_bus, ...
	        S_load_vec, S_additional, GFMbatt_noPower, batt_noPower, EVbatt_noPower);

	z = z0;
	exitflag = 0;

	for iter = 1:opt.maxIter
		[F, J] = pf_FJ_fast_diag(z, pf);

		if norm(F, inf) < opt.tolInf
			exitflag = 1;
			return;
		end

		if opt.reg > 0
			J = J + opt.reg * speye(size(J,1));
		end

		dz = -(J \ F);

		if norm(dz, inf) < opt.tolStepInf
			z = z + dz;
			exitflag = 1;
			[F, ~] = pf_FJ_fast_diag(z, pf);
			return;
		end

		if opt.lineSearch
			alpha = 1;
			nF = norm(F, inf);
			for ls = 1:8
				z_try = z + alpha*dz;
				F_try = pf_F_only_fast_diag(z_try, pf);
				if norm(F_try, inf) < (1 - 1e-4*alpha)*nF
					break;
				end
				alpha = 0.5*alpha;
			end
			z = z + alpha*dz;
		else
			z = z + dz;
		end
	end

	[F, ~] = pf_FJ_fast_diag(z, pf);
end

function pf = build_pf_cache_diag( ...
	Ybus, Yinv_DG_GFM, Yinv_Batt_GFM, Yinv_Batt_GFL, Yinv_Batt_EV, Yinv_PV, ...
	VterDG_GFM_bus, VinvBattGFM_bus, VinvBatt_bus, VinvEVBatt_bus, VinvPV_bus, ...
	S_load, S_additional, GFMbatt_noPower, batt_noPower, EVbatt_noPower)

	% English comments only (per your preference)
	pf.N	= size(Ybus,1);
	pf.Y	= sparse(Ybus);
	pf.Yr	= real(pf.Y);
	pf.Yi	= imag(pf.Y);

	% Extract diagonal admittances as vectors (fast path)
	y_dg	= diag_as_vec(Yinv_DG_GFM);
	y_gfm	= diag_as_vec(Yinv_Batt_GFM);
	y_gfl	= diag_as_vec(Yinv_Batt_GFL);
	y_ev	= diag_as_vec(Yinv_Batt_EV);
	y_pv	= diag_as_vec(Yinv_PV);

	% Apply "no power" flags by zeroing corresponding admittance
	if ~isempty(y_gfm)
		y_gfm(logical(GFMbatt_noPower(:))) = 0;
	end
	if ~isempty(y_gfl)
		y_gfl(logical(batt_noPower(:))) = 0;
	end
	if ~isempty(y_ev)
		y_ev(logical(EVbatt_noPower(:))) = 0;
	end

	% Aggregate inverter current model: Iinv = b_total - y_sum .* V
	pf.y_sum	= safe_add_vec(pf.N, y_dg, y_gfm, y_gfl, y_ev, y_pv);
	pf.b_total	= safe_add_vec(pf.N, ...
		y_gfl .* VinvBatt_bus, ...
		y_gfm .* VinvBattGFM_bus, ...
		y_ev  .* VinvEVBatt_bus, ...
		y_dg  .* VterDG_GFM_bus, ...
		y_pv  .* VinvPV_bus);

	% Constant power terms on RHS (island mode: no grid exchange)
	pf.S_const	= S_load + S_additional;
end

function [F, J] = pf_FJ_fast_diag(z, pf)
	% English comments only
	N = pf.N;
	Vr = z(1:N);
	Vi = z(N+1:end);
	V  = Vr + 1i*Vi;

	% Left term: V .* conj(Y*V)
	Ibus = pf.Y * V;
	left = V .* conj(Ibus);

	% Inverter aggregated: Iinv = b_total - y_sum .* V
	Iinv = pf.b_total - pf.y_sum .* V;
	Sinv = V .* conj(Iinv);

	G = left - (Sinv + pf.S_const);
	F = [real(G); imag(G)];

	% -------- Jacobian --------
	urL = real(Ibus);	uiL = imag(Ibus);

	DVr = spdiags(Vr, 0, N, N);
	DVi = spdiags(Vi, 0, N, N);
	DurL = spdiags(urL, 0, N, N);
	DuiL = spdiags(uiL, 0, N, N);

	% Left Jacobian blocks (sparse)
	JL11 = DurL + DVr*pf.Yr + DVi*pf.Yi;
	JL12 = DuiL + DVr*(-pf.Yi) + DVi*pf.Yr;
	JL21 = -DuiL + DVi*pf.Yr - DVr*pf.Yi;
	JL22 = DurL + DVi*(-pf.Yi) - DVr*pf.Yr;

	% Right inverter Jacobian (diagonal only, very fast)
	u  = Iinv;
	ur = real(u);	ui = imag(u);
	ar = -real(pf.y_sum);
	ai = -imag(pf.y_sum);

	d11 = ur + Vr.*ar + Vi.*ai;
	d12 = ui + Vr.*(-ai) + Vi.*ar;
	d21 = -ui + Vi.*ar - Vr.*ai;
	d22 = ur + Vi.*(-ai) - Vr.*ar;

	JR11 = sparse(1:N, 1:N, d11, N, N);
	JR12 = sparse(1:N, 1:N, d12, N, N);
	JR21 = sparse(1:N, 1:N, d21, N, N);
	JR22 = sparse(1:N, 1:N, d22, N, N);

	J11 = JL11 - JR11;
	J12 = JL12 - JR12;
	J21 = JL21 - JR21;
	J22 = JL22 - JR22;

	J = [J11, J12;
		 J21, J22];
end


function F = pf_F_only_fast_diag(z, pf)
	% English comments only
	N = pf.N;
	Vr = z(1:N);
	Vi = z(N+1:end);
	V  = Vr + 1i*Vi;

	Ibus = pf.Y * V;
	left = V .* conj(Ibus);

	Iinv = pf.b_total - pf.y_sum .* V;
	Sinv = V .* conj(Iinv);

	G = left - (Sinv + pf.S_const);
	F = [real(G); imag(G)];
end


function y = diag_as_vec(Y)
	% English comments only
	if isempty(Y)
		y = [];
		return;
	end
	if issparse(Y)
		y = full(diag(Y));
	else
		y = diag(Y);
	end
end


function s = safe_add_vec(N, varargin)
	% English comments only
	s = zeros(N,1);
	for k = 1:numel(varargin)
		v = varargin{k};
		if ~isempty(v)
			s = s + v;
		end
	end
end