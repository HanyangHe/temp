function [Line_Data, LineLimits, Line_DataBFM, LineLimitsBFM]= linedata(Topology,Z_base,I_base)

% cupper 3ph
k=1;
z_AWG1000=0.010+1j*0.08*k;%ohm/km
z_AWG750=0.025+1j*0.08*k;%ohm/km
z_AWG600=0.03+1j*0.08*k;%ohm/km
z_AWG500=0.08+1j*0.08*k;%ohm/km
z_AWG350=0.11+1j*0.08*k;%ohm/km
z_AWG250=0.15+1j*0.08*k;%ohm/km
z_AWG4_0=0.17+1j*0.08*k;%ohm/km
z_AWG3_0=0.23+1j*0.08*k;%ohm/km
z_AWG2_0=0.29+1j*0.08*k;%ohm/km
z_AWG1_0=0.35+1j*0.08*k;%ohm/km
z_AWG2=0.55+1j*0.08*k;%ohm/km
z_AWG3=0.90+1j*0.08*k;%ohm/km
z_AWG4=1.13+1j*0.08*k;%ohm/km
z_AWG6=1.40+1j*0.08*k;%ohm/km
z_AWG8=2.18+1j*0.08*k;%ohm/km
z_AWG10=3.45+1j*0.08*k;%ohm/km

% branch current limit (75°C)
k=1;
lmt_AWG1000=545*k;%A
lmt_AWG750=475*k;%A
lmt_AWG600=420*k;%A
lmt_AWG500=380*k;%A
lmt_AWG350=310*k;%A
lmt_AWG250=255*k;%A
lmt_AWG4_0=230*k;%A
lmt_AWG3_0=200*k;%A
lmt_AWG2_0=175*k;%A
lmt_AWG1_0=150*1.1*k;%A
lmt_AWG2=115*k;%A
lmt_AWG3=100*k;%A
lmt_AWG4=85*k;%A
lmt_AWG6=65*k;%A
lmt_AWG8=50*k;%A
lmt_AWG10=35*1.1*k;%A

BranchLength_long=120/1000;%km
BranchLength_main=80/1000;%km
BranchLength_sub=30/1000;%km

%            |From  |     |To    |     |R      |      |X     | 
%            |Bus   |     |Bus   |     |p.u.   |      |p.u.  | 
% Line_Data = [   1           3          0.2587500    0.0153750 ;
%                 3           6          0.4802811    0.0708750 ;
%                 3	        10	       0.0621250    0.0181562 ;
%                 10	        2	       0.6918750    0.0176250 ;
%                 3           4          0.124250     0.0363124 ;
%                 4           5          0.1633125    0.0151875 ;
%                 4           7          0.1863750    0.0544686 ;
%                 7           9          0.6918750    0.0176250 ;
%                 7           8          0.320875     0.0335312
%             ];
% line1_3=310/I_base;% AWG 350
% line3_6=175/I_base;% AWG 2/0
% line3_10=230/I_base;% AWG 4/0
% line2_10=35/I_base; % AWG 10
% line3_4=350/I_base;% AWG 400
% line4_5=100/I_base; % AWG 3
% line4_7=230/I_base;% AWG 4/0
% line7_9=35/I_base; % AWG 10
% line7_8=100/I_base;% AWG 3
% LineLimits=[line1_3;line3_6;line3_10;line2_10;line3_4;line4_5;line4_7;line7_9;line7_8];

if strcmp(Topology, '10bus')
% Line_Data = [   1           3          BranchLength_main*real(z_AWG500)   BranchLength_main*imag(z_AWG500);
%                 3           6          BranchLength_main*real(z_AWG8)   BranchLength_main*imag(z_AWG8);
%                 3	        10	       BranchLength_main*real(z_AWG4_0)   BranchLength_main*imag(z_AWG4_0);
%                 10	        2	       BranchLength_main*real(z_AWG10)   BranchLength_main*imag(z_AWG10);
%                 3           4          BranchLength_main*real(z_AWG350)   BranchLength_main*imag(z_AWG350);
%                 4           5          BranchLength_main*real(z_AWG6)   BranchLength_main*imag(z_AWG6);
%                 4           7          BranchLength_main*real(z_AWG2_0)   BranchLength_main*imag(z_AWG2_0);
%                 7           9          BranchLength_main*real(z_AWG10)   BranchLength_main*imag(z_AWG10);
%                 7           8          BranchLength_main*real(z_AWG6)   BranchLength_main*imag(z_AWG6);
%             ];
Line_Data = [ 
                1           3          BranchLength_main*real(z_AWG2_0)/2   BranchLength_main*imag(z_AWG2_0)/2;
                3           6          BranchLength_main*real(z_AWG8)   BranchLength_main*imag(z_AWG8);
                3	        10	       BranchLength_main*real(z_AWG4_0)   BranchLength_main*imag(z_AWG4_0);
                10	        2	       BranchLength_main*real(z_AWG10)   BranchLength_main*imag(z_AWG10);
                3           4          BranchLength_main*real(z_AWG1_0)/2   BranchLength_main*imag(z_AWG1_0)/2;
                4           5          BranchLength_main*real(z_AWG6)   BranchLength_main*imag(z_AWG6);
                4           7          BranchLength_main*real(z_AWG2_0)   BranchLength_main*imag(z_AWG2_0);
                7           9          BranchLength_main*real(z_AWG10)   BranchLength_main*imag(z_AWG10);
                7           8          BranchLength_main*real(z_AWG6)   BranchLength_main*imag(z_AWG6);
            ];
Line_Data(:,3:4)=Line_Data(:,3:4)/Z_base;

LineLimits = [
            lmt_AWG2_0*2;
            lmt_AWG8;
            lmt_AWG4_0;
            lmt_AWG10;
            lmt_AWG1_0*2;
            lmt_AWG6;
            lmt_AWG2_0;
            lmt_AWG10;
            lmt_AWG6
            ]/I_base;

Line_DataBFM=[0           1          1e2 1e2;% used for algorithm only
              Line_Data];
LineLimitsBFM=[0;% used for algorithm only
               LineLimits];

elseif strcmp(Topology, '10bus_loop')

Line_Data = [ 
                1           3          BranchLength_main*real(z_AWG2_0)/2   BranchLength_main*imag(z_AWG2_0)/2;
                3           6          BranchLength_main*real(z_AWG8)   BranchLength_main*imag(z_AWG8);
                3	        10	       BranchLength_main*real(z_AWG1_0)   BranchLength_main*imag(z_AWG1_0);
                10	        2	       BranchLength_main*real(z_AWG10)   BranchLength_main*imag(z_AWG10);
                3           4          BranchLength_main*real(z_AWG1_0)/2   BranchLength_main*imag(z_AWG1_0)/2;
                4           5          BranchLength_main*real(z_AWG6)   BranchLength_main*imag(z_AWG6);
                4           7          BranchLength_main*real(z_AWG2_0)   BranchLength_main*imag(z_AWG2_0);
                7           9          BranchLength_main*real(z_AWG10)   BranchLength_main*imag(z_AWG10);
                7           8          BranchLength_main*real(z_AWG6)   BranchLength_main*imag(z_AWG6);
                1           5          BranchLength_main*real(z_AWG1_0)   BranchLength_main*imag(z_AWG1_0);
                2           7          BranchLength_main*real(z_AWG1_0)   BranchLength_main*imag(z_AWG1_0);
            ];
Line_Data(:,3:4)=Line_Data(:,3:4)/Z_base;

LineLimits = [
            lmt_AWG2_0*2;
            lmt_AWG8;
            lmt_AWG1_0;
            lmt_AWG10;
            lmt_AWG1_0*2;
            lmt_AWG6;
            lmt_AWG2_0;
            lmt_AWG10;
            lmt_AWG6;
            lmt_AWG1_0;
            lmt_AWG1_0
            ]/I_base;

Line_DataBFM=[0           1          1e2 1e2;% used for algorithm only
              Line_Data];
LineLimitsBFM=[0;% used for algorithm only
               LineLimits];

elseif strcmp(Topology, '18bus-CIRED')
Line_Data = [  
            1   2   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
            2   3   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
            3   4   BranchLength_main*real(z_AWG600)   BranchLength_main*imag(z_AWG600);
            4   5   BranchLength_main*real(z_AWG350)   BranchLength_main*imag(z_AWG350);
            5   6   BranchLength_main*real(z_AWG350)   BranchLength_main*imag(z_AWG350);
            6   7   BranchLength_long*real(z_AWG1_0)   BranchLength_long*imag(z_AWG1_0);
            7   8   BranchLength_long*real(z_AWG1_0)   BranchLength_long*imag(z_AWG1_0);
            8   9   BranchLength_long*real(z_AWG1_0)   BranchLength_long*imag(z_AWG1_0);
            9   10  BranchLength_main*real(z_AWG1_0)   BranchLength_main*imag(z_AWG1_0);
            3   11  BranchLength_sub*real(z_AWG6)   BranchLength_sub*imag(z_AWG6);
            4   12  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
            12  13  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
            13  14  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
            14  15  BranchLength_sub*real(z_AWG250)   BranchLength_sub*imag(z_AWG250);
            6   16  BranchLength_sub*real(z_AWG250)   BranchLength_sub*imag(z_AWG250);
            9   17  BranchLength_sub*real(z_AWG2_0)   BranchLength_sub*imag(z_AWG2_0);
            10  18  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
            ];
Line_Data(:,3:4)=Line_Data(:,3:4)/Z_base;

LineLimits = [
              lmt_AWG750;
              lmt_AWG750;
              lmt_AWG600;
              lmt_AWG350;
              lmt_AWG350;
              lmt_AWG1_0;
              lmt_AWG1_0;
              lmt_AWG1_0;
              lmt_AWG1_0;
              lmt_AWG6;
              lmt_AWG1_0;
              lmt_AWG1_0;
              lmt_AWG1_0;
              lmt_AWG250;
              lmt_AWG250;
              lmt_AWG2_0;
              lmt_AWG1_0
            ]/I_base;

Line_DataBFM=[0           1          1e2 1e2;% used for algorithm only
              Line_Data];
LineLimitsBFM=[0;% used for algorithm only
               LineLimits];

elseif strcmp(Topology, '18bus-CIRED_loop')
Line_Data = [  
            1   2   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
            2   3   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
            3   4   BranchLength_main*real(z_AWG600)   BranchLength_main*imag(z_AWG600);
            4   5   BranchLength_main*real(z_AWG350)   BranchLength_main*imag(z_AWG350);
            5   6   BranchLength_main*real(z_AWG350)   BranchLength_main*imag(z_AWG350);
            6   7   BranchLength_long*real(z_AWG1_0)   BranchLength_long*imag(z_AWG1_0);
            7   8   BranchLength_long*real(z_AWG1_0)   BranchLength_long*imag(z_AWG1_0);
            8   9   BranchLength_long*real(z_AWG1_0)   BranchLength_long*imag(z_AWG1_0);
            9   10  BranchLength_main*real(z_AWG1_0)   BranchLength_main*imag(z_AWG1_0);
            3   11  BranchLength_sub*real(z_AWG6)   BranchLength_sub*imag(z_AWG6);
            4   12  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
            12  13  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
            13  14  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
            14  15  BranchLength_sub*real(z_AWG250)   BranchLength_sub*imag(z_AWG250);
            6   16  BranchLength_sub*real(z_AWG250)   BranchLength_sub*imag(z_AWG250);
            9   17  BranchLength_sub*real(z_AWG2_0)   BranchLength_sub*imag(z_AWG2_0);
            17  18  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
            1   12  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
            11  16  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
            ];
Line_Data(:,3:4)=Line_Data(:,3:4)/Z_base;

LineLimits = [
              lmt_AWG750;
              lmt_AWG750;
              lmt_AWG600;
              lmt_AWG350;
              lmt_AWG350;
              lmt_AWG1_0;
              lmt_AWG1_0;
              lmt_AWG1_0;
              lmt_AWG1_0;
              lmt_AWG6;
              lmt_AWG1_0;
              lmt_AWG1_0;
              lmt_AWG1_0;
              lmt_AWG250;
              lmt_AWG250;
              lmt_AWG2_0;
              lmt_AWG1_0;
              lmt_AWG1_0;
              lmt_AWG1_0;
            ]/I_base;

Line_DataBFM=[0           1          1e2 1e2;% used for algorithm only
              Line_Data];
LineLimitsBFM=[0;% used for algorithm only
               LineLimits];

elseif strcmp(Topology, '33bus-IEEE')
Line_Data = [  
            1   2   BranchLength_main*real(z_AWG600)/3   BranchLength_main*imag(z_AWG600)/3;%1
            2   3   BranchLength_main*real(z_AWG350)/3   BranchLength_main*imag(z_AWG350)/3;%2
            3   4   BranchLength_main*real(z_AWG250)/3   BranchLength_main*imag(z_AWG250)/3;%3
            4   5   BranchLength_main*real(z_AWG250)/3   BranchLength_main*imag(z_AWG250)/3;%4
            5   6   BranchLength_main*real(z_AWG250)/3   BranchLength_main*imag(z_AWG250)/3;%5
            6   7   BranchLength_main*real(z_AWG2_0)/2   BranchLength_main*imag(z_AWG2_0)/2;%6
            7   8   BranchLength_main*real(z_AWG2_0)/2   BranchLength_main*imag(z_AWG2_0)/2;%7
            8   9   BranchLength_main*real(z_AWG2_0)/2   BranchLength_main*imag(z_AWG2_0)/2;%8
            9   10   BranchLength_main*real(z_AWG2_0)/2   BranchLength_main*imag(z_AWG2_0)/2;%9
            10  11   BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%10
            11  12   BranchLength_sub*real(z_AWG2)/2   BranchLength_sub*imag(z_AWG2)/2;%11
            12  13   BranchLength_sub*real(z_AWG2)/2   BranchLength_sub*imag(z_AWG2)/2;%12
            13  14   BranchLength_sub*real(z_AWG4)/2   BranchLength_sub*imag(z_AWG4)/2;%13
            14  15   BranchLength_sub*real(z_AWG2)   BranchLength_sub*imag(z_AWG2);%14
            15  16   BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);%15
            16  17   BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);%16
            17  18   BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);%17
            2   19  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%18
            19  20  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%19
            20  21  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%20
            21  22  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%21
            3   23  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%22
            23  24  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%23
            24  25  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%24
            6   26  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%25
            26  27  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%26
            27  28  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%27
            28  29  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%28
            29  30  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%29
            30  31  BranchLength_sub*real(z_AWG2_0)/2   BranchLength_sub*imag(z_AWG2_0)/2;%30
            31  32  BranchLength_sub*real(z_AWG2_0)/2   BranchLength_sub*imag(z_AWG2_0)/2;%31
            32  33  BranchLength_sub*real(z_AWG2_0)/2   BranchLength_sub*imag(z_AWG2_0)/2;%32
            ];
Line_Data(:,3:4)=Line_Data(:,3:4)/Z_base;

LineLimits = [
              3*lmt_AWG600;%1
              3*lmt_AWG350;%2
              3*lmt_AWG250;%3
              3*lmt_AWG250;%4
              3*lmt_AWG250;%5
              2*lmt_AWG2_0;%6
              2*lmt_AWG2_0;%7
              2*lmt_AWG2_0;%8
              2*lmt_AWG2_0;%9
              2*lmt_AWG1_0;%10
              2*lmt_AWG2;%11
              2*lmt_AWG2;%12
              2*lmt_AWG4;%13
              lmt_AWG2;%14
              lmt_AWG1_0;%15
              lmt_AWG1_0;%16
              lmt_AWG1_0;%17
              2*lmt_AWG1_0;%18
              2*lmt_AWG1_0;%19
              2*lmt_AWG1_0;%20
              2*lmt_AWG1_0;%21
              2*lmt_AWG1_0;%22
              2*lmt_AWG1_0;%23
              2*lmt_AWG1_0;%24
              2*lmt_AWG1_0;%25
              2*lmt_AWG1_0;%26
              2*lmt_AWG1_0;%27
              2*lmt_AWG1_0;%28
              2*lmt_AWG1_0;%29
              2*lmt_AWG2_0;%30
              2*lmt_AWG2_0;%31
              2*lmt_AWG2_0;%32
            ]/I_base;

Line_DataBFM=[0           1          1e2 1e2;% used for algorithm only
              Line_Data];
LineLimitsBFM=[0;% used for algorithm only
               LineLimits];

elseif strcmp(Topology, '33bus-IEEE_loop')
Line_Data = [  
            1   2   BranchLength_main*real(z_AWG600)/3   BranchLength_main*imag(z_AWG600)/3;%1
            2   3   BranchLength_main*real(z_AWG350)/3   BranchLength_main*imag(z_AWG350)/3;%2
            3   4   BranchLength_main*real(z_AWG250)/3   BranchLength_main*imag(z_AWG250)/3;%3
            4   5   BranchLength_main*real(z_AWG250)/3   BranchLength_main*imag(z_AWG250)/3;%4
            5   6   BranchLength_main*real(z_AWG250)/3   BranchLength_main*imag(z_AWG250)/3;%5
            6   7   BranchLength_main*real(z_AWG2_0)/2   BranchLength_main*imag(z_AWG2_0)/2;%6
            7   8   BranchLength_main*real(z_AWG2_0)/2   BranchLength_main*imag(z_AWG2_0)/2;%7
            8   9   BranchLength_main*real(z_AWG2_0)/2   BranchLength_main*imag(z_AWG2_0)/2;%8
            9   10   BranchLength_main*real(z_AWG2_0)/2   BranchLength_main*imag(z_AWG2_0)/2;%9
            10  11   BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%10
            11  12   BranchLength_sub*real(z_AWG2)/2   BranchLength_sub*imag(z_AWG2)/2;%11
            12  13   BranchLength_sub*real(z_AWG2)/2   BranchLength_sub*imag(z_AWG2)/2;%12
            13  14   BranchLength_sub*real(z_AWG4)/2   BranchLength_sub*imag(z_AWG4)/2;%13
            14  15   BranchLength_sub*real(z_AWG2)   BranchLength_sub*imag(z_AWG2);%14
            15  16   BranchLength_sub*real(z_AWG3)   BranchLength_sub*imag(z_AWG3);%15
            16  17   BranchLength_sub*real(z_AWG3)   BranchLength_sub*imag(z_AWG3);%16
            17  18   BranchLength_sub*real(z_AWG3)   BranchLength_sub*imag(z_AWG3);%17
            2   19  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%18
            19  20  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%19
            20  21  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%20
            21  22  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%21
            3   23  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%22
            23  24  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%23
            24  25  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%24
            6   26  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%25
            26  27  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%26
            27  28  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%27
            28  29  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%28
            29  30  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;%29
            30  31  BranchLength_sub*real(z_AWG2_0)/2   BranchLength_sub*imag(z_AWG2_0)/2;%30
            31  32  BranchLength_sub*real(z_AWG2_0)/2   BranchLength_sub*imag(z_AWG2_0)/2;%31
            32  33  BranchLength_sub*real(z_AWG2_0)/2   BranchLength_sub*imag(z_AWG2_0)/2;%32
            8   21  BranchLength_main*real(z_AWG2_0)/2   BranchLength_main*imag(z_AWG2_0)/2;
            12  22  BranchLength_sub*real(z_AWG2)/2   BranchLength_sub*imag(z_AWG2)/2;
            25  29  BranchLength_sub*real(z_AWG1_0)/2   BranchLength_sub*imag(z_AWG1_0)/2;
            ];
Line_Data(:,3:4)=Line_Data(:,3:4)/Z_base;

LineLimits = [
              3*lmt_AWG600;%1
              3*lmt_AWG350;%2
              3*lmt_AWG250;%3
              3*lmt_AWG250;%4
              3*lmt_AWG250;%5
              2*lmt_AWG2_0;%6
              2*lmt_AWG2_0;%7
              2*lmt_AWG2_0;%8
              2*lmt_AWG2_0;%9
              2*lmt_AWG1_0;%10
              2*lmt_AWG2;%11
              2*lmt_AWG2;%12
              2*lmt_AWG4;%13
              lmt_AWG2;%14
              lmt_AWG3;%15
              lmt_AWG3;%16
              lmt_AWG3;%17
              2*lmt_AWG1_0;%18
              2*lmt_AWG1_0;%19
              2*lmt_AWG1_0;%20
              2*lmt_AWG1_0;%21
              2*lmt_AWG1_0;%22
              2*lmt_AWG1_0;%23
              2*lmt_AWG1_0;%24
              2*lmt_AWG1_0;%25
              2*lmt_AWG1_0;%26
              2*lmt_AWG1_0;%27
              2*lmt_AWG1_0;%28
              2*lmt_AWG1_0;%29
              2*lmt_AWG2_0;%30
              2*lmt_AWG2_0;%31
              2*lmt_AWG2_0;%32
              lmt_AWG2_0;
              lmt_AWG2;
              lmt_AWG1_0;
            ]/I_base;

Line_DataBFM=[0           1          1e2 1e2;% used for algorithm only
              Line_Data];
LineLimitsBFM=[0;% used for algorithm only
               LineLimits];

% elseif strcmp(Topology, '69bus-IEEE')
% Line_Data = [
%             1   2   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             2   3   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             3   4   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             4   5   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             5   6   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             6   7   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             7   8   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             8   9   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             9   10   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             10  11   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             11  12   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             12  13   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             13  14   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             14  15   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             15  16   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             16  17   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             17  18   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             18  19   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             19  20   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             20  21   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             21  22   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             22  23   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             23  24   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             24  25   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             25  26   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             26  27   BranchLength_main*real(z_AWG750)   BranchLength_main*imag(z_AWG750);
%             3   28  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             28  29  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             29  30  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             30  31  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             31  32  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             32  33  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             33  34  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             34  35  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             4   47  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             47  48  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             48  49  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             49  50  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             8   51  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             51  52  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             9   53  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             53  54  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             54  55  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             55  56  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             56  57  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             57  58  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             58  59  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             59  60  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             60  61  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             61  62  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             62  63  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             63  64  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             64  65  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             11  66  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             66  67  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             12  68  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             68  69  BranchLength_sub*real(z_AWG1_0)   BranchLength_sub*imag(z_AWG1_0);
%             ];
% Line_Data(:,3:4)=Line_Data(:,3:4)/Z_base;
% 
% LineLimits = 10*[lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;
%               lmt_AWG750;%26-27
%               lmt_AWG1_0;%3-28
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;%34-35
%               lmt_AWG1_0;%4-47
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;%49-50
%               lmt_AWG1_0;%8-51
%               lmt_AWG1_0;%51-52
%               lmt_AWG1_0;%9-53
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;
%               lmt_AWG1_0;%64-65
%               lmt_AWG1_0;%11-66
%               lmt_AWG1_0;%66-67
%               lmt_AWG1_0;%12-68
%               lmt_AWG1_0;%68-69
%             ]/I_base;
% Line_DataBFM=[0           1          1e9 1e9;% used for algorithm only
%               Line_Data];
% LineLimitsBFM=[0;% used for algorithm only
%                LineLimits];
end

end

