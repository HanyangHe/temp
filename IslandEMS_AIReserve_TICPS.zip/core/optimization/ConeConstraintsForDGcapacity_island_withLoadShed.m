function [Asc_ass_cell,bsc_ass_cell,dsc_ass_cell,gamma_ass_cell]=ConeConstraintsForDGcapacity_island_withLoadShed(S_DGmax,S_battGFMmax,S_battmax,S_RESmax,Line,Kday,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,Nload)

Nbus = max(Line(:,2));
Nbranch = size(Line,1);     
N_DG_GFM = length(BusOfDieselG_GFM);
NbattGFM = length(BusOfBatteryGFM);
Nbatt = length(BusOfBattery);
NbattEV = length(BusOfEVBattery);
N_res = length(BusOfPV);

Col = 2*Kday*(N_DG_GFM+N_res) +(2*Kday)*NbattEV + 3*Kday*(NbattGFM+Nbatt) +Kday*(3*Nbranch+Nbus)+Kday*Nload;

% assembly matrix
Asc_ass_cell= cell((N_DG_GFM+N_res+NbattGFM+Nbatt)*Kday,1);
bsc_ass_cell = cell(N_DG_GFM*Kday,1);
dsc_ass_cell = cell(N_DG_GFM*Kday,1);
gamma_ass_cell = cell(N_DG_GFM*Kday,1);

idx=1;
for ii=1:N_DG_GFM
    for k=1:Kday
        Asc = zeros(2, Col); 
        Asc(1,2*Kday*(ii-1) + k)=1;
        Asc(2,2*Kday*(ii-1) + Kday+ k)=1;
        Asc_ass_cell{idx}=Asc;
        bsc_ass_cell{idx}=zeros(2,1);
        dsc_ass_cell{idx}=zeros(Col,1);
        gamma_ass_cell{idx}=-S_DGmax(BusOfDieselG_GFM(ii),1);
        idx=idx+1;
    end
end
for ii=1:NbattGFM
    for k=1:Kday
        Asc = zeros(2, Col); 
        Asc(1,2*Kday*N_DG_GFM+3*Kday*(ii-1) + k)=1;
        Asc(1,2*Kday*N_DG_GFM+3*Kday*(ii-1) + Kday+ k)=-1;
        Asc(2,2*Kday*N_DG_GFM+3*Kday*(ii-1) + 2*Kday+ k)=1;
        Asc_ass_cell{idx}=Asc;
        bsc_ass_cell{idx}=zeros(2,1);
        dsc_ass_cell{idx}=zeros(Col,1);
        gamma_ass_cell{idx}=-S_battGFMmax(BusOfBatteryGFM(ii),1);
        idx=idx+1;
    end
end
for ii=1:Nbatt
    for k=1:Kday
        Asc = zeros(2, Col); 
        Asc(1,2*Kday*N_DG_GFM+3*Kday*NbattGFM+3*Kday*(ii-1) + k)=1;
        Asc(1,2*Kday*N_DG_GFM+3*Kday*NbattGFM+3*Kday*(ii-1) + Kday+ k)=-1;
        Asc(2,2*Kday*N_DG_GFM+3*Kday*NbattGFM+3*Kday*(ii-1) + 2*Kday+ k)=1;
        Asc_ass_cell{idx}=Asc;
        bsc_ass_cell{idx}=zeros(2,1);
        dsc_ass_cell{idx}=zeros(Col,1);
        gamma_ass_cell{idx}=-S_battmax(BusOfBattery(ii),1);
        idx=idx+1;
    end
end
for ii=1:N_res
    for k=1:Kday
        Asc = zeros(2, Col); 
        Asc(1,2*Kday*(N_DG_GFM)+(2*Kday)*NbattEV+3*Kday*(NbattGFM+Nbatt)+2*Kday*(ii-1) + k)=1;
        Asc(2,2*Kday*(N_DG_GFM)+(2*Kday)*NbattEV+3*Kday*(NbattGFM+Nbatt)+2*Kday*(ii-1) + Kday+ k)=1;
        Asc_ass_cell{idx}=Asc;
        bsc_ass_cell{idx}=zeros(2,1);
        dsc_ass_cell{idx}=zeros(Col,1);
        gamma_ass_cell{idx}=-S_RESmax(BusOfPV(ii),1);
        idx=idx+1;
    end
end
end