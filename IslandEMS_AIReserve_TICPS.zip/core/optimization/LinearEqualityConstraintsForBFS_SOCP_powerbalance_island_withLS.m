function [Aeq_grid,beq_grid]=LinearEqualityConstraintsForBFS_SOCP_powerbalance_island_withLS(Line,V_slack,Kday,Sinj_bus,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,BusOfload)
% Note: the root bus need to be defined as 1

Nbus = max(Line(:,2));     
Nbranch = size(Line,1);
N_DG_GFM = length(BusOfDieselG_GFM);
NbattGFM = length(BusOfBatteryGFM);
Nbatt = length(BusOfBattery);
NbattEV = length(BusOfEVBattery);
N_res = length(BusOfPV);
Nload = length(BusOfload);

% index of the decision variable, which is the column index of Aeq
idx_P = 1:Nbranch;
idx_Q = Nbranch+1:2*Nbranch;
idx_l = 2*Nbranch+1:3*Nbranch;
idx_v = 3*Nbranch+1:3*Nbranch+Nbus;

Aeq = []; 
beq = [];

offset = 2*Kday*(N_DG_GFM+N_res)+(2*Kday)*NbattEV+3*Kday*(NbattGFM+Nbatt)+Kday*Nload;
totalVars = 3*Nbranch+Nbus;

Aeq_grid=[];
beq_grid=[];

rowPvec=[];
for step=1:Kday
    % --- row number
    row = 1; 
    for e = 1:Nbus
        rowPvec(e)=row;
        rowQvec(e)=row+1;

	    OUTbus = Line(e,2);
	    % r_e    = Line(e,3);
        % x_e    = Line(e,4);

	    % ----------（1）power balance equation----------
        % branch power at the up-stream branch of OutBus-bus j
        father_branch = find(Line(:,2)==OUTbus);
        for k = father_branch(:)'
            r_e    = Line(k,3);
            x_e    = Line(k,4);
	        Aeq(row, idx_P(k)) = 1;  
            Aeq(row, idx_l(k)) = -r_e;
            Aeq(row+1, idx_Q(k)) = 1;  
            Aeq(row+1, idx_l(k)) = -x_e;
        end
    
	    % downstream branch start at OUTbus
	    child_branch = find(Line(:,1)==OUTbus);
	    for k = child_branch(:)'
		    Aeq(row, idx_P(k)) = -1; 
            Aeq(row+1, idx_Q(k)) = -1; 
	    end
	    
    
	    % if there is node injection power at the right side (ejection side),
        % and then here with "-".
	    beq(row,1) = -real(Sinj_bus(OUTbus,step)); % node injection power P
        beq(row+1,1) = -imag(Sinj_bus(OUTbus,step)); % node injection power Q
    
	    % ----------（2）voltage drop equation-----------
        row=row+2;
        for k = father_branch(:)'% more general version for mesh grid   
            INbus  = Line(k,1);
            r_e    = Line(k,3);
            x_e    = Line(k,4);
            % save all downstream voltage 2~Nbus at the last Nbranch colcumn
	        Aeq(row, idx_v(OUTbus)) = 1;
            if INbus==0
                % root voltage is given at 1pu, and move into the right side
                % coefficient vector
		        beq(row,1) = V_slack;
            else
	            Aeq(row, idx_v(INbus))  = -1;
                beq(row,1) = 0;
            end
	        Aeq(row, idx_l(k))      = -r_e^2-x_e^2;
	        Aeq(row, idx_P(k))      = 2*r_e;
            Aeq(row, idx_Q(k))      = 2*x_e;

            row=row+1;
        end
    end
    
    Aeq_extd = zeros(size(Aeq,1), offset+totalVars*Kday); 
    Aeq_extd(:,offset+1+(step-1)*totalVars:offset+step*totalVars)=Aeq;


    if N_DG_GFM~=0
    for dg_idx = 1:N_DG_GFM
        ii = BusOfDieselG_GFM(dg_idx);  % DG node number
        base = 2*Kday*(dg_idx-1);   % start location of the DG variable sequence
        col_Pdis = base + step;
        col_Qdg = base + Kday + step;
    
        branchNum = find(Line(:,2)==ii,1); %  branch ( node is the downstream node, branch number is the row number of that branch in the Line matrix)
        Aeq_extd(rowPvec(branchNum), col_Pdis) = 1;
        Aeq_extd(rowQvec(branchNum), col_Qdg) = 1;
    end
    end

    if NbattGFM~=0
    for batGFM_idx = 1:NbattGFM
        ii = BusOfBatteryGFM(batGFM_idx);  %  node number
        base = 2*Kday*N_DG_GFM+3*Kday*(batGFM_idx-1);   % start location of the battery variable sequence
        col_Pdis = base + step;
        col_Pch  = base + Kday + step;
        col_Q_GFM = base + 2*Kday + step;
        
        branchNum = find(Line(:,2)==ii,1); %  branch ( node is the downstream node, branch number is the row number of that branch in the Line matrix)
        Aeq_extd(rowPvec(branchNum), col_Pdis) = 1;
        Aeq_extd(rowPvec(branchNum), col_Pch)  = -1;
        Aeq_extd(rowQvec(branchNum), col_Q_GFM) = 1;
    end
    end

    if Nbatt~=0
    for bat_idx = 1:Nbatt
        ii = BusOfBattery(bat_idx);  %  node number
        base = 2*Kday*N_DG_GFM+3*Kday*(NbattGFM+bat_idx-1);   % start location of the battery variable sequence
        col_Pdis = base + step;
        col_Pch  = base + Kday + step;
        col_Qbatt = base + 2*Kday + step;
    
        branchNum = find(Line(:,2)==ii,1); %  branch (battery node is the downstream node, branch number is the row number of that branch in the Line matrix)
        Aeq_extd(rowPvec(branchNum), col_Pdis) = 1;
        Aeq_extd(rowPvec(branchNum), col_Pch)  = -1;
        Aeq_extd(rowQvec(branchNum), col_Qbatt) = 1;
    end
    end

    if NbattEV~=0
    for batEV_idx = 1:NbattEV
        ii = BusOfEVBattery(batEV_idx);  %  node number
        base = 2*Kday*N_DG_GFM+ (2*Kday)*(batEV_idx-1)+3*Kday*(NbattGFM+Nbatt);   % start location of the battery variable sequence
        col_Pdis = base + step;
        col_Pch  = col_Pdis + Kday;
    
        branchNum = find(Line(:,2)==ii,1); %  branch (node is the downstream node, branch number is the row number of that branch in the Line matrix)
        Aeq_extd(rowPvec(branchNum), col_Pdis) = 1;
        Aeq_extd(rowPvec(branchNum), col_Pch)  = -1;
    end
    end
    
    if N_res~=0
    for res_idx = 1:N_res
        ii = BusOfPV(res_idx);  % RES node number
        base = 2*Kday*(N_DG_GFM+res_idx-1)+(2*Kday)*NbattEV+3*Kday*(NbattGFM+Nbatt);   % start location of the battery variable sequence
        col_Pres = base + step;
        col_Qres = base + Kday + step;
    
        branchNum = find(Line(:,2)==ii,1); 
        Aeq_extd(rowPvec(branchNum), col_Pres) = 1;
        Aeq_extd(rowQvec(branchNum), col_Qres) = 1;
    end
    end

    if Nload~=0
    for load_idx = 1:Nload
        ii = BusOfload(load_idx);  % DG node number
        base = 2*Kday*(N_DG_GFM+N_res)+(2*Kday)*NbattEV+3*Kday*(NbattGFM+Nbatt)+Kday*(load_idx-1);   % start location of the DG variable sequence
        col_dPload = base + step;
    
        branchNum = find(Line(:,2)==ii,1); %  branch ( node is the downstream node, branch number is the row number of that branch in the Line matrix)
        Aeq_extd(rowPvec(branchNum), col_dPload) = 1;
    end
    end

    Aeq_grid=[Aeq_grid;Aeq_extd];
    
    beq_grid=[beq_grid;beq];
end

end