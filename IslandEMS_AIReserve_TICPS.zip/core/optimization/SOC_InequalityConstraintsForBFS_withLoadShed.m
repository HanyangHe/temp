function [A_SOC,b_SOC]=SOC_InequalityConstraintsForBFS_withLoadShed(Kday,SOCmax,SOCmin,SOC0,EbattMaxGFM,EbattMax,EbattMaxEV,inta_batt_ch,inta_batt_dis,DG_GFM_num,BatteryGFM_Num,BatteryNum,EVBatteryNum,SolarNum,loadNum,Nbranch,Nbus,dt_sys)

EbattMaxGFM=EbattMaxGFM(:);
EbattMax=EbattMax(:);
EbattMaxEV=EbattMaxEV(:);

idx_A=0;
idx_A_col=0;
idx_b=0;


b_SOC=zeros(Kday*2*(BatteryNum+BatteryGFM_Num+EVBatteryNum),1);
for ii=1:(BatteryNum+BatteryGFM_Num+EVBatteryNum)
    if ii<=BatteryGFM_Num +BatteryNum
        b_SOC(idx_b+1:idx_b+Kday,1)=(SOCmax-SOC0(ii,1))*ones(Kday,1);idx_b=idx_b+Kday;
        b_SOC(idx_b+1:idx_b+Kday,1)=(SOC0(ii,1)-SOCmin)*ones(Kday,1);idx_b=idx_b+Kday;
        b_SOC(idx_b,1)=SOC0(ii,1)-SOC0(ii,1);%total charge >= total discharge in a day
    else
        b_SOC(idx_b+1:idx_b+Kday,1)=(SOCmax-SOC0(ii,1))*ones(Kday,1);
        b_SOC(idx_b+Kday,1)=SOCmax-SOC0(ii,1);% SOCendCh<=SOCmax
        idx_b=idx_b+Kday;
        b_SOC(idx_b+1:idx_b+Kday,1)=(SOC0(ii,1)-SOCmin)*ones(Kday,1);
        b_SOC(idx_b+Kday,1)=SOC0(ii,1)-SOCmax;% SOCendCh>=SOCmax
        idx_b=idx_b+Kday;
    end
end

A_SOC0=zeros(length(b_SOC),(BatteryNum+BatteryGFM_Num)*3*Kday+EVBatteryNum*2*Kday);
for ii=1:(BatteryNum+BatteryGFM_Num+EVBatteryNum)
    if ii<=BatteryGFM_Num
        E=EbattMaxGFM(ii);
        for i=1:Kday
            A_SOC0(idx_A+i,idx_A_col+1:idx_A_col+i)=-1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=inta_batt_ch/E*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+1:idx_A_col+i)=1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=-inta_batt_ch/E*dt_sys;
        end
        idx_A_col=idx_A_col+3*Kday;
    elseif ii>BatteryGFM_Num && ii<=BatteryNum+BatteryGFM_Num
        jj=ii-BatteryGFM_Num; E=EbattMax(jj);
        for i=1:Kday
            A_SOC0(idx_A+i,idx_A_col+1:idx_A_col+i)=-1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=inta_batt_ch/E*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+1:idx_A_col+i)=1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=-inta_batt_ch/E*dt_sys;
        end
        idx_A_col=idx_A_col+3*Kday;
    else
        jj=ii-BatteryGFM_Num-BatteryNum; E=EbattMaxEV(jj);
        for i=1:Kday
            A_SOC0(idx_A+i,idx_A_col+1:idx_A_col+i)=-1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=inta_batt_ch/E*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+1:idx_A_col+i)=1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=-inta_batt_ch/E*dt_sys;
        end
        idx_A_col=idx_A_col+2*Kday;
    end
    idx_A=idx_A+2*Kday;
end
A_SOC=[zeros(size(A_SOC0,1),DG_GFM_num*Kday*2) A_SOC0 zeros(size(A_SOC0,1),SolarNum*2*Kday+loadNum*Kday+(3*Nbranch+Nbus)*Kday)];
end