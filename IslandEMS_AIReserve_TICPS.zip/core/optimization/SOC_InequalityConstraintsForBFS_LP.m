function [A_SOC,b_SOC]=SOC_InequalityConstraintsForBFS_LP(Kday,SOCmax,SOCmin,SOC0,EbattMaxGFM,EbattMax,EbattMaxEV,inta_batt_ch,inta_batt_dis,DG_GFM_num,BatteryGFM_Num,BatteryNum,EVBatteryNum,SolarNum,Nload,dt_sys,SOCorigin)
% The energy constraints is only sensitive to the total charging energy
% amount and the total charging period, instead of the specific sequence of the charging
% power. So, we can shuffle/shift/normalize the charging period to make it
% start at the initial charging time step making the SoC energy constraint
% easy to developed.

EbattMaxGFM=EbattMaxGFM(:);
EbattMax=EbattMax(:);
EbattMaxEV=EbattMaxEV(:);

idx_A=0;
idx_A_col=0;
idx_b=0;

index=Kday;
% departStep=mod(T_EVch1+Kday-T_EVch2  -step ,Kday)+1;% here use the original velue of T_EVch1 and T_EVch2 will be more reliable


b_SOC=zeros(Kday*2*(BatteryNum+BatteryGFM_Num+EVBatteryNum),1);
A_SOC0=zeros(length(b_SOC),length(b_SOC));
for ii=1:(BatteryNum+BatteryGFM_Num+EVBatteryNum)
    if ii<=BatteryGFM_Num
        E=EbattMaxGFM(ii);
        for i=1:Kday
            A_SOC0(idx_A+i,idx_A_col+1:idx_A_col+i)=-1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=inta_batt_ch/E*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+1:idx_A_col+i)=1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=-inta_batt_ch/E*dt_sys;
        end
        idx_A_col=idx_A_col+2*Kday;
    elseif ii>BatteryGFM_Num && ii<=BatteryNum+BatteryGFM_Num
        jj=ii-BatteryGFM_Num; E=EbattMax(jj);
        for i=1:Kday
            A_SOC0(idx_A+i,idx_A_col+1:idx_A_col+i)=-1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=inta_batt_ch/E*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+1:idx_A_col+i)=1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=-inta_batt_ch/E*dt_sys;
        end
        idx_A_col=idx_A_col+2*Kday;
    else
        jj=ii-BatteryGFM_Num-BatteryNum; E=EbattMaxEV(jj);
        for i=1:Kday
            A_SOC0(idx_A+i,idx_A_col+1:idx_A_col+i)=-1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=inta_batt_ch/E*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+1:idx_A_col+i)=1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=-inta_batt_ch/E*dt_sys;
        end
        idx_A_col=idx_A_col+2*Kday;
    end
    idx_A=idx_A+2*Kday;
end
A_SOC=[zeros(size(A_SOC0,1),DG_GFM_num*Kday) A_SOC0 zeros(size(A_SOC0,1),(SolarNum+Nload)*Kday)];

for ii=1:(BatteryNum+BatteryGFM_Num+EVBatteryNum)
    if ii<=BatteryGFM_Num +BatteryNum
        b_SOC(idx_b+1:idx_b+Kday,1)=(SOCmax-SOC0(ii,1))*ones(Kday,1);idx_b=idx_b+Kday;
        b_SOC(idx_b+1:idx_b+Kday,1)=(SOC0(ii,1)-SOCmin)*ones(Kday,1);idx_b=idx_b+Kday;
        b_SOC(idx_b-Kday+index,1)=SOC0(ii,1)-SOCorigin(ii,1);%total charge >= total discharge in a day
    else
        b_SOC(idx_b+1:idx_b+Kday,1)=(SOCmax-SOC0(ii,1))*ones(Kday,1);
        b_SOC(idx_b+index,1)=SOCmax-SOC0(ii,1);% SOCendCh<=SOCmax
        idx_b=idx_b+Kday;
        b_SOC(idx_b+1:idx_b+Kday,1)=(SOC0(ii,1)-SOCmin)*ones(Kday,1);
        b_SOC(idx_b+index,1)=SOC0(ii,1)-SOCmax;% SOCendCh>=SOCmax
        idx_b=idx_b+Kday;
    end
end
end