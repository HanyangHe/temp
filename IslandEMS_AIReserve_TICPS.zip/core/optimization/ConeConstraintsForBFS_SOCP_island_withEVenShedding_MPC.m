function [Asc_ass_cell,bsc_ass_cell,dsc_ass_cell,gamma_ass_cell]=ConeConstraintsForBFS_SOCP_island_withEVenShedding_MPC(Line,V_slack,Kday,BusOfDieselG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,Nload)

Nbus = max(Line(:,2));
Nbranch = size(Line,1);     
N_DG_GFM = length(BusOfDieselG_GFM);
NbattGFM = length(BusOfBatteryGFM);
Nbatt = length(BusOfBattery);
NbattEV = length(BusOfEVBattery);
N_res = length(BusOfPV);

% index of the decision variable, which is the column index of Aeq
idx_P = 1:Nbranch;
idx_Q = Nbranch+1:2*Nbranch;
idx_l = 2*Nbranch+1:3*Nbranch;
idx_v = 3*Nbranch+1:3*Nbranch+Nbus;

totalVars=3*Nbranch+Nbus;
Asc_box = [];
bsc_box = [];
dsc_box = [];
gamma_vec = zeros(Nbranch,1);


for e = 1:Nbranch
	INbus = Line(e,1); 
	Asc = zeros(3, totalVars); 
	bsc = zeros(3, 1);
	dsc = zeros(totalVars, 1);
	gamma = 0;

	Asc(1, idx_P(e)) = 2;
    Asc(2, idx_Q(e)) = 2;
    Asc(3, idx_l(e)) = -1;

	if INbus == 0
		bsc(3) = -V_slack;
		gamma = -V_slack;
	else
		Asc(3, idx_v(INbus)) = 1;
		dsc(idx_v(INbus)) = 1;
	end
	
	dsc(idx_l(e)) = 1;

	Asc_box(:,:,e) = Asc;
	bsc_box(:,:,e) = bsc;
	dsc_box(:,:,e) = dsc;
	gamma_vec(e) = gamma;
end

% assembly matrix
Asc_ass_cell= cell(Nbranch*Kday,1);
bsc_ass_cell = cell(Nbranch*Kday,1);
dsc_ass_cell = cell(Nbranch*Kday,1);
gamma_ass_cell = cell(Nbranch*Kday,1);

offset = 2*Kday*(N_DG_GFM+N_res)+(2*Kday+2)*NbattEV+3*Kday*NbattGFM+(3*Kday+1)*Nbatt+Kday*Nload;
ind=1;

for k=1:Kday
    for e=1:Nbranch
        Asc = zeros(3, offset+totalVars*Kday); 
        Asc(:,offset+1+(k-1)*totalVars:offset+k*totalVars)=Asc_box(:,:,e);
        Asc_ass_cell{ind}=Asc;

        bsc_ass_cell{ind}   = bsc_box(:,:,e);

        dsc = zeros(offset+totalVars*Kday,1); 
        dsc(offset+1+(k-1)*totalVars:offset+k*totalVars,:)=dsc_box(:,:,e);
        dsc_ass_cell{ind}=dsc;

        gamma_ass_cell{ind} = gamma_vec(e);
        ind=ind+1;
    end
end
end
