function [A_SOC,b_SOC]=SOC_InequalityConstraints_withEVenShedding_MPC(Kday,SOCmax,SOCmin,SOC0,EbattMaxGFM,EbattMax,EbattMaxEV,inta_batt_ch,inta_batt_dis,DG_GFM_num,BatteryGFM_Num,BatteryNum,EVBatteryNum,SolarNum,Nload,Nbranch,Nbus,dt_sys,step,SOCorigin)

EbattMaxGFM=EbattMaxGFM(:);
EbattMax=EbattMax(:);
EbattMaxEV=EbattMaxEV(:);

idx_A=0;
idx_A_col=0;
idx_b=0;

delta=1e-3*0;

index=Kday-step+1;

b_SOC=zeros(Kday*2*(BatteryNum+BatteryGFM_Num+EVBatteryNum),1);
for ii=1:(BatteryNum+BatteryGFM_Num+EVBatteryNum)
    if ii<=BatteryGFM_Num +BatteryNum
        b_SOC(idx_b+1:idx_b+Kday,1)=(SOCmax-SOC0(ii,1))*ones(Kday,1);idx_b=idx_b+Kday;
        b_SOC(idx_b+1:idx_b+Kday,1)=(SOC0(ii,1)-SOCmin)*ones(Kday,1);idx_b=idx_b+Kday;
        b_SOC(idx_b-Kday+index,1)=SOC0(ii,1)-SOCorigin(ii,1);%total charge >= total discharge in a day at the end of a natrue day
        b_SOC(idx_b,1)=0;% for even sliding prediction horizon, end=ini
    else%EV battery
        b_SOC(idx_b+1:idx_b+Kday,1)=(SOCmax-SOC0(ii,1))*ones(Kday,1);
        b_SOC(idx_b+index,1)=SOCmax+delta-SOC0(ii,1);% SOCtargetCh<=SOCmax full charge at the given time step
        if step>1
            b_SOC(idx_b+Kday,1)=SOC0(ii,1)+delta-SOC0(ii,1);% SOCendCh<=SOC0+d keep the SOCend=SOC0
        end
        idx_b=idx_b+Kday;
        b_SOC(idx_b+1:idx_b+Kday,1)=(SOC0(ii,1)-SOCmin)*ones(Kday,1);
        b_SOC(idx_b+index,1)=SOC0(ii,1)-SOCmax+delta;% SOCtargetCh>=SOCmax full charge at the given time step
        if step>1
            b_SOC(idx_b+Kday,1)=SOC0(ii,1)-SOC0(ii,1)+delta;% SOCendCh>=SOC0-d keep the SOCend=SOC0
        end
        idx_b=idx_b+Kday;
        % b_SOC(idx_b+1:idx_b+Kday,1)=0;
        % idx_b=idx_b+Kday;
    end
end

A_SOC0=zeros(length(b_SOC),BatteryNum*(3*Kday+1)+BatteryGFM_Num*3*Kday+EVBatteryNum*(2*Kday+2));
for ii=1:(BatteryNum+BatteryGFM_Num+EVBatteryNum)
    if ii<=BatteryGFM_Num
        E=EbattMaxGFM(ii);
        for i=1:Kday
            A_SOC0(idx_A+i,idx_A_col+1:idx_A_col+i)=-1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=inta_batt_ch/E*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+1:idx_A_col+i)=1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=-inta_batt_ch/E*dt_sys;
        end
        idx_A_col=idx_A_col+3*Kday;
        idx_A=idx_A+2*Kday;
    elseif ii>BatteryGFM_Num && ii<=BatteryNum+BatteryGFM_Num
        jj=ii-BatteryGFM_Num; E=EbattMax(jj);
        for i=1:Kday
            A_SOC0(idx_A+i,idx_A_col+1:idx_A_col+i)=-1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=inta_batt_ch/E*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+1:idx_A_col+i)=1/(E*inta_batt_dis)*dt_sys;
            A_SOC0(idx_A+Kday+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=-inta_batt_ch/E*dt_sys;
        end
        % BESS charging energy shedding
        A_SOC0(idx_A+index,idx_A_col+3*Kday+1)=1;
        A_SOC0(idx_A+Kday+index,idx_A_col+3*Kday+1)=-1;

        idx_A_col=idx_A_col+3*Kday+1;
        idx_A=idx_A+2*Kday;
    else% EV battery
        jj=ii-BatteryGFM_Num-BatteryNum; E=EbattMaxEV(jj);
        for i=1:Kday
            if i<=Kday-step+1
                A_SOC0(idx_A+i,idx_A_col+1:idx_A_col+i)=-1/(E*inta_batt_dis)*dt_sys;
                A_SOC0(idx_A+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=inta_batt_ch/E*dt_sys;
                % A_SOC0(idx_A+i,idx_A_col+2*Kday+1:idx_A_col+2*Kday+i)=-inta_batt_ch/(EbattMaxEV)*dt_sys;

                A_SOC0(idx_A+Kday+i,idx_A_col+1:idx_A_col+i)=1/(E*inta_batt_dis)*dt_sys;
                A_SOC0(idx_A+Kday+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=-inta_batt_ch/E*dt_sys;
                % A_SOC0(idx_A+Kday+i,idx_A_col+2*Kday+1:idx_A_col+2*Kday+i)=inta_batt_ch/(EbattMaxEV)*dt_sys;

                % A_SOC0(idx_A+2*Kday+i,idx_A_col+Kday+1:idx_A_col+Kday+i)=-1;
                % A_SOC0(idx_A+2*Kday+i,idx_A_col+2*Kday+1:idx_A_col+2*Kday+i)=1;
            else
                base=Kday-step+1;
                A_SOC0(idx_A+i,idx_A_col+1+base:idx_A_col+i)=-1/(E*inta_batt_dis)*dt_sys;
                A_SOC0(idx_A+i,idx_A_col+Kday+1+base:idx_A_col+Kday+i)=inta_batt_ch/E*dt_sys;
                % A_SOC0(idx_A+i,idx_A_col+2*Kday+1+base:idx_A_col+2*Kday+i)=-inta_batt_ch/(EbattMaxEV)*dt_sys;

                A_SOC0(idx_A+Kday+i,idx_A_col+1+base:idx_A_col+i)=1/(E*inta_batt_dis)*dt_sys;
                A_SOC0(idx_A+Kday+i,idx_A_col+Kday+1+base:idx_A_col+Kday+i)=-inta_batt_ch/E*dt_sys;
                % A_SOC0(idx_A+Kday+i,idx_A_col+2*Kday+1+base:idx_A_col+2*Kday+i)=inta_batt_ch/(EbattMaxEV)*dt_sys;

                % A_SOC0(idx_A+2*Kday+i,idx_A_col+Kday+1+base:idx_A_col+Kday+i)=-1;
                % A_SOC0(idx_A+2*Kday+i,idx_A_col+2*Kday+1+base:idx_A_col+2*Kday+i)=1;
            end
        end
        % consider relaxation gap
        A_SOC0(idx_A+index,idx_A_col+2*Kday+1)=-1;
        A_SOC0(idx_A+Kday+index,idx_A_col+2*Kday+1)=-1;
        % EV charging energy shedding
        A_SOC0(idx_A+index,idx_A_col+2*Kday+2)=1;
        A_SOC0(idx_A+Kday+index,idx_A_col+2*Kday+2)=-1;

        idx_A_col=idx_A_col+2*Kday+2;
        idx_A=idx_A+2*Kday;
    end
end
A_SOC=[zeros(size(A_SOC0,1),DG_GFM_num*Kday*2) A_SOC0 zeros(size(A_SOC0,1),SolarNum*2*Kday+Nload*Kday+(3*Nbranch+Nbus)*Kday)];
end