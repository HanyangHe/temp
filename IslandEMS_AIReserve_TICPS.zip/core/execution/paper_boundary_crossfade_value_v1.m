function v = paper_boundary_crossfade_value_v1(U,execIdx,RealStep,cfg,unitIndex)
%PAPER_BOUNDARY_CROSSFADE_VALUE_V1
% Frozen common paper execution layer: 5-min total symmetric linear
% crossfade (2.5 min before + 2.5 min after each 15-min MPC boundary).
% No method ID, alpha, KRR output, frequency outcome, or violation status.

N=size(U,1);
k=min(max(round(execIdx),1),N);
uNow=double(U(k,1,unitIndex));

enabled=false;
if isfield(cfg,'execution') && isfield(cfg.execution,'boundaryCrossfadeEnabled')
    enabled=logical(cfg.execution.boundaryCrossfadeEnabled);
end

if ~enabled || N<=1
    v=uNow;
    return;
end

samplePerHour=double(cfg.simulation.samplePerHour);
samplesPerDecision=round(double(cfg.mpc.decisionInterval_h)*samplePerHour);
dtPhys_s=3600/samplePerHour;

if isfield(cfg.execution,'boundaryCrossfadeTotal_s')
    totalWindow_s=double(cfg.execution.boundaryCrossfadeTotal_s);
else
    totalWindow_s=300;
end

blendWindowSamples=round(totalWindow_s/dtPhys_s);
if blendWindowSamples<2
    v=uNow;
    return;
end

H=floor(blendWindowSamples/2);
H=max(H,1);
H=min(H,floor(samplesPerDecision/2));
r=mod(round(RealStep)-1,samplesPerDecision);

% First half after boundary t_k: finish u_{k-1} -> u_k.
if r < H && k>1
    uPrev=double(U(k-1,1,unitIndex));
    beta=0.5 + 0.5*(double(r)/double(H));
    beta=min(max(beta,0),1);
    v=(1-beta)*uPrev + beta*uNow;
    return;
end

% Last half before boundary t_{k+1}: begin u_k -> u_{k+1}.
if r >= samplesPerDecision-H && k<N
    uNext=double(U(k+1,1,unitIndex));
    q=double(r-(samplesPerDecision-H))/double(H);
    beta=0.5*min(max(q,0),1);
    v=(1-beta)*uNow + beta*uNext;
    return;
end

v=uNow;
end
