function [Edq,dotX]=PID_GFMcontroller_DynModel_3States(Ref,FDBK,Xm_g,Zmv_g,K_Pdp,K_Qdp,omega_b,M,MainGFM,X)

% input
Vset=Ref(1,1);
dw_set=Ref(2,1);% derivative of the phasor angle difference rad/s
Pset = Ref(3,1);
Qset = Ref(4,1);

Vinv_g=FDBK(1,1);
Vpcc=FDBK(2,1);

% === measurements (current from Thevenin source through L+Zmv) ===
Theta_g = mod(X(2,1),2*pi);% phasor angle difference in dq frame
I_in_g = ((Vinv_g - Vpcc)/(1j*Xm_g+Zmv_g));
Pg=real(Vpcc*conj(I_in_g));%P=Vd*Id+Vq*Iq
Qg=imag(Vpcc*conj(I_in_g));%Q=Vq*Id-Vd*Iq

% === frequency–active power droop ===                                 
KI_Pdp=0.05*K_Pdp;
if MainGFM==0
    KI_Pdp=0;
end
Pset = Pset + KI_Pdp*X(1,1);% slow restoration of Pset via freq error integral

dw         = dw_set - K_Pdp*omega_b*(Pg - Pset);% rad/s
dotX(2,1)  = dw;                                 % dθ/dt
dotX(1,1) = dw_set - dw;

% === Q–V droop to voltage references ===
E_cmd   = Vset - K_Qdp*(Qg - Qset);
T_E = 0.2;                               % you can set 0.05~0.5 s; keep >0
dotX(3,1) = (E_cmd - X(3,1)) / T_E;

% === output internal EMF in dq (q-axis set to zero) with modulation limit ===
Emod_max  = 1.1 / M;             % ensure Vinv = M * Rot(theta) * Edq stays feasible
E_mag     = min(max(X(3,1), 0), Emod_max);

Edq = [E_mag; 0];