function [Edq,dotX]=PID_GFMcontroller_DynModel(Ref,FDBK,Xm_g,Zmv_g,controlParams,K_Pdp,K_Qdp,omega_b,M,MainGFM,X)

% control parameters
% KP_PLL_pq=controlParams(1,1);
% KI_PLL_pq=controlParams(2,1);
KI_outer_p=controlParams(3,1);
KI_outer_q=controlParams(4,1);
KI_inner_p=controlParams(5,1);
KI_inner_q=controlParams(6,1);
KP_outer_p=controlParams(7,1);
KP_outer_q=controlParams(8,1);
KP_inner_p=controlParams(9,1);
KP_inner_q=controlParams(10,1);

% Imax = 1.2;  % pu

% input
Vset=Ref(1,1);
dw_set=Ref(2,1);% derivative of the phasor angle difference rad/s
Pset = Ref(3,1);
Qset = Ref(4,1);
% SoCset = Ref(5,1);

Vinv_g=FDBK(1,1);
Vpcc=FDBK(2,1);
% SoC=FDBK(3,1);

% fdbk voltage and current calculation & xy->dq
Theta_g = mod(X(2,1),2*pi);% phasor angle difference in dq frame
I_in_g = ((Vinv_g - Vpcc)/(1j*Xm_g+Zmv_g));
Id_g = real(I_in_g(1,1))*cos(Theta_g) + imag(I_in_g(1,1))*sin(Theta_g);
Iq_g = -real(I_in_g(1,1))*sin(Theta_g) + imag(I_in_g(1,1))*cos(Theta_g);
Vd_g =  real(Vpcc)*cos(Theta_g) + imag(Vpcc)*sin(Theta_g);
Vq_g = -real(Vpcc)*sin(Theta_g) + imag(Vpcc)*cos(Theta_g);
Pg=real(Vpcc*conj(I_in_g));%P=Vd*Id+Vq*Iq
Qg=imag(Vpcc*conj(I_in_g));%Q=Vq*Id-Vd*Iq

% === frequency–active power droop ===                                 
KI_Pdp=0.05*K_Pdp;
if MainGFM==0
    KI_Pdp=0;
end
Pset = Pset + KI_Pdp*X(1);
dw         = dw_set - K_Pdp*omega_b*(Pg - Pset);% rad/s
dotX(2,1)  = dw;                                 % dθ/dt
dotX(1,1) = dw_set - dw;

% === Q–V droop to voltage references ===
Ecmd   = Vset - K_Qdp*(Qg - Qset);
Vd_ref = Ecmd;
Vq_ref = 0;

% -------- outer loop: voltage -> current references --------
% unsaturated outputs
id_unsat =  KP_outer_p*(Vd_ref - Vd_g) + X(3);
iq_unsat = -KP_outer_q*(Vq_ref - Vq_g) + X(5);

% current vector magnitude limit (apply only when saturated)
Kaw_p=0.5*KI_outer_p;
Kaw_q=0.5*KI_outer_q;
I2 = id_unsat^2 + iq_unsat^2;
Imax=1.2;
if I2 > Imax^2
    sc       = Imax/sqrt(I2);
    id_ref_g = id_unsat*sc;
    iq_ref_g = iq_unsat*sc;
    % back-calculation anti-windup (only when saturated)
    dotX(3,1) =  KI_outer_p*(Vd_ref - Vd_g) - Kaw_p*(id_unsat - id_ref_g);
    dotX(5,1) = -KI_outer_q*(Vq_ref - Vq_g) - Kaw_q*(iq_unsat - iq_ref_g);
else
    id_ref_g  = id_unsat;
    iq_ref_g  = iq_unsat;
    dotX(3,1) =  KI_outer_p*(Vd_ref - Vd_g);
    dotX(5,1) = -KI_outer_q*(Vq_ref - Vq_g);
end

% -------- inner loop: current -> modulation commands --------
u_d_unsat = KP_inner_p*(id_ref_g - Id_g) + X(4);
u_q_unsat = KP_inner_q*(iq_ref_g - Iq_g) + X(6);

% modulation magnitude limit (apply only when saturated)
Kaw_ip=0.5*KI_inner_p;
Kaw_iq=0.5*KI_inner_q;
U2 = u_d_unsat^2 + u_q_unsat^2;
Emod=1/M;
if U2 > Emod^2
    se    = Emod/sqrt(U2);
    Edr_g = u_d_unsat*se;
    Eqr_g = u_q_unsat*se;
    % back-calculation anti-windup (only when saturated)
    dotX(4,1) = KI_inner_p*(id_ref_g - Id_g) - Kaw_ip*(u_d_unsat - Edr_g);
    dotX(6,1) = KI_inner_q*(iq_ref_g - Iq_g) - Kaw_iq*(u_q_unsat - Eqr_g);
else
    Edr_g    = u_d_unsat;
    Eqr_g    = u_q_unsat;
    dotX(4,1)= KI_inner_p*(id_ref_g - Id_g);
    dotX(6,1)= KI_inner_q*(iq_ref_g - Iq_g);
end

Edq = [Edr_g; Eqr_g];