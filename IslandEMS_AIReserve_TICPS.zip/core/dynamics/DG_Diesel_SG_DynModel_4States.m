function [Edq, dotX,Psee] = DG_Diesel_SG_DynModel_4States(Ref,FDBK,Prate,Zs_DG,controlParams,Rdroop,kQ_DG,phys,MainGFM,X)
%DG_DIESEL_SG_DYNMODEL_4STATES Diesel SG + governor model on local DG power base.
% Prate is the active-power rating in MW. H, D, and Rdroop are defined on
% that same local power base. Network electrical quantities remain on the
% common system per-unit base. This explicit convention prevents the
% 1-MW/system-base droop ambiguity present in the legacy implementation.

    TimeScale=3600;

    % --- unpack inputs ---
    Vref  = Ref(1); 
    Pref  = Ref(2);
    Qref  = Ref(3);
    Vbus  = FDBK(1);
    Vinv_pre = FDBK(2);

    Tm    = controlParams(1);Tm_h=Tm/TimeScale;
    KIsec = controlParams(2);
    
    if MainGFM==0
        KIsec=0;
    end
    % xI is the integral of per-unit frequency error in seconds.
    % KIsec therefore maps xI to per-unit active-power correction.

    H     = phys.H; H_h=H/TimeScale;
    D     = phys.D; 
    omega_b = phys.omega_b;   % e.g., 2*pi*60rad/s

    Xd_prime=imag(Zs_DG);
    Ra=real(Zs_DG);
    
    if isfield(phys,'PminPu'), PminPu=phys.PminPu; else, PminPu=0.2; end
    if isfield(phys,'PmaxPu'), PmaxPu=phys.PmaxPu; else, PmaxPu=1.0; end
    Pmin = PminPu*Prate;
    Pmax = PmaxPu*Prate;
    
    % --- states ---
    delta    = X(1);% power angle rad, the electrical angle of rotator relative to the synchrnous axis
    dw       = X(2);%d_omega, rad/s
    Pm       = X(3);% MW (numerically system-base pu because Sbase=1 MVA)
    xI       = X(4);%Secondary frequency regulate integral amount
    
    % --- internal EMF (Thevenin source) ---
    % Qref=0;
    Eq_mag=abs(Vinv_pre);
    for iter=1:3
	    Eint   = Eq_mag * exp(1j*(delta + pi/2));          % j*Eq' * e^{j delta}
    
        I    = (Eint - Vbus) / Zs_DG;
        Q   = imag(Vbus * conj(I));  
        Eq_mag = abs(Vref)-kQ_DG*(Q-Qref);
    end
    
    % --- stator current and electrical power ---
    I    = (Eint - Vbus) / Zs_DG;                          % terminal current (phasor)
    Pe   = real(Vbus * conj(I));                        % electrical power

    % --- swing equations ---
    dot_delta  = dw;
    % Pm and Pe are in MW, so normalize by Prate before applying the
    % machine-base swing equation. Derivative is expressed per hour because
    % the outer integrator uses hours as its time variable.
    dot_dw = ((Pm-Pe)/Prate - D*(dw/omega_b))/(2*H_h)*omega_b;
    
    
    % --- governor + turbine with droop + secondary + anti-windup ---
    Kaw_gov= 5.0/Tm;           % anti-windup back-calculation
    
    Pe_min = Pmin;  Pe_max = Pmax;
    Pe_sat = min(max(Pe, Pe_min), Pe_max);
    Kpe = 0.00/Tm;   
    Pref_eff = Pref - Kpe*(Pe - Pe_sat);

    Pm_cmd_uf = Pref_eff + Prate*KIsec*xI ...
        - (Prate/Rdroop)*(dw/omega_b);
    Pm_cmd_ref = min(max(Pm_cmd_uf, Pmin), Pmax);

    %Governor + Turbine (primary frequency regulator)
    dot_Pm     = ( -Pm + Pm_cmd_ref ) / Tm_h;

    if (Pm >= Pmax) && (dot_Pm > 0)
        dot_Pm = 0;
    elseif (Pm <= Pmin) && (dot_Pm < 0)
        dot_Pm = 0;
    end
    
    if MainGFM==0
        dot_xI = 0;
    else
        % Convert the secondary-integrator derivative from 1/s to 1/h.
        dot_xI = TimeScale*(-dw/omega_b + ...
            Kaw_gov*(Pm_cmd_ref-Pm_cmd_uf)/Prate);
    end
    
    % --- pack outputs ---
    dotX = [dot_delta; dot_dw; dot_Pm;dot_xI];
    
    % For your outer reconstruction (like inverter), provide dq EMF:
    Ed = 0;
    Eq = Eq_mag;
    Edq = [Ed; Eq];
    Psee=[Pe;Pm_cmd_uf;Pm_cmd_ref;Pe-Pm];
end
