function [X,Vs,Vter,S_busInjVec,S_DG,S_inv_Batt,S_inv_PV,freq,SOC,fval,exitflag,Psee] = ...
    MicrogridSys_ODEAE_expIterSolver(X,Vs,Vter,Ref,S_load_vec, ...
                                     V_DC,Zs_DG,Xm_g,Zmv_g,Y_Bus,SOC,SOCmin,SOCmax,Prate,DGcontrolParams,SoCParams,phys,K_Pdp,K_Qdp,Rdroop,kQ_DG, ...
                                     BusOfDG_GFM,BusOfBatteryGFM,BusOfBattery,BusOfEVBattery,BusOfPV,MainGFM,h,Niter,Integrator)
    % sub-integral round for device with 1s level parameters
    % dt_s=50e-3;%s
    % SubIntCount=5;%round(3600*h/dt_s);%h->s

    % persistent Jpat Nbus_cached
    Nbus = size(Y_Bus,1);

    % SoC
    inta_batt_ch=SoCParams.eta_ch;
    inta_batt_dis=SoCParams.eta_dis;
    EbattMaxGFM=SoCParams.E_GFM_MWh(:);
    EbattMax=SoCParams.E_BESS_MWh(:);
    EbattMaxEV=SoCParams.E_EV_MWh(:);

    % Use sparse network matrices, but avoid reconstructing an already-sparse
    % Ybus at every 1-s physical step.
    if ~issparse(Y_Bus)
        Y_Bus = sparse(Y_Bus);
    end

    DG_NumGFM = numel(BusOfDG_GFM);
    BatteryNumGFM = numel(BusOfBatteryGFM);
    BatteryNum = numel(BusOfBattery);
    EVBatteryNum = numel(BusOfEVBattery);
    SolarNum   = numel(BusOfPV);

    % Constant used in inverter voltage reconstruction
    M = (sqrt(3)/sqrt(2))*0.5*V_DC;

    % dt_sec=dt_sec/Niter;

    dw_DG_GFM=[];
    dw_INV_GFM=[];

    GFMbatt_noPower=zeros(Nbus,1);
    batt_noPower=zeros(Nbus,1);
    EVbatt_noPower=zeros(Nbus,1);

    h=h/Niter;
    % dt_s=dt_s/Niter;
    % dt_s=h;NsbInt=1;

    for ii=1:DG_NumGFM
        Psee{ii}=0;
    end

    % Power-flow solver configuration is constant over the inner DAE
    % iterations.  The active fast path is Newton-Raphson (PFsolver=2), so
    % avoid constructing an unused fsolve options object 86,400 times/day.
    PFsolver=2;
    if PFsolver==1
        opts = optimoptions('fsolve','Display','off', ...
            'Algorithm','levenberg-marquardt');
    else
        nrOpt.maxIter = 6;       % warm-started rectangular NR
        nrOpt.tolInf = 1e-8;
        nrOpt.tolStepInf = 1e-10;
        nrOpt.lineSearch = false;
        nrOpt.reg = 0;
    end
% ============ outer physical sub-steps ============
    % Initialize iterates
    Vs_iter   = Vs;
    Vter_iter = Vter;
    X_iter    = X;
% for NsbInt=1:SubIntCount
    % ======= inner DAE explicit-split iterations (ODE -> PF) =======
    for m = 1:max(1,Niter)% explict DAE solver loop
        % ------ Build sparse inverter shunt admittances ------
        % allocate diagonal sparse matrices: number of nonzeros equals #devices
        Yinv_DG_GFM = spalloc(Nbus,Nbus,DG_NumGFM);
        Yinv_Batt_GFM = spalloc(Nbus,Nbus,BatteryNumGFM);
        Yinv_Batt_GFL = spalloc(Nbus,Nbus,BatteryNum);
        Yinv_Batt_EV = spalloc(Nbus,Nbus,EVBatteryNum);
        Yinv_PV   = spalloc(Nbus,Nbus,SolarNum);

        VterDG_GFM_bus = zeros(Nbus,1);
        VinvBattGFM_bus = zeros(Nbus,1);
        VinvBatt_bus = zeros(Nbus,1);
        VinvEVBatt_bus = zeros(Nbus,1);
        VinvPV_bus   = zeros(Nbus,1);
        

       
        idx_X   = 0;
        idx_ref = 0;
        idx_Vin = 0;
        idx_Xm  = 0;
        idx_Zs = 0;

        if DG_NumGFM > 0
            for gg = 1:DG_NumGFM
                % 1) ODE step for DG
                % for NsbInt=1:SubIntCount
                if strcmp(Integrator,'ode4')
                [Inc1, ~, Edq,Psee{gg}] = ode4_singleStep0( X_iter(idx_X+1:idx_X+4), h, ...
                    @DG_Diesel_SG_DynModel_4States, ...
                    Ref(idx_ref+1:idx_ref+3), ...
                    [Vs_iter(BusOfDG_GFM(gg)) Vter_iter(idx_Vin+1) Psee{gg}(1) ], ...
                    Prate(gg),Zs_DG(idx_Zs+1), DGcontrolParams,Rdroop(gg),kQ_DG(gg), phys,MainGFM(gg) );
                elseif strcmp(Integrator,'ode15s')
                [Inc1, ~, Edq,Psee{gg}] = ode15s_singleStep0( X_iter(idx_X+1:idx_X+4), h, ...
                    @DG_Diesel_SG_DynModel_4States, ...
                    Ref(idx_ref+1:idx_ref+3), ...
                    [Vs_iter(BusOfDG_GFM(gg)) Vter_iter(idx_Vin+1) Psee{gg}(1)], ...
                    Prate(gg),Zs_DG(idx_Zs+1), DGcontrolParams,Rdroop(gg),kQ_DG(gg), phys,MainGFM(gg) );
                end
    
                Xtemp = X_iter(idx_X+1:idx_X+4) + Inc1*h;
                X_iter(idx_X+1:idx_X+4,1) = Xtemp;

                % 2) Compute new Vinv from E_dq
                th  = Xtemp(1);
                Ex = Edq(1)*cos(th) - Edq(2)*sin(th);
                Ey = Edq(1)*sin(th) + Edq(2)*cos(th);
                Vter_iter(idx_Vin+1) = (Ex + 1j*Ey);
                % Vter_iter(idx_Vin+1) = Vter;
                % end
                
                % 3) Update shunt admittance and terminal voltage
                ii = BusOfDG_GFM(gg);
                Yinv_DG_GFM(ii,ii) = Yinv_DG_GFM(ii,ii) + 1/(Zs_DG(idx_Zs+1));
                VterDG_GFM_bus(ii) = Vter_iter(idx_Vin+1);

                dw_DG_GFM(gg) = Xtemp(2);
                
                idx_X  = idx_X  + 4;
                idx_ref= idx_ref+ 3;
                idx_Zs = idx_Zs + 1;
                idx_Vin= idx_Vin+ 1;
            end
        end

        % if NsbInt==1
        if BatteryNumGFM > 0
            for bb = 1:BatteryNumGFM
                % 1) ODE step for GFM battery

                if strcmp(Integrator,'ode4')
                [Inc1, ~, Edq] = ode4_singleStep( X_iter(idx_X+1:idx_X+3), h, ...
                    @PID_GFMcontroller_DynModel_3States, ...
                    Ref(idx_ref+1:idx_ref+4), ...
                    [Vter_iter(idx_Vin+1); Vs_iter(BusOfBatteryGFM(bb))], ...
                    Xm_g(idx_Xm+1), Zmv_g(idx_Xm+1), K_Pdp(bb),K_Qdp(bb),phys.omega_b,M,MainGFM(DG_NumGFM+bb) );
                elseif strcmp(Integrator,'ode15s')
                [Inc1, ~, Edq] = ode15s_singleStep( X_iter(idx_X+1:idx_X+3), h, ...
                    @PID_GFMcontroller_DynModel_3States, ...
                    Ref(idx_ref+1:idx_ref+4), ...
                    [Vter_iter(idx_Vin+1); Vs_iter(BusOfBatteryGFM(bb))], ...
                    Xm_g(idx_Xm+1), Zmv_g(idx_Xm+1), K_Pdp(bb),K_Qdp(bb),phys.omega_b,M,MainGFM(DG_NumGFM+bb) );
                end

                Xtemp = X_iter(idx_X+1:idx_X+3) + Inc1*h;
                X_iter(idx_X+1:idx_X+3,1) = Xtemp;
            
            
            
                % 2) Compute new Vinv from E_dq
                th  = Xtemp(2);
                Ex = Edq(1)*cos(th) - Edq(2)*sin(th);
                Ey = Edq(1)*sin(th) + Edq(2)*cos(th);
                Vter_iter(idx_Vin+1) = M*(Ex + 1j*Ey);
                % Vter_iter(idx_Vin+1) = Vter;

                
                % 3) Update shunt admittance and terminal voltage
                ii = BusOfBatteryGFM(bb);
                Yinv_Batt_GFM(ii,ii) = Yinv_Batt_GFM(ii,ii) + 1/(1j*Xm_g(idx_Xm+1)+Zmv_g(idx_Xm+1));
                VinvBattGFM_bus(ii) = Vter_iter(idx_Vin+1);
                if SOC(bb)<=SOCmin && real(Vs_iter(ii) .* conj(Yinv_Batt_GFM(ii,ii) * (VinvBattGFM_bus(ii) - Vs_iter(ii))))>0
                    Vter_iter(idx_Vin+1)=Vs_iter(ii);
                    VinvBattGFM_bus(ii)=Vs_iter(ii);
                    GFMbatt_noPower(ii)=1;
                    % SOC(bb)=SOCmin;
                elseif SOC(bb)>=SOCmax && real(Vs_iter(ii) .* conj(Yinv_Batt_GFM(ii,ii) * (VinvBattGFM_bus(ii) - Vs_iter(ii))))<0
                    Vter_iter(idx_Vin+1)=Vs_iter(ii);
                    VinvBattGFM_bus(ii)=Vs_iter(ii);
                    GFMbatt_noPower(ii)=1;
                    % SOC(bb)=SOCmax;
                else
                    GFMbatt_noPower(ii)=0;
                end
                % see=real(Vs_iter(ii) .* conj(Yinv_Batt_GFM(ii,ii) * (VinvBattGFM_bus(ii) - Vs_iter(ii))));

                dw_INV_GFM(bb) = Xtemp(2);

                idx_X  = idx_X  + 3;
                idx_ref= idx_ref+ 4;
                idx_Xm = idx_Xm + 1;
                idx_Vin= idx_Vin+ 1;
            end
        end

        if BatteryNum > 0
            for bb = 1:BatteryNum
                ii = BusOfBattery(bb);
                % 1) ODE step for GFL battery
                Vpcc=Vs_iter(BusOfBattery(bb));
                if SOC(bb+BatteryNumGFM)<=SOCmin && real(Vs_iter(ii) .* conj(Yinv_Batt_GFL(ii,ii) * (VinvBatt_bus(ii) - Vs_iter(ii))))>0
                    RefIn=[0;0];
                    batt_noPower(ii)=1;
                elseif SOC(bb+BatteryNumGFM)>=SOCmax && real(Vs_iter(ii) .* conj(Yinv_Batt_GFL(ii,ii) * (VinvBatt_bus(ii) - Vs_iter(ii))))<0
                    RefIn=[0;0];
                    batt_noPower(ii)=1;
                else
                    RefIn=Ref(idx_ref+1:idx_ref+2);
                    batt_noPower(ii)=0;
                end

                if strcmp(Integrator,'ode4')
                [Inc1, ~, Vinv] = ode4_singleStep( X_iter(idx_X+1:idx_X+2), h, ...
                    @PID_GFLcontroller_AlgModel, ...
                    RefIn, ...
                    [Vter_iter(idx_Vin+1);Vpcc], ...
                    Xm_g(idx_Xm+1), Zmv_g(idx_Xm+1));
                elseif strcmp(Integrator,'ode15s')
                [Inc1, ~, Vinv] = ode15s_singleStep( X_iter(idx_X+1:idx_X+2), h, ...
                    @PID_GFLcontroller_AlgModel, ...
                    RefIn, ...
                    [Vter_iter(idx_Vin+1);Vpcc], ...
                    Xm_g(idx_Xm+1), Zmv_g(idx_Xm+1));
                end
                X_iter(idx_X+1:idx_X+2)=X_iter(idx_X+1:idx_X+2)+Inc1*h;
            

                % 2) Compute new Vinv from E_dq
                % th  = angle(Vpcc);
                % Ex = Edq(1)*cos(th) - Edq(2)*sin(th);
                % Ey = Edq(1)*sin(th) + Edq(2)*cos(th);
                % Vter_iter(idx_Vin+1) = M*(Ex + 1j*Ey);
                Vter_iter(idx_Vin+1) = Vinv;


                % 3) Update shunt admittance and terminal voltage
                Yinv_Batt_GFL(ii,ii) = Yinv_Batt_GFL(ii,ii) + 1/(1j*Xm_g(idx_Xm+1)+Zmv_g(idx_Xm+1));
                VinvBatt_bus(ii) = Vter_iter(idx_Vin+1);
                
                idx_X  = idx_X  + 2;
                idx_ref= idx_ref+ 2;
                idx_Xm = idx_Xm + 1;
                idx_Vin= idx_Vin+ 1;
            end
        end

        if EVBatteryNum > 0
            for bb = 1:EVBatteryNum
                ii = BusOfEVBattery(bb);
                % 1) ODE step for GFM battery
                Vpcc=Vs_iter(BusOfEVBattery(bb));
                if SOC(bb+BatteryNumGFM+BatteryNum)<=SOCmin && real(Vs_iter(ii) .* conj(Yinv_Batt_EV(ii,ii) * (VinvEVBatt_bus(ii) - Vs_iter(ii))))>0
                    RefIn=[0;0];
                    EVbatt_noPower(ii)=1;
                elseif SOC(bb+BatteryNumGFM+BatteryNum)>=SOCmax && real(Vs_iter(ii) .* conj(Yinv_Batt_EV(ii,ii) * (VinvEVBatt_bus(ii) - Vs_iter(ii))))<0
                    RefIn=[0;0];
                    EVbatt_noPower(ii)=1;
                else
                    RefIn=Ref(idx_ref+1:idx_ref+2);
                    EVbatt_noPower(ii)=0;
                end

                if strcmp(Integrator,'ode4')
                [Inc1, ~, Vinv] = ode4_singleStep( X_iter(idx_X+1:idx_X+2), h, ...
                    @PID_GFLcontroller_AlgModel, ...
                    RefIn, ...
                    [Vter_iter(idx_Vin+1);Vpcc], ...
                    Xm_g(idx_Xm+1), Zmv_g(idx_Xm+1));
                elseif strcmp(Integrator,'ode15s')
                [Inc1, ~, Vinv] = ode15s_singleStep( X_iter(idx_X+1:idx_X+2), h, ...
                    @PID_GFLcontroller_AlgModel, ...
                    RefIn, ...
                    [Vter_iter(idx_Vin+1);Vpcc], ...
                    Xm_g(idx_Xm+1), Zmv_g(idx_Xm+1));
                end
                X_iter(idx_X+1:idx_X+2)=X_iter(idx_X+1:idx_X+2)+Inc1*h;% Just for improve the DAE performance, not true states
            

                % 2) Compute new Vinv from E_dq
                % th  = angle(Vpcc);
                % Ex = Edq(1)*cos(th) - Edq(2)*sin(th);
                % Ey = Edq(1)*sin(th) + Edq(2)*cos(th);
                % Vter_iter(idx_Vin+1) = M*(Ex + 1j*Ey);
                Vter_iter(idx_Vin+1) = Vinv;


                % 3) Update shunt admittance and terminal voltage
                Yinv_Batt_EV(ii,ii) = Yinv_Batt_EV(ii,ii) + 1/(1j*Xm_g(idx_Xm+1)+Zmv_g(idx_Xm+1));
                VinvEVBatt_bus(ii) = Vter_iter(idx_Vin+1);
                

                % 4) For EV battery, it will be disconnected from the
                % grid when charging finished
                if SOC(bb+BatteryNumGFM+BatteryNum)>=SOCmax
                    Yinv_Batt_EV(ii,ii) = 0;
                end
                
                idx_X  = idx_X  + 2;
                idx_ref= idx_ref+ 2;
                idx_Xm = idx_Xm + 1;
                idx_Vin= idx_Vin+ 1;
            end
        end

        if SolarNum > 0
            for ss = 1:SolarNum
                % 1) ODE step for PQ PV
                Vpcc=Vs_iter(BusOfPV(ss));
                RefIn=Ref(idx_ref+1:idx_ref+2);

                if strcmp(Integrator,'ode4')
                [Inc1, ~, Vinv] = ode4_singleStep( X_iter(idx_X+1:idx_X+2), h, ...
                    @PID_GFLcontroller_AlgModel, ...
                    RefIn, ...
                    [Vter_iter(idx_Vin+1);Vpcc], ...
                    Xm_g(idx_Xm+1), Zmv_g(idx_Xm+1));
                elseif strcmp(Integrator,'ode15s')
                [Inc1, ~, Vinv] = ode15s_singleStep( X_iter(idx_X+1:idx_X+2), h, ...
                    @PID_GFLcontroller_AlgModel, ...
                    RefIn, ...
                    [Vter_iter(idx_Vin+1);Vpcc], ...
                    Xm_g(idx_Xm+1), Zmv_g(idx_Xm+1));
                end
                X_iter(idx_X+1:idx_X+2)=X_iter(idx_X+1:idx_X+2)+Inc1*h;% Just for improve the DAE performance, not true states
            

                % 2) Compute new Vinv from E_dq
                % th  = angle(Vpcc);
                % Ex = Edq(1)*cos(th) - Edq(2)*sin(th);
                % Ey = Edq(1)*sin(th) + Edq(2)*cos(th);
                % Vter_iter(idx_Vin+1) = M*(Ex + 1j*Ey);
                Vter_iter(idx_Vin+1) = Vinv;


                % 3) Update shunt admittance and terminal voltage
                jj = BusOfPV(ss);
                Yinv_PV(jj,jj)   = Yinv_PV(jj,jj) + 1/(1j*Xm_g(idx_Xm+1)+Zmv_g(idx_Xm+1));
                VinvPV_bus(jj)   = Vter_iter(idx_Vin+1);

                idx_X  = idx_X  + 2;
                idx_ref= idx_ref+ 2;
                idx_Xm = idx_Xm + 1;
                idx_Vin= idx_Vin+ 1;
            end
        end

        % end
        
        if PFsolver==1
            % ------ Power-flow solve (FSOLVE) ------
            % Unknown vector: [Pslack; Re(V2..VN); Qslack; Im(V2..VN)]
            Vs_init = Vs_iter;
            z0 = [real(Vs_init);
                  imag(Vs_init) ];%island mode
    
    
            S_additional=zeros(size(S_load_vec));
            [z_sol, fval, exitflag] = fsolve(@(z) complex_power_flow_eq( ...
                    z, Y_Bus, Yinv_DG_GFM, Yinv_Batt_GFM,Yinv_Batt_GFL,Yinv_Batt_EV, Yinv_PV, VterDG_GFM_bus, VinvBattGFM_bus, VinvBatt_bus, VinvEVBatt_bus, VinvPV_bus, ...
                    S_load_vec, S_additional,GFMbatt_noPower,batt_noPower,EVbatt_noPower), z0, opts);
    
            N = size(Y_Bus,1);
            VsR = z_sol(1:N);
            VsI = z_sol(N+1:end);
            k_PFrlx=1;%0.3~0.8
            Vs_iterold=Vs_iter;
            Vs_iter = k_PFrlx*(VsR + 1j*VsI)+(1-k_PFrlx)*Vs_iterold;

        elseif PFsolver==2
            % ------ Power-flow solve (Newton-Raphson, rectangular) ------
            Vs_init = Vs_iter;
            z0 = [real(Vs_init); imag(Vs_init)];
            
            S_additional = zeros(size(S_load_vec));
            
            
            
            [z_sol, fval, exitflag, iter] = newton_pf_fast_diag(z0,Y_Bus, Yinv_DG_GFM, Yinv_Batt_GFM, Yinv_Batt_GFL, Yinv_Batt_EV, Yinv_PV, ...
	            VterDG_GFM_bus, VinvBattGFM_bus, VinvBatt_bus, VinvEVBatt_bus, VinvPV_bus, ...
	            S_load_vec, S_additional, GFMbatt_noPower, batt_noPower, EVbatt_noPower,  nrOpt);
            
            N = size(Y_Bus,1);
            VsR = z_sol(1:N);
            VsI = z_sol(N+1:end);
            
            k_PFrlx		= 1; % optionally 0.5~0.8 if you need extra damping
            Vs_iterold	= Vs_iter;
            Vs_iter		= k_PFrlx*(VsR + 1j*VsI) + (1-k_PFrlx)*Vs_iterold;
        end

        % over-charging and over-discharging protection
        if BatteryNumGFM > 0
            for bb = 1:BatteryNumGFM
                ii = BusOfBatteryGFM(bb);
                if GFMbatt_noPower(ii)==1
                    VinvBattGFM_bus(ii)=Vs_iter(ii);
                    Vter_iter(DG_NumGFM+bb)=Vs_iter(ii);
                end
            end
        end
        if BatteryNum > 0
            for bb = 1:BatteryNum
                ii = BusOfBattery(bb);
                if batt_noPower(ii)==1
                    VinvBatt_bus(ii)=Vs_iter(ii);
                    Vter_iter(DG_NumGFM+BatteryNumGFM+bb)=Vs_iter(ii);
                end
            end
        end
        if EVBatteryNum > 0
            for bb = 1:EVBatteryNum
                ii = BusOfEVBattery(bb);
                if EVbatt_noPower(ii)==1
                    VinvEVBatt_bus(ii)=Vs_iter(ii);
                    Vter_iter(DG_NumGFM+BatteryNumGFM+BatteryNum+bb)=Vs_iter(ii);
                end
            end
        end

    end% end inner DAE loop

% end
    
    % ------ outputs ------
    X = X_iter;
    Vs    = Vs_iter;
    Vter  = Vter_iter;
    freq  = ([60+(dw_DG_GFM)/(2*pi);60+(dw_INV_GFM)/(2*pi);]);
    
    S_busInjVec = Vs .* conj(Y_Bus*Vs);
    S_inv_Batt  = Vs .* conj(Yinv_Batt_GFL * (VinvBatt_bus - Vs)) + Vs .* conj(Yinv_Batt_GFM * (VinvBattGFM_bus - Vs))+ Vs .* conj(Yinv_Batt_EV * (VinvEVBatt_bus - Vs));
    S_inv_PV    = Vs .* conj(Yinv_PV   * (VinvPV_bus   - Vs));
    S_DG    = Vs .* conj(Yinv_DG_GFM   * (VterDG_GFM_bus   - Vs));

    idx_ref=0;
    Pbatt=real(S_inv_Batt([BusOfBatteryGFM BusOfBattery BusOfEVBattery],1));
    h_sub=h*Niter;
    if BatteryNumGFM+BatteryNum+EVBatteryNum>0
        for ii=1:BatteryNumGFM+BatteryNum+EVBatteryNum
            Pbatt_dis=max(Pbatt(ii,1),0);% active power injected from the storage system
            Pbatt_ch=max(-Pbatt(ii,1),0);% active power consumed by the storage system
            if ii<=BatteryNumGFM
                jj=ii;
                E=EbattMaxGFM(jj);
            elseif ii>BatteryNumGFM && ii<=BatteryNumGFM+BatteryNum
                jj=ii-BatteryNumGFM;
                E=EbattMax(jj);
            else
                jj=ii-BatteryNumGFM-BatteryNum;
                E=EbattMaxEV(jj);
            end
            SOC(ii,1)=SOC(ii,1)+inta_batt_ch*Pbatt_ch*h_sub/E ...
                -Pbatt_dis*h_sub/(E*inta_batt_dis);
        end
    else
        SOC=SOC;
    end


    

    % ================= local functions =================
    function F = complex_power_flow_eq(decision_real_imag, Ybus, Yinv_DG_GFM, Yinv_Batt_GFM,Yinv_Batt_GFL,Yinv_Batt_EV,Yinv_PV, ...
                                       VterDG_GFM_bus, VinvBattGFM_bus, VinvBatt_bus, VinvEVBatt_bus, VinvPV_bus, S_load, S_additional,GFMbatt_noPower,batt_noPower,EVbatt_noPower)
        N = size(Ybus,1);
        Vs_real = decision_real_imag(1:N);
        Vs_imag = decision_real_imag(N+1:end);

        Vbus    = Vs_real + 1i*Vs_imag;

        % Slack complex power (island mode)
        % Psl = Real(1);  Qsl = Imag(1);
        S_sys         = zeros(size(S_load));%no exchange power with main grid
        % S_sys(1,1)    = Psl + 1j*Qsl;

        % check GFM none power condition
        for ii=1:N
            if GFMbatt_noPower(ii)==1
                VinvBattGFM_bus(ii)=Vbus(ii);
            end
            if batt_noPower(ii)==1
                VinvBatt_bus(ii)=Vbus(ii);
            end
            if EVbatt_noPower(ii)==1
                VinvEVBatt_bus(ii)=Vbus(ii);
            end
        end

        % Inverter injections
        S_inv = Vbus .* conj(Yinv_Batt_GFL * (VinvBatt_bus - Vbus)) + ...
                Vbus .* conj(Yinv_Batt_GFM * (VinvBattGFM_bus - Vbus)) + ...
                Vbus .* conj(Yinv_Batt_EV * (VinvEVBatt_bus - Vbus)) + ...
                Vbus .* conj(Yinv_DG_GFM * (VterDG_GFM_bus - Vbus)) + ...
                Vbus .* conj(Yinv_PV   * (VinvPV_bus   - Vbus));

        left  = Vbus .* conj(Ybus * Vbus);
        right = S_inv + S_sys + S_load + S_additional;


        F = [ real(left - right); imag(left - right)];
    end


    function [IncRate,dotX,Edq] = ode4_singleStep(Xin, h, f_dyn, varargin)
        X1 = Xin;
        [Edq,k1] = f_dyn(varargin{:}, X1);

        X2 = Xin + 0.5*h*k1;
        [~,k2] = f_dyn(varargin{:}, X2);

        X3 = Xin + 0.5*h*k2;
        [~,k3] = f_dyn(varargin{:}, X3);

        X4 = Xin + h*k3;
        [~,k4] = f_dyn(varargin{:}, X4);

        IncRate = (k1 + 2*k2 + 2*k3 + k4)/6;
        dotX    = k1;
    end
    function [IncRate,dotX,Edq,Pe] = ode4_singleStep0(Xin, h, f_dyn, varargin)
        X1 = Xin;
        [Edq,k1,Pe] = f_dyn(varargin{:}, X1);

        X2 = Xin + 0.5*h*k1;
        [~,k2,~] = f_dyn(varargin{:}, X2);

        X3 = Xin + 0.5*h*k2;
        [~,k3,~] = f_dyn(varargin{:}, X3);

        X4 = Xin + h*k3;
        [~,k4,~] = f_dyn(varargin{:}, X4);

        IncRate = (k1 + 2*k2 + 2*k3 + k4)/6;
        dotX    = k1;
    end
    function [IncRate, dotX0, Edq_end] = ode15s_singleStep(Xin, h, f_dyn, varargin)
	    % Integrate x' = f_dyn(..., x) from 0 -> h using ode15s.
	    % Returns:
	    %   IncRate  = (X(h) - Xin)/h            (same shape as Xin)
	    %   dotX0    = f_dyn(..., Xin)           (derivative at the start, like your k1)
	    %   Edq_end  = Edq evaluated at the end state X(h)
	    %
	    % f_dyn must have signature:  [Edq, dxdt] = f_dyn(arg1, arg2, ..., x)
    
	    % derivative at the start (keeps your freq logging consistent)
	    [~, dotX0] = f_dyn(varargin{:}, Xin);
    
	    % cache for the most recent Edq inside the RHS
	    Edq_cache = [];
    
	    % RHS wrapper compatible with ode15s
	    function dx = rhs(~, x)
		    [Edq_cache, dx] = f_dyn(varargin{:}, x);
	    end
    
	    % Stiff-safe tolerances; keep MaxStep <= h to force internal substeps
	    opts = odeset('RelTol',1e-6, 'AbsTol',1e-8, ...
	                  'MaxStep', h, 'InitialStep', min(h/10, 0.02*h));
    
	    % Integrate one macro-step
	    [~, Xtraj] = ode15s(@rhs, [0 h], Xin, opts);
    
	    Xend    = Xtraj(end,:).';
	    IncRate = (Xend - Xin) / h;   % so Xin + IncRate*h == Xend
	    Edq_end = Edq_cache;          % Edq at final internal evaluation
    end
    function [IncRate, dotX0, Edq_end,Psee] = ode15s_singleStep0(Xin, h, f_dyn, varargin)
	    % Integrate x' = f_dyn(..., x) from 0 -> h using ode15s.
	    % Returns:
	    %   IncRate  = (X(h) - Xin)/h            (same shape as Xin)
	    %   dotX0    = f_dyn(..., Xin)           (derivative at the start, like your k1)
	    %   Edq_end  = Edq evaluated at the end state X(h)
	    %
	    % f_dyn must have signature:  [Edq, dxdt] = f_dyn(arg1, arg2, ..., x)
    
	    % derivative at the start (keeps your freq logging consistent)
	    [~, dotX0, ~] = f_dyn(varargin{:}, Xin);
    
	    % cache for the most recent Edq inside the RHS
	    Edq_cache = [];
        Psee_cache = [];
    
	    % RHS wrapper compatible with ode15s
	    function dx = rhs(~, x)
		    [Edq_cache, dx,Psee_cache] = f_dyn(varargin{:}, x);
	    end
    
	    % Stiff-safe tolerances; keep MaxStep <= h to force internal substeps
	    opts = odeset('RelTol',1e-6, 'AbsTol',1e-8, ...
	                  'MaxStep', h, 'InitialStep', min(h/10, 0.02*h));
    
	    % Integrate one macro-step
	    [~, Xtraj] = ode15s(@rhs, [0 h], Xin, opts);
    
	    Xend    = Xtraj(end,:).';
	    IncRate = (Xend - Xin) / h;   % so Xin + IncRate*h == Xend
	    Edq_end = Edq_cache;          % Edq at final internal evaluation
        Psee = Psee_cache;
    end

end
