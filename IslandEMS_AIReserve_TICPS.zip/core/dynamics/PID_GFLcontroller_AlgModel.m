function [Vinv,dotXnumerE]=PID_GFLcontroller_AlgModel(Ref,FDBK,Xm_g,Zmv_g,XnumerE)
% input
Pref = Ref(1,1);
Qref = Ref(2,1);

Vinv=FDBK(1,1);
Vpcc=FDBK(2,1);

% fdbk voltage and current calculation & xy->dq
Theta_g = angle(Vpcc);
Zf   = 1j*Xm_g + Zmv_g;

Sref = Pref + 1j*Qref;

Iref = conj(Sref) / conj(Vpcc);

Imax_pu = 1.2;  
Imag     = abs(Iref);
if Imag > Imax_pu
	Iref = Iref * (Imax_pu / Imag);
end

Idref = real(Iref)*cos(Theta_g) + imag(Iref)*sin(Theta_g);
Iqref = -real(Iref)*sin(Theta_g) + imag(Iref)*cos(Theta_g);


I_act = (Vinv - Vpcc) / Zf;
Id = real(I_act)*cos(Theta_g) + imag(I_act)*sin(Theta_g);
Iq = -real(I_act)*sin(Theta_g) + imag(I_act)*cos(Theta_g);

Vinv_ref = Vpcc + Zf * Iref;
Vdref = real(Vinv_ref)*cos(Theta_g) + imag(Vinv_ref)*sin(Theta_g);
Vqref = -real(Vinv_ref)*sin(Theta_g) + imag(Vinv_ref)*cos(Theta_g);

% Imax_pu = 1.2;  
% Imag     = abs(Iref);
% if Imag > Imax_pu
% 	Iref = Iref * (Imax_pu / Imag);
% end

% kd=real(Zf);
% kq=imag(Zf);
kd=0.1/2;
kq=kd;
Vd = Vdref + kd*(Idref - Id) + XnumerE(1);
Vq = Vqref + kq*(Iqref - Iq) + XnumerE(2);
kId=2;
kIq=kId;
dotXnumerE(1,1)=kId*(Idref - Id);
dotXnumerE(2,1)=kIq*(Iqref - Iq);

Ex = Vd*cos(Theta_g) - Vq*sin(Theta_g);
Ey = Vd*sin(Theta_g) + Vq*cos(Theta_g);
Vinv = (Ex + 1j*Ey);


