function s = summarize_result(result,cfg)
%SUMMARIZE_RESULT Compact result record for tables, ablations, and replay.
s = struct();
s.methodID = string(result.meta.methodID);
s.caseName = string(result.meta.caseName);
s.topologyKey = string(result.meta.topologyKey);
s.decayRatio = result.meta.decayRatio;
s.randomSeed = result.meta.randomSeed;
s.reserveMode = string(result.meta.reserveMode);
s.curtailmentMode = string(result.meta.curtailmentMode);
s.aiSafetyCalibration = logical(result.meta.aiSafetyCalibration);
s.totalCost = result.totalCost;
if isfield(result,'solver')
    ef=result.solver.optimizationExitflag;
    if isempty(ef)
        s.optimizationFailureRate=NaN;
        s.optimizationWarningRate=NaN;
        s.optimizationConvergedRate=NaN;
    else
        % Keep hard failure separate from coneprog -7 numerical warnings.
        s.optimizationFailureRate=mean(~(ef>0 | ef==-7),'omitnan');
        s.optimizationWarningRate=mean(ef==-7,'omitnan');
        s.optimizationConvergedRate=mean(ef>0,'omitnan');
    end
    pfef=result.solver.physicalPFExitflag;
    if isempty(pfef), s.physicalPFFailureRate=NaN; else, s.physicalPFFailureRate=mean(pfef<=0,'omitnan'); end
else
    s.optimizationFailureRate=NaN; s.optimizationWarningRate=NaN; s.optimizationConvergedRate=NaN; s.physicalPFFailureRate=NaN;
end
% Numerical quality of coneprog iterates, including exitflag -7 cases.
s.maxSolverManualResidual=NaN; s.maxSolverPrimalFeasibility=NaN;
s.maxSolverDualFeasibility=NaN; s.maxSolverRelativeGap=NaN;
s.solverRetryRate=0;
if isfield(result,'solver') && isfield(result.solver,'coneprogDiagnostics') && ...
        ~isempty(result.solver.coneprogDiagnostics)
    C=result.solver.coneprogDiagnostics;
    C=C(~cellfun(@isempty,C));
    if ~isempty(C)
        D=[C{:}];
        s.maxSolverManualResidual=max([D.maxManualConstraintViolation],[],'omitnan');
        s.maxSolverPrimalFeasibility=max([D.primalFeasibility],[],'omitnan');
        s.maxSolverDualFeasibility=max([D.dualFeasibility],[],'omitnan');
        s.maxSolverRelativeGap=max([D.relativeGap],[],'omitnan');
        if isfield(D,'retryUsed'), s.solverRetryRate=mean([D.retryUsed]); end
    end
end

s.maxAbsFreqDev_Hz = max(abs(result.freq_Hz(:)-cfg.frequency.nominal_Hz),[],'omitnan');
if isfield(result,'freqAll_Hz') && ~isempty(result.freqAll_Hz)
    s.maxIndividualFreqDev_Hz=max(abs(result.freqAll_Hz(:)-cfg.frequency.nominal_Hz),[],'omitnan');
else
    s.maxIndividualFreqDev_Hz=NaN;
end
if numel(result.freq_Hz)>1
    dt_s=3600/cfg.simulation.samplePerHour;
    s.maxAbsRoCoF_Hz_s=max(abs(diff(result.freq_Hz(:))/dt_s),[],'omitnan');
else
    s.maxAbsRoCoF_Hz_s=NaN;
end
if isfield(result,'freqAll_Hz') && size(result.freqAll_Hz,2)>1
    dt_s=3600/cfg.simulation.samplePerHour;
    s.maxIndividualRoCoF_Hz_s=max(abs(diff(result.freqAll_Hz,1,2)/dt_s),[],'all','omitnan');
else
    s.maxIndividualRoCoF_Hz_s=NaN;
end
if ~isempty(result.voltage_pu)
    s.minVoltage_pu=min(abs(result.voltage_pu),[],'all','omitnan');
    s.maxVoltage_pu=max(abs(result.voltage_pu),[],'all','omitnan');
else
    s.minVoltage_pu=NaN; s.maxVoltage_pu=NaN;
end
if ~isempty(result.current_pu) && ~isempty(result.lineLimits_pu)
    ratio=bsxfun(@rdivide,abs(result.current_pu),result.lineLimits_pu(:));
    s.maxCurrentRatio=max(ratio,[],'all','omitnan');
else
    s.maxCurrentRatio=NaN;
end
% Formal EMS frequency-security metric uses system/CoI frequency.  The
% individual rotor-frequency violation rate is retained separately as a
% diagnostic and is not used as the learned frequency-stress target.
if isfield(result.interval,'frequencySecureCoI')
    s.frequencyViolationRate=mean(~result.interval.frequencySecureCoI,'omitnan');
else
    freqBad = result.interval.maxAbsFreqDev_Hz > cfg.frequency.securityDeviation_Hz | ...
        result.interval.maxAbsRoCoF_Hz_s > cfg.frequency.securityRoCoF_Hz_s;
    s.frequencyViolationRate=mean(freqBad,'omitnan');
end
if isfield(result.interval,'frequencySecureIndividual')
    s.individualFrequencyViolationRate=mean(~result.interval.frequencySecureIndividual,'omitnan');
else
    s.individualFrequencyViolationRate=NaN;
end
if isfield(result.interval,'networkSecure')
    s.securityViolationRate=mean(~(result.interval.frequencySecureCoI & result.interval.networkSecure),'omitnan');
else
    s.securityViolationRate=s.frequencyViolationRate;
end
s.meanReserveRatio=mean(result.reserve.ratio,'omitnan');
s.stdReserveRatio=std(result.reserve.ratio,0,'omitnan');

% Use the actual post-clipping reserve returned by the reserve module.
reserveTotal_kW=[];
clipped=[];
oodFallback=[];
noSafeFallback=[];
missingFeatureFallback=[];
if isfield(result.reserve,'metaHistory') && ~isempty(result.reserve.metaHistory)
    for k=1:numel(result.reserve.metaHistory)
        m=result.reserve.metaHistory{k};
        if isempty(m) || ~isfield(m,'reservePu'), continue; end
        rp=m.reservePu(:);
        ratings=result.DG_rating_MW(:);
        n=min(numel(rp),numel(ratings));
        reserveTotal_kW(end+1)=1000*sum(rp(1:n).*ratings(1:n)); %#ok<AGROW>
        if isfield(m,'clippedByFeasibility')
            clipped(end+1)=logical(m.clippedByFeasibility); %#ok<AGROW>
        end
        if isfield(m,'prediction') && isfield(m.prediction,'oodFallback')
            oodFallback(end+1)=logical(m.prediction.oodFallback); %#ok<AGROW>
        end
        if isfield(m,'prediction') && isfield(m.prediction,'noSafeCandidateFallback')
            noSafeFallback(end+1)=logical(m.prediction.noSafeCandidateFallback); %#ok<AGROW>
        end
        if isfield(m,'prediction') && isfield(m.prediction,'missingFeatureFallback')
            missingFeatureFallback(end+1)=logical(m.prediction.missingFeatureFallback); %#ok<AGROW>
        end
    end
elseif isfield(result.reserve,'staticMeta') && ~isempty(fieldnames(result.reserve.staticMeta)) && ...
        isfield(result.reserve.staticMeta,'reservePu')
    rp=result.reserve.staticMeta.reservePu(:);
    ratings=result.DG_rating_MW(:);
    n=min(numel(rp),numel(ratings));
    reserveTotal_kW=1000*sum(rp(1:n).*ratings(1:n));
    if isfield(result.reserve.staticMeta,'clippedByFeasibility')
        clipped=logical(result.reserve.staticMeta.clippedByFeasibility);
    end
end
if isempty(reserveTotal_kW)
    R=cfg.frequency.droop_pu;
    H=cfg.frequency.H_s;
    physicsPu=max(cfg.frequency.reserveDeviation_Hz/(R*cfg.frequency.nominal_Hz), ...
        2*H*cfg.frequency.reserveRoCoF_Hz_s/cfg.frequency.nominal_Hz);
    reserveTotal_kW=1000*s.meanReserveRatio*physicsPu*sum(result.DG_rating_MW,'omitnan');
end
s.meanTotalDGReserve_kW=mean(reserveTotal_kW,'omitnan');
s.maxTotalDGReserve_kW=max(reserveTotal_kW,[],'omitnan');
if isempty(clipped), s.reserveFeasibilityClipRate=0; else, s.reserveFeasibilityClipRate=mean(clipped); end
if isempty(oodFallback), s.aiOODFallbackRate=0; else, s.aiOODFallbackRate=mean(oodFallback); end
if isempty(noSafeFallback), s.aiNoSafeCandidateFallbackRate=0; else, s.aiNoSafeCandidateFallbackRate=mean(noSafeFallback); end
if isempty(missingFeatureFallback), s.aiMissingFeatureFallbackRate=0; else, s.aiMissingFeatureFallbackRate=mean(missingFeatureFallback); end

if isfield(result,'flexibility')
    s.loadShedEnergy_kWh=getfield_default(result.flexibility,'loadShedEnergy_kWh',NaN);
    s.EVUnmetEnergy_kWh=getfield_default(result.flexibility,'EVUnmetEnergy_kWh',NaN);
    s.EVCommutingViolation_kWh=getfield_default(result.flexibility,'EVCommutingViolation_kWh',NaN);
    s.BESSTerminalDeficit_kWh=getfield_default(result.flexibility,'BESSTerminalDeficit_kWh',NaN);
    s.PVCurtailedEnergy_kWh=getfield_default(result.flexibility,'PVCurtailedEnergy_kWh',NaN);
else
    s.loadShedEnergy_kWh=NaN;
    s.EVUnmetEnergy_kWh=NaN;
    s.EVCommutingViolation_kWh=NaN;
    s.BESSTerminalDeficit_kWh=NaN;
    s.PVCurtailedEnergy_kWh=NaN;
end

s.meanDecisionTime_s=mean(result.decisionTime_s,'all','omitnan');
if isfield(result.reserve,'evalTime_s')
    s.meanReserveEvalTime_ms=1000*mean(result.reserve.evalTime_s,'all','omitnan');
else
    s.meanReserveEvalTime_ms=NaN;
end
if isfield(result,'performance')
    s.staticStructureBuild_s=getfield_default(result.performance,'staticStructureBuild_s',NaN);
    s.staticCacheReused=getfield_default(result.performance,'staticCacheReused',false);
    s.decisionSetupPostTotal_s=getfield_default(result.performance,'decisionSetupPost_s',NaN);
    s.forecastBuildTotal_s=getfield_default(result.performance,'forecastBuildTotal_s',NaN);
    s.dynamicAssemblyTotal_s=getfield_default(result.performance,'dynamicAssemblyTotal_s',NaN);
    s.postprocessTotal_s=getfield_default(result.performance,'postprocessTotal_s',NaN);
    s.physicalLoopRecordTotal_s=getfield_default(result.performance,'physicalLoopRecord_s',NaN);
    s.totalCoupledRuntime_s=getfield_default(result.performance,'totalCoupledRuntime_s',NaN);
else
    s.staticStructureBuild_s=NaN; s.staticCacheReused=false;
    s.decisionSetupPostTotal_s=NaN; s.forecastBuildTotal_s=NaN;
    s.dynamicAssemblyTotal_s=NaN; s.postprocessTotal_s=NaN;
    s.physicalLoopRecordTotal_s=NaN; s.totalCoupledRuntime_s=NaN;
end
end

function v=getfield_default(s,name,defaultValue)
if isfield(s,name), v=s.(name); else, v=defaultValue; end
end
