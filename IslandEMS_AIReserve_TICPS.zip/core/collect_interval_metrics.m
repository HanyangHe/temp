function interval = collect_interval_metrics(result,cfg)
%COLLECT_INTERVAL_METRICS Decision-interval physical security metrics.
% Frequency security is checked against BOTH the synchronous-DG CoI signal
% and individual saved frequency states so an unsafe local response cannot
% be hidden by averaging. Network security remains a separate check.

freq = result.freq_Hz(:).';
Nsim = numel(result.time_h);
if numel(freq) > Nsim, freq = freq(1:Nsim); end

freqAll=[];
if isfield(result,'freqAll_Hz') && ~isempty(result.freqAll_Hz)
    freqAll=result.freqAll_Hz;
    if size(freqAll,2)>Nsim, freqAll=freqAll(:,1:Nsim); end
end

samplesPerDecision = round(cfg.simulation.samplePerHour*24/cfg.mpc.decisionLevelSteps);
Nint = min(cfg.mpc.decisionLevelSteps,floor(numel(freq)/samplesPerDecision));
dt_s = 3600/cfg.simulation.samplePerHour;

interval.maxAbsFreqDev_Hz = nan(1,Nint);
interval.maxAbsRoCoF_Hz_s = nan(1,Nint);
interval.maxIndividualFreqDev_Hz = nan(1,Nint);
interval.maxIndividualRoCoF_Hz_s = nan(1,Nint);
interval.minVoltage_pu = nan(1,Nint);
interval.maxVoltage_pu = nan(1,Nint);
interval.maxCurrentRatio = nan(1,Nint);
interval.frequencySecureCoI = false(1,Nint);
interval.frequencySecureIndividual = false(1,Nint);
interval.frequencySecure = false(1,Nint); % legacy combined diagnostic
interval.networkSecure = false(1,Nint);
interval.secure = false(1,Nint);

for k=1:Nint
    idx=(k-1)*samplesPerDecision+1:k*samplesPerDecision;
    fk=freq(idx);
    interval.maxAbsFreqDev_Hz(k)=max(abs(fk-cfg.frequency.nominal_Hz),[],'omitnan');
    if numel(fk)>=2
        interval.maxAbsRoCoF_Hz_s(k)=max(abs(diff(fk)/dt_s),[],'omitnan');
    end

    if ~isempty(freqAll) && size(freqAll,2)>=idx(end)
        fall=freqAll(:,idx);
        interval.maxIndividualFreqDev_Hz(k)=max( ...
            abs(fall-cfg.frequency.nominal_Hz),[],'all','omitnan');
        if size(fall,2)>=2
            interval.maxIndividualRoCoF_Hz_s(k)=max( ...
                abs(diff(fall,1,2)/dt_s),[],'all','omitnan');
        end
    end

    if ~isempty(result.voltage_pu) && size(result.voltage_pu,2)>=idx(end)
        vk=abs(result.voltage_pu(:,idx));
        interval.minVoltage_pu(k)=min(vk,[],'all','omitnan');
        interval.maxVoltage_pu(k)=max(vk,[],'all','omitnan');
    end
    if ~isempty(result.current_pu) && ~isempty(result.lineLimits_pu) && ...
            size(result.current_pu,2)>=idx(end)
        ik=abs(result.current_pu(:,idx));
        lim=result.lineLimits_pu(:);
        ratio=bsxfun(@rdivide,ik,lim);
        interval.maxCurrentRatio(k)=max(ratio,[],'all','omitnan');
    end

    % Formal EMS/oracle security target is the system/CoI signal.
    coiFreqOK=isfinite(interval.maxAbsFreqDev_Hz(k)) && ...
        interval.maxAbsFreqDev_Hz(k)<=cfg.frequency.securityDeviation_Hz;
    coiRoCoFOK=~isfinite(interval.maxAbsRoCoF_Hz_s(k)) || ...
        interval.maxAbsRoCoF_Hz_s(k)<=cfg.frequency.securityRoCoF_Hz_s;
    interval.frequencySecureCoI(k)=coiFreqOK && coiRoCoFOK;

    % Individual rotor-frequency security is retained only as a diagnostic.
    if isfinite(interval.maxIndividualFreqDev_Hz(k))
        indFreqOK=interval.maxIndividualFreqDev_Hz(k)<=cfg.frequency.securityDeviation_Hz;
    else
        indFreqOK=true;
    end
    if isfinite(interval.maxIndividualRoCoF_Hz_s(k))
        indRoCoFOK=interval.maxIndividualRoCoF_Hz_s(k)<=cfg.frequency.securityRoCoF_Hz_s;
    else
        indRoCoFOK=true;
    end
    interval.frequencySecureIndividual(k)=indFreqOK && indRoCoFOK;
    interval.frequencySecure(k)=interval.frequencySecureCoI(k) && ...
        interval.frequencySecureIndividual(k); % backward-compatible diagnostic

    vOK = isnan(interval.minVoltage_pu(k)) || ...
        (interval.minVoltage_pu(k)>=cfg.network.Vmin_pu && ...
         interval.maxVoltage_pu(k)<=cfg.network.Vmax_pu);
    iOK = isnan(interval.maxCurrentRatio(k)) || interval.maxCurrentRatio(k)<=1;
    interval.networkSecure(k)=vOK && iOK;
    interval.secure(k)=interval.frequencySecure(k) && interval.networkSecure(k);
end
end
