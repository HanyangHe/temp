%% Diagnose canonical randomized-alpha frequency-response dataset (no simulation)
% clear; clc;
projectRoot=fileparts(mfilename('fullpath'));
addpath(genpath(projectRoot));
cfg=config_island_ems(); validate_config(cfg);

caseNames=cellstr(string(cfg.ai.response.systemCases));
if isempty(caseNames), error('cfg.ai.response.systemCases is empty.'); end
caseName=caseNames{1};

[dataset,f,msg]=find_latest_compatible_response_dataset(projectRoot,cfg,caseName);
if isempty(dataset)
    error('[%s] No compatible response dataset found: %s',caseName,msg);
end
fprintf('Dataset: %s\n',f);
fprintf('Case: %s | samples: %d | groups: %d | safe observed samples: %.1f%%\n', ...
    dataset.caseName,size(dataset.X,1),numel(unique(dataset.groupID)),100*mean(dataset.secure));
fprintf('Offline training alpha range: [%.2f, %.2f] | online permitted alpha range: [%.2f, %.2f]\n', ...
    cfg.ai.response.trainingAlphaMin,cfg.ai.response.trainingAlphaMax,cfg.ai.alphaMin,cfg.ai.alphaMax);
fprintf('Stress: min %.3f | median %.3f | mean %.3f | max %.3f | std %.3f\n', ...
    min(dataset.yStress),median(dataset.yStress),mean(dataset.yStress), ...
    max(dataset.yStress),std(dataset.yStress));

levels=sort(unique(dataset.alpha(:)));
counts=arrayfun(@(a)sum(abs(dataset.alpha-a)<1e-12),levels);
T=table(levels,counts,'VariableNames',{'Alpha','Count'}); disp(T);

figure('Name',sprintf('%s randomized-alpha response dataset',caseName));
tiledlayout(2,2);
nexttile; histogram(dataset.yStress); xline(1,'--'); xlabel('Frequency stress'); ylabel('Count'); grid on;
nexttile; histogram(dataset.alpha); xlabel('\alpha'); ylabel('Count'); grid on;
nexttile; scatter(dataset.alpha,dataset.yStress,16,dataset.decayRatio,'filled'); yline(1,'--');
xlabel('\alpha'); ylabel('Frequency stress'); grid on; colorbar;
nexttile; scatter(dataset.Xstate(:,1),dataset.yStress,16,dataset.alpha,'filled');
xlabel('P_{net} (pu)'); ylabel('Frequency stress'); grid on; colorbar;
