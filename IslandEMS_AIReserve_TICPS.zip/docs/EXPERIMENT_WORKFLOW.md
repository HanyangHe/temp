# Experiment workflow for the randomized-alpha AI reserve paper

## Stage 0 — physical/model checks

1. Run `tests/run_all_tests.m`.
2. Run `tests/smoke_T7_18bus.m` on the radial 18-bus case.
3. Verify the 0.30-Hz nominal reserve, CoI frequency/RoCoF, network limits, solver diagnostics, and runtime.

## Stage 1 — efficient response-data generation

The deprecated alpha* oracle sweep is not used.  Each offline training trajectory uses a balanced randomized reserve ratio at every 15-min MPC update.  One interval therefore contributes one sample

`[Pnet, |dPnet|, DG upward headroom, alpha] -> frequency stress`.

Frequency stress is the maximum of normalized CoI frequency deviation and normalized CoI RoCoF.  `stress <= 1` is secure.

- `quick`: 3 irradiance trajectories/grid (pipeline proof-of-concept).
- `paper`: 5 irradiance levels x 2 randomized/noise seeds = 10 trajectories/grid.

## Stage 2 — train and calibrate the stress-response KRR

Run `train_AIReserve.m`.  The model predicts frequency stress for candidate alpha values.  A one-sided calibration offset limits unsafe stress underprediction.  Online, the smallest alpha in `cfg.ai.candidateAlphaGrid` whose calibrated predicted stress is secure is selected.  If the state is missing/OOD or no candidate is predicted secure, the policy falls back to `alpha=1`.

Each radial grid owns one reusable model under `ai/models/<case>/reserve_krr_model.mat`.

## Stage 3 — pre-main gate

Run `tests/final_AIReserve_pre_main_test.m`.  It verifies the per-grid model signature, response target, calibration metrics, global-fixed baseline, and online inference without starting a simulation.

## Stage 4 — focused formal ablation

Use:

- `A0`: no frequency reserve;
- `T7`: full fixed physics reserve (`alpha=1`);
- `G1`: one globally tuned fixed alpha learned from training states;
- `P1U`: state-dependent response-model policy without one-sided calibration;
- `P1`: proposed calibrated state-dependent reserve policy.

Primary metrics: CoI frequency violation, CoI RoCoF, reserve ratio/MW, cost, service impacts, network feasibility, OOD/no-safe fallback rates, and computation time.

## Stage 5 — formal response training and three-grid study

After the quick pipeline is valid, set `cfg.ai.response.profile='paper'` and train one model for each of `10bus`, `18bus`, and `33bus`.  Learned coefficients are grid-specific; the method architecture is common.
