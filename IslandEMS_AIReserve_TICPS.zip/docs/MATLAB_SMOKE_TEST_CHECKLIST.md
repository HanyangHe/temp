# MATLAB checklist before formal mainV4

1. Run `tests/run_all_tests.m`.
2. Run `result = smoke_T7_18bus();` and confirm the radial 18-bus fixed-reserve baseline is physically credible.
3. Verify `reserveDeviation_Hz=0.30`, security limit `0.50 Hz`, and alpha=1 means the full nominal physics reserve.
4. Confirm CoI frequency/RoCoF, voltage/current, SoC, cost, and solver diagnostics are acceptable.
5. Set `cfg.ai.response.profile='quick'` and run `train_AIReserve.m` to verify the randomized-alpha response-learning pipeline.
6. Run `analyze_AIReserve_dataset.m` and inspect alpha coverage, frequency-stress distribution, and safe/unsafe balance.
7. Run `final_AIReserve_pre_main_test()`.
8. Only then enable `{'A0','T7','G1','P1U','P1'}` and run the focused mainV4 ablation.
9. For paper-scale training, set `cfg.ai.response.profile='paper'` and train the required radial grid models.

The old fixed-alpha full-day alpha* oracle sweep is deprecated and must not be used.
