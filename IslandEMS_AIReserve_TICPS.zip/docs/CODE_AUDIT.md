# Code audit and revision notes

## Scope of this refactor

The uploaded `mainV4` project was reorganized around the revised TICPS contribution: **physics-guided data-driven adaptive frequency reserve for convex MPC-EMS**. The implementation was statically audited and refactored, but it has **not been executed in MATLAB in this environment**. Numerical claims must be regenerated after MATLAB smoke tests.

## 1. Frequency-reserve base inconsistency — corrected

The legacy optimizer effectively formed reserve as a per-unit fraction of each DG's local rating, while the physical DG dynamic model used a droop power term without `Prate`, making the dynamic response behave as though the 3% droop were on a 1-MW/system base.

The revised DG model uses

```matlab
Pm_cmd_uf = Pref_eff + Prate*KIsec*xI ...
    - (Prate/Rdroop)*(dw/omega_b);
```

and the swing equation uses local-machine active-power base:

```matlab
dot_dw = ((Pm-Pe)/Prate - D*(dw/omega_b))/(2*H_h)*omega_b;
```

`H`, `D`, and `Rdroop` are therefore explicitly defined on each DG's own active-power rating. `Pmin`/`Pmax` in the dynamic model are also taken from the same central configuration as the EMS optimizer.

For the revised conventional physics baseline:

- `Delta f_res = 0.50 Hz`
- `Rdroop = 0.03`
- `f0 = 60 Hz`

fixed droop reserve = `0.277778 pu` of each local DG rating:

- 140 kW DG -> 38.89 kW
- 150 kW DG -> 41.67 kW

This preserves the manuscript's 0.50-Hz admissible-frequency meaning while removing the erroneous 1-MW-per-machine base that produced 277.8 kW.

## 2. Reserve-design and security limits — separated

The revised configuration distinguishes:

- `reserveDeviation_Hz = 0.50`: analytical droop-reserve design;
- `reserveRoCoF_Hz_s = 0.50`: analytical RoCoF-reserve design;
- `securityDeviation_Hz = 0.50`: physical security evaluation;
- `securityRoCoF_Hz_s = 0.50`: physical security evaluation.

The variables are deliberately separated by *meaning* even though the default frequency-deviation values are equal. This avoids the former manuscript/code ambiguity and makes later sensitivity studies explicit.

## 3. New AI adaptive-reserve module

The physical reserve is

```text
r_phy = max(Delta_f_res/(R*f0), 2*H*RoCoF_res/f0)
```

and the proposed reserve is

```text
r_adapt = alpha(state) * r_phy.
```

The KRR model predicts only the dimensionless multiplier `alpha`; the resulting reserve remains a known parameter before each MPC solve, so no learning model is embedded as a nonlinear optimization constraint.

Implemented safeguards:

- grouped train/calibration/test split by physical scenario;
- grouped cross-validation for KRR `sigma`/`lambda` when enough groups exist;
- a training-only global fixed-ratio comparator (`G1`) at the same one-sided risk level, so the paper can distinguish state-dependent adaptation from simply retuning one scalar reserve;
- one-sided calibration offset to reduce under-reserve risk;
- AI ratio clipping to a configured range;
- out-of-distribution fallback that restores at least the conventional physical reserve (`alpha >= 1`) when a feature leaves the expanded training box;
- feasibility clipping so symmetric reserve cannot invert the DG lower/upper power bounds;
- censored oracle samples excluded from exact-label regression by default;
- non-monotone alpha/security sweeps diagnosed and conservatively labeled with a safe suffix.

## 4. Removed interval-refinement path

All interval-representativeness / post-optimization command interpolation / frequency-triggered BESS corrective execution logic has been removed from the active MATLAB sources. EMS commands are applied by zero-order hold at the 1-h EMS decision interval. Interpolation remains only for exogenous physical load/PV profile generation.

The old single-DG interval-refinement result file and historical live scripts are not included in the revised project.

## 5. Storage and EV energy-capacity bugs — corrected

### BESS duration

The revised setting is 8 h, consistent with the rejected manuscript.

### Per-device BESS energy capacity

The legacy code reused a scalar capacity based on the first BESS. This is incorrect for the uploaded 33-bus case, whose BESS power ratings are heterogeneous. The revised code constructs `E_BESS_MWh` per device and all SoC constraints/dynamic updates use the corresponding element.

### EV double counting

`BatteryEV_P_rate` already contains `numberOfEVs * 7 kW`. The legacy capacity calculation multiplied by the EV number again. The revised code uses:

```text
E_EV = aggregate EV charger power * EV energy duration
```

without another EV-count factor.

## 6. Hidden EV terminal slack — disabled

The uploaded code contained a numerical terminal-SoC slack (`SOCrelaxGap=0.1`) not described in the manuscript. Its decision variable is retained to preserve the inherited optimization-vector layout, but its upper bound is zero by default:

```matlab
cfg.ev.terminalNumericalSlackMax = 0.0;
```

The explicit EV terminal-deficit variable is now the intended relaxation mechanism.

## 7. Physical EV upper-SoC threshold — corrected

The legacy physical DAE solver allowed EV charging/disconnection logic to use `1.05*SOCmax`, creating an undocumented 5% upper-SoC margin outside the optimization model. The revised physical execution uses the configured `SOCmax` directly, consistent with the EMS constraints. Paper results involving EV SoC must therefore be regenerated.

## 8. Objective/cost consistency — corrected

The manuscript defines prices in $/kWh while decision powers are numerically MW on the 1-MVA system base. Revised objective coefficients explicitly include:

```text
1000 * power(MW) * duration(h) * price($/kWh).
```

Terminal SoC deficit penalties are multiplied by the corresponding device MWh capacity. A further audit found that the rejected formulation **double counted energy losses**: DG output already increases to supply branch-flow losses and battery-conversion losses through the network/SoC balances, yet the old objective charged `C_DG*P_loss` and explicit `C_DG*(1-eta)P_batt` terms again. The revised economic objective charges DG generation once at the source, retains battery-throughput degradation costs, and lets physical losses affect cost through the extra DG energy they require. The SOCP `l*r` line-loss variables therefore have no duplicate monetary coefficient. The hidden negative PV-output incentive is disabled by default (`pvCurtailment_per_kWh = 0`).

The running-cost recorder uses the same corrected convention and, for MPC cases, the **currently executed** load-shedding action rather than repeatedly indexing action 1.

## 9. Physical frequency metric — improved

The saved `freq_Hz` signal is now the inertia-times-rating weighted synchronous-DG center-of-inertia frequency instead of a simple arithmetic mean. Individual frequency states are also saved and summarized. Decision-interval frequency security—and therefore the AI oracle label—checks **both CoI and individual frequency/RoCoF peaks**, so local divergence cannot be hidden by an average.

## 10. Test-system parameters — centralized

Physical test-grid settings have been moved to:

```text
config/system_case_catalog.m
```

so the method layer is independent of grid size. The main AI study remains configurable to one test grid (recommended default: 18-bus meshed), while the same reserve module can be called for all supported network cases.

The old manuscript and uploaded code do not agree on every rated value; see `MANUSCRIPT_CODE_ALIGNMENT.md`. No undocumented capacity change was silently made solely to reproduce the old table.

## 11. Input-shape and reproducibility cleanup

- `busdata.m` normalizes component-rating vectors to column form before indexed assignment.
- every run resets the RNG from `runCfg.randomSeed`, so method comparisons use the same randomized load ratings/noise for a given scenario;
- irradiance stress levels are explicit `[0.20 0.40 0.60 0.80 1.00]`;
- `UniversalCurve` optional-argument handling was corrected;
- no-reserve mode stays exactly at alpha=0 and is not clipped to the AI minimum.
- the day-ahead LP baseline now uses `linprog` directly instead of calling `intlinprog` with an empty integer set.
- optimizer outputs are checked before indexing/physical execution; empty or nonfinite decisions now fail fast and non-success exit flags are surfaced.

## 12. Independent methods, outputs, and replay

Each baseline/proposed method is selected through `baseline_catalog.m` and can be run independently. Results are written to:

```text
outputs/<timestamp>/<methodID>/...
```

with `run_manifest.mat` and `summary.csv` in the run root. Fixed-alpha oracle sweeps include the alpha value in each filename so intermediate cases cannot overwrite one another. Saved outputs include frequency/network/SoC signals, optimization and physical-PF exit flags, adaptive-reserve histories, AI evaluation time, load shedding, EV unmet energy, commuting-energy violation, BESS terminal deficit, and PV curtailment. `replay_results.m` reads saved results without re-solving the optimization.

## 13. Important remaining physical convention

The uploaded code does not establish unambiguously whether DG `Ra` and `Xd_prime` are machine-base or system-base per-unit values. The default:

```matlab
cfg.frequency.dgImpedanceBase = 'system';
```

preserves the legacy numerical values. `Ra` and `Xd_prime` are now centralized as `cfg.frequency.dgRa_pu` and `cfg.frequency.dgXdPrime_pu`. Switch to `'machine'` only after the source parameter convention is verified.

The inherited network equations also rely on the numerical equivalence of per-unit power and MW at a **1-MVA base**; `validate_config` prevents silently changing `Sbase` without a full unit refactor.

## 14. What must be rerun

Because the physical DG droop/inertia convention changed, all frequency-dependent figures and classifications from the rejected paper are obsolete. At minimum rerun:

- T1–T7 frequency curves if retained;
- fixed-reserve vs no-reserve comparisons;
- severe-shortage frequency-violation results;
- costs affected by the corrected objective/capacity handling;
- all new oracle, KRR, and AI-reserve experiments.

Follow `MATLAB_SMOKE_TEST_CHECKLIST.md` before launching paper-scale runs.
