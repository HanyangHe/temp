# Removed legacy/dead files

These files were omitted from the revised TICPS code because they are not reachable from the retained T1–T7/A0/G1/P1U/P1 execution paths. The user's original ZIP remains the archive if any historical variant is needed.

- `core/dynamics/PID_DroopGFLcontroller_DynModel.m`
- `core/dynamics/PID_GFLcontroller_DynModel.m`
- `core/dynamics/PID_GFMcontroller_DynModel20251015.m`
- `core/dynamics/PID_GFMcontroller_DynModel20251015v2.m`
- `core/optimization/ConeConstraintsForBFS_SOCP_island.m`
- `core/optimization/ConeConstraintsForBFS_SOCP_island_withEVenShedding.m`
- `core/optimization/ConeConstraintsForBFS_SOCP_island_withLoadShed_MPC.m`
- `core/optimization/ConeConstraintsForDGcapacity_island.m`
- `core/optimization/ConeConstraintsForDGcapacity_island_withEVenShedding.m`
- `core/optimization/ConeConstraintsForDGcapacity_island_withLoadShed_MPC.m`
- `core/optimization/LinearEqualityConstBFS_SOCP_powerbalance_island_withLS_MPC.m`
- `core/optimization/LinearEqualityConstraintsForBFS_SOCP_powerbalance_island.m`
- `core/optimization/LinearEqualityConstraintsForBFS_SOCP_powerbalance_island_withES.m`
- `core/optimization/SOC_InequalityConstraintsForBFS.m`
- `core/optimization/SOC_InequalityConstraintsForBFS_withLoadShed_MPC.m`
- `core/optimization/SOC_InequalityConstraints_withEVenShedding.m`
- `core/network/angleLoopIneqConstraints.m`
- `core/network/getAllBranchPairs.m`
- `core/network/newton_power_flow_rect.m`
- `utils/knnCPU.m`

The original live scripts and all interval-representativeness / post-optimization command-refinement artifacts were intentionally excluded from the revised project.
