# Manuscript–code alignment notes for the TICPS rewrite

This file records discrepancies found between the rejected TSG manuscript and the uploaded MATLAB implementation. The revised TICPS paper should use one final, explicitly frozen parameter table generated from the corrected code rather than copying the old table.

## Frequency reserve / dynamic model

- Rejected manuscript: the reserve equation was written with `P_base,g = 1 MW` and `Delta f = 0.5 Hz`, which implies approximately 277.8 kW droop reserve per DG and is inconsistent with 140–150 kW units.
- Uploaded optimizer: actually used `Delta f_res = 0.2 Hz` as a *per-unit-on-local-DG-rating* reserve fraction, giving 15.56 kW for 140 kW and 16.67 kW for 150 kW.
- Uploaded dynamic DG model: omitted the local `Prate` factor in the droop power response and therefore did not use the same base convention as the optimizer.
- Revised code: both reserve and DG dynamics use the DG's own active-power rating. The conventional fixed-reserve baseline now uses the manuscript's 0.5-Hz admissible deviation on the **local DG rating**, giving 38.89 kW for 140 kW and 41.67 kW for 150 kW. Reserve-design and security-evaluation variables remain separately named to avoid future ambiguity.

All frequency-dependent results must therefore be regenerated.

## Rated-power settings

The uploaded code and rejected manuscript are not identical for every benchmark. The revised code intentionally preserves the uploaded-code values until the new TICPS experiment design is frozen.

| System | Rejected manuscript | Uploaded/revised code | Action for TICPS |
|---|---|---|---|
| 10-bus DG | 1 x 140 kW | 1 x 140 kW | consistent |
| 10-bus BESS | 1 x 100 kW | 1 x 100 kW | consistent |
| 10-bus PV | 1 x 180 kW | 1 x 200 kW | choose one final value and report it explicitly |
| 18-bus DG | 2 x 140 kW | 2 x 140 kW | consistent |
| 18-bus BESS | 3 x 100 kW | 3 x 100 kW | consistent |
| 18-bus PV | 200 + 150 kW | 200 + 150 kW | consistent |
| 33-bus DG | 3 x 150 kW | 3 x 150 kW | consistent |
| 33-bus BESS | 3 x 100 kW | 200 + 150 + 150 + 150 kW | material mismatch; do not reuse the old table |
| 33-bus PV | 2 x 250 + 2 x 200 kW | 250 + 200 + 200 + 250 kW | consistent total/units |

For the new AI-reserve paper, the recommended primary test is the 18-bus meshed case because its principal DER ratings are already aligned with the old paper and it provides a nontrivial network without the 33-bus BESS mismatch.

## Storage energy capacity

- Rejected manuscript states an 8 h BESS energy duration.
- Legacy code contained a 10 h setting in some versions and also reused one scalar BESS energy capacity for heterogeneous devices.
- Revised code uses 8 h and computes one energy capacity per BESS from each device's own power rating.
- EV aggregate charger power already includes the number of EVs per residential bus; the legacy code multiplied by the EV count again when constructing energy capacity. The revised code removes that double count.

## Physical EV SoC limit

The uploaded physical DAE solver used `1.05*SOCmax` in EV charge cutoff/disconnection logic, whereas the optimization model uses `SOCmax`. The revised solver removes this undocumented 5% margin and applies the same configured upper SoC bound as the EMS.

## Objective-function consistency

The rejected manuscript states prices in $/kWh while optimization powers are represented numerically as MW on the 1-MVA base. The revised objective assembly explicitly includes the MW-to-kW factor 1000 and time-step factor. Terminal SoC deficit costs are multiplied by each device's MWh energy capacity.

The audit also identified an economic double-counting issue in the old manuscript/code: because DG generation in the branch-flow balance already supplies network losses, and terminal SoC dynamics already force replacement of battery-conversion losses, adding separate `C_DG P_loss` and `C_DG(1-eta)P_batt` charges counts those energy losses twice. The revised objective charges actual DG generation once plus battery degradation and service-curtailment penalties; physical losses remain fully represented through the balance/dynamics. The hidden negative PV reward is disabled by default (`pvCurtailment_per_kWh = 0`).

The reported running-cost calculation also now uses the currently executed load-shedding command rather than always indexing the first MPC action.

## EV terminal-energy slack

The legacy code contained an additional numerical EV terminal-SoC slack (`SOCrelaxGap=0.1`) that was not described in the manuscript. The variable is retained structurally to avoid changing optimization dimensions, but its upper bound is now zero by default. The explicit EV terminal-deficit variable is therefore the only intended terminal-energy relaxation in the revised method.

## IRI / execution refinement

All interval-representativeness and post-optimization frequency-triggered BESS correction logic has been removed. The revised method does not claim IRI. EMS commands are executed by zero-order hold between EMS decisions. Smooth interpolation is used only to construct exogenous physical load/PV profiles for simulation.

## Parameters that still require physical confirmation

`Ra` and `Xd_prime` in the DG electrical model were not unambiguously documented as machine-base or system-base per-unit quantities in the uploaded project. The revised default preserves the legacy numerical values as system-base (`cfg.frequency.dgImpedanceBase='system'`), with `Ra`/`Xd_prime` centralized in configuration rather than hidden in the engine. Do not switch to machine-base conversion unless the parameter source is confirmed.
