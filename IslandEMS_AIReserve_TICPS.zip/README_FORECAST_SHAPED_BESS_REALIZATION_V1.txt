FORECAST-SHAPED BESS REALIZATION TEST V1
========================================

Keep the 15-min MPC optimization unchanged.

Use the first two stages of the CURRENT forecast horizon:

  dPnet = Pnet_hat(2)-Pnet_hat(1)

Within the current interval:

  xi=(t-t_k)/DeltaT
  dPBESS,total=(xi-0.5)*dPnet

The four stationary BESS units share the correction by fixed rating weights.
The requested support has zero interval mean when no saturation occurs.

This uses forecast Sload/P_PV only. It never uses true future load/PV,
frequency outcomes, violation status, reserve alpha, KRR predictions, or
method identity. No retraining and zero extra MPC solves.

Files
-----
tests/
  test_F1_33bus_forecast_shaped_bess_realization_v1.m
tools/
  common_forecast_shaped_bess_value_v1.m
  restore_forecast_shaped_bess_engine_v1.m

Preflight
---------
clear functions
rehash
addpath(genpath(pwd))
Rpre = test_F1_33bus_forecast_shaped_bess_realization_v1(pwd,false);

If PASS
-------
Rfs = test_F1_33bus_forecast_shaped_bess_realization_v1(pwd,true);

Expected runtime: about 50-55 minutes.
