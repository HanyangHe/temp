REPLAY 33-BUS ISSUE FIX V1
==========================

This package addresses the two replay incompatibilities introduced by the
official final 33-bus output layout:

1) replay/replay_33bus_manuscript_results.m
   - function interface matches the working 18-bus replay implementation;
   - reads official final 33-bus files from:
       outputs/<runTag>/<PaperLabel>/decay_XXX_seed_XXX/result.mat
   - maps internal T7 -> paper folder F1.

2) tools/patch_replay_saved_operating_profiles_final33_v1.m
   - patches the EXISTING project-root replay_saved_operating_profiles.m;
   - leaves legacy 10-bus / 18-bus lookup unchanged;
   - adds only a 33-bus fallback for the official final storage layout;
   - maps T7 -> F1 for detailed operating-profile replay;
   - creates a backup before modifying the existing helper.

INSTALL
-------
A) Replace:
   replay/replay_33bus_manuscript_results.m

B) Copy the patch utility to:
   tools/patch_replay_saved_operating_profiles_final33_v1.m

Then run from project root:

clear functions
rehash
addpath(genpath(pwd))

Rfix = patch_replay_saved_operating_profiles_final33_v1(pwd,false);
Rfix = patch_replay_saved_operating_profiles_final33_v1(pwd,true);

Then:

clear functions
rehash
addpath(genpath(pwd))
replay_manuscript_results_with_raw_false_safe

NO simulation is launched by either replay fix.
