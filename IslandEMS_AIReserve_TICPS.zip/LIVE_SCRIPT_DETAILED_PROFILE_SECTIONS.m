%% ============================================================
% DETAILED OPERATING-PROFILE DISPLAY
% =============================================================
% This section supplements the summary tables with the physical profiles
% needed for manuscript figures and general diagnosis.
%
% For each selected saved method/decay, it displays and exports:
%   - aggregate power profiles
%   - individual DG and storage/EV power profiles
%   - all saved SoC trajectories
%   - CoI and individual frequency profiles
%   - CoI RoCoF
%   - voltage envelope and current loading
%   - baseline/executed load and load reduction
%   - reserve ratio / reserve power, when saved
%   - instantaneous/cumulative cost
%
% NO simulation is launched.

%% Select detailed profile cases
% Recommended manuscript inspection:
%   severe shortage + normal condition
profileDecays = [0.20 1.00];

% Internal method IDs. T7 is shown as F1.
profileMethods = ["A0","T7","G1","P1U","P1","C0","C1"];

% If you want every saved operating condition:
% profileDecays = [0.20 0.40 0.60 0.80 1.00];

%% Display/export detailed profiles
for caseName = replayCases

    report = get_report_local(reports,caseName);

    for decay = profileDecays

        for methodID = profileMethods

            paperLabel = methodID;
            if methodID=="T7"
                paperLabel = "F1";
            end

            fprintf('\nDetailed profile: %s | %s | decay %.2f\n', ...
                upper(caseName),paperLabel,decay);

            replay_saved_operating_profiles( ...
                report.runRoot, ...
                caseName, ...
                methodID, ...
                decay, ...
                'PaperLabel',paperLabel, ...
                'Visible',true, ...
                'Export',true);
        end
    end
end

%% Recommended manuscript figure selection
% Part I severe case:
%   A0, F1, G1, P1U, P1
%
% Part I normal case:
%   F1, P1
%
% Part II severe case:
%   C0, C1, P1
%
% Most important physical plots:
%   1) aggregate power balance
%   2) SoC trajectories
%   3) CoI frequency + RoCoF
%   4) reserve-ratio alpha
%   5) curtailment/load-reduction profile
%
% Voltage/current plots are useful as network-security validation and can be
% included in the paper or supplementary material depending on space.
