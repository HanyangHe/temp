function [feature,meta] = build_reserve_features(Sload,P_PV,DGPrate,dgUpHeadroom_pu)
%BUILD_RESERVE_FEATURES Three-feature physics input for AI reserve control.
%
% feature = [Pnet_now, |Delta Pnet|, SG upward headroom], all normalized by
% the aggregate SG active-power rating.  Sload and P_PV are the forecast
% trajectories available BEFORE the MPC solve. dgUpHeadroom_pu is computed
% from the measured SG output immediately before the current decision.
%
% The optional second output META exposes forecast-only directional
% quantities for a POST-KRR safety shield.  These quantities are NOT added to
% the frozen KRR input vector and therefore do not change the trained model
% contract.
%
%   meta.netLoadNow_pu
%   meta.signedNetRampForecast_pu = (Pnet_next-Pnet_now)/PdgRated
%   meta.netDropForecast_pu       = max(Pnet_now-Pnet_next,0)/PdgRated
%   meta.absNetRampForecast_pu
%
% All META quantities are available before the current MPC solve.
%
% The first decision of a fresh simulation has no prior measured SG output;
% pass NaN for dgUpHeadroom_pu.  AI mode then falls back to alpha=1 for that
% first step, and offline training excludes that nonfinite feature row.

Pload = max(-sum(real(Sload),1,'omitnan'),0); % positive consumption [MW]
Ppv   = max( sum(real(P_PV),1,'omitnan'),0);  % positive PV output [MW]
PdgTot = max(sum(DGPrate(:)),eps);
net = Pload-Ppv;

if isempty(net)
    error('build_reserve_features:EmptyForecast','Empty load/PV forecast trajectory.');
end

netNow_pu = net(1)/PdgTot;

if numel(net)>=2
    signedNetRampForecast_pu = (net(2)-net(1))/PdgTot;
    absNetRamp_pu = abs(signedNetRampForecast_pu);
else
    signedNetRampForecast_pu = 0;
    absNetRamp_pu = 0;
end

netDropForecast_pu = max(-signedNetRampForecast_pu,0);

if isempty(dgUpHeadroom_pu)
    dgUpHeadroom_pu = NaN;
end
if ~isscalar(dgUpHeadroom_pu)
    error('build_reserve_features:HeadroomShape','dgUpHeadroom_pu must be scalar.');
end

feature = [netNow_pu, absNetRamp_pu, dgUpHeadroom_pu];

% Forecast-derived quantities should always be finite.  Do NOT silently
% replace missing headroom with zero because that would imply no reserve.
if any(~isfinite(feature(1:2)))
    error('build_reserve_features:NonfiniteForecastFeature', ...
        'Net-load operating/ramp features must be finite.');
end

if nargout>=2
    meta = struct();
    meta.netLoadNow_pu = netNow_pu;
    meta.signedNetRampForecast_pu = signedNetRampForecast_pu;
    meta.netDropForecast_pu = netDropForecast_pu;
    meta.absNetRampForecast_pu = absNetRamp_pu;
end
end
