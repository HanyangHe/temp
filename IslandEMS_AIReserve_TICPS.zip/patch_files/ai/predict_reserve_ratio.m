function [alpha,info] = predict_reserve_ratio(model,feature,aiCfg)
%PREDICT_RESERVE_RATIO Online policy from learned stress + optional shield.
%
% Stage 1: KRR frequency-stress response search proposes alpha.
% Stage 2: optional forecast-aware POST-KRR safety shield may only INCREASE
%          alpha. It never lowers the KRR proposal.
%
% Experimental two-branch shield:
%
%   Branch A (moderate drop at sufficiently high net load):
%       forecastNetDrop_pu >= dropThreshold
%       AND forecastNetLoadNow_pu >= netLoadMin
%
%   Branch B (severe forecast drop regardless of current net load):
%       forecastNetDrop_pu >= severeDropThreshold
%
% If either branch is true and alpha_KRR < shieldAlpha, alpha is raised to
% shieldAlpha.
%
% The signed forecast quantity is NOT added to the frozen 3-feature KRR input
% vector; it is only used by the post-KRR correction.

feature=feature(:).';
expectedNames=reserve_feature_names();

if numel(feature)~=numel(expectedNames)
    error('predict_reserve_ratio:FeatureDimension', ...
        'AI reserve expects %d frozen state features but received %d.', ...
        numel(expectedNames),numel(feature));
end

if ~isfield(model,'stateFeatureNames') || ...
        ~isequal(string(model.stateFeatureNames(:)),string(expectedNames(:)))
    error('predict_reserve_ratio:StaleModel', ...
        ['Loaded AI reserve model does not use the frozen three-state ', ...
         'frequency-stress response contract. Retrain with train_AIReserve.m.']);
end

if ~isfield(model,'learningTarget') || ...
        ~strcmpi(model.learningTarget,'frequency-stress-response')
    error('predict_reserve_ratio:StaleTarget', ...
        'Loaded AI model is from the deprecated direct-alpha learning scheme. Retrain it.');
end

%% Stage 1: KRR proposal
[avec,d]=select_reserve_alpha_batch( ...
    model,feature,aiCfg,aiCfg.useSafetyCalibration);

alphaKRR=avec(1);
alpha=alphaKRR;

%% Stage 2: forecast-aware post-KRR shield
shieldEnabled = getfield_default_local( ...
    aiCfg,'enableForecastSafetyShield',false);

netDropForecast_pu = getfield_default_local( ...
    aiCfg,'forecastNetDrop_pu',NaN);

netLoadNowForecast_pu = getfield_default_local( ...
    aiCfg,'forecastNetLoadNow_pu',feature(1));

signedNetRampForecast_pu = getfield_default_local( ...
    aiCfg,'forecastSignedNetRamp_pu',NaN);

dropThreshold_pu = getfield_default_local( ...
    aiCfg,'forecastSafetyShieldDropThreshold_pu',0.02);

netLoadMin_pu = getfield_default_local( ...
    aiCfg,'forecastSafetyShieldNetLoadMin_pu',0.60);

% New severe-drop branch.
severeDropEnabled = getfield_default_local( ...
    aiCfg,'forecastSafetyShieldSevereDropEnabled',false);

severeDropThreshold_pu = getfield_default_local( ...
    aiCfg,'forecastSafetyShieldSevereDropThreshold_pu',0.10);

shieldAlpha = getfield_default_local( ...
    aiCfg,'forecastSafetyShieldAlpha',aiCfg.fallbackAlpha);

shieldAlpha=min(max(shieldAlpha,aiCfg.alphaMin),aiCfg.alphaMax);

branchModerate = false;
branchSevere = false;
shieldTriggered = false;

if shieldEnabled && ...
        isfinite(netDropForecast_pu) && ...
        isfinite(netLoadNowForecast_pu) && ...
        alphaKRR < shieldAlpha-1e-12

    branchModerate = ...
        netDropForecast_pu >= dropThreshold_pu-1e-12 && ...
        netLoadNowForecast_pu >= netLoadMin_pu-1e-12;

    branchSevere = ...
        severeDropEnabled && ...
        netDropForecast_pu >= severeDropThreshold_pu-1e-12;

    if branchModerate || branchSevere
        alpha=shieldAlpha;
        shieldTriggered=true;
    end
end

alpha=min(max(alpha,aiCfg.alphaMin),aiCfg.alphaMax);

%% Diagnostics
info=struct( ...
    'raw',NaN, ...
    'calibrated',alpha, ...
    'clipped',false, ...
    'oodFallback',d.oodFallback(1), ...
    'missingFeatureFallback',d.missingFeatureFallback(1), ...
    'noSafeCandidateFallback',d.noSafeCandidateFallback(1), ...
    'alphaGrid',d.alphaGrid, ...
    'rawStressCurve',d.rawStress(1,:), ...
    'decisionStressCurve',d.decisionStress(1,:), ...
    'usedCalibration',d.usedCalibration, ...
    'source','frequency-stress-response-search');

info.preShieldAlpha = alphaKRR;
info.postShieldAlpha = alpha;
info.forecastSafetyShieldEnabled = logical(shieldEnabled);
info.forecastSafetyShieldTriggered = logical(shieldTriggered);
info.forecastSafetyShieldModerateBranch = logical(branchModerate);
info.forecastSafetyShieldSevereBranch = logical(branchSevere);

info.forecastNetDrop_pu = netDropForecast_pu;
info.forecastNetLoadNow_pu = netLoadNowForecast_pu;
info.forecastSignedNetRamp_pu = signedNetRampForecast_pu;

info.forecastSafetyShieldDropThreshold_pu = dropThreshold_pu;
info.forecastSafetyShieldNetLoadMin_pu = netLoadMin_pu;
info.forecastSafetyShieldSevereDropEnabled = logical(severeDropEnabled);
info.forecastSafetyShieldSevereDropThreshold_pu = severeDropThreshold_pu;
info.forecastSafetyShieldAlpha = shieldAlpha;
end


function v = getfield_default_local(s,name,defaultValue)
v=defaultValue;
if isstruct(s) && isfield(s,name)
    v=s.(name);
end
end
