FINAL 33-BUS INPUT-AVERAGE PATCH V2
=====================================

This v2 fixes the path error in the previous patch:
config_island_ems.m is resolved with MATLAB WHICH after adding the project
tree to the path. It is no longer incorrectly assumed to live directly in
projectRoot.

Recommended sequence
--------------------
1) Dry run:
   R = apply_final_33bus_inputavg_patch_v2(pwd,false);

2) Apply only after the dry-run report looks correct:
   R = apply_final_33bus_inputavg_patch_v2(pwd,true);

3) Organize unofficial outputs:
   Rmove = organize_outputs_testResults_v2(pwd,false);
   Rmove = organize_outputs_testResults_v2(pwd,true);

4) Preflight:
   clear functions
   rehash
   addpath(genpath(pwd))
   Rpre = preflight_33bus_retrain_after_final_patch_v2(pwd);

5) If PRE-FLIGHT STATUS: PASS:
   clear functions
   rehash
   addpath(genpath(pwd))
   train_AIReserve

No simulation/training is launched by steps 1-4.

Final production contract
-------------------------
- 33bus DG = [0.17;0.17;0.17] MW
- 33bus PV = [1/6;2/15;2/15;1/6] MW
- Average ONLY predictive Sload/P_PV after 15-min MPC resampling
- True 1-s Pload_true_box/PV1_curve unchanged
- Original ZOH execution retained
- No midpoint / FOH / whole-average execution
- Current training target = 33bus only
- Old canonical 33bus dataset/model archived
- 10bus/18bus canonical assets untouched
