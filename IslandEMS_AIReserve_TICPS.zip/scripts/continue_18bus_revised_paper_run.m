%% CONTINUE 18bus formal results under the REVISED two-part paper design
clearvars; clc;
projectRoot = pwd;
addpath(genpath(projectRoot));

cfg = config_island_ems();
validate_config(cfg);

cfg.output.saveResults = true;
cfg.output.runTag = '20260907_115951';
runRoot = fullfile(projectRoot,cfg.output.root,cfg.output.runTag);
assert(exist(runRoot,'dir')==7,'Run folder not found: %s',runRoot);

caseName = '18bus';
seed = 0;
decayList = cfg.scenario.decayRatios;
paperMethods = ["A0","T7","G1","P1U","P1","C0","C1"];

catalog = paper_method_catalog();
catalogIDs = string({catalog.id});
dayTag = lower(strrep(cfg.scenario.dayType,' ','_'));

fprintf('\nREVISED 18BUS PAPER-RUN CONTINUATION\n');
fprintf('Part I: A0, F1(T7), G1, P1U, P1\n');
fprintf('Part II: C0, C1, P1\n');

for decay = decayList(:).'
    for id = paperMethods
        methodDir = fullfile(runRoot,char(id));
        decayCode = round(100*decay);
        pattern = sprintf('%s_%s_decay%03d_seed%03d_*.mat', ...
            caseName,dayTag,decayCode,seed);
        existing = dir(fullfile(methodDir,pattern));

        if ~isempty(existing)
            fprintf('[SKIP EXISTING] %s | decay %.2f\n',id,decay);
            continue;
        end

        idx = find(catalogIDs==id,1);
        assert(~isempty(idx),'Unknown paper method: %s',id);

        runCfg = catalog(idx);
        runCfg.caseName = caseName;
        runCfg.dayType = cfg.scenario.dayType;
        runCfg.decayRatio = decay;
        runCfg.randomSeed = seed;

        fprintf('\n=== RUN %s | %s | decay %.2f | seed %d ===\n', ...
            id,caseName,decay,seed);

        run_single_experiment(cfg,runCfg,projectRoot,runRoot,true);

        if ~cfg.output.showFigures, close all force; end
    end
end
