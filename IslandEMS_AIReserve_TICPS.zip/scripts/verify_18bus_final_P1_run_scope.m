function report = verify_18bus_final_P1_run_scope(targetRunTag,sourceRunTag)
%VERIFY_18BUS_FINAL_P1_RUN_SCOPE Verify final 18-bus paper method/decay scope.
%
% Expected final unique pairs:
%   Part I @ decay=1:
%     A0,T7,G1,P1U,P1
%
%   Part II:
%     C0,C1,P1 @ [0.20 0.40 0.60 0.80 1.00]
%
% Unique total = 19.
%
% A0/T7/G1/P1U must NOT appear at decay<1 in the final run folder.

if nargin<1 || isempty(targetRunTag)
    targetRunTag='20260908_finalP1S3_18bus';
end
if nargin<2
    sourceRunTag='';
end

projectRoot=pwd;
addpath(genpath(projectRoot));
cfg=config_island_ems();

root=fullfile(projectRoot,cfg.output.root,targetRunTag);
assert(exist(root,'dir')==7,'Run root not found: %s',root);

caseName='18bus';
seed=0;
dayTag=lower(strrep(cfg.scenario.dayType,' ','_'));

part1=["A0","T7","G1","P1U","P1"];
part2=["C0","C1","P1"];
decays=[0.20 0.40 0.60 0.80 1.00];

rows=strings(0,1);
missing=strings(0,1);

for id=part1
    ok=exists_one_local(root,char(id),caseName,dayTag,1.00,seed);
    rows(end+1,1)=sprintf('%s@1.00',id); %#ok<AGROW>
    if ~ok, missing(end+1,1)=rows(end); end %#ok<AGROW>
end

for decay=decays
    for id=part2
        if id=="P1" && abs(decay-1)<1e-12
            continue; % already counted as shared Part-I/II row
        end

        ok=exists_one_local(root,char(id),caseName,dayTag,decay,seed);
        rows(end+1,1)=sprintf('%s@%.2f',id,decay); %#ok<AGROW>
        if ~ok, missing(end+1,1)=rows(end); end %#ok<AGROW>
    end
end

assert(numel(rows)==19,'Internal expected-pair count is not 19.');

% Forbidden Part-I shortage rows.
forbidden=strings(0,1);

for id=["A0","T7","G1","P1U"]
    methodDir=fullfile(root,char(id));
    if exist(methodDir,'dir')~=7, continue; end

    hits=dir(fullfile(methodDir,sprintf('%s_%s_decay*_seed%03d_*.mat', ...
        caseName,dayTag,seed)));

    for k=1:numel(hits)
        token=regexp(hits(k).name,'decay(\d{3})','tokens','once');
        if isempty(token), continue; end
        d=str2double(token{1})/100;

        if abs(d-1)>1e-12
            forbidden(end+1,1)=string(fullfile(hits(k).folder,hits(k).name)); %#ok<AGROW>
        end
    end
end

report=struct();
report.targetRunTag=targetRunTag;
report.sourceRunTag=sourceRunTag;
report.expectedUniquePairCount=19;
report.missingPairs=missing;
report.forbiddenPartIShortageFiles=forbidden;
report.complete=isempty(missing) && isempty(forbidden);

fprintf('\nFinal-run scope verification:\n');
fprintf('  expected unique pairs : 19\n');
fprintf('  missing pairs         : %d\n',numel(missing));
fprintf('  forbidden Part-I rows : %d\n',numel(forbidden));

if ~isempty(missing)
    fprintf('  Missing: %s\n',strjoin(missing,', '));
end

if ~isempty(forbidden)
    fprintf('  Forbidden files:\n');
    fprintf('    %s\n',forbidden);
end

if report.complete
    fprintf('  STATUS                : COMPLETE\n');
else
    fprintf('  STATUS                : INCOMPLETE\n');
end
end


function tf=exists_one_local(root,id,caseName,dayTag,decay,seed)

methodDir=fullfile(root,id);
if exist(methodDir,'dir')~=7
    tf=false;
    return;
end

pattern=sprintf('%s_%s_decay%03d_seed%03d_*.mat', ...
    caseName,dayTag,round(100*decay),seed);

hits=dir(fullfile(methodDir,pattern));
tf=numel(hits)==1;

if numel(hits)>1
    error('Duplicate final results for %s decay %.2f.',id,decay);
end
end
