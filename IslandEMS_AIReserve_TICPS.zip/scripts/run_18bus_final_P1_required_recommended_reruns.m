%% run_18bus_final_P1_required_recommended_reruns.m
% Final 18-bus incremental formal rerun after replacing old P1 with final S3/P1.
%
% ONLY required/recommended rows are simulated:
%
%   Recommended:
%     P1U @ decay 1.00
%
%   Required Part II:
%     C0,C1,P1 @ decay 0.20,0.40,0.60,0.80,1.00
%
% P1@1.00 is shared by Part I and Part II and is simulated only once.
%
% Total new simulations = 16.
%
% Unaffected Part-I baselines are REUSED, not rerun:
%     A0,T7(F1),G1 @ decay 1.00
%
% No A0/T7/G1/P1U shortage-decay rows are created.
%
% The script creates a NEW complete final run folder containing:
%   3 reused unaffected baselines + 16 new runs
%   = 19 unique paper method/decay pairs.
%
% The script is resumable: already-existing target rows are skipped.

clearvars;
clc;

%% User-editable run tags
SOURCE_RUN_TAG = '20260907_115951';
TARGET_RUN_TAG = '20260908_finalP1S3_18bus';

%% Setup
projectRoot=pwd;
addpath(genpath(projectRoot));
rehash;

cfg=config_island_ems();
validate_config(cfg);

plan=paper_study_catalog();
catalog=paper_method_catalog();
catalogIDs=string({catalog.id});

assert(strcmp(plan.version,'ticps-two-stage-v4-final-P1-forecast-guard'), ...
    'Final P1 paper_study_catalog is not active.');

cfg.output.saveResults=true;
cfg.output.showFigures=false;
cfg.output.runTag=TARGET_RUN_TAG;

caseName='18bus';
seed=0;
dayTag=lower(strrep(cfg.scenario.dayType,' ','_'));

sourceRoot=fullfile(projectRoot,cfg.output.root,SOURCE_RUN_TAG);
targetRoot=fullfile(projectRoot,cfg.output.root,TARGET_RUN_TAG);

assert(exist(sourceRoot,'dir')==7, ...
    'Source run root not found: %s',sourceRoot);

if ~exist(targetRoot,'dir')
    mkdir(targetRoot);
end

fprintf('\n=============================================================\n');
fprintf(' FINAL 18BUS P1 REQUIRED/RECOMMENDED RERUN\n');
fprintf('=============================================================\n');
fprintf('source run : %s\n',sourceRoot);
fprintf('target run : %s\n',targetRoot);
fprintf('new runs   : 16\n');
fprintf('reuse      : A0,T7,G1 @ decay 1.00 only\n');
fprintf('P1U        : decay 1.00 only\n');
fprintf('Part II    : C0,C1,P1 @ five decay ratios\n');
fprintf('=============================================================\n');

%% ------------------------------------------------------------------------
% 1. Reuse unaffected Part-I baselines at decay=1 ONLY
% -------------------------------------------------------------------------
reuseMethods=["A0","T7","G1"];

fprintf('\nReusing unaffected Part-I baselines:\n');

for id=reuseMethods
    copy_one_result_local( ...
        sourceRoot,targetRoot,char(id),caseName,dayTag,1.00,seed);
end

%% ------------------------------------------------------------------------
% 2. Build exact 16-row rerun schedule
% -------------------------------------------------------------------------
methodCol=strings(0,1);
decayCol=zeros(0,1);
studyCol=strings(0,1);

% Recommended Part-I rerun.
methodCol(end+1,1)="P1U";
decayCol(end+1,1)=1.00;
studyCol(end+1,1)="Part I recommended";

% Required Part-II reruns. P1@1 is also the new Part-I P1 row.
decays=plan.curtailmentAllocationCost.decayRatios;

for decay=decays(:).'
    for id=["C0","C1","P1"]
        methodCol(end+1,1)=id; %#ok<SAGROW>
        decayCol(end+1,1)=decay; %#ok<SAGROW>
        if id=="P1" && abs(decay-1)<1e-12
            studyCol(end+1,1)="Part II required + shared Part I P1"; %#ok<SAGROW>
        else
            studyCol(end+1,1)="Part II required"; %#ok<SAGROW>
        end
    end
end

schedule=table(methodCol,decayCol,studyCol, ...
    'VariableNames',{'MethodID','DecayRatio','Reason'});

assert(height(schedule)==16,'Expected exactly 16 rerun rows.');
assert(nnz(schedule.MethodID=="P1U")==1 && ...
       schedule.DecayRatio(schedule.MethodID=="P1U")==1, ...
    'P1U must be rerun only at decay=1.');

fprintf('\nExact rerun schedule:\n');
disp(schedule);

%% Save final manifest before starting long simulations
manifest=struct();
manifest.cfg=cfg;
manifest.catalog=catalog;
manifest.paperStudies=plan;
manifest.sourceRunTag=SOURCE_RUN_TAG;
manifest.targetRunTag=TARGET_RUN_TAG;
manifest.reusedMethods=cellstr(reuseMethods);
manifest.rerunSchedule=schedule;
manifest.created=datestr(now,30);
manifest.projectRoot=projectRoot;
manifest.note=[ ...
    'Final P1 = uncalibrated KRR adaptive reserve + frozen two-branch ', ...
    'forecast guard. Only required/recommended 18-bus rows were rerun.'];

save(fullfile(targetRoot,'run_manifest.mat'),'manifest','-v7.3');

%% ------------------------------------------------------------------------
% 3. Execute/resume the 16 new rows
% -------------------------------------------------------------------------
status=schedule;
status.Action=repmat("PENDING",height(status),1);
status.TotalCost=nan(height(status),1);
status.MeanAlpha=nan(height(status),1);
status.MaxAbsFreqDev_Hz=nan(height(status),1);
status.MaxAbsRoCoF_Hz_s=nan(height(status),1);
status.SecurityViolationRate=nan(height(status),1);

for ir=1:height(schedule)

    id=schedule.MethodID(ir);
    decay=schedule.DecayRatio(ir);

    existing=find_result_local( ...
        targetRoot,char(id),caseName,dayTag,decay,seed);

    if ~isempty(existing)
        fprintf('[SKIP EXISTING] %s | decay %.2f\n',id,decay);
        status.Action(ir)="SKIP_EXISTING";

        try
            rr=load_result_local(existing);
            status=fill_status_local(status,ir,rr);
        catch ME
            warning('Could not summarize existing result %s: %s',existing,ME.message);
        end

        writetable(status,fullfile(targetRoot,'final_rerun_status.csv'));
        continue;
    end

    idx=find(catalogIDs==id,1);
    assert(~isempty(idx),'Unknown paper method: %s',id);

    runCfg=catalog(idx);
    runCfg.caseName=caseName;
    runCfg.dayType=cfg.scenario.dayType;
    runCfg.decayRatio=decay;
    runCfg.randomSeed=seed;

    % Final method contract assertions immediately before execution.
    if any(id==["P1","C0","C1"])
        assert(strcmpi(runCfg.reserveMode,'ai'));
        assert(~runCfg.aiSafetyCalibration);
        assert(runCfg.aiForecastSafetyShield);
        assert(abs(runCfg.aiForecastSafetyShieldDropThreshold_pu-0.02)<1e-12);
        assert(abs(runCfg.aiForecastSafetyShieldNetLoadMin_pu-0.60)<1e-12);
        assert(runCfg.aiForecastSafetyShieldSevereDropEnabled);
        assert(abs(runCfg.aiForecastSafetyShieldSevereDropThreshold_pu-0.11)<1e-12);
        assert(abs(runCfg.aiForecastSafetyShieldAlpha-1.00)<1e-12);
    elseif id=="P1U"
        assert(strcmpi(runCfg.reserveMode,'ai'));
        assert(~runCfg.aiSafetyCalibration);
        assert(~runCfg.aiForecastSafetyShield);
        assert(abs(decay-1)<1e-12);
    end

    fprintf('\n=============================================================\n');
    fprintf(' RUN %02d/%02d : %s | decay %.2f | seed %d\n', ...
        ir,height(schedule),id,decay,seed);
    fprintf('=============================================================\n');

    result=run_single_experiment( ...
        cfg,runCfg,projectRoot,targetRoot,true);

    status.Action(ir)="RERUN_COMPLETE";
    status=fill_status_local(status,ir,result);
    writetable(status,fullfile(targetRoot,'final_rerun_status.csv'));

    if ~cfg.output.showFigures
        close all force;
    end
end

%% ------------------------------------------------------------------------
% 4. Verify complete final paper scope
% -------------------------------------------------------------------------
report=verify_18bus_final_P1_run_scope( ...
    TARGET_RUN_TAG,SOURCE_RUN_TAG);

fprintf('\n=============================================================\n');
fprintf(' FINAL 18BUS INCREMENTAL RERUN FINISHED\n');
fprintf('=============================================================\n');
disp(status);
disp(report);
fprintf('Final results: %s\n',targetRoot);
fprintf('=============================================================\n');


%% =========================================================================
% Local helpers
% =========================================================================

function copy_one_result_local(sourceRoot,targetRoot,id,caseName,dayTag,decay,seed)

src=find_result_local(sourceRoot,id,caseName,dayTag,decay,seed);
assert(~isempty(src), ...
    'Required reusable source result missing: %s decay %.2f',id,decay);

dstDir=fullfile(targetRoot,id);
if ~exist(dstDir,'dir'), mkdir(dstDir); end

[~,name,ext]=fileparts(src);
dst=fullfile(dstDir,[name ext]);

if exist(dst,'file')==2
    fprintf('[REUSE EXISTS] %s | decay %.2f\n',id,decay);
else
    copyfile(src,dst,'f');
    fprintf('[REUSED]      %s | decay %.2f\n',id,decay);
end
end


function filePath=find_result_local(root,id,caseName,dayTag,decay,seed)

methodDir=fullfile(root,id);
if exist(methodDir,'dir')~=7
    filePath='';
    return;
end

pattern=sprintf('%s_%s_decay%03d_seed%03d_*.mat', ...
    caseName,dayTag,round(100*decay),seed);

hits=dir(fullfile(methodDir,pattern));

if isempty(hits)
    filePath='';
    return;
end

assert(numel(hits)==1, ...
    'Expected one %s result for decay %.2f; found %d in %s.', ...
    id,decay,numel(hits),methodDir);

filePath=fullfile(hits(1).folder,hits(1).name);
end


function result=load_result_local(filePath)

S=load(filePath);

if isfield(S,'result') && isstruct(S.result)
    result=S.result;
    return;
end

names=fieldnames(S);
for k=1:numel(names)
    x=S.(names{k});
    if isstruct(x) && isfield(x,'summary')
        result=x;
        return;
    end
end

error('Could not identify result struct in %s.',filePath);
end


function status=fill_status_local(status,ir,result)

status.TotalCost(ir)=double(result.totalCost);

if isfield(result,'summary')
    s=result.summary;

    if isfield(s,'meanReserveRatio')
        status.MeanAlpha(ir)=double(s.meanReserveRatio);
    elseif isfield(result,'reserve') && isfield(result.reserve,'ratio')
        status.MeanAlpha(ir)=mean(double(result.reserve.ratio(:)),'omitnan');
    end

    if isfield(s,'maxAbsFreqDev_Hz')
        status.MaxAbsFreqDev_Hz(ir)=double(s.maxAbsFreqDev_Hz);
    end
    if isfield(s,'maxAbsRoCoF_Hz_s')
        status.MaxAbsRoCoF_Hz_s(ir)=double(s.maxAbsRoCoF_Hz_s);
    end
    if isfield(s,'securityViolationRate')
        status.SecurityViolationRate(ir)=double(s.securityViolationRate);
    end
end
end
