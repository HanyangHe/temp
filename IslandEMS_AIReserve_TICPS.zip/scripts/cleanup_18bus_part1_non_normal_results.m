%% cleanup_18bus_part1_non_normal_results.m
% Remove obsolete Part-I shortage results from the completed 18-bus run.
%
% CRITICAL:
% Part I is NORMAL CASE ONLY (decay=1.00).
%
% Delete non-normal results for Part-I-only methods:
%   A0, T7(F1), G1, P1U at decay 0.20/0.40/0.60/0.80.
%
% DO NOT DELETE P1 at decay<1:
% P1 is required by Part II (C0/C1/P1 shortage study).
%
% Also removes the existing manuscript_replay folder because its old tables
% and figures include invalid Part-I decay sweeps. Replay it after cleanup.

clearvars;
clc;

projectRoot = pwd;
runTag = '20260907_115951';

cfg = config_island_ems();
runRoot = fullfile(projectRoot,cfg.output.root,runTag);

assert(exist(runRoot,'dir')==7, ...
    'Formal run folder not found: %s',runRoot);

part1OnlyMethods = ["A0","T7","G1","P1U"];
obsoleteDecays = [0.20 0.40 0.60 0.80];

fprintf('\n=============================================================\n');
fprintf(' CLEAN PART-I NON-NORMAL RESULTS\n');
fprintf(' runRoot : %s\n',runRoot);
fprintf(' delete  : A0,T7,G1,P1U at decay < 1\n');
fprintf(' keep    : all P1 results (Part II needs them)\n');
fprintf('=============================================================\n');

deletedFiles = strings(0,1);

for id = part1OnlyMethods
    methodDir = fullfile(runRoot,char(id));

    if exist(methodDir,'dir')~=7
        fprintf('[NOT PRESENT] %s\n',id);
        continue;
    end

    for decay = obsoleteDecays
        decayCode = round(100*decay);

        pattern = sprintf( ...
            '18bus_unusual_day_decay%03d_seed000_*.mat',decayCode);

        hits = dir(fullfile(methodDir,pattern));

        for k = 1:numel(hits)
            filePath = fullfile(hits(k).folder,hits(k).name);
            fprintf('[DELETE] %s\n',filePath);
            delete(filePath);
            deletedFiles(end+1,1)=string(filePath); %#ok<AGROW>
        end
    end
end

% Explicit safety check: P1 shortage results must still exist.
for decay = obsoleteDecays
    decayCode = round(100*decay);
    hits = dir(fullfile(runRoot,'P1',sprintf( ...
        '18bus_unusual_day_decay%03d_seed000_*.mat',decayCode)));

    assert(~isempty(hits), ...
        ['P1 decay %.2f is missing. It is required by Part II and must ', ...
         'NOT be deleted.'],decay);
end

% Remove stale replay outputs generated under the old Part-I scope.
replayDir = fullfile(runRoot,'manuscript_replay');
if exist(replayDir,'dir')==7
    fprintf('[DELETE STALE REPLAY] %s\n',replayDir);
    ok = rmdir(replayDir,'s');
    assert(ok,'Could not remove stale manuscript_replay folder.');
end

% Clean summary.csv if present.
summaryFile = fullfile(runRoot,'summary.csv');
if exist(summaryFile,'file')==2
    stamp = datestr(now,'yyyymmdd_HHMMSS');
    backup = [summaryFile '.before_part1_scope_cleanup_' stamp '.bak'];
    copyfile(summaryFile,backup,'f');

    T = readtable(summaryFile,'TextType','string');
    names = string(T.Properties.VariableNames);
    low = lower(names);

    methodCandidates = ["methodid","method_id","method","id"];
    decayCandidates = ["decayratio","decay_ratio","decay"];

    methodVar = "";
    decayVar = "";

    for x = methodCandidates
        idx=find(low==x,1);
        if ~isempty(idx), methodVar=names(idx); break; end
    end
    for x = decayCandidates
        idx=find(low==x,1);
        if ~isempty(idx), decayVar=names(idx); break; end
    end

    if strlength(methodVar)>0 && strlength(decayVar)>0
        methodVals = string(T.(char(methodVar)));
        decayVals = double(T.(char(decayVar)));

        removeRows = ismember(methodVals,part1OnlyMethods) & ...
            decayVals < 1-1e-12;

        fprintf('[SUMMARY] remove %d obsolete rows\n',nnz(removeRows));

        T(removeRows,:) = [];
        writetable(T,summaryFile);
    else
        warning(['summary.csv column names were not recognized. ', ...
            'The MAT-file cleanup is complete, but summary.csv was left unchanged.']);
    end
end

% Update manifest paper scope if present.
manifestFile = fullfile(runRoot,'run_manifest.mat');
if exist(manifestFile,'file')==2
    S = load(manifestFile);

    if isfield(S,'manifest')
        manifest = S.manifest;
        manifest.paperStudies = paper_study_catalog();
        manifest.part1ScopeCleanup = struct( ...
            'timestamp',datestr(now,30), ...
            'rule','Part I uses decayRatio=1.00 only', ...
            'deletedPart1OnlyMethods',{cellstr(part1OnlyMethods)}, ...
            'deletedDecays',obsoleteDecays, ...
            'note','P1 decay<1 retained because it belongs to Part II.');

        save(manifestFile,'manifest','-v7.3');
    end
end

fprintf('\nCleanup complete.\n');
fprintf('Deleted MAT files: %d\n',numel(deletedFiles));
fprintf('P1 shortage results were preserved.\n');
fprintf('Run replay_manuscript_results again to regenerate valid tables/figures.\n');
