TRANSITION CORRECTOR TEST V1
============================

Purpose
-------
Test a common, method-independent low-level DG command-transition corrector
on the final 33-bus F1, decay=1, seed=0 case.

This is deliberately the MINIMAL first corrector:
- DG Pref handoff only
- cubic smoothstep
- fixed Tc = 3*Tg = 4.5 s
- no BESS compensation in V1
- no KRR/model/training changes
- no forecast/reserve-alpha changes

Why no BESS compensation yet?
-----------------------------
The audited residuals are synchronized with DG Pref discontinuities. The
cleanest test is therefore to remove only that discontinuity first. If this
already clears 0/96, adding a second actuator would be unnecessary. If it
does not, the next experiment can add BESS compensation while keeping the
same fixed 4.5-s transition duration.

Files
-----
tests/
  test_F1_33bus_DG_transition_corrector_v1.m
tools/
  restore_transition_corrector_test_engine_v1.m

Run order
---------
1) Preflight only:
   clear functions
   rehash
   addpath(genpath(pwd))
   Rpre = test_F1_33bus_DG_transition_corrector_v1(pwd,false);

2) Only if PRE-FLIGHT STATUS: PASS:
   Rtc = test_F1_33bus_DG_transition_corrector_v1(pwd,true);

The engine patch is temporary. The script restores the exact original
engine text after the one-case run and verifies restoration.

Emergency restore
-----------------
Only if MATLAB is force-killed/crashes while the temporary patched engine is
installed:

   clear functions
   rehash
   addpath(genpath(pwd))
   Rrestore = restore_transition_corrector_test_engine_v1(pwd);

Test output
-----------
outputs/cache/transition_corrector_test_v1/33bus_F1_decay100_seed000/

Decision flags
--------------
DG_TRANSITION_CORRECTOR_CLEARS_F1_NORMAL
DG_TRANSITION_CORRECTOR_MATERIALLY_HELPS
DG_TRANSITION_CORRECTOR_NOT_SUFFICIENT
