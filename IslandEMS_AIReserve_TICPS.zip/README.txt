FINAL P1 / S3 FORMAL PATCH
===========================

Purpose
-------
Promote the successful S3 architecture to the paper method ID P1 and update
the formal test system.

Final Part-I definitions
------------------------
A0  : no reserve
F1  : internal T7, fixed alpha=1 reserve
G1  : global fixed alpha
P1U : uncalibrated adaptive KRR reserve WITHOUT forecast-aware guard
P1  : proposed uncalibrated adaptive KRR reserve WITH two-branch guard

Part I is NORMAL CASE ONLY:
    decayRatio = 1.00

Final P1 guard
--------------
Moderate branch:
    forecast net-load drop >= 0.02 pu
    AND forecast net load >= 0.60 pu

Severe branch:
    forecast net-load drop >= 0.11 pu

If either branch is true:
    alpha is raised to 1.00

The thresholds are normalized and frozen. They should NOT be retuned for
later seeds or grids.

Global additive KRR calibration
-------------------------------
Removed from final P1/P1U deployment:
    aiSafetyCalibration = false

The existing KRR model does NOT need retraining because its frozen input is
unchanged:
    netLoadNow_pu
    absNetLoadRamp_pu
    dgUpHeadroom_pu

The directional forecast quantities are used only outside KRR by the guard.

Part II
-------
C0/C1/P1 use the SAME final guarded adaptive reserve policy and differ only
in flexibility allocation:

    C0 = no special flexibility
    C1 = BESS-only
    P1 = hierarchical BESS/EV/load

Part II decays:
    [0.20 0.40 0.60 0.80 1.00]


INSTALL
=======
Unzip this package somewhere convenient.

From the IslandEMS project root:

    addpath(genpath('<unzipped patch folder>'))
    apply_final_P1_S3_formal_patch(pwd)

The installer makes timestamped backups before changing production files.

Then run the no-simulation contract test once:

    test_final_P1_S3_formal_contract(pwd)


18-BUS RERUN POLICY
===================
We do NOT rerun everything.

Reuse from outputs/20260907_115951:
    A0 @ 1.00
    T7/F1 @ 1.00
    G1 @ 1.00

Recommended rerun:
    P1U @ 1.00

Required reruns:
    C0,C1,P1 @ 0.20,0.40,0.60,0.80,1.00

P1@1 is shared by Parts I and II and runs only once.

Total new simulations:
    16

Final complete unique method/decay pairs:
    19


RUN
===
The incremental runner defaults to:

    SOURCE_RUN_TAG = '20260907_115951'
    TARGET_RUN_TAG = '20260908_finalP1S3_18bus'

Run:

    run_18bus_final_P1_required_recommended_reruns

The runner:
    - copies ONLY A0/T7/G1 decay=1 results from the old run;
    - never copies obsolete Part-I shortage rows;
    - runs exactly 16 required/recommended cases;
    - skips existing target rows if resumed;
    - writes final_rerun_status.csv;
    - verifies the final 19-pair paper scope.

After completion you can also run:

    verify_18bus_final_P1_run_scope('20260908_finalP1S3_18bus', ...
        '20260907_115951')


FULL FRESH RUNS FOR LATER GRIDS
==============================
core/run_experiments.m has also been updated. A later fresh 10-bus/33-bus
formal run will obey:

Part I:
    A0,T7,G1,P1U,P1 @ decay=1 only

Part II:
    C0,C1,P1 @ all five decays

so each fresh grid has exactly 19 unique method/decay pairs.


EXPECTED TIME FOR CURRENT 18-BUS RERUN
======================================
16 new full-day simulations.

At roughly 20-30 minutes/case:
    about 5.3-8 hours total

Run it as a resumable overnight job.


INTERPRETATION
==============
The final P1 guard improves robustness to rapid forecast net-load
transitions. Because 15-min EMS commands are validated against 1-s physical
dynamics, residual sub-interval cross-layer discrepancies are evaluated
a posteriori; the method should not be described as a mathematical
zero-violation guarantee.
