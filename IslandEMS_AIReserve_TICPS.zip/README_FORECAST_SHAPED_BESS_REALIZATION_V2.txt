FORECAST-SHAPED BESS REALIZATION TEST V2
========================================

Why V1 failed
-------------
V1 inserted a comment marker immediately after "=" inside the patched
BESS assignment. MATLAB then parsed:

  Ref(...)= % marker
      common_forecast_...

which is invalid syntax.

The onCleanup restoration worked correctly; the engine was restored before
the error returned.

V2 fix
------
V2 replaces the two COMPLETE BESS statements, not an expression fragment:

1) direct Ref assignment branch;
2) Pbatt_cmd assignment branch.

The marker is placed on its own line BEFORE the statement.

The physical experiment itself is unchanged.

Run preflight
-------------
clear functions
rehash
addpath(genpath(pwd))
Rpre = test_F1_33bus_forecast_shaped_bess_realization_v2(pwd,false);

The preflight prints BOTH patched statements explicitly. Check that they
look syntactically normal.

Only if PASS:
-------------
Rfs = test_F1_33bus_forecast_shaped_bess_realization_v2(pwd,true);

Expected simulation cost
------------------------
About 50-55 minutes.

Emergency restore
-----------------
Rrestore = restore_forecast_shaped_bess_engine_v2(pwd);
