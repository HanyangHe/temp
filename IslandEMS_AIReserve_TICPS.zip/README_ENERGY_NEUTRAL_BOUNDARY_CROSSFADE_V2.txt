ENERGY-NEUTRAL BOUNDARY CROSSFADE TEST V2
==========================================

The V1 simulation completed, but its fixed -v7.3 result filename failed to save because the destination appeared corrupt.

V2 keeps the EXACT SAME 5-min symmetric crossfade experiment and only hardens persistence:

1. Restore production engine immediately after simulation.
2. Compute security metrics before full-result persistence.
3. Save a small summary MAT + CSV files first.
4. Save the full result to a unique temporary MAT.
5. Verify it with whos('-file',...).
6. Atomically rename it to a timestamped final MAT.
7. If full-result save still fails, the summary outcome remains safely saved and printed.

The old V1 corrupt MAT is never overwritten or reused.

Files
-----
tests/test_F1_33bus_energy_neutral_boundary_crossfade_v2.m
tools/common_boundary_crossfade_value_v1.m
tools/restore_boundary_crossfade_engine_v2.m

Run
---
clear functions
rehash
addpath(genpath(pwd))
Rpre = test_F1_33bus_energy_neutral_boundary_crossfade_v2(pwd,false);

If PASS:
Rxf = test_F1_33bus_energy_neutral_boundary_crossfade_v2(pwd,true);
