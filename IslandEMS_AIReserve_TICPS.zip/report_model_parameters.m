%% Report key model/reserve parameters directly from the frozen configuration
clear; clc;
projectRoot=fileparts(mfilename('fullpath'));
addpath(genpath(projectRoot));
cfg=config_island_ems();
validate_config(cfg);

caseNames=["10bus","18bus","33bus"];
CaseName=strings(0,1);
DGindex=[]; DG_Rating_kW=[]; Droop_pu=[]; H_s=[];
ReserveDeltaF_Hz=[]; ReserveRoCoF_Hz_s=[];
DroopReserve_pu=[]; RoCoFReserve_pu=[]; FinalReserve_kW=[];

for ic=1:numel(caseNames)
    caseName=caseNames(ic);
    % Use a fixed seed so any randomized load ratings do not affect this
    % device/reserve parameter report.
    rng(0,'twister');
    sys=system_case_catalog(caseName,cfg);
    R=cfg.frequency.droop_pu*ones(size(sys.DieselG_Pgfm_rate(:)));
    H=cfg.frequency.H_s*ones(size(R));
    [rd,~,meta]=compute_frequency_reserve_pu('fixed',1,R,H, ...
        cfg.frequency.reserveDeviation_Hz,cfg.frequency.reserveRoCoF_Hz_s, ...
        cfg.frequency.nominal_Hz,[],[],cfg.frequency.dgPmin_pu, ...
        cfg.frequency.dgPmax_pu,cfg.ai);
    for g=1:numel(sys.DieselG_Pgfm_rate)
        CaseName(end+1,1)=caseName; %#ok<SAGROW>
        DGindex(end+1,1)=g; %#ok<AGROW>
        DG_Rating_kW(end+1,1)=1000*sys.DieselG_Pgfm_rate(g); %#ok<AGROW>
        Droop_pu(end+1,1)=R(g); %#ok<AGROW>
        H_s(end+1,1)=H(g); %#ok<AGROW>
        ReserveDeltaF_Hz(end+1,1)=cfg.frequency.reserveDeviation_Hz; %#ok<AGROW>
        ReserveRoCoF_Hz_s(end+1,1)=cfg.frequency.reserveRoCoF_Hz_s; %#ok<AGROW>
        DroopReserve_pu(end+1,1)=meta.droopPu(g); %#ok<AGROW>
        RoCoFReserve_pu(end+1,1)=meta.rocofPu(g); %#ok<AGROW>
        FinalReserve_kW(end+1,1)=1000*rd(g)*sys.DieselG_Pgfm_rate(g); %#ok<AGROW>
    end
end

T=table(CaseName,DGindex,DG_Rating_kW,Droop_pu,H_s, ...
    ReserveDeltaF_Hz,ReserveRoCoF_Hz_s,DroopReserve_pu, ...
    RoCoFReserve_pu,FinalReserve_kW);
disp(T);
outDir=fullfile(projectRoot,cfg.output.root);
if ~exist(outDir,'dir'), mkdir(outDir); end
outFile=fullfile(outDir,'model_parameter_audit.csv');
writetable(T,outFile);
fprintf('Saved parameter audit: %s\n',outFile);
