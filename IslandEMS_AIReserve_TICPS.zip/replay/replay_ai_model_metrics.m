function T = replay_ai_model_metrics(caseName,projectRoot)
%REPLAY_AI_MODEL_METRICS Replay paper KRR metrics with NO simulation.
%
% The raw false-safe rate is defined exactly as in the manuscript:
%
%   r_FS = N(yhat_raw <= 1 AND y_true > 1) / N(yhat_raw <= 1)
%
% and is evaluated on the SAME held-out test rows/groups used by the saved
% KRR model.  No safety-calibration offset and no online forecast guard are
% applied to yhat_raw.
%
% This helper first attempts to reconstruct the held-out raw KRR predictions
% from the saved model + canonical response dataset.  If the exact test split
% cannot be recovered, it will only accept an explicitly saved RAW false-safe
% metric; it will NOT silently evaluate on the full training dataset.
%
% Usage:
%   T = replay_ai_model_metrics("18bus",pwd);
%   disp(T)
%
% Expected project files:
%   ai/datasets/<case>/reserve_response_dataset_paper.mat
%   ai/models/<case>/reserve_krr_model.mat
%   select_reserve_alpha_batch.m
%
% NO optimization or physical simulation is launched.

if nargin < 1 || strlength(string(caseName))==0
    caseName = "18bus";
end
if nargin < 2 || isempty(projectRoot)
    projectRoot = pwd;
end

caseName = string(caseName);
projectRoot = char(projectRoot);

cfg = config_island_ems();

datasetFile = resolve_case_file_local( ...
    projectRoot,cfg.ai.datasetRoot,caseName,cfg.ai.datasetFileName);

modelFile = resolve_case_file_local( ...
    projectRoot,cfg.ai.modelRoot,caseName,cfg.ai.modelFileName);

assert(exist(datasetFile,'file')==2, ...
    'Canonical AI response dataset not found: %s',datasetFile);
assert(exist(modelFile,'file')==2, ...
    'AI reserve model not found: %s',modelFile);

Dmat = load(datasetFile);
Mmat = load(modelFile);
model = unwrap_model_local(Mmat);

D = decode_dataset_local(Dmat);

NSamples = numel(D.y);
if isempty(D.group)
    NGroups = NaN;
else
    NGroups = numel(unique(string(D.group)));
end

% -------------------------------------------------------------------------
% Recover the exact held-out split.
% -------------------------------------------------------------------------
[testMask,splitSource] = recover_test_mask_local(Mmat,Dmat,D);

% -------------------------------------------------------------------------
% Reconstruct RAW KRR prediction on the held-out rows.
% -------------------------------------------------------------------------
rawPred = [];
metricSource = "";
status = "VALID";

if ~isempty(testMask) && any(testMask)

    Xtest = D.X(testMask,:);
    atest = D.alpha(testMask);
    ytest = D.y(testMask);

    try
        rawPred = predict_raw_at_observed_alpha_local( ...
            model,Xtest,atest,cfg.ai);

        finite = isfinite(rawPred) & isfinite(ytest);
        rawPred = rawPred(finite);
        ytest = ytest(finite);

        assert(~isempty(rawPred), ...
            'No finite held-out predictions remained.');

        err = rawPred-ytest;
        TestRMSE = sqrt(mean(err.^2,'omitnan'));
        TestMAE  = mean(abs(err),'omitnan');

        predictedSafe = rawPred <= 1;
        falseSafe = predictedSafe & ytest > 1;

        NPredictedSafe = nnz(predictedSafe);
        NFalseSafe = nnz(falseSafe);

        if NPredictedSafe > 0
            RawFalseSafeRate = NFalseSafe/NPredictedSafe;
        else
            RawFalseSafeRate = NaN;
        end

        NTestSamples = numel(ytest);

        if isempty(D.group)
            NTestGroups = NaN;
        else
            gtest = string(D.group(testMask));
            gtest = gtest(finite);
            NTestGroups = numel(unique(gtest));
        end

        metricSource = "reconstructed held-out raw KRR; split=" + splitSource;

    catch ME
        warning('Held-out raw metric reconstruction failed: %s',ME.message);
        rawPred = [];
    end
end

% -------------------------------------------------------------------------
% Fallback: accept only explicitly saved RAW metrics, never a generic
% "FalseSafeRate" that might have been computed after old calibration.
% -------------------------------------------------------------------------
if isempty(rawPred)

    RawFalseSafeRate = find_named_scalar_local(Mmat, ...
        ["rawFalseSafeRate","falseSafeRateRaw", ...
         "rawTestFalseSafeRate","testRawFalseSafeRate"]);

    TestRMSE = find_named_scalar_local(Mmat, ...
        ["stressTestRMSE","testRMSE","TestRMSE"]);
    TestMAE = find_named_scalar_local(Mmat, ...
        ["stressTestMAE","testMAE","TestMAE"]);

    NTestSamples = find_named_scalar_local(Mmat, ...
        ["nTestSamples","NTestSamples","testSampleCount"]);
    NTestGroups = find_named_scalar_local(Mmat, ...
        ["nTestGroups","NTestGroups","testGroupCount"]);

    NPredictedSafe = find_named_scalar_local(Mmat, ...
        ["rawPredictedSafeCount","nRawPredictedSafe"]);
    NFalseSafe = find_named_scalar_local(Mmat, ...
        ["rawFalseSafeCount","nRawFalseSafe"]);

    if isfinite(RawFalseSafeRate)
        % Store internally as a fraction.  If saved as percent, normalize.
        if RawFalseSafeRate > 1
            RawFalseSafeRate = RawFalseSafeRate/100;
        end
        metricSource = "explicit saved RAW model metric";
        status = "VALID_SAVED_RAW";
    else
        status = "UNRESOLVED_TEST_SPLIT_OR_RAW_METRIC";
        metricSource = ...
            "raw false-safe unavailable; do not use generic calibrated metric";
    end
end

% -------------------------------------------------------------------------
% Other paper quantities.
% -------------------------------------------------------------------------
GlobalFixedAlpha = find_named_scalar_local(Mmat, ...
    ["globalFixedAlpha","GlobalFixedAlpha","fixedAlphaGlobal"]);

if ~isfinite(GlobalFixedAlpha)
    % The formal 18-bus G1 result itself shows alpha=0.60, but the model-level
    % value should preferably come from training metadata.  Leave NaN when
    % it is not explicitly stored.
    GlobalFixedAlpha = NaN;
end

RawFalseSafeRate_pct = 100*RawFalseSafeRate;

T = table( ...
    caseName, ...
    string(status), ...
    NSamples, ...
    NGroups, ...
    NTestSamples, ...
    NTestGroups, ...
    TestRMSE, ...
    TestMAE, ...
    RawFalseSafeRate_pct, ...
    NFalseSafe, ...
    NPredictedSafe, ...
    GlobalFixedAlpha, ...
    string(metricSource), ...
    string(datasetFile), ...
    string(modelFile), ...
    'VariableNames',{ ...
    'CaseName', ...
    'Status', ...
    'NSamples', ...
    'NGroups', ...
    'NTestSamples', ...
    'NTestGroups', ...
    'TestRMSE', ...
    'TestMAE', ...
    'RawFalseSafeRate_pct', ...
    'NFalseSafe', ...
    'NPredictedSafe', ...
    'GlobalFixedAlpha', ...
    'MetricSource', ...
    'DatasetFile', ...
    'ModelFile'});

fprintf('\n=============================================================\n');
fprintf(' OFFLINE KRR MODEL METRICS -- %s\n',upper(caseName));
fprintf('=============================================================\n');
disp(T(:,{ ...
    'CaseName','Status','NSamples','NGroups','NTestSamples','NTestGroups', ...
    'TestRMSE','TestMAE','RawFalseSafeRate_pct', ...
    'NFalseSafe','NPredictedSafe','GlobalFixedAlpha'}));

fprintf('Raw false-safe definition:\n');
fprintf('  N(raw predicted stress <= 1 AND simulated stress > 1)\n');
fprintf('  -------------------------------------------------------\n');
fprintf('          N(raw predicted stress <= 1)\n');
fprintf('Metric source: %s\n',metricSource);
fprintf('NO simulation was launched.\n');
fprintf('=============================================================\n');

if startsWith(status,"UNRESOLVED")
    fprintf(2,['WARNING: Raw false-safe rate was NOT reported because the ', ...
        'exact held-out split or an explicitly saved RAW metric could not ', ...
        'be recovered. Do not substitute the full-dataset rate.\n']);
end

end


%% =========================================================================
% Local helpers
% =========================================================================
function filePath = resolve_case_file_local(projectRoot,rootRel,caseName,fileName)
filePath = fullfile(projectRoot,rootRel,char(caseName),fileName);
if exist(filePath,'file')==2
    return;
end
candidate = fullfile(projectRoot,rootRel,fileName);
if exist(candidate,'file')==2
    filePath = candidate;
    return;
end
hits = dir(fullfile(projectRoot,'**',fileName));
if isempty(hits)
    return;
end
for i=1:numel(hits)
    p = fullfile(hits(i).folder,hits(i).name);
    if contains(lower(p),lower(char(caseName)))
        filePath = p;
        return;
    end
end
filePath = fullfile(hits(1).folder,hits(1).name);
end


function model = unwrap_model_local(S)
if isfield(S,'model') && isstruct(S.model)
    model = S.model;
    return;
end

fn = fieldnames(S);
for i=1:numel(fn)
    x = S.(fn{i});
    if isstruct(x) && numel(x)==1 && ...
            isfield(x,'stateFeatureNames') && ...
            isfield(x,'learningTarget')
        model = x;
        return;
    end
end

% Last resort: a one-struct MAT file.
structNames = fn(structfun(@(x)isstruct(x)&&numel(x)==1,S));
if numel(structNames)==1
    model = S.(structNames{1});
    return;
end

error('Could not identify the saved KRR model struct.');
end


function D = decode_dataset_local(S)
D = struct('X',[],'alpha',[],'y',[],'group',[],'testMask',[]);

[ok,D] = decode_struct_local(S,0);
assert(ok, ...
    ['Could not decode canonical response dataset. Expected three state ', ...
     'features, candidate alpha, stress target, and preferably group IDs.']);

good = all(isfinite(D.X),2) & isfinite(D.alpha) & isfinite(D.y);
D.X = D.X(good,:);
D.alpha = D.alpha(good);
D.y = D.y(good);

if ~isempty(D.group)
    D.group = D.group(good);
end
if ~isempty(D.testMask)
    D.testMask = logical(D.testMask(good));
end
end


function [ok,D] = decode_struct_local(S,depth)
D = struct('X',[],'alpha',[],'y',[],'group',[],'testMask',[]);
ok = false;

if depth>7 || ~isstruct(S)
    return;
end

if numel(S)>1
    try
        [ok,D] = decode_table_local(struct2table(S));
    catch
    end
    return;
end

fn = fieldnames(S);

% Tables first.
for i=1:numel(fn)
    v = S.(fn{i});
    if istable(v)
        [ok,D] = decode_table_local(v);
        if ok
            % Sibling group/split metadata may be separate from the table.
            N = numel(D.y);
            if isempty(D.group)
                D.group = find_group_vector_local(S,N);
            end
            if isempty(D.testMask)
                D.testMask = find_test_mask_vector_local(S,N);
            end
            return;
        end
    end
end

% Matrix X plus Y.
Xraw = [];
xName = "";
for i=1:numel(fn)
    name = string(fn{i});
    v = S.(fn{i});
    if isnumeric(v) && ismatrix(v) && size(v,1)>=20 && size(v,2)>=3
        lname = lower(name);
        if strcmpi(name,"X") || contains(lname,"feature") || ...
                contains(lname,"input") || contains(lname,"predictor")
            Xraw = double(v);
            xName = name; %#ok<NASGU>
            break;
        end
    end
end

if isempty(Xraw)
    c = {};
    for i=1:numel(fn)
        v=S.(fn{i});
        if isnumeric(v) && ismatrix(v) && size(v,1)>=20 && size(v,2)==4
            c{end+1}=double(v); %#ok<AGROW>
        end
    end
    if numel(c)==1
        Xraw=c{1};
    end
end

if ~isempty(Xraw)
    N=size(Xraw,1);
    y=find_target_vector_local(S,N);

    alpha=[];
    if size(Xraw,2)>=4 && alpha_plausible_local(Xraw(:,4))
        alpha=double(Xraw(:,4));
    else
        alpha=find_alpha_vector_local(S,N);
    end

    if ~isempty(y) && ~isempty(alpha)
        D.X=double(Xraw(:,1:3));
        D.alpha=double(alpha(:));
        D.y=double(y(:));
        D.group=find_group_vector_local(S,N);
        D.testMask=find_test_mask_vector_local(S,N);
        ok=true;
        return;
    end
end

% Separate vectors.
Ncandidate = find_common_vector_length_local(S);
if isfinite(Ncandidate) && Ncandidate>=20
    v1=find_vector_by_tokens_local(S,Ncandidate, ...
        ["netloadnowpu","netloadpu"],["netload"],["ramp","drop","delta"]);
    v2=find_vector_by_tokens_local(S,Ncandidate, ...
        ["absnetloadramppu","netloadramppu"],["netload","ramp"],[]);
    v3=find_vector_by_tokens_local(S,Ncandidate, ...
        ["dgupheadroompu","dgheadroompu"],["headroom"],[]);
    a=find_alpha_vector_local(S,Ncandidate);
    y=find_target_vector_local(S,Ncandidate);

    if ~isempty(v1)&&~isempty(v2)&&~isempty(v3)&&~isempty(a)&&~isempty(y)
        D.X=[double(v1(:)) double(v2(:)) double(v3(:))];
        D.alpha=double(a(:));
        D.y=double(y(:));
        D.group=find_group_vector_local(S,Ncandidate);
        D.testMask=find_test_mask_vector_local(S,Ncandidate);
        ok=true;
        return;
    end
end

% Recurse.
for i=1:numel(fn)
    v=S.(fn{i});
    if isstruct(v)
        [ok2,D2]=decode_struct_local(v,depth+1);
        if ok2
            ok=true; D=D2; return;
        end
    elseif iscell(v)
        for j=1:min(numel(v),100)
            x=v{j};
            if isstruct(x)
                [ok2,D2]=decode_struct_local(x,depth+1);
                if ok2
                    ok=true; D=D2; return;
                end
            elseif istable(x)
                [ok2,D2]=decode_table_local(x);
                if ok2
                    ok=true; D=D2; return;
                end
            end
        end
    end
end
end


function [ok,D] = decode_table_local(T)
D=struct('X',[],'alpha',[],'y',[],'group',[],'testMask',[]);
ok=false;
if height(T)<20, return; end

names=string(T.Properties.VariableNames);
norm=normalize_names_local(names);

i1=find_column_local(norm,["netloadnowpu","netloadpu"],["netload"],["ramp","drop","delta"]);
i2=find_column_local(norm,["absnetloadramppu","netloadramppu"],["netload","ramp"],[]);
i3=find_column_local(norm,["dgupheadroompu","dgheadroompu"],["headroom"],[]);
ia=find_column_local(norm,["alpha","candidatealpha","reserveratio"],["alpha"],[]);
if isempty(ia)
    ia=find_column_local(norm,[],["reserve","ratio"],[]);
end
iy=find_column_local(norm,["stress","targetstress","frequencystress","normalizedstress","y"],["stress"],[]);

if isempty(i1)||isempty(i2)||isempty(i3)||isempty(ia)||isempty(iy)
    return;
end

try
    D.X=[double(T{:,i1}) double(T{:,i2}) double(T{:,i3})];
    D.alpha=double(T{:,ia});
    D.y=double(T{:,iy});
catch
    return;
end

ig=find_column_local(norm, ...
    ["groupid","group","trajectoryid","scenarioid","trajectorygroup"], ...
    ["group"],[]);
if isempty(ig)
    ig=find_column_local(norm,[],["trajectory"],[]);
end
if ~isempty(ig)
    D.group=T{:,ig};
end

it=find_column_local(norm, ...
    ["istest","testmask","holdoutmask"],["test"],[]);
if ~isempty(it)
    try
        D.testMask=logical(T{:,it});
    catch
    end
end

ok=true;
end


function [testMask,source] = recover_test_mask_local(Mmat,Dmat,D)
N=numel(D.y);
testMask=[];
source="";

% Dataset-explicit split is strongest.
if ~isempty(D.testMask) && numel(D.testMask)==N
    testMask=logical(D.testMask(:));
    source="dataset explicit test mask";
    return;
end

% Search model MAT for row mask / indices.
[mask,path]=find_test_mask_recursive_local(Mmat,N,0,"modelMAT");
if ~isempty(mask)
    testMask=mask;
    source="saved model row split: "+path;
    return;
end

% Search dataset MAT for a split vector not caught by decoder.
[mask,path]=find_test_mask_recursive_local(Dmat,N,0,"datasetMAT");
if ~isempty(mask)
    testMask=mask;
    source="saved dataset row split: "+path;
    return;
end

% Group-level held-out metadata.
if ~isempty(D.group)
    [testGroups,path]=find_test_groups_recursive_local(Mmat,D.group,0,"modelMAT");
    if ~isempty(testGroups)
        testMask=ismember(string(D.group),string(testGroups));
        source="saved model held-out groups: "+path;
        return;
    end
end
end


function rawPred = predict_raw_at_observed_alpha_local(model,X,alpha,aiCfg)
assert(exist('select_reserve_alpha_batch','file')==2, ...
    'select_reserve_alpha_batch.m is not on the MATLAB path.');

alpha=double(alpha(:));
grid=unique(round(alpha,10)).';

cfgRun=aiCfg;
cfgRun.useSafetyCalibration=false;
cfgRun.alphaMin=min(grid);
cfgRun.alphaMax=max(grid);
cfgRun.candidateAlphaGrid=grid;
cfgRun.fallbackAlpha=max(grid);

[~,detail]=select_reserve_alpha_batch(model,double(X),cfgRun,false);

assert(isfield(detail,'rawStress') && isfield(detail,'alphaGrid'), ...
    'Selector did not expose rawStress/alphaGrid diagnostics.');

curve=double(detail.rawStress);
g=double(detail.alphaGrid(:).');

assert(size(curve,1)==size(X,1), ...
    'rawStress row count does not match test sample count.');

rawPred=nan(size(alpha));
for i=1:numel(alpha)
    [dist,j]=min(abs(g-alpha(i)));
    assert(dist<1e-8, ...
        'Observed alpha %.12g is absent from replay grid.',alpha(i));
    rawPred(i)=curve(i,j);
end
end


function [mask,path] = find_test_mask_recursive_local(S,N,depth,path0)
mask=[]; path="";
if depth>7 || ~isstruct(S), return; end

if numel(S)>1, return; end
fn=fieldnames(S);

for i=1:numel(fn)
    name=string(fn{i});
    norm=normalize_names_local(name);
    v=S.(fn{i});
    p=path0+"."+name;

    if islogical(v) && isvector(v) && numel(v)==N && ...
            (contains(norm,"test") || contains(norm,"holdout"))
        mask=logical(v(:)); path=p; return;
    end

    if isnumeric(v) && isvector(v)
        z=double(v(:));

        if numel(z)==N && all(isfinite(z)) && ...
                all(ismember(unique(z),[0 1])) && ...
                (contains(norm,"test") || contains(norm,"holdout"))
            mask=logical(z); path=p; return;
        end

        if numel(z)>=1 && numel(z)<N && all(isfinite(z)) && ...
                all(z>=1) && all(z<=N) && all(abs(z-round(z))<1e-12) && ...
                (contains(norm,"testidx") || ...
                 contains(norm,"testindice") || ...
                 contains(norm,"holdoutidx"))
            mask=false(N,1);
            mask(round(z))=true;
            path=p; return;
        end
    end
end

for i=1:numel(fn)
    v=S.(fn{i});
    if isstruct(v) && numel(v)==1
        [mask,path]=find_test_mask_recursive_local( ...
            v,N,depth+1,path0+"."+string(fn{i}));
        if ~isempty(mask), return; end
    end
end
end


function [groups,path] = find_test_groups_recursive_local(S,datasetGroups,depth,path0)
groups=[]; path="";
if depth>7 || ~isstruct(S) || numel(S)>1, return; end

u=unique(string(datasetGroups));
fn=fieldnames(S);

for i=1:numel(fn)
    name=string(fn{i});
    norm=normalize_names_local(name);
    v=S.(fn{i});
    p=path0+"."+name;

    if (contains(norm,"testgroup") || contains(norm,"holdoutgroup"))
        if isnumeric(v) || islogical(v) || isstring(v) || ischar(v) || iscellstr(v)
            vv=string(v(:));
            if any(ismember(vv,u))
                groups=vv; path=p; return;
            end
        end
    end
end

for i=1:numel(fn)
    v=S.(fn{i});
    if isstruct(v) && numel(v)==1
        [groups,path]=find_test_groups_recursive_local( ...
            v,datasetGroups,depth+1,path0+"."+string(fn{i}));
        if ~isempty(groups), return; end
    end
end
end


function val = find_named_scalar_local(S,candidates)
val=NaN;
[val0,found]=find_named_scalar_recursive_local(S, ...
    normalize_names_local(candidates),0);
if found, val=val0; end
end


function [val,found] = find_named_scalar_recursive_local(S,normCandidates,depth)
val=NaN; found=false;
if depth>8 || ~isstruct(S) || numel(S)>1, return; end
fn=fieldnames(S);
for i=1:numel(fn)
    n=normalize_names_local(string(fn{i}));
    v=S.(fn{i});
    if any(strcmpi(n,normCandidates)) && isnumeric(v) && isscalar(v)
        val=double(v); found=true; return;
    end
end
for i=1:numel(fn)
    v=S.(fn{i});
    if isstruct(v) && numel(v)==1
        [val,found]=find_named_scalar_recursive_local(v,normCandidates,depth+1);
        if found, return; end
    end
end
end


function y=find_target_vector_local(S,N)
y=find_vector_by_tokens_local(S,N, ...
    ["y","stress","targetstress","frequencystress","normalizedstress"], ...
    ["stress"],[]);
end


function a=find_alpha_vector_local(S,N)
a=find_vector_by_tokens_local(S,N, ...
    ["alpha","candidatealpha","reserveratio","reservealpha"], ...
    ["alpha"],[]);
if isempty(a)
    a=find_vector_by_tokens_local(S,N,[],["reserve","ratio"],[]);
end
if ~isempty(a) && ~alpha_plausible_local(a), a=[]; end
end


function g=find_group_vector_local(S,N)
g=[];
fn=fieldnames(S);
for i=1:numel(fn)
    name=normalize_names_local(string(fn{i}));
    v=S.(fn{i});
    if isvector(v) && numel(v)==N && ...
            (contains(name,"group") || contains(name,"trajectoryid") || ...
             contains(name,"scenarioid"))
        if isnumeric(v)||islogical(v)||isstring(v)||iscellstr(v)||iscategorical(v)
            g=v(:); return;
        end
    end
end
end


function mask=find_test_mask_vector_local(S,N)
mask=[];
fn=fieldnames(S);
for i=1:numel(fn)
    name=normalize_names_local(string(fn{i}));
    v=S.(fn{i});
    if isvector(v) && numel(v)==N && ...
            (contains(name,"test") || contains(name,"holdout"))
        if islogical(v)
            mask=v(:); return;
        elseif isnumeric(v) && all(ismember(unique(double(v(:))),[0 1]))
            mask=logical(v(:)); return;
        end
    end
end
end


function v=find_vector_by_tokens_local(S,N,exact,must,mustNot)
v=[];
fn=fieldnames(S);
norm=normalize_names_local(string(fn));

idx=find_column_local(norm,exact,must,mustNot);
if ~isempty(idx)
    x=S.(fn{idx});
    if isnumeric(x) && isvector(x) && numel(x)==N
        v=double(x(:));
    end
end
end


function N=find_common_vector_length_local(S)
N=NaN;
fn=fieldnames(S);
lens=[];
for i=1:numel(fn)
    v=S.(fn{i});
    if (isnumeric(v)||islogical(v)) && isvector(v) && numel(v)>=20
        lens(end+1)=numel(v); %#ok<AGROW>
    end
end
if isempty(lens), return; end
u=unique(lens);
counts=arrayfun(@(x)nnz(lens==x),u);
[~,j]=max(counts);
N=u(j);
end


function idx=find_column_local(normNames,exact,must,mustNot)
idx=[];
for q=1:numel(exact)
    j=find(strcmpi(normNames,normalize_names_local(exact(q))),1);
    if ~isempty(j), idx=j; return; end
end
if isempty(must), return; end
for j=1:numel(normNames)
    s=normNames(j);
    ok=true;
    for q=1:numel(must), ok=ok&&contains(s,normalize_names_local(must(q))); end
    for q=1:numel(mustNot), ok=ok&&~contains(s,normalize_names_local(mustNot(q))); end
    if ok, idx=j; return; end
end
end


function tf=alpha_plausible_local(a)
a=double(a(:)); a=a(isfinite(a));
tf=~isempty(a) && min(a)>=-1e-9 && max(a)<=1.05 && ...
    numel(unique(round(a,8)))>=2;
end


function s=normalize_names_local(s)
s=lower(regexprep(string(s),'[^a-zA-Z0-9]',''));
end
