%% MANUSCRIPT RESULT REPLAY DASHBOARD
% Central Live Script for 10-bus / 18-bus / 33-bus saved-result replay.
%
% NO optimization or physical simulation is launched.
%
% This Live Script controls:
%   - which grid(s) to replay
%   - which saved runTag belongs to each grid
%   - whether figures are displayed
%   - whether figures are exported
%   - whether summary figures are generated
%   - whether detailed operating-profile figures are generated
%   - which methods / decay ratios are shown in detail
%
% Required helper files on the MATLAB path:
%   replay_18bus_manuscript_results.m
%   replay_saved_operating_profiles.m
%
% Later:
%   replay_10bus_manuscript_results.m
%   replay_33bus_manuscript_results.m

clear;
clc;

projectRoot = pwd;
addpath(genpath(projectRoot));


%% ============================================================
%  USER REPLAY OPTIONS
% =============================================================

% Select one or more grids.
replayCases = "18bus";

% Later:
% replayCases = ["10bus","18bus","33bus"];


%% Formal run tags
% Explicit run tags are used so manuscript results are reproducible.

runTags = struct();

runTags.bus10 = '';
runTags.bus18 = '20260907_115951';
runTags.bus33 = '';


%% ============================================================
%  FIGURE OUTPUT CONTROL
% =============================================================
%
% All replay figure behavior is controlled HERE.
%
% Examples:
%
% A) Interactive manuscript analysis:
%       showFigures = true
%       exportFigures = true
%
% B) Full archival export without opening many windows:
%       showFigures = false
%       exportFigures = true
%
% C) Tables/text only:
%       generateSummaryFigures = false
%       generateDetailedProfiles = false

plotOpt = struct();

% ----- Master figure switches -------------------------------------------

plotOpt.showFigures = true;

plotOpt.exportFigures = true;

plotOpt.closeExistingFigures = true;


% ----- Summary / comparison figures -------------------------------------

plotOpt.generateSummaryFigures = true;


% ----- Full physical operating-profile figures --------------------------

plotOpt.generateDetailedProfiles = true;


% ----- Study-specific detailed profile scope ----------------------------
%
% CRITICAL PAPER RULE:
%
%   Part I adaptive-reserve ablation is NORMAL CASE ONLY:
%       decayRatio = 1.00
%
%   Part II curtailment study uses the generation-shortage sweep.
%
% Therefore Part-I methods must NEVER be requested at decay<1.

plotOpt.part1ProfileDecay = 1.00;

plotOpt.part1ProfileMethods = ...
    ["A0","T7","G1","P1U","P1"];

% Part II can be inspected at selected shortage severities.
plotOpt.part2ProfileDecays = [0.20 1.00];

% To display all Part-II shortage levels:
% plotOpt.part2ProfileDecays = [0.20 0.40 0.60 0.80 1.00];

plotOpt.part2ProfileMethods = ["C0","C1","P1"];


if plotOpt.closeExistingFigures
    close all force;
end


fprintf('\n=============================================================\n');
fprintf(' MANUSCRIPT REPLAY DASHBOARD\n');
fprintf('=============================================================\n');
fprintf('Project root            : %s\n',projectRoot);
fprintf('Selected case(s)        : %s\n',strjoin(replayCases,', '));
fprintf('Show figures            : %d\n',plotOpt.showFigures);
fprintf('Export figures          : %d\n',plotOpt.exportFigures);
fprintf('Summary figures         : %d\n',plotOpt.generateSummaryFigures);
fprintf('Detailed profiles       : %d\n',plotOpt.generateDetailedProfiles);
fprintf('Part-I profile decay    : %.2f (NORMAL CASE ONLY)\n', ...
    plotOpt.part1ProfileDecay);
fprintf('Part-I profile methods  : %s\n', ...
    strjoin(plotOpt.part1ProfileMethods,', '));
fprintf('Part-II profile decays  : %s\n', ...
    mat2str(plotOpt.part2ProfileDecays));
fprintf('Part-II profile methods : %s\n', ...
    strjoin(plotOpt.part2ProfileMethods,', '));
fprintf('=============================================================\n');


%% ============================================================
%  REPLAY SAVED RESULTS
% =============================================================

reports = struct();

for caseName = replayCases

    runTag = get_run_tag_local(caseName,runTags);

    fprintf('\n=============================================================\n');
    fprintf(' REPLAYING %s\n',upper(caseName));
    fprintf(' runTag = %s\n',runTag);
    fprintf('=============================================================\n');


    switch string(caseName)

        case "10bus"

            assert(exist('replay_10bus_manuscript_results','file')==2, ...
                ['replay_10bus_manuscript_results.m is not available yet. ', ...
                 'Complete the 10-bus formal run first.']);

            reports.bus10 = ...
                replay_10bus_manuscript_results( ...
                    runTag, ...
                    projectRoot, ...
                    'ShowFigures',plotOpt.showFigures, ...
                    'ExportFigures',plotOpt.exportFigures, ...
                    'GenerateSummaryFigures', ...
                        plotOpt.generateSummaryFigures);


        case "18bus"

            assert(exist('replay_18bus_manuscript_results','file')==2, ...
                'replay_18bus_manuscript_results.m is missing.');

            reports.bus18 = ...
                replay_18bus_manuscript_results( ...
                    runTag, ...
                    projectRoot, ...
                    'ShowFigures',plotOpt.showFigures, ...
                    'ExportFigures',plotOpt.exportFigures, ...
                    'GenerateSummaryFigures', ...
                        plotOpt.generateSummaryFigures);


        case "33bus"

            assert(exist('replay_33bus_manuscript_results','file')==2, ...
                ['replay_33bus_manuscript_results.m is not available yet. ', ...
                 'Complete the 33-bus formal run first.']);

            reports.bus33 = ...
                replay_33bus_manuscript_results( ...
                    runTag, ...
                    projectRoot, ...
                    'ShowFigures',plotOpt.showFigures, ...
                    'ExportFigures',plotOpt.exportFigures, ...
                    'GenerateSummaryFigures', ...
                        plotOpt.generateSummaryFigures);


        otherwise

            error('Unsupported case: %s',caseName);

    end

end


%% ============================================================
%  REPLAY COMPLETION STATUS
% =============================================================

for caseName = replayCases

    report = get_report_local(reports,caseName);

    if isempty(report.missing)

        fprintf('%-5s : COMPLETE\n',caseName);

    else

        fprintf('%-5s : WARNING -- missing results\n',caseName);
        disp(report.missing);

    end

end


%% ============================================================
%  PART I -- ADAPTIVE RESERVE ABLATION (NORMAL CASE ONLY)
% =============================================================
%
% Manuscript labels:
%
%   A0
%   F1 = internal T7, full fixed reserve alpha = 1
%   G1
%   P1U
%   P1

for caseName = replayCases

    report = get_report_local(reports,caseName);

    fprintf('\n-------------------------------------------------------------\n');
    fprintf(' PART I -- %s\n',upper(caseName));
    fprintf('-------------------------------------------------------------\n');

    disp(report.part1Table);


    fprintf('\nP1 versus F1 comparison -- %s\n',upper(caseName));

    disp(report.part1Comparison);

end


%% Part I focused manuscript quantities

part1Vars = { ...
    'PaperLabel', ...
    'DecayRatio', ...
    'TotalCost', ...
    'MeanReserveRatio', ...
    'StdReserveRatio', ...
    'MeanTotalDGReserve_kW', ...
    'MaxTotalDGReserve_kW', ...
    'MaxAbsFreqDev_Hz', ...
    'MaxAbsRoCoF_Hz_s', ...
    'SecurityViolationRate', ...
    'AIOODFallbackRate', ...
    'AINoSafeCandidateFallbackRate'};

for caseName = replayCases

    report = get_report_local(reports,caseName);

    varsThis = part1Vars( ...
        ismember(part1Vars, ...
        report.part1Table.Properties.VariableNames));

    fprintf('\nPart-I focused quantities -- %s\n',upper(caseName));

    disp(report.part1Table(:,varsThis));

end


%% ============================================================
%  PART II -- CURTAILMENT ALLOCATION AND OPERATING COST
% =============================================================
%
% All methods use:
%
%   MPC-SOCP
%   calibrated adaptive reserve
%
% Difference:
%
%   C0 = no special flexibility
%   C1 = BESS-only flexibility
%   P1 = hierarchical BESS / EV / load flexibility

for caseName = replayCases

    report = get_report_local(reports,caseName);

    fprintf('\n-------------------------------------------------------------\n');
    fprintf(' PART II -- %s\n',upper(caseName));
    fprintf('-------------------------------------------------------------\n');

    disp(report.part2Table);


    fprintf('\nC0 / C1 / P1 comparison -- %s\n',upper(caseName));

    disp(report.part2Comparison);

end


%% Part II focused allocation quantities

part2Vars = { ...
    'PaperLabel', ...
    'DecayRatio', ...
    'TotalCost', ...
    'LoadShedEnergy_kWh', ...
    'EVUnmetEnergy_kWh', ...
    'EVCommutingViolation_kWh', ...
    'BESSTerminalDeficit_kWh', ...
    'PVCurtailedEnergy_kWh', ...
    'MeanReserveRatio', ...
    'MaxAbsFreqDev_Hz', ...
    'MaxAbsRoCoF_Hz_s', ...
    'SecurityViolationRate'};

for caseName = replayCases

    report = get_report_local(reports,caseName);

    varsThis = part2Vars( ...
        ismember(part2Vars, ...
        report.part2Table.Properties.VariableNames));

    fprintf('\nPart-II allocation quantities -- %s\n',upper(caseName));

    disp(report.part2Table(:,varsThis));

end


%% ============================================================
%  SEVERE GENERATION-SHORTAGE SUMMARY
% =============================================================

for caseName = replayCases

    report = get_report_local(reports,caseName);

    severeDecay = min(report.part2Table.DecayRatio);

    idx = abs(report.part2Table.DecayRatio-severeDecay) < 1e-12;

    severePart2 = report.part2Table(idx,:);

    varsThis = part2Vars( ...
        ismember(part2Vars, ...
        severePart2.Properties.VariableNames));

    fprintf('\nMost severe Part-II condition -- %s, decay %.2f\n', ...
        upper(caseName), ...
        severeDecay);

    disp(severePart2(:,varsThis));

end


%% ============================================================
%  SOLVER / NUMERICAL RELIABILITY
% =============================================================

solverVars = { ...
    'PaperLabel', ...
    'DecayRatio', ...
    'OptimizationFailureRate', ...
    'OptimizationWarningRate', ...
    'OptimizationConvergedRate', ...
    'PhysicalPFFailureRate', ...
    'MaxSolverManualResidual', ...
    'MaxSolverPrimalFeasibility', ...
    'MaxSolverDualFeasibility', ...
    'MaxSolverRelativeGap', ...
    'SolverRetryRate'};

for caseName = replayCases

    report = get_report_local(reports,caseName);

    varsThis = solverVars( ...
        ismember(solverVars, ...
        report.allTable.Properties.VariableNames));

    fprintf('\nSolver reliability -- %s\n',upper(caseName));

    disp(report.allTable(:,varsThis));

end


%% ============================================================
%  COMPUTATIONAL PERFORMANCE
% =============================================================

runtimeVars = { ...
    'PaperLabel', ...
    'DecayRatio', ...
    'MeanDecisionTime_s', ...
    'MeanReserveEvalTime_ms', ...
    'TotalCoupledRuntime_s'};

for caseName = replayCases

    report = get_report_local(reports,caseName);

    varsThis = runtimeVars( ...
        ismember(runtimeVars, ...
        report.allTable.Properties.VariableNames));

    fprintf('\nComputational performance -- %s\n',upper(caseName));

    disp(report.allTable(:,varsThis));

end


%% ============================================================
%  KEY MANUSCRIPT FINDINGS
% =============================================================

for caseName = replayCases

    report = get_report_local(reports,caseName);

    fprintf('\nKey findings -- %s\n',upper(caseName));

    disp(report.keyFindings);

end


%% ============================================================
%  FULL PHYSICAL OPERATING-PROFILE FIGURES
% =============================================================
%
% This is the section that produces:
%
%   aggregate demand / DG / PV / battery power
%   individual DG power
%   individual storage / EV power
%   all saved SoC curves
%   CoI frequency
%   individual frequencies
%   CoI RoCoF
%   voltage envelope
%   current loading
%   baseline / executed load
%   load reduction / shedding
%   reserve alpha
%   reserve power
%   instantaneous / cumulative cost
%
% NO simulation is launched.

if plotOpt.generateDetailedProfiles

    assert(exist('replay_saved_operating_profiles','file')==2, ...
        'replay_saved_operating_profiles.m is missing.');

    for caseName = replayCases

        report = get_report_local(reports,caseName);

        % -------------------------------------------------------------
        % Part I detailed profiles: NORMAL CASE ONLY (decay=1.00)
        % -------------------------------------------------------------
        decay = plotOpt.part1ProfileDecay;

        assert(abs(decay-1.0)<1e-12, ...
            'Part I detailed replay MUST use decayRatio=1.00 only.');

        for methodID = plotOpt.part1ProfileMethods

            paperLabel = methodID;
            if methodID=="T7"
                paperLabel = "F1";
            end

            fprintf('\n-------------------------------------------------------------\n');
            fprintf(' Part-I detailed physical profile -- NORMAL CASE\n');
            fprintf(' case   : %s\n',upper(caseName));
            fprintf(' method : %s\n',paperLabel);
            fprintf(' decay  : %.2f\n',decay);
            fprintf('-------------------------------------------------------------\n');

            replay_saved_operating_profiles( ...
                report.runRoot,caseName,methodID,decay, ...
                'PaperLabel',paperLabel, ...
                'Visible',plotOpt.showFigures, ...
                'Export',plotOpt.exportFigures);

            drawnow;
        end

        % -------------------------------------------------------------
        % Part II detailed profiles: shortage sweep / selected severities
        % -------------------------------------------------------------
        for decay = plotOpt.part2ProfileDecays

            for methodID = plotOpt.part2ProfileMethods

                paperLabel = methodID;

                fprintf('\n-------------------------------------------------------------\n');
                fprintf(' Part-II detailed physical profile\n');
                fprintf(' case   : %s\n',upper(caseName));
                fprintf(' method : %s\n',paperLabel);
                fprintf(' decay  : %.2f\n',decay);
                fprintf('-------------------------------------------------------------\n');

                replay_saved_operating_profiles( ...
                    report.runRoot,caseName,methodID,decay, ...
                    'PaperLabel',paperLabel, ...
                    'Visible',plotOpt.showFigures, ...
                    'Export',plotOpt.exportFigures);

                drawnow;
            end
        end
    end

end


%% ============================================================
%  CROSS-GRID PART I SUMMARY
% =============================================================

combinedPart1 = table();

for caseName = replayCases

    report = get_report_local(reports,caseName);

    T = report.part1Table;

    T.CaseName = repmat(string(caseName),height(T),1);

    combinedPart1 = append_table_local(combinedPart1,T);

end


if ~isempty(combinedPart1)

    wanted = [ ...
        "CaseName", ...
        "PaperLabel", ...
        "DecayRatio", ...
        "TotalCost", ...
        "MeanReserveRatio", ...
        "MaxAbsFreqDev_Hz", ...
        "MaxAbsRoCoF_Hz_s", ...
        "SecurityViolationRate"];

    wanted = wanted( ...
        ismember(wanted, ...
        string(combinedPart1.Properties.VariableNames)));

    fprintf('\nCross-grid Part-I summary\n');

    disp(combinedPart1(:,cellstr(wanted)));

end


%% ============================================================
%  CROSS-GRID PART II SUMMARY
% =============================================================

combinedPart2 = table();

for caseName = replayCases

    report = get_report_local(reports,caseName);

    T = report.part2Table;

    T.CaseName = repmat(string(caseName),height(T),1);

    combinedPart2 = append_table_local(combinedPart2,T);

end


if ~isempty(combinedPart2)

    wanted = [ ...
        "CaseName", ...
        "PaperLabel", ...
        "DecayRatio", ...
        "TotalCost", ...
        "LoadShedEnergy_kWh", ...
        "EVUnmetEnergy_kWh", ...
        "EVCommutingViolation_kWh", ...
        "BESSTerminalDeficit_kWh", ...
        "SecurityViolationRate"];

    wanted = wanted( ...
        ismember(wanted, ...
        string(combinedPart2.Properties.VariableNames)));

    fprintf('\nCross-grid Part-II summary\n');

    disp(combinedPart2(:,cellstr(wanted)));

end


%% ============================================================
%  OUTPUT LOCATIONS
% =============================================================

fprintf('\n=============================================================\n');
fprintf(' MANUSCRIPT REPLAY OUTPUT LOCATIONS\n');
fprintf('=============================================================\n');

for caseName = replayCases

    report = get_report_local(reports,caseName);

    fprintf('%-5s : %s\n', ...
        caseName, ...
        report.outputDir);

end


%% ============================================================
%  LOCAL FUNCTIONS
% =============================================================

function runTag = get_run_tag_local(caseName,runTags)

switch string(caseName)

    case "10bus"

        runTag = string(runTags.bus10);

    case "18bus"

        runTag = string(runTags.bus18);

    case "33bus"

        runTag = string(runTags.bus33);

    otherwise

        error('Unsupported case: %s',caseName);

end


assert(strlength(runTag)>0, ...
    'No formal runTag has been assigned for %s.',caseName);

end


function report = get_report_local(reports,caseName)

switch string(caseName)

    case "10bus"

        assert(isfield(reports,'bus10'), ...
            '10-bus report has not been replayed.');

        report = reports.bus10;


    case "18bus"

        assert(isfield(reports,'bus18'), ...
            '18-bus report has not been replayed.');

        report = reports.bus18;


    case "33bus"

        assert(isfield(reports,'bus33'), ...
            '33-bus report has not been replayed.');

        report = reports.bus33;


    otherwise

        error('Unsupported case: %s',caseName);

end

end


function Tout = append_table_local(Tout,Tnew)

if isempty(Tout)

    Tout = Tnew;

    return;

end


commonVars = intersect( ...
    Tout.Properties.VariableNames, ...
    Tnew.Properties.VariableNames, ...
    'stable');


Tout = Tout(:,commonVars);

Tnew = Tnew(:,commonVars);


Tout = [Tout; Tnew];

end
