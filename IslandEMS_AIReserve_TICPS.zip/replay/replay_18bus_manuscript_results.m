function report = replay_18bus_manuscript_results(runTag,projectRoot,varargin)
%REPLAY_18BUS_MANUSCRIPT_RESULTS Replay saved 18-bus formal results.
%
% NO optimization or physical simulation is launched.
%
% Usage:
%   report = replay_18bus_manuscript_results('20260907_115951',pwd, ...
%       'ShowFigures',true, ...
%       'ExportFigures',true, ...
%       'GenerateSummaryFigures',true);
%
% The figure options are intentionally controlled by the caller so that the
% top-level replay_manuscript_results.mlx can decide whether figures should
% appear, be exported, both, or neither.

p = inputParser;
addParameter(p,'ShowFigures',true,@(x)islogical(x)||ismember(x,[0 1]));
addParameter(p,'ExportFigures',true,@(x)islogical(x)||ismember(x,[0 1]));
addParameter(p,'GenerateSummaryFigures',true,@(x)islogical(x)||ismember(x,[0 1]));
addParameter(p,'CloseGeneratedFigures',false,@(x)islogical(x)||ismember(x,[0 1]));
parse(p,varargin{:});
opt = p.Results;

if nargin < 1 || isempty(runTag)
    runTag = '20260907_115951';
end
if nargin < 2 || isempty(projectRoot)
    projectRoot = pwd;
end

projectRoot = char(projectRoot);
runTag = char(runTag);

addpath(genpath(projectRoot));
cfg = config_island_ems();

runRoot = fullfile(projectRoot,cfg.output.root,runTag);
assert(exist(runRoot,'dir')==7, ...
    'Saved run folder does not exist: %s',runRoot);

outDir = fullfile(runRoot,'manuscript_replay');
if ~exist(outDir,'dir')
    mkdir(outDir);
end

if opt.ShowFigures
    vis = 'on';
else
    vis = 'off';
end

fprintf('\n=============================================================\n');
fprintf(' MANUSCRIPT RESULT REPLAY -- NO SIMULATION\n');
fprintf(' runRoot : %s\n',runRoot);
fprintf(' case    : 18bus\n');
fprintf(' figures : show=%d, export=%d, summary=%d\n', ...
    opt.ShowFigures,opt.ExportFigures,opt.GenerateSummaryFigures);
fprintf('=============================================================\n');

part1Internal = ["A0","T7","G1","P1U","P1"];
part1Labels   = ["A0","F1","G1","P1U","P1"];
part1Decay = 1.00;  % Part I is NORMAL CASE ONLY.

part2Internal = ["C0","C1","P1"];
part2Labels   = ["C0","C1","P1"];
part2DecayList = cfg.experiment.paperStudies.curtailmentAllocationCost.decayRatios(:).';

caseName = '18bus';
seed = 0;
dayTag = lower(strrep(cfg.scenario.dayType,' ','_'));

rows = struct([]);
records = struct([]);
missing = strings(0,1);

% ---------------------------------------------------------------------
% Part I expected results: A0/F1/G1/P1U/P1 at decay=1.00 ONLY
% ---------------------------------------------------------------------
for im = 1:numel(part1Internal)
    id = part1Internal(im);
    label = part1Labels(im);
    decay = part1Decay;

    [found,row,rec] = load_expected_result_local( ...
        runRoot,caseName,dayTag,seed,id,label,decay);

    if found
        if isempty(rows), rows = row; else, rows(end+1) = row; end %#ok<AGROW>
        if isempty(records), records = rec; else, records(end+1) = rec; end %#ok<AGROW>
    else
        missing(end+1,1) = sprintf('%s decay %.2f',id,decay); %#ok<AGROW>
    end
end

% ---------------------------------------------------------------------
% Part II expected results: C0/C1/P1 across the shortage sweep.
% P1@1.00 is already loaded above, so do not duplicate it.
% ---------------------------------------------------------------------
for decay = part2DecayList
    for im = 1:numel(part2Internal)
        id = part2Internal(im);
        label = part2Labels(im);

        if id=="P1" && abs(decay-part1Decay)<1e-12
            continue;
        end

        [found,row,rec] = load_expected_result_local( ...
            runRoot,caseName,dayTag,seed,id,label,decay);

        if found
            if isempty(rows), rows = row; else, rows(end+1) = row; end %#ok<AGROW>
            if isempty(records), records = rec; else, records(end+1) = rec; end %#ok<AGROW>
        else
            missing(end+1,1) = sprintf('%s decay %.2f',id,decay); %#ok<AGROW>
        end
    end
end

assert(~isempty(rows),'No saved manuscript results were found.');

allTable = struct2table(rows);
allTable = sortrows(allTable,{'DecayRatio','PaperOrder'});

part1Table = allTable( ...
    ismember(string(allTable.MethodID),part1Internal) & ...
    abs(allTable.DecayRatio-part1Decay)<1e-12,:);

part2Table = allTable( ...
    ismember(string(allTable.MethodID),part2Internal) & ...
    ismembertol(allTable.DecayRatio,part2DecayList,1e-12),:);

part1Comparison = build_part1_comparison_local(part1Table);
part2Comparison = build_part2_comparison_local(part2Table);

writetable(allTable,fullfile(outDir,'all_methods_summary.csv'));
writetable(part1Table,fullfile(outDir,'part1_ai_ablation_summary.csv'));
writetable(part2Table,fullfile(outDir,'part2_curtailment_cost_summary.csv'));
writetable(part1Comparison,fullfile(outDir,'part1_comparison_vs_F1.csv'));
writetable(part2Comparison,fullfile(outDir,'part2_comparison_vs_C0_C1.csv'));

fprintf('\nPart I -- Adaptive reserve ablation\n');
print_compact_table_local(part1Table);

fprintf('\nPart II -- Curtailment Allocation and Operating Cost\n');
print_compact_table_local(part2Table);

figures = gobjects(0);

if opt.GenerateSummaryFigures

    figures(end+1) = plot_metric_by_method_local( ...
        part1Table,'TotalCost','Part I (normal case): Operating Cost', ...
        'Total cost ($)',fullfile(outDir,'fig_part1_normal_cost.png'), ...
        vis,opt.ExportFigures);

    figures(end+1) = plot_metric_by_method_local( ...
        part1Table,'MeanReserveRatio','Part I (normal case): Mean Reserve Ratio', ...
        'Mean reserve ratio \alpha', ...
        fullfile(outDir,'fig_part1_normal_mean_reserve_ratio.png'), ...
        vis,opt.ExportFigures);

    figures(end+1) = plot_metric_by_method_local( ...
        part1Table,'MaxAbsFreqDev_Hz', ...
        'Part I (normal case): Maximum CoI Frequency Deviation', ...
        'Maximum |{\Delta}f_{CoI}| (Hz)', ...
        fullfile(outDir,'fig_part1_normal_max_frequency_deviation.png'), ...
        vis,opt.ExportFigures,0.50);

    figures(end+1) = plot_metric_by_decay_local( ...
        part2Table,'TotalCost','Part II: Operating Cost', ...
        'Total cost ($)',fullfile(outDir,'fig_part2_cost_vs_decay.png'), ...
        vis,opt.ExportFigures);

    figures(end+1) = plot_metric_by_decay_local( ...
        part2Table,'LoadShedEnergy_kWh','Part II: Load-Shed Energy', ...
        'Load-shed energy (kWh)', ...
        fullfile(outDir,'fig_part2_load_shed_vs_decay.png'), ...
        vis,opt.ExportFigures);

    figures(end+1) = plot_metric_by_decay_local( ...
        part2Table,'EVUnmetEnergy_kWh','Part II: EV Unmet Energy', ...
        'EV unmet energy (kWh)', ...
        fullfile(outDir,'fig_part2_ev_unmet_vs_decay.png'), ...
        vis,opt.ExportFigures);

    figures(end+1) = plot_metric_by_decay_local( ...
        part2Table,'BESSTerminalDeficit_kWh','Part II: BESS Terminal Deficit', ...
        'BESS terminal deficit (kWh)', ...
        fullfile(outDir,'fig_part2_bess_terminal_deficit_vs_decay.png'), ...
        vis,opt.ExportFigures);

    minDecay = min(part2DecayList);

    fig = plot_part2_components_local(part2Table,minDecay, ...
        fullfile(outDir,'fig_part2_shortage_allocation_components.png'), ...
        vis,opt.ExportFigures);
    if ~isempty(fig), figures(end+1)=fig; end

    fig = plot_frequency_trajectories_local(records,part1Decay, ...
        ["A0","T7","P1"],["A0","F1","P1"], ...
        cfg.frequency.nominal_Hz,cfg.frequency.securityDeviation_Hz, ...
        fullfile(outDir,'fig_part1_normal_frequency_trajectories.png'), ...
        vis,opt.ExportFigures);
    if ~isempty(fig), figures(end+1)=fig; end

    fig = plot_reserve_ratio_trajectories_local(records,part1Decay, ...
        ["T7","G1","P1U","P1"],["F1","G1","P1U","P1"], ...
        fullfile(outDir,'fig_part1_normal_reserve_ratio_trajectories.png'), ...
        vis,opt.ExportFigures);
    if ~isempty(fig), figures(end+1)=fig; end
end

keyFindings = derive_key_findings_local(part1Comparison,part2Comparison);

report = struct();
report.runTag = runTag;
report.runRoot = runRoot;
report.outputDir = outDir;
report.missing = missing;
report.allTable = allTable;
report.part1Table = part1Table;
report.part2Table = part2Table;
report.part1Comparison = part1Comparison;
report.part2Comparison = part2Comparison;
report.keyFindings = keyFindings;
report.records = records;
report.figureOptions = opt;
report.figures = figures;
report.generatedAt = datestr(now,30);

% Save replay data without graphics handles to avoid MAT-file warnings/bloat.
figuresForCaller = report.figures;
report.figures = gobjects(0);
save(fullfile(outDir,'manuscript_replay.mat'),'report','-v7.3');
report.figures = figuresForCaller;

if opt.CloseGeneratedFigures && ~isempty(figures)
    close(figures(isgraphics(figures)));
end

fprintf('\nReplay completed. NO simulation was launched.\n');
fprintf('Output folder:\n  %s\n\n',outDir);
end

% -------------------------------------------------------------------------
% Helpers
% -------------------------------------------------------------------------
function [found,row,rec] = load_expected_result_local( ...
    runRoot,caseName,dayTag,seed,id,label,decay)

row = struct([]);
rec = struct([]);
found = false;

methodDir = fullfile(runRoot,char(id));
decayCode = round(100*decay);
pattern = sprintf('%s_%s_decay%03d_seed%03d_*.mat', ...
    caseName,dayTag,decayCode,seed);

hits = dir(fullfile(methodDir,pattern));

if isempty(hits)
    return;
end

if numel(hits)>1
    error('Multiple saved files match %s decay %.2f.',id,decay);
end

filePath = fullfile(hits(1).folder,hits(1).name);
result = load_result_struct_local(filePath);

row = summarize_result_local(result,id,label,decay,filePath);

rec = struct();
rec.methodID = char(id);
rec.paperLabel = char(label);
rec.decayRatio = decay;
rec.filePath = filePath;
rec.result = result;

found = true;
end


function result = load_result_struct_local(filePath)
S = load(filePath);
if isfield(S,'result') && isstruct(S.result)
    result = S.result;
    return;
end
names = fieldnames(S);
for k = 1:numel(names)
    x = S.(names{k});
    if isstruct(x) && ...
            (isfield(x,'summary') || isfield(x,'totalCost') || isfield(x,'freq_Hz'))
        result = x;
        return;
    end
end
error('Could not identify a result struct in %s.',filePath);
end

function row = summarize_result_local(result,id,label,decay,filePath)
row = struct();
row.MethodID = string(id);
row.PaperLabel = string(label);
row.PaperOrder = paper_order_local(string(label));
row.DecayRatio = decay;
row.TotalCost = get_metric_local(result,'totalCost',NaN);

names = { ...
'maxAbsFreqDev_Hz','maxIndividualFreqDev_Hz','maxAbsRoCoF_Hz_s', ...
'maxIndividualRoCoF_Hz_s','frequencyViolationRate', ...
'individualFrequencyViolationRate','securityViolationRate', ...
'minVoltage_pu','maxVoltage_pu','maxCurrentRatio', ...
'meanReserveRatio','stdReserveRatio','meanTotalDGReserve_kW', ...
'maxTotalDGReserve_kW','reserveFeasibilityClipRate', ...
'aiOODFallbackRate','aiNoSafeCandidateFallbackRate', ...
'aiMissingFeatureFallbackRate','loadShedEnergy_kWh','EVUnmetEnergy_kWh', ...
'EVCommutingViolation_kWh','BESSTerminalDeficit_kWh', ...
'PVCurtailedEnergy_kWh','optimizationFailureRate', ...
'optimizationWarningRate','optimizationConvergedRate', ...
'physicalPFFailureRate','maxSolverManualResidual', ...
'maxSolverPrimalFeasibility','maxSolverDualFeasibility', ...
'maxSolverRelativeGap','solverRetryRate','meanDecisionTime_s', ...
'meanReserveEvalTime_ms','totalCoupledRuntime_s'};

outNames = { ...
'MaxAbsFreqDev_Hz','MaxIndividualFreqDev_Hz','MaxAbsRoCoF_Hz_s', ...
'MaxIndividualRoCoF_Hz_s','FrequencyViolationRate', ...
'IndividualFrequencyViolationRate','SecurityViolationRate', ...
'MinVoltage_pu','MaxVoltage_pu','MaxCurrentRatio', ...
'MeanReserveRatio','StdReserveRatio','MeanTotalDGReserve_kW', ...
'MaxTotalDGReserve_kW','ReserveFeasibilityClipRate', ...
'AIOODFallbackRate','AINoSafeCandidateFallbackRate', ...
'AIMissingFeatureFallbackRate','LoadShedEnergy_kWh','EVUnmetEnergy_kWh', ...
'EVCommutingViolation_kWh','BESSTerminalDeficit_kWh', ...
'PVCurtailedEnergy_kWh','OptimizationFailureRate', ...
'OptimizationWarningRate','OptimizationConvergedRate', ...
'PhysicalPFFailureRate','MaxSolverManualResidual', ...
'MaxSolverPrimalFeasibility','MaxSolverDualFeasibility', ...
'MaxSolverRelativeGap','SolverRetryRate','MeanDecisionTime_s', ...
'MeanReserveEvalTime_ms','TotalCoupledRuntime_s'};

for k = 1:numel(names)
    row.(outNames{k}) = get_summary_local(result,names{k},NaN);
end

row.ResultFile = string(filePath);
end

function value = get_metric_local(result,name,defaultValue)
if isfield(result,name)
    x = result.(name);
    if isnumeric(x) && isscalar(x)
        value = double(x); return;
    end
end
value = get_summary_local(result,name,defaultValue);
end

function value = get_summary_local(result,name,defaultValue)
value = defaultValue;
if ~isfield(result,'summary') || isempty(result.summary), return; end
s = result.summary;
if istable(s)
    if ismember(name,s.Properties.VariableNames)
        x = s.(name);
        if isnumeric(x)&&~isempty(x), value=double(x(1)); end
    end
elseif isstruct(s) && isfield(s,name)
    x = s.(name);
    if (isnumeric(x)||islogical(x)) && isscalar(x)
        value = double(x);
    end
end
end

function order = paper_order_local(label)
labels = ["A0","F1","G1","P1U","P1","C0","C1"];
idx = find(labels==label,1);
if isempty(idx), order=999; else, order=idx; end
end

function Tcmp = build_part1_comparison_local(T)
Tcmp = T;
Tcmp.CostSavingVsF1_pct = nan(height(T),1);
Tcmp.ReserveRatioReductionVsF1 = nan(height(T),1);
Tcmp.FreqDevChangeVsF1_Hz = nan(height(T),1);

for d = unique(T.DecayRatio).'
    idxD = T.DecayRatio==d;
    idxF1 = idxD & string(T.PaperLabel)=="F1";
    if nnz(idxF1)~=1, continue; end
    f1Cost=T.TotalCost(idxF1);
    f1Alpha=T.MeanReserveRatio(idxF1);
    f1Df=T.MaxAbsFreqDev_Hz(idxF1);
    idx=find(idxD);
    if isfinite(f1Cost)&&f1Cost~=0
        Tcmp.CostSavingVsF1_pct(idx)=100*(f1Cost-T.TotalCost(idx))/f1Cost;
    end
    if isfinite(f1Alpha)
        Tcmp.ReserveRatioReductionVsF1(idx)=f1Alpha-T.MeanReserveRatio(idx);
    end
    if isfinite(f1Df)
        Tcmp.FreqDevChangeVsF1_Hz(idx)=T.MaxAbsFreqDev_Hz(idx)-f1Df;
    end
end
end

function Tcmp = build_part2_comparison_local(T)
Tcmp = T;
Tcmp.CostSavingVsC0_pct = nan(height(T),1);
Tcmp.CostSavingVsC1_pct = nan(height(T),1);
Tcmp.LoadShedReductionVsC0_kWh = nan(height(T),1);
Tcmp.EVUnmetReductionVsC0_kWh = nan(height(T),1);
Tcmp.BESSDeficitReductionVsC0_kWh = nan(height(T),1);

for d = unique(T.DecayRatio).'
    idxD=T.DecayRatio==d;
    idxC0=idxD & string(T.PaperLabel)=="C0";
    idxC1=idxD & string(T.PaperLabel)=="C1";
    if nnz(idxC0)~=1, continue; end
    c0Cost=T.TotalCost(idxC0);
    c0LS=T.LoadShedEnergy_kWh(idxC0);
    c0EV=T.EVUnmetEnergy_kWh(idxC0);
    c0BESS=T.BESSTerminalDeficit_kWh(idxC0);
    c1Cost=NaN; if nnz(idxC1)==1, c1Cost=T.TotalCost(idxC1); end
    idx=find(idxD);

    if isfinite(c0Cost)&&c0Cost~=0
        Tcmp.CostSavingVsC0_pct(idx)=100*(c0Cost-T.TotalCost(idx))/c0Cost;
    end
    if isfinite(c1Cost)&&c1Cost~=0
        Tcmp.CostSavingVsC1_pct(idx)=100*(c1Cost-T.TotalCost(idx))/c1Cost;
    end
    if isfinite(c0LS)
        Tcmp.LoadShedReductionVsC0_kWh(idx)=c0LS-T.LoadShedEnergy_kWh(idx);
    end
    if isfinite(c0EV)
        Tcmp.EVUnmetReductionVsC0_kWh(idx)=c0EV-T.EVUnmetEnergy_kWh(idx);
    end
    if isfinite(c0BESS)
        Tcmp.BESSDeficitReductionVsC0_kWh(idx)=c0BESS-T.BESSTerminalDeficit_kWh(idx);
    end
end
end

function print_compact_table_local(T)
wanted={'PaperLabel','DecayRatio','TotalCost','MeanReserveRatio', ...
'MaxAbsFreqDev_Hz','MaxAbsRoCoF_Hz_s','SecurityViolationRate', ...
'LoadShedEnergy_kWh','EVUnmetEnergy_kWh','BESSTerminalDeficit_kWh'};
wanted=wanted(ismember(wanted,T.Properties.VariableNames));
disp(T(:,wanted));
end

function fig = plot_metric_by_method_local( ...
    T,varName,titleText,yLabelText,filePath,vis,doExport,refLine)

if nargin<8
    refLine = [];
end

fig = figure('Visible',vis,'Name',titleText);

labels = string(T.PaperLabel);
y = T.(varName);

bar(categorical(labels,labels,'Ordinal',true),y);
hold on;

if ~isempty(refLine)
    yline(refLine,'--','DisplayName','Security limit');
end

xlabel('Method');
ylabel(yLabelText);
title(titleText);
grid on;
hold off;

if doExport
    exportgraphics(fig,filePath,'Resolution',220);
end

drawnow;
end


function fig = plot_metric_by_decay_local(T,varName,titleText,yLabelText,filePath,vis,doExport,refLine)
if nargin<8, refLine=[]; end
fig=figure('Visible',vis,'Name',titleText);
hold on;
labels=unique(string(T.PaperLabel),'stable');
for k=1:numel(labels)
    idx=string(T.PaperLabel)==labels(k);
    x=T.DecayRatio(idx); y=T.(varName)(idx);
    [x,ord]=sort(x); y=y(ord);
    if any(isfinite(y))
        plot(x,y,'-o','DisplayName',labels(k),'LineWidth',1.2);
    end
end
if ~isempty(refLine), yline(refLine,'--','DisplayName','Security limit'); end
xlabel('PV generation ratio / decay ratio'); ylabel(yLabelText);
title(titleText); grid on; legend('Location','best'); hold off;
if doExport, exportgraphics(fig,filePath,'Resolution',220); end
drawnow;
end

function fig = plot_part2_components_local(T,decay,filePath,vis,doExport)
idx=abs(T.DecayRatio-decay)<1e-12; S=T(idx,:);
if isempty(S), fig=[]; return; end
components=[S.LoadShedEnergy_kWh,S.EVUnmetEnergy_kWh, ...
S.EVCommutingViolation_kWh,S.BESSTerminalDeficit_kWh];
if all(~isfinite(components),'all'), fig=[]; return; end
components(~isfinite(components))=0;
fig=figure('Visible',vis,'Name','Part II shortage allocation');
bar(categorical(string(S.PaperLabel)),components,'stacked');
ylabel('Energy (kWh)');
title(sprintf('Part II shortage allocation at decay %.2f',decay));
legend({'Load shed','EV unmet','EV commuting violation','BESS terminal deficit'}, ...
'Location','best'); grid on;
if doExport, exportgraphics(fig,filePath,'Resolution',220); end
drawnow;
end

function fig = plot_frequency_trajectories_local(records,decay,ids,labels,nominalHz,limitHz,filePath,vis,doExport)
fig=figure('Visible',vis,'Name','Frequency trajectories');
hold on; plotted=false;
for k=1:numel(ids)
    rec=get_record_local(records,ids(k),decay);
    if isempty(rec)||~isfield(rec.result,'freq_Hz')||isempty(rec.result.freq_Hz), continue; end
    f=double(rec.result.freq_Hz(:));
    t=time_axis_local(rec.result,numel(f));
    plot(t,f,'DisplayName',labels(k),'LineWidth',1.0);
    plotted=true;
end
if ~plotted, close(fig); fig=[]; return; end
yline(nominalHz+limitHz,'--','HandleVisibility','off');
yline(nominalHz-limitHz,'--','HandleVisibility','off');
xlabel('Time (h)'); ylabel('Frequency (Hz)');
title(sprintf('Representative frequency trajectories, decay %.2f',decay));
legend('Location','best'); grid on; hold off;
if doExport, exportgraphics(fig,filePath,'Resolution',220); end
drawnow;
end

function fig = plot_reserve_ratio_trajectories_local(records,decay,ids,labels,filePath,vis,doExport)
fig=figure('Visible',vis,'Name','Reserve-ratio trajectories');
hold on; plotted=false;
for k=1:numel(ids)
    rec=get_record_local(records,ids(k),decay);
    if isempty(rec), continue; end
    ratio=extract_reserve_ratio_local(rec.result);
    if isempty(ratio), continue; end
    ratio=double(ratio(:)); t=linspace(0,24,numel(ratio)).';
    stairs(t,ratio,'DisplayName',labels(k),'LineWidth',1.0);
    plotted=true;
end
if ~plotted, close(fig); fig=[]; return; end
xlabel('Time (h)'); ylabel('Reserve ratio \alpha');
title(sprintf('Reserve-ratio trajectories, decay %.2f',decay));
ylim([0 1.05]); legend('Location','best'); grid on; hold off;
if doExport, exportgraphics(fig,filePath,'Resolution',220); end
drawnow;
end

function ratio = extract_reserve_ratio_local(result)
ratio=[];
if ~isfield(result,'reserve')||isempty(result.reserve)||~isstruct(result.reserve), return; end
r=result.reserve;
candidates={'ratio','reserveRatio','alpha','alphaSelected','selectedAlpha', ...
'ratioRecord','reserveRatioRecord'};
for k=1:numel(candidates)
    name=candidates{k};
    if isfield(r,name)
        x=r.(name);
        if isnumeric(x)&&isvector(x)&&~isempty(x), ratio=x; return; end
    end
end
end

function rec = get_record_local(records,id,decay)
rec=[];
for k=1:numel(records)
    if string(records(k).methodID)==string(id) && ...
            abs(records(k).decayRatio-decay)<1e-12
        rec=records(k); return;
    end
end
end

function t = time_axis_local(result,n)
if isfield(result,'time_h') && ~isempty(result.time_h)
    x=double(result.time_h(:));
    if numel(x)==n, t=x; return; end
    if numel(x)==n-1 && n>1
        dt=median(diff(x)); t=[x; x(end)+dt]; return;
    end
    if numel(x)>n, t=x(1:n); return; end
end
t=linspace(0,24,n).';
end

function findings = derive_key_findings_local(part1Cmp,part2Cmp)
rows=struct([]);
for d=unique(part1Cmp.DecayRatio).'
    idx=part1Cmp.DecayRatio==d & string(part1Cmp.PaperLabel)=="P1";
    if nnz(idx)==1
        r=struct('Section',"Part I",'Comparison',"P1 vs F1", ...
            'DecayRatio',d,'CostSaving_pct',part1Cmp.CostSavingVsF1_pct(idx), ...
            'PrimaryEnergySaving_kWh',NaN, ...
            'SecurityViolationRate',part1Cmp.SecurityViolationRate(idx));
        if isempty(rows), rows=r; else, rows(end+1)=r; end %#ok<AGROW>
    end
end
for d=unique(part2Cmp.DecayRatio).'
    idx=part2Cmp.DecayRatio==d & string(part2Cmp.PaperLabel)=="P1";
    if nnz(idx)==1
        r=struct('Section',"Part II",'Comparison',"P1 vs C0", ...
            'DecayRatio',d,'CostSaving_pct',part2Cmp.CostSavingVsC0_pct(idx), ...
            'PrimaryEnergySaving_kWh',part2Cmp.LoadShedReductionVsC0_kWh(idx), ...
            'SecurityViolationRate',part2Cmp.SecurityViolationRate(idx));
        if isempty(rows), rows=r; else, rows(end+1)=r; end %#ok<AGROW>
    end
end
if isempty(rows), findings=table(); else, findings=struct2table(rows); end
end
