function [Asc_ass_cell,bsc_ass_cell,dsc_ass_cell,gamma_ass_cell]=ConeConstraintsForBFS_SOCP(Line,Kday,N_DG,N_batt)
% Note: the root bus need to be defined as 1
LD=zeros(size(Line,1),5);
    LD(:,1)=1:size(Line,1);
    LD(:,2)=Line(:,1);
    LD(:,3)=Line(:,2);
    LD(:,4)=Line(:,3);
    LD(:,5)=Line(:,4);

Nbranch = size(LD,1);     
Nbus = max(max(LD(:,2:3)));

% index of the decision variable, which is the column index of Aeq
idx_P = 1:Nbranch;
idx_l = Nbranch+1:2*Nbranch;
idx_v = 2*Nbranch+1:3*Nbranch;

totalVars=3*Nbranch;
Asc_box = [];
bsc_box = [];
dsc_box = [];
gamma_vec = zeros(Nbranch,1);


for e = 1:Nbranch
	INbus = LD(e,2); OUTbus = LD(e,3);
	Asc = zeros(2, totalVars); 
	bsc = zeros(2, 1);
	dsc = zeros(totalVars, 1);
	gamma = 0;

	Asc(1, idx_P(e)) = 2;
	if INbus == 1
		bsc(2) = -1;
		gamma = -1;
	else
		Asc(2, idx_v(INbus-1)) = 1;
		dsc(idx_v(INbus-1)) = 1;
	end
	Asc(2, idx_l(e)) = -1;
	dsc(idx_l(e)) = 1;

	Asc_box(:,:,e) = Asc;
	bsc_box(:,:,e) = bsc;
	dsc_box(:,:,e) = dsc;
	gamma_vec(e) = gamma;
end

% assembly matrix
Asc_ass_cell= cell(Nbranch,1);
bsc_ass_cell = cell(Nbranch*Kday,1);
dsc_ass_cell = cell(Nbranch*Kday,1);
gamma_ass_cell = cell(Nbranch*Kday,1);

offset = Kday*N_DG + 2*Kday*N_batt + 2*Kday;
ind=1;
for k=1:Kday
    for e=1:Nbranch
        Asc = zeros(2, offset+totalVars*Kday); 
        Asc(:,offset+1+(k-1)*totalVars:offset+k*totalVars)=Asc_box(:,:,e);
        Asc_ass_cell{ind}=Asc;

        bsc_ass_cell{ind}   = bsc_box(:,:,e);

        dsc = zeros(1, offset+totalVars*Kday); 
        dsc(:,offset+1+(k-1)*totalVars:offset+k*totalVars)=dsc_box(:,:,e);
        dsc_ass_cell{ind}=dsc;

        gamma_ass_cell{ind} = gamma_vec(e);
        ind=ind+1;
    end
end
end
