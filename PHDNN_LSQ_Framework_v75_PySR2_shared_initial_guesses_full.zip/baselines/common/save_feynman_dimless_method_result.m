function recordFile = save_feynman_dimless_method_result(resultsRoot,iRound,caseName,methodField,methodLabel,result,context,quiet)
%SAVE_FEYNMAN_DIMLESS_METHOD_RESULT Save exactly one Feynman method/case/round.
% Each record is an independent MAT file. Updating one method therefore does
% not load, copy, or rewrite any other method's results.

    if nargin < 7 || isempty(context); context = struct(); end
    if nargin < 8 || isempty(quiet); quiet = false; end

    [recordFile, recordDir] = feynman_dimless_method_record_file( ...
        resultsRoot, iRound, caseName, methodField);
    if ~exist(recordDir,'dir'); mkdir(recordDir); end

    savedAt = char(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));
    feynmanMethodRecord = struct( ...
        'schema','feynman_dimless_method_record_v2_sharded', ...
        'methodField',methodField, ...
        'methodLabel',methodLabel, ...
        'round',iRound, ...
        'caseName',caseName, ...
        'savedAt',savedAt, ...
        'result',result, ...
        'context',context); %#ok<NASGU>

    % Atomic replacement avoids leaving a half-written record if MATLAB is
    % interrupted. -v7 is compact/fast for these individual records; fall
    % back to -v7.3 only if a single record exceeds the v7 limit.
    tmpFile = [tempname(recordDir) '.mat'];
    cleanupObj = onCleanup(@() cleanup_temp_local(tmpFile)); %#ok<NASGU>
    try
        save(tmpFile,'feynmanMethodRecord','-v7');
    catch
        save(tmpFile,'feynmanMethodRecord','-v7.3');
    end
    movefile(tmpFile, recordFile, 'f');

    if ~quiet
        fprintf('[Feynman checkpoint] %s | round %d | %s\n',caseName,iRound,methodLabel);
        fprintf('  -> %s\n',recordFile);
    end
end

function cleanup_temp_local(tmpFile)
    if exist(tmpFile,'file')
        try delete(tmpFile); catch, end
    end
end
