function [result,found,record] = load_feynman_dimless_method_result(resultsRoot,iRound,caseName,methodField,methodLabel,compact)
%LOAD_FEYNMAN_DIMLESS_METHOD_RESULT Load one small sharded Feynman record only.

    if nargin < 6; compact = true; end
    result = []; found = false; record = struct();

    [recordFile,~] = feynman_dimless_method_record_file( ...
        resultsRoot,iRound,caseName,methodField);
    if ~exist(recordFile,'file')
        warning('No saved Feynman record: case=%s round=%d method=%s.\nExpected: %s', ...
            caseName,iRound,methodLabel,recordFile);
        return;
    end

    S = load(recordFile,'feynmanMethodRecord');
    if ~isfield(S,'feynmanMethodRecord') || ~isstruct(S.feynmanMethodRecord)
        warning('Invalid Feynman method record: %s',recordFile);
        return;
    end
    record = S.feynmanMethodRecord;
    if ~isfield(record,'result')
        warning('Feynman method record has no result payload: %s',recordFile);
        return;
    end
    result = record.result;
    found = true;

    fprintf('\n[Feynman replay] %s | round %d | %s\n',caseName,iRound,methodLabel);
    if isfield(record,'savedAt'); fprintf('Saved at          : %s\n',record.savedAt); end
    fprintf('Record file       : %s\n',recordFile);
    if ~compact
        disp(result);
        return;
    end

    expr = getfield_default_local(result,'selectedExpressions',{});
    if isempty(expr) && isfield(result,'stage0Expressions'); expr = result.stage0Expressions; end
    if ~isempty(expr)
        if ischar(expr) || isstring(expr); expr = cellstr(expr); end
        parts = cell(1,numel(expr));
        for k = 1:numel(expr)
            parts{k} = sprintf('y%d=%s',k,char(string(expr{k})));
        end
        fprintf('Selected expr.    : %s\n',strjoin(parts,'; '));
    end
    fprintf('Validation RMSE   : %.6e\n',metric_from_result_local(result,'valMetrics','rmse'));
    fprintf('ID-test RMSE      : %.6e\n',metric_from_result_local(result,'testMetrics','rmse'));
    fprintf('OOD RMSE          : %.6e\n',metric_from_result_local(result,'oodMetrics','rmse'));
    t = getfield_default_local(result,'trainTime',NaN);
    if ~isfinite(t) && isfield(result,'timeStats')
        t = getfield_default_local(result.timeStats,'total',NaN);
    end
    fprintf('Training time [s] : %.3f\n',t);
end

function x = metric_from_result_local(R,f,n)
    x = NaN;
    if isstruct(R) && isfield(R,f) && isstruct(R.(f))
        x = getfield_default_local(R.(f),n,NaN);
    end
    if ~isfinite(x) && strcmp(f,'testMetrics') && isfield(R,'metrics')
        x = getfield_default_local(R.metrics,'rmse',NaN);
    end
end

function v = getfield_default_local(S,n,d)
    if isstruct(S) && isfield(S,n) && ~isempty(S.(n)); v = S.(n); else; v = d; end
end
