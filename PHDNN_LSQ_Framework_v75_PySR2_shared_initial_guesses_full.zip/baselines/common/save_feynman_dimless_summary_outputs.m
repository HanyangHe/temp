function save_feynman_dimless_summary_outputs(summaryFile,summaryRows,metadata)
%SAVE_FEYNMAN_DIMLESS_SUMMARY_OUTPUTS Save only the lightweight summary.
% Full method results live in independent sharded record files and are never
% duplicated into this summary file.

    if nargin < 3 || isempty(metadata); metadata = struct(); end
    folder = fileparts(summaryFile);
    if ~exist(folder,'dir'); mkdir(folder); end

    feynmanSummary = struct();
    feynmanSummary.schema = 'feynman_dimless_summary_v2_sharded';
    feynmanSummary.summaryRows = summaryRows;
    feynmanSummary.metadata = metadata;
    feynmanSummary.lastUpdated = char(datetime('now','Format','yyyy-MM-dd HH:mm:ss')); %#ok<NASGU>

    tmpFile = [tempname(folder) '.mat'];
    cleanupObj = onCleanup(@() cleanup_temp_local(tmpFile)); %#ok<NASGU>
    save(tmpFile,'feynmanSummary','-v7');
    movefile(tmpFile,summaryFile,'f');
    fprintf('[Feynman summary] lightweight summary -> %s\n',summaryFile);
end

function cleanup_temp_local(tmpFile)
    if exist(tmpFile,'file')
        try delete(tmpFile); catch, end
    end
end
