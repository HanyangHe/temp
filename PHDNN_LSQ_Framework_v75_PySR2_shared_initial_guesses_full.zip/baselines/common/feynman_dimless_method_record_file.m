function [recordFile, recordDir, methodFolder] = feynman_dimless_method_record_file(resultsRoot,iRound,caseName,methodField)
%FEYNMAN_DIMLESS_METHOD_RECORD_FILE Path for one independently saved Feynman record.
% Storage is intentionally sharded by method, round, and case so replaying or
% overwriting one result never loads or rewrites the other methods.

    if nargin < 4
        error('resultsRoot, iRound, caseName, and methodField are required.');
    end
    resultsRoot = char(string(resultsRoot));
    if endsWith(lower(resultsRoot), '.mat')
        % Compatibility guard for callers using the obsolete monolithic path.
        resultsRoot = fileparts(resultsRoot);
    end

    switch lower(char(string(methodField)))
        case 'phdn'
            methodFolder = 'PhDN';
        case 'stage0sr'
            methodFolder = 'Stage0SR_ProposedScore';
        case {'pysroriginalscore','pysr_original_score'}
            methodFolder = 'PySR_OriginalScore';
        case 'mlp'
            methodFolder = 'MLP';
        case 'eql'
            methodFolder = 'EQL_Div';
        case 'kan'
            methodFolder = 'KAN_Pruned';
        case 'sindy'
            methodFolder = 'SINDy';
        otherwise
            methodFolder = matlab.lang.makeValidName(char(string(methodField)));
    end

    roundFolder = sprintf('round_%02d', iRound);
    safeCase = matlab.lang.makeValidName(strrep(char(string(caseName)), '.', 'p'));
    recordDir = fullfile(resultsRoot, 'methods', methodFolder, roundFolder);
    recordFile = fullfile(recordDir, [safeCase '.mat']);
end
